Stub include files for compiling Abaqus user subroutines with gfortran OUTSIDE Abaqus.
Compile a listing:   gfortran -c -ffixed-form -std=legacy -I/home/claude/book/lib/aba file.f
Link a test driver:  gfortran -ffixed-form -std=legacy -I/home/claude/book/lib/aba driver.f file.f /home/claude/book/lib/aba/stubs.f -o t && ./t
stubs.f provides dummy XIT, GETOUTDIR, GETJOBNAME, STDB_ABQERR, GETNUMCPUS, GETRANK, MUTEXLOCK/UNLOCK, MUTEXINIT, SINV, SPRINC, SPRIND, XPLB_EXIT (no ROTSIG)
(SINV/SPRINC/SPRIND are simplified re-implementations for testing only).
Real Abaqus is NOT available here: never claim a listing was run in Abaqus.
