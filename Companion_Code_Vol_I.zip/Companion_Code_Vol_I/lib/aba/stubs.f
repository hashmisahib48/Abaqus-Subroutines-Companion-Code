      SUBROUTINE XIT
      WRITE(*,*) 'XIT called (stub): analysis would stop here'
      STOP
      END
      SUBROUTINE XPLB_EXIT
      STOP
      END
      SUBROUTINE GETOUTDIR(OUTDIR,LENOUT)
      CHARACTER*(*) OUTDIR
      OUTDIR='.'
      LENOUT=1
      END
      SUBROUTINE GETJOBNAME(JOBNAME,LENJOBNAME)
      CHARACTER*(*) JOBNAME
      JOBNAME='testjob'
      LENJOBNAME=7
      END
      SUBROUTINE STDB_ABQERR(LOP,STRING,INTV,REALV,CHARV)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) STRING
      CHARACTER*8 CHARV(*)
      DIMENSION INTV(*),REALV(*)
      WRITE(*,*) 'STDB_ABQERR',LOP,' ',TRIM(STRING)
      IF (LOP.EQ.-3) STOP
      END
      SUBROUTINE GETNUMCPUS(N)
      N=1
      END
      SUBROUTINE GETRANK(N)
      N=0
      END
      SUBROUTINE MUTEXINIT(N)
      END
      SUBROUTINE MUTEXLOCK(N)
      END
      SUBROUTINE MUTEXUNLOCK(N)
      END
C     SINV: first and second invariants (mean pressure-type trace/3 and Mises)
      SUBROUTINE SINV(STRESS,SINV1,SINV2,NDI,NSHR)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(*)
      SINV1=0.D0
      DO K=1,NDI
        SINV1=SINV1+STRESS(K)
      ENDDO
      SINV1=SINV1/3.D0
      S2=0.D0
      DO K=1,NDI
        S2=S2+(STRESS(K)-SINV1)**2
      ENDDO
      IF (NDI.LT.3) S2=S2+SINV1**2*(3-NDI)
      DO K=NDI+1,NDI+NSHR
        S2=S2+2.D0*STRESS(K)**2
      ENDDO
      SINV2=SQRT(1.5D0*S2)
      END
C     SPRINC: principal values of a symmetric tensor (LSTR=1 stress, 2 strain)
      SUBROUTINE SPRINC(S,PS,LSTR,NDI,NSHR)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(*),PS(3),A(3,3),AN(3,3)
      CALL STUBTEN(S,A,LSTR,NDI,NSHR)
      CALL STUBJAC(A,PS,AN)
      END
      SUBROUTINE SPRIND(S,PS,AN,LSTR,NDI,NSHR)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(*),PS(3),AN(3,3),A(3,3),V(3,3)
      CALL STUBTEN(S,A,LSTR,NDI,NSHR)
      CALL STUBJAC(A,PS,V)
C     Abaqus returns direction cosines of principal direction K in AN(K,1:3)
      DO K=1,3
        DO J=1,3
          AN(K,J)=V(J,K)
        ENDDO
      ENDDO
      END
      SUBROUTINE STUBTEN(S,A,LSTR,NDI,NSHR)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(*),A(3,3)
      A=0.D0
      F=1.D0
      IF (LSTR.EQ.2) F=0.5D0
      DO K=1,NDI
        A(K,K)=S(K)
      ENDDO
      IF (NSHR.GE.1) THEN
        A(1,2)=F*S(NDI+1)
        A(2,1)=A(1,2)
      ENDIF
      IF (NSHR.GE.2) THEN
        A(1,3)=F*S(NDI+2)
        A(3,1)=A(1,3)
      ENDIF
      IF (NSHR.GE.3) THEN
        A(2,3)=F*S(NDI+3)
        A(3,2)=A(2,3)
      ENDIF
      END
C     Jacobi eigen-solver for 3x3 symmetric A (copy); eigenvectors in columns of V
      SUBROUTINE STUBJAC(A0,D,V)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A0(3,3),A(3,3),D(3),V(3,3)
      A=A0
      V=0.D0
      DO K=1,3
        V(K,K)=1.D0
      ENDDO
      DO IT=1,50
        OFF=A(1,2)**2+A(1,3)**2+A(2,3)**2
        IF (OFF.LT.1.D-30) GOTO 10
        DO IP=1,2
          DO IQ=IP+1,3
            IF (ABS(A(IP,IQ)).GT.1.D-300) THEN
              TH=(A(IQ,IQ)-A(IP,IP))/(2.D0*A(IP,IQ))
              T=SIGN(1.D0,TH)/(ABS(TH)+SQRT(TH*TH+1.D0))
              C=1.D0/SQRT(T*T+1.D0)
              SN=T*C
              DO K=1,3
                AKP=A(K,IP)
                AKQ=A(K,IQ)
                A(K,IP)=C*AKP-SN*AKQ
                A(K,IQ)=SN*AKP+C*AKQ
              ENDDO
              DO K=1,3
                APK=A(IP,K)
                AQK=A(IQ,K)
                A(IP,K)=C*APK-SN*AQK
                A(IQ,K)=SN*APK+C*AQK
              ENDDO
              DO K=1,3
                VKP=V(K,IP)
                VKQ=V(K,IQ)
                V(K,IP)=C*VKP-SN*VKQ
                V(K,IQ)=SN*VKP+C*VKQ
              ENDDO
            ENDIF
          ENDDO
        ENDDO
      ENDDO
   10 DO K=1,3
        D(K)=A(K,K)
      ENDDO
      END
