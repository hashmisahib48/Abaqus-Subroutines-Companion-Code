      SUBROUTINE DLOAD(F,KSTEP,KINC,TIME,NOEL,NPT,LAYER,KSPT,
     1 COORDS,JLTYP,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!
!     Centrifugal body force per unit volume, one point per call
!     RHO in tonne/mm^3, OMEGA in rad/s  ->  F in N/mm^3
      PARAMETER (RHO = 7.85D-9, OMEGA = 1000.0D0)
      F = RHO*OMEGA**2*COORDS(1)
      RETURN
      END
