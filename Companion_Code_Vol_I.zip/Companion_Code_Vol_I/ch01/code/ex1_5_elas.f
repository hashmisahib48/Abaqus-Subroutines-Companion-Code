      SUBROUTINE K1_ELAS(PROPS, DSTRAN, STRESS, DDSDDE)
!     Isotropic elastic update of one material point, 3D, Voigt order
!     11,22,33,12,13,23 (engineering shear strains).
!     PROPS(1) = E in MPa, PROPS(2) = NU (-)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(2), DSTRAN(6), STRESS(6), DDSDDE(6,6)
      E  = PROPS(1)
      XNU = PROPS(2)
      EG = E/(2.0D0*(1.0D0 + XNU))
      EL = E*XNU/((1.0D0 + XNU)*(1.0D0 - 2.0D0*XNU))
      DO J = 1, 6
         DO I = 1, 6
            DDSDDE(I,J) = 0.0D0
         ENDDO
      ENDDO
      DO J = 1, 3
         DO I = 1, 3
            DDSDDE(I,J) = EL
         ENDDO
         DDSDDE(J,J)     = EL + 2.0D0*EG
         DDSDDE(J+3,J+3) = EG
      ENDDO
      DO I = 1, 6
         DO J = 1, 6
            STRESS(I) = STRESS(I) + DDSDDE(I,J)*DSTRAN(J)
         ENDDO
      ENDDO
      RETURN
      END
