# call counts and times used in Example 1.5-1 and Problem 1A.3 (per-call costs rounded from cost_output.txt)
ta,tw=0.03e-6,2.4e-6; B=85  # s per call (arithmetic, formatted WRITE of 6 numbers); bytes per record
def row(name,nel,nip,inc,it):
    n=nel*nip*inc*it
    print(f"{name:10s} N_calls={n:.3e}  arith {n*ta:8.2f} s  write {n*tw:9.1f} s ({n*tw/60:6.1f} min)  file {n*B/1e9:7.2f} GB")
row('A 2D',5000,4,30,4)
row('B example',20000,8,50,4)
row('C large',500000,8,100,5)
row('1A.3 UMAT',25000,8,40,3.5)
row('1A.3 DLOAD',2500,4,40,3.5)
