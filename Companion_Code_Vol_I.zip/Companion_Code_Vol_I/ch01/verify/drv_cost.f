      PROGRAM DRVCOST
!     Times K1_ELAS called point by point (Standard-like), with a guarded
!     and an unguarded formatted WRITE, and with an OPEN/READ/CLOSE per call.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PROPS(2), DSTRAN(6), STRESS(6), DDSDDE(6,6)
      INTEGER*8 N, IC0, IC1, IR, I8
      PROPS(1) = 210000.D0
      PROPS(2) = 0.3D0
      N = 20000000_8
      DO I = 1, 6
         STRESS(I) = 0.D0
         DSTRAN(I) = 1.D-9*I
      ENDDO
      CALL SYSTEM_CLOCK(IC0, IR)
      DO I8 = 1, N
         DSTRAN(1) = 1.D-9*MOD(I8,7_8)
         CALL K1_ELAS(PROPS, DSTRAN, STRESS, DDSDDE)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      T1 = DBLE(IC1-IC0)/DBLE(IR)
      WRITE(*,'(A,ES12.4,A)') ' checksum', STRESS(1), ''
      WRITE(*,'(A,F10.4,A,F8.4,A)') ' arithmetic only    N=2e7  total',
     1   T1, ' s   per call', 1.D6*T1/N, ' us'
!     formatted WRITE of 6 numbers per call to a file
      OPEN(7, FILE='wr.tmp', STATUS='REPLACE')
      N = 1000000_8
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         CALL K1_ELAS(PROPS, DSTRAN, STRESS, DDSDDE)
         WRITE(7,'(6ES14.5)') (STRESS(I), I=1,6)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      CLOSE(7, STATUS='DELETE')
      T2 = DBLE(IC1-IC0)/DBLE(IR)
      WRITE(*,'(A,F10.4,A,F8.4,A)') ' + formatted WRITE N=1e6  total',
     1   T2, ' s   per call', 1.D6*T2/N, ' us'
!     OPEN / READ / CLOSE of a small file per call
      OPEN(8, FILE='in.tmp', STATUS='REPLACE')
      WRITE(8,'(2ES14.5)') 210000.D0, 0.3D0
      CLOSE(8)
      N = 100000_8
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         OPEN(9, FILE='in.tmp', STATUS='OLD')
         READ(9,*) PROPS(1), PROPS(2)
         CLOSE(9)
         CALL K1_ELAS(PROPS, DSTRAN, STRESS, DDSDDE)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      OPEN(9, FILE='in.tmp', STATUS='OLD')
      CLOSE(9, STATUS='DELETE')
      T3 = DBLE(IC1-IC0)/DBLE(IR)
      WRITE(*,'(A,F10.4,A,F8.4,A)') ' + OPEN/READ/CLOSE N=1e5  total',
     1   T3, ' s   per call', 1.D6*T3/N, ' us'
      END
