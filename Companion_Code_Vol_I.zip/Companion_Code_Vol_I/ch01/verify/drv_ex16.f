      PROGRAM DRV16
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION TIME(2), PROPS(1), SVARS(1), SV(1), LFI(4), LFD(6)
      DIMENSION JLT(1), AD(1)
      CHARACTER*80 SN(1), AN
      DIMENSION TT(5)
      DATA TT /0.0D0, 0.1D0, 0.3D0, 0.4D0, 0.5D0/
      AN = 'RAMP'
      LFI(1) = 0
      LFI(2) = 1
      LFI(3) = 0
      LFI(4) = 1
      SV(1) = 0.D0
      SN(1) = ' '
      DO K = 1, 5
         TIME(1) = TT(K)
         TIME(2) = TT(K)
         CALL UAMP(AN, TIME, 0.D0, 0.1D0, 0, PROPS, 1, SVARS, LFI,
     1    0, SV, SN, JLT, AVN, LFD, D1, D2, D3, D4)
         WRITE(*,'(A,F5.2,A,F8.4)') ' t =', TT(K), '  amplitude =', AVN
      ENDDO
      END
