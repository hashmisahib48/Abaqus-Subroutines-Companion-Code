import numpy as np
s0,Q,b=250.0,150.0,12.0
f=lambda e: s0+Q*(1-np.exp(-b*e))
pts=np.array([0,0.0025,0.005,0.01,0.015,0.02,0.03,0.04,0.06,0.08,0.1,0.15,0.2,0.3])
e=np.linspace(0,0.3,300001)
err=np.abs(np.interp(e,pts,f(pts))-f(e))
print(len(pts),'points; max err',err.max(),'at',e[err.argmax()], 'rel to sy',err.max()/f(e[err.argmax()]))
print('sy(0.3)',f(0.3),'sy(0.1)',f(0.1))
# geometric table
for n in (8,10,14,20):
    p=np.concatenate([[0],np.geomspace(0.0025,0.3,n-1)])
    er=np.abs(np.interp(e,p,f(p))-f(e)); print(n,'geom pts max err',er.max())
# uniform tables
for n in (8,14,31,61):
    p=np.linspace(0,0.3,n); er=np.abs(np.interp(e,p,f(p))-f(e)); print(n,'uniform pts max err',er.max())
