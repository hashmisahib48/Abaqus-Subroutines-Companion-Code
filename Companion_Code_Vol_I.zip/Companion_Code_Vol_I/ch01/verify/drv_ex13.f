      PROGRAM DRV13
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION TIME(2), COORDS(3), CC(4,2), VEL(4,2), DC(4,2,2)
      DIMENSION VAL(4)
      CHARACTER*80 SNAME
      SNAME = ' '
      TIME(1) = 0.D0
      TIME(2) = 0.D0
      COORDS(2) = 0.D0
      COORDS(3) = 0.D0
      CC(1,1) = 100.D0
      CC(2,1) = 150.D0
      CC(3,1) = 200.D0
      CC(4,1) = 300.D0
      DO K = 1, 4
         CC(K,2) = 0.D0
         VEL(K,1) = 0.D0
         VEL(K,2) = 0.D0
      ENDDO
      CALL VDLOAD(4, 2, 0.D0, 0.D0, 1.D0, CC, VEL, DC, 0, SNAME, VAL)
      DO K = 1, 4
         COORDS(1) = CC(K,1)
         CALL DLOAD(F, 1, 1, TIME, 1, 1, 1, 1, COORDS, 0, SNAME)
         WRITE(*,'(A,F7.1,A,ES14.6,A,ES14.6,A,ES10.2)') ' x =',
     1    CC(K,1), '  DLOAD', F, '  VDLOAD', VAL(K), '  diff', F-VAL(K)
      ENDDO
      END
