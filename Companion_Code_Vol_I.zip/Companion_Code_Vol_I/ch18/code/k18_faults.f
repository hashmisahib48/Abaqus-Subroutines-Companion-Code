      SUBROUTINE K18_STEP(STRESS, STATEV, NSTATV, IFAULT)
!     Three typical run-time faults of a material routine, selected
!     by IFAULT.  Fragment of a UMAT-like update; units: MPa.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(6), STATEV(NSTATV), XN(6)
      IF (IFAULT .EQ. 1) THEN
!        fault 1: the loop runs one past the declared length
         DO I = 1, NSTATV + 1
            STATEV(I) = 0.0D0
         ENDDO
      ELSEIF (IFAULT .EQ. 2) THEN
!        fault 2: DP is set on one path only
         IF (STRESS(1) .GT. 1.0D0) DP = 1.0D-3
         STATEV(1) = STATEV(1) + DP
      ELSEIF (IFAULT .EQ. 3) THEN
!        fault 3: unit flow direction before the yield test; the
!        stress is zero at the first call of a step
         Q = SQRT(STRESS(1)**2 + STRESS(2)**2 + STRESS(3)**2)
         DO I = 1, 6
            XN(I) = STRESS(I)/Q
         ENDDO
         STATEV(2) = XN(1)
      ENDIF
      RETURN
      END
!
      PROGRAM K18FLT
!     Driver: calls K18_STEP with a zero stress, as at the start of
!     a step.  Usage: k18flt N   (N = 0 to 3)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(6), STATEV(2)
      CHARACTER*8 ARG
      CALL GET_COMMAND_ARGUMENT(1, ARG)
      READ(ARG,*) IFAULT
      STRESS = 0.0D0
      STATEV = 0.0D0
      CALL K18_STEP(STRESS, STATEV, 2, IFAULT)
      WRITE(*,'(A,I2,A,2ES12.4)') 'fault', IFAULT, '  STATEV =',
     1   STATEV
      END
