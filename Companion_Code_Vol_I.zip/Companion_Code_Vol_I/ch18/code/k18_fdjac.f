      SUBROUTINE K18_FDJAC(S0, SV0, DSTRAN, PROPS, H, DFD, ETA)
!     Central-difference Jacobian DFD of the UMAT stress (Eq. 18.6-1)
!     from the start state S0, SV0 (NTENS = 6).  ETA = max|DFD-DDSDDE|
!     / max|DDSDDE|.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S0(6), SV0(1), DSTRAN(6), PROPS(*), DFD(6,6)
      DIMENSION S(6), SV(1), D(6,6), DD(6,6), DE(6)
      S = S0
      SV = SV0
      CALL K18_CALL(S, SV, D, DSTRAN, PROPS, 1)
      DFD = 0.0D0
      DO J = 1, 6
         DO ISGN = -1, 1, 2
            DE = DSTRAN
            DE(J) = DSTRAN(J) + ISGN*H
            S = S0
            SV = SV0
            CALL K18_CALL(S, SV, DD, DE, PROPS, 1)
            DFD(:,J) = DFD(:,J) + ISGN*S/(2.0D0*H)
         ENDDO
      ENDDO
      ETA = MAXVAL(ABS(DFD - D))/MAXVAL(ABS(D))
      RETURN
      END
!
      SUBROUTINE K18_CALL(STRESS, STATEV, DDSDDE, DSTRAN, PROPS, NOEL)
!     Calls UMAT as Abaqus does for one point (NTENS = 6)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(6), STATEV(1), DDSDDE(6,6), DSTRAN(6)
      DIMENSION PROPS(7), TIME(2), PREDEF(1), DPRED(1), COORDS(3)
      DIMENSION DROT(3,3), DFG0(3,3), DFG1(3,3), JSTEP(4)
      DIMENSION DDT(6), DRE(6), STRAN(6)
      CHARACTER*80 CMNAME
      TIME = 0.0D0
      STRAN = 0.0D0
      CMNAME = 'K18J2'
      JSTEP = (/ 1, 1, 0, 0 /)
      CALL UMAT(STRESS, STATEV, DDSDDE, SSE, SPD, SCD, RPL, DDT,
     1  DRE, DRPLDT, STRAN, DSTRAN, TIME, 1.0D0, 20.0D0, 0.0D0,
     2  PREDEF, DPRED, CMNAME, 3, 3, 6, 1, PROPS, 7, COORDS, DROT,
     3  PNEWDT, 1.0D0, DFG0, DFG1, NOEL, 1, 1, 1, JSTEP, 1)
      RETURN
      END
