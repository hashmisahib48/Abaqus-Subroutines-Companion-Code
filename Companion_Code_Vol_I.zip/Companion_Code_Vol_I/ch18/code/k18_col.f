      PROGRAM K18COL
!     Newton-Raphson driver for a confined column of NE elements in
!     series (uniaxial strain, one K18_J2 point per element).  Node 0
!     is fixed, node NE is displaced; area 1 mm**2, length 1 mm, so
!     forces are stresses (N, MPa).  Convergence: largest residual
!     force <= TOLR * mean |stress| (default 0.005, as in Abaqus).  Element 1 is weaker (SYW).
!     Increment control mimics the automatic scheme: a failed
!     increment is repeated with 0.25 of its size.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NE = 6)
      COMMON /K18SV/ ZEP18(2000)
      LOGICAL HIST, OK
      NAMELIST /CIN/ IBUG, NINC, EAVG, MAXIT, TOLR, SYW, HIST, MAXINC
      DIMENSION PRP(7,NE), SIG0(6,NE), SV0(NE), EPS0(NE), U0(0:NE)
      DIMENSION U(0:NE), SIG(6,NE), SV(NE), D(6,6), DS(6), ST(6), SVT(1)
      DIMENSION RES(NE-1), DU(NE-1), A(NE-1), B(NE-1), C(NE-1)
      DIMENSION DD(NE), SN(NE), SVN(NE), EPSN(NE)
      IBUG = 0
      NINC = 4
      EAVG = 0.006D0
      MAXIT = 16
      TOLR = 5.0D-3
      MAXINC = 100
      SYW = 225.0D0
      HIST = .FALSE.
      READ(5, NML=CIN)
      DO IE = 1, NE
         CALL K18_SETP(PRP(1,IE), 1, IBUG)
      ENDDO
      PRP(3,1) = SYW
      ZEP18 = 0.0D0
      SIG0 = 0.0D0
      SV0 = 0.0D0
      EPS0 = 0.0D0
      U0 = 0.0D0
      T = 0.0D0
      DT = 1.0D0/NINC
      NACC = 0
      NCUT = 0
      NITT = 0
      DO WHILE (T .LT. 1.0D0 - 1.0D-12)
         DTT = MIN(DT, 1.0D0 - T)
         DUN = DTT*EAVG*NE
         U = U0
         U(NE) = U0(NE) + DUN
         OK = .FALSE.
         R0 = -1.0D0
         DO IT = 1, MAXIT + 1
!           element calls from the start-of-increment state
            DO IE = 1, NE
               ST = SIG0(:,IE)
               SVT(1) = SV0(IE)
               DS = 0.0D0
               DS(1) = (U(IE) - U(IE-1)) - EPS0(IE)
               CALL K18_CALLP(ST, SVT, D, DS, PRP(1,IE), IE)
               SIG(:,IE) = ST
               SVN(IE) = SVT(1)
               DD(IE) = D(1,1)
            ENDDO
            DO J = 1, NE-1
               RES(J) = SIG(1,J+1) - SIG(1,J)
            ENDDO
            RMAX = MAXVAL(ABS(RES))
            IF (RMAX .NE. RMAX .OR. RMAX .GT. 1.0D8) EXIT
            IF (HIST) WRITE(*,'(A,I3,A,I3,A,I3,A,ES11.3)') 'H inc',
     1         NACC+NCUT+1, ' it', IT, ' cut', NCUT, ' R', RMAX
            IF (RMAX .LE. TOLR*SUM(ABS(SIG(1,:)))/NE) THEN
               OK = .TRUE.
               EXIT
            ENDIF
            IF (IT .GT. MAXIT) EXIT
!           tangent matrix (tridiagonal) and correction
            DO J = 1, NE-1
               A(J) = -DD(J)
               B(J) = DD(J) + DD(J+1)
               C(J) = -DD(J+1)
            ENDDO
            CALL K18_TRI(NE-1, A, B, C, RES, DU)
            DO J = 1, NE-1
               U(J) = U(J) + DU(J)
            ENDDO
         ENDDO
         IF (NACC+NCUT .GT. MAXINC) THEN
            WRITE(*,*) 'ABANDONED: too many increments'
            STOP
         ENDIF
         IF (OK) THEN
            NACC = NACC + 1
            NITT = NITT + IT - 1
            WRITE(*,'(A,I5,A,F8.5,A,F8.5,A,I3)') 'INC', NACC, '  t=',
     1         T + DTT, '  dt=', DTT, '  iterations=', IT - 1
            T = T + DTT
            U0 = U
            SIG0 = SIG
            SV0 = SVN
            DO IE = 1, NE
               EPS0(IE) = U(IE) - U(IE-1)
            ENDDO
            IF (IT .LE. 5) DT = MIN(2.0D0*DT, 1.0D0/NINC)
         ELSE
            NCUT = NCUT + 1
            DT = 0.25D0*DTT
            WRITE(*,'(A,F9.6,A,F9.6)') 'CUTBACK dt', DTT, ' -> ', DT
            IF (DT .LT. 1.0D-5 .OR. NACC+NCUT .GT. MAXINC) THEN
               WRITE(*,*) 'ABANDONED: increment too small or too many'
               STOP
            ENDIF
         ENDIF
      ENDDO
      WRITE(*,'(A,I2,A,I6,A,I4,A,I7)') 'SUM ibug=', IBUG,
     1   '  increments=', NACC, '  cutbacks=', NCUT,
     2   '  iterations=', NITT
      WRITE(*,'(A,F10.4,A,F9.6,A,F9.6)') 'END s11=', SIG0(1,1),
     1   '  eps1=', EPS0(1), '  eps2=', EPS0(2)
      END
!
      SUBROUTINE K18_TRI(N, A, B, C, R, X)
!     Thomas algorithm: A sub-, B main, C super-diagonal
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(N), B(N), C(N), R(N), X(N), CP(N), RP(N)
      CP(1) = C(1)/B(1)
      RP(1) = R(1)/B(1)
      DO I = 2, N
         DEN = B(I) - A(I)*CP(I-1)
         CP(I) = C(I)/DEN
         RP(I) = (R(I) - A(I)*RP(I-1))/DEN
      ENDDO
      X(N) = RP(N)
      DO I = N-1, 1, -1
         X(I) = RP(I) - CP(I)*X(I+1)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K18_SETP(PROPS, IQ, IB)
!     Steel: E, NU, SY0, H, Q, B, IBUG   (MPa); IQ=2: linear hardening
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(7)
      PROPS = (/ 210000.0D0, 0.3D0, 250.0D0, 1000.0D0, 150.0D0,
     1           40.0D0, 0.0D0 /)
      IF (IQ .EQ. 2) PROPS(5) = 0.0D0
      PROPS(7) = IB
      RETURN
      END
!
      SUBROUTINE K18_CALLP(STRESS, STATEV, DDSDDE, DSTRAN, PROPS, NOEL)
!     Calls UMAT as Abaqus does for one point (NTENS = 6)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(6), STATEV(1), DDSDDE(6,6), DSTRAN(6)
      DIMENSION PROPS(7), TIME(2), PREDEF(1), DPRED(1), COORDS(3)
      DIMENSION DROT(3,3), DFG0(3,3), DFG1(3,3), JSTEP(4)
      DIMENSION DDT(6), DRE(6), STRAN(6)
      CHARACTER*80 CMNAME
      TIME = 0.0D0
      STRAN = 0.0D0
      CMNAME = 'K18J2'
      JSTEP = (/ 1, 1, 0, 0 /)
      CALL UMAT(STRESS, STATEV, DDSDDE, SSE, SPD, SCD, RPL, DDT,
     1  DRE, DRPLDT, STRAN, DSTRAN, TIME, 1.0D0, 20.0D0, 0.0D0,
     2  PREDEF, DPRED, CMNAME, 3, 3, 6, 1, PROPS, 7, COORDS, DROT,
     3  PNEWDT, 1.0D0, DFG0, DFG1, NOEL, 1, 1, 1, JSTEP, 1)
      RETURN
      END
