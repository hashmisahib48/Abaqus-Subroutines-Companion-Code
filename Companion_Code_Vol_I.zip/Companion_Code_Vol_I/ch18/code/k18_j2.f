      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),DDSDDE(NTENS,NTENS),
     1 DDSDDT(NTENS),DRPLDE(NTENS),STRAN(NTENS),DSTRAN(NTENS),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3),
     3 DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),JSTEP(4)
!
!     J2 plasticity with Voce hardening, radial return (3D, NTENS=6).
!     Test routine of Chapter 18; the switch IBUG injects faults.
!     PROPS: 1 E (MPa)  2 NU  3 SY0 (MPa)  4 H (MPa)  5 Q (MPa)  6 B
!            7 IBUG: 0 correct             1 stale hardening slope
!                    2 elastic matrix      3 tangent scaled by 0.4
!                    4 plastic state kept in COMMON instead of STATEV
!     STATEV(1) = equivalent plastic strain
      COMMON /K18SV/ ZEP18(2000)
      DIMENSION S(6), STRIAL(6), XN(6)
      E    = PROPS(1)
      XNU  = PROPS(2)
      IBUG = NINT(PROPS(7))
      XMU  = E/(2.0D0*(1.0D0 + XNU))
      XK   = E/(3.0D0*(1.0D0 - 2.0D0*XNU))
      CALL K18_ELAS(DDSDDE, NDI, NTENS, XK, XMU)
      DO I = 1, NTENS
         STRIAL(I) = STRESS(I)
         DO J = 1, NTENS
            STRIAL(I) = STRIAL(I) + DDSDDE(I,J)*DSTRAN(J)
         ENDDO
      ENDDO
      IF (IBUG .EQ. 4) THEN
         EPBAR = ZEP18(NOEL)
      ELSE
         EPBAR = STATEV(1)
      ENDIF
      CALL K18_HARD(PROPS, EPBAR, SY, HP)
      CALL K18_DEV(STRIAL, NTENS, P, S, Q, SN2)
      DP = 0.0D0
      IF (Q - SY .LE. 1.0D-10*PROPS(3)) THEN
         DO I = 1, NTENS
            STRESS(I) = STRIAL(I)
         ENDDO
      ELSE
         CALL K18_RET(PROPS, XMU, Q, EPBAR, DP, HPN)
         THETA = 1.0D0 - 3.0D0*XMU*DP/Q
         DO I = 1, NTENS
            STRESS(I) = THETA*S(I)
         ENDDO
         DO I = 1, NDI
            STRESS(I) = STRESS(I) + P
         ENDDO
         IF (IBUG .NE. 2) THEN
            HT = HPN
            IF (IBUG .EQ. 1) HT = HP
            THBAR = 3.0D0*XMU/(3.0D0*XMU + HT) - (1.0D0 - THETA)
            DO I = 1, NTENS
               XN(I) = S(I)/SQRT(SN2)
            ENDDO
            CALL K18_ELAS(DDSDDE, NDI, NTENS, XK, XMU*THETA)
            DO J = 1, NTENS
               DO I = 1, NTENS
                  DDSDDE(I,J) = DDSDDE(I,J)
     1                        - 2.0D0*XMU*THBAR*XN(I)*XN(J)
               ENDDO
            ENDDO
            IF (IBUG .EQ. 3) DDSDDE = 0.4D0*DDSDDE
         ENDIF
      ENDIF
      IF (IBUG .EQ. 4) ZEP18(NOEL) = EPBAR + DP
      STATEV(1) = EPBAR + DP
      RETURN
      END
!
      SUBROUTINE K18_ELAS(D, NDI, NTENS, XK, XMU)
!     Elastic matrix from bulk modulus XK and shear modulus XMU (MPa)
!     (the volumetric part keeps XK; XMU may carry the factor THETA)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(NTENS,NTENS)
      D = 0.0D0
      DO J = 1, NDI
         DO I = 1, NDI
            D(I,J) = XK - 2.0D0*XMU/3.0D0
         ENDDO
         D(J,J) = D(J,J) + 2.0D0*XMU
      ENDDO
      DO K = NDI+1, NTENS
         D(K,K) = XMU
      ENDDO
      RETURN
      END
!
      SUBROUTINE K18_DEV(SIG, NTENS, P, S, Q, SN2)
!     Mean stress, deviator, S:S and von Mises stress (MPa)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION SIG(NTENS), S(NTENS)
      P = (SIG(1) + SIG(2) + SIG(3))/3.0D0
      DO I = 1, 3
         S(I) = SIG(I) - P
      ENDDO
      SN2 = S(1)**2 + S(2)**2 + S(3)**2
      DO I = 4, NTENS
         S(I) = SIG(I)
         SN2 = SN2 + 2.0D0*S(I)**2
      ENDDO
      Q = SQRT(1.5D0*SN2)
      RETURN
      END
!
      SUBROUTINE K18_HARD(PROPS, EP, SY, HP)
!     Voce law SY = SY0 + H*EP + Q*(1-EXP(-B*EP)) and slope HP (MPa)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*)
      EX = EXP(-PROPS(6)*EP)
      SY = PROPS(3) + PROPS(4)*EP + PROPS(5)*(1.0D0 - EX)
      HP = PROPS(4) + PROPS(5)*PROPS(6)*EX
      RETURN
      END
!
      SUBROUTINE K18_RET(PROPS, XMU, Q, EPBAR, DP, HPN)
!     Solve Q - 3*XMU*DP - SY(EPBAR+DP) = 0 for DP by Newton
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*)
      CALL K18_HARD(PROPS, EPBAR, SY, HP)
      DP = (Q - SY)/(3.0D0*XMU + HP)
      DO IT = 1, 50
         CALL K18_HARD(PROPS, EPBAR + DP, SYN, HPN)
         G = Q - 3.0D0*XMU*DP - SYN
         IF (ABS(G) .LE. 1.0D-12*PROPS(3)) RETURN
         DP = DP + G/(3.0D0*XMU + HPN)
      ENDDO
      RETURN
      END
