      PROGRAM K18FD
!     Finite-difference test of DDSDDE and a one-call-per-increment
!     test of K18_J2 (Chapter 18).  Units N, mm, MPa.
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K18SV/ ZEP18(2000)
      DIMENSION PROPS(7), S0(6), SV0(1), D(6,6), DFD(6,6), DS(6)
      DIMENSION S(6), SV(1)
      DO IQ = 1, 2
         DO IB = 0, 3
            CALL K18_SETP(PROPS, IQ, IB)
!           plastic start state: one increment from the virgin state
            S0 = 0.0D0
            SV0 = 0.0D0
            DS = (/ 4.0D-3, 0.0D0, 0.0D0, 3.0D-3, 0.0D0, 0.0D0 /)
            CALL K18_CALL(S0, SV0, D, DS, PROPS, 1)
!           test increment from that state
            DS = (/ 2.0D-3, -5.0D-4, 3.0D-4, 4.0D-3, 0.0D0, 1.0D-3 /)
            CALL K18_FDJAC(S0, SV0, DS, PROPS, 1.0D-7, DFD, ETA)
            S = S0
            SV = SV0
            CALL K18_CALL(S, SV, D, DS, PROPS, 1)
            WRITE(*,'(A,I2,A,I2,A,ES10.2,A,F8.5)') 'FD q=', IQ,
     1        ' ibug=', IB, '  max|DF-D|/max|D| =', ETA,
     2        '  peeq =', SV(1)
         ENDDO
      ENDDO
!     one call per increment: five uniaxial-strain increments
      DO IB = 0, 4, 4
         CALL K18_SETP(PROPS, 1, IB)
         ZEP18 = 0.0D0
         S = 0.0D0
         SV = 0.0D0
         DS = (/ 2.0D-3, 0.0D0, 0.0D0, 0.0D0, 0.0D0, 0.0D0 /)
         DO K = 1, 5
            CALL K18_CALL(S, SV, D, DS, PROPS, 1)
         ENDDO
         WRITE(*,'(A,I2,A,F10.4,A,F9.6)') 'ONE-CALL ibug=', IB,
     1     '  s11 =', S(1), '  peeq =', SV(1)
      ENDDO
      END
!
      SUBROUTINE K18_SETP(PROPS, IQ, IB)
!     Steel: E, NU, SY0, H, Q, B, IBUG   (MPa); IQ=2: linear hardening
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(7)
      PROPS = (/ 210000.0D0, 0.3D0, 250.0D0, 1000.0D0, 150.0D0,
     1           40.0D0, 0.0D0 /)
      IF (IQ .EQ. 2) PROPS(5) = 0.0D0
      PROPS(7) = IB
      RETURN
      END
!
