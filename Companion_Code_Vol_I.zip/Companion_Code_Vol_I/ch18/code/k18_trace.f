      SUBROUTINE K18_TRACE(TAG, NOEL, NPT, KINC, X, N)
!     Guarded diagnostic: prints X (first six values) for point
!     (1,1) of increments 1-2, and stops cleanly at the first NaN
!     or huge value anywhere.  Unit 7 is the .msg file.
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) TAG
      DIMENSION X(N)
      LOGICAL BAD
      BAD = .FALSE.
      DO I = 1, N
         IF (X(I) .NE. X(I) .OR. ABS(X(I)) .GT. 1.0D30) BAD = .TRUE.
      ENDDO
      IF (BAD .OR. (NOEL .EQ. 1 .AND. NPT .EQ. 1 .AND.
     1    KINC .LE. 2)) THEN
         WRITE(7,'(A,3I7,6ES12.4)') TAG, NOEL, NPT, KINC,
     1      (X(I), I = 1, MIN(N,6))
      ENDIF
      IF (BAD) THEN
         WRITE(7,*) 'K18_TRACE: non-finite value in ', TAG
         CALL XIT
      ENDIF
      RETURN
      END
