import subprocess,json,re,time,os
O='/home/claude/book/ch18/out/'
def run(exe,nml):
    return subprocess.run([O+exe],input=nml+'\n',capture_output=True,text=True,timeout=300).stdout
def parse(out):
    h=[(int(m[0]),int(m[1]),float(m[2])) for m in re.findall(r'H inc\s*(\d+) it\s*(\d+) cut\s*\d+ R\s*(\S+)',out)]
    s=re.search(r'SUM ibug=\s*(\d+)\s+increments=\s*(\d+)\s+cutbacks=\s*(\d+)\s+iterations=\s*(\d+)',out)
    e=re.search(r'END s11=\s*(\S+)\s+eps1=\s*(\S+)\s+eps2=\s*(\S+)',out)
    return dict(hist=h,sum=[int(x) for x in s.groups()] if s else None,end=[float(x) for x in e.groups()] if e else None,aband='ABANDONED' in out,cuts=out.count('CUTBACK'))
R={}
for ninc in (1,4):
    for b in range(5):
        for tol,tag in ((1e-6,'t6'),):
            R[f'{b}_{ninc}_{tag}']=parse(run('col',f'&CIN IBUG={b} NINC={ninc} TOLR=1D-6 HIST=.T. /'))
# tight histories, first increment only
for b in range(4):
    R[f'h{b}']=parse(run('col',f'&CIN IBUG={b} NINC=1 TOLR=1D-14 MAXIT=40 HIST=.T. /'))
# loose Abaqus-like tolerance, IBUG 0 and 4
for b in (0,4):
    R[f'loose{b}']=parse(run('col',f'&CIN IBUG={b} NINC=4 TOLR=5D-3 /'))
# MAXIT=10 with elastic matrix, one increment
R['maxit10']=parse(run('col','&CIN IBUG=2 NINC=1 TOLR=1D-6 MAXIT=10 MAXINC=100000 /'))
R['maxit10c']=parse(run('col','&CIN IBUG=0 NINC=1 TOLR=1D-6 MAXIT=10 MAXINC=100000 /'))
# timing
def timeit(exe):
    t=time.time(); run(exe,'&CIN IBUG=0 NINC=100000 MAXINC=10000000 TOLR=1D-6 /'); return time.time()-t
R['t_plain']=min(timeit('col') for _ in range(3)); R['t_chk']=min(timeit('col_chk') for _ in range(3))
R['fd']=subprocess.run([O+'fd'],capture_output=True,text=True).stdout
fl={}
for n in (1,2,3):
    for exe in ('flt_plain','flt_chk','flt_fpe'):
        p=subprocess.run([O+exe,str(n)],capture_output=True,text=True); fl[f'{exe}{n}']=(p.stdout+p.stderr)[:600]
R['faults']=fl
json.dump(R,open('/home/claude/book/ch18/verify/results.json','w'),indent=1)
for k,v in R.items():
    if isinstance(v,dict) and 'sum' in v: print(k,v['sum'],v['end'],v['aband'],v['cuts'])
print(R['t_plain'],R['t_chk'])
print(R['fd'][:1])
for k in ('h0','h1','h2','h3'): print(k,[ '%.2e'%x[2] for x in R[k]['hist'] if x[0]==1][:40])
print(R['maxit10']['sum'],R['maxit10']['cuts'],R['maxit10c']['sum'])
print(R['faults'])
