"""Independent checks (Python) of the Chapter 18 numbers."""
import numpy as np, json
from scipy.optimize import brentq
E,nu,H,Q,B=210000.,.3,1000.,150.,40.
K=E/(3*(1-2*nu)); G=E/(2*(1+nu))
def sy(ep,sy0): return sy0+H*ep+Q*(1-np.exp(-B*ep))
def hp(ep): return H+Q*B*np.exp(-B*ep)
def sig_of_eps(e,sy0):
    """confined uniaxial strain, monotonic: sigma11 and ep"""
    qtr=2*G*e
    if qtr<=sy0: return K*e+2/3*qtr,0.
    ep=brentq(lambda p: qtr-3*G*p-sy(p,sy0),0,0.1)
    return K*e+2/3*(qtr-3*G*ep),ep
def eps_of_sig(s,sy0):
    return brentq(lambda e: sig_of_eps(e,sy0)[0]-s,0,0.1)
tot=6*0.006
s=brentq(lambda s: eps_of_sig(s,225.)+5*eps_of_sig(s,250.)-tot,100,5000,xtol=1e-12)
e1=eps_of_sig(s,225.);e2=eps_of_sig(s,250.)
print('column: sigma=%.4f eps1=%.6f eps2=%.6f'%(s,e1,e2))
ep2=sig_of_eps(e2,250.)[1]
Dpl=K+4/3*G*hp(ep2)/(3*G+hp(ep2)); Del=K+4/3*G
print('ep2=%.6f Dpl=%.1f Del=%.1f rho_elastic=%.4f'%(ep2,Dpl,Del,1-Dpl/Del))
# stale slope: slope at start of last increment (ep at t=0.75 ~) approximate, and virgin slope
for epo in (0.0,0.75*ep2):
    Dt=K+4/3*G*hp(epo)/(3*G+hp(epo)); print('stale from ep=%.5f: Dtilde=%.1f rho=%.5f'%(epo,Dt,1-Dt/Dpl))
# scaling
for a in (0.4,0.6,0.8,0.45,0.5): print('alpha',a,'factor',abs(1-1/a))
print('iterations for 1e-6 with 0.25:',np.log(1e-6)/np.log(.25))
# loose vs tight error
print('contam err %.3f %%'%((1248.0842-1226.7999)/1226.7999*100))
print('print volume GB',4e4*8*5*100*60/1e9, 4e4*8*5*100)
