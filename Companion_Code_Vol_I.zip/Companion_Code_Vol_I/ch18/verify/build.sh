#!/bin/sh
# builds the ch18 test programs (gfortran 13, stubs from lib/aba)
cd "$(dirname "$0")/../code"
G="gfortran -ffixed-form -std=legacy -I/home/claude/book/lib/aba"
mkdir -p ../out
for f in k18_j2 k18_faults k18_fd k18_fdjac k18_col k18_trace; do $G -Wall -c $f.f -o ../out/$f.o 2>&1 | grep -E "Error" ; done
$G -O2 k18_col.f k18_j2.f /home/claude/book/lib/aba/stubs.f -o ../out/col
$G -O2 k18_fd.f k18_fdjac.f k18_j2.f /home/claude/book/lib/aba/stubs.f -o ../out/fd
$G -O2 -g -fcheck=all -fbacktrace k18_col.f k18_j2.f /home/claude/book/lib/aba/stubs.f -o ../out/col_chk
$G -g -fcheck=all -fbacktrace k18_faults.f -o ../out/flt_chk
$G -g -ffpe-trap=invalid,zero,overflow -finit-real=snan -fbacktrace k18_faults.f -o ../out/flt_fpe
$G -g k18_faults.f -o ../out/flt_plain
echo built
