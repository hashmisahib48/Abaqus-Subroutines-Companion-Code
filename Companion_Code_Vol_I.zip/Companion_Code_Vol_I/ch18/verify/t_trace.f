      PROGRAM TTRACE
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(6)
      X = (/ 1.0D0, 2.0D0, 3.0D0, 4.0D0, 5.0D0, 6.0D0 /)
      CALL K18_TRACE('STRESS', 1, 1, 1, X, 6)
      CALL K18_TRACE('STRESS', 7, 2, 1, X, 6)
      X(3) = 0.0D0
      X(3) = X(3)/X(3)
      CALL K18_TRACE('DDSDDE', 7, 2, 5, X, 6)
      END
