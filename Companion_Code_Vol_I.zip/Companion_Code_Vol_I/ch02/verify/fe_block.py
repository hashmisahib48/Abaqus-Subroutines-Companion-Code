"""Independent finite element check of Example 2.6-1: one 8-node brick (full 2x2x2 integration),
20 x 10 x 10 mm, E = 210000 MPa, nu = 0.3, pressure 2.5 MPa on the top face (into the body)."""
import numpy as np, itertools
E,nu=210000.0,0.3; XL,YL,ZL=20.,10.,10.; P=2.5
X=np.array([[0,0,0],[XL,0,0],[XL,YL,0],[0,YL,0],[0,0,ZL],[XL,0,ZL],[XL,YL,ZL],[0,YL,ZL]],float)
sg=np.array([[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1],[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]],float)
lam=E*nu/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu))
Dm=np.zeros((6,6)); Dm[:3,:3]=lam; 
for k in range(3): Dm[k,k]=lam+2*mu
for k in range(3,6): Dm[k,k]=mu       # engineering shear; order 11 22 33 12 23 13
def Kel():
    K=np.zeros((24,24)); g=1/np.sqrt(3)
    for xi,et,ze in itertools.product([-g,g],repeat=3):
        dN=0.125*np.array([[s[0]*(1+s[1]*et)*(1+s[2]*ze),s[1]*(1+s[0]*xi)*(1+s[2]*ze),s[2]*(1+s[0]*xi)*(1+s[1]*et)] for s in sg])
        J=X.T@dN; dNx=dN@np.linalg.inv(J)
        B=np.zeros((6,24))
        for a in range(8):
            bx,by,bz=dNx[a]; c=3*a
            B[0,c]=bx;B[1,c+1]=by;B[2,c+2]=bz;B[3,c]=by;B[3,c+1]=bx;B[4,c+1]=bz;B[4,c+2]=by;B[5,c]=bz;B[5,c+2]=bx
        K+=B.T@Dm@B*np.linalg.det(J)
    return K
K=Kel()
# consistent nodal forces of the pressure on the top face (nodes 5..8), pressure acts into the body (-z)
f=np.zeros(24); g=1/np.sqrt(3)
for xi,et in itertools.product([-g,g],repeat=2):
    N=0.25*np.array([(1+s[0]*xi)*(1+s[1]*et) for s in sg[4:]])
    detJ=XL*YL/4
    for a in range(4): f[3*(4+a)+2]+=-P*N[a]*detJ
fixed=[3*a+2 for a in range(4)]+[0,1,4]            # U3 on bottom; U1,U2 node1; U2 node2
free=[d for d in range(24) if d not in fixed]
u=np.zeros(24); u[free]=np.linalg.solve(K[np.ix_(free,free)],f[free])
RF=K@u-f
print('nodal force per top node (N):',f[[3*a+2 for a in range(4,8)]])
print('sum RF3 bottom = %.4f N'%sum(RF[3*a+2] for a in range(4)))
print('U3 top nodes (mm):',u[[3*a+2 for a in range(4,8)]])
print('U1 nodes 2,3,6,7 (mm):',u[[3,6,15,18]])
print('closed form  U3 = -P h/E = %.6e ;  U1(x=20) = nu P L/E = %.6e'%(-P*ZL/E,nu*P*XL/E))
# stress at centroid
g0=0.0
dN=0.125*np.array([[s[0],s[1],s[2]] for s in sg]); J=X.T@dN; dNx=dN@np.linalg.inv(J)
B=np.zeros((6,24))
for a in range(8):
    bx,by,bz=dNx[a]; c=3*a
    B[0,c]=bx;B[1,c+1]=by;B[2,c+2]=bz;B[3,c]=by;B[3,c+1]=bx;B[4,c+1]=bz;B[4,c+2]=by;B[5,c]=bz;B[5,c+2]=bx
print('centroid stress (MPa):',Dm@B@u)
# rigid-body-mode study (Problem 2B.2)
w=np.linalg.eigvalsh(K); print('element K: zero eigenvalues =',int(np.sum(np.abs(w)<1e-6*w.max())))
def lowest(fx):
    fr=[d for d in range(24) if d not in fx]; ww=np.linalg.eigvalsh(K[np.ix_(fr,fr)]); return ww[:3],int(np.sum(np.abs(ww)<1e-8*ww.max()))
print('minimal BCs  : lowest eig, zero count',lowest(fixed))
print('without U2 at node 2:',lowest([3*a+2 for a in range(4)]+[0,1]))
print('without U1 at node 1:',lowest([3*a+2 for a in range(4)]+[1,4]))
print('only U3 on bottom   :',lowest([3*a+2 for a in range(4)]))
