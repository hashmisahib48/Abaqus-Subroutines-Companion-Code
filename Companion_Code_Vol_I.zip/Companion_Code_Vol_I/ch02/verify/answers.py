E,nu=210000.0,0.3
# 2A.1 block 30 x 12 x 8, p=4 MPa
L,B,H,p=30.,12.,8.,4.0
A=L*B
print('2A.1 area',A,'RF3',p*A,'U3',-p*H/E,'U1 far end',nu*p*L/E,'U2 far',nu*p*B/E,'RF if P2 with 1.0:',1.0*A)
# 2A.3 library vs user=
Tc,Tr,Tb,N=38.,12.,52.,150
a=N*(Tc+Tr); b=Tb+N*Tr
print('2A.3 user=',a,a/3600,'lib',b,b/3600,'breakeven',Tb/Tc,'saving',a-b,(a-b)/3600)
# example 2.6-1
print('ex RF',2.5*200,'U3',-2.5*10/E,'U1',nu*2.5*20/E)
# env file escapes
s='C:\\temp\\new_libs'.replace('\\\\','\\')
print(repr('C:\temp\new_libs'))
try:
    exec("compile_fortran = '/check:bounds'\nusub_lib_dir = 'C:\\temp\\new_libs'\n link_sl = 1\n")
except Exception as e: print(type(e).__name__,e)
exec("compile_fortran = '/check:bounds'\nusub_lib_dir = 'C:\\temp\\new_libs'\n",globals())
print(repr(usub_lib_dir))
try: compile_fortran.append('x')
except Exception as e: print(type(e).__name__,e)
