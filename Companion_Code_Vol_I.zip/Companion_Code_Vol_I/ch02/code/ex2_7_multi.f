      SUBROUTINE UEXTERNALDB(LOP,LRESTART,TIME,DTIME,KSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2)
      CHARACTER*80 JOBNAM
!     Stamp the build into the .msg file at the analysis start
      IF (LOP .EQ. 0) THEN
         CALL GETJOBNAME(JOBNAM, LENJOB)
         WRITE(7,*) 'K2 build 2024-r1, job = ', JOBNAM(1:LENJOB)
      ENDIF
!
      RETURN
      END
!
      SUBROUTINE DLOAD(F,KSTEP,KINC,TIME,NOEL,NPT,LAYER,KSPT,
     1 COORDS,JLTYP,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!     K2_PRESS begins with K: declare its type, or implicit
!     typing makes it INTEGER
      DOUBLE PRECISION K2_PRESS
!
      F = K2_PRESS(TIME(1))
!
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION K2_PRESS(T)
!     Helper with a unique prefix: ramp in MPa, T = step time
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (P0 = 2.5D0)
      K2_PRESS = P0*T
      RETURN
      END
