      PROGRAM DRVFB
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      TIME(1) = 1.0D0
      COORDS(1) = 20.0D0
      CALL DLOAD(F,1,1,TIME,1,1,0,0,COORDS,1,SNAME)
      WRITE(*,*) 'F =', F, '   intended 2.6'
      END
