      SUBROUTINE K2_FILL(X, N)
!     Fills X(1..N) with 1..N; the loop runs one step too far
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(N)
      DO K = 1, N + 1
         X(K) = DBLE(K)
      ENDDO
      RETURN
      END
!
      PROGRAM DRVBND
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 10)
      DIMENSION X(NMAX)
      N = NMAX
      CALL K2_FILL(X, N)
      WRITE(*,*) 'sum =', SUM(X)
      END
