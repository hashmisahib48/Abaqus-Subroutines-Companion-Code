      SUBROUTINE DLOAD(F,KSTEP,KINC,TIME,NOEL,NPT,LAYER,KSPT,
     1 COORDS,JLTYP,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!
!     Constant pressure for the first test run (Example 2.6-1)
!     P0 in MPa (N/mm^2); positive acts into the surface
      PARAMETER (P0 = 2.5D0)
!
      F = P0
!
!     Proof of call: first increment, first load point only.
!     The line goes to the .msg file (Fortran unit 7).
      IF (KINC .EQ. 1 .AND. NPT .EQ. 1) THEN
         WRITE(7,*) 'DLOAD called: NOEL, NPT, JLTYP, F =',
     1      NOEL, NPT, JLTYP, F
      ENDIF
!
      RETURN
      END
