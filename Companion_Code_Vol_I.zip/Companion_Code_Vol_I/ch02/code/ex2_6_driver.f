      PROGRAM DRVDL
!     Calls DLOAD at the 2 x 2 Gauss points of the top face of
!     Example 2.6-1 and integrates the pressure over the face.
!     Lengths in mm, pressure in MPa, force in N.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      PARAMETER (XL = 20.0D0, YL = 10.0D0, ZL = 10.0D0)
      G = 1.0D0/SQRT(3.0D0)
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      SNAME = ' '
      TOTAL = 0.0D0
      NPT = 0
      DO IY = 1, 2
         DO IX = 1, 2
            NPT = NPT + 1
            COORDS(1) = 0.5D0*XL*(1.0D0 + (2*IX-3)*G)
            COORDS(2) = 0.5D0*YL*(1.0D0 + (2*IY-3)*G)
            COORDS(3) = ZL
            CALL DLOAD(F,1,1,TIME,1,NPT,0,0,COORDS,2,SNAME)
!           Gauss weights are 1; face Jacobian is XL*YL/4
            TOTAL = TOTAL + F*XL*YL/4.0D0
         ENDDO
      ENDDO
      WRITE(*,'(A,F9.4,A)') ' Total on top face = ', TOTAL,
     1   ' N'
      END
