      SUBROUTINE GETVRM(VAR,ARRAY,JARRAY,FLGRAY,JRCD,JMAC,JMATYP,
     1 MATLAYO,LACCFLA)
!     TEST STUB (not Abaqus): returns the stress set by the driver in
!     COMMON /K7STUB/ in the documented order 11,22,33,12,13,23.
!     Mimics the documented return code: JRCD = 1 if all components zero.
      IMPLICIT REAL*8 (A-H,O-Z)
      CHARACTER*(*) VAR
      CHARACTER*3 FLGRAY(15)
      DIMENSION ARRAY(15), JARRAY(15)
      COMMON /K7STUB/ SSTUB(6), NSTUB
      JRCD = 0
      DO 10 K = 1, 15
         ARRAY(K) = 0.0D0
         JARRAY(K) = 0
         FLGRAY(K) = 'N/A'
   10 CONTINUE
      DO 20 K = 1, 6
         ARRAY(K) = SSTUB(K)
         FLGRAY(K) = 'YES'
   20 CONTINUE
      IF (NSTUB .EQ. 4) FLGRAY(5) = 'N/A'
      IF (NSTUB .EQ. 4) FLGRAY(6) = 'N/A'
      IF (ALL(SSTUB .EQ. 0.0D0)) JRCD = 1
      RETURN
      END
