      PROGRAM DRVSD
!     Driver for SDVINI (ex7_4_sdvini.f) and the hash K7_UNI.
      IMPLICIT REAL*8 (A-H,O-Z)
      REAL*8 K7_UNI
      PARAMETER (NEL = 100000, NPTS = 8)
      DIMENSION STATEV(1), COORDS(3), X(NEL,NPTS), X2(NEL,NPTS)
      DIMENSION UBIN(20)
      PARAMETER (XM = 10.0D0, P10 = 0.9D0)
      NSTATV = 1
!     forward order
      DO 10 NOEL = 1, NEL
         DO 5 NPT = 1, NPTS
            CALL SDVINI(STATEV,COORDS,NSTATV,3,NOEL,NPT,1,1)
            X(NOEL,NPT) = STATEV(1)
    5    CONTINUE
   10 CONTINUE
!     reverse order, must be identical
      DO 20 NOEL = NEL, 1, -1
         DO 15 NPT = NPTS, 1, -1
            CALL SDVINI(STATEV,COORDS,NSTATV,3,NOEL,NPT,1,1)
            X2(NOEL,NPT) = STATEV(1)
   15    CONTINUE
   20 CONTINUE
      DIFF = MAXVAL(ABS(X - X2))
      N = NEL*NPTS
      XMEAN = SUM(X)/N
      XVAR = SUM((X - XMEAN)**2)/(N - 1)
!     theoretical values
      TM = GAMMA(1.0D0 + 1.0D0/XM)
      TV = GAMMA(1.0D0 + 2.0D0/XM) - TM**2
!     fraction below the theoretical 10 % quantile
      Q10 = (-LOG(0.9D0))**(1.0D0/XM)
      F10 = COUNT(X .LT. Q10)/DBLE(N)
!     lag-1 correlation between consecutive elements (same point)
      C1 = 0.0D0
      DO 30 NPT = 1, NPTS
         DO 25 NOEL = 1, NEL - 1
            C1 = C1 + (X(NOEL,NPT)-XMEAN)*(X(NOEL+1,NPT)-XMEAN)
   25    CONTINUE
   30 CONTINUE
      C1 = C1/(NPTS*(NEL-1))/XVAR
!     correlation between point 1 and point 2 of the same element
      C2 = SUM((X(:,1)-XMEAN)*(X(:,2)-XMEAN))/NEL/XVAR
      WRITE(*,'(A,I8)')    'samples          ', N
      WRITE(*,'(A,E12.4)') 'max |fwd - rev|  ', DIFF
      WRITE(*,'(A,2F10.5)') 'mean sample/theory', XMEAN, TM
      WRITE(*,'(A,2F10.5)') 'var  sample/theory', XVAR, TV
      WRITE(*,'(A,2F10.5)') 'P(x<q10) / 0.10   ', F10, 0.1D0
      WRITE(*,'(A,2F10.5)') 'corr lag1 elem, pt1-pt2', C1, C2
      WRITE(*,'(A,3F12.8)') 'sample values (1,1),(1,2),(2,1)',
     1 X(1,1), X(1,2), X(2,1)
!     dump for the python cross-check and figure
      OPEN(30, FILE='hash_dump.txt', STATUS='UNKNOWN')
      DO 40 NOEL = 1, 2000
         WRITE(30,'(I6,8F14.10)') NOEL, (X(NOEL,NPT), NPT=1,8)
   40 CONTINUE
      OPEN(31, FILE='hash_u.txt', STATUS='UNKNOWN')
      DO 50 NOEL = 1, 20000
         WRITE(31,'(F14.10)') K7_UNI(NOEL, 1, 1001)
   50 CONTINUE
      END
