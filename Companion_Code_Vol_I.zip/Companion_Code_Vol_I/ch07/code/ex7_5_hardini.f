      SUBROUTINE HARDINI(ALPHA,EQPS,COORDS,NTENS,NCRDS,NOEL,NPT,
     1 LAYER,KSPT,LREBAR,REBARN)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION ALPHA(NTENS,*), COORDS(NCRDS)
      CHARACTER*80 REBARN
!
!     Cold-worked layers, Eq. (7.5-1), plate 0 <= Y <= THICK
      PARAMETER (EPSS = 0.10D0)   ! surface equivalent plastic strain
      PARAMETER (DELTA = 0.5D0)   ! decay depth, mm
      PARAMETER (THICK = 4.0D0)   ! plate thickness, mm
      PARAMETER (NBACK = 0)       ! backstresses in the material
!
      D = MAX(0.0D0, MIN(COORDS(2), THICK - COORDS(2)))  ! depth, mm
      EQPS = EPSS*EXP(-D/DELTA)
      DO 20 IB = 1, NBACK
         DO 10 K = 1, NTENS
            ALPHA(K,IB) = 0.0D0
   10    CONTINUE
   20 CONTINUE
      RETURN
      END
