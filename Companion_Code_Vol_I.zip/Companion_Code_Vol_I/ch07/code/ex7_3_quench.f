      SUBROUTINE SIGINI(SIGMA,COORDS,NTENS,NCRDS,NOEL,NPT,LAYER,
     1 KSPT,LREBAR,NAMES)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION SIGMA(NTENS), COORDS(NCRDS)
      CHARACTER NAMES(2)*80
!
!     Parabolic quench stress, Eq. (7.3-3): plate of thickness 2*HALF,
!     mid-plane at Y = 0, stress component 1 along the plate.
      PARAMETER (SIGC = 50.0D0)   ! core tension, MPa
      PARAMETER (HALF = 10.0D0)   ! half thickness, mm
!
      DO 10 K = 1, NTENS
         SIGMA(K) = 0.0D0
   10 CONTINUE
      ETA = COORDS(2)/HALF
      SIGMA(1) = SIGC*(1.0D0 - 3.0D0*ETA*ETA)
      RETURN
      END
