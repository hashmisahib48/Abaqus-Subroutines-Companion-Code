      INTEGER*8 FUNCTION K7_MIX(KEY)
!     32-bit xor-shift-multiply mixing; no 64-bit overflow
      INTEGER*8 KEY, X, MASK
      PARAMETER (MASK = 4294967295_8)
      X = IAND(KEY, MASK)
      X = IAND(IEOR(X, ISHFT(X, -16))*73244475_8, MASK)
      X = IAND(IEOR(X, ISHFT(X, -16))*73244475_8, MASK)
      K7_MIX = IEOR(X, ISHFT(X, -16))
      RETURN
      END
!
      REAL*8 FUNCTION K7_UNI(NOEL, NPT, ISALT)
!     Uniform deviate in (0,1) from NOEL, NPT, ISALT only
      INTEGER*8 K7_MIX, H
      H = K7_MIX(INT(NOEL, 8) + 1013904223_8)
      H = K7_MIX(IEOR(H, INT(NPT, 8) + 2654435769_8))
      H = K7_MIX(IEOR(H, INT(ISALT, 8) + 40503_8))
      K7_UNI = (DBLE(H) + 0.5D0)/4294967296.0D0
      RETURN
      END
