      SUBROUTINE K7_INVAR(S, ETA, XI, THETA)
!     Stress triaxiality ETA, Lode parameter XI, Lode angle
!     parameter THETA from S = (11,22,33,12,13,23); Eqs. (7.6-1,2,3)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(6), D(3)
      PARAMETER (PI = 3.14159265358979D0)
      PARAMETER (SMIN = 1.0D-6)   ! von Mises stress below this: MPa
!
      P = (S(1) + S(2) + S(3))/3.0D0
      D(1) = S(1) - P
      D(2) = S(2) - P
      D(3) = S(3) - P
      XJ2 = 0.5D0*(D(1)**2 + D(2)**2 + D(3)**2)
     1    + S(4)**2 + S(5)**2 + S(6)**2
      Q = SQRT(3.0D0*XJ2)                ! von Mises stress
      ETA = 0.0D0
      XI = 0.0D0
      THETA = 0.0D0
      IF (Q .LT. SMIN) RETURN
      XJ3 = D(1)*(D(2)*D(3) - S(6)**2) - S(4)*(S(4)*D(3)
     1    - S(6)*S(5)) + S(5)*(S(4)*S(6) - D(2)*S(5))
      ETA = P/Q
      XI = 13.5D0*XJ3/Q**3
      XI = MAX(-1.0D0, MIN(1.0D0, XI))   ! guard against round-off
      THETA = 1.0D0 - 2.0D0*ACOS(XI)/PI
      RETURN
      END
