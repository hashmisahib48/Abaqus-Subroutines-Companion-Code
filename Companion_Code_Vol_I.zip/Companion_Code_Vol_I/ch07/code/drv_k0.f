      PROGRAM DRVK0
!     Driver for SIGINI of ex7_3_k0.f: profile at chosen depths and the
!     vertical equilibrium of a Q4 column with 2x2 Gauss points.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION SIGMA(4), COORDS(2), DEP(5), SBAR(40)
      CHARACTER*80 NAMES(2)
      DATA DEP /1000.D0, 5000.D0, 10000.D0, 15000.D0, 20000.D0/
      DO 10 K = 1, 5
         COORDS(1) = 500.D0
         COORDS(2) = 20000.D0 - DEP(K)
         CALL SIGINI(SIGMA,COORDS,4,2,1,1,1,1,0,NAMES)
         WRITE(*,'(F9.0,3F11.5,F9.4)') DEP(K), SIGMA(1), SIGMA(2),
     1    SIGMA(3), SIGMA(1)/SIGMA(2)
   10 CONTINUE
!     discrete vertical equilibrium of a column of NE Q4 elements, width
!     W, 2x2 Gauss points: nodal internal force minus gravity load.
      H = 20000.D0
      W = 1000.D0
      GAM = 1.8D-5
      G = 1.D0/SQRT(3.D0)
      DO 40 NE = 5, 40, 35
         DY = H/NE
         RMAX = 0.D0
         DO 30 IE = 1, NE
            SB = 0.D0
            DO 20 IG = 1, 2
               COORDS(2) = (IE-1)*DY + DY/2.D0*(1.D0 + (2*IG-3)*G)
               CALL SIGINI(SIGMA,COORDS,4,2,1,1,1,1,0,NAMES)
               SB = SB + 0.5D0*SIGMA(2)
   20       CONTINUE
            SBAR(IE) = SB
   30    CONTINUE
         DO 35 J = 0, NE
            FI = 0.D0
            FE = -GAM*W*DY
            IF (J .GE. 1) FI = FI + W*SBAR(J)
            IF (J .LE. NE-1) FI = FI - W*SBAR(J+1)
            IF (J .EQ. 0 .OR. J .EQ. NE) FE = 0.5D0*FE
            IF (J .EQ. 0) RBASE = FI - FE
            IF (J .GE. 1) RMAX = MAX(RMAX, ABS(FI - FE))
   35    CONTINUE
         WRITE(*,'(A,I3,A,F10.4,A,E10.2)') 'NE =', NE,
     1    '  base reaction', RBASE, '  max node residual', RMAX
   40 CONTINUE
      WRITE(*,'(A,F10.4)') 'gamma*H*W =', GAM*H*W
      END
