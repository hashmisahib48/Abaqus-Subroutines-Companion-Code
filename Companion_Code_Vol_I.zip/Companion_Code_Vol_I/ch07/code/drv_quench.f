      PROGRAM DRVQ
!     Resultant force and moment of the SIGINI profile as sampled by
!     a mesh of NE Q4 elements through the thickness (2x2 Gauss).
!     Per element the end-face force/moment are 2-point Gauss rules.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION SIGMA(4), COORDS(2), NES(6)
      CHARACTER*80 NAMES(2)
      DATA NES /2, 4, 8, 16, 32, 64/
      HALF = 10.0D0
      G = 1.D0/SQRT(3.D0)
      DO 30 IM = 1, 6
         NE = NES(IM)
         DY = 2.D0*HALF/NE
         F = 0.D0
         XM = 0.D0
         DO 25 IE = 1, NE
            DO 20 IG = 1, 2
               Y = -HALF + (IE - 1)*DY + DY/2.D0*(1.D0 + (2*IG-3)*G)
               COORDS(1) = 0.D0
               COORDS(2) = Y
               CALL SIGINI(SIGMA,COORDS,4,2,1,1,1,1,0,NAMES)
               F = F + SIGMA(1)*DY/2.D0
               XM = XM + SIGMA(1)*Y*DY/2.D0
   20       CONTINUE
   25    CONTINUE
         WRITE(*,'(I4,2E14.5)') NE, F, XM
   30 CONTINUE
      END
