      PROGRAM DRVUV
!     Driver for UVARM (ex7_6_uvarm.f) with the GETVRM test stub.
      IMPLICIT REAL*8 (A-H,O-Z)
      COMMON /K7STUB/ SSTUB(6), NSTUB
      DIMENSION UVAR(4), DIRECT(3,3), T(3,3), TIME(2), JMAC(1),
     1 JMATYP(1), COORD(3), SR(6)
      CHARACTER*80 CMNAME, ORNAME
      CHARACTER*40 LAB(8)
      DIMENSION CASE(6,8)
      DATA LAB /'uniaxial tension 300','simple shear 100',
     1 'uniaxial compression -300','equibiaxial tension 300',
     2 'plane strain (300,0,150)','plane strain (300,150,0)',
     3 'hydrostatic 100','zero stress'/
      DATA CASE /300.D0,5*0.D0, 0.D0,0.D0,0.D0,100.D0,0.D0,0.D0,
     1 -300.D0,5*0.D0, 300.D0,300.D0,4*0.D0,
     2 300.D0,0.D0,150.D0,3*0.D0, 300.D0,150.D0,4*0.D0,
     3 100.D0,100.D0,100.D0,3*0.D0, 6*0.D0/
      NSTUB = 6
      CMNAME = 'STEEL'
      DO 10 IC = 1, 8
         DO 5 K = 1, 6
            SSTUB(K) = CASE(K,IC)
    5    CONTINUE
         UVAR(4) = -1.0D30
         CALL UVARM(UVAR,DIRECT,T,TIME,0.1D0,CMNAME,ORNAME,4,1,1,1,1,
     1    1,1,3,3,COORD,JMAC,JMATYP,1,1)
         WRITE(*,'(A,A,4F11.6)') 'CASE ', LAB(IC), UVAR
   10 CONTINUE
!     rotation invariance and comparison file with numpy
      OPEN(20, FILE='uv_states.txt', STATUS='OLD')
      OPEN(21, FILE='uv_fortran.txt', STATUS='UNKNOWN')
      NN = 0
   20 READ(20,*,END=30) (SR(K), K=1,6)
      DO 25 K = 1, 6
         SSTUB(K) = SR(K)
   25 CONTINUE
      UVAR(4) = -1.0D30
      CALL UVARM(UVAR,DIRECT,T,TIME,0.1D0,CMNAME,ORNAME,4,1,1,1,1,
     1 1,1,3,3,COORD,JMAC,JMATYP,1,1)
      WRITE(21,'(3E24.16)') UVAR(1), UVAR(2), UVAR(3)
      NN = NN + 1
      GO TO 20
   30 CONTINUE
      WRITE(*,*) 'states compared:', NN
!     running maximum, repeated calls (iterations) give the same result
      UVAR(4) = 0.2D0
      DO 40 IT = 1, 3
         SSTUB(1) = 100.D0*IT
         SSTUB(2) = 0.D0
         SSTUB(3) = 0.D0
         SSTUB(4) = 0.D0
         SSTUB(5) = 0.D0
         SSTUB(6) = 0.D0
         CALL UVARM(UVAR,DIRECT,T,TIME,0.1D0,CMNAME,ORNAME,4,1,1,1,1,
     1    1,1,3,3,COORD,JMAC,JMATYP,1,1)
         WRITE(*,'(A,I2,F10.6)') 'repeat call', IT, UVAR(4)
   40 CONTINUE
      END
