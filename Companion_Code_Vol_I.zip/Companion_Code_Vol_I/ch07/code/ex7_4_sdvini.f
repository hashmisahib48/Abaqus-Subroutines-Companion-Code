      SUBROUTINE SDVINI(STATEV,COORDS,NSTATV,NCRDS,NOEL,NPT,
     1 LAYER,KSPT)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION STATEV(NSTATV), COORDS(NCRDS)
      REAL*8 K7_UNI
!
!     SDV1 = local strength factor, Weibull distributed (Eq. 7.4-1)
      PARAMETER (XLAM = 1.0D0)    ! scale parameter, -
      PARAMETER (XM = 10.0D0)     ! Weibull modulus, -
!
      DO 10 K = 1, NSTATV
         STATEV(K) = 0.0D0
   10 CONTINUE
      U = K7_UNI(NOEL, NPT, 1000*LAYER + KSPT)
      STATEV(1) = XLAM*(-LOG(1.0D0 - U))**(1.0D0/XM)
      RETURN
      END
