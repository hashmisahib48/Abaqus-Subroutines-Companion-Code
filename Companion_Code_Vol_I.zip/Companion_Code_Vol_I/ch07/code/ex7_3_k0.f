      SUBROUTINE SIGINI(SIGMA,COORDS,NTENS,NCRDS,NOEL,NPT,LAYER,
     1 KSPT,LREBAR,NAMES)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION SIGMA(NTENS), COORDS(NCRDS)
      CHARACTER NAMES(2)*80
!
!     K0 profile of an over-consolidated dry soil, Y vertical (up).
!     Compression is negative.  Units: N, mm, MPa.
      PARAMETER (GAMMA = 1.8D-5)  ! unit weight, N/mm^3 (18 kN/m^3)
      PARAMETER (YTOP = 20000.0D0) ! ground surface, mm
      PARAMETER (POP = 0.10D0)    ! pre-overburden pressure, MPa
      PARAMETER (SINPHI = 0.5D0)  ! sin(30 deg)
!
      DO 10 K = 1, NTENS
         SIGMA(K) = 0.0D0
   10 CONTINUE
      SV = GAMMA*(YTOP - COORDS(2))      ! vertical effective stress
      IF (SV .LE. 0.0D0) RETURN
      OCR = 1.0D0 + POP/SV
      XK0 = (1.0D0 - SINPHI)*OCR**SINPHI ! Mayne-Kulhawy K0
      XKP = (1.0D0 + SINPHI)/(1.0D0 - SINPHI)  ! passive limit
      XK0 = MIN(XK0, XKP)
      SIGMA(1) = -XK0*SV                 ! sigma_xx
      SIGMA(2) = -SV                     ! sigma_yy (vertical)
      IF (NTENS .GE. 4) SIGMA(3) = -XK0*SV  ! sigma_zz
      RETURN
      END
