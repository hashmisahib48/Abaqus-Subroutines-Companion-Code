import numpy as np
from math import gamma, log
M=0xFFFFFFFF
def mix(x):
    x=x&M; x=((x^(x>>16))*73244475)&M; x=((x^(x>>16))*73244475)&M; return x^(x>>16)
def uni(noel,npt,salt):
    h=mix(noel+1013904223); h=mix(h^(npt+2654435769)); h=mix(h^(salt+40503)); return (h+0.5)/4294967296.0
# vectorised
def mixv(x):
    x=x&M; x=((x^(x>>16))*73244475)&M; x=((x^(x>>16))*73244475)&M; return x^(x>>16)
def univ(noel,npt,salt):
    h=mixv(noel.astype(np.uint64)+np.uint64(1013904223)); h=mixv(h^(npt.astype(np.uint64)+np.uint64(2654435769))); h=mixv(h^(np.uint64(salt)+np.uint64(40503))); return (h.astype(np.float64)+0.5)/4294967296.0
d=np.loadtxt('hash_dump.txt')
xm=10.0
err=0
for k in range(0,2000,97):
    for p in range(8):
        u=uni(int(d[k,0]),p+1,1001); x=(-log(1-u))**(1/xm); err=max(err,abs(x-d[k,p+1]))
print('python vs fortran, max diff (values printed to 1e-10):',err)
# quality: 2e7 samples, chi-square on 1000 bins
N=20_000_000
ne=np.arange(1,N//8+1); 
U=np.concatenate([univ(ne,np.full_like(ne,p),1001) for p in range(1,9)])
h,_=np.histogram(U,bins=1000,range=(0,1)); E=len(U)/1000
chi=((h-E)**2/E).sum(); print('chi2(999 dof)',chi,' (mean 999, sd 44.7)')
print('mean',U.mean(),'var*12',U.var()*12)
u=univ(np.arange(1,2_000_001),np.ones(2_000_000,dtype=np.int64),1001)
print('lag1',np.corrcoef(u[:-1],u[1:])[0,1],'lag2',np.corrcoef(u[:-2],u[2:])[0,1],'lag8',np.corrcoef(u[:-8],u[8:])[0,1])
# 2D uniformity of consecutive pairs 32x32 chi2
H,_,_=np.histogram2d(u[:-1],u[1:],bins=32,range=[[0,1],[0,1]]); E2=H.sum()/1024; print('pair chi2 (1023 dof)',((H-E2)**2/E2).sum())
q10=(-log(0.9))**(1/xm); X=(-np.log(1-U))**(1/xm); print('P(x<q10)',(X<q10).mean(), 'se', (0.09/len(X))**.5)
print('mean',X.mean(),gamma(1+1/xm),'var',X.var(),gamma(1+2/xm)-gamma(1+1/xm)**2)
