"""Independent plane-strain Q4 solution (written for this chapter) of the first-increment
relaxation of the parabolic quench stress, Eq. (7.3-3), in a plate of finite length with free ends.
Quarter model: free end at x=0, symmetry planes x=L/2 and y=0. E=210000 MPa, nu=0.3."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, json, sys
E,nu=210000.,0.3; H=10.; SC=50.
D=E/((1+nu)*(1-2*nu))*np.array([[1-nu,nu,0],[nu,1-nu,0],[0,0,(1-2*nu)/2]])
g=1/np.sqrt(3); GP=[(-g,-g),(g,-g),(g,g),(-g,g)]
def sig0(y): return SC*(1-3*(y/H)**2)
def run(Lhalf,ny=10):
    h=H/ny; nx=int(round(Lhalf/h)); nn=(nx+1)*(ny+1)
    nid=lambda i,j:i*(ny+1)+j
    rows=[];cols=[];vals=[]; f=np.zeros(2*nn); gps=[]
    for i in range(nx):
        for j in range(ny):
            nodes=[nid(i,j),nid(i+1,j),nid(i+1,j+1),nid(i,j+1)]
            xy=np.array([[i*h,j*h],[(i+1)*h,j*h],[(i+1)*h,(j+1)*h],[i*h,(j+1)*h]])
            Ke=np.zeros((8,8)); fe=np.zeros(8)
            for (xi,et) in GP:
                dN=0.25*np.array([[-(1-et),(1-et),(1+et),-(1+et)],[-(1-xi),-(1+xi),(1+xi),(1-xi)]])
                J=dN@xy; dNx=np.linalg.solve(J,dN); w=np.linalg.det(J)
                B=np.zeros((3,8)); B[0,0::2]=dNx[0]; B[1,1::2]=dNx[1]; B[2,0::2]=dNx[1]; B[2,1::2]=dNx[0]
                N=0.25*np.array([(1-xi)*(1-et),(1+xi)*(1-et),(1+xi)*(1+et),(1-xi)*(1+et)])
                ygp=N@xy[:,1]; xgp=N@xy[:,0]
                s0=np.array([sig0(ygp),0,0])
                Ke+=B.T@D@B*w; fe+=B.T@s0*w
                gps.append((i,j,xgp,ygp,B,s0,nodes))
            dofs=np.array([[2*n,2*n+1] for n in nodes]).ravel()
            for a in range(8):
                f[dofs[a]]+=fe[a]
                for b in range(8): rows.append(dofs[a]);cols.append(dofs[b]);vals.append(Ke[a,b])
    K=sp.csr_matrix((vals,(rows,cols)),shape=(2*nn,2*nn))
    fixed=[];
    for j in range(ny+1): fixed.append(2*nid(nx,j))      # ux=0 at x=L/2
    for i in range(nx+1): fixed.append(2*nid(i,0)+1)     # uy=0 at y=0
    free=np.setdiff1d(np.arange(2*nn),fixed)
    u=np.zeros(2*nn); u[free]=spl.spsolve(K[free][:,free].tocsc(),-f[free])
    out=[]
    for (i,j,xgp,ygp,B,s0,nodes) in gps:
        dofs=np.array([[2*n,2*n+1] for n in nodes]).ravel()
        s=s0+D@B@u[dofs]; out.append((xgp,ygp,s[0],s0[0]))
    out=np.array(out); return out,nx,h
res={}
for ratio in [1,2,4,8]:
    Lhalf=ratio*H            # L/2 ; L/(2H)=ratio
    out,nx,h=run(Lhalf)
    xm=out[:,0].max(); sel=np.abs(out[:,0]-xm)<1e-9
    y=out[sel,1]; s=out[sel,2]; s0=out[sel,3]
    o=np.argsort(y); y,s,s0=y[o],s[o],s0[o]
    dev=np.sqrt(np.sum((s-s0)**2)/np.sum(s0**2))
    res[ratio]=dict(y=y.tolist(),s=s.tolist(),s0=s0.tolist(),dev=dev,maxdev=float(np.abs(s-s0).max()),x=float(xm))
    print('L/(2H)=%d  rms dev at mid-length = %.4f  max|dσ| = %.3f MPa  (mesh %dx10)'%(ratio,dev,np.abs(s-s0).max(),nx))
json.dump(res,open('relax.json','w'))
