      SUBROUTINE SIGINI(SIGMA,COORDS,NTENS,NCRDS,NOEL,NPT,LAYER,
     1 KSPT,LREBAR,NAMES)
!     Verification variant: compressive surface layer exp(-d/DELTA),
!     balanced by a uniform tension so that the continuous force is 0.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION SIGMA(NTENS), COORDS(NCRDS)
      CHARACTER NAMES(2)*80
      PARAMETER (SIGS = 300.0D0, HALF = 10.0D0, DELTA = 1.0D0)
      DO 10 K = 1, NTENS
         SIGMA(K) = 0.0D0
   10 CONTINUE
      D = HALF - ABS(COORDS(2))
      XMEAN = DELTA*(1.0D0 - EXP(-HALF/DELTA))/HALF
      SIGMA(1) = -SIGS*(EXP(-D/DELTA) - XMEAN)
      RETURN
      END
