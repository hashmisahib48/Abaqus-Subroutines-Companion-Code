import numpy as np, json
E=210000.;SY=250.;Hh=1000.;Et=E*Hh/(E+Hh);T=4.;EPS=0.10;DEL=0.5
def pe0(y): d=np.minimum(y,T-y); return EPS*np.exp(-d/DEL)
def sig(eps,p0,sy0=SY):
    sy=sy0+Hh*p0; ey=sy/E
    return np.where(eps<=ey,E*eps,sy+Et*(eps-ey))
yc=np.linspace(0,T,200001); yc=(yc[1:]+yc[:-1])/2
ne=8; h=T/ne; g=1/np.sqrt(3)
ygp=np.array([ (k+0.5)*h+s*h/2*g for k in range(ne) for s in(-1,1)])
print('Gauss pt depth/PEEQ0 (first 4):',[ (round(min(y,T-y),4),round(float(pe0(y)),5)) for y in ygp[:4]])
print('PEEQ0 surface, depth 0.5, mid-plane:',pe0(0.),pe0(0.5),pe0(2.0),' sy:',SY+Hh*pe0(0.),SY+Hh*pe0(0.5),SY+Hh*pe0(2.0))
print('first-yield strain pristine',SY/E,' cold-worked (mid-plane)',(SY+Hh*pe0(2.0))/E)
rows=[]
for eps in [0.0010,0.0012,0.0015,0.002,0.003,0.005,0.01]:
    a_p=float(sig(eps,0*yc).mean()); a_c=float(sig(eps,pe0(yc)).mean()); a_m=float(sig(eps,pe0(ygp)).mean())
    rows.append((eps,a_p,a_c,a_m)); print('%.4f  pristine %.2f  cold-worked (exact) %.2f  8-element sampling %.2f'%(eps,a_p,a_c,a_m))
json.dump(rows,open('hardini_rows.json','w'))
# mean PEEQ0 of the whole thickness
print('thickness mean PEEQ0',pe0(yc).mean())
