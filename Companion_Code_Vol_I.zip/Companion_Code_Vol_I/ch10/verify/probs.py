import math, numpy as np
# 10B.1
E,SY,H=200000.,350.,2000.
pcr=0.01; emax=0.02; N=40
es=(SY+H*pcr)/E+pcr; de=emax/N; n=math.ceil(es/de-1e-12)
eps=n*de; ep=(E*eps-SY)/(E+H); sig=SY+H*ep
print('10B.1 eps*=%.6f dEps=%.6f n*=%d eps=%.4f epsp=%.7f sigma=%.3f'%(es,de,n,eps,ep,sig))
eps1=(n-1)*de; print('  prev inc eps=%.4f epsp=%.7f'%(eps1,(E*eps1-SY)/(E+H)))
# 10C.2
E,SY,H=210000.,250.,1000.
for pcr in (0.002,):
    es=(SY+H*pcr)/E+pcr; n=math.ceil(es/0.0005-1e-12); print('10C.2 eps*=%.6f n*=%d'%(es,n))
    for k in (n,8):
        eps=0.0005*k; ep=(E*eps-SY)/(E+H); print('   inc',k,'epsp=%.6f'%ep)
# 10C.1
y=np.array([0,2,4,6,8,10.]); p=np.array([1,.86,.64,.40,.18,0.])
print('trapz',np.trapezoid(p,y))
for ne in (10,7,5):
    xs=np.linspace(0,10,ne+1); g=1/math.sqrt(3); tot=0
    for a,b in zip(xs[:-1],xs[1:]):
        l=b-a; c=(a+b)/2
        for s in(-g,g): tot+=l/2*np.interp(c+s*l/2,y,p)
    print('  elements',ne,'quadrature total %.5f'%tot, 'rel err %.3f%%'%(100*(tot-5.16)/5.16))
# 10A.2
sig=255.2844; print('10A.2',round(sig,2),round(-sig/3,2))
# 10A.3
for N in (6,50,500): print(N,math.ceil(math.log2(N)))
# data volume
w=11+8+9+3; print('words per point',w,'bytes',8*w,'1e6 pts one inc MB',8*w*1e6/1e6,'100 inc GB',8*w*1e6*100/1e9)
