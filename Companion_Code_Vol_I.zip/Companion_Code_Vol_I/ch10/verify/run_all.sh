#!/bin/sh
# compiles every listing of Chapter 10 and runs the drivers (gfortran 13, stubs only; no Abaqus)
cd /home/claude/book/ch10/verify; C=../code; S=/home/claude/book/lib/aba
I="-ffixed-form -std=legacy -I$S -Wl,--allow-multiple-definition"
for f in ex10_3_uextdb ex10_3_lookup ex10_3_dload ex10_4_log ex10_4_put ex10_4_get ex10_7_urdfil ex10_7_uextdb p10b2_bug; do gfortran -c -ffixed-form -std=legacy -I$S $C/$f.f -o /tmp/$f.o || echo FAIL $f; done
gfortran $I $C/driver_table.f $C/ex10_3_uextdb.f $C/ex10_3_lookup.f $C/stubs10.f $S/stubs.f -o /tmp/dtab
for c in 1 2 3 4; do echo "--- case $c"; /tmp/dtab $c; done > table_out.txt 2>&1
gfortran -O2 $I $C/driver_cost.f $C/ex10_3_lookup.f $S/stubs.f -o /tmp/dcost && /tmp/dcost > cost_out.txt
rm -f k10_state.dat; gfortran $I $C/driver_log.f $C/ex10_4_log.f $C/ex10_4_put.f $C/ex10_4_get.f $C/stubs10.f $S/stubs.f -o /tmp/dlog && /tmp/dlog > log_out.txt
gfortran $I $C/driver_stop.f $C/ex10_7_urdfil.f $C/ex10_7_uextdb.f $C/stubs10.f $S/stubs.f -o /tmp/dstop
for e in 0.01 0.004; do echo "--- EPSMAX $e"; /tmp/dstop $e; done > stop_out.txt 2>&1
python3 stop_check.py > stop_check_out.txt; python3 probs.py > probs_out.txt
