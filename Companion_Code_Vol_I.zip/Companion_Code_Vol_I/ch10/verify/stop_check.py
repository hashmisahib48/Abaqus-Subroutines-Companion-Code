"""Closed-form check of Example 10.7-1 and data for the figure (no Abaqus involved)."""
import math, re
E,SY,H,PCR=210000.0,250.0,1000.0,5e-3
def nstop(epsmax,ninc=20):
    epsstar=(SY+H*PCR)/E+PCR
    return epsstar, math.ceil(epsstar/(epsmax/ninc)-1e-12)
def state(eps):
    ep=max(0.0,(E*eps-SY)/(E+H)); sig=E*(eps-ep); return sig,ep
if __name__=='__main__':
    es,n=nstop(0.01); print('eps* = %.7f   n* = %d'%(es,n))
    for k in (12,13):
        eps=0.01*k/20; s,ep=state(eps); print(k,eps,round(s,4),round(ep,6))
    es,n=nstop(0.004); print('eps_max=0.004: n* =',n,'(>20: no stop)')
    # compare with driver output
    txt=open('stop_out.txt').read().split('--- EPSMAX')[1:]
    for blk,epsmax in zip(txt,(0.01,0.004)):
        worst=0
        for ln in blk.splitlines():
            m=re.match(r'\s*(\d+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)\s+(\d)',ln)
            if m:
                k=int(m.group(1)); s,ep=state(epsmax*k/20)
                worst=max(worst,abs(s-float(m.group(3))),abs(ep-float(m.group(4)))*2e5/E*0.0+max(0,abs(ep-float(m.group(4)))-5e-7)*E)
        print('epsmax',epsmax,'max deviation driver vs closed form, beyond print rounding:',round(worst,4))
    # other parameter sets for problems
    for (sy,h,pcr,dt_ep) in [(250.,1000.,0.002,0.0004),]:
        pass
