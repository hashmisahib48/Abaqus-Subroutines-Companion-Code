      SUBROUTINE URDFIL(LSTOP,LOVRWRT,KSTEP,KINC,DTIME,TIME)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION ARRAY(500), TIME(2)
      DATA OLDMAX /0.0/
!     stop when the largest Mises stress no longer increases
      OPEN(UNIT=105, FILE='job.fil', STATUS='OLD')
      DO K1 = 1, 999999
         CALL DBFILE(0, ARRAY, JRCD)
         KEY = ARRAY(2)
         IF (KEY .EQ. 12) THEN
            IF (ARRAY(1) .GT. CURRMAX) CURRMAX = ARRAY(1)
         ENDIF
      ENDDO
      IF (CURRMAX .LE. OLDMAX) LSTOP = 1
      OLDMAX = CURRMAX
      IF (CURRMAX .GT. 400.D0) CALL XIT
      RETURN
      END
