      SUBROUTINE UEXTERNALDB(LOP,LRESTART,TIME,DTIME,KSTEP,KINC)
!     Final report of the quantities that URDFIL left in /K10MON/.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), INTV(1), REALV(2)
      CHARACTER*8 CHARV(1)
      COMMON /K10MON/ PEEQMX, SMISMX
!
      IF (LOP .EQ. 0) THEN
         PEEQMX = 0.D0
         SMISMX = 0.D0
      ELSE IF (LOP .EQ. 3) THEN
         REALV(1) = PEEQMX
         REALV(2) = SMISMX
         CALL STDB_ABQERR(1, 'Last PEEQ max %R, Mises max %R',
     1                    INTV, REALV, CHARV)
      ENDIF
      RETURN
      END
