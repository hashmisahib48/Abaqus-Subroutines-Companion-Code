      SUBROUTINE K10_GET(KSTEP, KINC)
!     Restart: restores the counters from the last record that is not
!     later than (KSTEP, KINC) and discards the records after it.
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*256 OUTDIR
      CHARACTER*8 CHARV(1)
      DIMENSION IREC(4,200), TREC(2,200), REALV(1), INTV(1)
      COMMON /K10LOG/ NATT, NACC, NFRESH
!
      CALL GETOUTDIR(OUTDIR, LENOUT)
      OPEN(UNIT=106, FILE=OUTDIR(1:LENOUT)//'/k10_state.dat',
     1     STATUS='OLD', IOSTAT=IOS)
      NREC = 0
      NKEEP = 0
      IF (IOS .EQ. 0) THEN
         DO K = 1, 200
            READ(106,'(4I8,1P,2E16.8)',IOSTAT=IOS) (IREC(J,K),J=1,4),
     1           (TREC(J,K),J=1,2)
            IF (IOS .NE. 0) EXIT
            NREC = K
            IF (IREC(1,K)*100000 + IREC(2,K) .LE.
     1          KSTEP*100000 + KINC) NKEEP = K
         ENDDO
         CLOSE(106)
      ENDIF
      IF (NKEEP .EQ. 0) THEN
         CALL STDB_ABQERR(-3, 'k10_state.dat: no record for restart',
     1                    INTV, REALV, CHARV)
         RETURN
      ENDIF
      NATT = IREC(3,NKEEP)
      NACC = IREC(4,NKEEP)
      NFRESH = 0
      OPEN(UNIT=106, FILE=OUTDIR(1:LENOUT)//'/k10_state.dat',
     1     STATUS='REPLACE')
      DO K = 1, NKEEP
         WRITE(106,'(4I8,1P,2E16.8)') (IREC(J,K),J=1,4),
     1         (TREC(J,K),J=1,2)
      ENDDO
      CLOSE(106)
      RETURN
      END
