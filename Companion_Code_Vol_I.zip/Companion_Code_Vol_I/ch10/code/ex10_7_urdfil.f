      SUBROUTINE URDFIL(LSTOP,LOVRWRT,KSTEP,KINC,DTIME,TIME)
!     Stops the analysis when the largest PEEQ (record 73) of the
!     increment just written reaches PEEQCR.
!     Needs *EL FILE with PEEQ and SINV.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION ARRAY(513), JRRAY(NPRECD,513), TIME(2)
      EQUIVALENCE (ARRAY(1), JRRAY(1,1))
      PARAMETER (PEEQCR = 5.0D-3)
      COMMON /K10MON/ PEEQMX, SMISMX
!
      LSTOP = 0
      LOVRWRT = 0
      PEEQMX = 0.D0
      SMISMX = 0.D0
      CALL POSFIL(KSTEP, KINC, ARRAY, JRCD)
      IF (JRCD .NE. 0) RETURN
      DO K1 = 1, 999999
         CALL DBFILE(0, ARRAY, JRCD)
         IF (JRCD .NE. 0) EXIT
         KEY = JRRAY(1,2)
         IF (KEY .EQ. 73) THEN
            PEEQMX = MAX(PEEQMX, ARRAY(3))
         ELSE IF (KEY .EQ. 12) THEN
            SMISMX = MAX(SMISMX, ARRAY(3))
         ENDIF
      ENDDO
      IF (PEEQMX .GE. PEEQCR) THEN
         LSTOP = 1
         WRITE(7,'(A,I4,A,I4,A,1P,E10.3)') ' URDFIL: step', KSTEP,
     1      ' increment', KINC, ' PEEQ max', PEEQMX
      ENDIF
      RETURN
      END
