      DOUBLE PRECISION FUNCTION K10_LOOKUP(Y)
!     Piecewise-linear interpolation in the table read by UEXTERNALDB.
!     Bisection: at most CEILING(LOG2(NPTS)) comparisons.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 500)
      COMMON /K10TAB/ YTAB(NMAX), PTAB(NMAX), NPTS
!
      IF (Y .LE. YTAB(1)) THEN
         K10_LOOKUP = PTAB(1)
      ELSE IF (Y .GE. YTAB(NPTS)) THEN
         K10_LOOKUP = PTAB(NPTS)
      ELSE
         KLO = 1
         KHI = NPTS
   10    IF (KHI - KLO .GT. 1) THEN
            KM = (KLO + KHI)/2
            IF (Y .GE. YTAB(KM)) THEN
               KLO = KM
            ELSE
               KHI = KM
            ENDIF
            GOTO 10
         ENDIF
         W = (Y - YTAB(KLO))/(YTAB(KHI) - YTAB(KLO))
         K10_LOOKUP = (1.0D0 - W)*PTAB(KLO) + W*PTAB(KHI)
      ENDIF
      RETURN
      END
