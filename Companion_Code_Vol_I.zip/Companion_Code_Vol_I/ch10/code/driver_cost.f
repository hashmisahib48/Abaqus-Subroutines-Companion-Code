!     Cost of a table look-up: linear search (Listing 5.9) against
!     bisection (K10_LOOKUP), N = 6, 50, 500, 2.0E6 random queries each.
      PROGRAM DRVCST
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 500, NQ = 2000000)
      COMMON /K10TAB/ YTAB(NMAX), PTAB(NMAX), NPTS
      DOUBLE PRECISION K10_LOOKUP, K10_LINEAR
      DIMENSION NSIZE(3), YQ(NQ)
      DATA NSIZE /6, 50, 500/
      DO IS = 1, 3
         NPTS = NSIZE(IS)
         DO K = 1, NPTS
            YTAB(K) = 10.D0*(K-1)**1.5D0/(NPTS-1)**1.5D0
            PTAB(K) = 1.D0 - (YTAB(K)/10.D0)**2
         ENDDO
         SEED = 0.3D0
         DO K = 1, NQ
            SEED = MOD(SEED*997.D0 + 0.137D0, 1.D0)
            YQ(K) = 10.D0*SEED
         ENDDO
         CALL CPU_TIME(T0)
         S1 = 0.D0
         DO K = 1, NQ
            S1 = S1 + K10_LOOKUP(YQ(K))
         ENDDO
         CALL CPU_TIME(T1)
         S2 = 0.D0
         DO K = 1, NQ
            S2 = S2 + K10_LINEAR(YQ(K))
         ENDDO
         CALL CPU_TIME(T2)
         DMAX = 0.D0
         DO K = 1, NQ, 97
            DMAX = MAX(DMAX, ABS(K10_LOOKUP(YQ(K)) - K10_LINEAR(YQ(K))))
         ENDDO
         WRITE(*,'(A,I4,A,F7.1,A,F7.1,A,1P,E9.2,A,E10.3)')
     1      ' N =', NPTS, '   bisection', 1.D9*(T1-T0)/NQ,
     2      ' ns   linear', 1.D9*(T2-T1)/NQ, ' ns   max diff',DMAX,
     3      '  sum', S1-S2
      ENDDO
      END
!
      DOUBLE PRECISION FUNCTION K10_LINEAR(Y)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 500)
      COMMON /K10TAB/ YTAB(NMAX), PTAB(NMAX), NPTS
      IF (Y .LE. YTAB(1)) THEN
         K10_LINEAR = PTAB(1)
      ELSE IF (Y .GE. YTAB(NPTS)) THEN
         K10_LINEAR = PTAB(NPTS)
      ELSE
         DO K = 2, NPTS
            IF (Y .LE. YTAB(K)) THEN
               W = (Y - YTAB(K-1))/(YTAB(K) - YTAB(K-1))
               K10_LINEAR = (1.0D0 - W)*PTAB(K-1) + W*PTAB(K)
               RETURN
            ENDIF
         ENDDO
      ENDIF
      RETURN
      END
