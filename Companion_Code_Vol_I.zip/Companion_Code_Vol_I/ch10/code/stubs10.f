!     TEST REPLACEMENTS used only to exercise the listings of Chapter 10
!     outside Abaqus.  They are NOT the Abaqus routines.
!     (1) STDB_ABQERR substitutes %I, %R and %S as documented (Chapter 4).
!     (2) POSFIL and DBFILE read a MOCK results file held in memory, built
!         by the driver from the record layout in the documentation:
!         word 1 = record length, word 2 = key, words 3... = data.
      SUBROUTINE STDB_ABQERR(LOP,STRING,INTV,REALV,CHARV)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) STRING
      CHARACTER*8 CHARV(*)
      CHARACTER*600 OUT
      CHARACTER*24 TMP
      DIMENSION INTV(*),REALV(*)
      NI = 0
      NR = 0
      NS = 0
      N = 0
      OUT = ' '
      K = 1
      LS = LEN_TRIM(STRING)
      DO WHILE (K .LE. LS)
         IF (STRING(K:K) .EQ. '%' .AND. K .LT. LS) THEN
            IF (STRING(K+1:K+1) .EQ. 'I') THEN
               NI = NI + 1
               WRITE(TMP,'(I0)') INTV(NI)
               OUT(N+1:) = TRIM(TMP)
               N = N + LEN_TRIM(TMP)
               K = K + 2
               CYCLE
            ELSE IF (STRING(K+1:K+1) .EQ. 'R') THEN
               NR = NR + 1
               WRITE(TMP,'(1P,E12.4)') REALV(NR)
               OUT(N+1:) = TRIM(ADJUSTL(TMP))
               N = N + LEN_TRIM(ADJUSTL(TMP))
               K = K + 2
               CYCLE
            ELSE IF (STRING(K+1:K+1) .EQ. 'S') THEN
               NS = NS + 1
               OUT(N+1:) = TRIM(CHARV(NS))
               N = N + LEN_TRIM(CHARV(NS))
               K = K + 2
               CYCLE
            ENDIF
         ENDIF
         N = N + 1
         OUT(N:N) = STRING(K:K)
         K = K + 1
      ENDDO
      WRITE(*,'(A,I3,A,A)') ' STDB_ABQERR(', LOP, ') ', OUT(1:N)
      IF (LOP .EQ. -3) STOP 3
      END
!
!     ---- mock results file: records are stored as 513-word arrays ----
      SUBROUTINE MOCK_RESET
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXREC = 4000)
      COMMON /MOCKF/ BUF(513,MAXREC), NREC, IPOS, NRD
      NREC = 0
      IPOS = 0
      RETURN
      END
!
      SUBROUTINE MOCK_ADD(REC, N)
!     appends a record REC(1:N); N includes the two leading words
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXREC = 4000)
      DIMENSION REC(*)
      COMMON /MOCKF/ BUF(513,MAXREC), NREC, IPOS, NRD
      NREC = NREC + 1
      DO K = 1, 513
         BUF(K,NREC) = 0.D0
      ENDDO
      DO K = 1, N
         BUF(K,NREC) = REC(K)
      ENDDO
      RETURN
      END
!
      SUBROUTINE MOCK_DROP(NKEEP)
!     LOVRWRT = 1: records after the first NKEEP are overwritten
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXREC = 4000)
      COMMON /MOCKF/ BUF(513,MAXREC), NREC, IPOS, NRD
      NREC = NKEEP
      RETURN
      END
!
      SUBROUTINE POSFIL(NSTEP,NINC,ARRAY,JRCD)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXREC = 4000)
      DIMENSION ARRAY(*)
      COMMON /MOCKF/ BUF(513,MAXREC), NREC, IPOS, NRD
      DIMENSION W(513), JW(NPRECD,513)
      EQUIVALENCE (W(1), JW(1,1))
      JRCD = 1
      DO K = 1, NREC
         DO J = 1, 513
            W(J) = BUF(J,K)
         ENDDO
         IF (JW(1,2) .EQ. 2000) THEN
            IF ((NSTEP .EQ. 0 .OR. JW(1,8) .EQ. NSTEP) .AND.
     1          (NINC .EQ. 0 .OR. JW(1,9) .EQ. NINC)) THEN
               DO J = 1, 513
                  ARRAY(J) = BUF(J,K)
               ENDDO
               IPOS = K
               JRCD = 0
               RETURN
            ENDIF
         ENDIF
      ENDDO
      RETURN
      END
!
      SUBROUTINE DBFILE(LOP,ARRAY,JRCD)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXREC = 4000)
      DIMENSION ARRAY(*)
      COMMON /MOCKF/ BUF(513,MAXREC), NREC, IPOS, NRD
      JRCD = 0
      IF (LOP .EQ. 2) THEN
         IPOS = 0
      ELSE
         IPOS = IPOS + 1
         IF (IPOS .GT. NREC) THEN
            JRCD = 1
         ELSE
            DO J = 1, 513
               ARRAY(J) = BUF(J,IPOS)
            ENDDO
         ENDIF
      ENDIF
      RETURN
      END
