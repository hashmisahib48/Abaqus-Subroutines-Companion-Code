      SUBROUTINE UEXTERNALDB(LOP,LRESTART,TIME,DTIME,KSTEP,KINC)
!     Counts attempts (LOP = 1) and accepted increments (LOP = 2) and
!     keeps a restart record in k10_state.dat (written at LOP = 2 when
!     a restart file is written, recovered at LOP = 4).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), INTV(3), REALV(1)
      CHARACTER*8 CHARV(1)
      COMMON /K10LOG/ NATT, NACC, NFRESH
!
      IF (LOP .EQ. 0) THEN
         NATT = 0
         NACC = 0
         NFRESH = 1
      ELSE IF (LOP .EQ. 1) THEN
         NATT = NATT + 1
      ELSE IF (LOP .EQ. 2) THEN
         NACC = NACC + 1
         IF (LRESTART .GE. 1) CALL K10_PUT(KSTEP, KINC, TIME)
      ELSE IF (LOP .EQ. 3) THEN
         INTV(1) = NACC
         INTV(2) = NATT - NACC
         CALL STDB_ABQERR(1, 'Accepted increments %I, cutbacks %I',
     1                    INTV, REALV, CHARV)
      ELSE IF (LOP .EQ. 4) THEN
         CALL K10_GET(KSTEP, KINC)
      ENDIF
      RETURN
      END
