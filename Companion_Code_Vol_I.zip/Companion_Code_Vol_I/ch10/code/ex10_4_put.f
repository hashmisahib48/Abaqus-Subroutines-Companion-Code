      SUBROUTINE K10_PUT(KSTEP, KINC, TIME)
!     Appends one record (step, increment, counters, time); the first
!     record of a fresh run replaces any file left by an earlier job.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2)
      CHARACTER*256 OUTDIR
      COMMON /K10LOG/ NATT, NACC, NFRESH
!
      CALL GETOUTDIR(OUTDIR, LENOUT)
      IF (NFRESH .EQ. 1) THEN
         OPEN(UNIT=106, FILE=OUTDIR(1:LENOUT)//'/k10_state.dat',
     1        STATUS='REPLACE')
         NFRESH = 0
      ELSE
         OPEN(UNIT=106, FILE=OUTDIR(1:LENOUT)//'/k10_state.dat',
     1        STATUS='OLD', POSITION='APPEND')
      ENDIF
      WRITE(106,'(4I8,1P,2E16.8)') KSTEP, KINC, NATT, NACC, TIME
      CLOSE(106)
      RETURN
      END
