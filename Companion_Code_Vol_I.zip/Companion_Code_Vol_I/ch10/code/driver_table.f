!     Driver for Example 10.3-1.  Usage: driver_table CASE
!     CASE 1  valid six-point table      CASE 2  y not increasing
!     CASE 3  point count too large      CASE 4  file missing
      PROGRAM DRVTAB
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), YQ(7)
      CHARACTER*8 ARG
      DOUBLE PRECISION K10_LOOKUP
      DATA YQ /-1.D0, 0.D0, 0.5D0, 5.D0, 9.D0, 10.D0, 10.5D0/
      TIME(1) = 0.D0
      TIME(2) = 0.D0
      CALL GETARG(1, ARG)
      READ(ARG,*) ICASE
      IF (ICASE .NE. 4) THEN
         OPEN(UNIT=20, FILE='./pmap.txt', STATUS='REPLACE')
         IF (ICASE .EQ. 1) THEN
            WRITE(20,*) 6
            WRITE(20,*) 0.D0,  1.00D0
            WRITE(20,*) 2.D0,  0.86D0
            WRITE(20,*) 4.D0,  0.64D0
            WRITE(20,*) 6.D0,  0.40D0
            WRITE(20,*) 8.D0,  0.18D0
            WRITE(20,*) 10.D0, 0.00D0
         ELSE IF (ICASE .EQ. 2) THEN
            WRITE(20,*) 3
            WRITE(20,*) 0.D0, 1.D0
            WRITE(20,*) 5.D0, 0.5D0
            WRITE(20,*) 4.D0, 0.2D0
         ELSE
            WRITE(20,*) 501
         ENDIF
         CLOSE(20)
      ELSE
         OPEN(UNIT=20, FILE='./pmap.txt', STATUS='UNKNOWN')
         CLOSE(20, STATUS='DELETE')
      ENDIF
      CALL UEXTERNALDB(0, 0, TIME, 0.D0, 1, 0)
      DO K = 1, 7
         P = K10_LOOKUP(YQ(K))
         WRITE(*,'(A,F6.2,A,F8.4)') ' y =', YQ(K), '   p =', P
      ENDDO
      END
