!     Driver for Example 10.4-1.  Imitates the DOCUMENTED call sequence
!     of UEXTERNALDB for a job of 8 increments in one step, with
!     cutbacks (failed attempts) before increments 3 and 6, restart
!     records written at the even increments, and a failure after
!     increment 7 followed by a restart from increment 4.
      PROGRAM DRVLOG
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), NCUT(8)
      COMMON /K10LOG/ NATT, NACC, NFRESH
      DATA NCUT /0, 0, 1, 0, 0, 2, 0, 0/
      DTIME = 0.125D0
!     ---- run A: uninterrupted
      WRITE(*,*) 'Run A: uninterrupted, increments 1-8'
      CALL UEXTERNALDB(0, 0, TIME, DTIME, 1, 0)
      CALL INCS(1, 8, NCUT, DTIME)
      CALL UEXTERNALDB(3, 0, TIME, DTIME, 1, 8)
      NA1 = NATT
      NA2 = NACC
!     ---- run B: fails after increment 7
      WRITE(*,*) 'Run B: starts afresh, fails after increment 7'
      CALL UEXTERNALDB(0, 0, TIME, DTIME, 1, 0)
      CALL INCS(1, 7, NCUT, DTIME)
      WRITE(*,'(A,2I4)') '   state at failure (attempts, accepted):',
     1      NATT, NACC
!     ---- run C: restart from increment 4 (fresh process memory)
      NATT = -99
      NACC = -99
      WRITE(*,*) 'Run C: restart from increment 4, LOP = 4'
      CALL UEXTERNALDB(4, 0, TIME, DTIME, 1, 4)
      WRITE(*,'(A,2I4)') '   restored (attempts, accepted):', NATT,NACC
      CALL INCS(5, 8, NCUT, DTIME)
      CALL UEXTERNALDB(3, 0, TIME, DTIME, 1, 8)
      WRITE(*,'(A,2I4,A,2I4)') ' run A final', NA1, NA2,
     1      '   run C final', NATT, NACC
!     ---- run D: restart from increment 8 (last record)
      NATT = -99
      NACC = -99
      CALL UEXTERNALDB(4, 0, TIME, DTIME, 1, 8)
      WRITE(*,'(A,2I4)') ' restart from 8 restores:', NATT, NACC
      END
!
      SUBROUTINE INCS(K1, K2, NCUT, DTIME)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), NCUT(8)
      COMMON /K10LOG/ NATT, NACC, NFRESH
      DO KINC = K1, K2
         TIME(1) = 0.125D0*(KINC - 1)
         TIME(2) = TIME(1)
         DO J = 1, NCUT(KINC)
            CALL UEXTERNALDB(1, 0, TIME, DTIME, 1, KINC)
         ENDDO
         CALL UEXTERNALDB(1, 0, TIME, DTIME, 1, KINC)
         TIME(1) = 0.125D0*KINC
         TIME(2) = TIME(1)
         LREST = 0
         IF (MOD(KINC,2) .EQ. 0) LREST = 1
         CALL UEXTERNALDB(2, LREST, TIME, DTIME, 1, KINC)
      ENDDO
      RETURN
      END
