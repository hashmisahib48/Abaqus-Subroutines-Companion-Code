!     Driver for Example 10.7-1.  A single 8-point element in uniaxial
!     tension (E, SY, H below) is driven by a strain ramp.  After every
!     increment the driver writes the records that *EL FILE (S, SINV,
!     PEEQ) would produce, in the documented layout, into a MOCK file,
!     and calls URDFIL as Abaqus would.  Usage: driver_stop EPSMAX
      PROGRAM DRVSTP
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E = 210000.D0, SY = 250.D0, H = 1000.D0)
      PARAMETER (NINC = 20, NIP = 8)
      DIMENSION TIME(2), REC(513), JREC(NPRECD,513)
      EQUIVALENCE (REC(1), JREC(1,1))
      CHARACTER*16 ARG
      COMMON /K10MON/ PEEQMX, SMISMX
      COMMON /MOCKF/ BUF(513,4000), NREC, IPOS, NRD
      CALL GETARG(1, ARG)
      READ(ARG,*) EPSMAX
      CALL MOCK_RESET
      TIME(1) = 0.D0
      TIME(2) = 0.D0
      CALL UEXTERNALDB(0, 0, TIME, 0.D0, 1, 0)
      SIG = 0.D0
      PEEQ = 0.D0
      DT = 1.D0/NINC
      WRITE(*,'(A)')
     1  '  inc   strain      stress    PEEQ     PEEQ(URDFIL) LSTOP'
      DO KINC = 1, NINC
         EPS = EPSMAX*KINC/NINC
         TIME(1) = KINC*DT
         TIME(2) = TIME(1)
!        --- uniaxial return mapping (stress and plastic strain)
         STR = SIG + E*EPSMAX*DT
         F = ABS(STR) - (SY + H*PEEQ)
         IF (F .GT. 0.D0) THEN
            DP = F/(E + H)
            PEEQ = PEEQ + DP
            SIG = SIGN(ABS(STR) - E*DP, STR)
         ELSE
            SIG = STR
         ENDIF
!        --- record 2000: increment start, 21 attributes
         REC = 0.D0
         JREC(1,1) = 23
         JREC(1,2) = 2000
         REC(3) = TIME(2)
         REC(4) = TIME(1)
         JREC(1,7) = 1
         JREC(1,8) = 1
         JREC(1,9) = KINC
         REC(13) = DT
         CALL MOCK_ADD(REC, 23)
         DO IP = 1, NIP
!           record 1: element 1, integration point IP, NDI 3, NSHR 3
            REC = 0.D0
            JREC(1,1) = 11
            JREC(1,2) = 1
            JREC(1,3) = 1
            JREC(1,4) = IP
            JREC(1,6) = 0
            JREC(1,8) = 3
            JREC(1,9) = 3
            CALL MOCK_ADD(REC, 11)
!           record 11: S11 S22 S33 S12 S13 S23
            REC = 0.D0
            JREC(1,1) = 8
            JREC(1,2) = 11
            REC(3) = SIG
            CALL MOCK_ADD(REC, 8)
!           record 12: Mises, Tresca, pressure, 0, 0, 0, third invariant
            REC = 0.D0
            JREC(1,1) = 9
            JREC(1,2) = 12
            REC(3) = ABS(SIG)
            REC(4) = ABS(SIG)
            REC(5) = -SIG/3.D0
            REC(9) = ABS(SIG)
            CALL MOCK_ADD(REC, 9)
!           record 73: PEEQ
            REC = 0.D0
            JREC(1,1) = 3
            JREC(1,2) = 73
            REC(3) = PEEQ
            CALL MOCK_ADD(REC, 3)
         ENDDO
         REC = 0.D0
         JREC(1,1) = 2
         JREC(1,2) = 2001
         CALL MOCK_ADD(REC, 2)
         LSTOP = 0
         LOVRWRT = 0
         CALL URDFIL(LSTOP, LOVRWRT, 1, KINC, DT, TIME)
         WRITE(*,'(I5,F9.5,F11.4,F11.6,F11.6,I5)') KINC, EPS, SIG,
     1        PEEQ, PEEQMX, LSTOP
         KLAST = KINC
         IF (LSTOP .EQ. 1) EXIT
      ENDDO
      WRITE(*,'(A,I5,A,I6)') ' last increment', KLAST,
     1     '   records in file', NREC
      CALL UEXTERNALDB(3, 0, TIME, DT, 1, KLAST)
      END
