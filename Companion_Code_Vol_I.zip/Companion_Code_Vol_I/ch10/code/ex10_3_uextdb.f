      SUBROUTINE UEXTERNALDB(LOP,LRESTART,TIME,DTIME,KSTEP,KINC)
!     Reads the table y (mm), p (MPa) once: at LOP = 0, and at
!     LOP = 4 in a restart analysis.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), INTV(2), REALV(1)
      CHARACTER*8 CHARV(1)
      CHARACTER*256 OUTDIR
      PARAMETER (NMAX = 500)
      COMMON /K10TAB/ YTAB(NMAX), PTAB(NMAX), NPTS
!
      IF (LOP .EQ. 0 .OR. LOP .EQ. 4) THEN
         CALL GETOUTDIR(OUTDIR, LENOUT)
         OPEN(UNIT=105, FILE=OUTDIR(1:LENOUT)//'/pmap.txt',
     1        STATUS='OLD', IOSTAT=IOS)
         IF (IOS .NE. 0) THEN
            CALL STDB_ABQERR(-3, 'pmap.txt cannot be opened',
     1                       INTV, REALV, CHARV)
            RETURN
         ENDIF
         READ(105,*,IOSTAT=IOS) NPTS
         IF (IOS .NE. 0 .OR. NPTS .LT. 2 .OR. NPTS .GT. NMAX) THEN
            INTV(1) = NPTS
            CALL STDB_ABQERR(-3, 'pmap.txt: invalid point count %I',
     1                       INTV, REALV, CHARV)
            RETURN
         ENDIF
         DO K = 1, NPTS
            READ(105,*,IOSTAT=IOS) YTAB(K), PTAB(K)
            IF (IOS .EQ. 0 .AND. K .GT. 1) THEN
               IF (YTAB(K) .LE. YTAB(K-1)) IOS = 1
            ENDIF
            IF (IOS .NE. 0) THEN
               INTV(1) = K
               CALL STDB_ABQERR(-3, 'pmap.txt: bad data at point %I',
     1                          INTV, REALV, CHARV)
               RETURN
            ENDIF
         ENDDO
         CLOSE(105)
         INTV(1) = NPTS
         CALL STDB_ABQERR(1, 'pmap.txt read: %I points', INTV,
     1                    REALV, CHARV)
      ENDIF
      RETURN
      END
