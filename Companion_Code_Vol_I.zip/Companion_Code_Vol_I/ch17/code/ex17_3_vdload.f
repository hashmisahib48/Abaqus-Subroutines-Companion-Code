      SUBROUTINE VDLOAD(
     1  NBLOCK, NDIM, STEPTIME, TOTALTIME,
     2  AMPLITUDE, CURCOORDS, VELOCITY, DIRCOS, JLTYP, SNAME,
     3  VALUE)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION CURCOORDS(NBLOCK,NDIM), VELOCITY(NBLOCK,NDIM),
     1  DIRCOS(NBLOCK,NDIM,NDIM), VALUE(NBLOCK), XCH(3)
      CHARACTER*80 SNAME
!
!     Friedlander blast pressure on a surface, Eqs. (17.3-1)-(17.3-3)
!     Units N, mm, MPa, s.  Charge at XCH (mm); PS0 (MPa) is the peak
!     overpressure at distance R0 (mm); CWAVE (mm/s); TD (s)
      PARAMETER (PS0 = 0.5D0, R0 = 1000.0D0, EXPN = 1.5D0,
     1           CWAVE = 3.4D5, TD = 2.0D-3, BDEC = 1.5D0)
      PARAMETER (ZERO = 0.0D0, ONE = 1.0D0, RMIN = 1.0D0)
      DATA XCH /0.0D0, -1000.0D0, 0.0D0/
!     normal of a face: 3rd direction cosine vector in 3-D,
!     1st in 2-D (an edge)
      INRM = 1
      IF (NDIM .EQ. 3) INRM = 3
      DO 100 K = 1, NBLOCK
         R2   = ZERO
         DOTN = ZERO
         DO 50 J = 1, NDIM
            D    = CURCOORDS(K,J) - XCH(J)
            R2   = R2 + D*D
            DOTN = DOTN + D*DIRCOS(K,J,INRM)
   50    CONTINUE
         R   = MAX(SQRT(R2), RMIN)
         TAU = TOTALTIME - R/CWAVE
         VALUE(K) = ZERO
         IF (TAU .GT. ZERO .AND. TAU .LT. TD) THEN
            X  = TAU/TD
            PS = PS0*(R0/R)**EXPN
            VALUE(K) = PS*(ONE - X)*EXP(-BDEC*X)*ABS(DOTN)/R
         ENDIF
  100 CONTINUE
      RETURN
      END
