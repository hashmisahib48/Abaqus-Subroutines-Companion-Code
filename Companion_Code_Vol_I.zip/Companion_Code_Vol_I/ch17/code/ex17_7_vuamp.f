      SUBROUTINE VUAMP(
     1  AMPNAME, TIME, AMPVALUEOLD, DT, NPROPS, PROPS, NSVARS, SVARS,
     2  LFLAGSINFO, NSENSOR, SENSORVALUES, SENSORNAMES,
     3  JSENSORLOOKUPTABLE,
     4  AMPVALUENEW,
     5  LFLAGSDEFINE,
     6  AMPDERIVATIVE, AMPSECDERIVATIVE, AMPINCINTEGRAL)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION TIME(NTIME), LFLAGSINFO(NFLAGSINFO),
     1  LFLAGSDEFINE(NFLAGSDEFINE), SENSORVALUES(NSENSOR),
     2  PROPS(NPROPS), SVARS(NSVARS), JSENSORLOOKUPTABLE(*)
      CHARACTER*80 SENSORNAMES(NSENSOR), AMPNAME
!
!     Integral controller: the amplitude follows the error between a
!     target and the sensor UTIP (previous increment's value).
!     PROPS: 1 TARGET (mm), 2 KI (1/(mm s)), 3 AMAX (-), 4 TOL (mm),
!            5 NHOLD (increments within TOL that end the step)
!     SVARS(1): consecutive increments within TOL
      TARGET = PROPS(1)
      KI     = PROPS(2)
      AMAX   = PROPS(3)
      TOL    = PROPS(4)
      NHOLD  = NINT(PROPS(5))
      IF (LFLAGSINFO(iInitialization) .EQ. 1) THEN
         AMPVALUENEW = 0.0D0
         SVARS(1)    = 0.0D0
      ELSE
         UTIP  = VGETSENSORVALUE('UTIP', JSENSORLOOKUPTABLE,
     1                           SENSORVALUES)
         ERR   = TARGET - UTIP
         AMPVALUENEW = MIN(AMAX, MAX(0.0D0, AMPVALUEOLD + KI*ERR*DT))
         IF (ABS(ERR) .LT. TOL) THEN
            SVARS(1) = SVARS(1) + 1.0D0
         ELSE
            SVARS(1) = 0.0D0
         ENDIF
         IF (NINT(SVARS(1)) .GE. NHOLD)
     1      LFLAGSDEFINE(iConcludeStep) = 1
      ENDIF
      RETURN
      END
