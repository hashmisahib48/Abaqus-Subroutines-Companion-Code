!     Driver: VSDVINI, VUFIELD, VUAMP (plant), VEXTERNALDB + VDLOAD
      DOUBLE PRECISION FUNCTION VGETSENSORVALUE(NAME, JTAB, VALS)
      CHARACTER*(*) NAME
      INTEGER JTAB(*)
      DOUBLE PRECISION VALS(*)
      VGETSENSORVALUE = VALS(1)
      END
      PROGRAM DRV
      INCLUDE 'VABA_PARAM.INC'
      CALL T8
      CALL T6
      CALL T7
      CALL T9
      END
      SUBROUTINE T8
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 5)
      DIMENSION JEL(NB), CO(NB,3), CL(NB), SI(NB,2)
      DIMENSION YY(NB)
      DATA YY /0.0D0, -0.1D0, -0.25D0, -0.5D0, -2.0D0/
      CHARACTER*80 CM
      CM = 'J2STEEL'
      DO K = 1, NB
         JEL(K) = K
         CO(K,1) = 1.0D0
         CO(K,2) = YY(K)
         CO(K,3) = 0.0D0
         CL(K) = 1.0D0
      ENDDO
      SI = 9.0D0
      CALL VSDVINI(NB, JEL, 1, 1, 1, 3, 2, CM, CO, CL, SI)
      DO K = 1, NB
         WRITE(*,'(A,F6.2,A,2F9.5)') 'vsdvini y= ', CO(K,2), ' state1,2 ', SI(K,1), SI(K,2)
      ENDDO
      END
      SUBROUTINE T6
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 4)
      DIMENSION F(NB,1,1), JFL(2), JN(NB), TM(4), CO(3,NB), U(8,NB), V(8,NB), A(8,NB)
      DO K = 1, NB
         JN(K) = K
         CO(1,K) = 20.0D0*(K-1)
         CO(2,K) = 0.0D0
         CO(3,K) = 0.0D0
      ENDDO
      TM = 0.0D0
      TM(i_ufld_Total) = 0.1D0
      CALL VUFIELD(F, NB, 1, 1, 1, 1, JFL, JN, TM, CO, U, V, A)
      DO K = 1, NB
         EX = 0.5D0*(1.0D0 - TANH((CO(1,K) - 20.0D0)/5.0D0))
         WRITE(*,'(A,F6.1,A,2F11.7)') 'vufield x= ', CO(1,K), ' f, exact ', F(K,1,1), EX
      ENDDO
      END
      SUBROUTINE T7
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION TM(2), PR(5), SV(1), LFI(3), LFD(5), SVAL(1), JT(1)
      CHARACTER*80 SNM(1), AN
      PARAMETER (XM = 0.01D0, XK = 1000.0D0, FMAX = 500.0D0)
      PARAMETER (ZETA = 0.1D0)
      XC = 2.0D0*ZETA*SQRT(XK*XM)
      PR(1) = 0.30D0
      PR(2) = 80.0D0
      PR(3) = 1.0D0
      PR(4) = 0.003D0
      PR(5) = 400.0D0
      AN = 'CTRL'
      SNM(1) = 'UTIP'
      DT = 1.0D-4
      X = 0.0D0
      XV = 0.0D0
      AOLD = 0.0D0
      SVAL(1) = 0.0D0
      LFI = 0
      LFI(iInitialization) = 1
      LFD = 0
      CALL VUAMP(AN, TM, AOLD, DT, 5, PR, 1, SV, LFI, 1, SVAL, SNM, JT,
     1   ANEW, LFD, D1, D2, D3)
      LFI(iInitialization) = 0
      LFI(iRegularInc) = 1
      AOLD = ANEW
      XMAX = 0.0D0
      OPEN(UNIT=21, FILE='amp.csv')
      TSET = -1.0D0
      DO KS = 1, 50000
         T = KS*DT
         TM(1) = T
         TM(2) = T
         SVAL(1) = X
         LFD = 0
         CALL VUAMP(AN, TM, AOLD, DT, 5, PR, 1, SV, LFI, 1, SVAL, SNM, JT,
     1      ANEW, LFD, D1, D2, D3)
         AOLD = ANEW
!        plant: m x'' + c x' + k x = Fmax*amp (central difference)
         ACC = (FMAX*ANEW - XC*XV - XK*X)/XM
         XV = XV + DT*ACC
         X = X + DT*XV
         IF (X .GT. XMAX) XMAX = X
         IF (MOD(KS,20) .EQ. 0) WRITE(21,'(3ES14.6)') T, ANEW, X
         IF (TSET .LT. 0.0D0 .AND. ABS(X - 0.30D0) .LT. 0.003D0) TSET = T
         IF (LFD(iConcludeStep) .EQ. 1) THEN
            WRITE(*,'(A,F8.4,A,3F10.6)') 'vuamp step concluded at t= ', T,
     1         ' amp, x, xmax ', ANEW, X, XMAX
            CLOSE(21)
            EXIT
         ENDIF
      ENDDO
      WRITE(*,'(A,F8.4,A,F8.4)') 'first entry into the 1 % band at t= ', TSET,
     1   '  expected steady amp ', 0.30D0*XK/FMAX
      END
      SUBROUTINE T9
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 3)
      DIMENSION IA(7), RA(3), CC(NB,3), VEL(NB,3), DC(NB,3,3), VAL(NB)
      CHARACTER*80 SN
      COMMON /K17BL/ BLAST(9), NBL
      OPEN(UNIT=11, FILE='./blast.dat')
      WRITE(11,*) '0.0 -1500.0 0.0  0.8 1500.0 1.0  3.4E5 1.0E-3 2.0'
      CLOSE(11)
      IA = 0
      RA = 0.0D0
      CALL VEXTERNALDB(j_int_StartAnalysis, IA, 7, RA, 3)
      WRITE(*,'(A,9G10.4)') 'blast read: ', BLAST
      IA(i_int_kInc) = 1
      CALL VEXTERNALDB(j_int_EndIncrement, IA, 7, RA, 3)
      CALL VEXTERNALDB(j_int_EndAnalysis, IA, 7, RA, 3)
      CC = 0.0D0
      CC(1,2) = 0.0D0
      CC(2,2) = 500.0D0
      CC(3,2) = 250.0D0
      VEL = 0.0D0
      DC = 0.0D0
      DC(1,2,3) = 1.0D0
      DC(2,2,3) = 1.0D0
      DC(3,2,3) = 1.0D0
      SN = 'W'
      R1 = 1500.0D0
      R2 = 2000.0D0
      T1 = R1/3.4D5
      CALL VDLOAD(NB, 3, T1 + 2.0D-4, T1 + 2.0D-4, 1.0D0, CC, VEL, DC, 0, SN, VAL)
      X = 2.0D-4/1.0D-3
      EX1 = 0.8D0*(1.0D0 - X)*EXP(-2.0D0*X)
      WRITE(*,'(A,2ES14.6)') 'vdload point 1 value, exact ', VAL(1), EX1
      T2 = R2/3.4D5
      CALL VDLOAD(NB, 3, T2 + 2.0D-4, T2 + 2.0D-4, 1.0D0, CC, VEL, DC, 0, SN, VAL)
      EX2 = 0.8D0*(R1/R2)**1.0D0*(1.0D0 - X)*EXP(-2.0D0*X)
      WRITE(*,'(A,2ES14.6)') 'vdload point 2 value, exact ', VAL(2), EX2
      T3 = 1750.0D0/3.4D5
      X = 5.0D-4/1.0D-3
      CALL VDLOAD(NB, 3, T3 + 5.0D-4, T3 + 5.0D-4, 1.0D0, CC, VEL, DC, 0, SN, VAL)
      EX3 = 0.8D0*(1500.0D0/1750.0D0)*(1.0D0 - X)*EXP(-2.0D0*X)
      WRITE(*,'(A,2ES14.6)') 'vdload point 3 value, exact ', VAL(3), EX3
      END
