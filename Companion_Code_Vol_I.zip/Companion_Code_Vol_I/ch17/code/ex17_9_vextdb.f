      SUBROUTINE VEXTERNALDB(LOP, I_ARRAY, NIARRAY, R_ARRAY, NRARRAY)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION I_ARRAY(NIARRAY), R_ARRAY(NRARRAY)
      CHARACTER*256 OUTDIR
      COMMON /K17BL/ BLAST(9), NBL
!
!     BLAST = xc, yc, zc (mm), PS0 (MPa), R0 (mm), EXPN (-),
!             CWAVE (mm/s), TD (s), BDEC (-)
      IF (LOP .EQ. j_int_StartAnalysis) THEN
         CALL GETOUTDIR(OUTDIR, LENOUT)
         OPEN(UNIT=105, FILE=OUTDIR(1:LENOUT)//'/blast.dat',
     1        STATUS='OLD', ERR=900)
         READ(105,*,ERR=900,END=900) (BLAST(J), J = 1, 9)
         CLOSE(105)
         IF (BLAST(4) .LE. 0.0D0 .OR. BLAST(8) .LE. 0.0D0 .OR.
     1       BLAST(7) .LE. 0.0D0) GO TO 910
         NBL = 9
      ELSE IF (LOP .EQ. j_int_EndIncrement) THEN
         IF (I_ARRAY(i_int_kInc) .EQ. 1)
     1      WRITE(6,*) 'blast data in use: ', BLAST(4), BLAST(8)
      ELSE IF (LOP .EQ. j_int_EndAnalysis) THEN
         WRITE(6,*) 'last total time ', R_ARRAY(i_flt_TotalTime)
      ENDIF
      RETURN
  900 WRITE(6,*) 'VEXTERNALDB: cannot read blast.dat'
      CALL XPLB_EXIT
  910 WRITE(6,*) 'VEXTERNALDB: nonpositive blast parameter'
      CALL XPLB_EXIT
      END
