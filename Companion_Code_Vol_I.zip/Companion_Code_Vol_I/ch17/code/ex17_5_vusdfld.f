      SUBROUTINE VUSDFLD(
     1  NBLOCK, NSTATEV, NFIELDV, NPROPS, NDIR, NSHR,
     2  JELEM, KINTPT, KLAYER, KSECPT,
     3  STEPTIME, TOTALTIME, DT, CMNAME,
     4  COORDMP, DIRECT, T, CHARLENGTH,
     5  PROPS, STATEOLD,
     6  STATENEW, FIELD)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION JELEM(NBLOCK), COORDMP(NBLOCK,*), DIRECT(NBLOCK,3,3),
     1  T(NBLOCK,3,3), CHARLENGTH(NBLOCK), PROPS(NPROPS),
     2  STATEOLD(NBLOCK,NSTATEV), STATENEW(NBLOCK,NSTATEV),
     3  FIELD(NBLOCK,NFIELDV)
      CHARACTER*80 CMNAME
!
!     Field 1 = scaled maximum equivalent plastic strain, which the
!     *PLASTIC table turns into softening.  PCR (-) is the strain at
!     which the field reaches 1.  PEEQ is read at the START of the
!     increment, so the update lags by one increment.
      PARAMETER (NRDATA = 6, PCR = 0.2D0, ONE = 1.0D0)
      CHARACTER*3 CDATA(MAXBLK*NRDATA)
      DIMENSION RDATA(MAXBLK*NRDATA), JDATA(MAXBLK*NRDATA)
!
      CALL VGETVRM('PEEQ', RDATA, JDATA, CDATA, JSTAT)
      IF (JSTAT .NE. 0) THEN
         WRITE(6,*) 'VUSDFLD: PEEQ not available in ', CMNAME
         CALL XPLB_EXIT
      ENDIF
      DO 100 K = 1, NBLOCK
         STATENEW(K,1) = MAX(STATEOLD(K,1), RDATA(K))
         FIELD(K,1)    = MIN(STATENEW(K,1)/PCR, ONE)
  100 CONTINUE
      RETURN
      END
