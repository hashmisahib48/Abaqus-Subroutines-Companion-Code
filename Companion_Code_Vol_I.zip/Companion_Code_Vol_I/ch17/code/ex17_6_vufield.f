      SUBROUTINE VUFIELD(FIELD, NBLOCK, NFIELD, KFIELD, NCOMP,
     1  KSTEP, JFLAGS, JNODEID, TIME, COORDS, U, V, A)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION FIELD(NBLOCK,NCOMP,NFIELD), JFLAGS(2),
     1  JNODEID(NBLOCK), TIME(4), COORDS(3,NBLOCK),
     2  U(8,NBLOCK), V(8,NBLOCK), A(8,NBLOCK)
!
!     Field 1 = smoothed front travelling in direction 1:
!     F = 0.5 (1 - tanh((X - XF)/WID)),  XF = X0 + VF*t
!     X0, WID in mm, VF in mm/s, t in s
      PARAMETER (X0 = 0.0D0, VF = 200.0D0, WID = 5.0D0)
      TT = TIME(i_ufld_Total)
      XF = X0 + VF*TT
      DO 100 K = 1, NBLOCK
         F = 0.5D0*(1.0D0 - TANH((COORDS(1,K) - XF)/WID))
         DO 50 IC = 1, NCOMP
            FIELD(K,IC,1) = F
   50    CONTINUE
  100 CONTINUE
      RETURN
      END
