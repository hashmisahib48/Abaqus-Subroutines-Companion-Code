      SUBROUTINE VSDVINI(
     1  NBLOCK, JELEM, NINTPT, NLAYER, NSECTPT,
     2  NDIM, NSTATEV, CMNAME, COORDMP, CHARLENGTH,
     3  STATEINI)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION JELEM(NBLOCK), COORDMP(NBLOCK,NDIM),
     1  CHARLENGTH(NBLOCK), STATEINI(NBLOCK,NSTATEV)
      CHARACTER*80 CMNAME
!
!     Peened layer below the surface Y = 0 (material at Y < 0):
!     initial equivalent plastic strain (state 1)
!     P0 = 0.05 at the surface, linearly to 0 at depth DEP (mm)
      PARAMETER (P0 = 0.05D0, DEP = 0.5D0, ZERO = 0.0D0)
      DO 100 K = 1, NBLOCK
         DEPTH = -COORDMP(K,2)
         DO 50 J = 1, NSTATEV
            STATEINI(K,J) = ZERO
   50    CONTINUE
         IF (DEPTH .LT. DEP)
     1      STATEINI(K,1) = P0*(1.0D0 - MAX(DEPTH,ZERO)/DEP)
  100 CONTINUE
      RETURN
      END
