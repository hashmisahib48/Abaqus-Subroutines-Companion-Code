      SUBROUTINE VDISP(
     1  NBLOCK, NDOF, NCOORD, KSTEP, KINC,
     2  STEPTIME, TOTALTIME, DTNEXT, DT,
     3  CBNAME, JBCTYPE, JDOF, JNODEUID, AMP,
     4  COORDNP, U, V, A, RF, RMASS, ROTARYI,
     5  RVAL)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION JDOF(NDOF), JNODEUID(NBLOCK), AMP(NBLOCK),
     1  COORDNP(NCOORD,NBLOCK), U(NDOF,NBLOCK), V(NDOF,NBLOCK),
     2  A(NDOF,NBLOCK), RF(NDOF,NBLOCK), RMASS(NBLOCK),
     3  ROTARYI(3,3,NBLOCK), RVAL(NDOF,NBLOCK)
      CHARACTER*80 CBNAME
!
!     Shaker, direction 1: a = A0 sin(W t), start velocity V0
!     A0 in mm/s^2, FREQ in Hz, V0 in mm/s, time in s
      PARAMETER (A0 = 1.962D5, FREQ = 50.0D0, V0 = 100.0D0)
      PARAMETER (PI = 3.14159265358979D0, ZERO = 0.0D0)
      W = 2.0D0*PI*FREQ
!     the value that is the same for every node of the block
      IF (STEPTIME .LT. ZERO) THEN
!        initial call (STEPTIME = -DT), with u0 = 0:
!        u0 - V0*DT, V0, V0/DT
         IF (JBCTYPE .EQ. 0) VAL = -V0*DT
         IF (JBCTYPE .EQ. 1) VAL = V0
         IF (JBCTYPE .EQ. 2) VAL = V0/DT
      ELSE IF (JBCTYPE .EQ. 0) THEN
!        displacement at STEPTIME + DTNEXT
         T   = STEPTIME + DTNEXT
         VAL = V0*T + A0*(W*T - SIN(W*T))/W**2
      ELSE IF (JBCTYPE .EQ. 1) THEN
!        mean velocity at STEPTIME + DTNEXT/2
         T   = STEPTIME + 0.5D0*DTNEXT
         VAL = V0 + A0*(1.0D0 - COS(W*T))/W
      ELSE
!        acceleration at STEPTIME
         VAL = A0*SIN(W*STEPTIME)
      ENDIF
      DO 100 K = 1, NBLOCK
         DO 90 J = 1, NDOF
            IF (JDOF(J) .EQ. 1) THEN
               RVAL(J,K) = ZERO
               IF (J .EQ. 1) RVAL(J,K) = VAL
            ENDIF
   90    CONTINUE
  100 CONTINUE
      RETURN
      END
