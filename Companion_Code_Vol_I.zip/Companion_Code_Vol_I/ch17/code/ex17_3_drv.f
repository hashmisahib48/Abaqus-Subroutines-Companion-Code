!     Driver for VDLOAD (Example 17.3-1).  Calls the routine as the
!     explicit solver would: a block of points, a time loop.
      PROGRAM DRV
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 4, ND = 3)
      DIMENSION CC(NB,ND), VEL(NB,ND), DC(NB,ND,ND), VAL(NB)
      DIMENSION CC2(NB,ND), DC2(NB,ND,ND), VAL2(NB)
      DIMENSION RIMP(NB), VMAX(NB), TA(NB), TPK(NB), RIMPEX(NB)
      CHARACTER*80 SNAME
      PARAMETER (PS0 = 0.5D0, R0 = 1000.0D0, EXPN = 1.5D0,
     1           CWAVE = 3.4D5, TD = 2.0D-3, BDEC = 1.5D0)
      PARAMETER (RHOA = 7.85D-8)
      DIMENSION R(NB), COSQ(NB)
      SNAME = 'WALL'
      VEL = 0.0D0
      DC = 0.0D0
!     points 1-3 face the charge on the axis at R = 1000, 1500, 2000 mm
      DO K = 1, 3
         CC(K,1) = 0.0D0
         CC(K,2) = -1000.0D0 + 1000.0D0*(1.0D0 + 0.5D0*(K-1))
         CC(K,3) = 0.0D0
         DC(K,1,1) = 1.0D0
         DC(K,3,2) = 1.0D0
         DC(K,2,3) = 1.0D0
      ENDDO
!     point 4: R = 1000 mm, wall normal inclined 60 degrees to the line of sight
      CC(4,1) = 0.0D0
      CC(4,2) = 0.0D0
      CC(4,3) = 0.0D0
      DC(4,1,3) = SIN(1.0471975511966D0)
      DC(4,2,3) = COS(1.0471975511966D0)
      DC(4,1,1) = 1.0D0
      DC(4,2,2) = 1.0D0
      DC(4,3,3) = 1.0D0
!     (point 4 sits at the origin, so R = 1000 mm from the charge)
      DO K = 1, NB
         R(K) = SQRT((CC(K,1))**2 + (CC(K,2)+1000.0D0)**2 + CC(K,3)**2)
      ENDDO
      COSQ(1) = 1.0D0
      COSQ(2) = 1.0D0
      COSQ(3) = 1.0D0
      COSQ(4) = ABS(DC(4,2,3))
      DT = 1.0D-6
      NSTEP = 20000
      DO K = 1, NB
         RIMP(K) = 0.0D0
         VMAX(K) = 0.0D0
      ENDDO
      PREV = 0.0D0
      DO KS = 0, NSTEP
         TT = KS*DT
         CALL VDLOAD(NB, ND, TT, TT, 1.0D0, CC, VEL, DC, 0, SNAME, VAL)
!        the same block in reverse order must give reversed values
         DO K = 1, NB
            KR = NB + 1 - K
            DO J = 1, ND
               CC2(K,J) = CC(KR,J)
               DO L = 1, ND
                  DC2(K,J,L) = DC(KR,J,L)
               ENDDO
            ENDDO
         ENDDO
         CALL VDLOAD(NB, ND, TT, TT, 1.0D0, CC2, VEL, DC2, 0, SNAME, VAL2)
         DO K = 1, NB
            IF (ABS(VAL2(NB+1-K) - VAL(K)) .GT. 0.0D0) WRITE(*,*) 'ORDER!'
            W = 1.0D0
            IF (KS .EQ. 0 .OR. KS .EQ. NSTEP) W = 0.5D0
            RIMP(K) = RIMP(K) + W*VAL(K)*DT
            IF (VAL(K) .GT. VMAX(K)) THEN
               VMAX(K) = VAL(K)
               TPK(K) = TT
            ENDIF
         ENDDO
      ENDDO
      DO K = 1, NB
         PS = PS0*(R0/R(K))**EXPN
         TA(K) = R(K)/CWAVE
         RIMPEX(K) = PS*COSQ(K)*TD*(1.0D0/BDEC - (1.0D0-EXP(-BDEC))/BDEC**2)
         WRITE(*,'(A,I1,A,6(1X,ES14.6))') 'PT', K, ' R ta Ps imp_num imp_ex vmax',
     1      R(K), TA(K), PS, RIMP(K), RIMPEX(K), VMAX(K)
         WRITE(*,'(A,I1,A,ES14.6,A,ES14.6)') 'PT', K, ' tpk ', TPK(K),
     1      ' vel_num ', RIMP(K)/RHOA
         WRITE(*,'(A,I1,A,ES14.6)') 'PT', K, ' relerr ', (RIMP(K)-RIMPEX(K))/RIMPEX(K)
      ENDDO
!     two-dimensional call: edge normal is the first direction cosine vector
      CALL TWOD
      END
      SUBROUTINE TWOD
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION CC(1,2), VEL(1,2), DC(1,2,2), VAL(1)
      CHARACTER*80 SNAME
      SNAME = 'E'
      VEL = 0.0D0
      CC(1,1) = 0.0D0
      CC(1,2) = 0.0D0
      DC = 0.0D0
      DC(1,1,1) = 0.0D0
      DC(1,2,1) = 1.0D0
      DC(1,1,2) = 1.0D0
      CALL VDLOAD(1, 2, 3.0D-3, 3.0D-3, 1.0D0, CC, VEL, DC, 0, SNAME, VAL)
      WRITE(*,'(A,ES14.6)') '2D value at t=3 ms, R=1000 ', VAL(1)
      END
