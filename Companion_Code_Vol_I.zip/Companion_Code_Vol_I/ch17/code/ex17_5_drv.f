!     Driver for VUSDFLD (Example 17.5-1): uniaxial strain-driven points
!     with perfectly plastic yield sigma_y(f) = SY0*(1 - 0.5 f); the
!     routine VGETVRM is a stub that returns the points' PEEQ.
      MODULE PTS
      PARAMETER (NB = 3)
      DOUBLE PRECISION PEEQ(NB)
      END MODULE
      SUBROUTINE VGETVRM(KEY, RDATA, JDATA, CDATA, JSTAT)
      USE PTS
      CHARACTER*(*) KEY
      DOUBLE PRECISION RDATA(*)
      INTEGER JDATA(*)
      CHARACTER*3 CDATA(*)
      JSTAT = 1
      IF (KEY .EQ. 'PEEQ') THEN
         DO K = 1, NB
            RDATA(K) = PEEQ(K)
         ENDDO
         JSTAT = 0
      ENDIF
      END
      PROGRAM DRV
      USE PTS
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NSV = 1, NFV = 1, NP = 1)
      DIMENSION JEL(NB), CM(NB,3), DIR(NB,3,3), TT(NB,3,3), CL(NB),
     1  PR(NP), SO(NB,NSV), SN(NB,NSV), FLD(NB,NFV), SIG(NB), EPS(NB), RATE(NB)
      CHARACTER*80 CMN
      PARAMETER (E = 210000.0D0, SY0 = 250.0D0, PCR = 0.2D0)
      PARAMETER (EMAX = 0.02D0)
      CMN = 'STEEL'
      RATE(1) = 1.0D0
      RATE(2) = 2.0D0
      RATE(3) = 0.5D0
      DO IR = 1, 5
         NINC = 10*4**(IR-1)
         DEINC = EMAX/NINC
         SO = 0.0D0
         SN = 0.0D0
         PEEQ = 0.0D0
         SIG = 0.0D0
         EPS = 0.0D0
         DO KI = 1, NINC
!           points 1..3 are strained at 1x, 2x, 0.5x of the rate
            CALL VUSDFLD(NB, NSV, NFV, NP, 3, 1, JEL, 1, 1, 1,
     1        0.0D0, 0.0D0, DEINC, CMN, CM, DIR, TT, CL, PR, SO, SN, FLD)
            DO K = 1, NB
               DE = DEINC*RATE(K)
               SY = SY0*(1.0D0 - 0.5D0*FLD(K,1))
               STR = SIG(K) + E*DE
               IF (STR .GT. SY) THEN
                  DP = (STR - SY)/E
                  PEEQ(K) = PEEQ(K) + DP
                  SIG(K) = SY
               ELSE
                  SIG(K) = STR
               ENDIF
               EPS(K) = EPS(K) + DE
            ENDDO
            SO = SN
         ENDDO
!        continuous-softening reference: E (eps - p) = SY0 - SLOPE p
         SLOPE = 0.5D0*SY0/PCR
         DO K = 1, NB
            PEX = (E*EPS(K) - SY0)/(E - SLOPE)
            SEX = SY0 - SLOPE*PEX
            IF (K .EQ. 1) WRITE(*,'(A,I5,A,3ES14.6)') 'ninc ', NINC,
     1         ' sigma_num sigma_ex err ', SIG(K), SEX, SIG(K) - SEX
            IF (IR .EQ. 1) WRITE(*,'(A,I1,A,3ES14.6)') ' pt', K,
     1         ' eps sigma_num sigma_ex', EPS(K), SIG(K), SEX
         ENDDO
      ENDDO
!     irreversibility: unload (negative p increment is not produced), state keeps max
      PEEQ(1) = 0.05D0
      SO(1,1) = 0.0D0
      CALL VUSDFLD(NB, NSV, NFV, NP, 3, 1, JEL, 1, 1, 1,
     1  0.0D0, 0.0D0, 1.0D-3, CMN, CM, DIR, TT, CL, PR, SO, SN, FLD)
      WRITE(*,'(A,2ES12.4)') 'peeq 0.05: state, field ', SN(1,1), FLD(1,1)
      PEEQ(1) = 0.01D0
      SO(1,1) = SN(1,1)
      CALL VUSDFLD(NB, NSV, NFV, NP, 3, 1, JEL, 1, 1, 1,
     1  0.0D0, 0.0D0, 1.0D-3, CMN, CM, DIR, TT, CL, PR, SO, SN, FLD)
      WRITE(*,'(A,2ES12.4)') 'peeq falls to 0.01: state, field ', SN(1,1), FLD(1,1)
      END
