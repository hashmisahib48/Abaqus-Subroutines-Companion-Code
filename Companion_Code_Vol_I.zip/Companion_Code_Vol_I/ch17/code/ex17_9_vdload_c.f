      SUBROUTINE VDLOAD(
     1  NBLOCK, NDIM, STEPTIME, TOTALTIME,
     2  AMPLITUDE, CURCOORDS, VELOCITY, DIRCOS, JLTYP, SNAME,
     3  VALUE)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION CURCOORDS(NBLOCK,NDIM), VELOCITY(NBLOCK,NDIM),
     1  DIRCOS(NBLOCK,NDIM,NDIM), VALUE(NBLOCK)
      CHARACTER*80 SNAME
      COMMON /K17BL/ BLAST(9), NBL
!
!     as Listing 17.1, but the constants come from VEXTERNALDB
      PARAMETER (ZERO = 0.0D0, ONE = 1.0D0, RMIN = 1.0D0)
      PS0 = BLAST(4)
      R0 = BLAST(5)
      EXPN = BLAST(6)
      CWAVE = BLAST(7)
      TD = BLAST(8)
      BDEC = BLAST(9)
      INRM = 1
      IF (NDIM .EQ. 3) INRM = 3
      DO 100 K = 1, NBLOCK
         R2   = ZERO
         DOTN = ZERO
         DO 50 J = 1, NDIM
            D    = CURCOORDS(K,J) - BLAST(J)
            R2   = R2 + D*D
            DOTN = DOTN + D*DIRCOS(K,J,INRM)
   50    CONTINUE
         R   = MAX(SQRT(R2), RMIN)
         TAU = TOTALTIME - R/CWAVE
         VALUE(K) = ZERO
         IF (TAU .GT. ZERO .AND. TAU .LT. TD) THEN
            X  = TAU/TD
            PS = PS0*(R0/R)**EXPN
            VALUE(K) = PS*(ONE - X)*EXP(-BDEC*X)*ABS(DOTN)/R
         ENDIF
  100 CONTINUE
      RETURN
      END
