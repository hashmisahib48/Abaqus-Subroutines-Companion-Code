!     Driver for VDISP (Example 17.4-1)
      PROGRAM DRV
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 2, NDF = 6, NC = 3)
      DIMENSION JDOF(NDF), JN(NB), AMP(NB), CO(NC,NB), U(NDF,NB),
     1  V(NDF,NB), A(NDF,NB), RF(NDF,NB), RM(NB), RI(3,3,NB), RV(NDF,NB)
      CHARACTER*80 CBN
      PARAMETER (A0 = 1.962D5, FREQ = 50.0D0, V0 = 100.0D0)
      PARAMETER (PI = 3.14159265358979D0)
      W = 2.0D0*PI*FREQ
      CBN = 'SHAKER'
      JDOF = 0
      JDOF(1) = 1
      JDOF(3) = 1
      JN(1) = 11
      JN(2) = 12
      DT = 1.0D-5
!     initial call
      DO IT = 0, 2
         CALL VDISP(NB, NDF, NC, 1, 0, -DT, -DT, DT, DT, CBN, IT, JDOF, JN,
     1     AMP, CO, U, V, A, RF, RM, RI, RV)
         WRITE(*,'(A,I1,A,ES13.5)') 'init jBCType ', IT, ' rval(1,1)= ', RV(1,1)
      ENDDO
      WRITE(*,'(A,2ES13.5)') 'rval(3,1), rval(3,2) (dof 3, jDof=1)= ', RV(3,1), RV(3,2)
!     leapfrog march on the acceleration returned, for several dt
      TEND = 0.04D0
      DO IR = 1, 4
         DTM = 4.0D-5/2.0D0**(IR-1)
         NS = NINT(TEND/DTM)
         CALL VDISP(NB, NDF, NC, 1, 0, 0.0D0, 0.0D0, DTM, DTM, CBN, 2, JDOF, JN,
     1     AMP, CO, U, V, A, RF, RM, RI, RV)
         ACC = RV(1,1)
         UU = 0.0D0
         VH = V0 + 0.5D0*DTM*ACC
         DO KS = 0, NS-1
            T = KS*DTM
            CALL VDISP(NB, NDF, NC, 1, KS, T, T, DTM, DTM, CBN, 2, JDOF, JN,
     1        AMP, CO, U, V, A, RF, RM, RI, RV)
            ACC = RV(1,1)
            IF (KS .GT. 0) VH = VH + DTM*ACC
            UU = UU + DTM*VH
         ENDDO
         T = NS*DTM
         CALL VDISP(NB, NDF, NC, 1, NS, T-DTM, T-DTM, DTM, DTM, CBN, 0, JDOF, JN,
     1     AMP, CO, U, V, A, RF, RM, RI, RV)
         UD = RV(1,1)
         UEX = V0*T + A0*(W*T - SIN(W*T))/W**2
         WRITE(*,'(A,ES10.3,A,3ES16.8)') 'dt ', DTM, ' u_march u_disp u_exact', UU, UD, UEX
         WRITE(*,'(A,ES10.3,A,ES12.4)') 'dt ', DTM, ' relerr_march', (UU-UEX)/UEX
      ENDDO
      CALL VDISP(NB, NDF, NC, 1, 0, 0.0D0, 0.0D0, 1.0D-5, 1.0D-5, CBN, 1, JDOF, JN,
     1     AMP, CO, U, V, A, RF, RM, RI, RV)
      WRITE(*,'(A,ES13.5)') 'velocity mode at step time 0, dtNext 1e-5 : ', RV(1,1)
      END
