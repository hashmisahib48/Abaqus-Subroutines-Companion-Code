import subprocess,json,re,os
os.chdir('/home/claude/book/ch17/verify')
INC='-I ../code/inc'; S='../../lib/aba/stubs.f'; C='../code/'
def build(out,*srcs):
    subprocess.run(['gfortran','-ffixed-form','-ffixed-line-length-none','-std=legacy','-I','../code/inc']+[C+s for s in srcs]+[S,'-o',out],check=True)
build('drv3','ex17_3_drv.f','ex17_3_vdload.f'); build('drv4','ex17_4_drv.f','ex17_4_vdisp.f')
build('drv5','ex17_5_drv.f','ex17_5_vusdfld.f')
build('drvc','ex17_comp_drv.f','ex17_6_vufield.f','ex17_8_vsdvini.f','ex17_7_vuamp.f','ex17_9_vextdb.f','ex17_9_vdload_c.f')
o3=subprocess.run(['./drv3'],capture_output=True,text=True).stdout
o4=subprocess.run(['./drv4'],capture_output=True,text=True).stdout
o5=subprocess.run(['./drv5'],capture_output=True,text=True).stdout
oc=subprocess.run(['./drvc'],capture_output=True,text=True).stdout
R={}
f=lambda s:float(s.replace('D','E'))
pts={}
for k in range(1,5):
    m=re.search(r'PT%d R ta Ps imp_num imp_ex vmax\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)'%k,o3)
    v=re.search(r'PT%d tpk\s+(\S+)\s+vel_num\s+(\S+)'%k,o3)
    e=re.search(r'PT%d relerr\s+(\S+)'%k,o3)
    pts[k]=dict(R=f(m[1]),ta=f(m[2]),ps=f(m[3]),imp=f(m[4]),impex=f(m[5]),vmax=f(m[6]),tpk=f(v[1]),vel=f(v[2]),err=f(e[1]))
R['blast']=pts; R['blast2d']=f(re.search(r'R=1000\s+(\S+)',o3)[1])
R['disp_init']=[f(x) for x in re.findall(r'rval\(1,1\)=\s+(\S+)',o4)]
R['march']=[dict(dt=f(a),um=f(b),ud=f(c),ue=f(d),err=f(e)) for a,b,c,d,e in re.findall(r'dt\s+(\S+) u_march u_disp u_exact\s+(\S+)\s+(\S+)\s+(\S+)\ndt\s+\S+ relerr_march\s+(\S+)',o4) and [(a,b,c,d,e) for (a,b,c,d),e in zip(re.findall(r'dt\s+(\S+) u_march u_disp u_exact\s+(\S+)\s+(\S+)\s+(\S+)',o4),re.findall(r'relerr_march\s+(\S+)',o4))]]
R['lag']=[dict(n=int(a),sig=f(b),ex=f(c),err=f(d)) for a,b,c,d in re.findall(r'ninc\s+(\d+) sigma_num sigma_ex err\s+(\S+)\s+(\S+)\s+(\S+)',o5)]
R['lag_pts']=[[f(x) for x in m] for m in re.findall(r'pt\d eps sigma_num sigma_ex\s+(\S+)\s+(\S+)\s+(\S+)',o5)]
R['vsd']=[(f(a),f(b)) for a,b in re.findall(r'vsdvini y=\s+(\S+) state1,2\s+(\S+)',oc)]
m=re.search(r'concluded at t=\s+(\S+) amp, x, xmax\s+(\S+)\s+(\S+)\s+(\S+)',oc)
R['amp']=dict(tc=f(m[1]),amp=f(m[2]),x=f(m[3]),xmax=f(m[4]),tband=f(re.search(r'1 % band at t=\s+(\S+)',oc)[1]))
R['vdc']=[f(x) for x in re.findall(r'vdload point \d value, exact\s+(\S+)',oc)]
R['vuf']=[(f(a),f(b)) for a,b in re.findall(r'vufield x=\s+\S+ f, exact\s+(\S+)\s+(\S+)',oc)]
json.dump(R,open('results.json','w'),indent=1)
print(json.dumps(R,indent=1)[:3000]); open('out3.txt','w').write(o3); open('out4.txt','w').write(o4);open('out5.txt','w').write(o5);open('outc.txt','w').write(oc)
