      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),DDSDDE(NTENS,NTENS),
     1 DDSDDT(NTENS),DRPLDE(NTENS),STRAN(NTENS),DSTRAN(NTENS),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3),
     3 DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),JSTEP(4)
!
!     Orthotropic elasticity from engineering constants, in the
!     order of *ELASTIC, TYPE=ENGINEERING CONSTANTS:
!     PROPS = E1 E2 E3 NU12 NU13 NU23 G12 G13 G23  (MPa, -, MPa)
!
      IF (NPROPS .LT. 9) THEN
         WRITE(7,*) 'UMAT: 9 constants required, found', NPROPS
         CALL XIT
      ENDIF
      CALL K12_ORTHO(DDSDDE, NDI, NSHR, NTENS, PROPS)
      CALL K12_UPD(STRESS, DDSDDE, DSTRAN, SSE, NTENS)
!
      RETURN
      END
!
      SUBROUTINE K12_ORTHO(D,NDI,NSHR,NTENS,PR)
!
!     Stiffness from the compliance, Eq. (12.5-1): NDI = 3 (3D,
!     plane strain, axisymmetric) or NDI = 2 (plane stress).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(NTENS,NTENS), PR(9), S(6,6), SP(3,3), IPS(3)
      DATA IPS /1, 2, 4/
!
      ISING = 0
      S = 0.0D0
      S(1,1) =  1.0D0/PR(1)
      S(2,2) =  1.0D0/PR(2)
      S(3,3) =  1.0D0/PR(3)
      S(1,2) = -PR(4)/PR(1)
      S(1,3) = -PR(5)/PR(1)
      S(2,3) = -PR(6)/PR(2)
      S(2,1) =  S(1,2)
      S(3,1) =  S(1,3)
      S(3,2) =  S(2,3)
      S(4,4) =  1.0D0/PR(7)
      S(5,5) =  1.0D0/PR(8)
      S(6,6) =  1.0D0/PR(9)
!
      IF (NDI .EQ. 3) THEN
         CALL K12_INV(S, 6, ISING)
         DO J = 1, NTENS
            DO I = 1, NTENS
               D(I,J) = S(I,J)
            ENDDO
         ENDDO
      ELSE IF (NDI .EQ. 2) THEN
!        plane stress: invert the (11, 22, 12) block of S
         DO J = 1, 3
            DO I = 1, 3
               SP(I,J) = S(IPS(I),IPS(J))
            ENDDO
         ENDDO
         CALL K12_INV(SP, 3, ISING)
         DO J = 1, 3
            DO I = 1, 3
               D(I,J) = SP(I,J)
            ENDDO
         ENDDO
      ELSE
         D(1,1) = PR(1)
      ENDIF
      IF (ISING .NE. 0) CALL XIT
      RETURN
      END
