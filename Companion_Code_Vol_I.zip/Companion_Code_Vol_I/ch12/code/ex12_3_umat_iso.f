      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),DDSDDE(NTENS,NTENS),
     1 DDSDDT(NTENS),DRPLDE(NTENS),STRAN(NTENS),DSTRAN(NTENS),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3),
     3 DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),JSTEP(4)
!
!     Isotropic linear elasticity for any element class.
!     PROPS(1) = E (MPa),  PROPS(2) = NU (-).  No state variables.
!
      E   = PROPS(1)
      XNU = PROPS(2)
      IF (E .LE. 0.0D0 .OR. XNU .LE. -1.0D0 .OR. XNU .GE. 0.5D0) THEN
         WRITE(7,*) 'UMAT: invalid E or NU', E, XNU
         CALL XIT
      ENDIF
!
      CALL K12_ISO(DDSDDE, NDI, NSHR, NTENS, E, XNU)
      CALL K12_UPD(STRESS, DDSDDE, DSTRAN, SSE, NTENS)
!
      RETURN
      END
!
      SUBROUTINE K12_ISO(D,NDI,NSHR,NTENS,E,XNU)
!
!     Stiffness D(NTENS,NTENS): Eq. (3.3-3), Eqs. (12.3-1, 12.3-2)
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(NTENS,NTENS)
!
      D = 0.0D0
      XMU = E/(2.0D0*(1.0D0 + XNU))
      IF (NDI .EQ. 3) THEN
!        3D, plane strain, axisymmetric
         XLAM = E*XNU/((1.0D0 + XNU)*(1.0D0 - 2.0D0*XNU))
         DO J = 1, 3
            DO I = 1, 3
               D(I,J) = XLAM
            ENDDO
            D(J,J) = XLAM + 2.0D0*XMU
         ENDDO
      ELSE IF (NDI .EQ. 2) THEN
!        plane stress (CPS, shells): sigma33 = 0 condensed out
         Q = E/(1.0D0 - XNU*XNU)
         D(1,1) = Q
         D(2,2) = Q
         D(1,2) = XNU*Q
         D(2,1) = XNU*Q
      ELSE
!        one-dimensional (uniaxial)
         D(1,1) = E
      ENDIF
      DO K = 1, NSHR
         D(NDI+K,NDI+K) = XMU
      ENDDO
      RETURN
      END
