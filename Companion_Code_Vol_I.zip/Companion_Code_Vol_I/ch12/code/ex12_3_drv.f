      PROGRAM EX12DRV
!
!     Strain driver for the isotropic UMAT (Chapter 12).  Calls UMAT
!     (through K12_CALL) with strain increments, as Abaqus would, and
!     compares the results with closed-form values.   E = 210000 MPa,
!     NU = 0.3, units N, mm, MPa.
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(2), STRESS(6), STRAN(6), DSTRAN(6), DD(36)
      INTEGER*8 ISEED
      DIMENSION EPST(6), SIGOLD(6), DP(6), DM(36)
      INTEGER NT(3), ND(3), NS(3)
      DDX(II,JJ) = DD(II + (JJ-1)*NTENS)
      DMX(II,JJ) = DM(II + (JJ-1)*NTENS)
      CHARACTER*16 NAME(3)
      DATA NT /6, 4, 3/, ND /3, 3, 2/, NS /3, 1, 1/
      DATA NAME /'3D (C3D8)', 'PLANE STRAIN', 'PLANE STRESS'/
      PROPS(1) = 210000.0D0
      PROPS(2) = 0.3D0
!
!     ---- T1: stiffness matrix, symmetry, shear entry --------------
      DO K = 1, 3
         NTENS = NT(K)
         CALL ZERO6(STRESS, STRAN, DSTRAN)
         CALL K12_CALL(ND(K),NS(K),NTENS,PROPS,2,STRESS,STRAN,DSTRAN,
     1                 DD,SSE)
         ASYM = 0.0D0
         DO I = 1, NTENS
            DO J = 1, NTENS
               ASYM = MAX(ASYM, ABS(DDX(I,J) - DDX(J,I)))
            ENDDO
         ENDDO
         WRITE(*,'(A,A16,A,I2,A,I2,A,I2)') 'T1 ', NAME(K), ' NTENS',
     1     NTENS, ' NDI', ND(K), ' NSHR', NS(K)
         DO I = 1, NTENS
            WRITE(*,'(A,6F12.2)') 'T1 ROW', (DDX(I,J), J = 1, NTENS)
         ENDDO
         WRITE(*,'(A,1PE10.2)') 'T1 ASYM', ASYM
      ENDDO
!
!     ---- T2: uniaxial stress (3D, plane stress) and uniaxial -------
!     ---- strain in plane (plane strain); eps11 = 1e-3 in 10 steps --
      DO K = 1, 3
         NTENS = NT(K)
         CALL ZERO6(STRESS, STRAN, DSTRAN)
         CALL ZERO6(EPST, SIGOLD, DP)
         SSE = 0.0D0
         DO N = 1, 10
            DSTRAN(1) = 1.0D-4
            NFREE = 0
            IF (K .EQ. 1) NFREE = 2
            IF (K .EQ. 2) NFREE = 1
            IF (K .EQ. 3) NFREE = 1
            DO IT = 1, 3
               CALL TRIAL(ND(K),NS(K),NTENS,PROPS,STRESS,STRAN,DSTRAN,
     1                    DD,SSE,SIGOLD)
!              free components 2 (and 3 in 3D): stress must vanish
               IF (NFREE .EQ. 1) THEN
                  DSTRAN(2) = DSTRAN(2) - SIGOLD(2)/DDX(2,2)
               ELSE
                  DET = DDX(2,2)*DDX(3,3) - DDX(2,3)*DDX(3,2)
                  R2 = SIGOLD(2)
                  R3 = SIGOLD(3)
                  DSTRAN(2) = DSTRAN(2)
     1                      - ( DDX(3,3)*R2 - DDX(2,3)*R3)/DET
                  DSTRAN(3) = DSTRAN(3)
     1                      - (-DDX(3,2)*R2 + DDX(2,2)*R3)/DET
               ENDIF
            ENDDO
!           accept the increment (final call updates STRESS, SSE)
            CALL K12_CALL(ND(K),NS(K),NTENS,PROPS,2,STRESS,STRAN,
     1                    DSTRAN,DD,SSE)
            DO I = 1, NTENS
               STRAN(I) = STRAN(I) + DSTRAN(I)
               DSTRAN(I) = 0.0D0
            ENDDO
         ENDDO
         WRITE(*,'(A,A16)') 'T2 ', NAME(K)
         WRITE(*,'(A,6F12.6)') 'T2 SIG', (STRESS(I), I = 1, NTENS)
         WRITE(*,'(A,6E14.6)') 'T2 EPS', (STRAN(I), I = 1, NTENS)
         W = 0.0D0
         DO I = 1, NTENS
            W = W + 0.5D0*STRESS(I)*STRAN(I)
         ENDDO
         WRITE(*,'(A,2E16.8)') 'T2 SSE  0.5*sig:eps', SSE, W
      ENDDO
!
!     ---- T3: pure shear gamma12 = 1e-3, hydrostatic strain ---------
      DO K = 1, 3
         NTENS = NT(K)
         CALL ZERO6(STRESS, STRAN, DSTRAN)
         DSTRAN(ND(K)+1) = 1.0D-3
         CALL K12_CALL(ND(K),NS(K),NTENS,PROPS,2,STRESS,STRAN,DSTRAN,
     1                 DD,SSE)
         WRITE(*,'(A,A16,6F12.6)') 'T3 SHEAR ', NAME(K),
     1     (STRESS(I), I = 1, NTENS)
      ENDDO
      CALL ZERO6(STRESS, STRAN, DSTRAN)
      DO I = 1, 3
         DSTRAN(I) = 1.0D-3
      ENDDO
      CALL K12_CALL(3,3,6,PROPS,2,STRESS,STRAN,DSTRAN,DD,SSE)
      WRITE(*,'(A,6F12.6)') 'T3 HYDRO 3D ', (STRESS(I), I = 1, 6)
!
!     ---- T4: path independence, 1000 pseudo-random increments, ----
!     ---- and the finite-difference test of DDSDDE ------------------
      CALL ZERO6(STRESS, STRAN, DSTRAN)
      CALL ZERO6(EPST, SIGOLD, DP)
      SSE = 0.0D0
      ISEED = 12345_8
      DO N = 1, 1000
         DO I = 1, 6
            ISEED = MOD(16807_8*ISEED, 2147483647_8)
            DSTRAN(I) = 2.0D-5*(DBLE(ISEED)/2147483647.0D0 - 0.5D0)
         ENDDO
         CALL K12_CALL(3,3,6,PROPS,2,STRESS,STRAN,DSTRAN,DD,SSE)
         DO I = 1, 6
            EPST(I) = EPST(I) + DSTRAN(I)
         ENDDO
      ENDDO
!     the same total strain applied in a single increment
      DO I = 1, 6
         DSTRAN(I) = EPST(I)
      ENDDO
      SSE1 = 0.0D0
      CALL K12_CALL(3,3,6,PROPS,2,SIGOLD,STRAN,DSTRAN,DD,SSE1)
      WRITE(*,'(A,6F12.6)') 'T4 SIG one step ', (SIGOLD(I), I = 1, 6)
      WRITE(*,'(A,6F12.6)') 'T4 SIG 1000 inc ', (STRESS(I), I = 1, 6)
      D1 = 0.0D0
      DO I = 1, 6
         D1 = MAX(D1, ABS(SIGOLD(I) - STRESS(I)))
      ENDDO
      WRITE(*,'(A,1PE10.2)') 'T4 MAXDIFF (MPa)', D1
      WRITE(*,'(A,2E18.10)') 'T4 SSE incremental, one step', SSE, SSE1
      W = 0.0D0
      DO I = 1, 6
         W = W + 0.5D0*SIGOLD(I)*EPST(I)
      ENDDO
      WRITE(*,'(A,2E18.10)') 'T4 0.5*sig:eps', W
!
!     finite-difference Jacobian
      NTENS = 6
      CALL ZERO6(STRESS, STRAN, DSTRAN)
      CALL K12_CALL(3,3,6,PROPS,2,STRESS,STRAN,DSTRAN,DD,SSE)
      FDM = 0.0D0
      H = 1.0D-6
      DO J = 1, 6
         CALL ZERO6(STRESS, STRAN, DSTRAN)
         DSTRAN(J) = H
         SSE = 0.0D0
         CALL K12_CALL(3,3,6,PROPS,2,STRESS,STRAN,DSTRAN,DM,SSE)
         DO I = 1, 6
            FDM = MAX(FDM, ABS(STRESS(I)/H - DDX(I,J)))
         ENDDO
      ENDDO
      WRITE(*,'(A,1PE10.2)') 'T4 FD-JACOBIAN max |FD - DDSDDE| (MPa)',
     1  FDM
      END
!
      SUBROUTINE ZERO6(A, B, C)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(6), B(6), C(6)
      DO I = 1, 6
         A(I) = 0.0D0
         B(I) = 0.0D0
         C(I) = 0.0D0
      ENDDO
      RETURN
      END
!
      SUBROUTINE TRIAL(NDI,NSHR,NTENS,PROPS,STRESS,STRAN,DSTRAN,DD,
     1                 SSE,SIGNEW)
!     trial call on copies: STRESS and SSE of the caller are untouched
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(2), STRESS(6), STRAN(6), DSTRAN(6), DD(36)
      DIMENSION SIGNEW(6)
      DO I = 1, 6
         SIGNEW(I) = STRESS(I)
      ENDDO
      SSET = SSE
      CALL K12_CALL(NDI,NSHR,NTENS,PROPS,2,SIGNEW,STRAN,DSTRAN,DD,SSET)
      RETURN
      END
