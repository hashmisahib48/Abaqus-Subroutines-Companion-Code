      SUBROUTINE K12_UPD(STRESS,DDSDDE,DSTRAN,SSE,NTENS)
!     Incremental update, Eq. (12.2-1); energy, Eq. (12.2-3)
!     STRESS in MPa, SSE in N.mm/mm^3, NTENS <= 6
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(NTENS), DDSDDE(NTENS,NTENS), DSTRAN(NTENS)
      DIMENSION DSIG(6)
!
      DO I = 1, NTENS
         DSIG(I) = 0.0D0
         DO J = 1, NTENS
            DSIG(I) = DSIG(I) + DDSDDE(I,J)*DSTRAN(J)
         ENDDO
      ENDDO
      DO I = 1, NTENS
         SSE = SSE + (STRESS(I) + 0.5D0*DSIG(I))*DSTRAN(I)
         STRESS(I) = STRESS(I) + DSIG(I)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K12_INV(A,N,ISING)
!
!     In-place inverse of the N x N matrix A (N <= 6), Gauss-Jordan
!     elimination with partial pivoting.  ISING = 1 if singular.
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(N,N)
      DIMENSION IPIV(6)
!
      ISING = 0
      DO K = 1, N
         IPIV(K) = K
      ENDDO
      DO K = 1, N
         PMAX = ABS(A(K,K))
         KP   = K
         DO I = K+1, N
            IF (ABS(A(I,K)) .GT. PMAX) THEN
               PMAX = ABS(A(I,K))
               KP   = I
            ENDIF
         ENDDO
         IF (PMAX .LT. 1.0D-300) THEN
            ISING = 1
            RETURN
         ENDIF
         IF (KP .NE. K) THEN
            DO J = 1, N
               T = A(K,J)
               A(K,J) = A(KP,J)
               A(KP,J) = T
            ENDDO
         ENDIF
         PIV = 1.0D0/A(K,K)
         A(K,K) = 1.0D0
         DO J = 1, N
            A(K,J) = A(K,J)*PIV
         ENDDO
         DO I = 1, N
            IF (I .NE. K) THEN
               F = A(I,K)
               A(I,K) = 0.0D0
               DO J = 1, N
                  A(I,J) = A(I,J) - F*A(K,J)
               ENDDO
            ENDIF
         ENDDO
         IPIV(K) = KP
      ENDDO
!     undo the row interchanges as column interchanges, last first
      DO K = N, 1, -1
         KP = IPIV(K)
         IF (KP .NE. K) THEN
            DO I = 1, N
               T = A(I,K)
               A(I,K) = A(I,KP)
               A(I,KP) = T
            ENDDO
         ENDIF
      ENDDO
      RETURN
      END
