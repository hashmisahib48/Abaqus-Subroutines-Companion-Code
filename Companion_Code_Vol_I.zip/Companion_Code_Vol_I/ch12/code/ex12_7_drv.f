      PROGRAM EX12BAD
!
!     Drives the faulty UMAT of Section 12.7 (PROPS(3) = 0 correct,
!     1 shear factor 2, 2 plane-strain block in plane stress, 3 total
!     form with an initial stress).  E = 210000 MPa, NU = 0.3.
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(3), STRESS(6), STRAN(6), DSTRAN(6), DD(36)
      DDX(II,JJ) = DD(II + (JJ-1)*NTENS)
      DO IV = 0, 4
         PROPS(1) = 210000.0D0
         PROPS(2) = 0.3D0
         PROPS(3) = DBLE(IV)
!        (a) pure shear gamma12 = 1e-3, 3D
         DO I = 1, 6
            STRESS(I) = 0.0D0
            STRAN(I) = 0.0D0
            DSTRAN(I) = 0.0D0
         ENDDO
         DSTRAN(4) = 1.0D-3
         CALL K12_CALL(3,3,6,PROPS,3,STRESS,STRAN,DSTRAN,DD,SSE)
         WRITE(*,'(A,I2,A,F12.4)') 'B1 variant', IV, ' sigma12 =',
     1      STRESS(4)
!        (b) plane stress: uniaxial stress modulus  D11 - D12**2/D22
         DO I = 1, 6
            STRESS(I) = 0.0D0
            DSTRAN(I) = 0.0D0
         ENDDO
         NTENS = 3
         CALL K12_CALL(2,1,3,PROPS,3,STRESS,STRAN,DSTRAN,DD,SSE)
         EEFF = DDX(1,1) - DDX(1,2)*DDX(2,1)/DDX(2,2)
         XNEFF = DDX(1,2)/DDX(2,2)
         WRITE(*,'(A,I2,A,F12.2,A,F8.4)') 'B2 variant', IV,
     1      ' E_eff =', EEFF, '  nu_eff =', XNEFF
!        (c) initial stress 50 MPa, then uniaxial stress increment
         DO I = 1, 6
            STRESS(I) = 0.0D0
            STRAN(I) = 0.0D0
            DSTRAN(I) = 0.0D0
         ENDDO
         STRESS(1) = 50.0D0
         STRAN(1)  = 0.0D0
         DSTRAN(1) =  1.0D-3
         DSTRAN(2) = -3.0D-4
         DSTRAN(3) = -3.0D-4
         CALL K12_CALL(3,3,6,PROPS,3,STRESS,STRAN,DSTRAN,DD,SSE)
         WRITE(*,'(A,I2,A,F12.4)') 'B3 variant', IV, ' sigma11 =',
     1      STRESS(1)
      ENDDO
      END
