      PROGRAM EX12ORT
!
!  Strain driver for the orthotropic UMAT (Chapter 12).  Unidirectional
!  glass/epoxy ply: E1 = 45000, E2 = E3 = 12000 MPa, NU12 = NU13 = 0.28,
!     NU23 = 0.42, G12 = G13 = 5500, G23 = 4225 MPa.
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(9), STRESS(6), STRAN(6), DSTRAN(6), DD(36)
      DDX(II,JJ) = DD(II + (JJ-1)*NTENS)
      DATA PROPS /45000.D0,12000.D0,12000.D0,0.28D0,0.28D0,0.42D0,
     1            5500.D0,5500.D0,4225.D0/
!
      NTENS = 6
      CALL Z6(STRESS, STRAN, DSTRAN)
      CALL K12_CALL(3,3,6,PROPS,9,STRESS,STRAN,DSTRAN,DD,SSE)
      WRITE(*,'(A)') 'O1 3D stiffness (MPa), order 11 22 33 12 13 23'
      DO I = 1, 6
         WRITE(*,'(A,6F12.2)') 'O1 ROW', (DDX(I,J), J = 1, 6)
      ENDDO
      NTENS = 6
      ASYM = 0.0D0
      DO I = 1, 6
         DO J = 1, 6
            ASYM = MAX(ASYM, ABS(DDX(I,J) - DDX(J,I)))
         ENDDO
      ENDDO
      WRITE(*,'(A,1PE10.2)') 'O1 ASYM', ASYM
!
!     plane stress block
      NTENS = 3
      CALL K12_CALL(2,1,3,PROPS,9,STRESS,STRAN,DSTRAN,DD,SSE)
      WRITE(*,'(A)') 'O2 plane stress stiffness (MPa), order 11 22 12'
      DO I = 1, 3
         WRITE(*,'(A,3F12.2)') 'O2 ROW', (DDX(I,J), J = 1, 3)
      ENDDO
!     plane strain block
      NTENS = 4
      CALL K12_CALL(3,1,4,PROPS,9,STRESS,STRAN,DSTRAN,DD,SSE)
      WRITE(*,'(A)') 'O3 plane strain stiffness, order 11 22 33 12'
      DO I = 1, 4
         WRITE(*,'(A,4F12.2)') 'O3 ROW', (DDX(I,J), J = 1, 4)
      ENDDO
!
!     uniaxial stress sigma11 = 100 MPa and sigma22 = 100 MPa:
!     strains from the stiffness inverse -> applied through the
!     strain that the UMAT must map back to the stress (3D)
      CALL Z6(STRESS, STRAN, DSTRAN)
      E1 = PROPS(1)
      E2 = PROPS(2)
      DSTRAN(1) = 100.0D0/E1
      DSTRAN(2) = -PROPS(4)*100.0D0/E1
      DSTRAN(3) = -PROPS(5)*100.0D0/E1
      CALL K12_CALL(3,3,6,PROPS,9,STRESS,STRAN,DSTRAN,DD,SSE)
      WRITE(*,'(A,6F12.6)') 'O4 strain of uniaxial 100 MPa along 1 ->',
     1     (STRESS(I), I = 1, 6)
      CALL Z6(STRESS, STRAN, DSTRAN)
      DSTRAN(2) = 100.0D0/E2
      DSTRAN(1) = -PROPS(4)*(E2/E1)*100.0D0/E2
      DSTRAN(3) = -PROPS(6)*100.0D0/E2
      CALL K12_CALL(3,3,6,PROPS,9,STRESS,STRAN,DSTRAN,DD,SSE)
      WRITE(*,'(A,6F12.6)') 'O4 strain of uniaxial 100 MPa along 2 ->',
     1     (STRESS(I), I = 1, 6)
      CALL Z6(STRESS, STRAN, DSTRAN)
      DSTRAN(4) = 1.0D-3
      CALL K12_CALL(3,3,6,PROPS,9,STRESS,STRAN,DSTRAN,DD,SSE)
      WRITE(*,'(A,6F12.6)') 'O4 gamma12 = 1e-3 ->', (STRESS(I),I=1,6)
      END
!
      SUBROUTINE Z6(A, B, C)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(6), B(6), C(6)
      DO I = 1, 6
         A(I) = 0.0D0
         B(I) = 0.0D0
         C(I) = 0.0D0
      ENDDO
      RETURN
      END
