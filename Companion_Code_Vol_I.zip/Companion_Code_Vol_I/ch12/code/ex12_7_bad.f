      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),DDSDDE(NTENS,NTENS),
     1 DDSDDT(NTENS),DRPLDE(NTENS),STRAN(NTENS),DSTRAN(NTENS),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3),
     3 DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),JSTEP(4)
!
!     Faulty variants of the isotropic routine, selected by
!     PROPS(3) = 1, 2, 3 or 4 (Section 12.7); 0 is the correct one.
!
      E    = PROPS(1)
      XNU  = PROPS(2)
      IVAR = NINT(PROPS(3))
      XMU  = E/(2.0D0*(1.0D0 + XNU))
      XLAM = E*XNU/((1.0D0 + XNU)*(1.0D0 - 2.0D0*XNU))
!
      DO J = 1, NTENS
         DO I = 1, NTENS
            DDSDDE(I,J) = 0.0D0
         ENDDO
      ENDDO
      IF (NDI .EQ. 3) THEN
         DO J = 1, 3
            DO I = 1, 3
               DDSDDE(I,J) = XLAM
            ENDDO
            DDSDDE(J,J) = XLAM + 2.0D0*XMU
         ENDDO
      ELSE
         Q = E/(1.0D0 - XNU*XNU)
         DDSDDE(1,1) = Q
         DDSDDE(2,2) = Q
         DDSDDE(1,2) = XNU*Q
         DDSDDE(2,1) = XNU*Q
         IF (IVAR .EQ. 2) THEN
!           fault 2: the plane-strain block used for plane stress
            DDSDDE(1,1) = XLAM + 2.0D0*XMU
            DDSDDE(2,2) = XLAM + 2.0D0*XMU
            DDSDDE(1,2) = XLAM
            DDSDDE(2,1) = XLAM
         ENDIF
      ENDIF
      DO K = 1, NSHR
         DDSDDE(NDI+K,NDI+K) = XMU
!        fault 1: tensor shear modulus 2*mu instead of mu
         IF (IVAR .EQ. 1) DDSDDE(NDI+K,NDI+K) = 2.0D0*XMU
      ENDDO
!
      IF (IVAR .EQ. 3) THEN
!        fault 3: total form; the stress on entry is overwritten
         DO I = 1, NTENS
            STRESS(I) = 0.0D0
            DO J = 1, NTENS
               STRESS(I) = STRESS(I)
     1                   + DDSDDE(I,J)*(STRAN(J) + DSTRAN(J))
            ENDDO
         ENDDO
      ELSE
         CALL K12_UPD(STRESS, DDSDDE, DSTRAN, SSE, NTENS)
      ENDIF
!     fault 4: correct stress, but a Jacobian 1.5 times too stiff
      IF (IVAR .EQ. 4) THEN
         DO J = 1, NTENS
            DO I = 1, NTENS
               DDSDDE(I,J) = 1.5D0*DDSDDE(I,J)
            ENDDO
         ENDDO
      ENDIF
      RETURN
      END
