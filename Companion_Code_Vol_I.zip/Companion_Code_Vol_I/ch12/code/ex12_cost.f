      PROGRAM EX12COST
!
!     Time per UMAT call.  Link once with the isotropic and once with
!     the orthotropic routine; run with the argument ISO or ORT.
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(9), STRESS(6), STRAN(6), DSTRAN(6), DD(36)
      CHARACTER*8 ARG
      INTEGER*8 N0, N1, NR
!
      CALL GETARG(1, ARG)
      IF (ARG(1:3) .EQ. 'ISO') THEN
         PROPS(1) = 210000.0D0
         PROPS(2) = 0.3D0
      ELSE
         PROPS(1) = 45000.0D0
         PROPS(2) = 12000.0D0
         PROPS(3) = 12000.0D0
         PROPS(4) = 0.28D0
         PROPS(5) = 0.28D0
         PROPS(6) = 0.42D0
         PROPS(7) = 5500.0D0
         PROPS(8) = 5500.0D0
         PROPS(9) = 4225.0D0
      ENDIF
      DO I = 1, 6
         STRESS(I) = 0.0D0
         STRAN(I)  = 0.0D0
         DSTRAN(I) = 0.0D0
      ENDDO
      DSTRAN(1) = 1.0D-6
      DSTRAN(2) = -3.0D-7
      DSTRAN(3) = -3.0D-7
      NCALL = 2000000
      CALL SYSTEM_CLOCK(N0, NR)
      DO N = 1, NCALL
         CALL K12_CALL(3,3,6,PROPS,9,STRESS,STRAN,DSTRAN,DD,SSE)
      ENDDO
      CALL SYSTEM_CLOCK(N1, NR)
      WRITE(*,'(A,F8.1,A,F10.4)') 'ns per call', 1.0D9*DBLE(N1-N0)/
     1   DBLE(NR)/DBLE(NCALL), '   sigma11', STRESS(1)
      END
