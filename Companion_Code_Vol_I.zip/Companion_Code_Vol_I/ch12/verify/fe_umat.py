"""Q4 finite element program (Python) that calls the compiled UMAT at its Gauss points.
Checks of Chapter 12: patch tests (plane stress, plane strain) and the Lame thick cylinder
(plane stress, plane strain, axisymmetric).  Output: ../out/fe_results.txt and fe_results.json"""
import numpy as np, json, sys
from umat_py import Umat
g=1/np.sqrt(3); GP=[(-g,-g),(g,-g),(g,g),(-g,g)]
def shape(xi,eta):
    N=0.25*np.array([(1-xi)*(1-eta),(1+xi)*(1-eta),(1+xi)*(1+eta),(1-xi)*(1+eta)])
    dN=0.25*np.array([[-(1-eta),-(1-xi)],[(1-eta),-(1+xi)],[(1+eta),(1+xi)],[-(1+eta),(1-xi)]])
    return N,dN
DIM={'PS':(2,1),'PE':(3,1),'AX':(3,1)}
def Bmat(mode,X,xi,eta):
    N,dN=shape(xi,eta); J=dN.T@X; dJ=np.linalg.det(J); dNx=dN@np.linalg.inv(J).T   # (4,2)
    xg=N@X; nt=sum(DIM[mode]); B=np.zeros((nt,8))
    for a in range(4):
        B[0,2*a]=dNx[a,0]; B[1,2*a+1]=dNx[a,1]
        B[nt-1,2*a]=dNx[a,1]; B[nt-1,2*a+1]=dNx[a,0]
        if mode=='AX': B[2,2*a]=N[a]/xg[0]
    w=dJ*(xg[0] if mode=='AX' else 1.0)
    return B,w,xg
def solve(U,mode,nodes,elems,fixed,F):
    """one increment: UMAT called with zero strain increment for DDSDDE, then with the converged one"""
    ndi,nshr=DIM[mode]; nt=ndi+nshr; n=len(nodes); K=np.zeros((2*n,2*n))
    for e in elems:
        X=nodes[e]; dof=np.array([[2*a,2*a+1] for a in e]).ravel(); Ke=np.zeros((8,8))
        for gp in GP:
            B,w,_=Bmat(mode,X,*gp); _,D,_=U.call(ndi,nshr,np.zeros(nt),np.zeros(nt))
            Ke+=B.T@D@B*w
        K[np.ix_(dof,dof)]+=Ke
    u=np.zeros(2*n); idx=np.array(sorted(fixed)); free=np.setdiff1d(np.arange(2*n),idx)
    for d,v in fixed.items(): u[d]=v
    rhs=F-K@u; u[free]=np.linalg.solve(K[np.ix_(free,free)],rhs[free])
    out=[]; sse_tot=0.0
    for e in elems:
        X=nodes[e]; dof=np.array([[2*a,2*a+1] for a in e]).ravel()
        for gp in GP:
            B,w,xg=Bmat(mode,X,*gp); eps=B@u[dof]
            sig,D,sse=U.call(ndi,nshr,np.zeros(nt),eps); out.append((xg,sig,eps)); sse_tot+=sse*w
    return u,out,sse_tot
def patch(U,mode,eps0):
    P=np.array([[0,0],[10,0],[10,10],[0,10],[2,2],[8,3],[8,7],[4,7]],float)
    elems=[[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[4,5,6,7]]
    ex,ey,gxy=eps0; fixed={}
    for a in range(4):
        x,y=P[a]; fixed[2*a]=ex*x+0.5*gxy*y; fixed[2*a+1]=ey*y+0.5*gxy*x
    u,out,_=solve(U,mode,P,elems,fixed,np.zeros(16))
    ndi,nshr=DIM[mode]; nt=ndi+nshr
    epsx=np.zeros(nt); epsx[0]=ex; epsx[1]=ey; epsx[nt-1]=gxy
    sref,_,_=U.call(ndi,nshr,np.zeros(nt),epsx)
    err=max(np.abs(s-sref).max() for _,s,_ in out)/np.abs(sref).max()
    ui=max(abs(u[2*a]-(ex*P[a,0]+0.5*gxy*P[a,1])) for a in range(4,8)); 
    ui=max(ui,max(abs(u[2*a+1]-(ey*P[a,1]+0.5*gxy*P[a,0])) for a in range(4,8)))
    return err,ui,sref
def lame(mode,r,a,b,p,E,nu):
    K=p*a*a/(b*b-a*a); sr=K*(1-b*b/r**2); st=K*(1+b*b/r**2)
    if mode in ('PE','AX'): sz=nu*(sr+st); u=(1+nu)*K/E*((1-2*nu)*r+b*b/r)
    else: sz=0*sr; u=K/E*((1-nu)*r+(1+nu)*b*b/r)
    return sr,st,sz,u
def cyl(U,mode,n,a=50.,b=100.,p=100.,E=210000.,nu=0.3):
    if mode=='AX':
        r=np.linspace(a,b,n+1); h=10.
        nodes=np.array([[x,0.] for x in r]+[[x,h] for x in r]); elems=[[i,i+1,n+1+i+1,n+1+i] for i in range(n)]
        fixed={}
        for i in range(2*(n+1)): fixed[2*i+1]=0.0
        F=np.zeros(2*len(nodes)); F[0]+=p*a*h/2; F[2*(n+1)]+=p*a*h/2
    else:
        nth=n; rr=np.linspace(a,b,n+1); th=np.linspace(0,np.pi/2,nth+1)
        nodes=np.array([[r*np.cos(t),r*np.sin(t)] for t in th for r in rr])   # node (j,i)=j*(n+1)+i
        elems=[[j*(n+1)+i,j*(n+1)+i+1,(j+1)*(n+1)+i+1,(j+1)*(n+1)+i] for j in range(nth) for i in range(n)]
        fixed={}
        for i in range(n+1): fixed[2*i+1]=0.0; fixed[2*(nth*(n+1)+i)]=0.0
        F=np.zeros(2*len(nodes))
        for j in range(nth):
            n1=j*(n+1); n2=(j+1)*(n+1); t=nodes[n2]-nodes[n1]; L=np.linalg.norm(t)
            nrm=np.array([t[1],-t[0]])/L           # normal pointing away from the axis for increasing theta
            if nrm@nodes[n1]<0: nrm=-nrm
            for nn in (n1,n2): F[2*nn:2*nn+2]+=p*L/2*nrm
    u,out,sse=solve(U,mode,nodes,elems,fixed,F)
    err_t=err_r=err_z=0; sc=p*a*a/(b*b-a*a); ea=[0.,0.,0.]
    for k in range(0,len(out),4):
        grp=out[k:k+4]; sig=np.mean([g[1] for g in grp],axis=0)
        xg=np.mean([g[0] for g in grp],axis=0); rg=xg[0] if mode=='AX' else np.hypot(*xg)
        sr,st,sz,_=lame(mode,rg,a,b,p,E,nu)
        if mode=='AX': c_r,c_t,c_z=sig[0],sig[2],sig[1]
        else:
            th_=np.arctan2(xg[1],xg[0]); c,s=np.cos(th_),np.sin(th_); sxx,syy,sxy=sig[0],sig[1],sig[-1]
            c_r=sxx*c*c+syy*s*s+2*sxy*s*c; c_t=sxx*s*s+syy*c*c-2*sxy*s*c; c_z=sig[2] if mode=='PE' else 0.
        ea=[max(ea[0],abs(c_r-sr)/p),max(ea[1],abs(c_t-st)/p),max(ea[2],abs(c_z-sz)/p)]
    for xg,sig,_ in out:
        rg=xg[0] if mode=='AX' else np.hypot(*xg); sr,st,sz,_=lame(mode,rg,a,b,p,E,nu)
        if mode=='AX': c_r,c_t,c_z=sig[0],sig[2],sig[1]
        else:
            th_=np.arctan2(xg[1],xg[0]); c,s=np.cos(th_),np.sin(th_); sxx,syy,sxy=sig[0],sig[1],sig[-1]
            c_r=sxx*c*c+syy*s*s+2*sxy*s*c; c_t=sxx*s*s+syy*c*c-2*sxy*s*c; c_z=sig[2] if mode=='PE' else 0.
        err_r=max(err_r,abs(c_r-sr)/ (p)); err_t=max(err_t,abs(c_t-st)/(p)); err_z=max(err_z,abs(c_z-sz)/p)
    ua=np.hypot(u[0],u[1]) if mode!='AX' else u[0]
    return dict(mode=mode,n=n,ea=ea,err_sr=err_r,err_st=err_t,err_sz=err_z,ua=ua,ua_exact=lame(mode,a,a,b,p,E,nu)[3],sse=sse,
                pts=[(float(np.hypot(*xg[:2]) if mode!='AX' else xg[0]),*[float(v) for v in sig]) for xg,sig,_ in out],
                nodes=nodes.tolist() if n<=8 else None)
if __name__=='__main__':
    iso=Umat('libiso.so',[210000.,0.3]); R={}; L=[]
    for mode in ('PS','PE'):
        err,ui,sref=patch(iso,mode,(1.0e-3,-2.0e-4,6.0e-4)); L.append(f'patch {mode}: max rel stress dev {err:.2e}, max interior nodal disp error {ui:.2e} mm, sigma={np.round(sref,4)}')
    ort=Umat('libortho.so',[45000.,12000.,12000.,.28,.28,.42,5500.,5500.,4225.])
    err,ui,sref=patch(ort,'PS',(1.0e-3,-2.0e-4,6.0e-4)); L.append(f'patch PS orthotropic: max rel stress dev {err:.2e}, disp err {ui:.2e}, sigma={np.round(sref,4)}')
    err,ui,sref=patch(ort,'PE',(1.0e-3,-2.0e-4,6.0e-4)); L.append(f'patch PE orthotropic: max rel stress dev {err:.2e}, disp err {ui:.2e}, sigma={np.round(sref,4)}')
    conv={}
    for mode in ('PS','PE','AX'):
        conv[mode]=[]
        for n in (2,4,8,16):
            d=cyl(iso,mode,n); conv[mode].append(d)
            L.append(f"cyl {mode} n={n:2d}: max |dsig_r|/p {d['err_sr']:.3e}  |dsig_t|/p {d['err_st']:.3e}  |dsig_z|/p {d['err_sz']:.3e}  elem-avg {d['ea'][0]:.2e} {d['ea'][1]:.2e} {d['ea'][2]:.2e}  u(a) {d['ua']:.6f} exact {d['ua_exact']:.6f} err {100*(d['ua']/d['ua_exact']-1):+.3f}%")
    open('../out/fe_results.txt','w').write('\n'.join(L)); print('\n'.join(L))
    json.dump(conv,open('../out/fe_results.json','w'))
