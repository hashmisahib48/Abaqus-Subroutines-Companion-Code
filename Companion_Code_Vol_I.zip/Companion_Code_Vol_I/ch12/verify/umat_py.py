"""ctypes access to the compiled UMAT (through K12_CALL) -- test harness for Chapter 12."""
import ctypes as C, numpy as np, os
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','out')
class Umat:
    def __init__(s,lib,props):
        s.lib=C.CDLL(os.path.join(OUT,lib)); s.props=np.array(props,float)
    def call(s,ndi,nshr,stress,dstran,stran=None):
        nt=ndi+nshr; st=np.array(stress,float).copy(); ds=np.array(dstran,float).copy()
        sn=np.zeros(nt) if stran is None else np.array(stran,float).copy()
        D=np.zeros((nt,nt),order='F'); sse=C.c_double(0.0)
        i=lambda v:C.byref(C.c_int(v)); p=lambda a:a.ctypes.data_as(C.c_void_p)
        s.lib.k12_call_(i(ndi),i(nshr),i(nt),p(s.props),i(len(s.props)),p(st),p(sn),p(ds),p(D),C.byref(sse))
        return st,D,sse.value
