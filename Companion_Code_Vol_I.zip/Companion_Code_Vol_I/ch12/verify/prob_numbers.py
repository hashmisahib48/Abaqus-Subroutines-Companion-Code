"""Numbers quoted in the problem answers of Chapter 12 (computed with the compiled UMATs)."""
import numpy as np
from umat_py import Umat
L=[]
# 12A.1 aluminium plane stress
U=Umat('libiso.so',[70000.,0.33]); _,D,_=U.call(2,1,np.zeros(3),np.zeros(3)); L.append('12A.1 PS D (E=70000, nu=0.33): '+np.array2string(D,precision=2,suppress_small=True).replace('\n',' '))
_,D3,_=U.call(3,3,np.zeros(6),np.zeros(6)); L.append('12A.1 3D D11,D12,D44: %.2f %.2f %.2f'%(D3[0,0],D3[0,1],D3[3,3]))
# 12A.2 energy increment PS steel
U=Umat('libiso.so',[210000.,0.3]); s0=np.array([100.,40.,30.]); de=np.array([2e-4,1e-4,4e-4])
s1,D,sse=U.call(2,1,s0,de); L.append(f'12A.2 sigma_new {s1} dSSE {sse:.6f}  ; by hand 0.5(s0+s1).de = {0.5*(s0+s1)@de:.6f}; dsig {s1-s0}')
# 12A.3 timber-like orthotropic plane stress
P=[14000.,1000.,1000.,.35,.35,.30,900.,900.,400.]; U=Umat('libortho.so',P); _,D,_=U.call(2,1,np.zeros(3),np.zeros(3))
n21=.35*1000/14000; L.append(f'12A.3 nu21 {n21:.4f}  1-n12n21 {1-.35*n21:.5f}  Q11 {D[0,0]:.2f} Q12 {D[0,1]:.2f} Q22 {D[1,1]:.2f} Q66 {D[2,2]:.2f}')
# 12B.3 incompressibility
for nu in (0.3,0.45,0.49,0.499,0.4999):
    E=210000.; lam=E*nu/((1+nu)*(1-2*nu)); mu=E/2/(1+nu); K=E/3/(1-2*nu)
    Uu=Umat('libiso.so',[E,nu]) if nu<0.5 else None
    _,D,_=Uu.call(3,3,np.zeros(6),np.zeros(6)); ev=np.linalg.eigvalsh(D)
    L.append(f'12B.3 nu {nu}: lam/mu {lam/mu:.1f}  cond(D) {ev[-1]/ev[0]:.1f}  3K {3*K:.4e} mu {mu:.1f} digits lost log10 {np.log10(ev[-1]/ev[0]):.2f}')
# 12C.1 transversely isotropic
E1,E2,n12,G12,n23=45000.,12000.,.28,5500.,.42; G23=E2/2/(1+n23)
U=Umat('libortho.so',[E1,E2,E2,n12,n12,n23,G12,G12,G23]); _,D,_=U.call(3,3,np.zeros(6),np.zeros(6))
L.append(f'12C.1 G23 {G23:.2f}  D11 {D[0,0]:.2f} D12 {D[0,1]:.2f} D22 {D[1,1]:.2f} D23 {D[1,2]:.2f} D44 {D[3,3]:.2f} D66 {D[5,5]:.2f}  (D22-D23)/2 {(D[1,1]-D[1,2])/2:.2f}')
open('../out/prob_numbers.txt','w').write('\n'.join(L)); print('\n'.join(L))
