#!/bin/sh
# build drivers and shared libraries for Chapter 12 (gfortran, stubs)
cd "$(dirname "$0")/../code"; mkdir -p ../out
F="gfortran -ffixed-form -std=legacy -fPIC -I/home/claude/book/lib/aba"
S=/home/claude/book/lib/aba/stubs.f
$F ex12_3_drv.f ex12_3_umat_iso.f k12_common.f k12_call.f $S -o ../out/drv3 || exit 1
$F ex12_5_drv.f ex12_5_umat_ortho.f k12_common.f k12_call.f $S -o ../out/drv5 || exit 1
$F ex12_7_drv.f ex12_7_bad.f k12_call.f k12_common.f $S -o ../out/drv7 || exit 1
$F -shared ex12_3_umat_iso.f k12_common.f k12_call.f $S -o ../out/libiso.so || exit 1
$F -shared ex12_5_umat_ortho.f k12_common.f k12_call.f $S -o ../out/libortho.so || exit 1
$F -shared ex12_7_bad.f k12_common.f k12_call.f $S -o ../out/libbad.so || exit 1
