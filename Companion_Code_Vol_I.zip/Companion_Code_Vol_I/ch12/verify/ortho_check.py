"""Independent checks of the orthotropic UMAT (Chapter 12): numpy compliance inverse, plane-stress
reduction formulas, isotropic limit against the isotropic UMAT, off-axis modulus of a rotated ply."""
import numpy as np, json
from umat_py import Umat
P=[45000.,12000.,12000.,.28,.28,.42,5500.,5500.,4225.]
E1,E2,E3,n12,n13,n23,G12,G13,G23=P
U=Umat('libortho.so',P); R=[]
S=np.zeros((6,6)); S[0,0]=1/E1;S[1,1]=1/E2;S[2,2]=1/E3;S[0,1]=S[1,0]=-n12/E1;S[0,2]=S[2,0]=-n13/E1;S[1,2]=S[2,1]=-n23/E2
S[3,3]=1/G12;S[4,4]=1/G13;S[5,5]=1/G23
Cn=np.linalg.inv(S)
_,D,_=U.call(3,3,np.zeros(6),np.zeros(6))
R.append(f'3D: max |D_umat - inv(S)|/max|D| = {np.abs(D-Cn).max()/np.abs(Cn).max():.2e}')
ev=np.linalg.eigvalsh(D); R.append('3D eigenvalues (MPa): '+' '.join(f'{x:.2f}' for x in ev))
n21=n12*E2/E1; n31=n13*E3/E1; n32=n23*E3/E2
Dl=1-n12*n21-n23*n32-n31*n13-2*n21*n32*n13
C11=E1*(1-n23*n32)/Dl; R.append(f'closed form C11 = E1(1-n23 n32)/Delta = {C11:.2f}   UMAT {D[0,0]:.2f}   nu21={n21:.5f}')
# plane stress
_,Dp,_=U.call(2,1,np.zeros(3),np.zeros(3))
Q11=E1/(1-n12*n21);Q22=E2/(1-n12*n21);Q12=n12*E2/(1-n12*n21)
R.append(f'PS: UMAT {Dp[0,0]:.2f} {Dp[0,1]:.2f} {Dp[1,1]:.2f} {Dp[2,2]:.2f}  closed form Q11,Q12,Q22,G12 {Q11:.2f} {Q12:.2f} {Q22:.2f} {G12:.2f}')
R.append(f'PS: max abs diff {max(abs(Dp[0,0]-Q11),abs(Dp[0,1]-Q12),abs(Dp[1,1]-Q22)):.2e}')
# plane-stress apparent properties: sigma22=0: eps22/eps11
# isotropic limit
E,nu=210000.,0.3; Ui=Umat('libiso.so',[E,nu]); Uo=Umat('libortho.so',[E,E,E,nu,nu,nu,E/2/(1+nu)]*1+[E/2/(1+nu),E/2/(1+nu)])
Uo.props=np.array([E,E,E,nu,nu,nu,E/2/(1+nu),E/2/(1+nu),E/2/(1+nu)])
for (ndi,nsh) in ((3,3),(3,1),(2,1)):
    nt=ndi+nsh; _,Di,_=Ui.call(ndi,nsh,np.zeros(nt),np.zeros(nt)); _,Do,_=Uo.call(ndi,nsh,np.zeros(nt),np.zeros(nt))
    R.append(f'isotropic limit NTENS={nt}: max|D_ortho-D_iso|/max|D| = {np.abs(Di-Do).max()/np.abs(Di).max():.2e}')
# off-axis: plane stress ply rotated theta; local axis 1' at theta from x
def T_eps(t):
    c,s=np.cos(t),np.sin(t); return np.array([[c*c,s*s,c*s],[s*s,c*c,-c*s],[-2*c*s,2*c*s,c*c-s*s]])
def T_sig(t):
    c,s=np.cos(t),np.sin(t); return np.array([[c*c,s*s,2*c*s],[s*s,c*c,-2*c*s],[-c*s,c*s,c*c-s*s]])
def Ex_nu(t):
    # global strain (ex, ey, gxy): ex=1e-3 prescribed; ey,gxy found so that sy=txy=0 (Newton with UMAT calls)
    f=lambda e: T_sig(-t)@U.call(2,1,np.zeros(3),T_eps(t)@e)[0]
    e=np.array([1e-3,0,0]); 
    for _ in range(3):
        s0=f(e); J=np.zeros((2,2))
        for j,k in enumerate((1,2)):
            h=1e-7; ee=e.copy(); ee[k]+=h; J[:,j]=(f(ee)-s0)[1:]/h
        e[1:]-=np.linalg.solve(J,s0[1:])
    s=f(e); return s[0]/e[0], -e[1]/e[0], e
th=np.radians(np.arange(0,91,15)); out=[]
for t in th:
    c,s=np.cos(t),np.sin(t)
    invEx=c**4/E1+(1/G12-2*n12/E1)*s*s*c*c+s**4/E2
    nuxy=(Ex_nu(t)[0])*(n12/E1*(c**4+s**4)-(1/E1+1/E2-1/G12)*s*s*c*c)
    ex_,nu_,_=Ex_nu(t); out.append((np.degrees(t),ex_,1/invEx,nu_,nuxy))
    R.append(f'theta {np.degrees(t):4.0f}: Ex UMAT {ex_:10.2f}  closed form {1/invEx:10.2f}   nu_xy UMAT {nu_:.5f}  closed form {nuxy:.5f}')
json.dump(out,open('../out/offaxis.json','w'))
open('../out/ortho_results.txt','w').write('\n'.join(R)); print('\n'.join(R))
