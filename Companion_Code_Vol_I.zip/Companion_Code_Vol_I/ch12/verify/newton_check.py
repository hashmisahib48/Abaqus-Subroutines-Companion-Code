"""Newton iteration count of the cylinder model (plane stress, 8 x 8 mesh) with the correct UMAT and with
fault 4 of Section 12.7 (correct stress, Jacobian 1.5 times too stiff)."""
import numpy as np
from umat_py import Umat
import fe_umat as F
def newton(U,mode='PS',n=8,a=50.,b=100.,p=100.,tol=1e-8):
    rr=np.linspace(a,b,n+1); th=np.linspace(0,np.pi/2,n+1)
    nodes=np.array([[r*np.cos(t),r*np.sin(t)] for t in th for r in rr])
    elems=[[j*(n+1)+i,j*(n+1)+i+1,(j+1)*(n+1)+i+1,(j+1)*(n+1)+i] for j in range(n) for i in range(n)]
    fixed={}
    for i in range(n+1): fixed[2*i+1]=0.0; fixed[2*(n*(n+1)+i)]=0.0
    Fx=np.zeros(2*len(nodes))
    for j in range(n):
        n1=j*(n+1); n2=(j+1)*(n+1); t=nodes[n2]-nodes[n1]; L=np.linalg.norm(t); nr=np.array([t[1],-t[0]])/L
        if nr@nodes[n1]<0: nr=-nr
        for nn in (n1,n2): Fx[2*nn:2*nn+2]+=p*L/2*nr
    ndi,nshr=F.DIM[mode]; nt=ndi+nshr; N=2*len(nodes); u=np.zeros(N)
    idx=np.array(sorted(fixed)); free=np.setdiff1d(np.arange(N),idx)
    # stress state at Gauss points is carried in STRESS (start of increment = 0), strains total
    hist=[]; sig_pts={}
    for it in range(60):
        K=np.zeros((N,N)); fint=np.zeros(N)
        for ie,e in enumerate(elems):
            X=nodes[e]; dof=np.array([[2*a_,2*a_+1] for a_ in e]).ravel()
            for ig,gp in enumerate(F.GP):
                B,w,_=F.Bmat(mode,X,*gp); eps=B@u[dof]
                sig,D,_=U.call(ndi,nshr,np.zeros(nt),eps)   # stress from zero state + total strain as one increment
                K[np.ix_(dof,dof)]+=B.T@D@B*w; fint[dof]+=B.T@sig*w
        res=(Fx-fint)[free]; rn=np.linalg.norm(res)/np.linalg.norm(Fx[free]); hist.append(rn)
        if rn<tol: break
        du=np.linalg.solve(K[np.ix_(free,free)],res); u[free]+=du
    return hist,np.hypot(u[0],u[1])
if __name__=='__main__':
    L=[]
    for name,props in (('correct',[210000.,.3,0.]),('fault 4 (J = 1.5 D)',[210000.,.3,4.])):
        h,ua=newton(Umat('libbad.so',props)); L.append(f'{name}: iterations {len(h)-1}, residual history '+' '.join(f'{x:.1e}' for x in h[:8])+f' ... final u(a)={ua:.8f}')
    open('../out/newton.txt','w').write('\n'.join(L)); print('\n'.join(L))
