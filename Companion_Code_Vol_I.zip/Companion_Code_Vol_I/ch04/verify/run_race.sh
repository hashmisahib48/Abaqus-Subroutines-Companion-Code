#!/bin/sh
# builds and runs the race driver 10 times; output in race_runs.txt
cd /home/claude/book/ch04
gfortran -O0 -fopenmp -ffixed-form -std=legacy -I/home/claude/book/lib/aba -Icode code/driver_race.f code/ex4_1_count.f code/mutex_omp.f /home/claude/book/lib/aba/stubs.f -Wl,--allow-multiple-definition -o /tmp/sc/dr
: > verify/race_runs.txt
for k in 1 2 3 4 5 6 7 8 9 10; do /tmp/sc/dr >> verify/race_runs.txt; done
