# Cross-check of K4_PRIN (SPRIND test stub) against numpy on random tensors.
import numpy as np, subprocess, os
os.chdir('/home/claude/book/ch04/verify'); rng=np.random.default_rng(4)
N=20000; S=rng.normal(0,100,(N,6)); np.savetxt('rand_in.txt',S,fmt='%.16e')
subprocess.run('gfortran -ffixed-form -std=legacy -I/home/claude/book/lib/aba ../code/driver_rand.f ../code/ex4_5_prin.f /home/claude/book/lib/aba/stubs.f -o /tmp/sc/drand && /tmp/sc/drand',shell=True,check=True)
O=np.loadtxt('rand_out.txt'); ePS=0; eAN=0; eOrth=0
for s,o in zip(S,O):
    A=np.array([[s[0],s[3],s[4]],[s[3],s[1],s[5]],[s[4],s[5],s[2]]])
    w,v=np.linalg.eigh(A); idx=np.argsort(-w); w=w[idx]; v=v[:,idx]
    ps=o[:3]; an=o[3:].reshape(3,3)
    ePS=max(ePS,np.abs(ps-w).max())
    for k in range(3): eAN=max(eAN,min(np.abs(an[k]-v[:,k]).max(),np.abs(an[k]+v[:,k]).max()))
    eOrth=max(eOrth,np.abs(an@an.T-np.eye(3)).max())
print('N',N,'max |dPS| %.2e'%ePS,'max direction diff (sign-free) %.2e'%eAN,'orthonormality %.2e'%eOrth)
