!     Executable part: part-instance name and local number of element
!     NOEL (an internal number).  Not trivial in cost: call it once.
      CHARACTER*80 CPNAME
!
      CALL GETPARTINFO(NOEL, 1, CPNAME, LOCNUM, JRCD)
      IF (JRCD .EQ. 0) THEN
         ILOC = LOCNUM
      ELSE
         ILOC = -1
      ENDIF
