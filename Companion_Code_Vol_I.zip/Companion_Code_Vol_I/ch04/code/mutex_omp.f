!     TEST REPLACEMENT for the Abaqus mutex routines, built on OpenMP
!     locks, so that thread races can be provoked outside Abaqus.
      SUBROUTINE MUTEXINIT(N)
      USE OMP_LIB
      INTEGER N
      INTEGER(OMP_LOCK_KIND) LCK(100)
      COMMON /K4LCK/ LCK
      CALL OMP_INIT_LOCK(LCK(N))
      RETURN
      END
      SUBROUTINE MUTEXLOCK(N)
      USE OMP_LIB
      INTEGER N
      INTEGER(OMP_LOCK_KIND) LCK(100)
      COMMON /K4LCK/ LCK
      CALL OMP_SET_LOCK(LCK(N))
      RETURN
      END
      SUBROUTINE MUTEXUNLOCK(N)
      USE OMP_LIB
      INTEGER N
      INTEGER(OMP_LOCK_KIND) LCK(100)
      COMMON /K4LCK/ LCK
      CALL OMP_UNSET_LOCK(LCK(N))
      RETURN
      END
