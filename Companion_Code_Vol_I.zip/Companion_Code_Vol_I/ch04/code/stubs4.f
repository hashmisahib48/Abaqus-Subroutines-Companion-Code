!     TEST REPLACEMENTS used only to compile and exercise the listings of
!     Chapter 4 outside Abaqus.  They are NOT the Abaqus routines.
!     GETVRM returns a fixed stress state in the component order of the
!     'S' variable; ROTSIG rotates a tensor held in Abaqus vector form
!     as  S' = R S R^T  (LSTR = 1 stress, 2 strain with engineering shear).
      SUBROUTINE GETVRM(VAR,ARRAY,JARRAY,FLGRAY,JRCD,JMAC,JMATYP,
     1                  MATLAYO,LACCFLA)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) VAR
      DIMENSION ARRAY(*), JARRAY(*)
      CHARACTER*3 FLGRAY(*)
      ARRAY(1) = 120.D0
      ARRAY(2) = -40.D0
      ARRAY(3) = 20.D0
      ARRAY(4) = 60.D0
      ARRAY(5) = -30.D0
      ARRAY(6) = 10.D0
      JRCD = 0
      RETURN
      END
!
      SUBROUTINE ROTSIG(S,R,SPRIME,LSTR,NDI,NSHR)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(*), R(3,3), SPRIME(*), A(3,3), B(3,3), F(3)
      INTEGER IA(3), IB(3)
      DATA IA /1, 1, 2/
      DATA IB /2, 3, 3/
      FAC = 1.D0
      IF (LSTR .EQ. 2) FAC = 0.5D0
      A = 0.D0
      DO K = 1, NDI
         A(K,K) = S(K)
      ENDDO
      DO K = 1, NSHR
         A(IA(K),IB(K)) = FAC*S(NDI+K)
         A(IB(K),IA(K)) = A(IA(K),IB(K))
      ENDDO
      B = MATMUL(R, MATMUL(A, TRANSPOSE(R)))
      DO K = 1, NDI
         SPRIME(K) = B(K,K)
      ENDDO
      DO K = 1, NSHR
         SPRIME(NDI+K) = B(IA(K),IB(K))/FAC
      ENDDO
      RETURN
      END
!
      SUBROUTINE GETPARTINFO(INTNUM,JTYP,CPNAME,LOCNUM,JRCD)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) CPNAME
      CPNAME = 'PLATE-1'
      LOCNUM = INTNUM - 1000
      JRCD = 0
      RETURN
      END
!
      SUBROUTINE GETINTERNAL(CPNAME,LOCNUM,JTYP,INTNUM,JRCD)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) CPNAME
      INTNUM = LOCNUM + 1000
      JRCD = 0
      RETURN
      END
