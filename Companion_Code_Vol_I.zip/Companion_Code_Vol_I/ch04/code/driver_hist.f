!     Driver for Example 4.3-1.  Force-controlled Newton iteration on a
!     single material point, with the Abaqus conventions that
!     (i) every call in an increment receives the STATEV of the START
!     of the increment, and (ii) the STATEV returned by a trial
!     iteration is kept only if the increment converges.
      PROGRAM DRVHST
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NITMAX = 5, TOL = 1.0D-6, SIGT = 4.0D0)
      DIMENSION STRESS(1),STATEV(1),DDSDDE(1,1),DDSDDT(1),DRPLDE(1)
      DIMENSION STRAN(1),DSTRAN(1),TIME(2),PREDEF(1),DPRED(1)
      DIMENSION PROPS(2),COORDS(3),DROT(3,3),DFGRD0(3,3),DFGRD1(3,3)
      DIMENSION JSTEP(4), SV0(1)
      CHARACTER*80 CMNAME
      COMMON /K4HST/ HC
      OPEN(UNIT=20, FILE='hist_iter.csv')
      PROPS(1) = 1000.D0
      PROPS(2) = 0.002D0
      HC = 0.D0
      SV0(1) = 0.D0
      EPSN = 0.D0
      TLAM = 0.D0
      DLAM = 1.D0
      NATT = 0
      EMAX = 0.D0
      WRITE(*,'(A)') ' attempt  size  iter  result      trial max '//
     1   '  STATEV(1)     HC'
 100  CONTINUE
      NATT = NATT + 1
      EPS  = EPSN
      TARG = SIGT*(TLAM + DLAM)
      DO IT = 1, NITMAX
         STATEV(1) = SV0(1)
         STRAN(1)  = EPSN
         DSTRAN(1) = EPS - EPSN
         CALL UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,RPL,DDSDDT,
     1    DRPLDE,DRPLDT,STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,
     2    DPRED,CMNAME,1,0,1,1,PROPS,2,COORDS,DROT,PNEWDT,CELENT,
     3    DFGRD0,DFGRD1,1,1,1,1,JSTEP,1)
         RES = TARG - STRESS(1)
         EMAX = MAX(EMAX, EPS)
         WRITE(20,'(2I4,2ES14.6)') NATT, IT, EPS, HC
         IF (ABS(RES) .LT. TOL*TARG) GOTO 200
         EPS = EPS + RES/DDSDDE(1,1)
      ENDDO
!     no convergence: cutback, start again from the converged state
      WRITE(*,'(I6,F8.3,I5,2X,A,ES12.4,2ES12.4)') NATT, DLAM,
     1   NITMAX, 'cutback  ', EMAX, STATEV(1), HC
      DLAM = 0.5D0*DLAM
      EMAX = 0.D0
      GOTO 100
 200  CONTINUE
      EPSN   = EPS
      SV0(1) = STATEV(1)
      TLAM   = TLAM + DLAM
      WRITE(*,'(I6,F8.3,I5,2X,A,ES12.4,2ES12.4)') NATT, DLAM,
     1   IT, 'accepted ', EMAX, SV0(1), HC
      EMAX = 0.D0
      IF (TLAM .LT. 1.D0 - 1.D-12) GOTO 100
      WRITE(*,'(A,ES14.6)') ' final strain', EPSN
      CLOSE(20)
      END
