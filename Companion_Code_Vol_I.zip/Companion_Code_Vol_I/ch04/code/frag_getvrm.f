!     Declarations and executable part of a USDFLD: FIELD(1) is the
!     largest principal stress at the START of the increment, in units
!     of the yield stress SY (MPa).
      DIMENSION ARRAY(15), JARRAY(15), PS(3), INTV(1), REALV(1)
      CHARACTER*3 FLGRAY(15)
      CHARACTER*8 CHARV(1)
      PARAMETER (SY = 250.0D0)
!
      CALL GETVRM('S', ARRAY, JARRAY, FLGRAY, JRCD, JMAC, JMATYP,
     1            MATLAYO, LACCFLA)
      IF (JRCD .NE. 0) THEN
         CALL STDB_ABQERR(-3, 'USDFLD: GETVRM failed for S',
     1                    INTV, REALV, CHARV)
      ENDIF
      CALL SPRINC(ARRAY, PS, 1, NDI, NSHR)
      FIELD(1) = MAX(PS(1), PS(2), PS(3))/SY
