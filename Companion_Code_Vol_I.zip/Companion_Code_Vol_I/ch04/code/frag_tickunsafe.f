!     Unprotected update: a read-modify-write on shared storage
      NCALL = NCALL + 1
