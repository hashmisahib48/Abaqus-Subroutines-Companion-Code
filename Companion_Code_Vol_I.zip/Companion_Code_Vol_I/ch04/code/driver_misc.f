!     Exercises the helper listings of Sections 4.5 and 4.6 with the test
!     stubs (stubs.f and stubs4.f): file name, messages, USDFLD, ROTSIG.
      PROGRAM DRVMISC
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*120 FNAME
      DIMENSION FIELD(1), STATEV(6), DIRECT(3,3), T(3,3), TIME(2)
      DIMENSION COORD(3), JMAC(1), JMATYP(1), PROPS(2)
      DIMENSION DROT(3,3), E0(6), E1(6)
      DIMENSION STRESS(6),DDSDDE(6,6),DDSDDT(6),DRPLDE(6),STRAN(6)
      DIMENSION DSTRAN(6),PREDEF(1),DPRED(1),COORDS(3),DFGRD0(3,3)
      DIMENSION DFGRD1(3,3),JSTEP(4)
      CHARACTER*80 CMNAME, ORNAME
      CALL K4_LOGNAME(FNAME)
      WRITE(*,*) 'log file: ', TRIM(FNAME)
      CALL USDFLD(FIELD,STATEV,PNEWDT,DIRECT,T,CELENT,TIME,DTIME,
     1  CMNAME,ORNAME,1,6,1,1,1,1,1,1,3,3,COORD,JMAC,JMATYP,1,1)
      WRITE(*,'(A,F12.8)') ' USDFLD FIELD(1) =', FIELD(1)
      PROPS(1) = 210000.D0
      PROPS(2) = 0.3D0
      CALL K4_CHECK(PROPS, 2)
      PROPS(2) = 0.5D0
      CALL K4_CHECK(PROPS, 2)
!     ROTSIG: rotation by 90 degrees about the 3-axis
      DROT = 0.D0
      DROT(1,2) = -1.D0
      DROT(2,1) = 1.D0
      DROT(3,3) = 1.D0
      E0 = (/1.D-3, -2.D-4, -3.D-4, 8.D-4, 0.D0, 0.D0/)
      STATEV = E0
      NDI = 3
      NSHR = 3
      NTENS = 6
      CALL ROTSIG(STATEV(1), DROT, E1, 2, NDI, NSHR)
      WRITE(*,'(A,6ES11.3)') ' before ', E0
      WRITE(*,'(A,6ES11.3)') ' after  ', E1
      CALL K4_WHO(1234, ILOC)
      WRITE(*,*) 'local element number', ILOC
      END
