!     Executable part of a one-dimensional UMAT (NTENS = 1).
!     PROPS(1) = E0 in MPa, PROPS(2) = EPS1 (dimensionless)
      E0   = PROPS(1)
      EPS1 = PROPS(2)
      EPS  = STRAN(1) + DSTRAN(1)
      STRESS(1)   = E0*EPS*(1.0D0 + (EPS/EPS1)**2)
      DDSDDE(1,1) = E0*(1.0D0 + 3.0D0*(EPS/EPS1)**2)
!     Variant S: largest strain so far, kept in STATEV
      STATEV(1) = MAX(STATEV(1), ABS(EPS))
!     Variant C: the same quantity in shared storage (WRONG)
      HC = MAX(HC, ABS(EPS))
