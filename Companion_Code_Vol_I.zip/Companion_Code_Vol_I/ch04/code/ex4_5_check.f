      SUBROUTINE K4_CHECK(PROPS, NPROPS)
!     Validates the material constants: PROPS(1) = E (MPa),
!     PROPS(2) = Poisson ratio.  Called at the first increment only.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(NPROPS), INTV(1), REALV(2)
      CHARACTER*8 CHARV(1)
!
      IF (NPROPS .LT. 2) THEN
         INTV(1) = NPROPS
         CALL STDB_ABQERR(-3, 'UMAT needs 2 constants, found %I',
     1                    INTV, REALV, CHARV)
      ENDIF
      IF (PROPS(2) .LE. 0.0D0 .OR. PROPS(2) .GE. 0.5D0) THEN
         REALV(1) = PROPS(2)
         CALL STDB_ABQERR(-1, 'Poisson ratio %R is outside (0, 0.5)',
     1                    INTV, REALV, CHARV)
      ENDIF
      RETURN
      END
