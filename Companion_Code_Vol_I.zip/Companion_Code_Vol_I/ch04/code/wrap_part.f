      SUBROUTINE K4_WHO(NOEL, ILOC)
      INCLUDE 'ABA_PARAM.INC'
      INCLUDE 'frag_part.f'
      RETURN
      END
