      SUBROUTINE K4_LOGNAME(FNAME)
!     Name of a per-process log file:  <outdir>/<job>_<rank>.log
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) FNAME
      CHARACTER*256 JOBNAME, OUTDIR
      CHARACTER*8 CRANK
!
      CALL GETJOBNAME(JOBNAME, LJOB)
      CALL GETOUTDIR(OUTDIR, LOUT)
      CALL GETRANK(KRANK)
      WRITE(CRANK,'(I0)') KRANK
      FNAME = OUTDIR(1:LOUT)//'/'//JOBNAME(1:LJOB)//'_'//
     1        TRIM(CRANK)//'.log'
      RETURN
      END
