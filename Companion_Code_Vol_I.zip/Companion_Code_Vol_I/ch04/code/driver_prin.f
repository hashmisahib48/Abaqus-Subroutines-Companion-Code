!     Driver for Example 4.5-1: principal stresses and directions
!     through SPRIND (here the test stub), SINV and K4_PRIN.
      PROGRAM DRVPRIN
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(6), PS(3), AN(3,3), PT(3), ANT(3,3), E(3)
      DATA S /120.D0, -40.D0, 20.D0, 60.D0, -30.D0, 10.D0/
      CALL SINV(S, SM, Q, 3, 3)
      WRITE(*,'(A,2F14.8)') ' SINV1, SINV2  ', SM, Q
      CALL SPRINC(S, PT, 1, 3, 3)
      WRITE(*,'(A,3F14.8)') ' SPRINC (raw)  ', PT
      CALL K4_PRIN(S, 3, 3, PS, AN)
      WRITE(*,'(A,3F14.8)') ' K4_PRIN       ', PS
      DO K = 1, 3
         WRITE(*,'(A,I1,A,3F14.8)') ' AN(', K, ',:)      ',
     1      (AN(K,J), J = 1, 3)
      ENDDO
!     orthonormality: largest deviation of AN*AN^T from I
      DEV = 0.D0
      DO K = 1, 3
         DO L = 1, 3
            D = DOT_PRODUCT(AN(K,:), AN(L,:))
            IF (K .EQ. L) D = D - 1.D0
            DEV = MAX(DEV, ABS(D))
         ENDDO
      ENDDO
      WRITE(*,'(A,ES10.2)') ' orthonormality deviation ', DEV
      WRITE(*,'(A,ES10.2)') ' trace check |sum PS - 3*SINV1| ',
     1   ABS(SUM(PS) - 3.D0*SM)
      QP = SQRT(0.5D0*((PS(1)-PS(2))**2+(PS(2)-PS(3))**2+
     1                 (PS(3)-PS(1))**2))
      WRITE(*,'(A,ES10.2)') ' Mises check |q(PS) - SINV2|     ',
     1   ABS(QP - Q)
      END
