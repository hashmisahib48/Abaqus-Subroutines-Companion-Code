!     Reads tensors from rand_in.txt, writes K4_PRIN results to rand_out.txt
      PROGRAM DRVRAND
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(6), PS(3), AN(3,3)
      OPEN(10, FILE='rand_in.txt')
      OPEN(11, FILE='rand_out.txt')
      DO
         READ(10,*,END=90) S
         CALL K4_PRIN(S, 3, 3, PS, AN)
         WRITE(11,'(12ES24.16)') PS, ((AN(K,J),J=1,3),K=1,3)
      ENDDO
 90   CONTINUE
      END
