!     Driver for Example 4.4-1: NTHR threads each make NPER updates of
!     a shared counter, without and with a mutex.
      PROGRAM DRVRACE
      USE OMP_LIB
      INTEGER, PARAMETER :: NPER = 2000000
      INTEGER NCALL, NTHR, K, ITH
      COMMON /K4CNT/ NCALL
      DOUBLE PRECISION T0, T1, T2
      CALL MUTEXINIT(1)
      DO ITH = 1, 4
         NTHR = ITH
         NCALL = 0
         T0 = OMP_GET_WTIME()
!$OMP PARALLEL DO NUM_THREADS(NTHR) SCHEDULE(STATIC)
         DO K = 1, NTHR*NPER
            CALL K4_TICKU
         ENDDO
!$OMP END PARALLEL DO
         T1 = OMP_GET_WTIME()
         WRITE(*,'(A,I2,A,I9,A,I9,A,F7.4)') ' threads', NTHR,
     1     '  unprotected: counted', NCALL, '  expected', NTHR*NPER,
     2     '  s', T1-T0
         NCALL = 0
         T1 = OMP_GET_WTIME()
!$OMP PARALLEL DO NUM_THREADS(NTHR) SCHEDULE(STATIC)
         DO K = 1, NTHR*NPER
            CALL K4_TICK
         ENDDO
!$OMP END PARALLEL DO
         T2 = OMP_GET_WTIME()
         WRITE(*,'(A,I2,A,I9,A,I9,A,F7.4)') ' threads', NTHR,
     1     '  mutex      : counted', NCALL, '  expected', NTHR*NPER,
     2     '  s', T2-T1
      ENDDO
      END
      SUBROUTINE K4_TICKU
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K4CNT/ NCALL
      INCLUDE 'frag_tickunsafe.f'
      RETURN
      END
