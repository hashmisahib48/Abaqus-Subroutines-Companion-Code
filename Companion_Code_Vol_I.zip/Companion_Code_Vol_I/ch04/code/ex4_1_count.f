      SUBROUTINE UEXTERNALDB(LOP,LRESTART,TIME,DTIME,KSTEP,KINC)
!     Counts the calls of the material routine in every increment.
!     K4_TICK is called once from the material routine (UMAT).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), INTV(2), REALV(1)
      CHARACTER*8 CHARV(1)
      COMMON /K4CNT/ NCALL
!
      IF (LOP .EQ. 0) THEN
         CALL MUTEXINIT(1)
         NCALL = 0
      ELSE IF (LOP .EQ. 2) THEN
         INTV(1) = KINC
         INTV(2) = NCALL
         CALL STDB_ABQERR(1, 'Increment %I: UMAT called %I times',
     1                    INTV, REALV, CHARV)
         NCALL = 0
      ENDIF
      RETURN
      END
!
      SUBROUTINE K4_TICK
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K4CNT/ NCALL
!
      CALL MUTEXLOCK(1)
      NCALL = NCALL + 1
      CALL MUTEXUNLOCK(1)
      RETURN
      END
