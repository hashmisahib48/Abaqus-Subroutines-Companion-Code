!     Driver for Example 4.1-1: imitates the DOCUMENTED call pattern
!     (two calls per point in the first iteration, one afterwards)
!     and checks the bookkeeping of ex4_1_count.f against Eq. 4.1-1.
      PROGRAM DRVCNT
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NINC = 4, NPT = 160)
      DIMENSION NIT(NINC), TIME(2)
      COMMON /K4CNT/ NCALL
      DATA NIT /3, 2, 2, 2/
      NTOT = 0
      TIME(1) = 0.D0
      TIME(2) = 0.D0
      CALL UEXTERNALDB(0, 0, TIME, 0.25D0, 1, 0)
      DO KINC = 1, NINC
         CALL UEXTERNALDB(1, 0, TIME, 0.25D0, 1, KINC)
         DO IT = 1, NIT(KINC)
            NPASS = 1
            IF (IT .EQ. 1) NPASS = 2
            DO IP = 1, NPT
               DO K = 1, NPASS
                  CALL K4_TICK
               ENDDO
            ENDDO
         ENDDO
         NEXP = NPT*(NIT(KINC) + 1)
         WRITE(*,'(A,I2,A,I5,A,I5)') ' increment', KINC,
     1      '  counter =', NCALL, '  formula =', NEXP
         NTOT = NTOT + NCALL
         CALL UEXTERNALDB(2, 0, TIME, 0.25D0, 1, KINC)
      ENDDO
      CALL UEXTERNALDB(3, 0, TIME, 0.25D0, 1, NINC)
      WRITE(*,'(A,I6)') ' total =', NTOT
      END
