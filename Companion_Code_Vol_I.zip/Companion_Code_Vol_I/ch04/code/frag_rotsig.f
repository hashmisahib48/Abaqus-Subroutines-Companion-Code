!     Executable part of a finite-strain UMAT: the elastic strain kept
!     in STATEV(1:NTENS) is rotated with the incremental rotation DROT.
      DIMENSION EELAS(6)
!
      CALL ROTSIG(STATEV(1), DROT, EELAS, 2, NDI, NSHR)
      DO K = 1, NTENS
         STATEV(K) = EELAS(K)
      ENDDO
