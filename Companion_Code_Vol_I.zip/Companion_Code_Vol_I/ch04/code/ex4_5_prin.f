      SUBROUTINE K4_PRIN(S, NDI, NSHR, PS, AN)
!     Principal stresses sorted PS(1) >= PS(2) >= PS(3) and the
!     direction cosines of PS(K) in AN(K,1:3).  S is in Abaqus order.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(*), PS(3), AN(3,3), PT(3), ANT(3,3)
      INTEGER IDX(3)
!
      CALL SPRIND(S, PT, ANT, 1, NDI, NSHR)
      DO K = 1, 3
         IDX(K) = K
      ENDDO
      DO K = 1, 2
         DO L = K + 1, 3
            IF (PT(IDX(L)) .GT. PT(IDX(K))) THEN
               ITMP   = IDX(K)
               IDX(K) = IDX(L)
               IDX(L) = ITMP
            ENDIF
         ENDDO
      ENDDO
      DO K = 1, 3
         PS(K) = PT(IDX(K))
         DO J = 1, 3
            AN(K,J) = ANT(IDX(K),J)
         ENDDO
      ENDDO
      RETURN
      END
