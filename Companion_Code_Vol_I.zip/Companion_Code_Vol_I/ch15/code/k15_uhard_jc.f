      SUBROUTINE UHARD(SYIELD,HARD,EQPLAS,EQPLASRT,TIME,DTIME,TEMP,
     1 DTEMP,NOEL,NPT,LAYER,KSPT,KSTEP,KINC,CMNAME,NSTATV,
     2 STATEV,NUMFIELDV,PREDEF,DPRED,NUMPROPS,PROPS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION HARD(3),STATEV(NSTATV),TIME(*),PREDEF(NUMFIELDV),
     1 DPRED(*),PROPS(NUMPROPS)
!
!     Voce x rate factor x thermal softening, Eq. 15.3-1
!     PROPS(1:4) = SIG0, QINF, BV, HLIN   (MPa, MPa, -, MPa)
!     PROPS(5) = CJC    rate coefficient                (-)
!     PROPS(6) = EDOT0  reference plastic strain rate   (1/s)
!     PROPS(7) = TREF   reference temperature           (deg C)
!     PROPS(8) = TMELT  melting temperature             (deg C)
!     PROPS(9) = XM     thermal softening exponent      (-)
      SIG0 = PROPS(1)
      QINF = PROPS(2)
      BV   = PROPS(3)
      HLIN = PROPS(4)
      CJC  = PROPS(5)
      ED0  = PROPS(6)
      TREF = PROPS(7)
      TMEL = PROPS(8)
      XM   = PROPS(9)
!
      EX  = EXP(-BV*EQPLAS)
      SS  = SIG0 + QINF*(1.0D0 - EX) + HLIN*EQPLAS
      DSS = QINF*BV*EX + HLIN
!
      EDOT = MAX(EQPLASRT, 0.0D0)
      FR   = 1.0D0 + CJC*LOG(1.0D0 + EDOT/ED0)
      DFR  = CJC/(ED0 + EDOT)
!
      TS = MIN(MAX((TEMP - TREF)/(TMEL - TREF), 0.0D0), 1.0D0)
      FT = 1.0D0 - TS**XM
      DFT = 0.0D0
      IF (TS .GT. 0.0D0 .AND. TS .LT. 1.0D0)
     1   DFT = -XM*TS**(XM - 1.0D0)/(TMEL - TREF)
!
      SYIELD  = SS*FR*FT
      HARD(1) = DSS*FR*FT
      HARD(2) = SS*DFR*FT
      HARD(3) = SS*FR*DFT
!
      RETURN
      END
