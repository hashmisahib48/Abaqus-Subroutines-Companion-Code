!     Test driver for CREEP: scalar (uniaxial) integration the way the
!     solver uses the routine.  Input (stdin): CMNAME, MODE, N, LEXIMP
!     MODE 1: constant stress     MODE 2: relaxation     MODE 3: stress step
      PROGRAM K15CRP
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION DECRA(5), DESWA(5), STATEV(1), EC(2), ESW(2), PREDEF(1),
     1 DPRED(1), TIME(3), COORDS(3)
      CHARACTER*80 CMNAME
      PARAMETER (E = 2.1D5, TEND = 3.6D6, SIG1 = 100.0D0,
     1 SIGA = 80.0D0, SIGB = 120.0D0, TSTEP = 1.8D6)
      READ(*,*) CMNAME, MODE, N, LEXIMP
      DT = TEND/N
      EC1 = 0.0D0
      SIG = SIG1
      NITMAX = 0
      DO K = 1, N
         T0 = (K-1)*DT
         T1 = K*DT
         EC(1) = EC1
         EC(2) = EC1
         IF (MODE .EQ. 1 .OR. MODE .EQ. 3) THEN
            SIG = SIG1
            IF (MODE .EQ. 3) THEN
               SIG = SIGA
               IF (T0 .GE. TSTEP - 1.0D-6) SIG = SIGB
            END IF
            LEND = 1 - LEXIMP
            TIME(3) = T0
            IF (LEND .EQ. 1) TIME(3) = T1
            TIME(1) = TIME(3)
            TIME(2) = TIME(3)
            CALL CREEP(DECRA,DESWA,STATEV,SERD,EC,ESW,0.0D0,SIG,0.0D0,
     1       0.0D0,PREDEF,DPRED,TIME,DT,CMNAME,LEXIMP,LEND,COORDS,1,1,
     2       1,1,1,1,K)
            EC1 = EC1 + DECRA(1)
         ELSE
            STN = SIG
            IF (LEXIMP .EQ. 0) THEN
               TIME(3) = T0
               TIME(1) = T0
               TIME(2) = T0
               CALL CREEP(DECRA,DESWA,STATEV,SERD,EC,ESW,0.0D0,SIG,
     1          0.0D0,0.0D0,PREDEF,DPRED,TIME,DT,CMNAME,0,0,COORDS,1,1,
     2          1,1,1,1,K)
               SIG = MAX(SIG - E*DECRA(1), 1.0D-8)
               EC1 = EC1 + DECRA(1)
            ELSE
               TIME(3) = T1
               TIME(1) = T1
               TIME(2) = T1
               DO IT = 1, 50
                  CALL CREEP(DECRA,DESWA,STATEV,SERD,EC,ESW,0.0D0,SIG,
     1             0.0D0,0.0D0,PREDEF,DPRED,TIME,DT,CMNAME,1,1,COORDS,
     2             1,1,1,1,1,1,K)
                  G  = SIG - STN + E*DECRA(1)
                  IF (ABS(G) .LT. 1.0D-10) EXIT
                  SIG = SIG - G/(1.0D0 + E*DECRA(5))
               END DO
               NITMAX = MAX(NITMAX, IT)
               EC1 = EC1 + DECRA(1)
            END IF
         END IF
      END DO
      WRITE(*,'(A,3ES24.15,I4)') 'END', EC1, SIG, TEND, NITMAX
      END
