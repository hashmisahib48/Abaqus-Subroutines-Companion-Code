!     Free-expansion driver for UEXPAN: temperature history in NINC steps.
      PROGRAM K15EXP
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION EXPAN(1), DEXP(1), TEMP(2), TIME(2), PREDEF(1),
     1 DPRED(1), STATEV(1)
      CHARACTER*80 CMNAME
      READ(*,*) T0, T1, NINC
      CMNAME = 'DRV'
      ETH = 0.0D0
      TC = T0
      DO K = 1, NINC
         TN = T0 + (T1 - T0)*K/NINC
         TEMP(1) = TN
         TEMP(2) = TN - TC
         CALL UEXPAN(EXPAN,DEXP,TEMP,TIME,1.0D0,PREDEF,DPRED,STATEV,
     1    CMNAME,1,1)
         ETH = ETH + EXPAN(1)
         TC = TN
      END DO
      WRITE(*,'(A,2ES24.15)') 'ETH', ETH, DEXP(1)
      END
