!     Strain-driven test of UHARD (uniaxial stress, 1D radial return).
!     Input (stdin): NP, PROPS(1:NP) / E, TEMP, EDOT, DEPS, NINC, ISW
!     ISW = 0: Newton with HARD (consistent), ISW = 1: elastic slope only
      PROGRAM K15DRV
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NPMAX = 20)
      DIMENSION PROPS(NPMAX), HARD(3), STATEV(1), TIME(2), PREDEF(1),
     1 DPRED(1), HP(3), HM(3)
      CHARACTER*80 CMNAME
      READ(*,*) NP, (PROPS(K), K = 1, NP)
      READ(*,*) E, TEMP, EDOT, DEPS, NINC, ISW
      CMNAME = 'DRV'
      DT = DEPS/EDOT
      SIG = 0.0D0
      EPL = 0.0D0
      EPS = 0.0D0
      NITMAX = 0
      NITTOT = 0
      DO KINC = 1, NINC
         EPS = EPS + DEPS
         STR = SIG + E*DEPS
         DP = 0.0D0
         CALL UHARD(SY,HARD,EPL,0.0D0,TIME,DT,TEMP,0.0D0,1,1,1,1,1,
     1    KINC,CMNAME,1,STATEV,1,PREDEF,DPRED,NP,PROPS)
         IF (STR .GT. SY) THEN
            DO IT = 1, 60
               CALL UHARD(SY,HARD,EPL+DP,DP/DT,TIME,DT,TEMP,0.0D0,1,1,
     1          1,1,1,KINC,CMNAME,1,STATEV,1,PREDEF,DPRED,NP,PROPS)
               FF = STR - E*DP - SY
               IF (ABS(FF) .LT. 1.0D-10*PROPS(1)) EXIT
               DF = -E
               IF (ISW .EQ. 0) DF = -E - HARD(1) - HARD(2)/DT
               DP = DP - FF/DF
            END DO
            NIT = IT
            NITMAX = MAX(NITMAX, NIT)
            NITTOT = NITTOT + NIT
            EPL = EPL + DP
            SIG = STR - E*DP
         ELSE
            SIG = STR
         END IF
         WRITE(*,'(A,I5,3ES24.15)') 'PT', KINC, EPS, SIG, EPL
      END DO
      WRITE(*,'(A,2I6)') 'ITER', NITMAX, NITTOT
!     central finite-difference check of HARD at the end state
      EP0 = 0.01D0
      ER0 = 0.5D0
      T0  = 300.0D0
      CALL UHARD(SY,HARD,EP0,ER0,TIME,DT,T0,0.0D0,1,1,1,1,1,1,CMNAME,
     1 1,STATEV,1,PREDEF,DPRED,NP,PROPS)
      H = 1.0D-6
      CALL UHARD(SA,HP,EP0+H,ER0,TIME,DT,T0,0.0D0,1,1,1,1,1,1,CMNAME,
     1 1,STATEV,1,PREDEF,DPRED,NP,PROPS)
      CALL UHARD(SB,HM,EP0-H,ER0,TIME,DT,T0,0.0D0,1,1,1,1,1,1,CMNAME,
     1 1,STATEV,1,PREDEF,DPRED,NP,PROPS)
      FD1 = (SA - SB)/(2.0D0*H)
      CALL UHARD(SA,HP,EP0,ER0+H,TIME,DT,T0,0.0D0,1,1,1,1,1,1,CMNAME,
     1 1,STATEV,1,PREDEF,DPRED,NP,PROPS)
      CALL UHARD(SB,HM,EP0,ER0-H,TIME,DT,T0,0.0D0,1,1,1,1,1,1,CMNAME,
     1 1,STATEV,1,PREDEF,DPRED,NP,PROPS)
      FD2 = (SA - SB)/(2.0D0*H)
      CALL UHARD(SA,HP,EP0,ER0,TIME,DT,T0+1.0D-3,0.0D0,1,1,1,1,1,1,
     1 CMNAME,1,STATEV,1,PREDEF,DPRED,NP,PROPS)
      CALL UHARD(SB,HM,EP0,ER0,TIME,DT,T0-1.0D-3,0.0D0,1,1,1,1,1,1,
     1 CMNAME,1,STATEV,1,PREDEF,DPRED,NP,PROPS)
      FD3 = (SA - SB)/2.0D-3
      WRITE(*,'(A,6ES22.12)') 'FD', HARD(1), FD1, HARD(2), FD2,
     1 HARD(3), FD3
      END
