      SUBROUTINE CREEP(DECRA,DESWA,STATEV,SERD,EC,ESW,P,QTILD,
     1 TEMP,DTEMP,PREDEF,DPRED,TIME,DTIME,CMNAME,LEXIMP,LEND,
     2 COORDS,NSTATV,NOEL,NPT,LAYER,KSPT,KSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION DECRA(5),DESWA(5),STATEV(*),PREDEF(*),DPRED(*),
     1 TIME(3),COORDS(*),EC(2),ESW(2)
!
!     Norton-Bailey law, Eqs. 15.4-3, 15.4-4; MPa, s
!     A in MPa^-5 s^-0.5;  AN and AM dimensionless
      PARAMETER (A = 1.0D-16, AN = 5.0D0, AM = -0.5D0)
!
      DO K = 1, 5
         DECRA(K) = 0.0D0
         DESWA(K) = 0.0D0
      END DO
      IF (QTILD .LE. 0.0D0) RETURN
!
      CS = A*QTILD**AN
      IF (INDEX(CMNAME,'TIMEHARD') .GT. 0) THEN
!        time hardening: integrate the rate exactly over the increment
         T1 = TIME(3)
         IF (LEND .EQ. 0) T1 = TIME(3) + DTIME
         T0 = T1 - DTIME
         DECRA(1) = CS*(T1**(AM+1.0D0) - T0**(AM+1.0D0))/(AM+1.0D0)
         IF (LEXIMP .EQ. 1) DECRA(5) = AN*DECRA(1)/QTILD
      ELSE
!        strain hardening: advance u = EC**(1/(AM+1)) linearly in time
         PW = 1.0D0/(AM + 1.0D0)
         RK = (CS/(AM + 1.0D0))**PW
         U  = EC(1)**PW + RK*DTIME
         DECRA(1) = U**(AM + 1.0D0) - EC(1)
         IF (LEXIMP .EQ. 1) DECRA(5) = AN*RK*DTIME*U**AM/QTILD
      END IF
!
      RETURN
      END
