      SUBROUTINE UHARD(SYIELD,HARD,EQPLAS,EQPLASRT,TIME,DTIME,TEMP,
     1 DTEMP,NOEL,NPT,LAYER,KSPT,KSTEP,KINC,CMNAME,NSTATV,
     2 STATEV,NUMFIELDV,PREDEF,DPRED,NUMPROPS,PROPS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION HARD(3),STATEV(NSTATV),TIME(*),PREDEF(NUMFIELDV),
     1 DPRED(*),PROPS(NUMPROPS)
!
!     Voce hardening with a linear term, Eq. (15.2-5)
!     PROPS(1) = SIG0  initial yield stress           (MPa)
!     PROPS(2) = QINF  saturation increment of Voce   (MPa)
!     PROPS(3) = BV    Voce rate                      (-)
!     PROPS(4) = HLIN  linear hardening modulus       (MPa)
      SIG0 = PROPS(1)
      QINF = PROPS(2)
      BV   = PROPS(3)
      HLIN = PROPS(4)
      EX   = EXP(-BV*EQPLAS)
!
      SYIELD  = SIG0 + QINF*(1.0D0 - EX) + HLIN*EQPLAS
      HARD(1) = QINF*BV*EX + HLIN
      HARD(2) = 0.0D0
      HARD(3) = 0.0D0
!
      RETURN
      END
