      SUBROUTINE UEXPAN(EXPAN,DEXPANDT,TEMP,TIME,DTIME,PREDEF,
     1 DPRED,STATEV,CMNAME,NSTATV,NOEL)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION EXPAN(*),DEXPANDT(*),TEMP(2),TIME(2),PREDEF(*),
     1 DPRED(*),STATEV(NSTATV)
!
!     alpha(T) = AL0 + AL1*T, T in deg C (Eq. 15.5-2)
      PARAMETER (AL0 = 1.0D-5, AL1 = 8.0D-9)   ! 1/degC, 1/degC^2
!
      T1 = TEMP(1)                  ! end of increment
      T0 = TEMP(1) - TEMP(2)        ! start of increment
      EXPAN(1)    = AL0*(T1 - T0) + 0.5D0*AL1*(T1*T1 - T0*T0)
      DEXPANDT(1) = AL0 + AL1*T1
!
      RETURN
      END
