import subprocess, json, numpy as np
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
B='/tmp/k15b/'
def run(exe,inp):
    return subprocess.run([B+exe],input=inp,capture_output=True,text=True,check=True).stdout
R={}
# ---------- UHARD Voce ----------
E=210000.; s0,Q,b,H=250.,150.,20.,200.
sy=lambda p:s0+Q*(1-np.exp(-b*p))+H*p
def cf(eps): # closed form uniaxial: sigma=sy(p), eps=sigma/E+p
    if eps<=s0/E: return E*eps,0.
    p=brentq(lambda p:sy(p)+E*p-E*eps,0,eps); return sy(p),p
def voce(deps,n,isw):
    o=run('dvoce',f"4 {s0} {Q} {b} {H}\n{E} 20 1 {deps} {n} {isw}\n")
    pts=[tuple(map(float,l.split()[2:5])) for l in o.splitlines() if l.startswith('PT')]
    it=[l for l in o.splitlines() if l.startswith('ITER')][0].split()
    fd=list(map(float,[l for l in o.splitlines() if l.startswith('FD')][0].split()[1:]))
    return pts,int(it[1]),int(it[2]),fd
pts,im,it,fd=voce(0.001,20,0)
err=max(abs(s-cf(e)[0]) for e,s,p in pts); errp=max(abs(p-cf(e)[1]) for e,s,p in pts)
pts5,im5,it5,_=voce(0.005,4,0); pts5b,im5b,it5b,_=voce(0.005,4,1)
R['voce']=dict(sig2=pts[-1][1],ep2=pts[-1][2],cf2=cf(0.02)[0],cfp2=cf(0.02)[1],err=err,errp=errp,
  itmax=im,ittot=it,fd=fd,coarse=dict(sig=pts5[-1][1],cf=cf(0.02)[0],err=max(abs(s-cf(e)[0]) for e,s,p in pts5),
  itC=(im5,it5),itE=(im5b,it5b)),
  y0=sy(0.),h0=Q*b+H)
R['voce']['curve']=[(0,0)]+[(e,s) for e,s,p in pts]
# ---------- UHARD JC ----------
jp=[250.,150.,20.,0.,0.02,1e-3,20.,1500.,1.0]
def jc(rate,T,deps,n,ep=None):
    o=run('djc',f"9 "+" ".join(map(str,jp))+f"\n{E} {T} {rate} {deps} {n} 0\n")
    pts=[tuple(map(float,l.split()[2:5])) for l in o.splitlines() if l.startswith('PT')]
    fd=list(map(float,[l for l in o.splitlines() if l.startswith('FD')][0].split()[1:]))
    return pts,fd
def ss(rate,T):
    fr=1+0.02*np.log(1+rate/1e-3); ts=min(max((T-20)/(1500-20),0),1); return 400*fr*(1-ts)
R['jc']={'rows':[]}
for rate in (0.01,1.0,100.0):
    pts,fd=jc(rate,20.,0.005,200)
    R['jc']['rows'].append((rate,ss(rate,20),pts[-1][1]))
pts,fd=jc(1.0,400.,0.005,200); R['jc']['T400']=(ss(1,400),pts[-1][1])
R['jc']['fd']=fd
# ODE reference, T=20, rate 1
def ode(rate,T,eps_end):
    ts=min(max((T-20)/(1500-20),0),1); FT=1-ts
    def f(t,y):
        p=y[0]; sig=E*(rate*t-p); ss_=(250+150*(1-np.exp(-20*p)))*FT
        arg=(sig/ss_-1)/0.02
        return [1e-3*np.expm1(arg) if sig>ss_ else 0.]
    # start when yield reached
    t0=250./E/rate
    s=solve_ivp(f,[t0,eps_end/rate],[0.],rtol=1e-12,atol=1e-14,dense_output=True)
    p=s.y[0,-1]; return E*(eps_end-p),p
R['jc']['ode']={}
for deps,n in ((0.005,10),(0.0005,100),(0.00005,1000)):
    pts,_=jc(1.0,20.,deps,n); sref,pref=ode(1.0,20.,0.05)
    R['jc']['ode'][str(deps)]=(pts[-1][1],sref)
R['jc']['curve']={}
for rate in (0.01,1.0,100.0):
    pts,_=jc(rate,20.,0.005,60); R['jc']['curve'][str(rate)]=[(0,0)]+[(e,s) for e,s,p in pts]
# ---------- CREEP ----------
A,n_,m=1e-16,5.,-0.5; Tend=3.6e6
def crp(name,mode,N,lx):
    o=run('dcrp',f"'{name}' {mode} {N} {lx}\n")
    l=[x for x in o.splitlines() if x.startswith('END')][0].split()
    return float(l[1]),float(l[2]),int(l[4])
cs=lambda s:A*s**n_
R['crp']={}
c1=A*100.**n_*Tend**(m+1)/(m+1)
R['crp']['const']=dict(cf=c1,vals={nm:crp(nm,1,10,1)[0] for nm in ('TIMEHARD','STRNHARD')},vals0={nm:crp(nm,1,10,0)[0] for nm in ('TIMEHARD','STRNHARD')},
   cf_sig=1e2,t=Tend)
# naive scheme mirror (rate at end of increment * dt), constant stress
def naive(N):
    dt=Tend/N; ec=0
    for k in range(1,N+1): ec+=A*100.**n_*(k*dt)**m*dt
    return ec
R['crp']['naive']={N:(naive(N)-c1)/c1 for N in (5,10,20,40,80)}
# relaxation
s0r=100.
def relax_cf(t): return (s0r**(1-n_)+(n_-1)*E*A*t**(m+1)/(m+1))**(-1/(n_-1))
sT=relax_cf(Tend)
def relax_strain_ref():
    pw=1/(m+1)
    def f(t,y):
        u=y[0]; sig=max(s0r-E*u**(m+1),1e-12) # eps_cr=u^(m+1), sigma=s0-E*eps
        return [(A*sig**n_/(m+1))**pw]
    s=solve_ivp(f,[0,Tend],[0.],rtol=1e-12,atol=1e-30); u=s.y[0,-1]; return s0r-E*u**(m+1)
sTs=relax_strain_ref()
R['crp']['relax']=dict(cf=sT,cfS=sTs,tab=[])
for N in (5,10,20,40,80,160):
    _,se,_=crp('TIMEHARD',2,N,0); _,si,ni=crp('TIMEHARD',2,N,1); _,ss_,ns=crp('STRNHARD',2,N,1)
    R['crp']['relax']['tab'].append((N,se,si,ss_,ni))
# curves for the figure
tt=np.linspace(0,Tend,200)[1:]
R['crp']['relax']['curve']=[(t/3600.,relax_cf(t)) for t in tt]
# step test
def step_cf(kind,t=Tend,t1=1.8e6):
    a1,a2=cs(80.),cs(120.)
    if kind=='T': return a1*t1**(m+1)/(m+1)+a2*(t**(m+1)-t1**(m+1))/(m+1)
    pw=1/(m+1); return ((a1/(m+1))**pw*t1+(a2/(m+1))**pw*(t-t1))**(m+1)
R['crp']['step']=dict(cfT=step_cf('T'),cfS=step_cf('S'),T=crp('TIMEHARD',3,40,1)[0],S=crp('STRNHARD',3,40,1)[0],
  Te=crp('TIMEHARD',3,40,0)[0],Se=crp('STRNHARD',3,40,0)[0])
tt=np.linspace(0,Tend,121)
R['crp']['step']['curve']=[(t/3600.,step_cf('T',t) if t>=1.8e6 else cs(80.)*t**(m+1)/(m+1),
   step_cf('S',t) if t>=1.8e6 else cs(80.)*t**(m+1)/(m+1)) for t in tt]
# ---------- UEXPAN ----------
al0,al1=1e-5,8e-9
eth=lambda T0,T1:al0*(T1-T0)+al1/2*(T1**2-T0**2)
R['exp']=dict(cf=eth(20,600),n1=float(run('dexp','20 600 1\n').split()[1]),n10=float(run('dexp','20 600 10\n').split()[1]),
  alpha600=al0+al1*600, sec=(al0+al1*600/2*0+al1*(600+20)/2)*580, constr=-E*eth(20,600),L=500*eth(20,600),
  cf2=eth(600,20))
# secant alpha at 600 relative to Tref=20 : eth/(T-Tref)
R['exp']['secant']=eth(20,600)/580.
R['exp']['mid']=al0+al1*(20+600)/2
json.dump(R,open('/home/claude/book/ch15/out/results.json','w'),indent=1)
print(json.dumps({k:R[k] for k in ('voce','jc')},indent=0)[:3500]); print(json.dumps(R['crp'],indent=0)[:3500]); print(R['exp'])
