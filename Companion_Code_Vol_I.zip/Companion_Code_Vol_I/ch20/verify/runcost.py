import subprocess,json,statistics as st,collections
cfg={'O0':'dc_O0','O1':'dc_O1','O2':'dc_O2','O3':'dc_O3','O2 -fcheck=all':'dc_O2fcheckall'}
res={}
for k,exe in cfg.items():
    d=collections.defaultdict(list)
    for rep in range(5):
        for l in subprocess.check_output(['/tmp/'+exe],text=True).splitlines():
            if l.startswith('#'): continue
            n,v=l.split(); d[n].append(float(v))
    res[k]={n:[min(v),st.median(v),max(v)] for n,v in d.items()}
json.dump(res,open('out/cost.json','w'),indent=1)
for k,v in res.items():
    print(k); [print('  %-16s %8.1f %8.1f %8.1f'%(n,*x)) for n,x in v.items()]
