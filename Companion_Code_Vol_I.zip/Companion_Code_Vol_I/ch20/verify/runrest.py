import subprocess,json,collections
def runs(exe,n):
    d=collections.defaultdict(list)
    for _ in range(n):
        for l in subprocess.check_output([exe],text=True).splitlines():
            if l.startswith('#'): continue
            if l.startswith('nb'):
                p=l.split(); d['A%s'%p[1]].append(float(p[2])); d['B%s'%p[1]].append(float(p[3]))
            else:
                k=l.rsplit(None,1); d[k[0].strip()].append(float(k[1]))
    return {k:[min(v),max(v)] for k,v in d.items()}
out={'prim':runs('/tmp/dp',5),'vec2':runs('/tmp/dv-O2',7),'vec3':runs('/tmp/dv-O3',7)}
json.dump(out,open('out/rest.json','w'),indent=1)
print(json.dumps(out))
