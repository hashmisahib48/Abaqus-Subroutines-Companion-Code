      PROGRAM DRVVEC
!     Time per point of a block update for several block lengths NB.
      IMPLICIT REAL*8 (A-H,O-Z)
      INTEGER*8 IC0, IC1, IR, NTOT
      PARAMETER (MAXB = 65536)
      DOUBLE PRECISION, ALLOCATABLE :: S(:,:), D(:,:), VM(:), S2(:,:)
      INTEGER NBS(7)
      DATA NBS /8, 32, 128, 512, 2048, 8192, 65536/
      ALLOCATE(S(MAXB,6), S2(MAXB,6), D(MAXB,6), VM(MAXB))
      NTOT = 40000000_8
      DO J = 1, 6
         DO K = 1, MAXB
            S(K,J) = 0.D0
            S2(K,J) = 0.D0
            D(K,J) = 1.D-9*(1+MOD(K+J,5))
         ENDDO
      ENDDO
      DO IB = 1, 7
         NB = NBS(IB)
         NREP = INT(NTOT/NB)
         S(:NB,:) = 0.D0
         S2(:NB,:) = 0.D0
         CALL SYSTEM_CLOCK(IC0, IR)
         DO IREP = 1, NREP
            CALL K20_VECA(NB, 210000.D0, 0.3D0, S, D, VM)
         ENDDO
         CALL SYSTEM_CLOCK(IC1)
         TA = DBLE(IC1-IC0)/DBLE(IR)/(NREP*DBLE(NB))*1.D9
         CALL SYSTEM_CLOCK(IC0)
         DO IREP = 1, NREP
            CALL K20_VECB(NB, 210000.D0, 0.3D0, S2, D, VM)
         ENDDO
         CALL SYSTEM_CLOCK(IC1)
         TB = DBLE(IC1-IC0)/DBLE(IR)/(NREP*DBLE(NB))*1.D9
         WRITE(*,'(A,I6,2F9.2)') 'nb', NB, TA, TB
      ENDDO
      WRITE(*,'(A,ES12.4,ES12.4)') '#agree', MAXVAL(ABS(S(:65536,1)
     1   -S2(:65536,1))), S(1,1)
      END
