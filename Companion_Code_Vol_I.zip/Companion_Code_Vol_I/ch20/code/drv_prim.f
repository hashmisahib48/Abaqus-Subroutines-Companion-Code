      PROGRAM DRVPRIM
!     Throughput of single operations on independent data
!     (compile with -O2 -fno-tree-vectorize: one operation per
!     result, as in a point routine).
      IMPLICIT REAL*8 (A-H,O-Z)
      INTEGER*8 IC0, IC1, IR
      PARAMETER (M = 1024, NREP = 40000)
      DOUBLE PRECISION K20_ALLTEST
      DIMENSION X(M), Y(M), Z(M)
      INTEGER NEXP
      NEXP = 3
      DO I = 1, M
         X(I) = 0.5D0 + I*1.D-3
         Y(I) = 1.5D0 + MOD(I,17)*0.01D0
      ENDDO
      CALL SYSTEM_CLOCK(IC0, IR)
      DO IR2 = 1, NREP
         DO I = 1, M
            Z(I) = X(I)
         ENDDO
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      T0 = DBLE(IC1-IC0)/DBLE(IR)
      WRITE(*,'(A,F8.2)') 'copy_only ', T0/(NREP*DBLE(M))*1.D9
      CALL TIMEIT('mult_add', 1, X, Y, Z, M, NREP, T0, NEXP)
      CALL TIMEIT('divide', 2, X, Y, Z, M, NREP, T0, NEXP)
      CALL TIMEIT('sqrt', 3, X, Y, Z, M, NREP, T0, NEXP)
      CALL TIMEIT('exp', 4, X, Y, Z, M, NREP, T0, NEXP)
      CALL TIMEIT('log', 5, X, Y, Z, M, NREP, T0, NEXP)
      CALL TIMEIT('x**y real', 6, X, Y, Z, M, NREP, T0, NEXP)
      CALL TIMEIT('x**3 const', 7, X, Y, Z, M, NREP, T0, NEXP)
      CALL TIMEIT('x**n var', 8, X, Y, Z, M, NREP, T0, NEXP)
      CALL TIMEIT('sin', 9, X, Y, Z, M, NREP, T0, NEXP)
!     allocate and deallocate 36 reals in a called routine
      CALL SYSTEM_CLOCK(IC0)
      S = 0.D0
      DO IR2 = 1, NREP*M/8
         S = S + K20_ALLTEST(36, IR2)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F8.2)') 'allocate36 ',
     1  DBLE(IC1-IC0)/DBLE(IR)/(NREP*M/8)*1.D9
      WRITE(*,'(A,ES10.3)') '#S ', S
      END
      SUBROUTINE TIMEIT(NAME, K, X, Y, Z, M, NREP, T0, NEXP)
      IMPLICIT REAL*8 (A-H,O-Z)
      INTEGER*8 IC0, IC1, IR
      CHARACTER*(*) NAME
      DIMENSION X(M), Y(M), Z(M)
      CALL SYSTEM_CLOCK(IC0, IR)
      DO IR2 = 1, NREP
         IF (K .EQ. 1) THEN
            DO I = 1, M
               Z(I) = X(I)*Y(I) + 0.3D0
            ENDDO
         ELSE IF (K .EQ. 2) THEN
            DO I = 1, M
               Z(I) = X(I)/Y(I)
            ENDDO
         ELSE IF (K .EQ. 3) THEN
            DO I = 1, M
               Z(I) = SQRT(X(I))
            ENDDO
         ELSE IF (K .EQ. 4) THEN
            DO I = 1, M
               Z(I) = EXP(X(I))
            ENDDO
         ELSE IF (K .EQ. 5) THEN
            DO I = 1, M
               Z(I) = LOG(X(I))
            ENDDO
         ELSE IF (K .EQ. 6) THEN
            DO I = 1, M
               Z(I) = X(I)**Y(I)
            ENDDO
         ELSE IF (K .EQ. 7) THEN
            DO I = 1, M
               Z(I) = X(I)**3
            ENDDO
         ELSE IF (K .EQ. 8) THEN
            DO I = 1, M
               Z(I) = X(I)**NEXP
            ENDDO
         ELSE
            DO I = 1, M
               Z(I) = SIN(X(I))
            ENDDO
         ENDIF
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F8.2)') NAME, (DBLE(IC1-IC0)/DBLE(IR) - T0)/
     1   (NREP*DBLE(M))*1.D9
      IF (Z(7) .LT. -1.D30) WRITE(*,*) Z(7)
      END
      DOUBLE PRECISION FUNCTION K20_ALLTEST(N, J)
      INTEGER N, J
      DOUBLE PRECISION, ALLOCATABLE :: W(:)
      ALLOCATE(W(N))
      W(1) = J
      W(N) = 2.D0*J
      K20_ALLTEST = W(1) + W(N)
      DEALLOCATE(W)
      END
