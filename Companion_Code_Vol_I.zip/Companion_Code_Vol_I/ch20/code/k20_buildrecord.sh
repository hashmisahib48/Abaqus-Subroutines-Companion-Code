#!/bin/sh
# usage: k20_buildrecord.sh job.inp sub.f [more files]
OUT=build_record.txt
{
echo "date      $(date -u +%Y-%m-%dT%H:%MZ)"
echo "host      $(uname -sr) $(uname -m)"
if command -v abaqus >/dev/null 2>&1; then
  echo "abaqus    $(abaqus information=version 2>&1 | head -n 3 | tr '\n' ' ')"
else echo "abaqus    (not found on this machine)"; fi
for C in ifx ifort gfortran; do
  command -v $C >/dev/null 2>&1 || continue
  echo "compiler  $($C --version 2>&1 | head -n 1)"; break
done
echo "git       $(git describe --always --dirty 2>/dev/null || echo none)"
sha256sum "$@"
} | tee $OUT
