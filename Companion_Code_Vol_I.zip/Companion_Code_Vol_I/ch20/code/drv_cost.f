      PROGRAM DRVCOST
!     Cost per call of the Chapter 20 variants (Example 20.4-1).
!     Every call starts from the same stored state, so that elastic
!     and plastic branches are timed separately.
      IMPLICIT REAL*8 (A-H,O-Z)
      INTEGER*8 N, I8, IC0, IC1, IR
      DIMENSION S0(6), DEL(6), DPL(6), ST(6), DS(6), DD(6,6), DD2(6,6)
      DIMENSION PROPS(4), COORDS(3), DROT(3,3), DFG(3,3), JSTEP(4)
      DIMENSION STRAN(6), DDT(6), DRPLDE(6), PREDEF(1), DPRED(1)
      DIMENSION TIME(2), STATEV(1)
      CHARACTER*80 CMNAME
      PROPS = (/210000.D0, 0.3D0, 250.D0, 1000.D0/)
      S0 = (/100.D0, 20.D0, -30.D0, 40.D0, 5.D0, -10.D0/)
      DEL = (/1.D-6, -2.D-7, 3.D-7, 1.D-6, 0.D0, 0.D0/)
      DPL = (/3.D-3, -1.D-3, 5.D-4, 2.D-3, -1.D-3, 1.D-3/)
      POW = 2.0D0
      N = 4000000_8
      CHK = 0.D0
!     --- agreement of the variants
      ST = S0
      PE = 0.D0
      CALL K20_UPDATE(PROPS(1),PROPS(2),PROPS(3),PROPS(4),ST,DPL,PE,DD)
      DS = S0
      PE2 = 0.D0
      CALL K20_NAIVE(PROPS(1),PROPS(2),PROPS(3),PROPS(4),DS,DPL,PE2,
     1               DD2,POW)
      WRITE(*,'(A,ES9.2,A,ES9.2)') '#agree stress', MAXVAL(ABS(ST-DS)),
     1    ' tangent', MAXVAL(ABS(DD-DD2))
      GOTO 10
 10   CONTINUE
!     --- baseline: state reset only
      CALL SYSTEM_CLOCK(IC0, IR)
      DO I8 = 1, N
         ST = S0
         ST(1) = ST(1) + 1.D-12*MOD(I8,7_8)
         CHK = CHK + ST(1)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      TB = DBLE(IC1-IC0)/DBLE(IR)/N*1.D9
      WRITE(*,'(A,F9.2)') 'reset_only ', TB
!
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         ST = S0
         PE = 0.D0
         DS = DEL
         DS(1) = DS(1) + 1.D-12*MOD(I8,7_8)
         CALL K20_UPDATE(PROPS(1),PROPS(2),PROPS(3),PROPS(4),ST,DS,PE,
     1                   DD)
         CHK = CHK + ST(1) + DD(1,1)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'update_elastic ',
     1    DBLE(IC1-IC0)/DBLE(IR)/N*1.D9 - TB
!
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         ST = S0
         PE = 0.D0
         DS = DPL
         DS(1) = DS(1) + 1.D-12*MOD(I8,7_8)
         CALL K20_UPDATE(PROPS(1),PROPS(2),PROPS(3),PROPS(4),ST,DS,PE,
     1                   DD)
         CHK = CHK + ST(1) + DD(1,1)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'update_plastic ',
     1    DBLE(IC1-IC0)/DBLE(IR)/N*1.D9 - TB
!
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         ST = S0
         PE = 0.D0
         DS = DEL
         DS(1) = DS(1) + 1.D-12*MOD(I8,7_8)
         CALL K20_NAIVE(PROPS(1),PROPS(2),PROPS(3),PROPS(4),ST,DS,PE,
     1                  DD,POW)
         CHK = CHK + ST(1) + DD(1,1)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'naive_elastic ',
     1    DBLE(IC1-IC0)/DBLE(IR)/N*1.D9 - TB
!
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         ST = S0
         PE = 0.D0
         DS = DPL
         DS(1) = DS(1) + 1.D-12*MOD(I8,7_8)
         CALL K20_NAIVE(PROPS(1),PROPS(2),PROPS(3),PROPS(4),ST,DS,PE,
     1                  DD,POW)
         CHK = CHK + ST(1) + DD(1,1)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'naive_plastic ',
     1    DBLE(IC1-IC0)/DBLE(IR)/N*1.D9 - TB
!
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         ST = S0
         PE = 0.D0
         DS = DPL
         DS(1) = DS(1) + 1.D-12*MOD(I8,7_8)
         CALL K20_ALLOC(PROPS(1),PROPS(2),PROPS(3),PROPS(4),ST,DS,PE,
     1                  DD)
         CHK = CHK + ST(1) + DD(1,1)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'alloc_plastic ',
     1    DBLE(IC1-IC0)/DBLE(IR)/N*1.D9 - TB
!
!     validator alone, every call / once
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         PROPS(1) = 210000.D0 + MOD(I8,3_8)
         CALL K20_CHKPR(PROPS, 4, 1, 3, 3)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'chkpr_every ', DBLE(IC1-IC0)/DBLE(IR)/N*1.D9
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         PROPS(1) = 210000.D0 + MOD(I8,3_8)
         CALL K20_CHKONCE(PROPS, 4, 1, 3, 3)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'chkpr_once ', DBLE(IC1-IC0)/DBLE(IR)/N*1.D9
!     guarded diagnostic
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         CALL K20_DIAG(7, 3, ST)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'diag_guard ', DBLE(IC1-IC0)/DBLE(IR)/N*1.D9
!     full UMAT wrapper, plastic
      PROPS(1) = 210000.D0
      JSTEP = 0
      CALL SYSTEM_CLOCK(IC0)
      DO I8 = 1, N
         ST = S0
         STATEV(1) = 0.D0
         DS = DPL
         DS(1) = DS(1) + 1.D-12*MOD(I8,7_8)
         CALL UMAT(ST,STATEV,DD,SSE,SPD,SCD,RPL,DDT,DRPLDE,DRPLDT,
     1     STRAN,DS,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,3,3,6,1,
     2     PROPS,4,COORDS,DROT,PNEWDT,CELENT,DFG,DFG,1,1,1,1,JSTEP,1)
         CHK = CHK + ST(1) + DD(1,1)
      ENDDO
      CALL SYSTEM_CLOCK(IC1)
      WRITE(*,'(A,F9.2)') 'umat_plastic ',
     1    DBLE(IC1-IC0)/DBLE(IR)/N*1.D9 - TB
      WRITE(*,'(A,ES12.4)') '#checksum ', CHK
      END
