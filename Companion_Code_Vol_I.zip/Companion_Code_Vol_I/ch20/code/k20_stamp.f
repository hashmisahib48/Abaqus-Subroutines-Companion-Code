      SUBROUTINE UEXTERNALDB(LOP,LRESTART,TIME,DTIME,KSTEP,KINC)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2)
      CHARACTER*40 VERS
      PARAMETER (VERS = 'k20_umat 1.0 (J2 test vehicle)')
!     Version stamp: once per analysis, to the .dat (unit 6) and
!     .msg (unit 7) files, so that every result carries its source.
      IF (LOP .EQ. 0) THEN
         WRITE(6,'(2A)') ' USER SUBROUTINE BUILD: ', VERS
         WRITE(7,'(2A)') ' USER SUBROUTINE BUILD: ', VERS
      ENDIF
      RETURN
      END
