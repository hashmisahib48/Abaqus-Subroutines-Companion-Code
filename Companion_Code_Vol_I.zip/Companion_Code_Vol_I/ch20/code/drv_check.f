      PROGRAM DRVCHK
!     Checks of k20_umat.f outside Abaqus: (1) pure shear against the
!     closed form, (2) finite-difference test of the tangent, and
!     (3) the validator on faulty constants.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION STRESS(6), DSTRAN(6), DDSDDE(6,6), D2(6,6), SP(6),
     1          SM(6), DS2(6), STRES0(6), PR(4), DUM(6,6)
      PARAMETER (E = 210000.D0, XNU = 0.3D0, SY0 = 250.D0,
     1           HM = 1000.D0)
      G = E/(2.D0*(1.D0+XNU))
!     ---- (1) shear: gamma from 0 to 0.01 in 20 equal increments
      STRESS = 0.D0
      PEEQ = 0.D0
      DO N = 1, 20
         DSTRAN = 0.D0
         DSTRAN(4) = 0.01D0/20.D0
         CALL K20_UPDATE(E, XNU, SY0, HM, STRESS, DSTRAN, PEEQ, DDSDDE)
      ENDDO
      GAM = 0.01D0
      TEX = (SY0 + HM*(DSQRT(3.D0)*G*GAM - SY0)/(3.D0*G+HM))
     1      /DSQRT(3.D0)
      WRITE(*,'(A,F10.4,A,F10.4,A,ES9.2)') ' shear tau  code',
     1   STRESS(4), '  closed form', TEX, '  diff', STRESS(4)-TEX
      WRITE(*,'(A,ES12.5,A,ES12.5)') ' peeq code', PEEQ,
     1   '  closed form', (DSQRT(3.D0)*G*GAM-SY0)/(3.D0*G+HM)
      WRITE(*,'(A,6F10.4)') ' other stresses (must be 0):',
     1   STRESS(1), STRESS(2), STRESS(3), STRESS(5), STRESS(6)
!     ---- (2) tangent by central differences, elastic and plastic
      DO ICASE = 1, 2
         STRESS = 0.D0
         PEEQ = 0.D0
         DSTRAN = 0.D0
         IF (ICASE .EQ. 1) THEN
            DS2 = (/1.D-4, -2.D-5, 3.D-5, 4.D-5, -1.D-5, 2.D-5/)
         ELSE
            DSTRAN = (/3.D-3, -1.D-3, 5.D-4, 2.D-3, -1.D-3, 1.D-3/)
            CALL K20_UPDATE(E,XNU,SY0,HM,STRESS,DSTRAN,PEEQ,DUM)
            DS2 = (/2.D-3, 1.D-3, -5.D-4, 1.D-3, 5.D-4, -1.D-3/)
         ENDIF
         STRES0 = STRESS
         PEEQ0 = PEEQ
         CALL K20_UPDATE(E,XNU,SY0,HM,STRESS,DS2,PEEQ,DDSDDE)
         H = 1.D-8
         ERRMAX = 0.D0
         DO J = 1, 6
            SP = STRES0
            PP = PEEQ0
            DSTRAN = DS2
            DSTRAN(J) = DSTRAN(J) + H
            CALL K20_UPDATE(E,XNU,SY0,HM,SP,DSTRAN,PP,DUM)
            SM = STRES0
            PP = PEEQ0
            DSTRAN = DS2
            DSTRAN(J) = DSTRAN(J) - H
            CALL K20_UPDATE(E,XNU,SY0,HM,SM,DSTRAN,PP,DUM)
            DO I = 1, 6
               ERRMAX = MAX(ERRMAX, ABS((SP(I)-SM(I))/(2.D0*H)
     1                  - DDSDDE(I,J)))
            ENDDO
         ENDDO
         WRITE(*,'(A,I2,A,F9.5,A,ES9.2,A)') ' tangent case', ICASE,
     1     '  peeq', PEEQ, '  max |C_fd - C| =', ERRMAX,
     2     '  (MPa, ||C|| ~ 3E5)'
      ENDDO
!     ---- (3) validator on faulty constants
      WRITE(*,*)
      DO K = 0, 7
         PR = (/E, XNU, SY0, HM/)
         NPR = 4
         NDI = 3
         IF (K .EQ. 1) PR(1) = 2.1D11
         IF (K .EQ. 2) PR(2) = 0.5D0
         IF (K .EQ. 3) PR(1) = 210.D0
         IF (K .EQ. 4) PR(3) = -250.D0
         IF (K .EQ. 5) PR(4) = -1000.D0
         IF (K .EQ. 6) NPR = 3
         IF (K .EQ. 7) NDI = 2
         WRITE(*,'(A,I2,A,4ES10.3,A,I2,A,I2)') ' case', K, ' PROPS',
     1      PR, '  NPROPS', NPR, '  NDI', NDI
         CALL K20_CHKPR(PR, NPR, 1, NDI, 3)
      ENDDO
      END
