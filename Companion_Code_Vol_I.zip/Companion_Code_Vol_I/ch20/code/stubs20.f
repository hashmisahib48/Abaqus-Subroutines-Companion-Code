!     Test replacement for STDB_ABQERR: prints the message with the
!     %I and %R fields filled in and does NOT stop (lets a driver
!     exercise every check).  Not the Abaqus message format.
      SUBROUTINE STDB_ABQERR(LOP,STRING,INTV,REALV,CHARV)
      CHARACTER*(*) STRING
      CHARACTER*8 CHARV(*)
      DOUBLE PRECISION REALV(*)
      INTEGER INTV(*)
      CHARACTER*200 OUT
      CHARACTER*20 TMP
      INTEGER NI, NR, K, L
      NI = 0
      NR = 0
      OUT = ' '
      L = 1
      K = 1
      DO WHILE (K .LE. LEN_TRIM(STRING))
         IF (STRING(K:K) .EQ. '%' .AND. K .LT. LEN_TRIM(STRING)) THEN
            IF (STRING(K+1:K+1) .EQ. 'I') THEN
               NI = NI + 1
               WRITE(TMP,'(I0)') INTV(NI)
            ELSE
               NR = NR + 1
               WRITE(TMP,'(1PG11.4)') REALV(NR)
            ENDIF
            TMP = ADJUSTL(TMP)
            OUT(L:L+LEN_TRIM(TMP)-1) = TRIM(TMP)
            L = L + LEN_TRIM(TMP)
            K = K + 2
         ELSE
            OUT(L:L) = STRING(K:K)
            L = L + 1
            K = K + 1
         ENDIF
      ENDDO
      WRITE(*,'(A,I3,2A)') '   STDB_ABQERR(', LOP, ') ', OUT(1:L-1)
      END
      SUBROUTINE XIT
      STOP
      END
