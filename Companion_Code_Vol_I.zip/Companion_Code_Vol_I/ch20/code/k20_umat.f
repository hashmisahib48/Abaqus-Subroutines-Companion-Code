      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!=====================================================================
! UMAT   J2 plasticity, linear isotropic hardening (test vehicle)
! File   k20_umat.f      Version 1.0      Author  M. H. Hashmi
! Abaqus 2024 / Standard      Units  N, mm, MPa, tonne, s
! Tested outside Abaqus with ch20/code/drv_check.f (gfortran 13)
!---------------------------------------------------------------------
! *USER MATERIAL, CONSTANTS=4
!   PROPS(1) = E     Young modulus          MPa
!   PROPS(2) = XNU   Poisson ratio          -        (-1 < XNU < 0.5)
!   PROPS(3) = SY0   initial yield stress   MPa
!   PROPS(4) = HMOD  hardening modulus      MPa      (dSigma/dPEEQ)
! *DEPVAR, 1
!   STATEV(1) = PEEQ  equivalent plastic strain   -
! Elements: 3D (NDI = 3, NSHR = 3) only; other classes stop the job.
!=====================================================================
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),
     1 DDSDDE(NTENS,NTENS),DDSDDT(NTENS),DRPLDE(NTENS),
     2 STRAN(NTENS),DSTRAN(NTENS),TIME(2),PREDEF(1),DPRED(1),
     3 PROPS(NPROPS),COORDS(3),DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),
     4 JSTEP(4)
!
      CALL K20_CHKPR(PROPS, NPROPS, NSTATV, NDI, NSHR)
      CALL K20_UPDATE(PROPS(1), PROPS(2), PROPS(3), PROPS(4),
     1                STRESS, DSTRAN, STATEV(1), DDSDDE)
      RETURN
      END
!
!     Validation of the constants and of the element class.
!     Called at every point; costs a few comparisons (Example 20.3-1).
      SUBROUTINE K20_CHKPR(PROPS, NPROPS, NSTATV, NDI, NSHR)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*), INTV(2), REALV(3)
      CHARACTER*8 CHARV(1)
      PARAMETER (EMIN = 1.0D0, EMAX = 1.0D7,       ! MPa
     1           YSMIN = 1.0D-6, YSMAX = 0.1D0)    ! SY0/E (-)
      IF (NPROPS .NE. 4 .OR. NSTATV .LT. 1) THEN
         INTV(1) = NPROPS
         INTV(2) = NSTATV
         CALL STDB_ABQERR(-3, 'K20: need CONSTANTS=4, DEPVAR>=1; '//
     1      'found NPROPS=%I, NSTATV=%I', INTV, REALV, CHARV)
      ENDIF
      IF (NDI .NE. 3 .OR. NSHR .NE. 3) THEN
         INTV(1) = NDI
         INTV(2) = NSHR
         CALL STDB_ABQERR(-3, 'K20: 3D elements only; NDI=%I, '//
     1      'NSHR=%I', INTV, REALV, CHARV)
      ENDIF
      E = PROPS(1)
      IF (.NOT. (E .GE. EMIN .AND. E .LE. EMAX)) THEN
         REALV(1) = E
         CALL STDB_ABQERR(-3, 'K20: E = %R MPa outside 1 ... 1E7; '//
     1      'check the unit system', INTV, REALV, CHARV)
      ENDIF
      IF (.NOT. (PROPS(2) .GT. -1.0D0 .AND. PROPS(2) .LT. 0.5D0)) THEN
         REALV(1) = PROPS(2)
         CALL STDB_ABQERR(-3, 'K20: Poisson ratio %R outside '//
     1      '(-1, 0.5)', INTV, REALV, CHARV)
      ENDIF
      RATIO = PROPS(3)/E
      IF (.NOT. (RATIO .GE. YSMIN .AND. RATIO .LE. YSMAX)) THEN
         REALV(1) = PROPS(3)
         REALV(2) = RATIO
         CALL STDB_ABQERR(-3, 'K20: SY0 = %R MPa, SY0/E = %R is '//
     1      'implausible; check units', INTV, REALV, CHARV)
      ENDIF
      IF (.NOT. (PROPS(4) .GE. 0.0D0)) THEN
         REALV(1) = PROPS(4)
         CALL STDB_ABQERR(-3, 'K20: hardening modulus %R < 0',
     1      INTV, REALV, CHARV)
      ENDIF
      RETURN
      END
!
!     Kernel: closed-form radial return and consistent tangent.
!     No Abaqus arguments, so a driver can call it directly.
!     STRESS (6) on entry: start of increment; on exit: end.
!     Order 11,22,33,12,13,23; DSTRAN holds engineering shear strain.
      SUBROUTINE K20_UPDATE(E, XNU, SY0, HMOD, STRESS, DSTRAN,
     1                      PEEQ, DDSDDE)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(6), DSTRAN(6), DDSDDE(6,6), S(6), XN(6)
      PARAMETER (ZERO = 0.0D0, ONE = 1.0D0, TWO = 2.0D0,
     1           THREE = 3.0D0)
      G    = E/(TWO*(ONE + XNU))                       ! MPa
      XK   = E/(THREE*(ONE - TWO*XNU))                 ! MPa
      XLAM = XK - TWO*G/THREE                          ! MPa
      TRE  = DSTRAN(1) + DSTRAN(2) + DSTRAN(3)
      DO I = 1, 3
         STRESS(I)   = STRESS(I)   + XLAM*TRE + TWO*G*DSTRAN(I)
         STRESS(I+3) = STRESS(I+3) + G*DSTRAN(I+3)
      ENDDO
      P = (STRESS(1) + STRESS(2) + STRESS(3))/THREE
      S(1) = STRESS(1) - P
      S(2) = STRESS(2) - P
      S(3) = STRESS(3) - P
      S(4) = STRESS(4)
      S(5) = STRESS(5)
      S(6) = STRESS(6)
      SN2 = S(1)**2 + S(2)**2 + S(3)**2
     1    + TWO*(S(4)**2 + S(5)**2 + S(6)**2)          ! s:s, MPa^2
      Q = SQRT(1.5D0*SN2)                              ! Mises, MPa
      F = Q - (SY0 + HMOD*PEEQ)
      THETA = ONE
      THBAR = ZERO
      IF (F .GT. ZERO) THEN
         DP    = F/(THREE*G + HMOD)
         THETA = ONE - THREE*G*DP/Q
         THBAR = ONE/(ONE + HMOD/(THREE*G)) - (ONE - THETA)
         SNORM = SQRT(SN2)
         DO I = 1, 6
            XN(I) = S(I)/SNORM
            S(I)  = THETA*S(I)
         ENDDO
         PEEQ = PEEQ + DP
         DO I = 1, 3
            STRESS(I) = P + S(I)
         ENDDO
         DO I = 4, 6
            STRESS(I) = S(I)
         ENDDO
      ELSE
         DO I = 1, 6
            XN(I) = ZERO
         ENDDO
      ENDIF
      DO J = 1, 6
         DO I = 1, 6
            DDSDDE(I,J) = -TWO*G*THBAR*XN(I)*XN(J)
         ENDDO
      ENDDO
      DO J = 1, 3
         DO I = 1, 3
            DDSDDE(I,J) = DDSDDE(I,J) + XK - TWO*G*THETA/THREE
         ENDDO
         DDSDDE(J,J)     = DDSDDE(J,J) + TWO*G*THETA
         DDSDDE(J+3,J+3) = DDSDDE(J+3,J+3) + G*THETA
      ENDDO
      RETURN
      END
