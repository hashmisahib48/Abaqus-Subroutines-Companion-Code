!     Variants of the K20_UPDATE kernel used only to measure cost
!     (Example 20.4-1).  All give the same stress as K20_UPDATE.
!
!     (a) "first draft": constants rebuilt in every tangent entry,
!         squares written as a real power with a variable exponent
      DOUBLE PRECISION FUNCTION K20_G(E, XNU)
      DOUBLE PRECISION E, XNU
      K20_G = E/(2.0D0*(1.0D0 + XNU))
      END
      DOUBLE PRECISION FUNCTION K20_CEL(I, J, E, XNU)
      DOUBLE PRECISION E, XNU, G, XLAM
      INTEGER I, J
      G    = E/(2.0D0*(1.0D0 + XNU))
      XLAM = E*XNU/((1.0D0 + XNU)*(1.0D0 - 2.0D0*XNU))
      K20_CEL = 0.0D0
      IF (I .LE. 3 .AND. J .LE. 3) THEN
         K20_CEL = XLAM
         IF (I .EQ. J) K20_CEL = XLAM + 2.0D0*G
      ELSE IF (I .EQ. J) THEN
         K20_CEL = G
      ENDIF
      END
      SUBROUTINE K20_NAIVE(E, XNU, SY0, HMOD, STRESS, DSTRAN,
     1                     PEEQ, DDSDDE, POW)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION STRESS(6), DSTRAN(6), DDSDDE(6,6), S(6), XN(6)
      DOUBLE PRECISION K20_G, K20_CEL
      DO J = 1, 6
         DO I = 1, 6
            DDSDDE(I,J) = K20_CEL(I, J, E, XNU)
         ENDDO
      ENDDO
      DO I = 1, 6
         DO J = 1, 6
            STRESS(I) = STRESS(I) + DDSDDE(I,J)*DSTRAN(J)
         ENDDO
      ENDDO
      P = (STRESS(1) + STRESS(2) + STRESS(3))/3.0D0
      SN2 = 0.0D0
      DO I = 1, 6
         S(I) = STRESS(I)
         IF (I .LE. 3) S(I) = S(I) - P
         IF (I .LE. 3) THEN
            SN2 = SN2 + ABS(S(I))**POW
         ELSE
            SN2 = SN2 + 2.0D0*ABS(S(I))**POW
         ENDIF
      ENDDO
      Q = (1.5D0*SN2)**(POW/4.0D0)
      F = Q - (SY0 + HMOD*PEEQ)
      THETA = 1.0D0
      THBAR = 0.0D0
      DO I = 1, 6
         XN(I) = 0.0D0
      ENDDO
      IF (F .GT. 0.0D0) THEN
         DP    = F/(3.0D0*K20_G(E,XNU) + HMOD)
         THETA = 1.0D0 - 3.0D0*K20_G(E,XNU)*DP/Q
         THBAR = 1.0D0/(1.0D0 + HMOD/(3.0D0*K20_G(E,XNU)))
     1           - (1.0D0 - THETA)
         DO I = 1, 6
            XN(I) = S(I)/SQRT(SN2)
            S(I)  = THETA*S(I)
         ENDDO
         PEEQ = PEEQ + DP
         DO I = 1, 3
            STRESS(I) = P + S(I)
         ENDDO
         DO I = 4, 6
            STRESS(I) = S(I)
         ENDDO
         DO J = 1, 6
            DO I = 1, 6
               DDSDDE(I,J) = -2.0D0*K20_G(E,XNU)*THBAR*XN(I)*XN(J)
     1           + THETA*K20_CEL(I,J,E,XNU)
     2           + (1.0D0 - THETA)*(E/(3.0D0*(1.0D0-2.0D0*XNU)))*
     3             MERGE(1.0D0, 0.0D0, I.LE.3 .AND. J.LE.3)
            ENDDO
         ENDDO
      ENDIF
      END
!
!     (b) the kernel with a work array allocated at every call
      SUBROUTINE K20_ALLOC(E, XNU, SY0, HMOD, STRESS, DSTRAN,
     1                     PEEQ, DDSDDE)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION STRESS(6), DSTRAN(6), DDSDDE(6,6)
      DOUBLE PRECISION, ALLOCATABLE :: WD(:,:)
      ALLOCATE(WD(6,6))
      CALL K20_UPDATE(E, XNU, SY0, HMOD, STRESS, DSTRAN, PEEQ, WD)
      DDSDDE = WD
      DEALLOCATE(WD)
      END
!
!     (c) validation once, with a SAVEd flag (benign race, see 20.5)
      SUBROUTINE K20_CHKONCE(PROPS, NPROPS, NSTATV, NDI, NSHR)
      DIMENSION PROPS(*)
      LOGICAL DONE
      SAVE DONE
      DATA DONE /.FALSE./
      IF (.NOT. DONE) THEN
         CALL K20_CHKPR(PROPS, NPROPS, NSTATV, NDI, NSHR)
         DONE = .TRUE.
      ENDIF
      END
!
!     (d) a guarded diagnostic whose condition is false
      SUBROUTINE K20_DIAG(NOEL, KINC, STRESS)
      DIMENSION STRESS(6)
      IF (KINC .EQ. 1 .AND. NOEL .EQ. 1) THEN
         WRITE(7,'(6ES14.5)') (STRESS(I), I=1,6)
      ENDIF
      END
