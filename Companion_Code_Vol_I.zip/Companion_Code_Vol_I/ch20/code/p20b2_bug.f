      SUBROUTINE K20_PB(PROPS, NPROPS, STRESS, DSTRAN, STATEV, NSTATV,
     1                  NOEL)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(NPROPS), STRESS(6), DSTRAN(6), STATEV(NSTATV)
      LOGICAL FIRST
      SAVE FIRST, G, XLAM
      DATA FIRST /.TRUE./
!     elastic update; *USER MATERIAL, CONSTANTS=4; *DEPVAR, 1
      IF (FIRST) THEN
         E   = PROPS(1)*1000.0
         XNU = PROPS(2)
         G    = E/(2.0*(1.0 + XNU))
         XLAM = E*XNU/((1.0 + XNU)*(1.0 - 2.0*XNU))
         FIRST = .FALSE.
      ENDIF
      WRITE(6,*) 'NOEL', NOEL, (STRESS(I), I=1,6)
      TRE = DSTRAN(1) + DSTRAN(2) + DSTRAN(3)
      DO I = 1, 3
         STRESS(I)   = STRESS(I) + XLAM*TRE + 2.0D0*G*DSTRAN(I)
         STRESS(I+3) = STRESS(I+3) + G*DSTRAN(I+3)
      ENDDO
      STATEV(2) = STRESS(1)
      IF (PROPS(5) .GT. 0.0D0) STATEV(1) = PROPS(5)*TRE
      RETURN
      END
