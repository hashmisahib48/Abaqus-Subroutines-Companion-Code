      SUBROUTINE K20_VECA(NB, E, XNU, STRESS, DSTRAN, VM)
!     Block update, inner loops over the points of the block
!     (unit stride in the Abaqus/Explicit layout STRESS(NB,6)).
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION STRESS(NB,6), DSTRAN(NB,6), VM(NB)
      G    = E/(2.0D0*(1.0D0 + XNU))
      XLAM = E*XNU/((1.0D0 + XNU)*(1.0D0 - 2.0D0*XNU))
      DO K = 1, NB
         TRE = DSTRAN(K,1) + DSTRAN(K,2) + DSTRAN(K,3)
         STRESS(K,1) = STRESS(K,1) + XLAM*TRE + 2.0D0*G*DSTRAN(K,1)
         STRESS(K,2) = STRESS(K,2) + XLAM*TRE + 2.0D0*G*DSTRAN(K,2)
         STRESS(K,3) = STRESS(K,3) + XLAM*TRE + 2.0D0*G*DSTRAN(K,3)
      ENDDO
      DO J = 4, 6
         DO K = 1, NB
            STRESS(K,J) = STRESS(K,J) + G*DSTRAN(K,J)
         ENDDO
      ENDDO
      DO K = 1, NB
         P = (STRESS(K,1) + STRESS(K,2) + STRESS(K,3))/3.0D0
         VM(K) = SQRT(1.5D0*((STRESS(K,1)-P)**2 + (STRESS(K,2)-P)**2
     1     + (STRESS(K,3)-P)**2 + 2.0D0*(STRESS(K,4)**2
     2     + STRESS(K,5)**2 + STRESS(K,6)**2)))
      ENDDO
      END
!
      SUBROUTINE K20_VECB(NB, E, XNU, STRESS, DSTRAN, VM)
!     The same arithmetic with the point as the outer loop and a
!     short inner loop over the six components (stride NB).
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION STRESS(NB,6), DSTRAN(NB,6), VM(NB), S(6)
      G    = E/(2.0D0*(1.0D0 + XNU))
      XLAM = E*XNU/((1.0D0 + XNU)*(1.0D0 - 2.0D0*XNU))
      DO K = 1, NB
         TRE = DSTRAN(K,1) + DSTRAN(K,2) + DSTRAN(K,3)
         DO J = 1, 3
            STRESS(K,J) = STRESS(K,J) + XLAM*TRE + 2.0D0*G*DSTRAN(K,J)
            STRESS(K,J+3) = STRESS(K,J+3) + G*DSTRAN(K,J+3)
         ENDDO
         DO J = 1, 6
            S(J) = STRESS(K,J)
         ENDDO
         P = (S(1) + S(2) + S(3))/3.0D0
         VM(K) = SQRT(1.5D0*((S(1)-P)**2 + (S(2)-P)**2 + (S(3)-P)**2
     1     + 2.0D0*(S(4)**2 + S(5)**2 + S(6)**2)))
      ENDDO
      END
