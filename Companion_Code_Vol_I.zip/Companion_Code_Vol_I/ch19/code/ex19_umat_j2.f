      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),DDSDDE(NTENS,NTENS),
     1 DDSDDT(NTENS),DRPLDE(NTENS),STRAN(NTENS),DSTRAN(NTENS),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3),
     3 DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),JSTEP(4)
!
!     J2 plasticity, linear isotropic hardening, radial return.
!     PROPS: 1 E (MPa)  2 NU (-)  3 SY0 (MPa)  4 H (MPa)
!     STATEV: 1 equivalent plastic strain; 2..NTENS+1 plastic strain
!             (engineering shear).  Self-contained test routine of
!             Chapter 19; the algorithm is that of Chapter 13.
!
      DIMENSION STRIAL(6), S(6), DEP(6), SOLD(6)
      PARAMETER (TOL = 1.0D-10)
!
      E   = PROPS(1)
      XNU = PROPS(2)
      SY0 = PROPS(3)
      HH  = PROPS(4)
      XMU = E/(2.0D0*(1.0D0 + XNU))
      XK  = E/(3.0D0*(1.0D0 - 2.0D0*XNU))
      EPBAR = STATEV(1)
      SY = SY0 + HH*EPBAR
!
!     elastic stiffness and trial stress
      CALL K19_ELAS(DDSDDE, NDI, NTENS, XK, XMU)
      DO I = 1, NTENS
         SOLD(I) = STRESS(I)
         STRIAL(I) = STRESS(I)
         DO J = 1, NTENS
            STRIAL(I) = STRIAL(I) + DDSDDE(I,J)*DSTRAN(J)
         ENDDO
      ENDDO
      CALL K19_DEV(STRIAL, NTENS, P, S, Q, SN2)
      DP = 0.0D0
      DEP = 0.0D0
      IF (Q .LE. SY*(1.0D0 + TOL)) THEN
         DO I = 1, NTENS
            STRESS(I) = STRIAL(I)
         ENDDO
      ELSE
         DP = (Q - SY)/(3.0D0*XMU + HH)
         THETA = 1.0D0 - 3.0D0*XMU*DP/Q
         DO I = 1, NTENS
            STRESS(I) = THETA*S(I)
            DEP(I) = 1.5D0*DP*S(I)/Q
         ENDDO
         DO I = 1, NDI
            STRESS(I) = STRESS(I) + P
         ENDDO
         DO I = NDI+1, NTENS
            DEP(I) = 2.0D0*DEP(I)
         ENDDO
         CALL K19_TAN(DDSDDE, S, SN2, DP, Q, XMU, HH, NDI, NTENS)
      ENDIF
!
!     state variables and energies (SPD: trapezoidal in the stress)
      STATEV(1) = EPBAR + DP
      DO I = 1, NTENS
         STATEV(1+I) = STATEV(1+I) + DEP(I)
         SPD = SPD + 0.5D0*(SOLD(I) + STRESS(I))*DEP(I)
      ENDDO
      CALL K19_DEV(STRESS, NTENS, P, S, Q, SN2)
      SSE = P*P/(2.0D0*XK) + SN2/(4.0D0*XMU)
      RETURN
      END
!
      SUBROUTINE K19_ELAS(D, NDI, NTENS, XK, XMU)
!     Isotropic elastic matrix from bulk modulus XK and shear
!     modulus XMU (MPa), engineering shear strains
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(NTENS,NTENS)
      D = 0.0D0
      DO J = 1, NDI
         DO I = 1, NDI
            D(I,J) = XK - 2.0D0*XMU/3.0D0
         ENDDO
         D(J,J) = D(J,J) + 2.0D0*XMU
      ENDDO
      DO K = NDI+1, NTENS
         D(K,K) = XMU
      ENDDO
      RETURN
      END
!
      SUBROUTINE K19_DEV(SIG, NTENS, P, S, Q, SN2)
!     Mean stress P, deviator S, S:S (SN2) and von Mises stress Q
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION SIG(NTENS), S(NTENS)
      P = (SIG(1) + SIG(2) + SIG(3))/3.0D0
      DO I = 1, 3
         S(I) = SIG(I) - P
      ENDDO
      SN2 = S(1)**2 + S(2)**2 + S(3)**2
      DO I = 4, NTENS
         S(I) = SIG(I)
         SN2 = SN2 + 2.0D0*S(I)**2
      ENDDO
      Q = SQRT(1.5D0*SN2)
      RETURN
      END
!
      SUBROUTINE K19_TAN(D, S, SN2, DP, Q, XMU, HH, NDI, NTENS)
!     Consistent tangent of the radial return with linear hardening
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(NTENS,NTENS), S(NTENS), XN(6)
      THETA = 1.0D0 - 3.0D0*XMU*DP/Q
      THBAR = 3.0D0*XMU/(3.0D0*XMU + HH) - (1.0D0 - THETA)
      XK = D(1,2) + 2.0D0*XMU/3.0D0
      DO I = 1, NTENS
         XN(I) = S(I)/SQRT(SN2)
      ENDDO
      D = 0.0D0
      DO J = 1, NDI
         DO I = 1, NDI
            D(I,J) = XK - 2.0D0*THETA*XMU/3.0D0
         ENDDO
         D(J,J) = D(J,J) + 2.0D0*THETA*XMU
      ENDDO
      DO K = NDI+1, NTENS
         D(K,K) = THETA*XMU
      ENDDO
      DO J = 1, NTENS
         DO I = 1, NTENS
            D(I,J) = D(I,J) - 2.0D0*XMU*THBAR*XN(I)*XN(J)
         ENDDO
      ENDDO
      RETURN
      END
