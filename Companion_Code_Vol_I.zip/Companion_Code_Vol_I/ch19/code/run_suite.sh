#!/bin/sh
# Regression suite: two optimisation levels, run-time checks on, and
# a comparison of the PASS/FAIL pattern with the stored pattern.
INC=/home/claude/book/lib/aba
for OPT in -O0 -O2; do
  gfortran -ffixed-form -std=legacy -I$INC $OPT -fcheck=all \
     -ffpe-trap=invalid,zero,overflow -finit-real=snan \
     ex19_drv.f ex19_umat_j2.f $INC/stubs.f -o suite$OPT || exit 9
  ./suite$OPT | grep -E '^T[0-9]+ (PASS|FAIL)' | cut -c1-8 > got$OPT.txt
  diff -q golden.txt got$OPT.txt || exit 1
done
echo SUITE OK
