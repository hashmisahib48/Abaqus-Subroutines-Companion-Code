      PROGRAM K19DRV
!     Verification driver for the J2 UMAT of ex19_umat_j2.f (Chapter 19).
!     Fourteen tests; the program ends with STOP 1 if any fails.
!     Optional command-line argument: factor that multiplies every
!     tolerance (default 1).  Units: N, mm, MPa.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E0 = 210000.0D0, XNU0 = 0.3D0, SY00 = 250.0D0,
     1           HH0 = 1000.0D0)
      COMMON /K19P/ PROPS(4), TOLFAC
      COMMON /K19R/ ERRMAX(20), NCHK(20), NFAIL(20)
      DIMENSION S(6), SV(7), D(6,6), DS(6), PATH(6,40), SREF(6)
      DIMENSION EPREF(6), S1(6), SV1(7), D1(6,6)
      CHARACTER*32 ARG
!
      PROPS(1) = E0
      PROPS(2) = XNU0
      PROPS(3) = SY00
      PROPS(4) = HH0
      TOLFAC = 1.0D0
      CALL GET_COMMAND_ARGUMENT(1, ARG)
      IF (LEN_TRIM(ARG) .GT. 0) READ(ARG,*) TOLFAC
      ERRMAX = 0.0D0
      NCHK = 0
      NFAIL = 0
      XMU = E0/(2.0D0*(1.0D0 + XNU0))
      XK = E0/(3.0D0*(1.0D0 - 2.0D0*XNU0))
      XLAM = XK - 2.0D0*XMU/3.0D0
      SSE = 0.0D0
      SPD = 0.0D0
      CALL K19_READ(PATH, SREF, PREF, EPREF)
!
!     T01  elastic uniaxial strain and T02 elastic shear
      CALL K19_ZERO(S, SV)
      SPD = 0.0D0
      DS = 0.0D0
      DS(1) = 1.0D-3
      CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      CALL K19_CHK(1, 'T01 s11 = (lam+2mu) e', S(1), (XLAM+2*XMU)*1D-3,
     1             S(1), 1.0D-12)
      CALL K19_CHK(1, 'T01 s22 = lam e      ', S(2), XLAM*1D-3,
     1             S(1), 1.0D-12)
      CALL K19_ZERO(S, SV)
      SPD = 0.0D0
      DS = 0.0D0
      DS(4) = 1.0D-3
      CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      CALL K19_CHK(2, 'T02 s12 = G gamma    ', S(4), XMU*1D-3,
     1             S(4), 1.0D-12)
!
!     T03  hydrostatic compression to e_v = -0.03: no yielding
      CALL K19_ZERO(S, SV)
      SPD = 0.0D0
      DS = 0.0D0
      DS(1) = -1.0D-2
      DS(2) = -1.0D-2
      DS(3) = -1.0D-2
      CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      CALL K19_CHK(3, 'T03 s11 = K e_v      ', S(1), -XK*3.0D-2,
     1             S(1), 1.0D-12)
      CALL K19_CHK(3, 'T03 PEEQ = 0         ', SV(1), 0.0D0,
     1             1.0D0, 1.0D-14)
!
!     T04  uniaxial stress to 2 percent in one increment
      EPS = 2.0D-2
      PX = (EPS - SY00/E0)/(1.0D0 + HH0/E0)
      SX = SY00 + HH0*PX
      CALL K19_UNI(1, EPS, S, SV, D, E22)
      CALL K19_CHK(4, 'T04 s11 (MPa)        ', S(1), SX, SX, 1.0D-9)
      CALL K19_CHK(4, 'T04 PEEQ             ', SV(1), PX, PX, 1.0D-9)
      CALL K19_CHK(4, 'T04 e22              ', E22,
     1             -XNU0*SX/E0 - 0.5D0*PX, E22, 1.0D-9)
!
!     T05  the same strain in 20 and in 200 increments
      CALL K19_UNI(20, EPS, S, SV, D, E22)
      CALL K19_CHK(5, 'T05 s11, 20 incr.    ', S(1), SX, SX, 1.0D-9)
      CALL K19_UNI(200, EPS, S, SV, D, E22)
      CALL K19_CHK(5, 'T05 s11, 200 incr.   ', S(1), SX, SX, 1.0D-9)
      CALL K19_CHK(5, 'T05 PEEQ, 200 incr.  ', SV(1), PX, PX, 1.0D-9)
!
!     T06  simple shear to gamma = 0.05 in 10 increments
      CALL K19_ZERO(S, SV)
      DO K = 1, 10
         DS = 0.0D0
         DS(4) = 5.0D-3
         CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      ENDDO
      TY = SY00/SQRT(3.0D0)
      GY = TY/XMU
      TREF = TY + (5.0D-2 - GY)*XMU*HH0/(3.0D0*XMU + HH0)
      CALL K19_CHK(6, 'T06 s12 (MPa)        ', S(4), TREF, TREF, 1.0D-9)
      CALL K19_CHK(6, 'T06 PEEQ             ', SV(1),
     1             (SQRT(3.0D0)*TREF - SY00)/HH0,
     2             (SQRT(3.0D0)*TREF - SY00)/HH0, 1.0D-9)
      CALL K19_CHK(6, 'T06 s11, s22, s33    ',
     1   MAX(ABS(S(1)),ABS(S(2)),ABS(S(3))), 0.0D0, TREF, 1.0D-12)
!
!     T07  unloading, elastic reversal, reverse yielding
      CALL K19_UNI(1, EPS, S, SV, D, E22)
      CALL K19_CALL1(S, SV, D, -SX/E0, E22)
      CALL K19_CHK(7, 'T07 s11 after unload ', S(1), 0.0D0, SX, 1.0D-9)
      CALL K19_CHK(7, 'T07 plastic e11      ', SV(2), PX, PX, 1.0D-9)
      CALL K19_UNI(1, EPS, S, SV, D, E22)
      CALL K19_CALL1(S, SV, D, -2.0D0*SX/E0, E22)
      CALL K19_CHK(7, 'T07 s11 at reversal  ', S(1), -SX, SX, 1.0D-9)
      CALL K19_CHK(7, 'T07 PEEQ unchanged   ', SV(1), PX, PX, 1.0D-9)
      CALL K19_CALL1(S, SV, D, -1.0D-3, E22)
      ET = E0*HH0/(E0 + HH0)
      CALL K19_CHK(7, 'T07 s11 reverse yld  ', S(1), -SX - ET*1D-3, SX,
     1             1.0D-9)
      CALL K19_CHK(7, 'T07 PEEQ reverse yld ', SV(1),
     1             PX + 1D-3*E0/(E0 + HH0), PX, 1.0D-9)
!
!     T08  energy balance over the 40-increment path
      CALL K19_ZERO(S, SV)
      SPD = 0.0D0
      W = 0.0D0
      DO K = 1, 40
         S1 = S
         DS = PATH(:,K)
         CALL K19_CALL(DS, S, SV, D, SSE, SPD)
         DO I = 1, 6
            W = W + 0.5D0*(S1(I) + S(I))*DS(I)
         ENDDO
      ENDDO
      CALL K19_CHK(8, 'T08 SSE+SPD = work   ', SSE + SPD, W, W, 1.0D-12)
!
!     T14  independent tensor-form implementation (Python)
      CALL K19_ZERO(S, SV)
      SPD = 0.0D0
      DO K = 1, 40
         DS = PATH(:,K)
         CALL K19_CALL(DS, S, SV, D, SSE, SPD)
         IF (K .EQ. 20) THEN
            S1 = S
            SV1 = SV
         ENDIF
      ENDDO
      SMAX = MAXVAL(ABS(SREF))
      DO I = 1, 6
         CALL K19_CHK(14, 'T14 stress component ', S(I), SREF(I), SMAX,
     1                1.0D-9)
         CALL K19_CHK(14, 'T14 plastic strain  ', SV(1+I), EPREF(I),
     1                MAXVAL(ABS(EPREF)), 1.0D-9)
      ENDDO
      CALL K19_CHK(14, 'T14 PEEQ            ', SV(1), PREF, PREF,
     1             1.0D-9)
!
!     T09  symmetry of DDSDDE (elastic and plastic states)
      DS = PATH(:,21)
      CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      ASYM = 0.0D0
      DO J = 1, 6
         DO I = 1, 6
            ASYM = MAX(ASYM, ABS(D(I,J) - D(J,I)))
         ENDDO
      ENDDO
      CALL K19_CHK(9, 'T09 max |D - D^T|    ', ASYM, 0.0D0,
     1             MAXVAL(ABS(D)), 1.0D-12)
!
!     T10  consistent tangent against central differences, from the
!          state after 20 increments, increment 21 of the path
      S = S1
      SV = SV1
      DS = PATH(:,21)
      CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      DMAX = MAXVAL(ABS(D))
      ERRFD = 0.0D0
      HFD = 1.0D-7
      DO J = 1, 6
         DO I = 1, 6
            S = S1
            SV = SV1
            DS = PATH(:,21)
            DS(J) = DS(J) + HFD
            CALL K19_CALL(DS, S, SV, D1, SSE, SPD)
            SP = S(I)
            S = S1
            SV = SV1
            DS = PATH(:,21)
            DS(J) = DS(J) - HFD
            CALL K19_CALL(DS, S, SV, D1, SSE, SPD)
            ERRFD = MAX(ERRFD, ABS((SP - S(I))/(2.0D0*HFD) - D(I,J)))
         ENDDO
      ENDDO
      CALL K19_CHK(10, 'T10 FD tangent error ', ERRFD, 0.0D0, DMAX,
     1             1.0D-6)
!
!     T11  frame invariance of the 20-increment path
      CALL K19_FRAME(PATH, S1, SV1)
!
!     T12  one huge increment: uniaxial strain e11 = 1
      CALL K19_ZERO(S, SV)
      SPD = 0.0D0
      DS = 0.0D0
      DS(1) = 1.0D0
      CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      Q = ABS(S(1) - S(2))
      CALL K19_CHK(12, 'T12 q = SY0 + H p   ', Q, SY00 + HH0*SV(1),
     1             Q, 1.0D-9)
      CALL K19_CHK(12, 'T12 tr(plastic) = 0 ', SV(2)+SV(3)+SV(4), 0.0D0,
     1             1.0D0, 1.0D-12)
!
!     T13  zero increment from the plastic state of the path
      S = S1
      SV = SV1
      DS = 0.0D0
      CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      DO I = 1, 6
         CALL K19_CHK(13, 'T13 stress unchanged', S(I), S1(I),
     1                MAXVAL(ABS(S1)), 1.0D-12)
      ENDDO
      CALL K19_CHK(13, 'T13 PEEQ unchanged  ', SV(1), SV1(1), SV1(1),
     1             1.0D-12)
      CALL K19_CHK(13, 'T13 D(1,1) elastic  ', D(1,1), XLAM+2*XMU,
     1             D(1,1), 1.0D-12)
!
!     summary
      NF = 0
      WRITE(*,'(A)') 'SUMMARY'
      DO K = 1, 14
         IF (NCHK(K) .GT. 0) THEN
            IF (NFAIL(K) .GT. 0) THEN
               WRITE(*,'(A,I2.2,A,ES10.2)') 'T', K, ' FAIL  maxerr=',
     1                                       ERRMAX(K)
               NF = NF + 1
            ELSE
               WRITE(*,'(A,I2.2,A,ES10.2)') 'T', K, ' PASS  maxerr=',
     1                                       ERRMAX(K)
            ENDIF
         ENDIF
      ENDDO
      WRITE(*,'(A,I3)') 'FAILED TESTS ', NF
      IF (NF .GT. 0) STOP 1
      END
!
      SUBROUTINE K19_ZERO(S, SV)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(6), SV(7)
      S = 0.0D0
      SV = 0.0D0
      RETURN
      END
!
      SUBROUTINE K19_CALL(DS, S, SV, D, SSE, SPD)
!     One call of the UMAT as Abaqus makes it (3-D, NTENS = 6)
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K19P/ PROPS(4), TOLFAC
      DIMENSION DS(6), S(6), SV(7), D(6,6)
      DIMENSION DDSDDT(6), DRPLDE(6), STRAN(6), TIME(2), PREDEF(1),
     1 DPRED(1), COORDS(3), DROT(3,3), DFGRD0(3,3), DFGRD1(3,3),
     2 JSTEP(4)
      CHARACTER*80 CMNAME
      CMNAME = 'STEEL'
      STRAN = 0.0D0
      TIME = 0.0D0
      PREDEF = 0.0D0
      DPRED = 0.0D0
      COORDS = 0.0D0
      DROT = 0.0D0
      DFGRD0 = 0.0D0
      DFGRD1 = 0.0D0
      DO I = 1, 3
         DROT(I,I) = 1.0D0
         DFGRD0(I,I) = 1.0D0
         DFGRD1(I,I) = 1.0D0
      ENDDO
      JSTEP = 1
      D = 1.0D10
      PNEWDT = 1.0D0
      CALL UMAT(S, SV, D, SSE, SPD, SCD, RPL, DDSDDT, DRPLDE, DRPLDT,
     1 STRAN, DS, TIME, 1.0D0, 20.0D0, 0.0D0, PREDEF, DPRED, CMNAME,
     2 3, 3, 6, 7, PROPS, 4, COORDS, DROT, PNEWDT, 1.0D0, DFGRD0,
     3 DFGRD1, 1, 1, 1, 1, JSTEP, 1)
      RETURN
      END
!
      SUBROUTINE K19_UNI(N, EPS, S, SV, D, E22)
!     Uniaxial stress: e11 = EPS in N equal increments from the zero
!     state; the lateral strain (e22 = e33) is found by Newton's
!     method on s22 = 0.  E22 returns the total lateral strain.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(6), SV(7), D(6,6), DS(6), S0(6), SV0(7)
      CALL K19_ZERO(S, SV)
      SSE = 0.0D0
      SPD = 0.0D0
      E22 = 0.0D0
      DO K = 1, N
         S0 = S
         SV0 = SV
         DL = 0.0D0
         DO IT = 1, 30
            S = S0
            SV = SV0
            DS = 0.0D0
            DS(1) = EPS/N
            DS(2) = DL
            DS(3) = DL
            CALL K19_CALL(DS, S, SV, D, SSE, SPD)
            IF (ABS(S(2)) .LE. 1.0D-11) GOTO 10
            DL = DL - S(2)/(D(2,2) + D(2,3))
         ENDDO
   10    CONTINUE
         E22 = E22 + DL
      ENDDO
      RETURN
      END
!
      SUBROUTINE K19_CALL1(S, SV, D, DE11, E22)
!     One further uniaxial-stress increment DE11 from state (S, SV)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(6), SV(7), D(6,6), DS(6), S0(6), SV0(7)
      SSE = 0.0D0
      SPD = 0.0D0
      S0 = S
      SV0 = SV
      DL = 0.0D0
      DO IT = 1, 30
         S = S0
         SV = SV0
         DS = 0.0D0
         DS(1) = DE11
         DS(2) = DL
         DS(3) = DL
         CALL K19_CALL(DS, S, SV, D, SSE, SPD)
         IF (ABS(S(2)) .LE. 1.0D-11) GOTO 10
         DL = DL - S(2)/(D(2,2) + D(2,3))
      ENDDO
   10 E22 = E22 + DL
      RETURN
      END
!
      SUBROUTINE K19_CHK(ID, NAME, GOT, REF, SCL, RTOL)
!     Pass if |GOT - REF| <= RTOL*TOLFAC*SCL.  A NaN fails.
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K19P/ PROPS(4), TOLFAC
      COMMON /K19R/ ERRMAX(20), NCHK(20), NFAIL(20)
      CHARACTER*(*) NAME
      SC = ABS(SCL)
      IF (.NOT. (SC .GT. 0.0D0)) SC = 1.0D0
      ERR = ABS(GOT - REF)/SC
      NCHK(ID) = NCHK(ID) + 1
      IF (.NOT. (ERR .LE. RTOL*TOLFAC)) NFAIL(ID) = NFAIL(ID) + 1
      IF (ERR .GT. ERRMAX(ID) .OR. ERR .NE. ERR) ERRMAX(ID) = ERR
      WRITE(*,'(A,2ES20.12,ES10.2)') NAME, GOT, REF, ERR
      RETURN
      END
!
      SUBROUTINE K19_READ(PATH, SREF, PREF, EPREF)
!     Reads the path and the independent reference of ref_path.txt
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PATH(6,40), SREF(6), EPREF(6)
      OPEN(UNIT=11, FILE='ref_path.txt', STATUS='OLD')
      DO K = 1, 40
         READ(11,*) (PATH(I,K), I = 1, 6)
      ENDDO
      READ(11,*) SREF
      READ(11,*) PREF
      READ(11,*) EPREF
      CLOSE(11)
      RETURN
      END
!
      SUBROUTINE K19_FRAME(PATH, S1, SV1)
!     Frame invariance: the path rotated by Q gives the stress
!     rotated by Q.  S1 holds the stress after 20 increments.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PATH(6,40), S1(6), SV1(7)
      DIMENSION Q(3,3), T(3,3), TR(3,3), DS(6), S(6), SV(7), D(6,6)
      DIMENSION SR(6), A(3,3), AX(3)
      AX(1) = 1.0D0/SQRT(14.0D0)
      AX(2) = 2.0D0/SQRT(14.0D0)
      AX(3) = 3.0D0/SQRT(14.0D0)
      ANG = 0.7D0
      A = 0.0D0
      A(1,2) = -AX(3)
      A(1,3) = AX(2)
      A(2,1) = AX(3)
      A(2,3) = -AX(1)
      A(3,1) = -AX(2)
      A(3,2) = AX(1)
      Q = SIN(ANG)*A + (1.0D0 - COS(ANG))*MATMUL(A, A)
      DO I = 1, 3
         Q(I,I) = Q(I,I) + 1.0D0
      ENDDO
      CALL K19_ZERO(S, SV)
      SSE = 0.0D0
      SPD = 0.0D0
      DO K = 1, 20
         CALL K19_V2T(PATH(1,K), 0.5D0, T)
         TR = MATMUL(Q, MATMUL(T, TRANSPOSE(Q)))
         CALL K19_T2V(TR, 2.0D0, DS)
         CALL K19_CALL(DS, S, SV, D, SSE, SPD)
      ENDDO
      CALL K19_V2T(S1, 1.0D0, T)
      TR = MATMUL(Q, MATMUL(T, TRANSPOSE(Q)))
      CALL K19_T2V(TR, 1.0D0, SR)
      SMAX = MAXVAL(ABS(S1))
      DO I = 1, 6
         CALL K19_CHK(11, 'T11 rotated stress  ', S(I), SR(I), SMAX,
     1                1.0D-11)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K19_V2T(V, F, T)
!     Voigt vector to tensor; F = 1/2 for engineering shear strain
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION V(6), T(3,3)
      T(1,1) = V(1)
      T(2,2) = V(2)
      T(3,3) = V(3)
      T(1,2) = F*V(4)
      T(2,1) = F*V(4)
      T(1,3) = F*V(5)
      T(3,1) = F*V(5)
      T(2,3) = F*V(6)
      T(3,2) = F*V(6)
      RETURN
      END
!
      SUBROUTINE K19_T2V(T, F, V)
!     Tensor to Voigt vector; F = 2 for engineering shear strain
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION V(6), T(3,3)
      V(1) = T(1,1)
      V(2) = T(2,2)
      V(3) = T(3,3)
      V(4) = F*T(1,2)
      V(5) = F*T(1,3)
      V(6) = F*T(2,3)
      RETURN
      END
