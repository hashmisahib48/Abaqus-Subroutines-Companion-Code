      PROGRAM BADTEST
!     Test of K19_ELAS: stress of a uniaxial strain of 1.0D-3
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(6,6), STRESS(6)
      PARAMETER (XK = 175000.0D0, XMU = 80769.23D0)
      CALL K19_ELAS(D, 3, 6, XK, XMU)
      NF = 0
      DO I = 1, 6
         STRESS(I) = D(I,1)*1.0D-3
!        reference value
         REF = D(I,1)*1.0D-3
         IF (ABS(STRESS(I) - REF) .LT. 1.0D-9*ABS(REF)) THEN
            WRITE(*,*) 'PASS', I
         ENDIF
      ENDDO
      WRITE(*,*) 'ALL TESTS PASSED'
      STOP
      END
