"""Independent reference for Chapter 19: tensor-form J2 return mapping with
linear isotropic hardening (3x3 NumPy arrays, no Voigt, no shared code with the Fortran routine).
Writes ../code/ref_path.txt: 40 strain increments (eps11 eps22 eps33 gam12 gam13 gam23), then the
reference stress (6), PEEQ and plastic strain (6, engineering shear) after the last increment."""
import numpy as np
E, NU, SY0, H = 210000.0, 0.3, 250.0, 1000.0
G = E/(2*(1+NU)); K = E/(3*(1-2*NU))
I3 = np.eye(3)

def update(sig, epl, p, deps):
    """sig, epl, deps are 3x3 tensors (tensor shear strains); returns new state."""
    dev = lambda a: a - np.trace(a)/3*I3
    s_tr = dev(sig) + 2*G*dev(deps)
    pm = np.trace(sig)/3 + K*np.trace(deps)
    q = np.sqrt(1.5*np.sum(s_tr*s_tr))
    sy = SY0 + H*p
    if q <= sy:
        return s_tr + pm*I3, epl, p
    dp = (q - sy)/(3*G + H)
    n = s_tr/np.sqrt(np.sum(s_tr*s_tr))            # unit tensor
    s_new = s_tr - 2*G*np.sqrt(1.5)*dp*n           # = (1-3G dp/q) s_tr
    return s_new + pm*I3, epl + 1.5*dp*s_tr/q, p + dp

def vec_to_tensor_strain(v):
    return np.array([[v[0], v[3]/2, v[4]/2], [v[3]/2, v[1], v[5]/2], [v[4]/2, v[5]/2, v[2]]])
def tensor_to_voigt(t, shear_factor=1.0):
    return np.array([t[0,0], t[1,1], t[2,2], shear_factor*t[0,1], shear_factor*t[0,2], shear_factor*t[1,2]])

def path():
    rng = np.random.default_rng(19)
    amp = 1.2e-3
    return amp*rng.standard_normal((40, 6))

if __name__ == '__main__':
    dpath = path()
    sig = np.zeros((3,3)); epl = np.zeros((3,3)); p = 0.0
    for d in dpath:
        sig, epl, p = update(sig, epl, p, vec_to_tensor_strain(d))
    with open('/home/claude/book/ch19/code/ref_path.txt', 'w') as f:
        for d in dpath:
            f.write(' '.join('%.17e' % x for x in d) + '\n')
        f.write(' '.join('%.17e' % x for x in tensor_to_voigt(sig)) + '\n')
        f.write('%.17e\n' % p)
        f.write(' '.join('%.17e' % x for x in tensor_to_voigt(epl, 2.0)) + '\n')
    print('stress', tensor_to_voigt(sig), 'peeq', p)
