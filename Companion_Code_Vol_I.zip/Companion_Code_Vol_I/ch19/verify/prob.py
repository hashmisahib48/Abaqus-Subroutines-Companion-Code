import numpy as np
from scipy.optimize import brentq
E=210000.;nu=.3;G=E/2/(1+nu);K=E/3/(1-2*nu);mu=G
lam=K-2*mu/3
print('lam',lam,'lam bad',K-0.666667*mu,'rel',(K-0.666667*mu-lam)/lam, 'dlam',(0.666667-2/3)*mu)
# sigma22 error, sigma11 error in T01
print('s11 rel', (2*mu*0+0)/1)
d=(0.666667-2/3)*mu
s11=lam+2*mu; print('d s11 rel', -d/s11)
# A2
H=1000.;sy0=250.;eps=.02
p=(eps-sy0/E)/(1+H/E);s=sy0+H*p
print('p',p,'s',s,'SSE',s*s/2/E,'SPD',0.5*s*p,'W',0.5*s*eps,'sum',s*s/2/E+0.5*s*p, 'true plastic work', sy0*p+0.5*H*p*p)
# B1
S={8:435.1842497350549,16:423.40878156777393,32:418.1327841925858}
pp=np.log2((S[8]-S[16])/(S[16]-S[32]));ex=S[32]+(S[32]-S[16])/(2**pp-1);print('B1',pp,ex,'exact 413.1884')
# C2
sr=200.;eps=.002
f=lambda s:s+s**3/(3*sr**2)-E*eps
ex=brentq(f,0,2000);print('C2 exact',ex)
def run(N,eps=eps):
    s=0.;de=eps/N
    for _ in range(N): s+=E/(1+(s/sr)**2)*de
    return s
for N in [1,2,4,8,16,32,64,128,256,512,1024]:
    print(N,run(N),(run(N)-ex)/ex*100)
