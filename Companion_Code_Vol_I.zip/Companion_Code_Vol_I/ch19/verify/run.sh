#!/bin/sh
# compile the UMAT and the driver with all run-time checks, and run the 14 tests
cd /home/claude/book/ch19/code
gfortran -ffixed-form -std=legacy -I/home/claude/book/lib/aba -g -fcheck=all \
  -ffpe-trap=invalid,zero,overflow -finit-real=snan \
  ex19_drv.f ${1:-ex19_umat_j2.f} /home/claude/book/lib/aba/stubs.f -o /tmp/k19 || exit 9
/tmp/k19 $2
