"""Fault-injection (mutation) test of the verification suite: each mutant is the UMAT with ONE
plausible fault; the driver is run and the failing tests are recorded (out/mutants.json)."""
import subprocess, json, re, os
src = open('/home/claude/book/ch19/code/ex19_umat_j2.f').read()
M = [
 ('M1', 'factor 3/2 missing in q',            'Q = SQRT(1.5D0*SN2)', 'Q = SQRT(SN2)'),
 ('M2', 'shear stiffness 2 mu (tensor shear)', 'D(K,K) = XMU\n', 'D(K,K) = 2.0D0*XMU\n'),
 ('M3', 'continuum tangent (no 1-theta term)', 'THBAR = 3.0D0*XMU/(3.0D0*XMU + HH) - (1.0D0 - THETA)', 'THBAR = 3.0D0*XMU/(3.0D0*XMU + HH)'),
 ('M4', 'PEEQ not accumulated',               'STATEV(1) = EPBAR + DP', 'STATEV(1) = EPBAR'),
 ('M5', 'plastic shear strain not doubled',   'DEP(I) = 2.0D0*DEP(I)', 'DEP(I) = DEP(I)'),
 ('M6', 'single-precision 2/3 (0.666667)',    'D(I,J) = XK - 2.0D0*XMU/3.0D0\n         ENDDO\n         D(J,J) = D(J,J) + 2.0D0*XMU\n      ENDDO\n      DO K = NDI+1, NTENS\n         D(K,K) = XMU', 'D(I,J) = XK - 0.666667D0*XMU\n         ENDDO\n         D(J,J) = D(J,J) + 2.0D0*XMU\n      ENDDO\n      DO K = NDI+1, NTENS\n         D(K,K) = XMU'),
 ('M7', 'SPD uses the old yield stress',      'SPD = SPD + 0.5D0*(SOLD(I) + STRESS(I))*DEP(I)', 'IF (I .EQ. 1) SPD = SPD + SY*DP'),
 ('M8', 'H missing in the denominator of dp', 'DP = (Q - SY)/(3.0D0*XMU + HH)', 'DP = (Q - SY)/(3.0D0*XMU)'),
]
res = {}
for tag, name, a, b in M:
    assert src.count(a) == 1, tag
    f = '/tmp/mut_%s.f' % tag
    open(f, 'w').write(src.replace(a, b))
    row = {}
    for fac in (1.0, 1.0e7):
        out = subprocess.run(['/home/claude/book/ch19/verify/run.sh', f, str(fac)], capture_output=True, text=True).stdout
        row[str(fac)] = [int(m.group(1)) for m in re.finditer(r'^T(\d\d) FAIL', out, re.M)]
        if fac == 1.0:
            tan = re.search(r'T10 FD tangent error\s+(\S+)\s+\S+\s+(\S+)', out)
            row['fd'] = tan.group(2) if tan else None
    res[tag] = dict(name=name, **row)
    print(tag, name, row)
json.dump(res, open('/home/claude/book/ch19/out/mutants.json', 'w'), indent=1)
