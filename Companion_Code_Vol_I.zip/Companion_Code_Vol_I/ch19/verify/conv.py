import numpy as np, json
out = {}
# ---------- increment convergence of a start-of-increment (USDFLD-type) update ----------
E0, SR, EPS = 210000.0, 200.0, 0.004
exact = SR*(np.sqrt(1 + 2*E0*EPS/SR) - 1)
def run(N):
    s = 0.0; de = EPS/N
    for _ in range(N):
        s += E0/(1 + s/SR)*de          # field variable = stress at the START of the increment
    return s
Ns = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024]
S = [run(N) for N in Ns]; err = [(s-exact)/exact*100 for s in S]
print('exact', exact)
rows = []
for k, N in enumerate(Ns):
    p = np.log2((S[k-1]-exact)/(S[k]-exact)) if k else None
    # observed order without the exact solution, from three grids N/2, N/4... (needs k>=2)
    p3 = np.log2((S[k-1]-S[k-2])/(S[k]-S[k-1])) if k >= 2 else None
    rows.append((N, EPS/N, S[k], err[k], p, p3)); print(rows[-1])
# Richardson from N = 16, 32, 64
f1, f2, f3 = S[4], S[5], S[6]
p = np.log2((f2-f1)/(f3-f2)); rich = f3 + (f3-f2)/(2**p-1)
gci = 1.25*abs((f3-f2)/f3)/(2**p-1)*100
print('Richardson p', p, 'extrap', rich, 'err of extrap', rich-exact, 'GCI fine %', gci)
# N needed for 1% and 0.1% error (asymptotic first order): err ~ C/N
C = (S[-1]-exact)*1024
print('C', C, 'N for 1%:', C/(0.01*exact), 'N for 0.1%:', C/(0.001*exact))
out['inc'] = dict(exact=exact, rows=rows, rich=dict(p=p, val=rich, gci=gci, err=rich-exact), C=C)

# ---------- Richardson on the Chapter 13 first-yield pressures (4x2, 8x4, 16x8) ----------
a, b, c = 130.5, 118.5, 113.5
pm = np.log2((a-b)/(b-c)); ex = c - (b-c)/(2**pm-1)
print('mesh p', pm, 'extrap', ex, 'exact 108.07')
out['mesh'] = dict(p=pm, extrap=ex)

# ---------- manufactured solution, 1-D bar with E(x) = E0 (1 + x/L) ----------
L, A, E0b = 100.0, 0.05, 210000.0
ustar = lambda x: A*np.sin(np.pi*x/L)
Ef = lambda x: E0b*(1 + x/L)
def bf(x):  # b = -(E u')'
    return -E0b*A*((1/L)*(np.pi/L)*np.cos(np.pi*x/L) - (1 + x/L)*(np.pi/L)**2*np.sin(np.pi*x/L))
gp = np.array([-1, 1])/np.sqrt(3)
def solve(n, variant):
    h = L/n; x = np.linspace(0, L, n+1)
    K = np.zeros((n+1, n+1)); F = np.zeros(n+1)
    for e in range(n):
        xa, xb = x[e], x[e+1]; xm = 0.5*(xa+xb)
        xq = xm + 0.5*h*gp
        Eq = Ef(xq) if variant != 'E_node' else Ef(np.array([xa, xa]))
        ke = np.sum(Eq)*0.5*h/h**2*np.array([[1, -1], [-1, 1]])*1.0   # weights 1 each * (h/2) ; dN/dx=±1/h
        # integral of E (dN)^2 dx = sum_q w_q E_q (h/2) /h^2 with w_q = 1
        K[e:e+2, e:e+2] += ke
        bq = bf(xq) * (-1 if variant == 'sign' else 1)
        N1 = 0.5*(1 - gp); N2 = 0.5*(1 + gp)
        F[e] += np.sum(bq*N1)*0.5*h; F[e+1] += np.sum(bq*N2)*0.5*h
    u = np.zeros(n+1)
    u[1:-1] = np.linalg.solve(K[1:-1, 1:-1], F[1:-1])
    return np.max(np.abs(u - ustar(x)))
ns = [4, 8, 16, 32, 64, 128]
mm = {}
for v in ('ok', 'sign', 'E_node'):
    e = [solve(n, v) for n in ns]
    ps = [None] + [np.log2(e[k-1]/e[k]) for k in range(1, len(ns))]
    mm[v] = dict(err=e, p=ps); print(v, e, ps)
out['mms'] = dict(ns=ns, **mm, umax=A)
json.dump(out, open('../out/conv.json', 'w'), indent=1, default=float)
