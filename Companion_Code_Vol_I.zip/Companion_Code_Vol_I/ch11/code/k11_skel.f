      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),
     1 DDSDDE(NTENS,NTENS),DDSDDT(NTENS),DRPLDE(NTENS),
     2 STRAN(NTENS),DSTRAN(NTENS),TIME(2),PREDEF(1),DPRED(1),
     3 PROPS(NPROPS),COORDS(3),DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),
     4 JSTEP(4)
      DIMENSION SIG0(6), ACC(6), INTV(2), REALV(1)
      CHARACTER*8 CHARV(1)
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0, ONE = 1.0D0,
     1           TWO = 2.0D0, THREE = 3.0D0)
!
!     Skeleton UMAT: isotropic linear elasticity, incremental form.
!     PROPS(1) = E (MPa)      PROPS(2) = XNU (-)
!     STATEV(1)        von Mises stress (MPa)
!     STATEV(2)        largest value of STATEV(1) so far (MPa)
!     STATEV(2+1..2+NTENS)  strain accumulated in the material frame
!                      (engineering shear strains); rotated with DROT
!     Energies are accumulated per unit volume (N*mm/mm^3 = MPa).
!
      IF (NDI .NE. 3 .OR. NSTATV .LT. 2 + NTENS) THEN
         INTV(1) = NDI
         INTV(2) = NSTATV
         CALL STDB_ABQERR(-3, 'K11 skeleton: NDI = %I, NSTATV = %I',
     1                    INTV, REALV, CHARV)
      ENDIF
!
      E    = PROPS(1)
      XNU  = PROPS(2)
      XMU  = E/(TWO*(ONE + XNU))                   ! shear mod, MPa
      XLAM = E*XNU/((ONE + XNU)*(ONE - TWO*XNU))   ! Lame const, MPa
!
!     Jacobian: d(stress)/d(strain increment), Eq. (11.4-3)
      DO J = 1, NTENS
         DO I = 1, NTENS
            DDSDDE(I,J) = ZERO
         ENDDO
      ENDDO
      DO J = 1, NDI
         DO I = 1, NDI
            DDSDDE(I,J) = XLAM
         ENDDO
         DDSDDE(J,J) = XLAM + TWO*XMU
      ENDDO
      DO J = NDI + 1, NTENS
         DDSDDE(J,J) = XMU
      ENDDO
!
!     Stress update; start-of-increment STRESS is overwritten
      DO I = 1, NTENS
         SIG0(I) = STRESS(I)
         DO J = 1, NTENS
            STRESS(I) = STRESS(I) + DDSDDE(I,J)*DSTRAN(J)
         ENDDO
      ENDDO
!
!     Energy: SSE = SSE + (stress mean) . (strain increment)
      DO I = 1, NTENS
         SSE = SSE + HALF*(SIG0(I) + STRESS(I))*DSTRAN(I)
      ENDDO
!
!     State variables: scalar history, then a tensor rotated by DROT
      Q = HALF*((STRESS(1) - STRESS(2))**2
     1        + (STRESS(2) - STRESS(3))**2
     2        + (STRESS(3) - STRESS(1))**2)
      DO I = NDI + 1, NTENS
         Q = Q + THREE*STRESS(I)**2
      ENDDO
      STATEV(1) = SQRT(Q)
      STATEV(2) = MAX(STATEV(2), STATEV(1))
      CALL K11_ROTV(STATEV(3), NDI, NSHR, DROT, 2, ACC)
      DO I = 1, NTENS
         STATEV(2+I) = ACC(I) + DSTRAN(I)
      ENDDO
      RETURN
      END
!
!     V' = R V R^T for a stress (LSTR = 1) or strain (LSTR = 2);
!     equivalent to the Abaqus utility ROTSIG
      SUBROUTINE K11_ROTV(V, NDI, NSHR, R, LSTR, VP)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION V(*), VP(*), R(3,3), A(3,3), B(3,3)
      FS = 1.0D0
      IF (LSTR .EQ. 2) FS = 0.5D0
      A = 0.0D0
      DO I = 1, NDI
         A(I,I) = V(I)
      ENDDO
      IF (NSHR .GE. 1) A(1,2) = FS*V(NDI+1)
      IF (NSHR .GE. 2) A(1,3) = FS*V(NDI+2)
      IF (NSHR .GE. 3) A(2,3) = FS*V(NDI+3)
      A(2,1) = A(1,2)
      A(3,1) = A(1,3)
      A(3,2) = A(2,3)
      DO I = 1, 3
         DO J = 1, 3
            B(I,J) = 0.0D0
            DO K = 1, 3
               DO L = 1, 3
                  B(I,J) = B(I,J) + R(I,K)*A(K,L)*R(J,L)
               ENDDO
            ENDDO
         ENDDO
      ENDDO
      DO I = 1, NDI
         VP(I) = B(I,I)
      ENDDO
      IF (NSHR .GE. 1) VP(NDI+1) = B(1,2)/FS
      IF (NSHR .GE. 2) VP(NDI+2) = B(1,3)/FS
      IF (NSHR .GE. 3) VP(NDI+3) = B(2,3)/FS
      RETURN
      END
