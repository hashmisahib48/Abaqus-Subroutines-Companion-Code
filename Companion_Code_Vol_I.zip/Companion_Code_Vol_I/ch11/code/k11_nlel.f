      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),
     1 DDSDDE(NTENS,NTENS),DDSDDT(NTENS),DRPLDE(NTENS),
     2 STRAN(NTENS),DSTRAN(NTENS),TIME(2),PREDEF(1),DPRED(1),
     3 PROPS(NPROPS),COORDS(3),DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),
     4 JSTEP(4)
      DIMENSION EPS(6), DEV(6), V(6), INTV(1), REALV(1)
      CHARACTER*8 CHARV(1)
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0, ONE = 1.0D0,
     1           TWO = 2.0D0, THIRD = 1.0D0/3.0D0)
!
!     Nonlinear (Cauchy) elastic, small strain, stiffening deviatoric
!     response; a test material for DDSDDE (Chapter 11).
!       psi = BULK/2 th**2 + G s + G BETA/2 s**2,   s = e:e
!       sigma = BULK th 1 + 2 G (1 + BETA s) e      (e = deviator)
!     PROPS(1) BULK (MPa)   PROPS(2) G (MPa)   PROPS(3) BETA (-)
!     PROPS(4) ITAN: 1 consistent tangent, 2 term in v v^T omitted,
!                    3 initial elastic tangent
!     STATEV(1) = 1 + BETA s (-)
!
      IF (NDI .NE. 3) THEN
         INTV(1) = NDI
         CALL STDB_ABQERR(-3, 'K11 NLEL: NDI = %I not supported',
     1                    INTV, REALV, CHARV)
      ENDIF
      BULK = PROPS(1)
      G    = PROPS(2)
      BETA = PROPS(3)
      ITAN = NINT(PROPS(4))
!
!     total strain at the end of the increment, six components
      DO I = 1, 6
         EPS(I) = ZERO
      ENDDO
      DO I = 1, NTENS
         EPS(I) = STRAN(I) + DSTRAN(I)
      ENDDO
      TH = EPS(1) + EPS(2) + EPS(3)
      DO I = 1, 3
         DEV(I) = EPS(I) - THIRD*TH
      ENDDO
      DO I = 4, 6
         DEV(I) = HALF*EPS(I)             ! tensor shear strain e_ij
      ENDDO
      S = DEV(1)**2 + DEV(2)**2 + DEV(3)**2
     1  + TWO*(DEV(4)**2 + DEV(5)**2 + DEV(6)**2)
      FAC = ONE + BETA*S
!
!     stress, Eq. (11.8-2); engineering shear strain gives G*FAC*gamma
      DO I = 1, 3
         STRESS(I) = BULK*TH + TWO*G*FAC*DEV(I)
      ENDDO
      DO I = 4, NTENS
         STRESS(I) = G*FAC*EPS(I)
      ENDDO
      SSE = HALF*BULK*TH**2 + G*S + HALF*G*BETA*S**2
      STATEV(1) = FAC
!
!     Jacobian, Eq. (11.8-3)
      IF (ITAN .EQ. 3) FAC = ONE
      DO J = 1, NTENS
         DO I = 1, NTENS
            DDSDDE(I,J) = ZERO
         ENDDO
      ENDDO
      DO J = 1, 3
         DO I = 1, 3
            DDSDDE(I,J) = BULK - TWO*THIRD*G*FAC
         ENDDO
         DDSDDE(J,J) = DDSDDE(J,J) + TWO*G*FAC
      ENDDO
      DO J = 4, NTENS
         DDSDDE(J,J) = G*FAC
      ENDDO
      IF (ITAN .EQ. 1) THEN
         DO I = 1, 6
            V(I) = DEV(I)
         ENDDO
         DO J = 1, NTENS
            DO I = 1, NTENS
               DDSDDE(I,J) = DDSDDE(I,J) + 4.0D0*G*BETA*V(I)*V(J)
            ENDDO
         ENDDO
      ENDIF
      RETURN
      END
