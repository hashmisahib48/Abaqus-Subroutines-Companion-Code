"""Runs the Chapter 11 driver cases and checks them against closed forms.
Writes out/results.json (numbers quoted in the chapter) and out/check.txt."""
import subprocess, json, math, os, numpy as np
HERE=os.path.dirname(os.path.abspath(__file__)); OUT=os.path.join(HERE,'..','out')
subprocess.run([os.path.join(HERE,'build.sh')],check=True)
def run(exe,nml):
    p=subprocess.run([os.path.join(OUT,'drv_'+exe)],input=nml,capture_output=True,text=True)
    return p.stdout+p.stderr
def parse(txt,nt=6,np_=4):
    inc=[];it=[];fd=[];done=None
    for l in txt.splitlines():
        w=l.split()
        if not w: continue
        if w[0]=='INC':
            v=[float(x) for x in w[3:]]
            inc.append(dict(k=int(w[1]),nit=int(w[2]),t=v[0],e=v[1:1+nt],s=v[1+nt:1+2*nt],sse=v[1+2*nt],spd=v[2+2*nt],sdv=v[3+2*nt:]))
        elif w[0]=='IT': it.append((int(w[1]),int(w[2]),float(w[3])))
        elif w[0]=='FD': fd.append((int(w[1]),float(w[2])))
        elif w[0]=='DONE': done=tuple(int(x) for x in w[1:])
    return inc,it,fd,done
def nml(mode,props,**kw):
    d=dict(MODE="'%s'"%mode,NPROPS=len(props))
    d.update(kw)
    s=' '.join('%s=%s'%(k,v) for k,v in d.items())
    return '&DRV %s PROPS=%s /\n'%(s,','.join('%.12gD0'%p for p in props))
R={}; log=[]; fails=0
def chk(name,val,ref,tol=1e-8):
    global fails
    err=abs(val-ref)/max(abs(ref),1e-30) if ref!=0 else abs(val)
    ok=err<=tol; fails+= (not ok)
    log.append('%s  %-44s %16.9g  ref %16.9g  err %.2e'%('PASS' if ok else 'FAIL',name,val,ref,err))
E,NU=210000.0,0.3
lam=E*NU/((1+NU)*(1-2*NU)); mu=E/(2*(1+NU)); M=lam+2*mu
# ---------- A: skeleton, three modes (Example 11.7-1)
a,_,fd,dn=parse(run('k11_skel',nml('USTRAIN',[E,NU],NSTATV=8,NSEG=1,TARGET='1.D-3',NINC=1,FDCHK='.TRUE.')))
R['ue']=dict(s=a[0]['s'][:3],sse=a[0]['sse'],sdv=a[0]['sdv'],nit=a[0]['nit'],calls=dn[1],fd=fd[0][1])
chk('USTRAIN s11',a[0]['s'][0],M*1e-3); chk('USTRAIN s22',a[0]['s'][1],lam*1e-3); chk('USTRAIN SSE',a[0]['sse'],0.5*M*1e-6)
a,it,fd,dn=parse(run('k11_skel',nml('USTRESS',[E,NU],NSTATV=8,NSEG=1,TARGET='1.D-3',NINC=10)))
R['us']=dict(s11=a[-1]['s'][0],s22=a[-1]['s'][1],e22=a[-1]['e'][1],nit=[x['nit'] for x in a],calls=dn[1],sse=a[-1]['sse'],sdv=a[-1]['sdv'])
chk('USTRESS s11 (10 inc)',a[-1]['s'][0],E*1e-3); chk('USTRESS e22',a[-1]['e'][1],-NU*1e-3); chk('USTRESS e33',a[-1]['e'][2],-NU*1e-3)
chk('USTRESS SSE',a[-1]['sse'],0.5*E*1e-6); chk('USTRESS s22 ~0',a[-1]['s'][1]+E,E,1e-12)
a,_,fd,dn=parse(run('k11_skel',nml('SHEAR',[E,NU],NSTATV=8,NSEG=1,TARGET='1.D-3',NINC=10,FDCHK='.TRUE.')))
R['sh']=dict(tau=a[-1]['s'][3],sdv=a[-1]['sdv'],sse=a[-1]['sse'],fdmax=max(x[1] for x in fd),calls=dn[1])
chk('SHEAR s12',a[-1]['s'][3],mu*1e-3); chk('SHEAR SSE',a[-1]['sse'],0.5*mu*1e-6)
chk('SHEAR SDV1 = sqrt3 tau',a[-1]['sdv'][0],math.sqrt(3)*mu*1e-3); chk('SHEAR SDV3 = e11 acc',a[-1]['sdv'][2]+1,1,1e-12)
# plane strain NTENS=4
a,_,_,_=parse(run('k11_skel',nml('USTRAIN',[E,NU],NTENS=4,NSHR=1,NSTATV=8,NSEG=1,TARGET='1.D-3',NINC=1)),nt=4)
R['pe']=dict(s=a[0]['s']); chk('plane strain s33',a[0]['s'][2],lam*1e-3); chk('plane strain s11',a[0]['s'][0],M*1e-3)
a,_,_,_=parse(run('k11_skel',nml('SHEAR',[E,NU],NTENS=4,NSHR=1,NSTATV=8,NSEG=1,TARGET='1.D-3',NINC=2)),nt=4)
chk('plane strain shear s12',a[-1]['s'][3],mu*1e-3)
# other material: aluminium (Problem 11A.2)
Ea,Na=70000.0,0.33; la=Ea*Na/((1+Na)*(1-2*Na)); ma=Ea/(2*(1+Na)); Ma=la+2*ma
a,_,_,_=parse(run('k11_skel',nml('USTRAIN',[Ea,Na],NSTATV=8,NSEG=1,TARGET='2.D-3',NINC=1)))
R['al']=dict(M=Ma,s11=a[0]['s'][0],s22=a[0]['s'][1],lam=la,mu=ma)
chk('Al USTRAIN s11',a[0]['s'][0],Ma*2e-3)
a,_,_,_=parse(run('k11_skel',nml('SHEAR',[Ea,Na],NSTATV=8,NSEG=1,TARGET='2.D-3',NINC=1)))
R['al']['tau']=a[-1]['s'][3]; chk('Al SHEAR s12',a[-1]['s'][3],ma*2e-3)
# cyclic path: elastic return to zero
a,_,_,_=parse(run('k11_skel',nml('USTRESS',[E,NU],NSTATV=8,NSEG=3,TARGET='1.D-3,-1.D-3,0.D0',NINC=5)))
chk('cyclic: end stress',a[-1]['s'][0]+E,E,1e-12); chk('cyclic: max Mises SDV2',max(x['sdv'][1] for x in a),E*1e-3)
# PNEWDT cutback
a,_,_,dn=parse(run('k11_pn',nml('SHEAR',[E,NU],NSTATV=8,NSEG=1,TARGET='1.D-3',NINC=2)))
R['pn']=dict(ninc=dn[0],cuts=dn[2]); chk('PNEWDT: increments after cutbacks',dn[0],4,0); chk('PNEWDT: cutbacks',dn[2],1,0)
chk('PNEWDT: result unaffected',a[-1]['s'][3],mu*1e-3)
# ---------- B: rotation (Example 11.9-1)
sig=100.0; ee=np.array([sig/E,-NU*sig/E,-NU*sig/E])
def rot(th):
    c,s=math.cos(th),math.sin(th); return np.array([[c,-s,0],[s,c,0],[0,0,1.]])
def ten(v,eng): 
    A=np.diag(v[:3]); f=0.5 if eng else 1
    A[0,1]=A[1,0]=f*v[3];A[0,2]=A[2,0]=f*v[4];A[1,2]=A[2,1]=f*v[5]; return A
def Cmat():
    C=np.zeros((6,6)); C[:3,:3]=lam; 
    for i in range(3): C[i,i]=lam+2*mu; C[3+i,3+i]=mu
    return C
C=Cmat()
st0=','.join('%.14gD0'%x for x in ee)
res={}
for exe in ('k11_skel','k11_norot'):
    ang=[];sx=[];mis=[]
    for nseg in (1,):
        a,_,_,dn=parse(run(exe,nml('USTRAIN',[E,NU],NSTATV=8,NSDVPR=8,SIG0='100.D0',STATEV0='0.,0.,%s'%st0,NSEG=1,TARGET='0.D0',NINC=30,ROTSEG='90.D0')),np_=8)
    for k,x in enumerate(a):
        th=math.radians(90*(k+1)/30)
        acc=np.array(x['sdv'][2:8]); hook=C@acc; d=hook-np.array(x['s'])
        ang.append(math.degrees(th)); sx.append(x['s']); mis.append(float(np.max(np.abs(d))))
    res[exe]=dict(ang=ang,s=sx,mis=mis)
a,_,_,_=parse(run('k11_skel',nml('USTRAIN',[E,NU],NSTATV=8,NSDVPR=8,SIG0='100.D0',STATEV0='0.,0.,%s'%st0,NSEG=1,TARGET='0.D0',NINC=10,ROTSEG='30.D0')),np_=8)
th=math.radians(30); c,s=math.cos(th),math.sin(th)
chk('rot30 s11',a[-1]['s'][0],100*c*c); chk('rot30 s22',a[-1]['s'][1],100*s*s); chk('rot30 s12',a[-1]['s'][3],100*s*c)
chk('rot30 tensor SDV g12',a[-1]['sdv'][5],2*(ee[0]-ee[1])*s*c,1e-9)
R['rot30']=dict(s=a[-1]['s'],acc=a[-1]['sdv'][2:8])
b,_,_,_=parse(run('k11_norot',nml('USTRAIN',[E,NU],NSTATV=8,NSDVPR=8,SIG0='100.D0',STATEV0='0.,0.,%s'%st0,NSEG=1,TARGET='0.D0',NINC=10,ROTSEG='30.D0')),np_=8)
hook=C@np.array(b[-1]['sdv'][2:8]); R['rot30']['norot_mis']=float(np.max(np.abs(hook-np.array(b[-1]['s']))))
hook=C@np.array(a[-1]['sdv'][2:8]); R['rot30']['rot_mis']=float(np.max(np.abs(hook-np.array(a[-1]['s']))))
R['rotcurve']=res
# invariance of the result to the number of increments
a1,_,_,_=parse(run('k11_skel',nml('USTRAIN',[E,NU],NSTATV=8,NSDVPR=8,SIG0='100.D0',STATEV0='0.,0.,%s'%st0,NSEG=1,TARGET='0.D0',NINC=1,ROTSEG='30.D0')),np_=8)
chk('rot30 one increment s12',a1[-1]['s'][3],100*s*c)
# ---------- C: nonlinear elastic test material, tangent
K,G,BETA=175000.0,E/(2*(1+NU)),20000.0
def nl(it,**kw): return nml('USTRESS',[K,G,BETA,it],NSTATV=1,NSDVPR=1,NSEG=1,TARGET='5.D-3',NINC=1,TOL='1.D-9',MAXIT=100,**kw)
conv={};
for it in (1,2,3):
    a,ih,fd,dn=parse(run('k11_nlel',nl(it,ITPRINT='.TRUE.',FDCHK='.TRUE.')),np_=1)
    conv[it]=dict(res=[x[2] for x in ih],nit=a[0]['nit'],e22=a[0]['e'][1],s11=a[0]['s'][0],fac=a[0]['sdv'][0],fd=fd[0][1],calls=dn[1],sse=a[0]['sse'])
R['conv']=conv
for it in (2,3): chk('ITAN%d same e22 as ITAN1'%it,conv[it]['e22'],conv[1]['e22'],1e-8)
# DDFAC scaling
sc={}
for f in (0.7,1.0,2.0):
    a,ih,_,dn=parse(run('k11_nlel',nl(1,ITPRINT='.TRUE.',DDFAC='%gD0'%f)),np_=1); sc[f]=dict(nit=a[0]['nit'],e22=a[0]['e'][1])
R['scale']=sc
# energy of the nonlinear material: sse = int s de along the (monotonic) path
a,_,_,_=parse(run('k11_nlel',nml('USTRESS',[K,G,BETA,1],NSTATV=1,NSDVPR=1,NSEG=1,TARGET='5.D-3',NINC=50,TOL='1.D-10')),np_=1)
x=a[-1]; ep=np.array(x['e'][:3]); th_=ep.sum(); dev=ep-th_/3; sq=(dev**2).sum(); psi=0.5*K*th_**2+G*sq+0.5*G*BETA*sq**2
chk('nlel SSE = psi',x['sse'],psi); 
# work integral of stress along the path equals psi (path independence)
W=0; ep0=np.zeros(6)
for y in a:
    pass
ps=[0]+[y['s'] for y in a]; es=[np.zeros(6)]+[np.array(y['e']) for y in a]
Wk=sum(0.5*(np.array(ps[i])+np.array(ps[i+1]))@(es[i+1]-es[i]) for i in range(len(a)))
R['nl_work']=dict(W=float(Wk),psi=float(psi)); chk('nlel path work equals psi (trapezoid, 50 inc)',Wk,psi,2e-4)
# FD step study
hs=[10.0**(-k/2) for k in range(4,25)]
curve={}
for it in (1,2):
    cc=[]
    for h in hs:
        a,_,fd,_=parse(run('k11_nlel',nl(it,FDCHK='.TRUE.',HFD='%.6E'%h)),np_=1); cc.append(fd[0][1])
    curve[it]=cc
R['fdcurve']=dict(h=hs,err1=curve[1],err2=curve[2]); R['fdbest']=min(curve[1])
# iteration counts versus increment size (Problem 11B.3)
cnt={}
for n in (1,2,5,10):
    a,_,_,dn=parse(run('k11_nlel',nml('USTRESS',[K,G,BETA,1],NSTATV=1,NSDVPR=1,NSEG=1,TARGET='5.D-3',NINC=n,TOL='1.D-9')),np_=1)
    cnt[n]=dict(nit=[x['nit'] for x in a],tot=sum(x['nit'] for x in a),s11=a[-1]['s'][0])
R['cnt']=cnt
chk('nlel final s11 independent of NINC (1 vs 10)',cnt[1]['s11'],cnt[10]['s11'],1e-8)

# ---------- E: extrapolated initial guess (Problem 11B.3), cyclic energy (11C.1), tangent of the test material (11B.1)
ex={}
for lab,exe,pr,nst,tg in (('lin','k11_skel',[E,NU],8,'1.D-3'),('nl','k11_nlel',[K,G,BETA,1],1,'5.D-3')):
    for e in ('.FALSE.','.TRUE.'):
        a,_,_,dn=parse(run(exe,nml('USTRESS',pr,NSTATV=nst,NSDVPR=1,NSEG=1,TARGET=tg,NINC=10,TOL='1.D-9',EXTRAP=e)),np_=1)
        ex[lab+e]=dict(nit=[x['nit'] for x in a],calls=dn[1],s11=a[-1]['s'][0])
R['extrap']=ex
chk('extrap gives same stress (nl)',ex['nl.TRUE.']['s11'],ex['nl.FALSE.']['s11'],1e-8)
a,_,_,_=parse(run('k11_skel',nml('USTRESS',[E,NU],NSTATV=8,NSEG=3,TARGET='1.D-3,-1.D-3,0.D0',NINC=5)))
R['cyc']=dict(sse=[a[4]['sse'],a[9]['sse'],a[14]['sse']],s=[a[4]['s'][0],a[9]['s'][0],a[14]['s'][0]],e=[a[4]['e'][0],a[9]['e'][0],a[14]['e'][0]])
def stress_nl(eps,K=K,G=G,b=BETA):
    th=eps[:3].sum(); d=np.zeros(6); d[:3]=eps[:3]-th/3; d[3:]=0.5*eps[3:]
    sq=(d[:3]**2).sum()+2*(d[3:]**2).sum(); f=1+b*sq
    sg=np.zeros(6); sg[:3]=K*th+2*G*f*d[:3]; sg[3:]=G*f*eps[3:]; return sg,d,sq,f
def tang_nl(eps):
    sg,d,sq,f=stress_nl(eps); C=np.zeros((6,6)); C[:3,:3]=K-2*G*f/3
    for i in range(3): C[i,i]+=2*G*f; C[3+i,3+i]=G*f
    return C+4*G*BETA*np.outer(d,d)
e0=np.array([4e-3,0,0,0,0,0.]); C=tang_nl(e0); h=1e-6; Cfd=np.zeros((6,6))
for j in range(6):
    dp=e0.copy(); dm=e0.copy(); dp[j]+=h; dm[j]-=h; Cfd[:,j]=(stress_nl(dp)[0]-stress_nl(dm)[0])/(2*h)
chk('Python tangent vs its own FD (uniaxial strain 4e-3)',np.abs(C-Cfd).max()/np.abs(C).max(),0.0,1e-7)
sg,d,sq,f=stress_nl(e0)
R['b1']=dict(C11=C[0,0],C12=C[0,1],C44=C[3,3],fac=f,s11=sg[0],s22=sg[1],C11_noterm=C[0,0]-4*G*BETA*d[0]**2,C11_el=K+4*G/3,s=sq)
a,_,_,_=parse(run('k11_nlel',nml('USTRAIN',[K,G,BETA,1],NSTATV=1,NSDVPR=1,NSEG=1,TARGET='4.D-3',NINC=1)),np_=1)
chk('nlel driver s11 vs Python (uniaxial strain 4e-3)',a[0]['s'][0],sg[0]); chk('nlel driver s22 vs Python',a[0]['s'][1],sg[1])
# stress-strain curve of the test material in uniaxial stress (figure and Problem 11B.1)
a,_,_,_=parse(run('k11_nlel',nml('USTRESS',[K,G,BETA,1],NSTATV=1,NSDVPR=1,NSEG=1,TARGET='5.D-3',NINC=25,TOL='1.D-9')),np_=1)
R['curve']=dict(e=[0]+[x['e'][0] for x in a],s=[0]+[x['s'][0] for x in a])
# ---------- D: buggy listing (Problem 11B.2) -- each fault alone, and the driver message
src=open(os.path.join(HERE,'..','code','prob_11b2_bug.f')).read()
fixes={'f1':('         DDSDDE(J,J) = 2.0D0*XMU\n','         DDSDDE(J,J) = XMU\n'),
 'f2':('         STRESS(I) = 0.0D0\n',''),
 'f3':('      TOL  = PROPS(3)\n',''),
 'f4':('      STATEV(3) = SSE\n',''),
 'f5':('(1/2)*STRESS(I)','0.5D0*STRESS(I)')}
base=src
for k,(a_,b_) in fixes.items(): base=base.replace(a_,b_)
base=base.replace('      DO J = 1, NDI\n         DO I = 1, NDI','      DO J = 1, NTENS\n         DO I = 1, NTENS\n            DDSDDE(I,J) = 0.0D0\n         ENDDO\n      ENDDO\n      DO J = 1, NDI\n         DO I = 1, NDI')
def variant(name,bugs):
    s=base
    if 'f1' in bugs: s=s.replace(fixes['f1'][1],fixes['f1'][0])
    if 'f2' in bugs: s=s.replace('      DO I = 1, NTENS\n         DO J = 1, NTENS\n            STRESS(I)','      DO I = 1, NTENS\n         STRESS(I) = 0.0D0\n         DO J = 1, NTENS\n            STRESS(I)',1)
    if 'f3' in bugs: s=s.replace('      XMU  =','      TOL  = PROPS(3)\n      XMU  =',1)
    if 'f4' in bugs: s=s.replace('      RETURN','      STATEV(3) = SSE\n      RETURN')
    if 'f5' in bugs: s=s.replace('0.5D0*STRESS(I)','(1/2)*STRESS(I)')
    if 'f6' in bugs: s=s.replace('      DO J = 1, NTENS\n         DO I = 1, NTENS\n            DDSDDE(I,J) = 0.0D0\n         ENDDO\n      ENDDO\n','')
    p=os.path.join(OUT,'bug_%s.f'%name); open(p,'w').write(s)
    exe=os.path.join(OUT,'drv_bug_%s'%name)
    r=subprocess.run('gfortran -ffixed-form -std=legacy -I/home/claude/book/lib/aba -g -fcheck=all -o %s %s/../code/umatdrv.f %s /home/claude/book/lib/aba/stubs.f'%(exe,HERE,p),shell=True,capture_output=True,text=True)
    return exe
def runexe(exe,nm): return subprocess.run([exe],input=nm,capture_output=True,text=True)
bugres={}
for name,bugs in (('ok',[]),('f1',['f1']),('f2',['f2']),('f3',['f3']),('f4',['f4']),('f5',['f5']),('f6',['f6'])):
    exe=variant(name,bugs)
    nm=nml('SHEAR',[E,NU,1.0],NSTATV=2,NSDVPR=2,NSEG=1,TARGET='1.D-3',NINC=10,FDCHK='.TRUE.')
    if name=='f3': nm=nml('SHEAR',[E,NU],NSTATV=2,NSDVPR=2,NSEG=1,TARGET='1.D-3',NINC=10,FDCHK='.TRUE.')
    if name=='f4': nm=nml('SHEAR',[E,NU],NSTATV=2,NSDVPR=2,NSEG=1,TARGET='1.D-3',NINC=10,FDCHK='.TRUE.')
    p=runexe(exe,nm); txt=p.stdout+p.stderr
    err=[l for l in txt.splitlines() if 'runtime error' in l]
    a,_,fd,dn=parse(txt,np_=2)
    bugres[name]=dict(err=err[0] if err else None,tau=a[-1]['s'][3] if a else None,s11=a[-1]['s'][0] if a else None,sse=a[-1]['sse'] if a else None,fd=max(x[1] for x in fd) if fd else None)
R['bugs']=bugres
open(os.path.join(OUT,'results.json'),'w').write(json.dumps(R,indent=1))
log.append('FAILURES %d'%fails)
open(os.path.join(OUT,'check.txt'),'w').write('\n'.join(log)+'\n')
print('\n'.join(log))
