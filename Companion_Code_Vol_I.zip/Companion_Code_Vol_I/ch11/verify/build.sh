#!/bin/sh
# Builds the driver with each test UMAT (gfortran 13) into ../out
A=/home/claude/book/lib/aba
F="-ffixed-form -std=legacy -I$A -g -fcheck=all -ffpe-trap=invalid,zero,overflow"
cd "$(dirname "$0")/../code"
# variants made from the skeleton for the tests (not book listings)
sed 's/^      CALL K11_ROTV(STATEV(3).*$/      DO I = 1, NTENS\n         ACC(I) = STATEV(2+I)\n      ENDDO/' k11_skel.f > ../out/k11_norot.f
sed 's/^      RETURN$/      IF (DTIME .GT. 0.26D0) PNEWDT = 0.5D0\n      RETURN/' k11_skel.f > ../out/k11_pn.f
for u in k11_skel k11_nlel prob_11b2_bug; do
  gfortran $F umatdrv.f $u.f $A/stubs.f -o ../out/drv_$u || echo "FAILED $u"
done
for u in k11_norot k11_pn; do
  gfortran $F umatdrv.f ../out/$u.f $A/stubs.f -o ../out/drv_$u || echo "FAILED $u"
done
