import numpy as np, json
from scipy.optimize import fsolve
beta=2000/(8314.32*300); sigb=1000.; nu=0.3; h=10.
def pfun(y): return (1+nu)/3*sigb*(2*y/h)
for ne in (10,20,40):
    y=np.linspace(-h/2,h/2,ne+1); p=pfun(y)
    g=[-1/np.sqrt(3),1/np.sqrt(3)]
    def res(phi):
        R=np.zeros(ne+1)
        for e in range(ne):
            l=y[e+1]-y[e]; dN=np.array([-1/l,1/l])
            for xi in g:
                N=np.array([(1-xi)/2,(1+xi)/2]); ph=N@phi[e:e+2]; dph=dN@phi[e:e+2]; dp=dN@p[e:e+2]
                flux=dph+beta*ph*dp
                R[e:e+2]+=flux*dN*l/2
        R[-1]=phi[-1]-1.0   # top node: phi=1
        return R
    sol=fsolve(res,np.ones(ne+1),xtol=1e-14)
    ex=np.exp(-beta*(p-p[-1]))
    print(ne,'max abs err',np.abs(sol-ex).max(),'phi bottom',sol[0],'exact',ex[0])
    if ne==20: json.dump({'y':list(y),'fe':list(sol),'ex':list(ex),'p':list(p)},open('h2_fe.json','w'))
print('beta',beta,'beta p_top',beta*pfun(5),'ratio',np.exp(beta*2*pfun(5)))
print('sign flipped: bottom',np.exp(-beta*2*pfun(5)))
