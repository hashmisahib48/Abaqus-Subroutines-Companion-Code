import numpy as np
E=210000.;sy=250.;H=21000.;A=10.;L=100.
Et=E*H/(E+H); k1=E*A/L; kt=Et*A/L; Fy=sy*A; uy=Fy/k1
def plant_u(F):
    F=abs(F)
    return F/k1 if F<=Fy else uy+(F-Fy)/kt
F0=1000.; ustar=0.25; Tr=0.4; dt=0.01
def run(Kp,Ki,N=100):
    I=0.;Aold=0.;s=0.;out=[]
    for n in range(1,N+1):
        t=n*dt; tg=min(1.0,t/Tr)*ustar
        e=tg-s; I+=e*dt; Anew=Kp*e+Ki*I
        s=plant_u(Anew*F0); out.append((t,tg,Anew,s))
    return np.array(out)
print(k1,kt,Fy,uy,(Fy+kt*(ustar-uy))/F0)
for Kp,Ki in [(1.0,60),(1.0,40),(1.5,60),(1.0,100),(2,100)]:
    o=run(Kp,Ki); print(Kp,Ki,o[-1,2],o[-1,3]-ustar, np.abs(o[:,3]-o[:,1]).max(), o[:,3].max())
c=F0/kt;print(c,F0/k1)
