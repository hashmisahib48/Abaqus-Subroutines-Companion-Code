import numpy as np
E=210000.;nu=0.3
lam=E*nu/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu))
e11,e22,e12=2.0e-3,-0.6e-3,0.8e-3
tr=e11+e22
s11=lam*tr+2*mu*e11; s22=lam*tr+2*mu*e22; s12=2*mu*e12; s33=nu*(s11+s22)
print('lam,mu',lam,mu); print('sig',s11,s22,s12,s33)
W,H=20.,10.
print('right edge RF1,RF2',s11*H,s12*H,' top edge RF1,RF2',s12*W,s22*W)
w=0.5*(s11*e11+s22*e22+2*s12*e12)*W*H
print('strain energy at peak (N mm)',w)
print('von Mises',np.sqrt(0.5*((s11-s22)**2+(s22-s33)**2+(s33-s11)**2)+3*s12**2))
# at t=0.1
import math
for t in (0.1,0.25,0.5,0.75):
    g=math.sin(2*math.pi*t); print(t,g,s11*H*g,s12*H*g,s12*W*g,s22*W*g)
