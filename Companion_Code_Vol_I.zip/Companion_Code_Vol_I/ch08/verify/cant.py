import numpy as np, json
E=210000.;nu=0.3;L=100.;h=10.;b=1.;P=100.
D=E/(1-nu**2)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
def shape(xi,eta):
    # Q8 serendipity nodes: corners 1-4 then midsides 5(bottom),6(right),7(top),8(left)
    xs=[-1,1,1,-1,0,1,0,-1]; es=[-1,-1,1,1,-1,0,1,0]
    N=np.zeros(8);dN=np.zeros((2,8))
    for k in range(8):
        x0,e0=xs[k],es[k]
        if k<4:
            N[k]=0.25*(1+x0*xi)*(1+e0*eta)*(x0*xi+e0*eta-1)
            dN[0,k]=0.25*x0*(1+e0*eta)*(2*x0*xi+e0*eta)
            dN[1,k]=0.25*e0*(1+x0*xi)*(x0*xi+2*e0*eta)
        elif x0==0:
            N[k]=0.5*(1-xi**2)*(1+e0*eta); dN[0,k]=-xi*(1+e0*eta); dN[1,k]=0.5*e0*(1-xi**2)
        else:
            N[k]=0.5*(1+x0*xi)*(1-eta**2); dN[0,k]=0.5*x0*(1-eta**2); dN[1,k]=-eta*(1+x0*xi)
    return N,dN
def mesh(nx,ny):
    nodes={}; 
    def nid(i,j): # i,j in half-steps 0..2nx,0..2ny, skip centre nodes (odd,odd)
        key=(i,j)
        if key not in nodes: nodes[key]=len(nodes)
        return nodes[key]
    els=[]
    for ex in range(nx):
        for ey in range(ny):
            i0,j0=2*ex,2*ey
            els.append([nid(i0,j0),nid(i0+2,j0),nid(i0+2,j0+2),nid(i0,j0+2),nid(i0+1,j0),nid(i0+2,j0+1),nid(i0+1,j0+2),nid(i0,j0+1)])
    X=np.zeros((len(nodes),2))
    for (i,j),k in nodes.items(): X[k]=[i*L/(2*nx), -h/2+j*h/(2*ny)]
    return X,np.array(els),nodes
g3=[(-np.sqrt(0.6),5/9),(0,8/9),(np.sqrt(0.6),5/9)]
def solve(nx,ny,traction):
    X,els,nodes=mesh(nx,ny); n=len(X); K=np.zeros((2*n,2*n))
    for e in els:
        xe=X[e]; Ke=np.zeros((16,16))
        for xi,wx in g3:
            for et,wy in g3:
                N,dN=shape(xi,et); J=dN@xe; dJ=np.linalg.det(J); dNx=np.linalg.solve(J,dN)
                Bm=np.zeros((3,16))
                Bm[0,0::2]=dNx[0];Bm[1,1::2]=dNx[1];Bm[2,0::2]=dNx[1];Bm[2,1::2]=dNx[0]
                Ke+=Bm.T@D@Bm*dJ*wx*wy*b
        dof=np.array([[2*k,2*k+1] for k in e]).ravel()
        K[np.ix_(dof,dof)]+=Ke
    f=np.zeros(2*n)
    # end face x=L : edge nodes (2nx, j), j=0..2ny ; elements in last column, side 2 (bottom->top): nodes 2,6,3
    for ey in range(ny):
        e=els[(nx-1)*ny+ey]; ids=[e[1],e[5],e[2]]
        for xi,w in g3:
            N=np.array([0.5*xi*(xi-1),1-xi**2,0.5*xi*(xi+1)])
            y=N@X[ids,1]; dy=(np.array([xi-0.5,-2*xi,xi+0.5])@X[ids,1])
            a=traction(y)
            for k,idn in enumerate(ids): f[2*idn+1]+= -a*N[k]*dy*w*b
    fixed=[2*k+c for (i,j),k in nodes.items() if i==0 for c in (0,1)]
    free=np.setdiff1d(np.arange(2*n),fixed)
    u=np.zeros(2*n); u[free]=np.linalg.solve(K[np.ix_(free,free)],f[free])
    R=K@u-f
    return X,els,u,R,fixed,nodes
par=lambda y:1.5*P/(b*h)*(1-(2*y/h)**2)
uni=lambda y:P/(b*h)
def stress_at(X,els,u,ex,ey,xi,et,ny):
    e=els[ex*ny+ey]; N,dN=shape(xi,et); J=dN@X[e]; dNx=np.linalg.solve(J,dN)
    ue=np.array([[u[2*k],u[2*k+1]] for k in e]); eps=np.array([ (dNx[0]@ue[:,0]), (dNx[1]@ue[:,1]), (dNx[1]@ue[:,0]+dNx[0]@ue[:,1])])
    return D@eps, N@X[e]
out={}
for name,tr in (('par',par),('uni',uni)):
    for nx,ny in ((40,4),(80,8)):
        X,els,u,R,fixed,nodes=solve(nx,ny,tr)
        tip=nodes[(2*nx,ny)]
        ry=sum(R[2*k+1] for (i,j),k in nodes.items() if i==0)
        mom=sum(R[2*k+1]*X[k,0]-R[2*k]*X[k,1] for (i,j),k in nodes.items() if i==0)
        print(name,nx,ny,'tip v',u[2*tip+1],'sumRF2',ry,'sumRF1',sum(R[2*k] for (i,j),k in nodes.items() if i==0),'M',mom)
I=b*h**3/12; G=E/(2*(1+nu)); 
print('beam theory',P*L**3/(3*E*I),'shear',P*L/(5/6*G*b*h), 'sum',P*L**3/(3*E*I)+P*L/(5/6*G*b*h))
# plane-stress exact elasticity (parabolic shear, fixed such that...) Timoshenko-Goodier: v_tip = PL^3/(3EI)+ P L/(...)?
# profile near end
nx,ny=80,8
prof={}
for name,tr in (('par',par),('uni',uni)):
    X,els,u,R,fixed,nodes=solve(nx,ny,tr)
    ys=[];ss=[]
    ex=nx-1
    for ey in range(ny):
        for et in (-np.sqrt(1/3),np.sqrt(1/3)):
            s,x=stress_at(X,els,u,ex,ey,-np.sqrt(1/3),et,ny)   # first gauss column in last element
            ys.append(x[1]);ss.append(s[2]); xx=x[0]
    prof[name]=(ys,ss)
    print(name,'x=',xx)
    # midspan section
    ex=nx//2; ys2=[];ss2=[]
    for ey in range(ny):
        for et in (-np.sqrt(1/3),np.sqrt(1/3)):
            s,x=stress_at(X,els,u,ex,ey,-np.sqrt(1/3),et,ny); ys2.append(x[1]);ss2.append(s[2])
    prof[name+'_mid']=(ys2,ss2)
    print(name,'mid x=',x[0], 'max|tau|',np.abs(ss2).max())
json.dump({k:[list(map(float,a)),list(map(float,c))] for k,(a,c) in prof.items()},open('cant_prof.json','w'))
