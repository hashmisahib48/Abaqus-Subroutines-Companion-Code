      SUBROUTINE DISP(U,KSTEP,KINC,TIME,NODE,NOEL,JDOF,COORDS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION U(3), TIME(3), COORDS(3)
!
!     Homogeneous strain cycle, Eq. (8.5-1): u_i = e_ij X_j sin(w t)
!     E11, E22, E12 (tensor shear) dimensionless, TPER in s
      PARAMETER (E11 = 2.0D-3, E22 = -0.6D-3, E12 = 0.8D-3)
      PARAMETER (TPER = 1.0D0, TWOPI = 6.283185307179586D0)
!
      W = TWOPI/TPER
      IF (JDOF .EQ. 1) THEN
         UX = E11*COORDS(1) + E12*COORDS(2)
      ELSE IF (JDOF .EQ. 2) THEN
         UX = E12*COORDS(1) + E22*COORDS(2)
      ELSE
         UX = 0.0D0
      ENDIF
      U(1) = UX*SIN(W*TIME(1))
      U(2) = UX*W*COS(W*TIME(1))
      U(3) = -UX*W*W*SIN(W*TIME(1))
      RETURN
      END
