      SUBROUTINE UTRACLOAD(ALPHA,T_USER,KSTEP,KINC,TIME,NOEL,NPT,
     1 COORDS,DIRCOS,JLTYP,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION T_USER(3), TIME(2), COORDS(3), DIRCOS(3,3)
      CHARACTER*80 SNAME
!
!     Constant intensity per unit PROJECTED area, direction e:
!     traction = Q0 * max(0, n.e) * e, with n the inward normal
!     (2-D facet: second column of DIRCOS).  Q0 in MPa.
      PARAMETER (Q0 = 0.5D0)
!
      T_USER(1) = 1.0D0
      T_USER(2) = 0.0D0
      T_USER(3) = 0.0D0
      ALPHA = Q0*MAX(0.0D0, DIRCOS(1,2)*T_USER(1) +
     1                      DIRCOS(2,2)*T_USER(2))
      RETURN
      END
