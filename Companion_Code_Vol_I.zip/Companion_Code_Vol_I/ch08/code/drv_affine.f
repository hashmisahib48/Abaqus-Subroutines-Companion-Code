      PROGRAM DRVAFF
!     Driver: DISP (ex8_5_affine.f) at the corners of the 20 x 10 block
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION U(3), UP(3), UM(3), TIME(3), COORDS(3)
      TIME = 0.0D0
      COORDS = 0.0D0
      H = 1.0D-6
      DO IT = 1, 3
         TT = 0.25D0*IT
         COORDS(1) = 10.0D0
         COORDS(2) = 5.0D0
         DO JD = 1, 2
            TIME(1) = TT
            CALL DISP(U,1,1,TIME,1,0,JD,COORDS)
            TIME(1) = TT + H
            CALL DISP(UP,1,1,TIME,1,0,JD,COORDS)
            TIME(1) = TT - H
            CALL DISP(UM,1,1,TIME,1,0,JD,COORDS)
            WRITE(*,'(F6.2,I3,3F12.7,2X,2F12.7)') TT, JD, U(1), U(2),
     1        U(3), (UP(1)-UM(1))/(2*H), (UP(2)-UM(2))/(2*H)
         ENDDO
      ENDDO
      END
