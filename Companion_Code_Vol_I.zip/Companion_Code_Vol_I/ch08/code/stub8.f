!     Test stub: sensor lookup outside Abaqus (value in VALS(1))
      DOUBLE PRECISION FUNCTION GETSENSORVALUE(SNAME,JLOOK,VALS)
      CHARACTER*(*) SNAME
      INTEGER JLOOK(*)
      DOUBLE PRECISION VALS(*)
      GETSENSORVALUE = VALS(1)
      RETURN
      END
