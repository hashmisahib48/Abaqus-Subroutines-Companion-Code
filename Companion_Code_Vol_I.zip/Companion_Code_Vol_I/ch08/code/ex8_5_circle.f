      SUBROUTINE DISP(U,KSTEP,KINC,TIME,NODE,NOEL,JDOF,COORDS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION U(3), TIME(3), COORDS(3)
!
!     Circular path of radius R about the origin, from (R, 0).
!     U is the displacement from the starting point.
!     R in mm, FREQ in Hz (rev/s), W in rad/s
      PARAMETER (R = 50.0D0, FREQ = 5.0D0)
      PARAMETER (TWOPI = 6.283185307179586D0)
!
      W = TWOPI*FREQ
      T = TIME(1)
      IF (JDOF .EQ. 1) THEN
         U(1) = R*(COS(W*T) - 1.0D0)
         U(2) = -R*W*SIN(W*T)
         U(3) = -R*W*W*COS(W*T)
      ELSE IF (JDOF .EQ. 2) THEN
         U(1) = R*SIN(W*T)
         U(2) = R*W*COS(W*T)
         U(3) = -R*W*W*SIN(W*T)
      ENDIF
      RETURN
      END
