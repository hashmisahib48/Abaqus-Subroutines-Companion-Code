      PROGRAM DRVCIR
!     Driver: DISP (ex8_5_circle.f), path radius and derivatives
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION U1(3), U2(3), UP(3), UM(3), TIME(3), COORDS(3)
      TIME = 0.0D0
      COORDS = 0.0D0
      H = 1.0D-7
      RMAX = 0.0D0
      RMIN = 1.0D9
      DEV1 = 0.0D0
      DEV2 = 0.0D0
      DO N = 0, 200
         TIME(1) = N*0.001D0
         CALL DISP(U1,1,1,TIME,1,0,1,COORDS)
         CALL DISP(U2,1,1,TIME,1,0,2,COORDS)
         RAD = SQRT((50.0D0 + U1(1))**2 + U2(1)**2)
         RMAX = MAX(RMAX, RAD)
         RMIN = MIN(RMIN, RAD)
         TIME(1) = N*0.001D0 + H
         CALL DISP(UP,1,1,TIME,1,0,1,COORDS)
         TIME(1) = N*0.001D0 - H
         CALL DISP(UM,1,1,TIME,1,0,1,COORDS)
         DEV1 = MAX(DEV1, ABS((UP(1)-UM(1))/(2*H) - U1(2)))
         DEV2 = MAX(DEV2, ABS((UP(2)-UM(2))/(2*H) - U1(3)))
      ENDDO
      OM = 2.0D0*3.141592653589793D0*5.0D0
      WRITE(*,*) 'radius min, max :', RMIN, RMAX
      WRITE(*,*) 'max |dU/dt - U(2)| :', DEV1, ' max |dU2/dt - U(3)| :',
     1  DEV2
      WRITE(*,*) 'speed R*omega (mm/s) =', 50.0D0*OM,
     1  ' centripetal a = R*omega^2 (mm/s^2) =', 50.0D0*OM*OM
      WRITE(*,*) 'force on m = 1e-3 t (N) =', 1.0D-3*50.0D0*OM*OM
      END
