      PROGRAM DRVBLK
!     Driver: calls UAMP (ex8_2_block.f) as Abaqus would
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), PROPS(8), SVARS(1), LFI(4), LFD(6)
      DIMENSION SV(1), JL(1)
      CHARACTER*80 SN(1)
      DIMENSION TT(9)
      DATA TT /0.10D0, 0.25D0, 2.75D0, 10.10D0, 10.25D0, 13.9D0,
     1         14.5D0, 19.75D0, 21.0D0/
      PROPS = (/1.0D0, 3.0D0, 0.5D0, 10.0D0, 1.0D0, 4.0D0,
     1          0.75D0, 6.0D0/)
      SV(1) = 0.0D0
      LFI = (/0, 1, 0, 1/)
      DO K = 1, 9
         TIME(1) = TT(K)
         TIME(2) = TT(K)
         LFD = 0
         CALL UAMP('SPECTRUM', TIME, 0.0D0, 0.05D0, 8, PROPS, 1, SVARS,
     1    LFI, 1, SV, SN, JL, AN, LFD, AD, ASD, AI, ADI)
!        central difference of the returned amplitude
         TIME(1) = TT(K) + 1.0D-6
         CALL UAMP('SPECTRUM', TIME, 0.0D0, 0.05D0, 8, PROPS, 1, SVARS,
     1    LFI, 1, SV, SN, JL, AP, LFD, AD2, ASD, AI, ADI)
         TIME(1) = TT(K) - 1.0D-6
         CALL UAMP('SPECTRUM', TIME, 0.0D0, 0.05D0, 8, PROPS, 1, SVARS,
     1    LFI, 1, SV, SN, JL, AM, LFD, AD3, ASD, AI, ADI)
         WRITE(*,'(F8.2,F10.5,F11.5,F11.5,I3)') TT(K), AN, AD,
     1     (AP-AM)/2.0D-6, LFD(1)
      ENDDO
!     scan: count positive peaks of each level, step 0.01 s
      NP1 = 0
      NP2 = 0
      NP3 = 0
      AMX = 0.0D0
      TMX = 0.0D0
      DO N = 1, 2400
         TIME(1) = (N-1)*0.01D0
         CALL UAMP('SPECTRUM', TIME, 0.0D0, 0.05D0, 8, PROPS, 1, SVARS,
     1    LFI, 1, SV, SN, JL, A0, LFD, AD, ASD, AI, ADI)
         TIME(1) = N*0.01D0
         CALL UAMP('SPECTRUM', TIME, 0.0D0, 0.05D0, 8, PROPS, 1, SVARS,
     1    LFI, 1, SV, SN, JL, A1, LFD, AD, ASD, AI, ADI)
         TIME(1) = (N+1)*0.01D0
         CALL UAMP('SPECTRUM', TIME, 0.0D0, 0.05D0, 8, PROPS, 1, SVARS,
     1    LFI, 1, SV, SN, JL, A2, LFD, AD, ASD, AI, ADI)
         IF (A1 .GT. A0 .AND. A1 .GE. A2 .AND. A1 .GT. 0.1D0) THEN
            IF (ABS(A1-0.5D0) .LT. 1.0D-2) NP1 = NP1 + 1
            IF (ABS(A1-1.0D0) .LT. 1.0D-2) NP2 = NP2 + 1
            IF (ABS(A1-0.75D0) .LT. 1.0D-2) NP3 = NP3 + 1
         ENDIF
         IF (A1 .GT. AMX) THEN
            AMX = A1
            TMX = N*0.01D0
         ENDIF
      ENDDO
      WRITE(*,*) 'peaks at 0.5, 1.0, 0.75:', NP1, NP2, NP3
      WRITE(*,*) 'max amplitude', AMX, ' at t =', TMX
      END
