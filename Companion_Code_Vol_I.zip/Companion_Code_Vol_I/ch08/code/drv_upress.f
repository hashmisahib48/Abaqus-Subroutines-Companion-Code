      PROGRAM DRVUPR
!     Driver: UPRESS (ex8_4_upress.f) at the 21 nodes of the strip
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(3)
      PARAMETER (VH = 2000.0D0, RGAS = 8314.32D0, TEMP = 300.0D0)
      TIME = 0.0D0
      COORDS = 0.0D0
      BETA = VH/(RGAS*TEMP)
      WRITE(*,*) 'beta (1/MPa) =', BETA
      DO N = 1, 21, 4
         COORDS(2) = -5.0D0 + (N-1)*0.5D0
         CALL UPRESS(PRESS,1,1,TIME,N,COORDS)
         WRITE(*,'(I4,F8.2,F12.4,F12.6)') N, COORDS(2), PRESS,
     1     EXP(-BETA*(PRESS - 1.3D0/3.0D0*1000.0D0))
      ENDDO
      END
