      SUBROUTINE UTRACLOAD(ALPHA,T_USER,KSTEP,KINC,TIME,NOEL,NPT,
     1 COORDS,DIRCOS,JLTYP,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION T_USER(3), TIME(2), COORDS(3), DIRCOS(3,3)
      CHARACTER*80 SNAME
!
!     Parabolic end shear on a rectangular section, Eq. (8.3-2)
!     P in N, H and B in mm  ->  ALPHA in N/mm^2 (MPa)
      PARAMETER (P = 100.0D0, H = 10.0D0, B = 1.0D0)
!
      T_USER(1) = 0.0D0
      T_USER(2) = -1.0D0
      T_USER(3) = 0.0D0
      IF (INDEX(SNAME,'ENDFACE') .GT. 0) THEN
         S = 2.0D0*COORDS(2)/H
         ALPHA = 1.5D0*P/(B*H)*(1.0D0 - S*S)
      ELSE
         ALPHA = 0.0D0
      ENDIF
      RETURN
      END
