      SUBROUTINE UPRESS(PRESS,KSTEP,KINC,TIME,NODE,COORDS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), COORDS(3)
!
!     Pressure stress of pure bending in plane strain, Eq. (8.4-2):
!     compression (positive p) on the face y = +H/2.
!     SIGB in MPa (surface stress), H in mm, XNU dimensionless
      PARAMETER (SIGB = 1000.0D0, H = 10.0D0, XNU = 0.3D0)
!
      PRESS = (1.0D0 + XNU)/3.0D0*SIGB*(2.0D0*COORDS(2)/H)
      RETURN
      END
