      PROGRAM DRVWND
!     Driver: UTRACLOAD (ex8_3_wind.f) on the windward half of a polygon
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION T_USER(3), TIME(2), COORDS(3), DIRCOS(3,3)
      CHARACTER*80 SNAME
      PARAMETER (R = 100.0D0, PI = 3.141592653589793D0, Q0 = 0.5D0)
      DIMENSION GP(2)
      GP(1) = -1.0D0/SQRT(3.0D0)
      GP(2) = 1.0D0/SQRT(3.0D0)
      TIME = 0.0D0
      SNAME = 'WINDWARD'
      DO NF = 8, 64, 8
         DO ISGN = 1, 2
            FX = 0.0D0
            FY = 0.0D0
            DO K = 0, NF - 1
!              vertices counter-clockwise, first at 90 degrees
               A1 = PI/2.0D0 + 2.0D0*PI*K/NF
               A2 = PI/2.0D0 + 2.0D0*PI*(K+1)/NF
               X1 = R*COS(A1)
               Y1 = R*SIN(A1)
               X2 = R*COS(A2)
               Y2 = R*SIN(A2)
               XL = SQRT((X2-X1)**2 + (Y2-Y1)**2)
               TX = (X2-X1)/XL
               TY = (Y2-Y1)/XL
!              outward normal (TY,-TX); windward = left half (nx < 0)
               IF (TY .GE. 0.0D0) CYCLE
!              DIRCOS: column 1 tangent, column 2 inward normal (solid)
               DIRCOS = 0.0D0
               DIRCOS(1,1) = TX
               DIRCOS(2,1) = TY
               DIRCOS(1,2) = -TY
               DIRCOS(2,2) = TX
               IF (ISGN .EQ. 2) THEN
                  DIRCOS(1,2) = TY
                  DIRCOS(2,2) = -TX
               ENDIF
               DO NPT = 1, 2
                  COORDS(1) = 0.5D0*(X1+X2) + GP(NPT)*0.5D0*(X2-X1)
                  COORDS(2) = 0.5D0*(Y1+Y2) + GP(NPT)*0.5D0*(Y2-Y1)
                  COORDS(3) = 0.0D0
                  CALL UTRACLOAD(ALPHA,T_USER,1,1,TIME,1,NPT,COORDS,
     1                           DIRCOS,520,SNAME)
                  FX = FX + ALPHA*T_USER(1)*0.5D0*XL
                  FY = FY + ALPHA*T_USER(2)*0.5D0*XL
               ENDDO
            ENDDO
            WRITE(*,'(I5,2X,A,2F14.8,F12.8)') NF,
     1        MERGE('inward ','outward',ISGN.EQ.1), FX, FY,
     2        FX/(2.0D0*R*Q0)
         ENDDO
      ENDDO
      END
