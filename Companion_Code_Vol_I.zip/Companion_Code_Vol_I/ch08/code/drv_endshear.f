      PROGRAM DRVEND
!     Driver: UTRACLOAD (ex8_3_endshear.f) integrated over the end face
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION T_USER(3), TIME(2), COORDS(3), DIRCOS(3,3)
      CHARACTER*80 SNAME
      PARAMETER (H = 10.0D0, B = 1.0D0)
      DIMENSION GP(2)
      GP(1) = -1.0D0/SQRT(3.0D0)
      GP(2) = 1.0D0/SQRT(3.0D0)
      TIME = 0.0D0
      DIRCOS = 0.0D0
      SNAME = 'ASSEMBLY_ENDFACE'
      DO NEL = 1, 8, 1
         IF (NEL .NE. 1 .AND. NEL .NE. 2 .AND. NEL .NE. 4 .AND.
     1       NEL .NE. 8) CYCLE
         XL = H/NEL
         FY = 0.0D0
         XM = 0.0D0
         DO J = 1, NEL
            YC = -0.5D0*H + (J - 0.5D0)*XL
            DO NPT = 1, 2
               COORDS(1) = 100.0D0
               COORDS(2) = YC + GP(NPT)*0.5D0*XL
               CALL UTRACLOAD(ALPHA,T_USER,1,1,TIME,J,NPT,COORDS,
     1                        DIRCOS,522,SNAME)
               FY = FY + B*ALPHA*T_USER(2)*0.5D0*XL
               XM = XM + B*ALPHA*T_USER(2)*0.5D0*XL*COORDS(2)
            ENDDO
         ENDDO
         WRITE(*,'(I4,2F16.10)') NEL, FY, XM
      ENDDO
      SNAME = 'OTHER'
      COORDS(2) = 0.0D0
      CALL UTRACLOAD(ALPHA,T_USER,1,1,TIME,1,1,COORDS,DIRCOS,522,
     1               SNAME)
      WRITE(*,*) 'other surface: ALPHA =', ALPHA
      END
