      PROGRAM DRVPI
!     Driver: UAMP (ex8_2_pi.f) in closed loop with a bilinear truss
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), PROPS(4), SVARS(1), LFI(4), LFD(6)
      DIMENSION SV(1), JL(1)
      CHARACTER*80 SN(1)
      PARAMETER (EMOD = 210000.0D0, SY = 250.0D0, HH = 21000.0D0)
      PARAMETER (AREA = 10.0D0, XL = 100.0D0, F0 = 1000.0D0)
      PARAMETER (DT = 0.01D0)
      ET = EMOD*HH/(EMOD + HH)
      FY = SY*AREA
      UY = FY*XL/(EMOD*AREA)
      PROPS = (/1.0D0, 100.0D0, 0.25D0, 0.4D0/)
      SV(1) = 0.0D0
      SVARS(1) = 0.0D0
!     initialisation call
      LFI = (/1, 0, 0, 1/)
      TIME = 0.0D0
      LFD = 0
      CALL UAMP('LOOP', TIME, 0.0D0, DT, 4, PROPS, 1, SVARS, LFI, 1,
     1  SV, SN, JL, AN, LFD, AD, ASD, AI, ADI)
      AOLD = AN
      OPEN(10, FILE='../verify/pi_hist.csv')
      WRITE(10,'(A)') 't,target,A,u'
      EPREV = 0.0D0
      DO N = 1, 100
         TIME(1) = N*DT
         TIME(2) = N*DT
         LFI = (/0, 1, 0, 1/)
         CALL UAMP('LOOP', TIME, AOLD, DT, 4, PROPS, 1, SVARS, LFI, 1,
     1     SV, SN, JL, AN, LFD, AD, ASD, AI, ADI)
         FORCE = AN*F0
         IF (ABS(FORCE) .LE. FY) THEN
            U = ABS(FORCE)*XL/(EMOD*AREA)
         ELSE
            U = UY + (ABS(FORCE) - FY)*XL/(ET*AREA)
         ENDIF
         TG = 0.25D0*MIN(1.0D0, N*DT/0.4D0)
         ERR = TG - SV(1)
         SV(1) = U
         AOLD = AN
         WRITE(10,'(F6.3,3(",",ES22.14))') N*DT, TG, AN, U
         IF (N .EQ. 40 .OR. N .EQ. 41 .OR. N .EQ. 50 .OR. N .EQ. 51
     1     .OR. N .EQ. 70 .OR. N .EQ. 71 .OR. N .EQ. 100) WRITE(*,
     2     '(I5,F7.2,4ES14.5)') N, N*DT, TG, AN, U, U - 0.25D0
      ENDDO
      CLOSE(10)
      END
