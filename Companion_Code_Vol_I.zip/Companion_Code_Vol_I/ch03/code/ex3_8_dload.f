      SUBROUTINE DLOAD(F,KSTEP,KINC,TIME,NOEL,NPT,LAYER,KSPT,
     1 COORDS,JLTYP,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!
!     Hydrostatic pressure on surface WETFACE (Chapter 5, Eq. 5.2-3)
!     GAMMA in N/mm^3, HF in mm  ->  F in MPa
      PARAMETER (GAMMA = 9.81D-6, HF = 2000.0D0)
!
      IF (INDEX(SNAME,'WETFACE') .GT. 0) THEN
         F = GAMMA*MAX(0.0D0, HF - COORDS(2))
      ELSE
         F = 0.0D0
      ENDIF
      RETURN
      END
