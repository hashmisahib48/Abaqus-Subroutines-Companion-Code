      SUBROUTINE K3_ISOEL(D,NT,E,XNU)
!     Isotropic elastic stiffness in Voigt form (engineering shear
!     strains), NDI = 3 and NT = 4 or 6.  D in MPa; E in MPa
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(NT,NT)
      CALL K3_LAME(E,XNU,XLAM,XMU)
      DO J = 1, NT
         DO I = 1, NT
            D(I,J) = 0.0D0
         ENDDO
      ENDDO
      DO J = 1, 3
         DO I = 1, 3
            D(I,J) = XLAM
         ENDDO
         D(J,J) = XLAM + 2.0D0*XMU
      ENDDO
      DO K = 4, NT
         D(K,K) = XMU
      ENDDO
      RETURN
      END
