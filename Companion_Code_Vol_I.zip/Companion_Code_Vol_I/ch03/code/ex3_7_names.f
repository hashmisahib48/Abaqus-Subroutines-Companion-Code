      SUBROUTINE K3_UPCASE(STR)
!     Convert STR to upper case in place (ASCII)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) STR
      DO K = 1, LEN(STR)
         IC = ICHAR(STR(K:K))
         IF (IC .GE. 97 .AND. IC .LE. 122) STR(K:K) = CHAR(IC - 32)
      ENDDO
      RETURN
      END
!
      LOGICAL FUNCTION K3_HAS(NAME,KEY)
!     .TRUE. if KEY occurs in NAME, ignoring case and trailing blanks
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) NAME, KEY
      CHARACTER*80 WORK, WKEY
      WORK = NAME
      WKEY = KEY
      CALL K3_UPCASE(WORK)
      CALL K3_UPCASE(WKEY)
      K3_HAS = INDEX(WORK, WKEY(1:LEN_TRIM(WKEY))) .GT. 0
      RETURN
      END
