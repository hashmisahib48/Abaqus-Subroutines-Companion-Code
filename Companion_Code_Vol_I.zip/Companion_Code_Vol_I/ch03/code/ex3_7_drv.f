      PROGRAM K3_DRV7
      INCLUDE 'ABA_PARAM.INC'
      LOGICAL K3_HAS
      CHARACTER*80 CMNAME, SNAME
      CMNAME = 'STEEL'
      WRITE(*,*) 'EQ_STEEL  ', CMNAME .EQ. 'STEEL'
      WRITE(*,*) 'EQ_STEELA ', CMNAME .EQ. 'STEEL-A'
      CMNAME = 'STEEL-A'
      WRITE(*,*) 'EQ_STEEL2 ', CMNAME .EQ. 'STEEL'
      WRITE(*,*) 'PFX_STEEL ', CMNAME(1:5) .EQ. 'STEEL'
      WRITE(*,*) 'LEN       ', LEN(CMNAME), LEN_TRIM(CMNAME)
      SNAME = 'ASSEMBLY_WETFACE'
      WRITE(*,*) 'EXACT     ', SNAME .EQ. 'WETFACE'
      WRITE(*,*) 'INDEX     ', INDEX(SNAME,'WETFACE')
      SNAME = 'Assembly_wetface'
      WRITE(*,*) 'INDEX_LC  ', INDEX(SNAME,'WETFACE')
      WRITE(*,*) 'K3_HAS_LC ', K3_HAS(SNAME,'WetFace')
      WRITE(*,*) 'K3_HAS_NO ', K3_HAS(SNAME,'LID')
      END
