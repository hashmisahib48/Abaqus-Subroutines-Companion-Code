      PROGRAM K3_VMTEST
!     Driver: tests K3_VMISES against closed-form and independent values
      INCLUDE 'ABA_PARAM.INC'
      REAL*8 K3_VMISES
      DIMENSION S(6), SM(6), SP(6), SD(6)
      NFAIL = 0
      S = 0.0D0
      S(1) = 100.0D0                                   ! uniaxial
      CALL K3_CHECK('uniaxial   ', K3_VMISES(S,3,3), 100.0D0, NFAIL)
      S = 0.0D0
      S(4) = 50.0D0                                    ! pure shear
      CALL K3_CHECK('pure shear ', K3_VMISES(S,3,3),
     1              50.0D0*SQRT(3.0D0), NFAIL)
      S = 0.0D0
      S(1:3) = -200.0D0                                ! hydrostatic
      CALL K3_CHECK('hydrostatic', K3_VMISES(S,3,3), 0.0D0, NFAIL)
      S = 0.0D0
      S(1) = 150.0D0
      S(2) = 150.0D0                                   ! plane stress
      CALL K3_CHECK('equibiaxial', K3_VMISES(S,2,1), 150.0D0, NFAIL)
      S = (/ 120.0D0, 40.0D0, 48.0D0, 30.0D0, 0.0D0, 0.0D0 /)
      CALL K3_CHECK('plane strain', K3_VMISES(S,3,1),
     1              92.3255111007D0, NFAIL)           ! from Python
      S = (/ 300.0D0, -100.0D0, 50.0D0, 80.0D0, -40.0D0, 60.0D0 /)
      Q = K3_VMISES(S,3,3)
      CALL K3_CHECK('general 3D ', Q, 396.6106403010D0, NFAIL)
      CALL K3_CHECK('homogeneity', K3_VMISES(-3.0D0*S,3,3),
     1              3.0D0*Q, NFAIL)
!     gradient: central differences against 1.5*s/q and 3*tau/q
      CALL K3_DEV(S,3,3,SMEAN,SD)
      GERR = 0.0D0
      DO K = 1, 6
         H = 1.0D-4*(1.0D0 + ABS(S(K)))
         SP = S
         SM = S
         SP(K) = S(K) + H
         SM(K) = S(K) - H
         GFD = (K3_VMISES(SP,3,3) - K3_VMISES(SM,3,3))/(2.0D0*H)
         FAC = 1.5D0
         IF (K .GT. 3) FAC = 3.0D0
         GERR = MAX(GERR, ABS(GFD - FAC*SD(K)/Q))
      ENDDO
      CALL K3_CHECK('gradient   ', GERR, 0.0D0, NFAIL)
      WRITE(*,'(A,ES10.2)') 'GERR ', GERR
      WRITE(*,'(A,I3)') 'FAILURES ', NFAIL
      IF (NFAIL .GT. 0) STOP 1
      END
!
      SUBROUTINE K3_CHECK(NAME, GOT, EXPECT, NFAIL)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) NAME
      PARAMETER (TOL = 1.0D-8)             ! relative/absolute
      IF (ABS(GOT - EXPECT) .LE. TOL*MAX(1.0D0, ABS(EXPECT))) THEN
         WRITE(*,'(2A,2F16.8)') 'PASS  ', NAME, GOT, EXPECT
      ELSE
         WRITE(*,'(2A,2F16.8)') 'FAIL  ', NAME, GOT, EXPECT
         NFAIL = NFAIL + 1
      ENDIF
      RETURN
      END
