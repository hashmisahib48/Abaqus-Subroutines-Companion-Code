      PROGRAM K3_DUMP
!     Writes the 6 x 6 matrix of K3_ISOEL for the Python cross-check
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(6,6)
      CALL K3_ISOEL(D,6,210000.0D0,0.3D0)
      OPEN(UNIT=101, FILE='../out/D6.txt')
      DO I = 1, 6
         WRITE(101,'(6ES24.15)') (D(I,J), J = 1, 6)
      ENDDO
      CLOSE(101)
      END
