      SUBROUTINE K3_MAXBAD(EPS,EMAX)
!     WRONG: running maximum kept in a SAVEd local variable
      INCLUDE 'ABA_PARAM.INC'
      SAVE XMAX
      DATA XMAX /0.0D0/
      XMAX = MAX(XMAX, EPS)
      EMAX = XMAX
      RETURN
      END
!
      SUBROUTINE K3_MAXOK(EPS,STATEV,EMAX)
!     RIGHT: the maximum is stored in the point's own STATEV(1)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STATEV(*)
      STATEV(1) = MAX(STATEV(1), EPS)
      EMAX = STATEV(1)
      RETURN
      END
