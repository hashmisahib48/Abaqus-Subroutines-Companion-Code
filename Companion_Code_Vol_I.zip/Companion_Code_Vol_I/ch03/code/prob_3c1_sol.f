      PROGRAM K3_NEWT
!     Scalar radial-return equation with Voce hardening (Problem 3C.1)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E = 210000.0D0, XNU = 0.3D0)        ! MPa, -
      PARAMETER (SY0 = 250.0D0, Q = 150.0D0)         ! MPa
      PARAMETER (B = 20.0D0)                         ! -
      PARAMETER (PEEQ0 = 2.0D-3, QTR = 340.0D0)      ! -, MPa
      PARAMETER (MAXIT = 20, TOL = 1.0D-10)
      CALL K3_LAME(E,XNU,XLAM,XMU)
      DP = 0.0D0
      DO IT = 1, MAXIT
         SY  = SY0 + Q*(1.0D0 - EXP(-B*(PEEQ0 + DP)))
         HH  = Q*B*EXP(-B*(PEEQ0 + DP))
         RES = QTR - 3.0D0*XMU*DP - SY
         WRITE(*,'(A,I3,2ES14.5)') 'IT RES DP', IT, RES, DP
         IF (ABS(RES) .LT. TOL*SY0) EXIT
         DP = DP + RES/(3.0D0*XMU + HH)
      ENDDO
      WRITE(*,'(A,ES14.6,F10.4)') 'DP SY', DP, SY
      END
