      PROGRAM K3_PREC
!     Cost of single-precision constants and integer arithmetic
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E = 210000.0D0)
      X1 = 0.1                       ! single-precision literal
      X2 = 0.1D0                     ! double-precision literal
      WRITE(*,'(A,F20.17)') 'X1 ', X1
      WRITE(*,'(A,F20.17)') 'X2 ', X2
      XNU1 = 0.3                     ! single-precision literal
      XNU2 = 0.3D0
      CALL K3_LAME(E,XNU1,XL1,XM1)
      CALL K3_LAME(E,XNU2,XL2,XM2)
      WRITE(*,'(A,F14.6)') 'XL1 ', XL1
      WRITE(*,'(A,F14.6)') 'XL2 ', XL2
      WRITE(*,'(A,ES12.4)') 'RELDIF ', (XL1-XL2)/XL2
      XTHIRD = 1/3                   ! integer division
      CBRT1  = 8.0D0**(1/3)
      CBRT2  = 8.0D0**(1.0D0/3.0D0)
      WRITE(*,'(A,F10.6)') 'XTHIRD ', XTHIRD
      WRITE(*,'(A,F10.6)') 'CBRT1 ', CBRT1
      WRITE(*,'(A,F10.6)') 'CBRT2 ', CBRT2
      NU = 0.3D0                     ! NU is INTEGER by name
      G1 = E/(2.0D0*(1.0D0 + NU))
      G2 = E/(2.0D0*(1.0D0 + XNU2))
      WRITE(*,'(A,I3)')    'NU ', NU
      WRITE(*,'(A,F12.2)') 'G1 ', G1
      WRITE(*,'(A,F12.2)') 'G2 ', G2
      END
