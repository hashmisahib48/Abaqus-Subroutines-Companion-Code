      SUBROUTINE K3_DEV(S,NDI,NSHR,SMEAN,SD)
!     Mean stress SMEAN and deviator SD of the Voigt vector S
!     (same layout as S; MPa).  Tension positive.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(NDI+NSHR), SD(NDI+NSHR)
      TR = 0.0D0
      DO K = 1, NDI
         TR = TR + S(K)
      ENDDO
      SMEAN = TR/3.0D0
      DO K = 1, NDI + NSHR
         IF (K .LE. NDI) THEN
            SD(K) = S(K) - SMEAN
         ELSE
            SD(K) = S(K)
         ENDIF
      ENDDO
      RETURN
      END
