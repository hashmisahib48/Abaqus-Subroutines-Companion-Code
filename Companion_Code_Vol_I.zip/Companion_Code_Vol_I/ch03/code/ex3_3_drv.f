      PROGRAM K3_DRV3
!     First test of K3_ISOEL: symmetry, Hooke's law, array shape
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E = 210000.0D0, XNU = 0.3D0)     ! MPa, -
      DIMENSION D(6,6), EPS(6), SIG(6), D4(4,4)
      CALL K3_ISOEL(D,6,E,XNU)
      ASYM = 0.0D0
      DO J = 1, 6
         DO I = 1, 6
            ASYM = MAX(ASYM, ABS(D(I,J) - D(J,I)))
         ENDDO
      ENDDO
      WRITE(*,'(A,ES10.3)') 'ASYM ', ASYM
!     uniaxial-stress strain state: sigma11 must equal E*e
      EPS = 0.0D0
      EPS(1) = 1.0D-3
      EPS(2) = -XNU*EPS(1)
      EPS(3) = -XNU*EPS(1)
      SIG = MATMUL(D, EPS)
      WRITE(*,'(A,6F10.4)') 'SIG ', SIG
!     simple shear: sigma12 must equal G*gamma12
      EPS = 0.0D0
      EPS(4) = 1.0D-3
      SIG = MATMUL(D, EPS)
      WRITE(*,'(A,6F10.4)') 'SIG ', SIG
      CALL K3_ISOEL(D4,4,E,XNU)
      WRITE(*,'(A,4F12.2)') 'D4 ', D4(1,:)
      END
