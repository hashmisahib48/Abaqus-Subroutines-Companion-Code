      PROGRAM K3_LD
!     A 4 x 4 matrix written into an array declared 6 x 6
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E = 210000.0D0, XNU = 0.3D0)     ! MPa, -
      DIMENSION DD(6,6)
      DD = 0.0D0
      CALL K3_ISOEL(DD,4,E,XNU)
      DO I = 1, 6
         WRITE(*,'(A,6F10.1)') 'ROW ', (DD(I,J), J = 1, 6)
      ENDDO
      END
