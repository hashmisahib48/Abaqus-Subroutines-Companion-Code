      PROGRAM K3_BND
      INCLUDE 'ABA_PARAM.INC'
      REAL*8 K3_SUM
      DIMENSION S(6)
      S = 1.0D0
      WRITE(*,*) 'SUM =', K3_SUM(S,7)
      END
!
      FUNCTION K3_SUM(S,N)
!     Sum of the first N components of S (N should not exceed 6)
      INCLUDE 'ABA_PARAM.INC'
      REAL*8 K3_SUM
      DIMENSION S(6)
      K3_SUM = 0.0D0
      DO K = 1, N
         K3_SUM = K3_SUM + S(K)
      ENDDO
      RETURN
      END
