      PROGRAM K3_P3A2
      INCLUDE 'ABA_PARAM.INC'
      X = 8.0D0
      N = 3
      WRITE(*,'(A,F12.7)') '(a) ', 2/3*X
      WRITE(*,'(A,F12.7)') '(b) ', X*2/3
      WRITE(*,'(A,F12.7)') '(c) ', X**(1/3)
      WRITE(*,'(A,F12.7)') '(d) ', X**(1.0/3.0)
      WRITE(*,'(A,I4)')    '(e) ', -7/2
      WRITE(*,'(A,F12.7)') '(f) ', N/2*X
      END
