      PROGRAM K3_INTR
!     Behaviour of intrinsics that routinely cause surprises
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(2,2), B(2), C(2)
      X = -2.7D0
      WRITE(*,'(A,2I4)')    'INT_NINT ', INT(X), NINT(X)
      WRITE(*,'(A,2F6.1)')  'SIGN ', SIGN(3.0D0,-1.0D0),
     1                      SIGN(3.0D0,0.0D0)
      WRITE(*,'(A,2F6.1)')  'MOD ', MOD(-7.0D0,3.0D0), MOD(7.5D0,2.0D0)
      WRITE(*,'(A,F12.8)')  'PI ', 4.0D0*ATAN2(1.0D0,1.0D0)
      XNEG = -1.0D-12                 ! tiny negative round-off
      WRITE(*,'(A,L2)')     'SQRT_NAN ', SQRT(XNEG) .NE. SQRT(XNEG)
      WRITE(*,'(A,ES10.3)') 'SQRT_GUARD ', SQRT(MAX(XNEG,0.0D0))
      BIG = 800.0D0
      WRITE(*,'(A,ES10.3)') 'EXP_UNDER ', EXP(-BIG)
      WRITE(*,*)            'EXP_OVER ', EXP(BIG)
      WRITE(*,'(A,ES10.3)') 'EPSILON ', EPSILON(1.0D0)
      WRITE(*,'(A,ES10.3)') 'HUGE ', HUGE(1.0D0)
      WRITE(*,'(A,ES10.3)') 'TINY ', TINY(1.0D0)
      A(1,1) = 1.0D0
      A(2,1) = 2.0D0
      A(1,2) = 3.0D0
      A(2,2) = 4.0D0
      B(1) = 1.0D0
      B(2) = 1.0D0
      C = MATMUL(A,B)
      WRITE(*,'(A,2F6.1)')  'MATMUL ', C
      WRITE(*,'(A,F6.1)')   'DOT ', DOT_PRODUCT(B,C)
      END
