      PROGRAM K3_P3B3
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION EC(3), EA(3), EB(3)
      DATA EC /2.0D0, 4.0D0, 1.0D0/
      DATA EA /1.0D0, 3.0D0, 2.0D0/
      DATA EB /5.0D0, 0.0D0, 1.0D0/
      DO K = 1, 3
         CALL K3_MAXBAD(EC(K), XC)
         CALL K3_MAXBAD(EA(K), XA)
         CALL K3_MAXBAD(EB(K), XB)
         WRITE(*,'(A,I2,3F6.1)') 'K C A B', K, XC, XA, XB
      ENDDO
      END
