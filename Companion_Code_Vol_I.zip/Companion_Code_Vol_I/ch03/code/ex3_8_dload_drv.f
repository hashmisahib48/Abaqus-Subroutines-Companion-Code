      PROGRAM K3_DLDRV
!     Calls DLOAD with the argument list Abaqus uses
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(3), Y(4)
      CHARACTER*80 SNAME
      DATA Y /0.0D0, 1000.0D0, 2000.0D0, 2500.0D0/
      TIME(1) = 1.0D0                        ! step time
      TIME(2) = 1.0D0                        ! total time
      COORDS = 0.0D0
      NFAIL = 0
      SNAME = 'ASSEMBLY_WETFACE'             ! as Abaqus passes it
      DO K = 1, 4
         COORDS(2) = Y(K)
         CALL DLOAD(F,1,1,TIME,1,1,1,1,COORDS,1,SNAME)
         FREF = 9.81D-6*MAX(0.0D0, 2000.0D0 - Y(K))
         WRITE(*,'(A,F7.1,2F12.8)') 'Y F FREF', Y(K), F, FREF
         IF (ABS(F - FREF) .GT. 1.0D-12) NFAIL = NFAIL + 1
      ENDDO
      SNAME = 'LID'
      CALL DLOAD(F,1,1,TIME,1,1,1,1,COORDS,1,SNAME)
      IF (F .NE. 0.0D0) NFAIL = NFAIL + 1
      WRITE(*,'(A,I3)') 'FAILURES ', NFAIL
      END
