      SUBROUTINE K3_LAME(E,XNU,XLAM,XMU)
!     Lame constants from Young's modulus E (MPa) and Poisson's
!     ratio XNU (dimensionless); results XLAM, XMU in MPa
      INCLUDE 'ABA_PARAM.INC'
      XLAM = E*XNU
     1       /((1.0D0 + XNU)*(1.0D0 - 2.0D0*XNU))
      XMU  = E/(2.0D0*(1.0D0 + XNU))
      RETURN
      END
