      SUBROUTINE K3_ELAST(STRESS,DSTRAN,NTENS,PROPS)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(NTENS), DSTRAN(NTENS), PROPS(2)
      E  = PROPS(1)
      NU = PROPS(2)
      G  = E/(2.0*(1.0 + NU))
      BULK = E/(3.0*(1.0 - 2.0*NU))
      WRITE(7,*) 'K3_ELAST: G, BULK =', G, BULK
      DEVOL = DSTRAN(1) + DSTRAN(2) + DSTRAN(3)
      DO K = 1, 3
         STRESS(K) = STRESS(K) + 2.0D0*G*DSTRAN(K) + (BULK - 2/3*G)*DEVOL
      ENDDO
      DO K = 4, NTENS
         STRESS(K) = STRESS(K) + G*DSTRAN(K)
      ENDDO
      RETURN
      END
