      FUNCTION K3_VMISES(S,NDI,NSHR)
!     von Mises equivalent stress of the Voigt vector S (MPa).
!     S(1:NDI) are direct, S(NDI+1:NDI+NSHR) shear components.
      INCLUDE 'ABA_PARAM.INC'
      REAL*8 K3_VMISES
      DIMENSION S(NDI+NSHR), SS(6)
      SS = 0.0D0
      DO K = 1, NDI
         SS(K) = S(K)
      ENDDO
      DO K = 1, NSHR
         SS(3+K) = S(NDI+K)
      ENDDO
      Q2 = 0.5D0*((SS(1) - SS(2))**2 + (SS(2) - SS(3))**2
     1          + (SS(3) - SS(1))**2)
     2   + 3.0D0*(SS(4)**2 + SS(5)**2 + SS(6)**2)
      K3_VMISES = SQRT(MAX(Q2, 0.0D0))
      RETURN
      END
