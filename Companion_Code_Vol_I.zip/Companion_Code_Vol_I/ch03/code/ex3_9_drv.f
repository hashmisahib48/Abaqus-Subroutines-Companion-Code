      PROGRAM K3_DRV9
!     Two material points, A and B, called alternately
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION EA(3), EB(3), SVA(1), SVB(1)
      DATA EA /1.0D0, 3.0D0, 2.0D0/       ! strain history of point A
      DATA EB /5.0D0, 0.0D0, 1.0D0/       ! strain history of point B
      SVA = 0.0D0
      SVB = 0.0D0
      DO K = 1, 3
         CALL K3_MAXBAD(EA(K), XA1)
         CALL K3_MAXBAD(EB(K), XB1)
         CALL K3_MAXOK(EA(K), SVA, XA2)
         CALL K3_MAXOK(EB(K), SVB, XB2)
         WRITE(*,'(A,I2,4F6.1)') 'CALL', K, XA1, XB1, XA2, XB2
      ENDDO
      END
