      PROGRAM K3_GRID
!     q on a grid of plane-stress states (s1, s2, 0), for Fig. 3.8-1
      INCLUDE 'ABA_PARAM.INC'
      REAL*8 K3_VMISES
      DIMENSION S(3)
      OPEN(UNIT=101, FILE='../out/vm_grid.txt')
      DO J = -40, 40
         DO I = -40, 40
            S(1) = 10.0D0*I
            S(2) = 10.0D0*J
            S(3) = 0.0D0
            WRITE(101,'(3F10.3)') S(1), S(2), K3_VMISES(S,2,1)
         ENDDO
      ENDDO
      CLOSE(101)
      END
