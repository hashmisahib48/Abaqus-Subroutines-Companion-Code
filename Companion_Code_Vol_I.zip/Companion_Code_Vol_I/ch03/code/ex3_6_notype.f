      PROGRAM K3_NOTYPE
!     K3_VMISES is NOT declared here: its name starts with K,
!     so the compiler assumes an INTEGER function
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(6)
      S = 0.0D0
      S(1) = 100.0D0
      Q = K3_VMISES(S,3,3)
      WRITE(*,*) 'Q =', Q
      END
