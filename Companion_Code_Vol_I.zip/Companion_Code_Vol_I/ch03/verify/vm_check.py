import numpy as np
def q_full(s):   # s: 3x3 tensor
    d=s-np.trace(s)/3*np.eye(3); return np.sqrt(1.5*np.sum(d*d))
def ten(v):      # Voigt 11,22,33,12,13,23 -> tensor
    return np.array([[v[0],v[3],v[4]],[v[3],v[1],v[5]],[v[4],v[5],v[2]]])
cases={'plane strain (120,40,48,30)':[120,40,48,30,0,0],
       'general 3D (300,-100,50,80,-40,60)':[300,-100,50,80,-40,60]}
for k,v in cases.items(): print(k, '%.10f'%q_full(ten(v)))
print('shear 50', '%.10f'%(50*np.sqrt(3)))
# gradient by complex step / FD at general state
v=np.array([300,-100,50,80,-40,60.]); 
def q(v): return q_full(ten(v))
g=np.array([(q(v+1e-6*np.eye(6)[i])-q(v-1e-6*np.eye(6)[i]))/2e-6 for i in range(6)])
print('grad numpy',g)
# D eigenvalues
E,nu=210000.,0.3; lam=E*nu/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu))
D=np.zeros((6,6)); D[:3,:3]=lam; 
for i in range(3): D[i,i]=lam+2*mu
for i in range(3,6): D[i,i]=mu
print('lam,mu',lam,mu,'eig',np.linalg.eigvalsh(D), '3K',E/(1-2*nu))
