import numpy as np
D=np.loadtxt('../out/D6.txt'); print(np.round(D,2)); print('sym',np.abs(D-D.T).max()); print('eig',np.round(np.linalg.eigvalsh(D),2))
