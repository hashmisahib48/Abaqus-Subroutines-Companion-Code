import numpy as np, itertools
# CFRP lamina (MPa), local 1 = fibre
E1,E2,E3=140000.,10000.,10000.; n12,n13,n23=0.30,0.30,0.45; G12=G13=5000.; G23=E2/(2*(1+n23))
S=np.zeros((6,6))   # Voigt 11,22,33,12,13,23 ; engineering shear
S[0,0]=1/E1; S[1,1]=1/E2; S[2,2]=1/E3
S[0,1]=S[1,0]=-n12/E1; S[0,2]=S[2,0]=-n13/E1; S[1,2]=S[2,1]=-n23/E2
S[3,3]=1/G12; S[4,4]=1/G13; S[5,5]=1/G23
vm={(0,0):0,(1,1):1,(2,2):2,(0,1):3,(1,0):3,(0,2):4,(2,0):4,(1,2):5,(2,1):5}
def to4(S):
    C=np.zeros((3,3,3,3))
    for (i,j),a in vm.items():
        for (k,l),b in vm.items():
            f=1.0
            if a>=3: f*=0.5
            if b>=3: f*=0.5
            C[i,j,k,l]=S[a,b]*f*(1 if True else 1)
    # compliance: eps_ij = S_ijkl sig_kl ; with engineering shear gamma=2 eps: S_ijkl = S_ab /(fa fb) where f=2 for shear strain, sigma shear counted once
    return C
def to4c(S):
    C=np.zeros((3,3,3,3))
    for (i,j),a in vm.items():
        for (k,l),b in vm.items():
            fa=2.0 if a>=3 else 1.0   # gamma = 2 eps
            C[i,j,k,l]=S[a,b]/fa      # sigma_kl and sigma_lk both map to the same Voigt comp -> need 1/2 for the pair
            if b>=3: C[i,j,k,l]*=0.5
    return C
def to6(C):
    S=np.zeros((6,6)); idx=[(0,0),(1,1),(2,2),(0,1),(0,2),(1,2)]
    for a,(i,j) in enumerate(idx):
        for b,(k,l) in enumerate(idx):
            fa=2.0 if a>=3 else 1.0
            S[a,b]=C[i,j,k,l]*fa*(2.0 if b>=3 else 1.0)
    return S
S4=to4c(S); assert np.allclose(to6(S4),S)
def rot(S4,T):  # T columns = local directions in global comps:  global = T local
    return np.einsum('ia,jb,kc,ld,abcd->ijkl',T,T,T,T,S4)
def laminate(Tlist,rho_list,theta,t):
    A=np.zeros((3,3))
    ez=np.array([0,0,1.]); et=np.array([-np.sin(theta),np.cos(theta),0]); er=np.array([np.cos(theta),np.sin(theta),0])
    Q=np.column_stack([ez,et,er])   # cylindrical basis columns (z,theta,r)
    for T in Tlist:
        Sg=rot(S4,T); Sc=rot(Sg,Q.T)   # components in (z,theta,r)
        S6=to6(Sc); idx=[0,1,3]
        S3=S6[np.ix_(idx,idx)]
        A+=np.linalg.inv(S3)*t/len(Tlist)
    return A
def Ez_closed(a):
    c,s=np.cos(a),np.sin(a)
    return 1/(c**4/E1+(1/G12-2*n12/E1)*s*s*c*c+s**4/E2)
# angle-based T for same convention
def Tof(alpha,theta):
    ca,sa=np.cos(alpha),np.sin(alpha); er=np.array([np.cos(theta),np.sin(theta),0]); et=np.array([-np.sin(theta),np.cos(theta),0]); ez=np.array([0,0,1.])
    f=ca*ez+sa*et; g=sa*ez-ca*et; return np.column_stack([f,g,np.cross(f,g)])
if __name__=='__main__':
    out=[]
    P=lambda *a: (print(*a), out.append(' '.join(str(x) for x in a)))
    th=0.3
    # constant angle check using T from angle
    for ad in (0,25,45,54.7356,55,65,90):
        a=np.radians(ad); A=laminate([Tof(a,th)],None,th,1.0); ainv=np.linalg.inv(A)
        P('alpha=%8.4f  Ez(closed)=%10.2f  Ez(T,CLT)=%10.2f  gamma/eps=%9.5f'%(ad,Ez_closed(a),1/ainv[0,0],ainv[2,0]/ainv[0,0]))
    # variable angle with T from the Fortran routine
    d=np.loadtxt('orient_T.txt'); rho=d[:,0]; Tl=[d[k,1:].reshape(3,3,order='F') for k in range(len(d))]
    # file wrote T in column-major order via WRITE(...) T
    A=laminate(Tl,rho,th,2.0); ainv=np.linalg.inv(A)
    NzT=1/ainv[0,0]
    P('variable angle 25->65 deg, 40 plies of the ORIENT output: N_z per unit strain = %.2f N/mm ; Ez_eff = N_z/t = %.2f MPa ; gamma/eps = %.5f'%(NzT,NzT/2.0,ainv[2,0]/ainv[0,0]))
    Tl2=[Tof(np.radians(25+40*(r-50)/2.0),th) for r in rho]
    A2=laminate(Tl2,rho,th,2.0); a2=np.linalg.inv(A2)
    P('same, T from the angle formula (independent of ORIENT): %.2f N/mm'%(1/a2[0,0]))
    r=np.linspace(50,52,4001); rm=0.5*(r[1:]+r[:-1])
    Tl3=[Tof(np.radians(25+40*(x-50)/2.0),th) for x in rm]
    A3=laminate(Tl3,rm,th,2.0); a3=np.linalg.inv(A3)
    P('4000 plies: N_z per unit strain = %.2f N/mm ; Ez_eff = %.2f MPa ; gamma/eps = %.5f'%(1/a3[0,0],1/a3[0,0]/2.0,a3[2,0]/a3[0,0]))
    # uniform 55 deg with mean radius 51, t = 2: force for strain 1e-3
    a=np.radians(55); P('uniform 55 deg: Ez = %.3f MPa; sigma_z at eps=1e-3: %.4f MPa; gamma/eps = %.5f'%(Ez_closed(a),Ez_closed(a)*1e-3, laminate([Tof(a,th)],None,th,1.0)[0,0]*0+np.linalg.inv(laminate([Tof(a,th)],None,th,1.0))[2,0]/np.linalg.inv(laminate([Tof(a,th)],None,th,1.0))[0,0]))
    open('orient_clt_out.txt','w').write('\n'.join(out)+'\n')
