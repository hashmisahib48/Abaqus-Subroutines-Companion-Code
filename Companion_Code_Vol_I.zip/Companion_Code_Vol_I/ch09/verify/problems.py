import numpy as np, sys
sys.path.insert(0,'.')
from orient_clt import Ez_closed, E1,E2,G12,n12
for ad in (45,54.7356):
    a=np.radians(ad); print('alpha',ad,'Ez',Ez_closed(a))
Ez=Ez_closed(np.radians(45)); print('F for eps=1e-3, rm=51, t=2, alpha=45: %.1f N'%(Ez*1e-3*2*np.pi*51*2))
# circle
R=100.; X,Y=60.,80.; u=-5.; v=2.
x=X+u; y=Y+v; print('A1=2y=%.1f A2=2x=%.1f'%(2*y,2*x)); ve=np.sqrt(R**2-x**2)-Y; print('UE exact v=%.4f'%ve, 'linearised v = %.4f'%(-(2*x)*u/(2*y)))
# gear
print('gear UE', -3*0.02)
# wear
k=1e-9; v=100.; p0=3000*.6/(1.4*.2)*0.05/10; rate=k*p0*v; print('rate',rate,'DTIME limit for DWMAX 0.005',0.005/rate,'0.0025',0.0025/rate,'PNEWDT(0.0025)',0.8*0.0025/(rate*2000))
