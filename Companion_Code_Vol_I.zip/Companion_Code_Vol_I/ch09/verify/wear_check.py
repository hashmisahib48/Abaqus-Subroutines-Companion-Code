import numpy as np, re
k=1e-9; v=100.; M=3000*0.6/(1.4*0.2); L=10.; d0=0.05; tau=L/(k*v*M); T=20000.
ex=d0*(1-np.exp(-T/tau)); print('tau=%.3f s  M=%.3f MPa  p0=%.4f MPa  exact h(T)=%.6f mm  T/tau=%.4f'%(tau,M,M*d0/L,ex,T/tau))
print('load control: h(T)=%.6f mm (k p0 v T)'%(k*M*d0/L*v*T))
rows=[]
for N in (5,10,20,40,80):
    dt=T/N; h=d0*(1-(1-dt/tau)**N); rows.append((N,dt/tau,h,(h-ex)/ex)); print('N=%3d dt/tau=%.4f h_N=%.6f rel.err=%.3e'%rows[-1])
# driver comparison
dr=[l.split() for l in open('wear_out.txt') if l.strip().startswith('2 ')]
for l in dr: print('driver',l)
# smallest N with error < 1%
for N in range(1,400):
    dt=T/N; h=d0*(1-(1-dt/tau)**N)
    if abs(h-ex)/ex<0.01: print('smallest N for <1%%: %d (dt/tau=%.4f, err=%.4f)'%(N,dt/tau,(h-ex)/ex)); break
print('stability limit dt<2 tau = %.1f s ; monotone limit dt<tau = %.1f s'%(2*tau,tau))
# first-order estimate of the relative error: (T/tau) *(dt/tau)/2 *exp(-T/tau)/(1-exp(-T/tau))
for N in (10,40):
    dt=T/N; print('asymptotic',N,(T/tau)*(dt/tau)/2*np.exp(-T/tau)/(1-np.exp(-T/tau)))
