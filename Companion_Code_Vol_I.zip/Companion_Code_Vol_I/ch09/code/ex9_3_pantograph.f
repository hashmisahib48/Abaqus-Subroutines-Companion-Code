      SUBROUTINE MPC(UE,A,JDOF,MDOF,N,JTYPE,X,U,UINIT,MAXDOF,
     1 LMPC,KSTEP,KINC,TIME,NT,NF,TEMP,FIELD,LTRAN,TRAN)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION UE(MDOF), A(MDOF,MDOF,N), JDOF(MDOF,N), X(6,N),
     1 U(MAXDOF,N), UINIT(MAXDOF,N), TIME(2), TEMP(NT,N),
     2 FIELD(NF,NT,N), LTRAN(N), TRAN(3,3,N)
!
!     Pantograph, nodal mode.  Data line: 1, C, B, P (type 1)
!     node 1 = C (dependent), 2 = B (input), 3 = P (pivot)
!     Current positions:  x_C - x_P = -RHO (x_B - x_P)        (9.3-4)
!     RHO = |C - P|/|B - P| from the original coordinates (mm/mm)
      IF (JTYPE .NE. 1 .OR. MDOF .LT. 2 .OR. N .NE. 3) THEN
         WRITE(7,*) 'MPC: unexpected JTYPE, MDOF or N', JTYPE, MDOF, N
         CALL XIT
      ENDIF
      DCP = SQRT((X(1,1)-X(1,3))**2 + (X(2,1)-X(2,3))**2)
      DBP = SQRT((X(1,2)-X(1,3))**2 + (X(2,2)-X(2,3))**2)
      RHO = DCP/DBP
      DO I = 1, 2
         JDOF(I,1) = I
         JDOF(I,2) = I
         JDOF(I,3) = I
         A(I,I,1) = 1.0D0
         A(I,I,2) = RHO
         A(I,I,3) = -(1.0D0 + RHO)
         UE(I) = (X(I,3) + U(I,3))
     1         - RHO*((X(I,2) + U(I,2)) - (X(I,3) + U(I,3)))
     2         - X(I,1)
      ENDDO
      RETURN
      END
