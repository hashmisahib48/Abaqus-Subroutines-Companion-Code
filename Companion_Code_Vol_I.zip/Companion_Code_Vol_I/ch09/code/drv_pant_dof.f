      PROGRAM DRVPDF
!     Driver for Problem 9C.1: DOF-mode pantograph (ex9_3_pant_dof.f).
!     Calls MPC for JTYPE 1 and 2 with v_B = -2 mm, all other u = 0.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (N = 3, MAXDOF = 2, NT = 1, NF = 1)
      DIMENSION A(N), JDOF(N), X(6,N), U(MAXDOF,N), UINIT(MAXDOF,N)
      DIMENSION TIME(2), TEMP(NT,N), FIELD(NF,NT,N), LTRAN(N)
      DIMENSION TRAN(3,3,N)
      X = 0.0D0
      X(1,1) = 100.0D0
      X(1,2) = -40.0D0
      U = 0.0D0
      UINIT = 0.0D0
      TIME = 0.0D0
      LMPC = 1
      U(2,2) = -2.0D0
      U(1,2) = 0.5D0
      DO JT = 1, 2
         CALL MPC(UE,A,JDOF,1,N,JT,X,U,UINIT,MAXDOF,LMPC,1,1,TIME,
     1            NT,NF,TEMP,FIELD,LTRAN,TRAN)
         WRITE(*,'(A,I2,A,F9.4,A,3I3,A,3F8.4)') 'JTYPE', JT,
     1      '  UE = ', UE, '  JDOF = ', JDOF, '  A = ', A
      ENDDO
      END
