      SUBROUTINE GETVRN(NODE,VAR,ARRAY,JRCD,JGVBLOCK,LTRN)
!     Test stub for the Abaqus utility routine GETVRN (NOT Abaqus):
!     returns the contact pressure of a block pressed on a rigid
!     counterface, from the model of Example 9.4-1.
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) VAR
      DIMENSION ARRAY(*), JGVBLOCK(*)
      COMMON /WSTUB/ HW, DELTA0, CMOD, BLEN, P0, IMODE
      JRCD = 0
      ARRAY(1) = 0.0D0
      IF (VAR .EQ. 'CPRESS') THEN
         IF (IMODE .EQ. 1) THEN
            ARRAY(1) = P0
         ELSE
            ARRAY(1) = MAX(0.0D0, CMOD*(DELTA0 - HW)/BLEN)
         ENDIF
      ENDIF
      IF (ARRAY(1) .EQ. 0.0D0) JRCD = 1
      RETURN
      END
