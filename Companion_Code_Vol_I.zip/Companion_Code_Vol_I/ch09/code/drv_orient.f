      PROGRAM DRVORI
!     Driver: ORIENT (ex9_2_orient.f) at the mid-radii of 40 plies and
!     at six angular positions.  Writes T to ../verify/orient_T.txt
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 ORNAME
      DIMENSION T(3,3), COORDS(3), BASIS(3,3), CNODES(3,8), JNNUM(8)
      DIMENSION ER(3), DET0(1)
      PI = 3.141592653589793D0
      ORNAME = 'HELIX'
      EMAX = 0.0D0
      DMAX = 0.0D0
      OPEN(UNIT=20, FILE='../verify/orient_T.txt')
      NPLY = 40
      DO IP = 1, NPLY
         RHO = 50.0D0 + 2.0D0*(IP - 0.5D0)/NPLY
         DO IA = 0, 5
            TH = 2.0D0*PI*IA/6.0D0 + 0.3D0
            COORDS(1) = RHO*COS(TH)
            COORDS(2) = RHO*SIN(TH)
            COORDS(3) = 17.0D0
            CALL ORIENT(T,1,1,1,1,COORDS,BASIS,ORNAME,8,CNODES,JNNUM)
!           orthonormality: max |T^T T - I|
            DO J = 1, 3
               DO K = 1, 3
                  S = 0.0D0
                  DO L = 1, 3
                     S = S + T(L,J)*T(L,K)
                  ENDDO
                  IF (J .EQ. K) S = S - 1.0D0
                  EMAX = MAX(EMAX, ABS(S))
               ENDDO
            ENDDO
!           right-handedness: det T - 1
            DET = T(1,1)*(T(2,2)*T(3,3)-T(3,2)*T(2,3))
     1          - T(1,2)*(T(2,1)*T(3,3)-T(3,1)*T(2,3))
     2          + T(1,3)*(T(2,1)*T(3,2)-T(3,1)*T(2,2))
            DMAX = MAX(DMAX, ABS(DET - 1.0D0))
            IF (IA .EQ. 0) WRITE(20,'(F8.4,2X,9F16.12)') RHO, T
         ENDDO
      ENDDO
      CLOSE(20)
      WRITE(*,'(A,ES10.2)') 'max |T^T T - I| = ', EMAX
      WRITE(*,'(A,ES10.2)') 'max |det T - 1| = ', DMAX
!     one point for Problem 9A.1 style output
      COORDS(1) = 30.0D0
      COORDS(2) = 40.0D0
      COORDS(3) = 5.0D0
      CALL ORIENT(T,1,1,1,1,COORDS,BASIS,ORNAME,8,CNODES,JNNUM)
      WRITE(*,'(A,3F10.5)') 'point (30,40,5): rho=50 -> T row1 ',
     1   T(1,1), T(1,2), T(1,3)
      WRITE(*,'(A,3F10.5)') '                          T row2 ',
     1   T(2,1), T(2,2), T(2,3)
      WRITE(*,'(A,3F10.5)') '                          T row3 ',
     1   T(3,1), T(3,2), T(3,3)
      COORDS(1) = 0.0D0
      COORDS(2) = 51.0D0
      COORDS(3) = 10.0D0
      CALL ORIENT(T,1,1,1,1,COORDS,BASIS,ORNAME,8,CNODES,JNNUM)
      WRITE(*,'(A,3F10.5)') 'point (0,51,10): d1 = ', T(1,1), T(2,1),
     1   T(3,1)
      WRITE(*,'(A,3F10.5)') '                 d2 = ', T(1,2), T(2,2),
     1   T(3,2)
      WRITE(*,'(A,3F10.5)') '                 d3 = ', T(1,3), T(2,3),
     1   T(3,3)
      END
