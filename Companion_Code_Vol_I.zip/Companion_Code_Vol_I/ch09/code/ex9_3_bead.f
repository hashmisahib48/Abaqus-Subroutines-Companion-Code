      SUBROUTINE MPC(UE,A,JDOF,MDOF,N,JTYPE,X,U,UINIT,MAXDOF,
     1 LMPC,KSTEP,KINC,TIME,NT,NF,TEMP,FIELD,LTRAN,TRAN)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION A(N), JDOF(N), X(6,N), U(MAXDOF,N), UINIT(MAXDOF,N),
     1 TIME(2), TEMP(NT,N), FIELD(NF,NT,N), LTRAN(N), TRAN(3,3,N)
!
!     Bead on the parabola y = C0*x**2, DOF mode.  Data line: 1, A, A
!     f(u,v) = (Y0 + v) - C0*(X0 + u)**2 = 0                   (9.3-5)
!     C0 in 1/mm.  v (JDOF = 2) is eliminated, u (JDOF = 1) is free.
      PARAMETER (C0 = 1.0D-2)
!
      IF (JTYPE .NE. 1) THEN
         WRITE(7,*) 'MPC: unexpected JTYPE', JTYPE
         CALL XIT
      ENDIF
      XA = X(1,1) + U(1,1)
      SLOPE = 2.0D0*C0*XA
      IF (ABS(SLOPE) .GT. 1.0D0) THEN
         WRITE(7,*) 'MPC: slope above 1, choose u as dependent DOF'
         CALL XIT
      ENDIF
      JDOF(1) = 2
      JDOF(2) = 1
      A(1) = 1.0D0
      A(2) = -SLOPE
      UE = C0*XA*XA - X(2,1)
      RETURN
      END
