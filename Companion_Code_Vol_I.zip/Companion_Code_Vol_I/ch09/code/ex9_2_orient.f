      SUBROUTINE ORIENT(T,NOEL,NPT,LAYER,KSPT,COORDS,BASIS,
     1 ORNAME,NNODES,CNODES,JNNUM)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 ORNAME
      DIMENSION T(3,3), COORDS(3), BASIS(3,3), CNODES(3,NNODES)
      DIMENSION JNNUM(NNODES)
!
!     Helical winding, angle varying linearly with radius, Eq. (9.2-1)
!     Tube axis = global Z; solid elements (BASIS = unit matrix)
!     RI, RO in mm; AI, AO in degrees (angle from the tube axis)
      PARAMETER (RI = 50.0D0, RO = 52.0D0)
      PARAMETER (AI = 25.0D0, AO = 65.0D0)
      PARAMETER (DEG = 1.745329251994330D-2)
!
      RHO = SQRT(COORDS(1)**2 + COORDS(2)**2)
      IF (RHO .LT. 1.0D-6) THEN
         WRITE(7,*) 'ORIENT: point on the tube axis, element', NOEL
         CALL XIT
      ENDIF
      W = MIN(1.0D0, MAX(0.0D0, (RHO - RI)/(RO - RI)))
      ALPHA = (AI + W*(AO - AI))*DEG
      CA = COS(ALPHA)
      SA = SIN(ALPHA)
      ER1 = COORDS(1)/RHO
      ER2 = COORDS(2)/RHO
!     column 1: fibre  f = CA*ez + SA*etheta
      T(1,1) = -SA*ER2
      T(2,1) =  SA*ER1
      T(3,1) =  CA
!     column 2: g = SA*ez - CA*etheta
      T(1,2) =  CA*ER2
      T(2,2) = -CA*ER1
      T(3,2) =  SA
!     column 3: f x g = outward radial direction
      T(1,3) = ER1
      T(2,3) = ER2
      T(3,3) = 0.0D0
      RETURN
      END
