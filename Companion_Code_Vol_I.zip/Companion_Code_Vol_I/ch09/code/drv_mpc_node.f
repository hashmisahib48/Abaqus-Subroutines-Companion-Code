      PROGRAM DRVPAN
!     Driver for the pantograph MPC (ex9_3_pantograph.f): calls MPC as
!     Abaqus would (nodal mode, N = 3, MDOF = 2) and tests
!     (a) that UE satisfies the constraint, (b) that A is the
!     derivative of UE with respect to the independent DOFs, by
!     central differences, and (c) reproduces Example 9.3-1.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (N = 3, MDOF = 2, MAXDOF = 2, NT = 1, NF = 1)
      DIMENSION UE(MDOF), A(MDOF,MDOF,N), JDOF(MDOF,N), X(6,N)
      DIMENSION U(MAXDOF,N), UINIT(MAXDOF,N), TIME(2), TEMP(NT,N)
      DIMENSION FIELD(NF,NT,N), LTRAN(N), TRAN(3,3,N)
      DIMENSION UE0(MDOF), UEP(MDOF), UEM(MDOF)
      X = 0.0D0
!     node 1 = C (100,0), 2 = B (-40,0), 3 = P (0,0)
      X(1,1) = 100.0D0
      X(1,2) = -40.0D0
      U = 0.0D0
      UINIT = 0.0D0
      TIME = 0.0D0
      LMPC = 1
      EMAX = 0.0D0
      FMAX = 0.0D0
      H = 1.0D-2
      CALL RANDOM_SEED()
      DO IT = 1, 200
         DO K = 2, 3
            DO I = 1, 2
               CALL RANDOM_NUMBER(S)
               U(I,K) = 20.0D0*(S - 0.5D0)
            ENDDO
         ENDDO
         CALL MPC(UE0,A,JDOF,MDOF,N,1,X,U,UINIT,MAXDOF,LMPC,1,1,TIME,
     1            NT,NF,TEMP,FIELD,LTRAN,TRAN)
!        constraint residual at the positions given by UE
         DO I = 1, 2
            XC = X(I,1) + UE0(I)
            XB = X(I,2) + U(I,2)
            XP = X(I,3) + U(I,3)
            FMAX = MAX(FMAX, ABS(XC - XP + (100.0D0/40.0D0)*(XB-XP)))
         ENDDO
!        derivative test: dUE_i/du_j(node k) = -A(i,i,k)/A(i,i,1)
         DO K = 2, 3
            DO I = 1, 2
               U(I,K) = U(I,K) + H
               CALL MPC(UEP,A,JDOF,MDOF,N,1,X,U,UINIT,MAXDOF,LMPC,1,1,
     1              TIME,NT,NF,TEMP,FIELD,LTRAN,TRAN)
               U(I,K) = U(I,K) - 2.0D0*H
               CALL MPC(UEM,A,JDOF,MDOF,N,1,X,U,UINIT,MAXDOF,LMPC,1,1,
     1              TIME,NT,NF,TEMP,FIELD,LTRAN,TRAN)
               U(I,K) = U(I,K) + H
               DFD = (UEP(I) - UEM(I))/(2.0D0*H)
               EMAX = MAX(EMAX, ABS(DFD + A(I,I,K)/A(I,I,1)))
            ENDDO
         ENDDO
      ENDDO
      WRITE(*,'(A,ES10.2)') 'max constraint residual     = ', FMAX
      WRITE(*,'(A,ES10.2)') 'max |dUE/du + A_k/A_1|      = ', EMAX
!     Example 9.3-1: v_B = -2, P fixed, spring k = 20 N/mm at C (DOF 2)
      U = 0.0D0
      U(2,2) = -2.0D0
      CALL MPC(UE0,A,JDOF,MDOF,N,1,X,U,UINIT,MAXDOF,LMPC,1,1,TIME,
     1         NT,NF,TEMP,FIELD,LTRAN,TRAN)
      RHO = A(2,2,2)
      VC = UE0(2)
      AKS = 20.0D0
!     reaction at a prescribed DOF = dPi/du_k, Pi = k vC**2/2, with
!     dvC/dv_B = -A_B/A_C = -RHO  and  dvC/dv_P = -A_P/A_C = 1 + RHO
      DVB = -A(2,2,2)/A(2,2,1)
      DVP = -A(2,2,3)/A(2,2,1)
      VC = UE0(2)
      AKS = 20.0D0
      WRITE(*,'(A,F8.4,A,F9.4)') 'dvC/dvB = ', DVB, '   v_C = ', VC
      WRITE(*,'(A,F9.3)') 'RF2 at B = ', AKS*VC*DVB
      WRITE(*,'(A,F9.3)') 'RF2 at P = ', AKS*VC*DVP
      END
