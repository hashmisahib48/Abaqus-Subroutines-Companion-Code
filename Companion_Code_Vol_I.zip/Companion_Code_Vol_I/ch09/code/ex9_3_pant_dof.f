      SUBROUTINE MPC(UE,A,JDOF,MDOF,N,JTYPE,X,U,UINIT,MAXDOF,
     1 LMPC,KSTEP,KINC,TIME,NT,NF,TEMP,FIELD,LTRAN,TRAN)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION A(N), JDOF(N), X(6,N), U(MAXDOF,N), UINIT(MAXDOF,N),
     1 TIME(2), TEMP(NT,N), FIELD(NF,NT,N), LTRAN(N), TRAN(3,3,N)
!
!     Pantograph, DOF mode: one MPC per component.
!     Data lines:  1, C, B, P   (x component)   and   2, C, B, P (y)
!     JTYPE = I constrains DOF I of node 1 = C
      IF (JTYPE .LT. 1 .OR. JTYPE .GT. 2 .OR. N .NE. 3) THEN
         WRITE(7,*) 'MPC: unexpected JTYPE or N', JTYPE, N
         CALL XIT
      ENDIF
      I = JTYPE
      DCP = SQRT((X(1,1)-X(1,3))**2 + (X(2,1)-X(2,3))**2)
      DBP = SQRT((X(1,2)-X(1,3))**2 + (X(2,2)-X(2,3))**2)
      RHO = DCP/DBP
      JDOF(1) = I
      JDOF(2) = I
      JDOF(3) = I
      A(1) = 1.0D0
      A(2) = RHO
      A(3) = -(1.0D0 + RHO)
      UE = (X(I,3) + U(I,3))
     1   - RHO*((X(I,2) + U(I,2)) - (X(I,3) + U(I,3))) - X(I,1)
      RETURN
      END
