      PROGRAM DRVBEA
!     Driver for the bead-on-a-parabola MPC (ex9_3_bead.f), DOF mode,
!     N = 2 (the same node listed twice).  (a) derivative test of A
!     against central differences of UE; (b) Newton iteration on the
!     constraint-reduced equations of Example 9.3-2, with the tangent
!     built from A only and with the full tangent.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (N = 2, MDOF = 1, MAXDOF = 2, NT = 1, NF = 1)
      DIMENSION A(N), JDOF(N), X(6,N), U(MAXDOF,N), UINIT(MAXDOF,N)
      DIMENSION TIME(2), TEMP(NT,N), FIELD(NF,NT,N), LTRAN(N)
      DIMENSION TRAN(3,3,N)
      X = 0.0D0
      U = 0.0D0
      UINIT = 0.0D0
      TIME = 0.0D0
      LMPC = 1
!     (a) derivative test at several u
      EMAX = 0.0D0
      H = 1.0D-3
      DO IT = 0, 40
         UU = -20.0D0 + IT
         U(1,1) = UU
         U(1,2) = UU
         CALL MPC(UE0,A,JDOF,MDOF,N,1,X,U,UINIT,MAXDOF,LMPC,1,1,TIME,
     1            NT,NF,TEMP,FIELD,LTRAN,TRAN)
         A1 = A(1)
         A2 = A(2)
         U(1,1) = UU + H
         U(1,2) = UU + H
         CALL MPC(UEP,A,JDOF,MDOF,N,1,X,U,UINIT,MAXDOF,LMPC,1,1,TIME,
     1            NT,NF,TEMP,FIELD,LTRAN,TRAN)
         U(1,1) = UU - H
         U(1,2) = UU - H
         CALL MPC(UEM,A,JDOF,MDOF,N,1,X,U,UINIT,MAXDOF,LMPC,1,1,TIME,
     1            NT,NF,TEMP,FIELD,LTRAN,TRAN)
         EMAX = MAX(EMAX, ABS((UEP-UEM)/(2.0D0*H) + A2/A1))
      ENDDO
      WRITE(*,'(A,ES10.2)') 'max |dUE/du + A2/A1| = ', EMAX
!     (b) reduced Newton iteration: load Fx = 100 N, Fy = -W = -100 N
!     on the bead, spring k = 10 N/mm in the x direction
      AK = 10.0D0
      FX = 100.0D0
      FY = -100.0D0
      DO MODE = 1, 2
         IF (MODE .EQ. 1) WRITE(*,*) 'tangent from A only (K = k)'
         IF (MODE .EQ. 2) WRITE(*,*) 'full tangent (K = k + 2 c W)'
         UU = 0.0D0
         DO IT = 1, 12
            U(1,1) = UU
            U(1,2) = UU
            CALL MPC(VV,A,JDOF,MDOF,N,1,X,U,UINIT,MAXDOF,LMPC,1,1,
     1               TIME,NT,NF,TEMP,FIELD,LTRAN,TRAN)
!           residual of the reduced equation: Fx + Fy dv/du - k u
            DVDU = -A(2)/A(1)
            RES = FX + FY*DVDU - AK*UU
            WRITE(*,'(I4,2F14.8,ES12.3)') IT-1, UU, VV, RES
            IF (ABS(RES) .LT. 1.0D-10) EXIT
            IF (MODE .EQ. 1) THEN
               UU = UU + RES/AK
            ELSE
               UU = UU + RES/(AK + 2.0D0*1.0D-2*(-FY))
            ENDIF
         ENDDO
      ENDDO
      END
