      SUBROUTINE UMESHMOTION(UREF,ULOCAL,NODE,NNDOF,
     1 LNODETYPE,ALOCAL,NDIM,TIME,DTIME,PNEWDT,
     2 KSTEP,KINC,KMESHSWEEP,JMATYP,JGVBLOCK,LSMOOTH)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION ULOCAL(NDIM), ALOCAL(NDIM,*), TIME(2)
      DIMENSION JMATYP(*), JGVBLOCK(*), ARRAY(15)
!
!     Archard wear, Eq. (9.4-1): recession velocity = AKW * p * VSLIP
!     AKW in mm^2/N, VSLIP in mm/s, p in MPa  ->  rate in mm/s
!     DWMAX: largest recession allowed in one increment (mm)
      PARAMETER (AKW = 1.0D-9, VSLIP = 100.0D0, DWMAX = 5.0D-3)
!     outward normal of the wearing face in global coordinates (+Y)
      PARAMETER (YOUT = 1.0D0)
!
      IF (LNODETYPE .LT. 3 .OR. LNODETYPE .GT. 5) RETURN
      CALL GETVRN(NODE, 'CPRESS', ARRAY, JRCD, JGVBLOCK, 0)
      IF (JRCD .NE. 0) RETURN
      PRESS = ARRAY(1)
      RATE = AKW*PRESS*VSLIP
!     local normal = direction NDIM; which way does it point?
      SGN = SIGN(1.0D0, YOUT*ALOCAL(2,NDIM))
      ULOCAL(NDIM) = -SGN*RATE
      IF (RATE*DTIME .GT. DWMAX) PNEWDT = MIN(PNEWDT, 
     1    0.8D0*DWMAX/(RATE*DTIME))
      RETURN
      END
