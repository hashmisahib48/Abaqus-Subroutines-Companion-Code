      PROGRAM DRVWEA
!     Driver: UMESHMOTION (ex9_4_wear.f) called once per increment for
!     one surface node of a block on a moving rigid counterface.
!     The stub GETVRN supplies the pressure of the model
!       IMODE = 1: load control,          p = P0
!       IMODE = 2: displacement control,  p = CMOD (DELTA0 - h)/BLEN
!     After each call the mesh velocity is converted to a global
!     displacement, h = recession of the surface (mm).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION ULOCAL(2), ALOCAL(2,2), TIME(2), JMATYP(1), JGV(1)
      COMMON /WSTUB/ HW, DELTA0, CMOD, BLEN, P0, IMODE
      PARAMETER (AKW = 1.0D-9, VS = 100.0D0)
      CMOD = 3000.0D0*0.6D0/(1.4D0*0.2D0)
      BLEN = 10.0D0
      DELTA0 = 0.05D0
      P0 = CMOD*DELTA0/BLEN
      TAU = BLEN/(AKW*VS*CMOD)
      TTOT = 20000.0D0
      WRITE(*,'(A,F10.4,A,F10.3,A)') 'p0 = ', P0, ' MPa   tau = ', TAU,
     1   ' s'
      WRITE(*,'(A)') 'IMODE  flip  NINC   dt/tau   h(T) mm   exact mm'
     1 //'   rel.err'
      DO IMODE = 1, 2
         DO IFLIP = 0, 1
            DO NI = 5, 80, 5
               IF (NI .NE. 5 .AND. NI .NE. 10 .AND. NI .NE. 20 .AND.
     1             NI .NE. 40 .AND. NI .NE. 80) CYCLE
               IF (IFLIP .EQ. 1 .AND. NI .NE. 10) CYCLE
               DT = TTOT/NI
               HW = 0.0D0
               ALOCAL = 0.0D0
               ALOCAL(1,1) = 1.0D0
               ALOCAL(2,2) = 1.0D0
               IF (IFLIP .EQ. 1) ALOCAL(2,2) = -1.0D0
               TIME = 0.0D0
               DO K = 1, NI
                  ULOCAL = 0.0D0
                  PNEWDT = 1.0D5
                  TIME(1) = K*DT
                  TIME(2) = K*DT
                  CALL UMESHMOTION(0.0D0,ULOCAL,1,2,5,ALOCAL,2,TIME,DT,
     1                 PNEWDT,1,K,1,JMATYP,JGV,LSMOOTH)
!                 global y velocity = sum ALOCAL(2,k) ULOCAL(k)
                  VY = ALOCAL(2,1)*ULOCAL(1) + ALOCAL(2,2)*ULOCAL(2)
                  HW = HW - VY*DT
               ENDDO
               IF (IMODE .EQ. 1) THEN
                  HEX = AKW*P0*VS*TTOT
               ELSE
                  HEX = DELTA0*(1.0D0 - EXP(-TTOT/TAU))
               ENDIF
               WRITE(*,'(I4,I7,I7,F10.4,2F11.6,ES11.2)') IMODE, IFLIP,
     1              NI, DT/TAU, HW, HEX, (HW-HEX)/HEX
            ENDDO
         ENDDO
      ENDDO
!     PNEWDT test: pressure P0, DTIME large
      IMODE = 1
      ULOCAL = 0.0D0
      PNEWDT = 1.0D5
      CALL UMESHMOTION(0.0D0,ULOCAL,1,2,5,ALOCAL,2,TIME,2000.0D0,
     1     PNEWDT,1,1,1,JMATYP,JGV,LSMOOTH)
      WRITE(*,'(A,2F12.6)') 'PNEWDT for DTIME = 2000 s, rate*DTIME:',
     1     PNEWDT, AKW*P0*VS*2000.0D0
      END
