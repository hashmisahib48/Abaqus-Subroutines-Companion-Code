      SUBROUTINE MPC(UE,A,JDOF,MDOF,N,JTYPE,X,U,UINIT,MAXDOF,
     1 LMPC,KSTEP,KINC,TIME,NT,NF,TEMP,FIELD,LTRAN,TRAN)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION UE(MDOF), A(MDOF,MDOF,N), JDOF(MDOF,N), X(6,N),
     1 U(MAXDOF,N), UINIT(MAXDOF,N), TIME(2), TEMP(NT,N),
     2 FIELD(NF,NT,N), LTRAN(N), TRAN(3,3,N)
!     pantograph, C = node 1, B = node 2, P = node 3
      RHO = (X(1,1)-X(1,3))/(X(1,3)-X(1,2))
      IF (KSTEP .EQ. 1) LMPC = 0
      DO I = 1, 2
         JDOF(1,I) = I
         JDOF(2,I) = I
         JDOF(3,I) = I
         A(I,I,1) = 1.0D0
         A(I,I,2) = RHO
         A(I,I,3) = 1.0D0 + RHO
         UE(I) = UINIT(I,3) + RHO*(UINIT(I,2) - UINIT(I,3))
      ENDDO
      RETURN
      END
