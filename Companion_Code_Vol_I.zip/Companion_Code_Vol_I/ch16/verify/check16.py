"""Chapter 16 verification: compile every listing, run the drivers, compare with closed forms.
usage: python3 check16.py   (writes results.json, uni.dat)"""
import subprocess, json, glob, os, re, math
import numpy as np
from scipy.integrate import solve_ivp
HERE=os.path.dirname(os.path.abspath(__file__)); CODE=os.path.join(HERE,'..','code'); os.chdir(HERE)
INC='/home/claude/book/lib/aba'; FL=['-ffixed-form','-ffixed-line-length-none','-std=legacy','-I'+INC]
def sh(c): return subprocess.run(c,shell=True,capture_output=True,text=True)
# 1. compile every file
nok=0
for f in sorted(glob.glob(CODE+'/*.f')):
    r=sh('gfortran -c '+' '.join(FL)+' '+f+' -o /dev/null')
    ok=r.returncode==0 and 'Error' not in r.stderr
    print(('OK   ' if ok else 'FAIL ')+os.path.basename(f)); nok+=ok
    if not ok: print(r.stderr[:600])
    over=[i+1 for i,l in enumerate(open(f).read().split('\n')) if len(l)>72]
    if over: print('  >72 col lines:',over)
# 2. link and run
C=lambda n:CODE+'/'+n
sh('gfortran '+' '.join(FL)+f' {C("ex16_drv.f")} {C("ex16_4_vumat_j2.f")} {C("ex16_ref_umat.f")} -o drv')
sh('gfortran '+' '.join(FL)+f' {C("ex16_drv.f")} {C("ex16_3_vumat_el.f")} {C("ex16_ref_umat.f")} -o drv_el')
sh('gfortran '+' '.join(FL)+f' {C("ex16_comp_drv.f")} {C("ex16_7_vuhard.f")} {C("ex16_8_vuexpan.f")} {C("ex16_9_vucharlength.f")} -o comp')
o1=sh('./drv').stdout; o2=sh('./drv_el el').stdout.strip(); o3=sh('./comp').stdout
print(o1);print('--- elastic routine, T3:');print(o2);print(o3)
R={}
E,nu,sy0,Hm=210000.,0.3,250.,1000.
G=E/2/(1+nu); lam=E*nu/((1+nu)*(1-2*nu))
# T3 numbers from the elastic routine
R['sig12_ok']=float(re.search(r'strainInc = gamma/2\s+([\d.]+)',o2).group(1))
R['sig12_bad']=float(re.search(r'strainInc = gamma\s+([\d.]+)',o2).group(1))
print('G*gamma =',G*1e-3,'expected',R['sig12_ok'])
# T1
for k,pat in [('d_sig',r'dSigma\| VUMAT-UMAT \(MPa\)\s+(\S+)'),('d_peeq',r'dPEEQ\|\s+(\S+)'),('d_ddsdde',r'DDSDDE vs FD\s+(\S+)'),('d_energy',r'enerInelas - SPD\| \(MPa\)\s+(\S+)'),('n_plastic',r'block-increments\s+(\S+)')]:
    R[k]=float(re.search(pat,o1).group(1))
# T2 closed form
d=np.loadtxt('uni.dat'); eps,sig,p,Wi,Wd,s22=d.T
Et=E*Hm/(E+Hm); ey=sy0/E
load=slice(0,200)
cf=np.where(eps[load]<=ey,E*eps[load],sy0+Et*(eps[load]-ey))
R['uni_maxdev_load']=float(np.abs(sig[load]-cf).max()); R['uni_max_s22']=float(np.abs(s22).max())
e1=eps[199]; s1=sy0+Et*(e1-ey); p1=e1-s1/E
R['uni_eps']=float(e1); R['uni_sig_vumat']=float(sig[199]); R['uni_sig_cf']=s1
R['uni_p_vumat']=float(p[199]); R['uni_p_cf']=p1
diss=sy0*p1+0.5*Hm*p1**2; el=0.5*s1**2/E
R['uni_diss_vumat']=float(Wd[199]); R['uni_diss_cf']=diss
R['uni_Wint_vumat']=float(Wi[199]); R['uni_Wint_cf']=diss+el; R['uni_elastic_cf']=el
# unloading to eps=0: reverse yield at -s1, then plastic with Et
dr=2*s1/E; s_end=-s1-Et*(e1-dr)
R['uni_end_sig_vumat']=float(sig[399]); R['uni_end_sig_cf']=s_end; R['uni_end_p_vumat']=float(p[399])
# cf end p: p grows by (e1-dr)*E/(E+Hm)
R['uni_end_p_cf']=p1+(e1-dr)*E/(E+Hm)
# T4
m=re.search(r'initial call: s11, s22, PEEQ\s+(\S+)\s+(\S+)\s+(\S+)',o1); R['init']=[float(x) for x in m.groups()]
m=re.search(r'ordinary call: s11, s22, PEEQ\s+(\S+)\s+(\S+)\s+(\S+)',o1); R['ord']=[float(x) for x in m.groups()]
R['init_cf']=[(lam+2*G)*0.01,lam*0.01]
# wave speed / stable increment
def cd(Ey,n,rho): return math.sqrt(Ey*(1-n)/((1+n)*(1-2*n))/rho)
R['cd_steel']=cd(210000,.3,7.85e-9); R['cd_al']=cd(70000,.33,2.7e-9)
R['dt_steel_1mm']=1/R['cd_steel']; R['dt_al_0p5']=0.5/R['cd_al']
R['n_steel_1ms']=1e-3/R['dt_steel_1mm']
# mass scaling example: density x100 -> dt x10
R['dt_steel_1mm_rho100']=1/cd(210000,.3,7.85e-7)
# T5: VUHARD
m=re.findall(r'H case (\d) C=\s*(\S+) sigma\(0.05\)=\s*(\S+) p=\s*(\S+)',o3); R['H']=[[float(x) for x in t] for t in m]
def h(p): return 250+150*(1-np.exp(-10*p))
def dh(p): return 1500*np.exp(-10*p)
sol=solve_ivp(lambda e,y:[E*dh(y[1])/(E+dh(y[1])),E/(E+dh(y[1]))],[250/E,0.05],[250.,0.],rtol=1e-11,atol=1e-12)
R['H_cf0']=[float(sol.y[0,-1]),float(sol.y[1,-1])]
def rate_case(edot,C=0.03,pd0=1.0):
    ty=250/(E*edot)
    def f(t,y):
        s,p=y; hh=h(p); pd=pd0*(np.exp((s/hh-1)/C)-1) if s>hh else 0.
        return [E*(edot-pd),pd]
    tf=0.05/edot; sol=solve_ivp(f,[ty,tf],[250.,0.],method='Radau',rtol=1e-10,atol=1e-12,max_step=tf/2000)
    return float(sol.y[0,-1]),float(sol.y[1,-1])
R['H_cf10']=rate_case(10.); R['H_cf100']=rate_case(100.)
R['H_fd']=[float(x) for x in re.findall(r'analytic, FD\s+(\S+)\s+(\S+)',o3)[0]]+[float(x) for x in re.findall(r'analytic, FD\s+(\S+)\s+(\S+)',o3)[1]]
R['H_y']=float(re.search(r'yield\(0.02, 5\)\s+(\S+)',o3).group(1))
R['H_y_cf']=h(0.02)*(1+0.03*math.log(1+5.))
# VUEXPAN
R['X_tot']=float(re.search(r'20->520 C\s+(\S+)',o3).group(1)); R['X_cf']=1.1e-5*500+7e-9/2*(520**2-20**2)
R['X_const']=1.1e-5*500+7e-9*20*500  # secant coefficient alpha(20) constant
R['X_dL']=100*R['X_tot']
# VUCHARLENGTH
cl=[float(x) for x in re.findall(r'charLength\s+(\S+)',o3)]; R['CL']=cl
def shoe(P):
    P=np.array(P);x,y=P[:,0],P[:,1]; return 0.5*abs(np.dot(x,np.roll(y,-1))-np.dot(y,np.roll(x,-1)))
quads=[[(0,0),(1,0),(1,1),(0,1)],[(0,0),(2,0),(2,.5),(0,.5)],[(0,0),(2,0),(2.5,1),(.5,1)],[(0,0),(3,0),(2,2),(0,1)]]
R['CL_cf']=[math.sqrt(shoe(q)) for q in quads]+[1.0,(7/3)**(1/3)]
Gf,ft=0.1,3.0   # N/mm, MPa
R['cb']=[[Lc,2*Gf/(ft*Lc)] for Lc in (0.5,1.0,2.0,4.0)]
json.dump(R,open('results.json','w'),indent=1)
print(json.dumps(R,indent=1)); print('compiled OK:',nok)
