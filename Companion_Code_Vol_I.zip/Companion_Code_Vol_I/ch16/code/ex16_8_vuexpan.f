      SUBROUTINE VUEXPAN(
     1  NBLOCK, NDIR, NSHR, NEXPANTYPE,
     2  NELEM, NINTPT, NLAYER, NSECTPT,
     3  STEPTIME, TOTALTIME, DT, CMNAME,
     4  NSTATEV, NFIELDV, NPROPS, PROPS,
     5  TEMPOLD, TEMPNEW, FIELDOLD, FIELDNEW,
     6  STATEOLD,
     7  STATENEW, STRAINTHINC, DSTRAINTHERDT)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION STRAINTHINC(NBLOCK,NDIR+NSHR),
     1  DSTRAINTHERDT(NBLOCK,NDIR+NSHR), NELEM(NBLOCK),
     2  PROPS(NPROPS), TEMPOLD(NBLOCK), TEMPNEW(NBLOCK),
     3  FIELDOLD(NBLOCK,NFIELDV), FIELDNEW(NBLOCK,NFIELDV),
     4  STATEOLD(NBLOCK,NSTATEV), STATENEW(NBLOCK,NSTATEV)
      CHARACTER*80 CMNAME
!
!     Isotropic expansion with an instantaneous coefficient
!     alpha(T) = A0 + A1*T   (1/K, T in deg C); PROPS: 1 A0, 2 A1
!     thermal strain eps(T) = A0*T + A1*T**2/2, so that the increment
!     eps(Tnew) - eps(Told) sums to eps(T) - eps(T0) over any history
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0)
      A0 = PROPS(1)
      A1 = PROPS(2)
      DO 100 K = 1, NBLOCK
         TO = TEMPOLD(K)
         TN = TEMPNEW(K)
         DEPS = A0*(TN - TO) + HALF*A1*(TN*TN - TO*TO)
         DO 10 I = 1, NDIR + NSHR
            STRAINTHINC(K,I)   = ZERO
            DSTRAINTHERDT(K,I) = ZERO
   10    CONTINUE
         DO 20 I = 1, NDIR
            STRAINTHINC(K,I)   = DEPS
            DSTRAINTHERDT(K,I) = A0 + A1*TN
   20    CONTINUE
  100 CONTINUE
      RETURN
      END
