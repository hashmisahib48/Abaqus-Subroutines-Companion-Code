      PROGRAM K16DRV
!     Driver for the J2 VUMAT of Chapter 16: calls it the way
!     Abaqus/Explicit would, and calls the reference UMAT in parallel.
!     Link:  gfortran ex16_drv.f ex16_4_vumat_j2.f ex16_ref_umat.f
!     (argument 'el': link ex16_3_vumat_el.f instead, run T3 only)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(4)
      CHARACTER*8 ARG
      PROPS = (/ 210000.0D0, 0.3D0, 250.0D0, 1000.0D0 /)
      CALL GETARG(1, ARG)
      IF (ARG(1:2) .NE. 'el') THEN
         CALL T1RUN(PROPS)
         CALL T2RUN(PROPS)
         CALL T4RUN(PROPS)
      ENDIF
      CALL T3RUN(PROPS)
      END
!
      SUBROUTINE CALLV(NBL, PROPS, DEN, DE, SO, SN, STO, STN,
     1                 EIO, EIN, EDO, EDN, TT, ST)
!     one VUMAT call for NBL points; DEN, DE, SO, ... as in Abaqus
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(4), DEN(NBL), DE(NBL,6), SO(NBL,6), SN(NBL,6)
      DIMENSION STO(NBL,2), STN(NBL,2), EIO(NBL), EIN(NBL)
      DIMENSION EDO(NBL), EDN(NBL)
      DIMENSION DTA(2*NBL+1), CO(NBL,3), CL(NBL), RS(NBL,3)
      DIMENSION T0(NBL), TU(NBL,6), DG(NBL,9), FD(NBL,1), TN(NBL)
      DIMENSION TUN(NBL,6), DGN(NBL,9), FDN(NBL,1), JI(8)
      CHARACTER*80 CMN
      DTA = 1.0D-6
      CMN = 'J2TEST'
      JI = 0
      CALL VUMAT(NBL, 3, 3, 2, 0, 4, JI, ST, TT, DTA, CMN, CO, CL,
     1  PROPS, DEN, DE, RS, T0, TU, DG, FD, SO, STO, EIO, EDO,
     2  TN, TUN, DGN, FDN, SN, STN, EIN, EDN)
      RETURN
      END
!
      SUBROUTINE CALLU(PROPS, SIG, PEEQ, DST, DDS, SPD)
!     one call of the reference UMAT (engineering shear, order 11,22,
!     33,12,13,23); SIG and PEEQ are updated in place
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(4), SIG(6), DST(6), DDS(6,6)
      DIMENSION SV(1), DDT(6), DRE(6), STRN(6), TM(2), PR(1), DP(1)
      DIMENSION CO(3), DR(3,3), DF0(3,3), DF1(3,3), JS(4)
      CHARACTER*80 CMN
      SV(1) = PEEQ
      STRN = 0.0D0
      TM = 0.0D0
      PR = 0.0D0
      DP = 0.0D0
      DR = 0.0D0
      DF0 = 0.0D0
      DF1 = 0.0D0
      CO = 0.0D0
      JS = 1
      PNEW = 1.0D0
      SSE = 0.0D0
      SCD = 0.0D0
      RPL = 0.0D0
      CMN = 'J2TEST'
      CALL UMAT(SIG, SV, DDS, SSE, SPD, SCD, RPL, DDT, DRE, DT0,
     1  STRN, DST, TM, 1.0D-6, 20.0D0, 0.0D0, PR, DP, CMN, 3, 3, 6, 1,
     2  PROPS, 4, CO, DR, PNEW, 1.0D0, DF0, DF1, 1, 1, 1, 1, JS, 1)
      PEEQ = SV(1)
      RETURN
      END
!
      SUBROUTINE PATH(IB, N, NINC, E)
!     tensor strain of block IB at increment N (E in VUMAT order)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION E(6), AMP(3,6), PHI(6)
      DATA PHI /0.0D0, 0.5D0, 1.0D0, 1.5D0, 2.0D0, 2.5D0/
      DATA AMP /0.006D0,0.0D0,0.004D0, 0.0D0,0.0D0,-0.002D0,
     1  0.0D0,0.0D0,0.001D0, 0.0D0,0.004D0,0.002D0,
     2  0.0D0,0.0D0,-0.0015D0, 0.0D0,0.0D0,0.003D0/
      PI = 3.14159265358979D0
      T = DBLE(N)/DBLE(NINC)
      DO 10 IC = 1, 6
         E(IC) = AMP(IB,IC)*(SIN(2.0D0*PI*T+PHI(IC)) - SIN(PHI(IC)))
   10 CONTINUE
      RETURN
      END
!
      SUBROUTINE T1RUN(PROPS)
!     T1: three multiaxial strain paths, VUMAT against the reference
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (NB = 3, NINC = 400)
      DIMENSION PROPS(4), SO(NB,6), SN(NB,6), STO(NB,2), STN(NB,2)
      DIMENSION EIO(NB), EIN(NB), EDO(NB), EDN(NB), DEN(NB), DE(NB,6)
      DIMENSION EO(6), EN(6), US(NB,6), UP(NB), SPDT(NB)
      DIMENSION DST(6), DDS(6,6), SA(6), SB(6), DS2(6), UDUM(6)
      INTEGER MAP(6)
      DATA MAP /1,2,3,4,6,5/
      DEN = 7.85D-9
      SO = 0.0D0
      STO = 0.0D0
      EIO = 0.0D0
      EDO = 0.0D0
      US = 0.0D0
      UP = 0.0D0
      SPDT = 0.0D0
      DIFS = 0.0D0
      DIFP = 0.0D0
      DIFT = 0.0D0
      DIFE = 0.0D0
      DIFW = 0.0D0
      NPL = 0
      DO 200 N = 1, NINC
         DO 20 IB = 1, NB
            CALL PATH(IB, N, NINC, EN)
            CALL PATH(IB, N-1, NINC, EO)
            DO 10 IC = 1, 6
               DE(IB,IC) = EN(IC) - EO(IC)
   10       CONTINUE
   20    CONTINUE
         CALL CALLV(NB, PROPS, DEN, DE, SO, SN, STO, STN, EIO, EIN,
     1              EDO, EDN, DBLE(N)*1.0D-6, DBLE(N)*1.0D-6)
         DO 100 IB = 1, NB
            DST(1) = DE(IB,1)
            DST(2) = DE(IB,2)
            DST(3) = DE(IB,3)
            DST(4) = 2.0D0*DE(IB,4)
            DST(5) = 2.0D0*DE(IB,6)
            DST(6) = 2.0D0*DE(IB,5)
!           central-difference check of the reference tangent
            DO 50 M = 1, 6
               H = 1.0D-8
               DO 30 K = 1, 6
                  SA(K) = US(IB,K)
                  SB(K) = US(IB,K)
                  DS2(K) = DST(K)
   30          CONTINUE
               DS2(M) = DST(M) + H
               PA = UP(IB)
               CALL CALLU(PROPS, SA, PA, DS2, DDS, DUM)
               DS2(M) = DST(M) - H
               PB = UP(IB)
               CALL CALLU(PROPS, SB, PB, DS2, DDS, DUM)
               DS2(M) = DST(M)
               DO 40 K = 1, 6
                  UDUM(K) = (SA(K) - SB(K))/(2.0D0*H)
   40          CONTINUE
               DO 45 K = 1, 6
                  SA(K) = US(IB,K)
   45          CONTINUE
               PA = UP(IB)
               CALL CALLU(PROPS, SA, PA, DST, DDS, DUM)
               DO 46 K = 1, 6
                  DIFT = MAX(DIFT, ABS(UDUM(K) - DDS(K,M))/2.1D5)
   46          CONTINUE
   50       CONTINUE
            SPD0 = 0.0D0
            CALL CALLU(PROPS, US(IB,:), UP(IB), DST, DDS, SPD0)
            SPDT(IB) = SPDT(IB) + SPD0
            IF (STN(IB,2) .GT. 0.5D0) NPL = NPL + 1
            DO 60 K = 1, 6
               DIFS = MAX(DIFS, ABS(SN(IB,K) - US(IB,MAP(K))))
   60       CONTINUE
            DIFP = MAX(DIFP, ABS(STN(IB,1) - UP(IB)))
            DIFE = MAX(DIFE, ABS(EDN(IB)*DEN(IB) - SPDT(IB)))
  100    CONTINUE
         SO = SN
         STO = STN
         EIO = EIN
         EDO = EDN
  200 CONTINUE
      WRITE(*,'(A,ES10.3)') 'T1 max |dSigma| VUMAT-UMAT (MPa)   ', DIFS
      WRITE(*,'(A,ES10.3)') 'T1 max |dPEEQ|                     ', DIFP
      WRITE(*,'(A,ES10.3)') 'T1 max rel err DDSDDE vs FD        ', DIFT
      WRITE(*,'(A,ES10.3)') 'T1 max |rho*enerInelas - SPD| (MPa)', DIFE
      WRITE(*,'(A,I6)')     'T1 plastic block-increments        ', NPL
      DO 300 IB = 1, NB
         WRITE(*,'(A,I1,A,6F11.4,A,F9.6)') 'T1 block ', IB,
     1     ' sigma(VUMAT order) ', (SN(IB,K), K=1,6), '  PEEQ ',
     2     STN(IB,1)
  300 CONTINUE
      RETURN
      END
!
      SUBROUTINE T2RUN(PROPS)
!     T2: uniaxial stress (s22 = s33 = 0 by secant iteration on the
!     lateral strain increment), load to 0.01, unload to 0
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (NINC = 400)
      DIMENSION PROPS(4), SO(1,6), SN(1,6), STO(1,2), STN(1,2)
      DIMENSION EIO(1), EIN(1), EDO(1), EDN(1), DEN(1), DE(1,6)
      DEN = 7.85D-9
      SO = 0.0D0
      STO = 0.0D0
      EIO = 0.0D0
      EDO = 0.0D0
      EPS = 0.0D0
      OPEN(11, FILE='uni.dat')
      DO 100 N = 1, NINC
         IF (N .LE. 200) THEN
            D1 = 0.01D0/200.0D0
         ELSE
            D1 = -0.01D0/200.0D0
         ENDIF
         X0 = -0.3D0*D1
         X1 = -0.5D0*D1
         DO 20 IT = 1, 30
            DE = 0.0D0
            DE(1,1) = D1
            DE(1,2) = X0
            DE(1,3) = X0
            CALL CALLV(1, PROPS, DEN, DE, SO, SN, STO, STN, EIO, EIN,
     1                 EDO, EDN, DBLE(N)*1.0D-6, DBLE(N)*1.0D-6)
            F0 = SN(1,2)
            IF (ABS(F0) .LT. 1.0D-10) GOTO 30
            DE(1,2) = X1
            DE(1,3) = X1
            CALL CALLV(1, PROPS, DEN, DE, SO, SN, STO, STN, EIO, EIN,
     1                 EDO, EDN, DBLE(N)*1.0D-6, DBLE(N)*1.0D-6)
            F1 = SN(1,2)
            XN = X1 - F1*(X1-X0)/(F1-F0)
            X0 = X1
            X1 = XN
   20    CONTINUE
   30    CONTINUE
         DE = 0.0D0
         DE(1,1) = D1
         DE(1,2) = X0
         DE(1,3) = X0
         CALL CALLV(1, PROPS, DEN, DE, SO, SN, STO, STN, EIO, EIN,
     1              EDO, EDN, DBLE(N)*1.0D-6, DBLE(N)*1.0D-6)
         EPS = EPS + D1
         WRITE(11,'(6ES20.12)') EPS, SN(1,1), STN(1,1),
     1      DEN(1)*EIN(1), DEN(1)*EDN(1), SN(1,2)
         SO = SN
         STO = STN
         EIO = EIN
         EDO = EDN
  100 CONTINUE
      CLOSE(11)
      WRITE(*,'(A,2F14.8)') 'T2 at eps=0 (end)  sigma11, PEEQ  ',
     1   SN(1,1), STN(1,1)
      WRITE(*,'(A,2ES14.6)') 'T2 end: rho*Eint, rho*Einel (MPa)  ',
     1   DEN(1)*EIN(1), DEN(1)*EDN(1)
      RETURN
      END
!
      SUBROUTINE T3RUN(PROPS)
!     T3: tensor shear convention.  gamma12 = 1.0e-3 (engineering)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(4), SO(1,6), SN(1,6), STO(1,2), STN(1,2)
      DIMENSION EIO(1), EIN(1), EDO(1), EDN(1), DEN(1), DE(1,6)
      DEN = 7.85D-9
      SO = 0.0D0
      STO = 0.0D0
      EIO = 0.0D0
      EDO = 0.0D0
      DE = 0.0D0
      DE(1,4) = 0.5D-3
      CALL CALLV(1, PROPS, DEN, DE, SO, SN, STO, STN, EIO, EIN,
     1           EDO, EDN, 1.0D-6, 1.0D-6)
      WRITE(*,'(A,F12.6)') 'T3 sigma12, strainInc = gamma/2 ', SN(1,4)
      DE(1,4) = 1.0D-3
      CALL CALLV(1, PROPS, DEN, DE, SO, SN, STO, STN, EIO, EIN,
     1           EDO, EDN, 1.0D-6, 1.0D-6)
      WRITE(*,'(A,F12.6)') 'T3 sigma12, strainInc = gamma   ', SN(1,4)
      RETURN
      END
!
      SUBROUTINE T4RUN(PROPS)
!     T4: initial call (totalTime = stepTime = 0, fictitious strain)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(4), SO(1,6), SN(1,6), STO(1,2), STN(1,2)
      DIMENSION EIO(1), EIN(1), EDO(1), EDN(1), DEN(1), DE(1,6)
      DEN = 7.85D-9
      SO = 0.0D0
      STO = 0.0D0
      EIO = 0.0D0
      EDO = 0.0D0
      DE = 0.0D0
      DE(1,1) = 0.01D0
      CALL CALLV(1, PROPS, DEN, DE, SO, SN, STO, STN, EIO, EIN,
     1           EDO, EDN, 0.0D0, 0.0D0)
      WRITE(*,'(A,2F12.4,F10.6)') 'T4 initial call: s11, s22, PEEQ ',
     1   SN(1,1), SN(1,2), STN(1,1)
      CALL CALLV(1, PROPS, DEN, DE, SO, SN, STO, STN, EIO, EIN,
     1           EDO, EDN, 1.0D-6, 1.0D-6)
      WRITE(*,'(A,2F12.4,F10.6)') 'T4 ordinary call: s11, s22, PEEQ',
     1   SN(1,1), SN(1,2), STN(1,1)
      RETURN
      END
