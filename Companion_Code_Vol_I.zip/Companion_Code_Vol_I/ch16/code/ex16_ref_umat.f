      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,
     2 PREDEF,DPRED,CMNAME,NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,
     3 DROT,PNEWDT,CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
!     Reference radial return (Abaqus/Standard interface, 3D only):
!     J2, linear isotropic hardening, consistent tangent.  Tensor
!     formulation with 3 x 3 matrices, independent of the VUMAT.
!     PROPS: 1 E (MPa), 2 NU, 3 SIGY0 (MPa), 4 H (MPa)
!     STATEV(1) = equivalent plastic strain.  Standard order
!     11,22,33,12,13,23 and ENGINEERING shear strain in DSTRAN.
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),DDSDDE(NTENS,NTENS),
     1 DDSDDT(NTENS),DRPLDE(NTENS),STRAN(NTENS),DSTRAN(NTENS),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3),
     3 DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),JSTEP(4)
      DIMENSION S(3,3), EP(3,3), SD(3,3), XN(3,3), DE(3,3), D4(3,3,3,3)
      INTEGER IA(6), JA(6)
      DATA IA /1,2,3,1,1,2/, JA /1,2,3,2,3,3/
      E = PROPS(1)
      XNU = PROPS(2)
      SY0 = PROPS(3)
      H = PROPS(4)
      G = 0.5D0*E/(1.0D0+XNU)
      BK = E/(3.0D0*(1.0D0-2.0D0*XNU))
      DO 5 I = 1, 3
         DO 4 J = 1, 3
            S(I,J) = 0.0D0
            DE(I,J) = 0.0D0
    4    CONTINUE
    5 CONTINUE
      DO 6 M = 1, 6
         S(IA(M),JA(M)) = STRESS(M)
         S(JA(M),IA(M)) = STRESS(M)
         F = 1.0D0
         IF (M .GT. 3) F = 0.5D0
         DE(IA(M),JA(M)) = F*DSTRAN(M)
         DE(JA(M),IA(M)) = F*DSTRAN(M)
    6 CONTINUE
      TRE = DE(1,1) + DE(2,2) + DE(3,3)
      DO 8 I = 1, 3
         DO 7 J = 1, 3
            S(I,J) = S(I,J) + 2.0D0*G*DE(I,J)
            IF (I .EQ. J) S(I,J) = S(I,J) + (BK-2.0D0*G/3.0D0)*TRE
    7    CONTINUE
    8 CONTINUE
      PM = (S(1,1)+S(2,2)+S(3,3))/3.0D0
      SN = 0.0D0
      DO 10 I = 1, 3
         DO 9 J = 1, 3
            SD(I,J) = S(I,J)
            IF (I .EQ. J) SD(I,J) = SD(I,J) - PM
            SN = SN + SD(I,J)**2
    9    CONTINUE
   10 CONTINUE
      SN = SQRT(SN)
      Q = SQRT(1.5D0)*SN
      SYO = SY0 + H*STATEV(1)
      DP = 0.0D0
      THETA = 1.0D0
      THB = 0.0D0
      IF (Q .GT. SYO) THEN
         DP = (Q - SYO)/(3.0D0*G + H)
         THETA = 1.0D0 - 3.0D0*G*DP/Q
         THB = 3.0D0*G/(3.0D0*G+H) - (1.0D0-THETA)
      ENDIF
      DO 12 I = 1, 3
         DO 11 J = 1, 3
            XN(I,J) = SD(I,J)/SN
            S(I,J) = THETA*SD(I,J)
            IF (I .EQ. J) S(I,J) = S(I,J) + PM
   11    CONTINUE
   12 CONTINUE
      STATEV(1) = STATEV(1) + DP
      DO 13 M = 1, 6
         STRESS(M) = S(IA(M),JA(M))
   13 CONTINUE
!     consistent tangent D = K 1x1 + 2G theta (I - 1x1/3) - 2G thb n x n
      DO 17 I = 1, 3
       DO 16 J = 1, 3
        DO 15 K = 1, 3
         DO 14 L = 1, 3
          X = 0.5D0*(DEL(I,K)*DEL(J,L) + DEL(I,L)*DEL(J,K))
          D4(I,J,K,L) = (BK-2.0D0*G*THETA/3.0D0)*DEL(I,J)*DEL(K,L)
     1                + 2.0D0*G*THETA*X - 2.0D0*G*THB*XN(I,J)*XN(K,L)
   14    CONTINUE
   15   CONTINUE
   16  CONTINUE
   17 CONTINUE
      DO 19 M = 1, 6
         DO 18 N = 1, 6
            DDSDDE(M,N) = D4(IA(M),JA(M),IA(N),JA(N))
   18    CONTINUE
   19 CONTINUE
      SPD = SPD + DP*(SYO + 0.5D0*H*DP)
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION DEL(I, J)
      INTEGER I, J
      DEL = 0.0D0
      IF (I .EQ. J) DEL = 1.0D0
      RETURN
      END
