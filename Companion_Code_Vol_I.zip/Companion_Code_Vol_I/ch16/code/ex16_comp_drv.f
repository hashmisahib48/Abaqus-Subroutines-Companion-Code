      PROGRAM K16COMP
!     Drivers for VUHARD, VUEXPAN and VUCHARLENGTH (Chapter 16).
!     gfortran ex16_comp_drv.f ex16_7_vuhard.f ex16_8_vuexpan.f
!              ex16_9_vucharlength.f
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      CALL HRUN
      CALL XRUN
      CALL CRUN
      END
!
      SUBROUTINE CALLH(PROPS, P, PDOT, YLD, DYP, DYR)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(5), JE(1), TO(1), TN(1), FO(1,1), FN(1,1)
      DIMENSION SOLD(1,1), SNEW(1,1), EP(1), ER(1), Y(1), DT(1)
      DIMENSION DY(1,2)
      CHARACTER*80 CMN
      EP(1) = P
      ER(1) = PDOT
      CMN = 'VOCE'
      CALL VUHARD(1, JE, 1, 1, 1, 0, 0.0D0, 0.0D0, 1.0D-5, CMN, 1, 0,
     1  5, PROPS, TO, TN, FO, FN, SOLD, EP, ER, Y, DT, DY, SNEW)
      YLD = Y(1)
      DYP = DY(1,1)
      DYR = DY(1,2)
      RETURN
      END
!
      SUBROUTINE HRUN
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(5)
      E = 210000.0D0
      PROPS = (/ 250.0D0, 150.0D0, 10.0D0, 0.03D0, 1.0D0 /)
!     derivative check by central differences at p = 0.02, pdot = 5
      P0 = 0.02D0
      R0 = 5.0D0
      HP = 1.0D-7
      HR = 1.0D-6
      CALL CALLH(PROPS, P0, R0, Y0, A1, A2)
      CALL CALLH(PROPS, P0+HP, R0, YP, B1, B2)
      CALL CALLH(PROPS, P0-HP, R0, YM, B1, B2)
      DPN = (YP - YM)/(2.0D0*HP)
      CALL CALLH(PROPS, P0, R0+HR, YP, B1, B2)
      CALL CALLH(PROPS, P0, R0-HR, YM, B1, B2)
      DRN = (YP - YM)/(2.0D0*HR)
      WRITE(*,'(A,F12.6)') 'H yield(0.02, 5)            ', Y0
      WRITE(*,'(A,2ES14.6)') 'H dy/dp  analytic, FD     ', A1, DPN
      WRITE(*,'(A,2ES14.6)') 'H dy/dpdot analytic, FD   ', A2, DRN
!     uniaxial return mapping with VUHARD: cases (C, strain rate)
      DO 100 IC = 1, 3
         IF (IC .EQ. 1) THEN
            PROPS(4) = 0.0D0
            DT = 1.0D-5
         ELSE IF (IC .EQ. 2) THEN
            PROPS(4) = 0.03D0
            DT = 1.0D-5
         ELSE
            PROPS(4) = 0.03D0
            DT = 1.0D-6
         ENDIF
         DEPS = 1.0D-4
         S = 0.0D0
         P = 0.0D0
         EPS = 0.0D0
         DO 50 N = 1, 500
            STR = S + E*DEPS
            CALL CALLH(PROPS, P, 0.0D0, Y0, YP1, YR1)
            DP = 0.0D0
            IF (STR .GT. Y0) THEN
               DP = (STR - Y0)/(E + YP1)
               DO 40 IT = 1, 30
                  CALL CALLH(PROPS, P+DP, DP/DT, Y1, YP1, YR1)
                  G = STR - E*DP - Y1
                  IF (ABS(G) .LT. 1.0D-10) GOTO 45
                  DPN = DP + G/(E + YP1 + YR1/DT)
                  IF (DPN .LE. 0.0D0) DPN = 0.5D0*DP
                  DP = DPN
   40          CONTINUE
   45          CONTINUE
            ENDIF
            S = STR - E*DP
            P = P + DP
            EPS = EPS + DEPS
   50    CONTINUE
         WRITE(*,'(A,I1,A,F8.4,A,F12.6,A,F10.7)') 'H case ', IC,
     1     ' C=', PROPS(4), ' sigma(0.05)=', S, ' p=', P
  100 CONTINUE
      RETURN
      END
!
      SUBROUTINE XRUN
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(2), TO(1), TN(1), FO(1,1), FN(1,1), NE(1)
      DIMENSION SO(1,1), SN(1,1), STH(1,6), DST(1,6)
      CHARACTER*80 CMN
      PROPS = (/ 1.1D-5, 7.0D-9 /)
      CMN = 'STEELX'
      TOT = 0.0D0
      T = 20.0D0
      DO 10 N = 1, 50
         TO(1) = T
         TN(1) = T + 10.0D0
         CALL VUEXPAN(1, 3, 3, 1, NE, 1, 1, 1, 0.0D0, 0.0D0, 1.0D0,
     1     CMN, 1, 0, 2, PROPS, TO, TN, FO, FN, SO, SN, STH, DST)
         TOT = TOT + STH(1,1)
         T = TN(1)
   10 CONTINUE
      WRITE(*,'(A,ES18.10)') 'X total thermal strain 20->520 C  ', TOT
      WRITE(*,'(A,ES14.6,F10.6)') 'X dStrain/dT at 520 C; shear', 
     1    DST(1,1), STH(1,4)
      RETURN
      END
!
      SUBROUTINE CRUN
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION CN2(4,4,2), CMP2(4,2), DIR(4,3,3), TT(4,3,3), PR(1)
      DIMENSION FL(4,1), SO(4,1), CL(4,1), JE(4), JT(3)
      DIMENSION CN3(2,8,3), CMP3(2,3), CL3(2,1), JE3(2), FL3(2,1)
      DIMENSION SO3(2,1), DIR3(2,3,3), TT3(2,3,3)
      CHARACTER*80 CMN
      CMN = 'CRACK'
      JT = (/ 3, 1, 1 /)
      CN2 = 0.0D0
!     element 1: unit square; 2: 2 x 0.5; 3: parallelogram; 4: general
      CN2(1,:,1) = (/ 0.0D0, 1.0D0, 1.0D0, 0.0D0 /)
      CN2(1,:,2) = (/ 0.0D0, 0.0D0, 1.0D0, 1.0D0 /)
      CN2(2,:,1) = (/ 0.0D0, 2.0D0, 2.0D0, 0.0D0 /)
      CN2(2,:,2) = (/ 0.0D0, 0.0D0, 0.5D0, 0.5D0 /)
      CN2(3,:,1) = (/ 0.0D0, 2.0D0, 2.5D0, 0.5D0 /)
      CN2(3,:,2) = (/ 0.0D0, 0.0D0, 1.0D0, 1.0D0 /)
      CN2(4,:,1) = (/ 0.0D0, 3.0D0, 2.0D0, 0.0D0 /)
      CN2(4,:,2) = (/ 0.0D0, 0.0D0, 2.0D0, 1.0D0 /)
      CALL VUCHARLENGTH(4, 0, 0, 1, 2, 4, 0, 1, 1, 1, JT, JE, 0.0D0,
     1  0.0D0, 1.0D0, CMN, CMP2, CN2, DIR, TT, PR, FL, SO, CL)
      DO 10 K = 1, 4
         WRITE(*,'(A,I1,A,F12.8)') 'C quad ', K, ' charLength ',
     1      CL(K,1)
   10 CONTINUE
      JT = (/ 6, 2, 1 /)
      CN3 = 0.0D0
!     element 1: 2 x 1 x 0.5 box; 2: frustum 2 x 2 -> 1 x 1, h = 1
      DO 20 I = 1, 8
         X = 0.0D0
         Y = 0.0D0
         Z = 0.0D0
         IF (I.EQ.2 .OR. I.EQ.3 .OR. I.EQ.6 .OR. I.EQ.7) X = 1.0D0
         IF (I.EQ.3 .OR. I.EQ.4 .OR. I.EQ.7 .OR. I.EQ.8) Y = 1.0D0
         IF (I .GE. 5) Z = 1.0D0
         CN3(1,I,1) = 2.0D0*X
         CN3(1,I,2) = Y
         CN3(1,I,3) = 0.5D0*Z
         IF (I .LE. 4) THEN
            CN3(2,I,1) = 2.0D0*X
            CN3(2,I,2) = 2.0D0*Y
         ELSE
            CN3(2,I,1) = 0.5D0 + X
            CN3(2,I,2) = 0.5D0 + Y
         ENDIF
         CN3(2,I,3) = Z
   20 CONTINUE
      CALL VUCHARLENGTH(2, 0, 0, 1, 3, 8, 0, 1, 1, 1, JT, JE3, 0.0D0,
     1  0.0D0, 1.0D0, CMN, CMP3, CN3, DIR3, TT3, PR, FL3, SO3, CL3)
      WRITE(*,'(A,F12.8)') 'C hex 1 charLength ', CL3(1,1)
      WRITE(*,'(A,F12.8)') 'C hex 2 charLength ', CL3(2,1)
      RETURN
      END
