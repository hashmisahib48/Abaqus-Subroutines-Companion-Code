      SUBROUTINE VUMAT(
     1  NBLOCK, NDIR, NSHR, NSTATEV, NFIELDV, NPROPS, JINFOARRAY,
     2  STEPTIME, TOTALTIME, DTARRAY, CMNAME, COORDMP, CHARLENGTH,
     3  PROPS, DENSITY, STRAININC, RELSPININC,
     4  TEMPOLD, STRETCHOLD, DEFGRADOLD, FIELDOLD,
     5  STRESSOLD, STATEOLD, ENERINTERNOLD, ENERINELASOLD,
     6  TEMPNEW, STRETCHNEW, DEFGRADNEW, FIELDNEW,
     7  STRESSNEW, STATENEW, ENERINTERNNEW, ENERINELASNEW)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION PROPS(NPROPS), DENSITY(NBLOCK), COORDMP(NBLOCK,*),
     1  CHARLENGTH(NBLOCK), DTARRAY(2*NBLOCK+1),
     2  STRAININC(NBLOCK,NDIR+NSHR), RELSPININC(NBLOCK,NSHR),
     3  TEMPOLD(NBLOCK), STRETCHOLD(NBLOCK,NDIR+NSHR),
     4  DEFGRADOLD(NBLOCK,NDIR+NSHR+NSHR), FIELDOLD(NBLOCK,NFIELDV),
     5  STRESSOLD(NBLOCK,NDIR+NSHR), STATEOLD(NBLOCK,NSTATEV),
     6  ENERINTERNOLD(NBLOCK), ENERINELASOLD(NBLOCK),
     7  TEMPNEW(NBLOCK), STRETCHNEW(NBLOCK,NDIR+NSHR),
     8  DEFGRADNEW(NBLOCK,NDIR+NSHR+NSHR), FIELDNEW(NBLOCK,NFIELDV),
     9  STRESSNEW(NBLOCK,NDIR+NSHR), STATENEW(NBLOCK,NSTATEV),
     1  ENERINTERNNEW(NBLOCK), ENERINELASNEW(NBLOCK), JINFOARRAY(*)
      CHARACTER*80 CMNAME
!
!     J2 plasticity, linear isotropic hardening (3D, PE, AX)
!     PROPS: 1 E (MPa), 2 NU (-), 3 SIGY0 (MPa), 4 H (MPa)
!     STATE: 1 equivalent plastic strain (-), 2 plastic flag (0/1)
!     Stress order 11,22,33,12,23,31; strainInc holds TENSOR shear
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0, ONE = 1.0D0,
     1           TWO = 2.0D0, THREE = 3.0D0, ONEPT5 = 1.5D0)
      LOGICAL PACKGR
      E     = PROPS(1)
      XNU   = PROPS(2)
      SY0   = PROPS(3)
      HMOD  = PROPS(4)
      G     = HALF*E/(ONE + XNU)
      XLAM  = E*XNU/((ONE + XNU)*(ONE - TWO*XNU))
      THREEG = THREE*G
!     packager (initial) call: totalTime = stepTime = 0, fictitious
!     strains; return the elastic response and leave the state alone
      PACKGR = (TOTALTIME .EQ. ZERO .AND. STEPTIME .EQ. ZERO)
!
      DO 100 K = 1, NBLOCK
         TR = STRAININC(K,1) + STRAININC(K,2) + STRAININC(K,3)
         DO 10 I = 1, 3
            STRESSNEW(K,I) = STRESSOLD(K,I) + XLAM*TR
     1                     + TWO*G*STRAININC(K,I)
   10    CONTINUE
         DO 20 I = 4, 3 + NSHR
            STRESSNEW(K,I) = STRESSOLD(K,I) + TWO*G*STRAININC(K,I)
   20    CONTINUE
         DP = ZERO
         SYOLD = SY0 + HMOD*STATEOLD(K,1)
         IF (.NOT. PACKGR) THEN
!           deviatoric trial stress and von Mises equivalent stress
            PM = (STRESSNEW(K,1)+STRESSNEW(K,2)+STRESSNEW(K,3))/THREE
            SS = (STRESSNEW(K,1)-PM)**2 + (STRESSNEW(K,2)-PM)**2
     1         + (STRESSNEW(K,3)-PM)**2
            DO 30 I = 4, 3 + NSHR
               SS = SS + TWO*STRESSNEW(K,I)**2
   30       CONTINUE
            Q = SQRT(ONEPT5*SS)
!           radial return, Eqs. 16.4-2 to 16.4-4
            IF (Q .GT. SYOLD) THEN
               DP  = (Q - SYOLD)/(THREEG + HMOD)
               FAC = ONE - THREEG*DP/Q
               DO 40 I = 1, 3
                  STRESSNEW(K,I) = FAC*(STRESSNEW(K,I)-PM) + PM
   40          CONTINUE
               DO 50 I = 4, 3 + NSHR
                  STRESSNEW(K,I) = FAC*STRESSNEW(K,I)
   50          CONTINUE
            ENDIF
         ENDIF
         STATENEW(K,1) = STATEOLD(K,1) + DP
         STATENEW(K,2) = ZERO
         IF (DP .GT. ZERO) STATENEW(K,2) = ONE
!        energies per unit mass: work of the stresses, dissipation
         W = ZERO
         DO 60 I = 1, 3
            W = W + (STRESSOLD(K,I)+STRESSNEW(K,I))*STRAININC(K,I)
   60    CONTINUE
         DO 70 I = 4, 3 + NSHR
            W = W + TWO*(STRESSOLD(K,I)+STRESSNEW(K,I))
     1            *STRAININC(K,I)
   70    CONTINUE
         ENERINTERNNEW(K) = ENERINTERNOLD(K) + HALF*W/DENSITY(K)
         ENERINELASNEW(K) = ENERINELASOLD(K)
     1     + HALF*(SYOLD + SY0 + HMOD*STATENEW(K,1))*DP/DENSITY(K)
  100 CONTINUE
      RETURN
      END
