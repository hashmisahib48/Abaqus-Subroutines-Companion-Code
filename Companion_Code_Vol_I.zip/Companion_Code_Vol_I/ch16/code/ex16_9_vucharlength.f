      SUBROUTINE VUCHARLENGTH(
     1  NBLOCK, NFIELDV, NPROPS, NCOMP, NDIM, NNODE, NSTATEV,
     2  KSECPT, KLAYER, KINTPT, JELTYPE, JELEM,
     3  TOTALTIME, STEPTIME, DT,
     4  CMNAME, COORDMP, COORDNODE, DIRECT, T, PROPS,
     5  FIELD, STATEOLD,
     6  CHARLENGTH)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION JELTYPE(3), JELEM(NBLOCK), COORDMP(NBLOCK,NDIM),
     1  COORDNODE(NBLOCK,NNODE,NDIM), DIRECT(NBLOCK,3,3),
     2  T(NBLOCK,3,3), PROPS(NPROPS), STATEOLD(NBLOCK,NSTATEV),
     3  CHARLENGTH(NBLOCK,NCOMP), FIELD(NBLOCK,NFIELDV)
      CHARACTER*80 CMNAME
      DIMENSION X(8,3)
!
!     Characteristic length = sqrt(area) of a quadrilateral or
!     (volume)**(1/3) of a hexahedron, from the corner nodes only.
!     Other element shapes: the mean distance to the first node.
      PARAMETER (HALF = 0.5D0, THIRD = 1.0D0/3.0D0)
      DO 100 K = 1, NBLOCK
         IF (JELTYPE(1) .EQ. 3 .AND. NDIM .EQ. 2) THEN
            AREA = 0.0D0
            DO 10 I = 1, 4
               J = MOD(I,4) + 1
               AREA = AREA + HALF*(COORDNODE(K,I,1)*COORDNODE(K,J,2)
     1                           - COORDNODE(K,J,1)*COORDNODE(K,I,2))
   10       CONTINUE
            CL = SQRT(ABS(AREA))
         ELSE IF (JELTYPE(1) .EQ. 6 .AND. NDIM .EQ. 3) THEN
            DO 12 I = 1, 8
               X(I,1) = COORDNODE(K,I,1)
               X(I,2) = COORDNODE(K,I,2)
               X(I,3) = COORDNODE(K,I,3)
   12       CONTINUE
            CALL K16_HEXVOL(X, VOL)
            CL = ABS(VOL)**THIRD
         ELSE
            CL = 0.0D0
            DO 20 I = 2, NNODE
               D2 = 0.0D0
               DO 15 J = 1, NDIM
                  D2 = D2 + (COORDNODE(K,I,J)-COORDNODE(K,1,J))**2
   15          CONTINUE
               CL = CL + SQRT(D2)/DBLE(NNODE-1)
   20       CONTINUE
         ENDIF
         DO 30 IC = 1, NCOMP
            CHARLENGTH(K,IC) = CL
   30    CONTINUE
  100 CONTINUE
      RETURN
      END
!
      SUBROUTINE K16_HEXVOL(X, VOL)
!     volume of an 8-node hexahedron, 2 x 2 x 2 Gauss quadrature
!     of det J (exact for trilinear geometry); nodes in Abaqus order
      DOUBLE PRECISION X(8,3), VOL, S(8,3), G, XI(3), DN(8,3), AJ(3,3)
      INTEGER I, J, K, L, IG, JG, KG
      DATA S /-1,1,1,-1,-1,1,1,-1, -1,-1,1,1,-1,-1,1,1,
     1        -1,-1,-1,-1,1,1,1,1/
      G = 1.0D0/SQRT(3.0D0)
      VOL = 0.0D0
      DO 50 IG = -1, 1, 2
       DO 40 JG = -1, 1, 2
        DO 30 KG = -1, 1, 2
         XI(1) = G*IG
         XI(2) = G*JG
         XI(3) = G*KG
         DO 10 I = 1, 8
            DN(I,1) = 0.125D0*S(I,1)*(1+S(I,2)*XI(2))*(1+S(I,3)*XI(3))
            DN(I,2) = 0.125D0*S(I,2)*(1+S(I,1)*XI(1))*(1+S(I,3)*XI(3))
            DN(I,3) = 0.125D0*S(I,3)*(1+S(I,1)*XI(1))*(1+S(I,2)*XI(2))
   10    CONTINUE
         DO 20 J = 1, 3
            DO 19 L = 1, 3
               AJ(J,L) = 0.0D0
               DO 18 K = 1, 8
                  AJ(J,L) = AJ(J,L) + DN(K,J)*X(K,L)
   18          CONTINUE
   19       CONTINUE
   20    CONTINUE
         VOL = VOL + AJ(1,1)*(AJ(2,2)*AJ(3,3)-AJ(2,3)*AJ(3,2))
     1             - AJ(1,2)*(AJ(2,1)*AJ(3,3)-AJ(2,3)*AJ(3,1))
     2             + AJ(1,3)*(AJ(2,1)*AJ(3,2)-AJ(2,2)*AJ(3,1))
   30   CONTINUE
   40  CONTINUE
   50 CONTINUE
      RETURN
      END
