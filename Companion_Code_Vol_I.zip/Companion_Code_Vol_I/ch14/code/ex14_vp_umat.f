      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),
     1 DDSDDE(NTENS,NTENS),DDSDDT(NTENS),DRPLDE(NTENS),
     2 STRAN(NTENS),DSTRAN(NTENS),TIME(2),PREDEF(1),DPRED(1),
     3 PROPS(NPROPS),COORDS(3),DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),
     4 JSTEP(4)
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0, ONE = 1.0D0,
     1           TWO = 2.0D0, THREE = 3.0D0)
      PARAMETER (MAXIT = 50, TOL = 1.0D-12)
      DIMENSION SIG0(6), STR(6), SD(6), XN(6), INTV(2), REALV(1)
      CHARACTER*8 CHARV(1)
!
!     Perzyna viscoplasticity: J2, linear isotropic hardening
!     PROPS(1) E (MPa)        PROPS(2) XNU (-)
!     PROPS(3) SY0 (MPa)      PROPS(4) H (MPa)
!     PROPS(5) TAUV (s)       PROPS(6) XM >= 1 (-)
!     PROPS(7) RHOMAX (-): largest fraction of the trial stress that
!              one increment may remove before PNEWDT is reduced
!     STATEV(1) equivalent viscoplastic strain kappa
!     STATEV(2) rate dkappa/dt (1/s)     STATEV(3) overstress f (MPa)
!
      IF (NDI .NE. 3 .OR. NPROPS .LT. 7 .OR. NSTATV .LT. 3 .OR.
     1    PROPS(6) .LT. ONE) THEN
         INTV(1) = NPROPS
         INTV(2) = NSTATV
         CALL STDB_ABQERR(-3, 'K14 VP: NPROPS=%I NSTATV=%I or NDI',
     1                    INTV, REALV, CHARV)
      ENDIF
      G = HALF*PROPS(1)/(ONE + PROPS(2))                  ! MPa
      XK = PROPS(1)/(THREE*(ONE - TWO*PROPS(2)))          ! MPa
      SY0 = PROPS(3)
      H = PROPS(4)
      XM = PROPS(6)
      C = THREE*G + H
!
!     elastic predictor
      DTH = DSTRAN(1) + DSTRAN(2) + DSTRAN(3)
      DO I = 1, NTENS
         SIG0(I) = STRESS(I)
         STR(I) = STRESS(I)
      ENDDO
      DO I = 1, 3
         STR(I) = STR(I) + XK*DTH + TWO*G*(DSTRAN(I) - DTH/THREE)
      ENDDO
      DO I = 4, NTENS
         STR(I) = STR(I) + G*DSTRAN(I)
      ENDDO
      PM = (STR(1) + STR(2) + STR(3))/THREE
      DO I = 1, NTENS
         SD(I) = STR(I)
         IF (I .LE. 3) SD(I) = STR(I) - PM
      ENDDO
      SS = SD(1)**2 + SD(2)**2 + SD(3)**2
      DO I = 4, NTENS
         SS = SS + TWO*SD(I)**2
      ENDDO
      QTR = SQRT(1.5D0*SS)
      FTR = QTR - (SY0 + H*STATEV(1))
!
!     viscoplastic corrector: scalar equation, Newton from DG = 0
      DG = ZERO
      CD = ZERO
      IF (FTR .GT. ZERO .AND. DTIME .GT. ZERO) THEN
         RT = DTIME/(PROPS(5)*SY0**XM)
         DO IT = 1, MAXIT
            FOV = MAX(FTR - C*DG, ZERO)
            RES = DG - RT*FOV**XM
            IF (ABS(RES) .LE. TOL*MAX(DG, 1.0D-12)) EXIT
            DG = DG - RES/(ONE + RT*XM*C*FOV**(XM - ONE))
         ENDDO
         FOV = MAX(FTR - C*DG, ZERO)
         CD = RT*XM*FOV**(XM - ONE)
         STATEV(2) = DG/DTIME
         STATEV(3) = FOV
      ELSE
         STATEV(2) = ZERO
         STATEV(3) = MAX(FTR, ZERO)
      ENDIF
      THETA = ONE - THREE*G*DG/QTR
      STATEV(1) = STATEV(1) + DG
!
!     stress update (radial return) and energies
      CP = 1.5D0*DG/QTR
      WE = ZERO
      DO I = 1, NTENS
         STRESS(I) = THETA*SD(I)
         IF (I .LE. 3) STRESS(I) = STRESS(I) + PM
         DEP = CP*SD(I)
         IF (I .GT. 3) DEP = TWO*DEP
         WE = WE + HALF*(SIG0(I) + STRESS(I))*(DSTRAN(I) - DEP)
      ENDDO
      SSE = SSE + WE
      SPD = SPD + (QTR - THREE*G*DG)*DG
!
!     Jacobian: elastic part, radial-return part, and the term of
!     the overstress, Eq. (14.10-5)
      DO J = 1, NTENS
         DO I = 1, NTENS
            DDSDDE(I,J) = ZERO
         ENDDO
      ENDDO
      DO J = 1, 3
         DO I = 1, 3
            DDSDDE(I,J) = XK - TWO*G*THETA/THREE
         ENDDO
         DDSDDE(J,J) = DDSDDE(J,J) + TWO*G*THETA
      ENDDO
      DO J = 4, NTENS
         DDSDDE(J,J) = G*THETA
      ENDDO
      IF (DG .GT. ZERO) THEN
         A = -6.0D0*G*G*(CD/(ONE + C*CD) - DG/QTR)
         DO I = 1, NTENS
            XN(I) = SD(I)/SQRT(SS)
         ENDDO
         DO J = 1, NTENS
            DO I = 1, NTENS
               DDSDDE(I,J) = DDSDDE(I,J) + A*XN(I)*XN(J)
            ENDDO
         ENDDO
      ENDIF
!
!     accuracy control, Eq. (14.9-1)
      IF (DG .GT. ZERO) THEN
         RHO = THREE*G*DG/QTR
         IF (RHO .GT. PROPS(7)) THEN
            PNEWDT = MIN(PNEWDT, MAX(0.1D0, 0.9D0*PROPS(7)/RHO))
         ENDIF
      ENDIF
      RETURN
      END
