      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),
     1 DDSDDE(NTENS,NTENS),DDSDDT(NTENS),DRPLDE(NTENS),
     2 STRAN(NTENS),DSTRAN(NTENS),TIME(2),PREDEF(1),DPRED(1),
     3 PROPS(NPROPS),COORDS(3),DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),
     4 JSTEP(4)
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0, ONE = 1.0D0,
     1           TWO = 2.0D0, THREE = 3.0D0, MAXP = 8)
      DIMENSION DE(6), DS(6), HB(6), ET(6), INTV(2), REALV(1)
      CHARACTER*8 CHARV(1)
!
!     Generalised Maxwell (Prony) viscoelasticity, Abaqus conventions
!     PROPS(1) = E0   instantaneous Young's modulus (MPa)
!     PROPS(2) = XNU0 instantaneous Poisson's ratio (-)
!     PROPS(3) = NPR  number of Prony terms (<= 8)
!     PROPS(4+3*(I-1)) = g_i, +1 = k_i (-), +2 = tau_i (s)
!     STATEV(6*(I-1)+1..6)  branch deviatoric stress h_i, tensor
!                           components 11,22,33,12,13,23 (MPa)
!     STATEV(6*NPR+I)       branch volumetric stress (MPa)
!
      NPR = NINT(PROPS(3))
      IF (NDI .NE. 3 .OR. NPR .LT. 1 .OR. NPR .GT. MAXP .OR.
     1    NPROPS .NE. 3 + 3*NPR .OR. NSTATV .LT. 7*NPR) THEN
         INTV(1) = NPROPS
         INTV(2) = NSTATV
         CALL STDB_ABQERR(-3, 'K14 VE: bad NDI/NPROPS=%I/NSTATV=%I',
     1                    INTV, REALV, CHARV)
      ENDIF
      G0 = HALF*PROPS(1)/(ONE + PROPS(2))                 ! MPa
      XK0 = PROPS(1)/(THREE*(ONE - TWO*PROPS(2)))         ! MPa
      GINF = ONE
      XKINF = ONE
      DO I = 1, NPR
         GINF = GINF - PROPS(4+3*(I-1))
         XKINF = XKINF - PROPS(5+3*(I-1))
      ENDDO
!
!     rotate the tensor state variables with the body (Section 11.9)
      IF (JSTEP(3) .NE. 0) THEN
         DO I = 1, NPR
            CALL K14_ROTS(STATEV(6*(I-1)+1), DROT)
         ENDDO
      ENDIF
!
!     deviatoric strain increment (tensor) and volume change
      DTH = DSTRAN(1) + DSTRAN(2) + DSTRAN(3)
      DO I = 1, 3
         DE(I) = DSTRAN(I) - DTH/THREE
      ENDDO
      DO I = 4, 6
         DE(I) = ZERO
         IF (I .LE. NTENS) DE(I) = HALF*DSTRAN(I)
      ENDDO
      DO I = 1, 6
         DS(I) = TWO*G0*GINF*DE(I)
      ENDDO
      DP = XK0*XKINF*DTH
      ALG = GINF
      ALK = XKINF
!
!     exponential update of every branch, Eqs. (14.3-3), (14.3-4)
      DO IB = 1, NPR
         GI = PROPS(4+3*(IB-1))
         XKI = PROPS(5+3*(IB-1))
         CALL K14_AB(DTIME, PROPS(6+3*(IB-1)), A, BB)
         DO J = 1, 6
            K = 6*(IB-1) + J
            HNEW = A*STATEV(K) + TWO*G0*GI*BB*DE(J)
            DS(J) = DS(J) + HNEW - STATEV(K)
            STATEV(K) = HNEW
         ENDDO
         K = 6*NPR + IB
         HNEW = A*STATEV(K) + XK0*XKI*BB*DTH
         DP = DP + HNEW - STATEV(K)
         STATEV(K) = HNEW
         ALG = ALG + GI*BB
         ALK = ALK + XKI*BB
      ENDDO
!
!     stress update; the energies use the old and new stress
      WORK = ZERO
      DO I = 1, NTENS
         STOLD = STRESS(I)
         IF (I .LE. 3) THEN
            STRESS(I) = STRESS(I) + DS(I) + DP
         ELSE
            STRESS(I) = STRESS(I) + DS(I)
         ENDIF
         WORK = WORK + HALF*(STOLD + STRESS(I))*DSTRAN(I)
      ENDDO
!
!     Jacobian, Eq. (14.3-6): algorithmic moduli GA, XKA
      GA = G0*ALG
      XKA = XK0*ALK
      DO J = 1, NTENS
         DO I = 1, NTENS
            DDSDDE(I,J) = ZERO
         ENDDO
      ENDDO
      DO J = 1, 3
         DO I = 1, 3
            DDSDDE(I,J) = XKA - TWO*GA/THREE
         ENDDO
         DDSDDE(J,J) = DDSDDE(J,J) + TWO*GA
      ENDDO
      DO J = 4, NTENS
         DDSDDE(J,J) = GA
      ENDDO
!
!     stored energy (SSE) and dissipation (SCD) per unit volume
      DO I = 1, NTENS
         ET(I) = STRAN(I) + DSTRAN(I)
      ENDDO
      TH = ET(1) + ET(2) + ET(3)
      ESQ = ZERO
      DO I = 1, 6
         EV = ZERO
         IF (I .LE. 3) EV = ET(I) - TH/THREE
         IF (I .GT. 3 .AND. I .LE. NTENS) EV = HALF*ET(I)
         ESQ = ESQ + EV*EV*(ONE + (I/4))
      ENDDO
      SSEN = HALF*XK0*XKINF*TH*TH + G0*GINF*ESQ
      DO IB = 1, NPR
         GI = PROPS(4+3*(IB-1))
         XKI = PROPS(5+3*(IB-1))
         HSQ = ZERO
         DO J = 1, 6
            HSQ = HSQ + STATEV(6*(IB-1)+J)**2*(ONE + (J/4))
         ENDDO
         IF (GI .GT. ZERO) SSEN = SSEN + HSQ/(TWO*TWO*G0*GI)
         IF (XKI .GT. ZERO) SSEN = SSEN +
     1      HALF*STATEV(6*NPR+IB)**2/(XK0*XKI)
      ENDDO
      SCD = SCD + WORK - (SSEN - SSE)
      SSE = SSEN
      RETURN
      END
!
!     a = exp(-dt/tau), b = (1 - a)*tau/dt; limit b = 1 at dt = 0
      SUBROUTINE K14_AB(DT, TAU, A, B)
      INCLUDE 'ABA_PARAM.INC'
      X = DT/TAU
      IF (X .LT. 1.0D-6) THEN
         A = 1.0D0 - X + 0.5D0*X*X
         B = 1.0D0 - 0.5D0*X + X*X/6.0D0
      ELSE
         A = EXP(-X)
         B = (1.0D0 - A)/X
      ENDIF
      RETURN
      END
!
!     V' = R V R^T for a symmetric tensor stored as 11,22,33,12,13,23
      SUBROUTINE K14_ROTS(V, R)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION V(6), R(3,3), A(3,3), B(3,3)
      A(1,1) = V(1)
      A(2,2) = V(2)
      A(3,3) = V(3)
      A(1,2) = V(4)
      A(1,3) = V(5)
      A(2,3) = V(6)
      A(2,1) = A(1,2)
      A(3,1) = A(1,3)
      A(3,2) = A(2,3)
      DO I = 1, 3
         DO J = 1, 3
            B(I,J) = 0.0D0
            DO K = 1, 3
               DO L = 1, 3
                  B(I,J) = B(I,J) + R(I,K)*A(K,L)*R(J,L)
               ENDDO
            ENDDO
         ENDDO
      ENDDO
      V(1) = B(1,1)
      V(2) = B(2,2)
      V(3) = B(3,3)
      V(4) = B(1,2)
      V(5) = B(1,3)
      V(6) = B(2,3)
      RETURN
      END
