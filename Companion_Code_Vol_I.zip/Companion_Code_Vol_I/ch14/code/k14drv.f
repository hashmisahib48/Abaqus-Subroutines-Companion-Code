      PROGRAM K14DRV
!     Single-point time-history driver for a UMAT (Abaqus/Standard
!     interface, Abaqus 2024), 3D layout (NTENS = 6).  Namelist DRV.
!     CTRL = 'E': component ICOMP follows a prescribed strain history
!     CTRL = 'S': component ICOMP follows a prescribed stress history
!     LAT  = 'FREE': other direct stresses are zero (Newton on the
!            lateral strains); 'FIX': other strains are zero
!     Each segment i runs to time SEGT(i) with SEGN(i) increments whose
!     lengths grow by the factor SEGR(i); SEGK(i) = 0: linear in time
!     to SEGV(i); SEGK(i) = 1: SEGV(i)*SIN(2*PI*TIME/PER).
!     TANMODE = 1: Newton uses DDSDDE;  2: the instantaneous elastic
!     matrix of PROPS(1), PROPS(2).  ROTRATE: rigid rotation (rad/s)
!     about axis 3 imposed through DROT from time ROTT0 on.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NPMAX = 50, NSMAX = 60, NSG = 20)
      CHARACTER*1 CTRL
      CHARACTER*4 LAT
      LOGICAL FDCHK, ITPRINT, INITCALL
      DIMENSION PROPS(NPMAX), SEGT(NSG), SEGV(NSG), SEGN(NSG),
     1   SEGR(NSG), SEGK(NSG)
      NAMELIST /DRV/ NPROPS, PROPS, NSTATV, NSEG, SEGT, SEGV, SEGN,
     1   SEGR, SEGK, PER, ICOMP, CTRL, LAT, TOL, MAXIT, ROTRATE,
     2   NSDVPR, FDCHK, ITPRINT, TANMODE, INITCALL, HFD, ROTT0
      NPROPS = 0
      PROPS = 0.0D0
      NSTATV = 8
      NSEG = 1
      SEGT = 1.0D0
      SEGV = 0.0D0
      SEGN = 1
      SEGR = 1.0D0
      SEGK = 0
      PER = 1.0D0
      ICOMP = 1
      CTRL = 'E'
      LAT = 'FREE'
      TOL = 1.0D-9
      MAXIT = 30
      ROTRATE = 0.0D0
      NSDVPR = 8
      FDCHK = .FALSE.
      ITPRINT = .FALSE.
      TANMODE = 1
      INITCALL = .TRUE.
      HFD = 1.0D-7
      ROTT0 = 0.0D0
      READ(5, NML=DRV)
      CALL K14D_RUN(NPROPS, PROPS, NSTATV, NSEG, SEGT, SEGV, SEGN,
     1   SEGR, SEGK, PER, ICOMP, CTRL, LAT, TOL, MAXIT, ROTRATE,
     2   NSDVPR, FDCHK, ITPRINT, TANMODE, INITCALL, HFD, ROTT0)
      END
!
      SUBROUTINE K14D_RUN(NPROPS, PROPS, NSTATV, NSEG, SEGT, SEGV,
     1   SEGN, SEGR, SEGK, PER, ICOMP, CTRL, LAT, TOL, MAXIT, ROTRATE,
     2   NSDVPR, FDCHK, ITPRINT, TANMODE, INITCALL, HFD, ROTT0)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NTENS = 6, NDI = 3, NSHR = 3, BIG = 1.0D36,
     1           PI = 3.14159265358979D0)
      CHARACTER*1 CTRL
      CHARACTER*4 LAT
      CHARACTER*80 CMNAME
      LOGICAL FDCHK, ITPRINT, INITCALL, OK, CUT
      DIMENSION PROPS(NPROPS), SEGT(*), SEGV(*), SEGN(*), SEGR(*),
     1   SEGK(*)
      DIMENSION STRESS0(NTENS), STATEV(NSTATV), STATEVS(NSTATV)
      DIMENSION STRESS(NTENS), STRANS(NTENS), STRANR(NTENS)
      DIMENSION SIGR(NTENS), DSTRAN(NTENS), DDSDDE(NTENS,NTENS)
      DIMENSION DDSDDT(NTENS), DRPLDE(NTENS), STRAN(NTENS)
      DIMENSION TIME(2), PREDEF(1), DPRED(1), COORDS(3)
      DIMENSION DROT(3,3), DFGRD0(3,3), DFGRD1(3,3), JSTEP(4)
      DIMENSION RINC(3,3), ROW(2*NTENS+NSTATV+8)
      DIMENSION AJ(3,3), RJ(3), IU(3), TGT(3), DDFD(NTENS,NTENS)
      DIMENSION WRKP(NTENS), WRKM(NTENS), WRKS(NSTATV), DSP(NTENS)
      DIMENSION CEL(NTENS,NTENS)
      CMNAME = 'DRIVER'
      NOEL = 1
      NPT = 1
      LAYER = 1
      KSPT = 1
      CELENT = 1.0D0
      TEMP = 20.0D0
      DTEMP = 0.0D0
      PREDEF(1) = 0.0D0
      DPRED(1) = 0.0D0
      COORDS = 0.0D0
      JSTEP = 0
      JSTEP(1) = 1
      DFGRD0 = 0.0D0
      DFGRD1 = 0.0D0
      DO I = 1, 3
         DFGRD0(I,I) = 1.0D0
         DFGRD1(I,I) = 1.0D0
      ENDDO
      NP = MIN(NSDVPR, NSTATV)
      NR = 3 + 2*NTENS + 3 + NP
!     control set: components whose stress is prescribed
      NU = 0
      IF (LAT .EQ. 'FREE' .AND. ICOMP .LE. 3) THEN
         DO I = 1, 3
            IF (I .NE. ICOMP) THEN
               NU = NU + 1
               IU(NU) = I
            ENDIF
         ENDDO
      ENDIF
      IF (CTRL .EQ. 'S') THEN
         NU = NU + 1
         IU(NU) = ICOMP
      ENDIF
!     instantaneous elastic matrix (for TANMODE = 2)
      G = 0.5D0*PROPS(1)/(1.0D0 + PROPS(2))
      XLAM = PROPS(1)*PROPS(2)/((1.0D0 + PROPS(2))*
     1       (1.0D0 - 2.0D0*PROPS(2)))
      CEL = 0.0D0
      DO J = 1, 3
         DO I = 1, 3
            CEL(I,J) = XLAM
         ENDDO
         CEL(J,J) = XLAM + 2.0D0*G
         CEL(J+3,J+3) = G
      ENDDO
      STRESS0 = 0.0D0
      STRANS = 0.0D0
      STATEVS = 0.0D0
      SSE0 = 0.0D0
      SPD0 = 0.0D0
      SCD0 = 0.0D0
      T = 0.0D0
      KINC = 0
      NCALL = 0
      NCUTS = 0
      NITOT = 0
      VSTART = 0.0D0
      WRITE(*,'(A,I4,2A)') '# k14drv ntens=', NTENS, ' ctrl=', CTRL
      IF (INITCALL) THEN
         DSTRAN = 0.0D0
         KINC = 1
         DTIME = 0.0D0
         TIME(1) = 0.0D0
         TIME(2) = 0.0D0
         CALL SETCTX(0.0D0)
         CALL EVAL(DSTRAN, STRESS, STATEV, DDSDDE, PNEWDT)
         KINC = 0
      ENDIF
      DO ISEG = 1, NSEG
         T0 = T
         TEND = SEGT(ISEG)
         NS = NINT(SEGN(ISEG))
         RG = SEGR(ISEG)
         IF (ABS(RG - 1.0D0) .LT. 1.0D-12) THEN
            H1 = (TEND - T0)/NS
         ELSE
            H1 = (TEND - T0)*(1.0D0 - RG)/(1.0D0 - RG**NS)
         ENDIF
         DTPL = H1
         NCONS = 0
         DO WHILE (T .LT. TEND - 1.0D-10*TEND)
            DT = MIN(DTPL, TEND - T)
            IF (TEND - T - DT .LT. 1.0D-9*TEND) DT = TEND - T
            KINC = KINC + 1
            DTIME = DT
            TIME(1) = T
            TIME(2) = T
            ANGI = 0.0D0
            IF (T .GE. ROTT0 - 1.0D-12) ANGI = ROTRATE*DT
            CALL SETCTX(ANGI)
            TG = VAL(ISEG, T0, TEND, VSTART, T + DT)
            DSTRAN = 0.0D0
            IF (CTRL .EQ. 'E') DSTRAN(ICOMP) = TG -
     1         VAL(ISEG, T0, TEND, VSTART, T)
            OK = .FALSE.
            CUT = .FALSE.
            DO IT = 1, MAXIT
               CALL EVAL(DSTRAN, STRESS, STATEV, DDSDDE, PNEWDT)
               NITOT = NITOT + 1
               IF (PNEWDT .LT. 1.0D0) THEN
                  CUT = .TRUE.
                  EXIT
               ENDIF
               IF (NU .EQ. 0) THEN
                  OK = .TRUE.
                  EXIT
               ENDIF
               RES = 0.0D0
               DO K = 1, NU
                  TGT(K) = 0.0D0
                  IF (CTRL .EQ. 'S' .AND. IU(K) .EQ. ICOMP) TGT(K)=TG
                  RJ(K) = TGT(K) - STRESS(IU(K))
                  RES = MAX(RES, ABS(RJ(K)))
               ENDDO
               IF (ITPRINT) WRITE(*,'(A,2I5,ES14.5)') 'IT', KINC, IT,
     1            RES
               IF (RES .LE. TOL) THEN
                  OK = .TRUE.
                  EXIT
               ENDIF
               DO L = 1, NU
                  DO K = 1, NU
                     IF (TANMODE .EQ. 2) THEN
                        AJ(K,L) = CEL(IU(K),IU(L))
                     ELSE
                        AJ(K,L) = DDSDDE(IU(K),IU(L))
                     ENDIF
                  ENDDO
               ENDDO
               CALL K14D_SOLVE(AJ, RJ, NU, IERR)
               IF (IERR .NE. 0) STOP 3
               DO K = 1, NU
                  DSTRAN(IU(K)) = DSTRAN(IU(K)) + RJ(K)
               ENDDO
            ENDDO
            IF (.NOT. OK) THEN
               NCUTS = NCUTS + 1
               NCONS = NCONS + 1
               IF (NCONS .GT. 25) STOP 4
               KINC = KINC - 1
               IF (CUT) THEN
                  DTPL = DT*MAX(PNEWDT, 0.05D0)
               ELSE
                  DTPL = 0.5D0*DT
               ENDIF
               CYCLE
            ENDIF
            NCONS = 0
            IF (FDCHK) THEN
               CALL FDJAC(DSTRAN, DDFD)
               ERR = 0.0D0
               REFV = 0.0D0
               DO J = 1, NTENS
                  DO I = 1, NTENS
                     ERR = MAX(ERR, ABS(DDFD(I,J) - DDSDDE(I,J)))
                     REFV = MAX(REFV, ABS(DDSDDE(I,J)))
                  ENDDO
               ENDDO
               WRITE(*,'(A,I6,ES14.5)') 'FD', KINC, ERR/REFV
            ENDIF
            T = T + DT
            DO I = 1, NTENS
               STRANS(I) = STRANR(I) + DSTRAN(I)
               STRESS0(I) = STRESS(I)
            ENDDO
            STATEVS = STATEV
            SSE0 = SSEC
            SPD0 = SPDC
            SCD0 = SCDC
            DTPL = DT*RG
            ROW(1) = T
            ROW(2) = DT
            ROW(3) = IT
            ROW(4:3+NTENS) = STRANS
            ROW(4+NTENS:3+2*NTENS) = STRESS
            ROW(4+2*NTENS) = SSEC
            ROW(5+2*NTENS) = SPDC
            ROW(6+2*NTENS) = SCDC
            ROW(7+2*NTENS:6+2*NTENS+NP) = STATEV(1:NP)
            WRITE(*,'(A,I6,*(ES24.15E3))') 'INC', KINC, ROW(1:NR)
         ENDDO
         VSTART = VAL(ISEG, T0, TEND, VSTART, TEND)
      ENDDO
      WRITE(*,'(A,4I8)') 'DONE', KINC, NCALL, NCUTS, NITOT
      RETURN
!
      CONTAINS
!
!     value of the controlled quantity at time TT within segment ISG
      FUNCTION VAL(ISG, TA, TB, VS, TT)
      INTEGER ISG
      IF (NINT(SEGK(ISG)) .EQ. 1) THEN
         VAL = SEGV(ISG)*SIN(2.0D0*PI*TT/PER)
      ELSE
         VAL = VS + (SEGV(ISG) - VS)*(TT - TA)/(TB - TA)
      ENDIF
      RETURN
      END
!
!     rotated start-of-increment stress and strain, DROT
      SUBROUTINE SETCTX(ANG)
      C = COS(ANG)
      S = SIN(ANG)
      RINC = 0.0D0
      RINC(1,1) = C
      RINC(1,2) = -S
      RINC(2,1) = S
      RINC(2,2) = C
      RINC(3,3) = 1.0D0
      DROT = RINC
      JSTEP(3) = 0
      IF (ANG .NE. 0.0D0) JSTEP(3) = 1
      CALL K14D_ROTV(STRESS0, RINC, 1, SIGR)
      CALL K14D_ROTV(STRANS, RINC, 2, STRANR)
      RETURN
      END
!
!     one UMAT call from the start-of-increment state
      SUBROUTINE EVAL(DSTR, SIGO, STVO, DDS, PNEWDT)
      DIMENSION DSTR(NTENS), SIGO(NTENS), STVO(NSTATV)
      DIMENSION DDS(NTENS,NTENS)
      SIGO = SIGR
      STVO = STATEVS
      SSE = SSE0
      SPD = SPD0
      SCD = SCD0
      RPL = 0.0D0
      DRPLDT = 0.0D0
      DDS = 1.0D10
      PNEWDT = BIG
      STRAN = STRANR
      NCALL = NCALL + 1
      CALL UMAT(SIGO, STVO, DDS, SSE, SPD, SCD, RPL, DDSDDT, DRPLDE,
     1   DRPLDT, STRAN, DSTR, TIME, DTIME, TEMP, DTEMP, PREDEF, DPRED,
     2   CMNAME, NDI, NSHR, NTENS, NSTATV, PROPS, NPROPS, COORDS,
     3   DROT, PNEWDT, CELENT, DFGRD0, DFGRD1, NOEL, NPT, LAYER, KSPT,
     4   JSTEP, KINC)
      SSEC = SSE
      SPDC = SPD
      SCDC = SCD
      RETURN
      END
!
!     central-difference Jacobian d(sigma)/d(dstran)
      SUBROUTINE FDJAC(DSTR, DDF)
      DIMENSION DSTR(NTENS), DDF(NTENS,NTENS), DDX(NTENS,NTENS)
      DO J = 1, NTENS
         DSP = DSTR
         DSP(J) = DSTR(J) + HFD
         CALL EVAL(DSP, WRKP, WRKS, DDX, PN)
         DSP(J) = DSTR(J) - HFD
         CALL EVAL(DSP, WRKM, WRKS, DDX, PN)
         DO I = 1, NTENS
            DDF(I,J) = (WRKP(I) - WRKM(I))/(2.0D0*HFD)
         ENDDO
      ENDDO
      RETURN
      END
      END
!
!     Gaussian elimination with partial pivoting, A x = b, N <= 3
      SUBROUTINE K14D_SOLVE(A, B, N, IERR)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), B(3)
      IERR = 0
      DO K = 1, N
         IP = K
         DO I = K + 1, N
            IF (ABS(A(I,K)) .GT. ABS(A(IP,K))) IP = I
         ENDDO
         IF (ABS(A(IP,K)) .LT. 1.0D-300) THEN
            IERR = 1
            RETURN
         ENDIF
         IF (IP .NE. K) THEN
            DO J = 1, N
               T = A(K,J)
               A(K,J) = A(IP,J)
               A(IP,J) = T
            ENDDO
            T = B(K)
            B(K) = B(IP)
            B(IP) = T
         ENDIF
         DO I = K + 1, N
            F = A(I,K)/A(K,K)
            DO J = K, N
               A(I,J) = A(I,J) - F*A(K,J)
            ENDDO
            B(I) = B(I) - F*B(K)
         ENDDO
      ENDDO
      DO K = N, 1, -1
         DO J = K + 1, N
            B(K) = B(K) - A(K,J)*B(J)
         ENDDO
         B(K) = B(K)/A(K,K)
      ENDDO
      RETURN
      END
!
!     V' = R V R^T for a stress (LSTR = 1) or strain (LSTR = 2) vector
      SUBROUTINE K14D_ROTV(V, R, LSTR, VP)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION V(6), VP(6), R(3,3), A(3,3), B(3,3)
      FS = 1.0D0
      IF (LSTR .EQ. 2) FS = 0.5D0
      A(1,1) = V(1)
      A(2,2) = V(2)
      A(3,3) = V(3)
      A(1,2) = FS*V(4)
      A(1,3) = FS*V(5)
      A(2,3) = FS*V(6)
      A(2,1) = A(1,2)
      A(3,1) = A(1,3)
      A(3,2) = A(2,3)
      DO I = 1, 3
         DO J = 1, 3
            B(I,J) = 0.0D0
            DO K = 1, 3
               DO L = 1, 3
                  B(I,J) = B(I,J) + R(I,K)*A(K,L)*R(J,L)
               ENDDO
            ENDDO
         ENDDO
      ENDDO
      VP(1) = B(1,1)
      VP(2) = B(2,2)
      VP(3) = B(3,3)
      VP(4) = B(1,2)/FS
      VP(5) = B(1,3)/FS
      VP(6) = B(2,3)/FS
      RETURN
      END
