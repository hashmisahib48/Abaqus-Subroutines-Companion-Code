import sys; sys.path.insert(0,'.')
from common import *
E,NU,SY0,H,TV=210000.0,0.3,250.0,1000.0,10.0
def props(tv=TV,m=1.0,rho=1e9): return [E,NU,SY0,H,tv,m,rho]
base=lambda **k: dict(NPROPS=7,PROPS=props(**k),NSTATV=8,NSDVPR=3)
out={}; Rr={}
eta=TV*SY0; a=(E+H)/eta
def kap_rate(t,rate):   # m=1, constant strain rate
    ty=SY0/(E*rate); tt=np.maximum(np.asarray(t,float)-ty,0)
    return E*rate/(eta*a)*(tt-(1-np.exp(-a*tt))/a)
def sig_rate(t,rate): return E*(rate*np.asarray(t,float)-kap_rate(t,rate))
rate=1e-2; eend=0.04; tend=eend/rate
err={}
for N in [20,40,80,160,320,640]:
    D=run('drv_vp',dict(base(),NSEG=1,SEGT=[tend],SEGV=[eend],SEGN=[N],ICOMP=1,LAT='FREE'))
    ref=sig_rate(D['t'],rate); err[N]=float(np.max(np.abs(D['sig'][:,0]-ref)))
out['rate_err']=err
D=run('drv_vp',dict(base(),NSEG=1,SEGT=[tend],SEGV=[eend],SEGN=[2000],ICOMP=1,LAT='FREE'))
ref=sig_rate(D['t'],rate); out['rate_fine']=dict(maxerr=float(np.max(np.abs(D['sig'][:,0]-ref))),sig_end=float(D['sig'][-1,0]),ref_end=float(ref[-1]),ty=SY0/(E*rate),tc=1/a)
Rr['rate_t']=D['t'][::10].tolist(); Rr['rate_s']=D['sig'][::10,0].tolist(); Rr['rate_e']=D['eps'][::10,0].tolist()
# steady stress
def sig_ss(eps,rate,tv,m):
    kd=E*rate/(E+H); fss=SY0*(tv*kd)**(1/m)
    return E*(SY0+fss+H*eps)/(E+H), fss
ss=[]
for m in [1.0,2.0]:
    for rate_ in [1e-3,1e-2,1e-1]:
        eend_=0.05; te=eend_/rate_
        D=run('drv_vp',dict(base(m=m),NSEG=1,SEGT=[te],SEGV=[eend_],SEGN=[1000],ICOMP=1,LAT='FREE'))
        ref,fss=sig_ss(eend_,rate_,TV,m)
        slope=(D['sig'][-1,0]-D['sig'][-2,0])/(D['eps'][-1,0]-D['eps'][-2,0])
        ss.append(dict(m=m,rate=rate_,fss=fss,ref=ref,drv=float(D['sig'][-1,0]),slope=float(slope),f_state=float(D['sdv'][-1,2])))
out['steady']=ss
out['slope_ref']=E*H/(E+H)
for m_,rate_ in [(1.0,1e-2),(1.0,1e-3),(2.0,1e-2)]:
    pass
# rate figures
Rr['rate_curves']={}
for rate_ in [1e-3,1e-2,1e-1]:
    D=run('drv_vp',dict(base(m=2.0),NSEG=1,SEGT=[0.05/rate_],SEGV=[0.05],SEGN=[1000],ICOMP=1,LAT='FREE'))
    Rr['rate_curves'][str(rate_)]=dict(e=D['eps'][::5,0].tolist(),s=D['sig'][::5,0].tolist())
# rate-independent limit
D=run('drv_vp',dict(base(tv=1e-9),NSEG=1,SEGT=[1.0],SEGV=[0.01],SEGN=[10],ICOMP=1,LAT='FREE'))
bil=SY0+E*H/(E+H)*(D['eps'][:,0]-SY0/E); bil=np.where(D['eps'][:,0]>SY0/E,bil,E*D['eps'][:,0])
out['limit']=dict(maxerr=float(np.max(np.abs(D['sig'][:,0]-bil))),s_end=float(D['sig'][-1,0]),ref_end=float(bil[-1]))
# FD check
for m_ in [1.0,2.0]:
    D=run('drv_vp',dict(base(m=m_),NSEG=2,SEGT=[0.5,1.0],SEGV=[0.03,0.03],SEGN=[6,3],ICOMP=1,LAT='FREE',FDCHK=True,HFD=1e-7,TOL=1e-12))
    out['fd_vp_m%d'%int(m_)]=float(D['FD'][:,1].max())
# 3D mixed shear/uniaxial FD: shear mode
D=run('drv_vp',dict(base(m=2.0),NSEG=1,SEGT=[1.0],SEGV=[0.02],SEGN=[8],ICOMP=4,LAT='FIX',FDCHK=True,HFD=1e-7))
out['fd_vp_shear']=float(D['FD'][:,1].max())
# convergence
def conv(tm,m=2.0):
    D=run('drv_vp',dict(base(m=m),NSEG=1,SEGT=[1.0],SEGV=[0.01],SEGN=[1],ICOMP=1,LAT='FREE',TANMODE=tm,ITPRINT=True,TOL=1e-10))
    return D['IT'][:,2].tolist()
out['conv_vp']=dict(consistent=conv(1),elastic=conv(2))
# relaxation and PNEWDT
e0,trr=0.004,0.004; rr=e0/trr; thold=0.2
ty=SY0/(E*rr); kt=float(kap_rate(trr,rr)); kinf=(E*e0-SY0)/(E+H)
def sig_rel(t):
    t=np.asarray(t,float); k=np.where(t<=trr,kap_rate(t,rr),kinf+(kt-kinf)*np.exp(-a*(t-trr)))
    return E*(np.minimum(t,trr)*rr*0+np.where(t<=trr,rr*t,e0)-k)
def relax(**kw):
    rho=kw.pop('rho',1e9)
    d=dict(base(rho=rho),NSEG=2,SEGT=[trr,thold],SEGV=[e0,e0],SEGN=[40,kw['n']],SEGR=[1.0,kw['r']],ICOMP=1,LAT='FREE')
    D=run('drv_vp',d); ref=sig_rel(D['t'])
    i=np.argmin(np.abs(D['t']-0.0158))
    return D,float(np.max(np.abs(D['sig'][:,0]-ref))),D
res={}
for name,kw in {'fixed':dict(n=10,r=1.0),'g20':dict(n=10,r=1.25,rho=0.2),'g10':dict(n=10,r=1.25,rho=0.1),'g05':dict(n=10,r=1.25,rho=0.05),'free_g':dict(n=10,r=1.25),'fine':dict(n=2000,r=1.0)}.items():
    D,e,_=relax(**kw)
    t=D['t']; k=np.argmax(np.abs(D['sig'][:,0]-sig_rel(t)))
    res[name]=dict(maxerr=e,tat=float(t[k]),ninc=len(t),calls=D['done'][1],cuts=D['done'][2],dt1=float(t[40]-t[39]))
out['pnewdt']=res
out['relax_info']=dict(a=a,tr=trr,e0=e0,sig_tr=float(sig_rel([trr])[0]),sig_inf=float(E*(e0-kinf)),tau_r=1/a,sig_01=float(sig_rel([0.0158])[0]))
# data for figure: relaxation curves
Rr['relax']={}
tt=np.linspace(trr,thold,300)
Rr['relax_ref_t']=np.concatenate([[0],tt]).tolist(); Rr['relax_ref_s']=sig_rel(np.concatenate([[0],tt])).tolist()
for name in ['fixed','g10','fine']:
    kw={'fixed':dict(n=10,r=1.0),'g10':dict(n=10,r=1.25,rho=0.1),'fine':dict(n=2000,r=1.0)}[name]
    D,e,_=relax(**kw); Rr['relax'][name]=dict(t=D['t'].tolist(),s=D['sig'][:,0].tolist())
be={}
for n in [1,2,4,8,16,32,64,128]:
    D=run('drv_vp',dict(base(),NSEG=2,SEGT=[trr,trr+0.05],SEGV=[e0,e0],SEGN=[400,n],ICOMP=1,LAT='FREE'))
    be[n]=float(D['sig'][-1,0]-sig_rel([trr+0.05])[0])
out['be']=be; out['be_ref']=float(sig_rel([trr+0.05])[0])
json.dump(dict(out=out,R=Rr),open(OUT+'/vp.json','w'),indent=1)
print(json.dumps(out,indent=1))
