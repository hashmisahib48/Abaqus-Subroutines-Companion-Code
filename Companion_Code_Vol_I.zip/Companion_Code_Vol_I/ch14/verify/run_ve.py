import sys; sys.path.insert(0,'.')
from common import *
R={}
base=dict(NPROPS=12,PROPS=VEP,NSTATV=21,NSDVPR=3)
Mi=K0*KI+4/3*G0*GI; Minf=K0*KINF+4/3*G0*GINF
Li=K0*KI-2/3*G0*GI; Linf=K0*KINF-2/3*G0*GINF
def rh(t,r,tr,Minf,Mi):
    t=np.asarray(t,float); tc=np.minimum(t,tr)[:,None]
    return r*(Minf*tc[:,0]+(Mi*TAU*np.exp(-t[:,None]/TAU)*(np.exp(tc/TAU)-1)).sum(1))
e0,tr,tend=0.01,0.5,100.0
r_=e0/tr
def relax(inc1,inc2,ratio,comp=1,exe='drv_ve'):
    d=dict(base,NSEG=2,SEGT=[tr,tend],SEGV=[e0,e0],SEGN=[inc1,inc2],SEGR=[1.0,ratio],ICOMP=comp,LAT='FIX')
    return run(exe,d)
out={}
cases={'A':(1,1,1.0),'B':(5,40,1.3),'C':(50,200,1.0)}
for k,(a,b,c) in cases.items():
    D=relax(a,b,c); t=D['t']
    ref=rh(t,r_,tr,Minf,Mi); ref2=rh(t,r_,tr,Linf,Li)
    e1=np.max(np.abs(D['sig'][:,0]-ref)/ref); e2=np.max(np.abs(D['sig'][:,1]-ref2)/np.abs(ref2))
    out['relax_'+k]=dict(n=len(t),err11=e1,err22=e2,calls=D['done'][1])
    if k=='B': R['relax_t']=t.tolist(); R['relax_s11']=D['sig'][:,0].tolist()
# shear relaxation (engineering shear gamma)
g0=0.02; r2=g0/tr
Dsh=run('drv_ve',dict(base,NSEG=2,SEGT=[tr,tend],SEGV=[g0,g0],SEGN=[4,30],SEGR=[1.0,1.4],ICOMP=4,LAT='FIX'))
t=Dsh['t']; ref=rh(t,r2,tr,G0*GINF,G0*GI)
out['shear_relax']=dict(err=float(np.max(np.abs(Dsh['sig'][:,3]-ref)/ref)),n=len(t),s_end=float(Dsh['sig'][-1,3]),ref_end=float(ref[-1]),ginf_lim=float(G0*GINF*g0))
# a couple of table values (case A one increment): t=tr and t=tend
DA=relax(1,1,1.0)
out['A_vals']=dict(t=DA['t'].tolist(),s=DA['sig'][:,0].tolist(),ref=rh(DA['t'],r_,tr,Minf,Mi).tolist(),M0=float(Minf+Mi.sum()),Minf=float(Minf),G0=G0,K0=K0,GINF=GINF,KINF=KINF)
# ---- creep (shear stress control)
s_=np.poly1d([1.0])
def poly_from_taus(): 
    Dn=np.poly1d([1.0])
    for t_ in TAU: Dn=Dn*np.poly1d([t_,1.0])
    return Dn
Dn=poly_from_taus()
Nn=Dn*float(GINF)
for i in range(3):
    p=np.poly1d([GI[i]*TAU[i],0.0])
    for j in range(3):
        if j!=i: p=p*np.poly1d([TAU[j],1.0])
    Nn=Nn+p
roots=np.roots(Nn.coeffs); dN=Nn.deriv()
coef=np.array([Dn(s)/(G0*s*dN(s)) for s in roots]).real; roots=roots.real
J0inf=Dn(0)/(G0*Nn(0))   # = 1/Ginf
def Jc(t): 
    t=np.asarray(t,float)[:,None]; return J0inf+(coef*np.exp(roots*t)).sum(1)
def creep_ref(t,tau0,trr):
    t=np.asarray(t,float); tc=np.minimum(t,trr)
    # gamma = tau0/trr * int_0^tc J(t-s) ds
    I=J0inf*tc+(coef*(np.exp(roots*t[:,None])*(1-np.exp(-roots*tc[:,None]))/roots)).sum(1)  # int e^{s_k (t-s)} ds = e^{s_k t}(1-e^{-s_k tc})/s_k
    return tau0/trr*I
tau0,trc,tendc=1.0,0.01,100.0
creep={}
for k,(n1,n2,rr) in {'A':(1,20,1.5),'B':(5,100,1.1),'C':(20,400,1.0)}.items():
    D=run('drv_ve',dict(base,NSEG=2,SEGT=[trc,tendc],SEGV=[tau0,tau0],SEGN=[n1,n2],SEGR=[1.0,rr],ICOMP=4,CTRL='S',LAT='FIX'))
    ref=creep_ref(D['t'],tau0,trc); e=np.abs(D['eps'][:,3]-ref)/ref
    sel=D['t']>0.2
    creep[k]=dict(n=len(D['t']),maxerr=float(e.max()),maxerr_late=float(e[sel].max()),calls=D['done'][1],its=float(D['it'].max()))
    if k=='B': R['creep_t']=D['t'].tolist(); R['creep_g']=D['eps'][:,3].tolist()
out['creep']=creep
out['creep_info']=dict(roots=roots.tolist(),coef=coef.tolist(),J0=float(Jc([0.0])[0]*G0),Jinf_G0=float(J0inf*G0),Ginf=float(G0*GINF),theta=(-1/roots).tolist())
D=run('drv_ve',dict(base,NSEG=2,SEGT=[trc,tendc],SEGV=[tau0,tau0],SEGN=[5,100],SEGR=[1.0,1.1],ICOMP=4,CTRL='S',LAT='FIX'))
tt=np.array([0.01,0.1,1,10,100.0]); out['creep_tab']=dict(t=tt.tolist(),ref=creep_ref(tt,tau0,trc).tolist())
# interpolate driver at those t (they are on grid? use nearest check)
out['creep_drv_at']=[float(np.interp(x,D['t'],D['eps'][:,3])) for x in tt]
R['creep_ref_t']=np.logspace(-2,2,200).tolist(); R['creep_ref_g']=creep_ref(np.logspace(-2,2,200),tau0,trc).tolist()
# ---- harmonic loading (shear strain control)
g0h,PERh=0.01,1.0; om=2*np.pi/PERh
def harm_ref(t):
    t=np.asarray(t,float)[:,None]; wt=om*TAU
    s=G0*g0h*(GINF*np.sin(om*t)+(GI*wt*(np.cos(om*t)+wt*np.sin(om*t)-np.exp(-t/TAU))/(1+wt**2)).sum(1,keepdims=True)) 
    return s[:,0]
Gp=G0*(GINF+(GI*(om*TAU)**2/(1+(om*TAU)**2)).sum()); Gpp=G0*(GI*om*TAU/(1+(om*TAU)**2)).sum()
harm={}
for N in [4,8,16,32,64,128]:
    Tend=20.0
    D=run('drv_ve',dict(base,NSEG=1,SEGT=[Tend],SEGV=[g0h],SEGN=[N*int(Tend/PERh)],SEGK=[1],PER=PERh,ICOMP=4,LAT='FIX'))
    ref=harm_ref(D['t']); err=np.max(np.abs(D['sig'][:,3]-ref))/np.max(np.abs(ref))
    harm[N]=float(err)
out['harm']=harm; out['harm_mod']=dict(Gp=float(Gp),Gpp=float(Gpp),om=om)
# dissipation per cycle over the last cycle of a long run
Tend=200.0; N=64
D=run('drv_ve',dict(base,NSEG=1,SEGT=[Tend],SEGV=[g0h],SEGN=[N*int(Tend)],SEGK=[1],PER=PERh,ICOMP=4,LAT='FIX'))
i1=np.argmin(abs(D['t']-(Tend-1))); i2=-1
diss=D['scd'][i2]-D['scd'][i1]
out['diss']=dict(drv=float(diss),ref=float(np.pi*Gpp*g0h**2),stored_ok=bool(np.all(np.diff(D['scd'])>=-1e-14)))
# last-cycle amplitude check: stress amplitude
sl=D['sig'][i1:,3]; out['amp']=dict(drv=float(sl.max()),ref=float(g0h*np.hypot(Gp,Gpp)))
tt=D['t'][:len(D['t'])//200*0+400]
D2=run('drv_ve',dict(base,NSEG=1,SEGT=[20.0],SEGV=[g0h],SEGN=[64*20],SEGK=[1],PER=PERh,ICOMP=4,LAT='FIX'))
R['harm_t']=D2['t'].tolist(); R['harm_g']=D2['eps'][:,3].tolist(); R['harm_s']=D2['sig'][:,3].tolist()
# ---- convergence histories (uniaxial stress, one increment, strain ctrl 0.02 in 0.5 s ramp after stress)
def conv(tm):
    D=run('drv_ve',dict(base,NSEG=1,SEGT=[1.0],SEGV=[0.02],SEGN=[1],ICOMP=1,LAT='FREE',TANMODE=tm,ITPRINT=True,TOL=1e-12))
    return D['IT'][:,2].tolist()
out['conv_ve']=dict(consistent=conv(1),elastic=conv(2))
# ---- FD check at a few states
D=run('drv_ve',dict(base,NSEG=2,SEGT=[0.5,5.0],SEGV=[0.01,0.01],SEGN=[5,10],SEGR=[1.0,1.5],ICOMP=1,LAT='FREE',FDCHK=True,HFD=1e-7))
out['fd_ve']=dict(max=float(D['FD'][:,1].max()))
# ---- DTIME = 0 call: relaxation with a zero-length increment leaves state unchanged
# ---- rotation test
tr_=0.5
Dn_=run('drv_ve',dict(base,NSEG=2,SEGT=[tr_,10.0],SEGV=[0.02,0.02],SEGN=[5,40],SEGR=[1.0,1.0],ICOMP=4,LAT='FIX'))
rot=np.pi/2/(10.0-tr_)
for exe in ['drv_ve','drv_ve_norot']:
    pass
def rotrun(exe):
    return run(exe,dict(base,NSEG=2,SEGT=[tr_,10.0],SEGV=[0.02,0.02],SEGN=[5,40],SEGR=[1.0,1.0],ICOMP=4,LAT='FIX',ROTRATE=0.0))
# rotation only in the hold: use two-run trick: ROTRATE applies to all increments; so ramp with rotation too, compare rotated-frame invariants
rr=np.pi/2/(10.0-tr_)
Dr=run('drv_ve',dict(base,NSEG=2,SEGT=[tr_,10.0],SEGV=[0.02,0.02],SEGN=[5,40],SEGR=[1.0,1.0],ICOMP=4,LAT='FIX',ROTRATE=rr,ROTT0=tr_))
Db=run('drv_ve_norot',dict(base,NSEG=2,SEGT=[tr_,10.0],SEGV=[0.02,0.02],SEGN=[5,40],SEGR=[1.0,1.0],ICOMP=4,LAT='FIX',ROTRATE=rr,ROTT0=tr_))
def nrm(S): return np.sqrt(S[:,0]**2+S[:,1]**2+S[:,2]**2+2*(S[:,3]**2+S[:,4]**2+S[:,5]**2))
out['rot']=dict(ref_end=float(np.sqrt(2)*Dn_['sig'][-1,3]),with_end=float(nrm(Dr['sig'])[-1]),norot_end=float(nrm(Db['sig'])[-1]),
   maxdiff_with=float(np.max(np.abs(nrm(Dr['sig'])-np.sqrt(2)*Dn_['sig'][:,3]))),maxdiff_norot=float(np.max(np.abs(nrm(Db['sig'])-np.sqrt(2)*Dn_['sig'][:,3]))),s12_end=float(Dr['sig'][-1,3]),s11_end=float(Dr['sig'][-1,0]))
json.dump(dict(out=out,R=R),open(OUT+'/ve.json','w'),indent=1)
print(json.dumps(out,indent=1))
