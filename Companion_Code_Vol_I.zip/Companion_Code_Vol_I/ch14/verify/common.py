import subprocess, numpy as np, json, os
OUT='/home/claude/book/ch14/out'
def nml(d):
    s='&DRV\n'
    for k,v in d.items():
        if isinstance(v,(list,tuple)): v=','.join(('%.16g'%x if isinstance(x,float) else str(x)) for x in v)
        elif isinstance(v,bool): v='.TRUE.' if v else '.FALSE.'
        elif isinstance(v,str): v="'%s'"%v
        elif isinstance(v,float): v='%.16g'%v
        s+=' %s=%s,\n'%(k,v)
    return s+'/\n'
def run(exe,d):
    p=subprocess.run([OUT+'/'+exe],input=nml(d),capture_output=True,text=True)
    inc=[];it=[];fd=[];done=None
    for l in p.stdout.splitlines():
        w=l.split()
        if not w: continue
        if w[0]=='INC': inc.append([float(x) for x in w[1:]])
        elif w[0]=='IT': it.append([float(x) for x in w[1:]])
        elif w[0]=='FD': fd.append([float(x) for x in w[1:]])
        elif w[0]=='DONE': done=[int(x) for x in w[1:]]
    if p.returncode!=0 or done is None: raise RuntimeError(p.stdout[-500:]+p.stderr[-500:])
    A=np.array(inc)
    # columns: kinc t dt it eps1..6 sig1..6 sse spd scd sdv...
    R=dict(kinc=A[:,0],t=A[:,1],dt=A[:,2],it=A[:,3],eps=A[:,4:10],sig=A[:,10:16],sse=A[:,16],spd=A[:,17],scd=A[:,18],sdv=A[:,19:],IT=np.array(it),FD=np.array(fd),done=done)
    return R
# ---- viscoelastic material (Section 14.2)
E0,NU0=3000.0,0.4
GI=np.array([0.20,0.25,0.15]); KI=np.array([0.04,0.05,0.03]); TAU=np.array([0.1,1.0,10.0])
G0=E0/(2*(1+NU0)); K0=E0/(3*(1-2*NU0)); GINF=1-GI.sum(); KINF=1-KI.sum()
VEP=[E0,NU0,3.0]
for g,k,t in zip(GI,KI,TAU): VEP+= [g,k,t]
def gR(t): t=np.asarray(t,float)[...,None]; return G0*(GINF+(GI*np.exp(-t/TAU)).sum(-1))
def kR(t): t=np.asarray(t,float)[...,None]; return K0*(KINF+(KI*np.exp(-t/TAU)).sum(-1))
