import sys; sys.path.insert(0,'.')
from common import *
out={}
base=dict(NPROPS=12,PROPS=VEP,NSTATV=21,NSDVPR=3)
Mi=K0*KI+4/3*G0*GI; Minf=K0*KINF+4/3*G0*GINF
def rh(t,r,tr,Minf,Mi):
    t=np.asarray(t,float); tc=np.minimum(t,tr)
    return r*(Minf*tc+(Mi*TAU*np.exp(-t[:,None]/TAU)*(np.exp(tc[:,None]/TAU)-1)).sum(1))
e0,tr=0.01,0.5
D=run('drv_ve',dict(base,NSEG=5,SEGT=[0.5,1,5,20,100],SEGV=[e0]*5,SEGN=[1]*5,ICOMP=1,LAT='FIX'))
ref=rh(D['t'],e0/tr,tr,Minf,Mi)
out['tab']=dict(t=D['t'].tolist(),drv=D['sig'][:,0].tolist(),ref=ref.tolist(),err=np.abs(D['sig'][:,0]-ref).max(),s22=D['sig'][:,1].tolist(),
  ref22=rh(D['t'],e0/tr,tr,K0*KINF-2/3*G0*GINF,K0*KI-2/3*G0*GI).tolist(),gR=(gR:=gR_ if False else None) if False else None)
out['tab']['gR_over_G0']=[float(gR_/G0) for gR_ in gR(D['t'])] if False else [float(x/G0) for x in gR(D['t'])]
out['tab']['kR_over_K0']=[float(x/K0) for x in kR(D['t'])]
# SLS check: g1=.6, tau=2, G0=1000 (nu=.3 => E0=2600), k=0
nu=0.3; G=1000.0; E=2*G*(1+nu)
P=[E,nu,1.0,0.6,0.0,2.0]
D=run('drv_ve',dict(NPROPS=6,PROPS=P,NSTATV=7,NSEG=2,SEGT=[0.01,50.0],SEGV=[1.0,1.0],SEGN=[1,50],SEGR=[1.0,1.0],ICOMP=4,CTRL='S',LAT='FIX',NSDVPR=2))
J=lambda t:1e-3+1.5e-3*(1-np.exp(-t/5))
# ramp then hold: ref = 1/tr * int
def ref(t,trr=0.01):
    tc=np.minimum(t,trr); return (1e-3*tc+1.5e-3*(tc-5*np.exp(-t/5)*(np.exp(tc/5)-1)))/trr
t=D['t']; out['sls']=dict(err=float(np.max(np.abs(D['eps'][:,3]-ref(t))/ref(t))),g5=float(np.interp(5.01,t,D['eps'][:,3])),J5=float(J(5.0)),Jinf=2.5e-3,gend=float(D['eps'][-1,3]),t=t[-1])
x=0.5; a=np.exp(-x); b=(1-a)/x
out['A1']=dict(Ginf=400.0,G2=400+600*np.exp(-1),tauc=5.0,a=a,b=b,Galg=1000*(0.4+0.6*b))
a1=np.exp(-1.0); b1=(1-a1)
out['A2']=dict(h=1000*0.3*b1*1e-3,sig=0.7+1000*0.3*b1*1e-3,Galg=1000*(0.7+0.3*b1),b=b1,a=a1)
E_,H_,SY,TV=210000.,1000.,250.,10.
def fss(rate,m): return SY*(TV*E_*rate/(E_+H_))**(1/m)
f=fss(1e-2,2); out['A3']=dict(f=f,sig=E_*(SY+f+H_*0.05)/(E_+H_))
out['C2']=dict(f1=fss(1e-3,2),f2=fss(1e-2,2),dsig=E_/(E_+H_)*(fss(1e-2,2)-fss(1e-3,2)))
out['C2']['fvals']=[fss(1e-3,2),fss(1e-2,2),fss(1e-1,2)]
# WLF
C1,C2,dT=17.44,51.6,10.0; la=-C1*dT/(C2+dT); out['C1']=dict(log10aT=la,aT=10**la)
# b(x)
for x in [0.01,1,10]: out['bx_%g'%x]=(1-np.exp(-x))/x
json.dump(out,open(OUT+'/extra.json','w'),indent=1,default=float)
print(json.dumps(out,indent=1,default=float))
# hand check: one shear increment from rest, book material
D=run('drv_ve',dict(base,NSEG=1,SEGT=[0.5],SEGV=[0.001],SEGN=[1],ICOMP=4,LAT='FIX'))
bb=(1-np.exp(-0.5/TAU))/(0.5/TAU); Ga=G0*(GINF+(GI*bb).sum())
hand=dict(b=bb.tolist(),Galg=float(Ga),sig_hand=float(Ga*1e-3),sig_drv=float(D['sig'][0,3]))
D=run('drv_ve',dict(NPROPS=6,PROPS=[2600.,0.3,1.0,0.3,0.0,1.0],NSTATV=7,NSEG=1,SEGT=[1.0],SEGV=[1e-3],SEGN=[1],ICOMP=4,LAT='FIX'))
hand['A2_drv']=float(D['sig'][0,3])
j=json.load(open(OUT+'/extra.json')); j['hand']=hand; json.dump(j,open(OUT+'/extra.json','w'),indent=1,default=float)
print(hand)
