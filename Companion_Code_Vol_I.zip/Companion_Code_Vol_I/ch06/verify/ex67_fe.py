import numpy as np,sys
sys.path.insert(0,'/home/claude/book/ch06/verify')
from fe_q4 import q4
L,H=100.,20.; E0,nu=70000.,0.3; beta=0.02; c0=1.0
a=beta*c0/L            # strain gradient at T=1 (end of step)
def run(nx,ny,tt=1.0):
    XY,K,f,nid=q4(L,H,nx,ny,lambda x,y:E0,nu,eig=lambda x,y:beta*c0*tt*x/L)
    nn=len(XY); fixed=[0,1,2*nid(nx,0)+1]
    free=[d for d in range(2*nn) if d not in fixed]
    u=np.zeros(2*nn); u[free]=np.linalg.solve(K[np.ix_(free,free)],f[free]); return XY,u,nid,K
ux=lambda x,y:a*(x*x-y*y)/2; uy=lambda x,y:a*x*y
print('closed: ux(L,0)=%.5f ux(L,H)=%.5f uy(L,H)=%.5f uy(0.5L,H)=%.5f'%(ux(L,0),ux(L,H),uy(L,H),uy(L/2,H)))
for nx,ny in[(10,2),(20,4),(40,8),(80,16)]:
    XY,u,nid,K=run(nx,ny)
    print(nx,ny,'ux(L,0)=%.5f ux(L,H)=%.5f uy(L,H)=%.5f'%(u[2*nid(nx,0)],u[2*nid(nx,ny)],u[2*nid(nx,ny)+1]), 'maxerr',max(np.hypot(u[2*k]-ux(*XY[k]),u[2*k+1]-uy(*XY[k])) for k in range(len(XY))))
# stress at gauss points for 40x8: sigma = D(eps - eps*)
