import numpy as np
E0,FRES,EMAX,S0,SU=210000.,0.1,0.004,300.,400.; AK=1-FRES
def march(N):
    eps=np.linspace(0,EMAX,N+1); sig=[0.]; smax=0.
    for n in range(N):
        smax=max(smax,sig[-1]); d=min(1,max(0,(smax-S0)/(SU-S0)))
        sig.append(sig[-1]+E0*(1-AK*d)*(eps[n+1]-eps[n]))
    return eps,np.array(sig)
def exact(e):
    e=np.asarray(e,float); e0=S0/E0; x=AK*E0/(SU-S0); e1=e0+np.log(1/(1-AK))/x
    s=np.where(e<=e0,E0*e,np.where(e<=e1,S0+(SU-S0)/AK*(1-np.exp(-x*(e-e0))),SU+FRES*E0*(e-e1)))
    return s
if __name__=='__main__':
    print('exact',exact(EMAX))
    for N in(4,8,16,32,64,128,1024): print(N,march(N)[1][-1])
