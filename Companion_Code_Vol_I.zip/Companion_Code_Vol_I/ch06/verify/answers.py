import numpy as np
E0,S0,SU,K=210000.,300.,400.,0.9; ds=SU-S0
print('6A1: E(0.2)=%.1f E(0.6)=%.1f E(-0.1)=%.1f E(1.4)=%.1f f(E=45)=%.4f'%(np.interp(.2,[0,.4,.8],[70,50,20]),np.interp(.6,[0,.4,.8],[70,50,20]),70,20,0.4+(50-45)/30*0.4))
P,L,A=1000.,100.,10.; E0b=100000.; g=1.
print('6A2: exact %.5f  mean-E %.5f  err %.2f%%  eps(0)=%.2e eps(L)=%.2e'%(P*L*np.log(2)/(A*E0b*g),P*L/(A*1.5*E0b),(P*L/(A*1.5*E0b)/(P*L*np.log(2)/(A*E0b*g))-1)*100,100/E0b,100/(2*E0b)))
calls=20000*8*50*4; print('6A3: calls %.3e  at 3us %.0f s ; at 20us %.0f s'%(calls,calls*3e-6,calls*20e-6))
r=lambda de:K*E0*de/ds
print('6B1: crit monotone %.4e  stable %.4e'%(ds/(K*E0),2*ds/(K*E0)))
de=0.2e-3; rr=r(de); s3=ds/K*(1-(1-rr)**3); ex=ds/K*(1-np.exp(-K*E0*3*de/ds)); print(' r=%.3f s3=%.2f exact=%.2f err %.1f%%'%(rr,s3,ex,(s3/ex-1)*100))
de=0.7e-3; rr=r(de); print(' r(0.7e-3)=%.3f s1=%.1f s2=%.1f'%(rr,ds/K*(1-(1-rr)),ds/K*(1-(1-rr)**2)))
a=0.002/10; Lb=100; Hb=10
print('6B3: curvature %.2e uy(L,0)=%.3f ux(L,H)=%.3f'%(a,-a*Lb**2/2,a*Lb*Hb))
from ex66_curves import march,exact,EMAX
for N in(32,64,128): print(N,(march(N)[1][-1]/exact(EMAX)-1)*100)
e=[(march(N)[1][-1]/exact(EMAX)-1)*100 for N in (64,128,1024)]; print('ratio',e[0]/e[1],'p from 128->1024',np.log(e[1]/e[2])/np.log(8))
