"""Independent plane-stress Q4 (2x2 Gauss) finite element code used for Examples 6.5-1 and 6.7-1.
Units N, mm, MPa.  Element stiffness with E(x,y) sampled at the Gauss points; optional eigenstrain eps*(x,y,t) I."""
import numpy as np
def q4(L,H,nx,ny,Efun,nu,t=1.0,eig=None,force=None,fixed=None):
    xs=np.linspace(0,L,nx+1); ys=np.linspace(0,H,ny+1)
    nid=lambda i,j:j*(nx+1)+i
    XY=np.array([[x,y] for y in ys for x in xs]); nn=len(XY); K=np.zeros((2*nn,2*nn)); f=np.zeros(2*nn)
    g=1/np.sqrt(3); sg=np.array([[-1,-1],[1,-1],[1,1],[-1,1]],float)
    for j in range(ny):
        for i in range(nx):
            n=[nid(i,j),nid(i+1,j),nid(i+1,j+1),nid(i,j+1)]; X=XY[n]; dofs=np.array([[2*a,2*a+1] for a in n]).ravel()
            for xi in(-g,g):
                for et in(-g,g):
                    N=0.25*(1+sg[:,0]*xi)*(1+sg[:,1]*et)
                    dN=0.25*np.array([[sg[a,0]*(1+sg[a,1]*et),sg[a,1]*(1+sg[a,0]*xi)] for a in range(4)])
                    J=X.T@dN; dNx=dN@np.linalg.inv(J); x,y=N@X[:,0],N@X[:,1]; E=Efun(x,y)
                    D=E/(1-nu**2)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
                    B=np.zeros((3,8))
                    for a in range(4): B[0,2*a]=dNx[a,0];B[1,2*a+1]=dNx[a,1];B[2,2*a]=dNx[a,1];B[2,2*a+1]=dNx[a,0]
                    w=np.linalg.det(J)*t; K[np.ix_(dofs,dofs)]+=B.T@D@B*w
                    if eig is not None:
                        e=eig(x,y); f[dofs]+=B.T@D@np.array([e,e,0.0])*w
    return XY,K,f,nid
