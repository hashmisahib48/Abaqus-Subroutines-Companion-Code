      SUBROUTINE USDFLD(FIELD,STATEV,PNEWDT,DIRECT,T,CELENT,
     1 TIME,DTIME,CMNAME,ORNAME,NFIELD,NSTATV,NOEL,NPT,LAYER,
     2 KSPT,KSTEP,KINC,NDI,NSHR,COORD,JMAC,JMATYP,MATLAYO,LACCFLA)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME,ORNAME
      DIMENSION FIELD(NFIELD),STATEV(NSTATV),DIRECT(3,3),
     1 T(3,3),TIME(2),COORD(*),JMAC(*),JMATYP(*)
      DIMENSION ARRAY(15), JARRAY(15), PS(3), INTV(1), REALV(1)
      CHARACTER*3 FLGRAY(15)
      CHARACTER*8 CHARV(1)
!
!     As Listing 6.5, plus control of the increment size.
!     STATEV: (1) largest stress so far, (2) damage, (3) largest
!     stress at the previous call (MPa), (4) previous DTIME (s)
      PARAMETER (S0 = 300.0D0, SU = 400.0D0)
      PARAMETER (DDMAX = 0.1D0, PMIN = 0.25D0)
!
      DO K = 1, 15
         ARRAY(K) = 0.0D0
      ENDDO
      CALL GETVRM('S',ARRAY,JARRAY,FLGRAY,JRCD,JMAC,JMATYP,
     1            MATLAYO,LACCFLA)
      IF (JRCD .NE. 0) THEN
         CALL STDB_ABQERR(-3,'USDFLD: GETVRM failed for S',
     1                    INTV,REALV,CHARV)
      ENDIF
      CALL SPRINC(ARRAY,PS,1,3,3)
      PSM  = MAX(PS(1), PS(2), PS(3))
      SMAX = MAX(STATEV(1), PSM)
      DAM  = MIN(1.0D0, MAX(0.0D0, (SMAX - S0)/(SU - S0)))
!
!     stress expected at the end of this increment, extrapolated
!     from the last one (no prediction at the first call)
      IF (STATEV(4) .GT. 0.0D0) THEN
         SPRED = PSM + (PSM - STATEV(3))*DTIME/STATEV(4)
         DPRED = MIN(1.0D0, MAX(0.0D0,
     1           (MAX(SMAX,SPRED) - S0)/(SU - S0))) - DAM
         IF (DPRED .GT. DDMAX) PNEWDT = MAX(PMIN, DDMAX/DPRED)
      ENDIF
!
      STATEV(1) = SMAX
      STATEV(2) = DAM
      STATEV(3) = PSM
      STATEV(4) = DTIME
      FIELD(1)  = DAM
      RETURN
      END
