!     Diagnostic print, once per call at one material point
      IF (NOEL .EQ. 1 .AND. NPT .EQ. 1) THEN
         WRITE(7,*) 'USDFLD KSTEP KINC TIME(1)', KSTEP, KINC, TIME(1)
         WRITE(7,*) '   FIELD  ', (FIELD(K), K = 1, NFIELD)
         WRITE(7,*) '   STATEV ', (STATEV(K), K = 1, NSTATV)
      ENDIF
