!     TEST REPLACEMENT for the Abaqus utility GETVRM, used only to compile and
!     exercise the listings of Chapter 6 outside Abaqus.  It is NOT the Abaqus
!     routine.  The driver places the stress components of the material point
!     (order 11, 22, 33, 12, 13, 23) in the COMMON block K6GV before each call.
      SUBROUTINE GETVRM(VAR,ARRAY,JARRAY,FLGRAY,JRCD,JMAC,JMATYP,
     1                  MATLAYO,LACCFLA)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) VAR
      DIMENSION ARRAY(*), JARRAY(*)
      CHARACTER*3 FLGRAY(*)
      COMMON /K6GV/ SSTUB(6), SDVSTUB(4)
      JRCD = 1
      IF (VAR(1:1) .EQ. 'S' .AND. LEN_TRIM(VAR) .EQ. 1) THEN
         DO K = 1, 6
            ARRAY(K) = SSTUB(K)
         ENDDO
         JRCD = 0
      ENDIF
      RETURN
      END
