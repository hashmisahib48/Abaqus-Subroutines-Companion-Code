!     Test of Listing 6.5 (USDFLD with PNEWDT) outside Abaqus.  The driver
!     imitates automatic incrementation in the simplest way: if the routine
!     returns PNEWDT < 1 the increment is abandoned, STATEV is restored and
!     the increment is repeated with DTIME*PNEWDT; after an increment that
!     needed no cutback the next size is min(planned, 1.5 DTIME).
!     Same material and strain ramp as drv_ex66.f.  Units N, mm, MPa, s.
      PROGRAM DRV68
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E0 = 210000.0D0, FRES = 0.1D0, EMAX = 0.004D0)
      PARAMETER (S0 = 300.0D0, SU = 400.0D0)
      DIMENSION FIELD(1), STATEV(4), SAVE(4), DIRECT(3,3), T(3,3)
      DIMENSION TIME(2), COORD(3), JMAC(1), JMATYP(1), NLIST(4)
      CHARACTER*80 CMNAME, ORNAME
      COMMON /K6GV/ SSTUB(6), SDVSTUB(4)
      DATA NLIST /4, 8, 16, 32/
      CMNAME = 'DEGRADE'
      ORNAME = ' '
      AK = 1.0D0 - FRES
      EPS0 = S0/E0
      X = AK*E0/(SU - S0)
      EPS1 = EPS0 + LOG(1.0D0/(1.0D0 - AK))/X
      SIGEX = SU + FRES*E0*(EMAX - EPS1)
      WRITE(*,'(A)') '    N0  accepted  cutbacks  sigma(EMAX)  error(%)'
      DO IR = 1, 4
         DPLAN = 1.0D0/NLIST(IR)
         DT = DPLAN
         TNOW = 0.0D0
         SIG = 0.0D0
         NACC = 0
         NCUT = 0
         STATEV = 0.0D0
         DO WHILE (TNOW .LT. 1.0D0 - 1.0D-12)
            DT = MIN(DT, 1.0D0 - TNOW)
            SAVE = STATEV
            DO
               STATEV = SAVE
               SSTUB(1:6) = 0.0D0
               SSTUB(1) = SIG
               FIELD(1) = 0.0D0
               PNEWDT = 1.0D0
               TIME(1) = TNOW
               TIME(2) = TNOW
               CALL USDFLD(FIELD,STATEV,PNEWDT,DIRECT,T,CELENT,TIME,
     1           DT,CMNAME,ORNAME,1,4,1,1,1,1,NACC+1,1,2,1,COORD,
     2           JMAC,JMATYP,MATLAYO,LACCFLA)
               IF (PNEWDT .GE. 1.0D0) EXIT
               DT = DT*PNEWDT
               NCUT = NCUT + 1
            ENDDO
            EF = E0*(1.0D0 - (1.0D0 - FRES)*FIELD(1))
            SIG = SIG + EF*EMAX*DT
            TNOW = TNOW + DT
            NACC = NACC + 1
            IF (NCUT .GT. 0) THEN
               DT = MIN(DPLAN, 1.5D0*DT)
            ELSE
               DT = DPLAN
            ENDIF
         ENDDO
         WRITE(*,'(I6,I10,I10,F13.4,F10.4)') NLIST(IR), NACC, NCUT,
     1     SIG, 100.0D0*(SIG/SIGEX - 1.0D0)
      ENDDO
      END
