      SUBROUTINE USDFLD(FIELD,STATEV,PNEWDT,DIRECT,T,CELENT,
     1 TIME,DTIME,CMNAME,ORNAME,NFIELD,NSTATV,NOEL,NPT,LAYER,
     2 KSPT,KSTEP,KINC,NDI,NSHR,COORD,JMAC,JMATYP,MATLAYO,LACCFLA)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME,ORNAME
      DIMENSION FIELD(NFIELD),STATEV(NSTATV),DIRECT(3,3),
     1 T(3,3),TIME(2),COORD(*),JMAC(*),JMATYP(*)
      DIMENSION ARRAY(15), JARRAY(15), PS(3), INTV(1), REALV(1)
      CHARACTER*3 FLGRAY(15)
      CHARACTER*8 CHARV(1)
!
!     Irreversible stiffness degradation driven by the largest
!     principal stress seen at the start of any increment so far.
!     S0, SU in MPa: damage starts at S0 and is complete at SU.
      PARAMETER (S0 = 300.0D0, SU = 400.0D0)
!
      DO K = 1, 15
         ARRAY(K) = 0.0D0
      ENDDO
      CALL GETVRM('S',ARRAY,JARRAY,FLGRAY,JRCD,JMAC,JMATYP,
     1            MATLAYO,LACCFLA)
      IF (JRCD .NE. 0) THEN
         CALL STDB_ABQERR(-3,'USDFLD: GETVRM failed for S',
     1                    INTV,REALV,CHARV)
      ENDIF
      CALL SPRINC(ARRAY,PS,1,3,3)
!
      SMAX = MAX(STATEV(1), PS(1), PS(2), PS(3))
      DAM  = MIN(1.0D0, MAX(0.0D0, (SMAX - S0)/(SU - S0)))
      STATEV(1) = SMAX
      STATEV(2) = DAM
      FIELD(1)  = DAM
!
      RETURN
      END
