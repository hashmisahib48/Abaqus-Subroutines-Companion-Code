!     Strain-driven test of Listing 6.4 outside Abaqus (Example 6.6-1).
!     Uniaxial stress, strain ramped to EMAX in N equal increments.  In each
!     increment the driver (i) puts the stress at the start of the increment
!     where the GETVRM stub returns it, (ii) calls USDFLD, (iii) reads E(f)
!     from the table  f = 0: E0,  f = 1: (1-KAPPA) E0, and (iv) updates the
!     stress incrementally,  SIG = SIG + E(f) DEPS.   Units N, mm, MPa.
      PROGRAM DRV66
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E0 = 210000.0D0, FRES = 0.1D0, EMAX = 0.004D0)
      PARAMETER (S0 = 300.0D0, SU = 400.0D0)
      DIMENSION FIELD(1), STATEV(3), DIRECT(3,3), T(3,3), TIME(2)
      DIMENSION COORD(3), JMAC(1), JMATYP(1), NLIST(8)
      CHARACTER*80 CMNAME, ORNAME
      COMMON /K6GV/ SSTUB(6), SDVSTUB(4)
      DATA NLIST /2, 4, 8, 16, 32, 64, 128, 1024/
      CMNAME = 'DEGRADE'
      ORNAME = ' '
      AK = 1.0D0 - FRES
!     closed-form solution of dsig/deps = E0 (1 - AK d(sig)), Eq. (6.6-3)
      EPS0 = S0/E0
      X = AK*E0/(SU - S0)
      EPS1 = EPS0 + LOG(1.0D0/(1.0D0 - AK))/X
      SIGEX = SU + FRES*E0*(EMAX - EPS1)
      WRITE(*,'(A,F9.6,A,F9.4)') ' eps1 =', EPS1,
     1  '   exact sigma(EMAX) =', SIGEX
      WRITE(*,'(A)') '     N      DEPS   sigma(EMAX)   error(%)
     1   d(end)'
      DO IR = 1, 8
         N = NLIST(IR)
         DEPS = EMAX/N
         SIG = 0.0D0
         DO K = 1, 3
            STATEV(K) = 0.0D0
         ENDDO
         DO IN = 1, N
            DO K = 1, 6
               SSTUB(K) = 0.0D0
            ENDDO
            SSTUB(1) = SIG
            FIELD(1) = 0.0D0
            TIME(1) = (IN-1)*DEPS/EMAX
            TIME(2) = TIME(1)
            DTIME = DEPS/EMAX
            PNEWDT = 1.0D0
            CALL USDFLD(FIELD,STATEV,PNEWDT,DIRECT,T,CELENT,TIME,
     1        DTIME,CMNAME,ORNAME,1,3,1,1,1,1,IN,IN,2,1,COORD,
     2        JMAC,JMATYP,MATLAYO,LACCFLA)
            EF = E0*(1.0D0 - (1.0D0 - FRES)*FIELD(1))
            SIG = SIG + EF*DEPS
         ENDDO
         WRITE(*,'(I6,F11.6,F13.4,F11.4,F9.4)') N, DEPS, SIG,
     1     100.0D0*(SIG/SIGEX - 1.0D0), STATEV(2)
      ENDDO
      END
