      SUBROUTINE UFIELD(FIELD,KFIELD,NSECPT,KSTEP,KINC,TIME,NODE,
     1 COORDS,TEMP,DTEMP,NFIELD)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION FIELD(NSECPT,*), TIME(2), COORDS(3),
     1 TEMP(NSECPT), DTEMP(NSECPT)
!
!     Swelling variable C(x,t) = C0 (t/TSTEP) (x/XL), dimensionless.
!     XL in mm, TSTEP in s; TIME(1) is the step time.
      PARAMETER (C0 = 1.0D0, XL = 100.0D0, TSTEP = 1.0D0)
!
      FIELD(1,1) = C0*(TIME(1)/TSTEP)*(COORDS(1)/XL)
!
      RETURN
      END
