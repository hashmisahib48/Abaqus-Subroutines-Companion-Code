!     Driver for Example 6.5-1.  A one-dimensional chain of two-node bar
!     elements (area A, length XL) with two Gauss points per element; at each
!     Gauss point the driver calls USDFLD as Abaqus would, then reads E(f)
!     from the *ELASTIC table.  Tip displacement is compared with the
!     closed form  U = P L ln(1+G)/(A E0 G).     Units N, mm, MPa.
      PROGRAM DRV65
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (XL = 100.0D0, AREA = 10.0D0, PL = 1000.0D0)
      PARAMETER (E0 = 70000.0D0, E1 = 210000.0D0, G = 2.0D0)
      DIMENSION FIELD(1), STATEV(1), DIRECT(3,3), T(3,3), TIME(2)
      DIMENSION COORD(3), JMAC(1), JMATYP(1)
      DIMENSION DG(500), UG(500), RG(500), SG(500)
      CHARACTER*80 CMNAME, ORNAME
      CMNAME = 'GRADED'
      ORNAME = ' '
      EXACT = PL*XL*LOG(1.0D0 + G)/(AREA*E0*G)
      WRITE(*,'(A,F10.6)') ' closed form tip displacement (mm):', EXACT
      DO IT = 1, 4
         NEL = 10*2**(IT-1)
         H = XL/NEL
         DO K = 1, NEL+1
            DG(K) = 0.0D0
            SG(K) = 0.0D0
            RG(K) = 0.0D0
         ENDDO
         DO IE = 1, NEL
            X1 = (IE-1)*H
            AK = 0.0D0
            DO IG = 1, 2
               XI = (2*IG - 3)/SQRT(3.0D0)
               COORD(1) = X1 + 0.5D0*H*(1.0D0 + XI)
               COORD(2) = 0.0D0
               COORD(3) = 0.0D0
               FIELD(1) = 0.0D0
               CALL USDFLD(FIELD,STATEV,PNEWDT,DIRECT,T,CELENT,TIME,
     1           DTIME,CMNAME,ORNAME,1,1,IE,IG,1,1,1,1,3,3,COORD,
     2           JMAC,JMATYP,MATLAYO,LACCFLA)
!              *ELASTIC table: E = E0 at f = 0, E1 at f = XL
               EF = E0 + (E1 - E0)*FIELD(1)/XL
               AK = AK + EF*AREA/H
            ENDDO
            AK = 0.5D0*AK
            DG(IE)   = DG(IE) + AK
            DG(IE+1) = DG(IE+1) + AK
            SG(IE)   = SG(IE) - AK
         ENDDO
!        tridiagonal solve, node 1 fixed, load PL at node NEL+1
         N = NEL + 1
         RG(N) = PL
         CALL SOLVE(DG, SG, RG, N, UG)
         WRITE(*,'(A,I4,A,F10.6,A,F8.4,A)') ' NEL =', NEL,
     1     '  tip displacement =', UG(N), '  error ',
     2     100.0D0*(UG(N)/EXACT - 1.0D0), ' %'
      ENDDO
      END
!
      SUBROUTINE SOLVE(D, S, R, N, U)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(*), S(*), R(*), U(*), DD(500), RR(500)
!     elimination for the free nodes 2..N (node 1 fixed); S(K) couples K,K+1
      DO K = 2, N
         DD(K) = D(K)
         RR(K) = R(K)
      ENDDO
      DO K = 3, N
         W = S(K-1)/DD(K-1)
         DD(K) = DD(K) - W*S(K-1)
         RR(K) = RR(K) - W*RR(K-1)
      ENDDO
      U(1) = 0.0D0
      U(N) = RR(N)/DD(N)
      DO K = N-1, 2, -1
         U(K) = (RR(K) - S(K)*U(K+1))/DD(K)
      ENDDO
      RETURN
      END
