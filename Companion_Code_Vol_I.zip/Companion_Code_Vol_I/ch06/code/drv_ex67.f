!     Driver for Example 6.7-1: calls UFIELD at the nodes of a regular
!     grid as Abaqus would (individual-variable mode, NSECPT = 1) and
!     compares the result with C = C0 (t/TSTEP)(x/XL).   Units mm, s.
      PROGRAM DRV67
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FIELD(1,1), TIME(2), COORDS(3), TEMP(1), DTEMP(1)
      DMAX = 0.0D0
      TEMP(1) = 1.0D0
      DTEMP(1) = 0.0D0
      NODE = 0
      DO IT = 1, 5
         TIME(1) = 0.25D0*IT
         TIME(2) = TIME(1)
         DO IX = 0, 50
            NODE = NODE + 1
            COORDS(1) = 2.0D0*IX
            COORDS(2) = 0.0D0
            COORDS(3) = 0.0D0
            FIELD(1,1) = -1.0D0
            CALL UFIELD(FIELD,1,1,1,IT,TIME,NODE,COORDS,TEMP,DTEMP,1)
            CEX = TIME(1)*COORDS(1)/100.0D0
            DMAX = MAX(DMAX, ABS(FIELD(1,1) - CEX))
         ENDDO
      ENDDO
      WRITE(*,'(A,I6,A,E10.3)') ' nodes x increments:', NODE,
     1  '   max |C - C0 t x/L| =', DMAX
      FIELD(1,1) = -1.0D0
      TIME(1) = 1.0D0
      COORDS(1) = 100.0D0
      CALL UFIELD(FIELD,1,1,1,5,TIME,1,COORDS,TEMP,DTEMP,1)
      WRITE(*,'(A,F8.4)') ' C(x = L, t = 1) =', FIELD(1,1)
      END
