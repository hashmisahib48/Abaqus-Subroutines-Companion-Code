      SUBROUTINE UMAT(STRESS,STATEV,DDSDDE,SSE,SPD,SCD,
     1 RPL,DDSDDT,DRPLDE,DRPLDT,
     2 STRAN,DSTRAN,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CMNAME,
     3 NDI,NSHR,NTENS,NSTATV,PROPS,NPROPS,COORDS,DROT,PNEWDT,
     4 CELENT,DFGRD0,DFGRD1,NOEL,NPT,LAYER,KSPT,JSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION STRESS(NTENS),STATEV(NSTATV),DDSDDE(NTENS,NTENS),
     1 DDSDDT(NTENS),DRPLDE(NTENS),STRAN(NTENS),DSTRAN(NTENS),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3),
     3 DROT(3,3),DFGRD0(3,3),DFGRD1(3,3),JSTEP(4)
!
!     J2 plasticity, isotropic hardening, radial return
!     PROPS: 1 E (MPa)   2 NU (-)   3 SY0 (MPa)   4 H (MPa)
!            5 Q (MPa)   6 B (-)    7 NTAB        8 ITANG
!            9... NTAB pairs (SY (MPa), EP) of the table
!     STATEV: 1 PEEQ; 2..NTENS+1 plastic strain (eng. shear)
!     ITANG: 0 consistent, 1 continuum tangent, 2 elastic matrix
!
      DIMENSION STRIAL(6), S(6), DEP(6)
      PARAMETER (TOL = 1.0D-10)
!
      E   = PROPS(1)
      XNU = PROPS(2)
      SY0 = PROPS(3)
      IF (NDI .NE. 3 .OR. NSTATV .LT. NTENS+1 .OR.
     1    E .LE. 0.0D0 .OR. XNU .LE. -1.0D0 .OR.
     2    XNU .GE. 0.5D0 .OR. SY0 .LE. 0.0D0) THEN
         WRITE(7,*) 'UMAT: needs NDI=3, NSTATV>=NTENS+1, props'
         CALL XIT
      ENDIF
      XMU = E/(2.0D0*(1.0D0 + XNU))
      XK  = E/(3.0D0*(1.0D0 - 2.0D0*XNU))
!
!     elastic predictor
      CALL K13_ELAS(DDSDDE, NDI, NTENS, XK, XMU)
      DO I = 1, NTENS
         STRIAL(I) = STRESS(I)
         DO J = 1, NTENS
            STRIAL(I) = STRIAL(I) + DDSDDE(I,J)*DSTRAN(J)
         ENDDO
      ENDDO
      EPBAR = STATEV(1)
      CALL K13_HARD(PROPS, NPROPS, EPBAR, SY, HP)
      CALL K13_DEV(STRIAL, NTENS, P, S, Q, SN2)
      DP = 0.0D0
      DEP = 0.0D0
      SYN = SY
      IF (Q - SY .LE. TOL*SY0) THEN
!        elastic step: the trial state is the new state
         DO I = 1, NTENS
            STRESS(I) = STRIAL(I)
         ENDDO
      ELSE
         CALL K13_RET(PROPS, NPROPS, XMU, Q, EPBAR, DP, SYN, HPN,
     1                IERR)
         IF (IERR .NE. 0) THEN
            PNEWDT = 0.5D0
            RETURN
         ENDIF
         CALL K13_UPD(STRESS, DEP, P, S, Q, DP, XMU, NDI, NTENS)
         CALL K13_TAN(DDSDDE, S, SN2, DP, Q, XMU, HPN, NDI, NTENS,
     1                NINT(PROPS(8)))
      ENDIF
!
!     state variables, energies
      STATEV(1) = EPBAR + DP
      DO I = 1, NTENS
         STATEV(1+I) = STATEV(1+I) + DEP(I)
      ENDDO
      CALL K13_DEV(STRESS, NTENS, P, S, Q, SN2)
      SSE = P*P/(2.0D0*XK) + SN2/(4.0D0*XMU)
      SPD = SPD + 0.5D0*(SY + SYN)*DP
!
      RETURN
      END
!
      SUBROUTINE K13_ELAS(D, NDI, NTENS, XK, XMU)
!     Elastic stiffness: bulk modulus XK, shear modulus XMU (MPa)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(NTENS,NTENS)
      D = 0.0D0
      DO J = 1, NDI
         DO I = 1, NDI
            D(I,J) = XK - 2.0D0*XMU/3.0D0
         ENDDO
         D(J,J) = D(J,J) + 2.0D0*XMU
      ENDDO
      DO K = NDI+1, NTENS
         D(K,K) = XMU
      ENDDO
      RETURN
      END
!
      SUBROUTINE K13_DEV(SIG, NTENS, P, S, Q, SN2)
!     Mean stress P, deviator S, S:S (SN2), von Mises stress Q
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION SIG(NTENS), S(NTENS)
      P = (SIG(1) + SIG(2) + SIG(3))/3.0D0
      DO I = 1, 3
         S(I) = SIG(I) - P
      ENDDO
      SN2 = S(1)**2 + S(2)**2 + S(3)**2
      DO I = 4, NTENS
         S(I) = SIG(I)
         SN2 = SN2 + 2.0D0*S(I)**2
      ENDDO
      Q = SQRT(1.5D0*SN2)
      RETURN
      END
!
      SUBROUTINE K13_HARD(PROPS, NPROPS, EP, SY, HP)
!     Yield stress SY and slope HP = dSY/dEP (MPa) at PEEQ = EP:
!     SY0 + H*EP + Q*(1 - EXP(-B*EP)), or the table of pairs
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(NPROPS)
      NTAB = NINT(PROPS(7))
      IF (NTAB .LE. 0) THEN
         EX = EXP(-PROPS(6)*EP)
         SY = PROPS(3) + PROPS(4)*EP + PROPS(5)*(1.0D0 - EX)
         HP = PROPS(4) + PROPS(5)*PROPS(6)*EX
      ELSE
         SY = PROPS(9+2*(NTAB-1))
         HP = 0.0D0
         DO K = 1, NTAB-1
            E1 = PROPS(10+2*(K-1))
            E2 = PROPS(10+2*K)
            IF (EP .LT. E2) THEN
               HP = (PROPS(9+2*K) - PROPS(9+2*(K-1)))/(E2 - E1)
               SY = PROPS(9+2*(K-1)) + HP*(EP - E1)
               EXIT
            ENDIF
         ENDDO
      ENDIF
      RETURN
      END
!
      SUBROUTINE K13_RET(PROPS, NPROPS, XMU, Q, EPBAR, DP, SYN,
     1                   HPN, IERR)
!     Solve  Q - 3*XMU*DP - SY(EPBAR+DP) = 0  for DP (Newton)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(NPROPS)
      PARAMETER (MAXIT = 50, TOL = 1.0D-12)
      IERR = 0
      CALL K13_HARD(PROPS, NPROPS, EPBAR, SY, HP)
      DP = (Q - SY)/(3.0D0*XMU + HP)
      DO IT = 1, MAXIT
         CALL K13_HARD(PROPS, NPROPS, EPBAR + DP, SYN, HPN)
         G = Q - 3.0D0*XMU*DP - SYN
         IF (ABS(G) .LE. TOL*PROPS(3)) RETURN
         DP = DP + G/(3.0D0*XMU + HPN)
      ENDDO
      IERR = 1
      RETURN
      END
!
      SUBROUTINE K13_UPD(STRESS, DEP, P, S, Q, DP, XMU, NDI,
     1                   NTENS)
!     Radial return: new stress and plastic strain increment
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION STRESS(NTENS), DEP(NTENS), S(NTENS)
      THETA = 1.0D0 - 3.0D0*XMU*DP/Q
      DO I = 1, NTENS
         STRESS(I) = THETA*S(I)
         DEP(I) = 1.5D0*DP*S(I)/Q
      ENDDO
      DO I = 1, NDI
         STRESS(I) = STRESS(I) + P
      ENDDO
      DO I = NDI+1, NTENS
         DEP(I) = 2.0D0*DEP(I)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K13_TAN(D, S, SN2, DP, Q, XMU, HPN, NDI, NTENS,
     1                   ITANG)
!     Consistent tangent (ITANG 1: continuum, 2: elastic matrix)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(NTENS,NTENS), S(NTENS), XN(6)
      IF (ITANG .EQ. 2) RETURN
      THETA = 1.0D0 - 3.0D0*XMU*DP/Q
      THBAR = 3.0D0*XMU/(3.0D0*XMU + HPN) - (1.0D0 - THETA)
      IF (ITANG .EQ. 1) THEN
         THETA = 1.0D0
         THBAR = 3.0D0*XMU/(3.0D0*XMU + HPN)
      ENDIF
      XK = D(1,2) + 2.0D0*XMU/3.0D0
      DO I = 1, NTENS
         XN(I) = S(I)/SQRT(SN2)
      ENDDO
      D = 0.0D0
      DO J = 1, NDI
         DO I = 1, NDI
            D(I,J) = XK - 2.0D0*THETA*XMU/3.0D0
         ENDDO
         D(J,J) = D(J,J) + 2.0D0*THETA*XMU
      ENDDO
      DO K = NDI+1, NTENS
         D(K,K) = THETA*XMU
      ENDDO
      DO J = 1, NTENS
         DO I = 1, NTENS
            D(I,J) = D(I,J) - 2.0D0*XMU*THBAR*XN(I)*XN(J)
         ENDDO
      ENDDO
      RETURN
      END
