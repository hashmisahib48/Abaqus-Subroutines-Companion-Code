      PROGRAM UMATDRV
!     Single-point strain driver for a UMAT (Abaqus/Standard interface,
!     Abaqus 2024).  Reads the namelist DRV from the standard input.
!     MODE = 'USTRAIN'  uniaxial strain      (e11 given, other e = 0)
!            'USTRESS'  uniaxial stress      (e11 given, s22 = s33 = 0,
!                                             lateral strains by Newton)
!            'SHEAR'    simple shear         (g12 given, other e = 0)
!     Link with any UMAT:  gfortran umatdrv.f umat.f stubs.f
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NTMAX = 6, NPMAX = 50, NSMAX = 50, NSGMAX = 20)
      CHARACTER*8 MODE
      LOGICAL FDCHK, ITPRINT, INITCALL, EXTRAP
      DIMENSION PROPS(NPMAX), STATEV0(NSMAX), SIG0(NTMAX)
      DIMENSION TARGET(NSGMAX)
      NAMELIST /DRV/ MODE, NTENS, NDI, NSHR, NPROPS, PROPS, NSTATV,
     1   STATEV0, SIG0, NSEG, TARGET, NINC, TSEG, DDFAC, TOL, MAXIT,
     2   ROTSEG, HFD, FDCHK, ITPRINT, NSDVPR, INITCALL, EXTRAP
!     defaults (units: N, mm, MPa, s)
      MODE = 'USTRAIN'
      NTENS = 6
      NDI = 3
      NSHR = 3
      NPROPS = 0
      PROPS = 0.0D0
      NSTATV = 8
      STATEV0 = 0.0D0
      SIG0 = 0.0D0
      NSEG = 1
      TARGET = 0.0D0
      NINC = 1
      TSEG = 1.0D0
      DDFAC = 1.0D0
      TOL = 1.0D-6
      MAXIT = 25
      ROTSEG = 0.0D0
      HFD = 1.0D-6
      FDCHK = .FALSE.
      ITPRINT = .FALSE.
      NSDVPR = 4
      INITCALL = .TRUE.
      EXTRAP = .FALSE.
      READ(5, NML=DRV)
      CALL K11D_RUN(MODE, NTENS, NDI, NSHR, NPROPS, PROPS, NSTATV,
     1   STATEV0, SIG0, NSEG, TARGET, NINC, TSEG, DDFAC, TOL, MAXIT,
     2   ROTSEG, HFD, FDCHK, ITPRINT, NSDVPR, INITCALL, EXTRAP)
      END
!
      SUBROUTINE K11D_RUN(MODE, NTENS, NDI, NSHR, NPROPS, PROPS,
     1   NSTATV, STATEV0, SIG0, NSEG, TARGET, NINC, TSEG, DDFAC, TOL,
     2   MAXIT, ROTSEG, HFD, FDCHK, ITPRINT, NSDVPR, INITCALL,
     3   EXTRAP)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0, BIG = 1.0D36)
      CHARACTER*8 MODE
      CHARACTER*80 CMNAME
      LOGICAL FDCHK, ITPRINT, INITCALL, OK, CUT, USTR, EXTRAP
      DIMENSION PROPS(NPROPS), STATEV0(*), SIG0(*), TARGET(*)
!     state at the start of the increment (converged), and trial values
      DIMENSION STRESS0(NTENS), STATEV(NSTATV), STATEVS(NSTATV)
      DIMENSION STRESS(NTENS), STRANS(NTENS), STRANR(NTENS)
      DIMENSION SIGR(NTENS), DSTRAN(NTENS), DDSDDE(NTENS,NTENS)
      DIMENSION DDSDDT(NTENS), DRPLDE(NTENS), STRAN(NTENS)
      DIMENSION TIME(2), PREDEF(1), DPRED(1), COORDS(3)
      DIMENSION DROT(3,3), DFGRD0(3,3), DFGRD1(3,3), JSTEP(4)
      DIMENSION RINC(3,3), RCUM(3,3), RNEW(3,3), ROW(2*NTENS+NSTATV+8)
      DIMENSION DDFD(NTENS,NTENS), DLAST(NTENS)
      DIMENSION WRKS(NSTATV), WRKP(NTENS), WRKM(NTENS), DSP(NTENS)
      DIMENSION AL(NTENS-1,NTENS-1), RL(NTENS-1)
      CMNAME = 'DRIVER'
      NOEL = 1
      NPT = 1
      LAYER = 1
      KSPT = 1
      CELENT = 1.0D0
      TEMP = 20.0D0
      DTEMP = 0.0D0
      PREDEF(1) = 0.0D0
      DPRED(1) = 0.0D0
      COORDS = 0.0D0
      JSTEP = 0
      DTIME = 0.0D0
      NL = NTENS - 1
      IDRV = 1
      IF (MODE(1:2) .EQ. 'SH') IDRV = NDI + 1
      USTR = MODE(1:5) .EQ. 'USTRE'
      IF (USTR .AND. NTENS .NE. 6) THEN
         WRITE(*,*) 'USTRESS needs NTENS = 6'
         STOP 2
      ENDIF
      NP = MIN(NSDVPR, NSTATV)
      NR = 1 + NTENS + NTENS + 2 + NP
      DO I = 1, NTENS
         STRESS0(I) = SIG0(I)
         STRANS(I) = 0.0D0
      ENDDO
      DO I = 1, NSTATV
         STATEVS(I) = STATEV0(I)
      ENDDO
      SSE0 = 0.0D0
      SPD0 = 0.0D0
      SCD0 = 0.0D0
      RCUM = 0.0D0
      RCUM(1,1) = 1.0D0
      RCUM(2,2) = 1.0D0
      RCUM(3,3) = 1.0D0
      TTOT = 0.0D0
      KINC = 0
      NCALL = 0
      NCUTS = 0
      DLAST = 0.0D0
      DFLAST = 0.0D0
      UPREV = 0.0D0
      WRITE(*,'(2A,3(A,I3))') '# umatdrv  mode=', MODE, ' ntens=',
     1   NTENS, ' ndi=', NDI, ' nshr=', NSHR
!
!     Abaqus starts the first increment of a step with a zero strain
!     increment, in which only DDSDDE is used.  Output is discarded.
      IF (INITCALL) THEN
         DSTRAN = 0.0D0
         KINC = 1
         CALL SETCTX(1.0D0, 0.0D0)
         CALL EVAL(DSTRAN, STRESS, STATEV, DDSDDE, PNEWDT)
         KINC = 0
      ENDIF
!
      DO ISEG = 1, NSEG
         FRAC = 0.0D0
         DFRAC = 1.0D0/NINC
         NCONS = 0
         JSTEP(1) = ISEG
         DO WHILE (FRAC .LT. 1.0D0 - 1.0D-10)
            DFRAC = MIN(DFRAC, 1.0D0 - FRAC)
            KINC = KINC + 1
            DSTRAN = 0.0D0
            DSTRAN(IDRV) = (TARGET(ISEG) - UPREV)*DFRAC
            IF (EXTRAP .AND. USTR .AND. DFLAST .GT. 0.0D0) THEN
!              initial guess: lateral increments of the last increment
               DO I = 2, NTENS
                  DSTRAN(I) = DLAST(I)*DFRAC/DFLAST
               ENDDO
            ENDIF
            CALL SETCTX(DFRAC, ROTSEG*PI/180.0D0*DFRAC)
            OK = .FALSE.
            CUT = .FALSE.
            DO IT = 1, MAXIT
               CALL EVAL(DSTRAN, STRESS, STATEV, DDSDDE, PNEWDT)
               IF (PNEWDT .LT. 1.0D0) THEN
                  CUT = .TRUE.
                  EXIT
               ENDIF
               IF (.NOT. USTR) THEN
                  OK = .TRUE.
                  EXIT
               ENDIF
!              uniaxial stress: residual = lateral stress
               RES = 0.0D0
               DO I = 1, NL
                  RL(I) = -STRESS(I+1)
                  RES = MAX(RES, ABS(STRESS(I+1)))
               ENDDO
               IF (ITPRINT)
     1            WRITE(*,'(A,2I5,ES14.5)') 'IT', KINC, IT, RES
               IF (RES .LE. TOL) THEN
                  OK = .TRUE.
                  EXIT
               ENDIF
               DO J = 1, NL
                  DO I = 1, NL
                     AL(I,J) = DDFAC*DDSDDE(I+1,J+1)
                  ENDDO
               ENDDO
               CALL K11D_SOLVE(AL, RL, NL, IERR)
               IF (IERR .NE. 0) THEN
                  WRITE(*,*) 'singular Jacobian in increment', KINC
                  STOP 3
               ENDIF
               DO I = 1, NL
                  DSTRAN(I+1) = DSTRAN(I+1) + RL(I)
               ENDDO
            ENDDO
            IF (.NOT. OK) THEN
               NCUTS = NCUTS + 1
               NCONS = NCONS + 1
               IF (NCONS .GT. 12) THEN
                  WRITE(*,*) 'too many cutbacks in increment', KINC
                  STOP 4
               ENDIF
               KINC = KINC - 1
               IF (CUT) THEN
                  DFRAC = DFRAC*MAX(PNEWDT, 0.05D0)
               ELSE
                  DFRAC = 0.5D0*DFRAC
               ENDIF
               CYCLE
            ENDIF
!           finite-difference Jacobian at the converged increment,
!           from the START-of-increment state (before it is advanced)
            IF (FDCHK) THEN
               CALL FDJAC(DSTRAN, DDFD)
               ERR = 0.0D0
               REFV = 0.0D0
               DO J = 1, NTENS
                  DO I = 1, NTENS
                     ERR = MAX(ERR, ABS(DDFD(I,J) - DDSDDE(I,J)))
                     REFV = MAX(REFV, ABS(DDSDDE(I,J)))
                  ENDDO
               ENDDO
               WRITE(*,'(A,I6,ES14.5)') 'FD', KINC, ERR/REFV
            ENDIF
!           accept: the output of the converged call becomes the state
            NCONS = 0
            TTOT = TTOT + TSEG*DFRAC
            FRAC = FRAC + DFRAC
            DO I = 1, NTENS
               STRANS(I) = STRANR(I) + DSTRAN(I)
               STRESS0(I) = STRESS(I)
               DLAST(I) = DSTRAN(I)
            ENDDO
            DFLAST = DFRAC
            DO I = 1, NSTATV
               STATEVS(I) = STATEV(I)
            ENDDO
            SSE0 = SSEC
            SPD0 = SPDC
            SCD0 = SCDC
            RCUM = RNEW
            ROW(1) = TTOT
            ROW(2:1+NTENS) = STRANS
            ROW(2+NTENS:1+2*NTENS) = STRESS
            ROW(2+2*NTENS) = SSEC
            ROW(3+2*NTENS) = SPDC
            ROW(4+2*NTENS:3+2*NTENS+NP) = STATEV(1:NP)
            WRITE(*,'(A,I6,I4,*(ES16.8))') 'INC', KINC, IT, ROW(1:NR)
         ENDDO
         UPREV = TARGET(ISEG)
      ENDDO
      WRITE(*,'(A,3I8)') 'DONE', KINC, NCALL, NCUTS
      RETURN
!
      CONTAINS
!
!     Context of the current increment: rotated start state, DROT, TIME
      SUBROUTINE SETCTX(DF, ANG)
      C = COS(ANG)
      S = SIN(ANG)
      RINC = 0.0D0
      RINC(1,1) = C
      RINC(1,2) = -S
      RINC(2,1) = S
      RINC(2,2) = C
      RINC(3,3) = 1.0D0
      DROT = RINC
      DFGRD0 = RCUM
      RNEW = MATMUL(RINC, RCUM)
      DFGRD1 = RNEW
      JSTEP(3) = 0
      IF (ANG .NE. 0.0D0) JSTEP(3) = 1
      CALL K11D_ROTV(STRESS0, NDI, NSHR, RINC, 1, SIGR)
      CALL K11D_ROTV(STRANS, NDI, NSHR, RINC, 2, STRANR)
      TIME(1) = TSEG*FRAC
      TIME(2) = TTOT
      DTIME = TSEG*DF
      RETURN
      END
!
!     One UMAT call from the start-of-increment state (Eq. 11.2-1)
      SUBROUTINE EVAL(DSTR, SIGO, STVO, DDS, PNEWDT)
      DIMENSION DSTR(NTENS), SIGO(NTENS), STVO(NSTATV)
      DIMENSION DDS(NTENS,NTENS)
      SIGO = SIGR
      STVO = STATEVS
      SSE = SSE0
      SPD = SPD0
      SCD = SCD0
      RPL = 0.0D0
      DRPLDT = 0.0D0
      DDS = 1.0D10                    ! poison: UMAT must define all
      PNEWDT = BIG
      STRAN = STRANR
      NCALL = NCALL + 1
      CALL UMAT(SIGO, STVO, DDS, SSE, SPD, SCD, RPL, DDSDDT, DRPLDE,
     1   DRPLDT, STRAN, DSTR, TIME, DTIME, TEMP, DTEMP, PREDEF, DPRED,
     2   CMNAME, NDI, NSHR, NTENS, NSTATV, PROPS, NPROPS, COORDS,
     3   DROT, PNEWDT, CELENT, DFGRD0, DFGRD1, NOEL, NPT, LAYER, KSPT,
     4   JSTEP, KINC)
      SSEC = SSE
      SPDC = SPD
      SCDC = SCD
      RETURN
      END
!
!     Central-difference Jacobian d(sigma)/d(dstran), column by column
      SUBROUTINE FDJAC(DSTR, DDF)
      INTEGER I, J
      DIMENSION DSTR(NTENS), DDF(NTENS,NTENS), DDX(NTENS,NTENS)
      DO J = 1, NTENS
         DSP = DSTR
         DSP(J) = DSTR(J) + HFD
         CALL EVAL(DSP, WRKP, WRKS, DDX, PN)
         DSP(J) = DSTR(J) - HFD
         CALL EVAL(DSP, WRKM, WRKS, DDX, PN)
         DO I = 1, NTENS
            DDF(I,J) = (WRKP(I) - WRKM(I))/(2.0D0*HFD)
         ENDDO
      ENDDO
      RETURN
      END
      END
!
!     Gaussian elimination with partial pivoting: A x = b, b overwritten
      SUBROUTINE K11D_SOLVE(A, B, N, IERR)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(N,N), B(N)
      IERR = 0
      DO K = 1, N
         IP = K
         DO I = K + 1, N
            IF (ABS(A(I,K)) .GT. ABS(A(IP,K))) IP = I
         ENDDO
         IF (ABS(A(IP,K)) .LT. 1.0D-300) THEN
            IERR = 1
            RETURN
         ENDIF
         IF (IP .NE. K) THEN
            DO J = 1, N
               T = A(K,J)
               A(K,J) = A(IP,J)
               A(IP,J) = T
            ENDDO
            T = B(K)
            B(K) = B(IP)
            B(IP) = T
         ENDIF
         DO I = K + 1, N
            F = A(I,K)/A(K,K)
            DO J = K, N
               A(I,J) = A(I,J) - F*A(K,J)
            ENDDO
            B(I) = B(I) - F*B(K)
         ENDDO
      ENDDO
      DO K = N, 1, -1
         DO J = K + 1, N
            B(K) = B(K) - A(K,J)*B(J)
         ENDDO
         B(K) = B(K)/A(K,K)
      ENDDO
      RETURN
      END
!
!     V' = R V R^T for a stress (LSTR=1) or strain (LSTR=2) vector
      SUBROUTINE K11D_ROTV(V, NDI, NSHR, R, LSTR, VP)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION V(*), VP(*), R(3,3), A(3,3), B(3,3)
      FS = 1.0D0
      IF (LSTR .EQ. 2) FS = 0.5D0
      A = 0.0D0
      DO I = 1, NDI
         A(I,I) = V(I)
      ENDDO
      IF (NSHR .GE. 1) A(1,2) = FS*V(NDI+1)
      IF (NSHR .GE. 2) A(1,3) = FS*V(NDI+2)
      IF (NSHR .GE. 3) A(2,3) = FS*V(NDI+3)
      A(2,1) = A(1,2)
      A(3,1) = A(1,3)
      A(3,2) = A(2,3)
      DO I = 1, 3
         DO J = 1, 3
            B(I,J) = 0.0D0
            DO K = 1, 3
               DO L = 1, 3
                  B(I,J) = B(I,J) + R(I,K)*A(K,L)*R(J,L)
               ENDDO
            ENDDO
         ENDDO
      ENDDO
      DO I = 1, NDI
         VP(I) = B(I,I)
      ENDDO
      IF (NSHR .GE. 1) VP(NDI+1) = B(1,2)/FS
      IF (NSHR .GE. 2) VP(NDI+2) = B(1,3)/FS
      IF (NSHR .GE. 3) VP(NDI+3) = B(2,3)/FS
      RETURN
      END
