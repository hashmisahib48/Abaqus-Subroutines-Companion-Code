from fe_plast import *
from scipy.optimize import brentq
import json
R={}
# closed-form first yield (plane strain, elastic Lame)
a,b=50.,100.
def seq(p):
    sr=-p; st=p*(b*b+a*a)/(b*b-a*a); sz=NU*(sr+st)
    return np.sqrt(0.5*((st-sr)**2+(sr-sz)**2+(sz-st)**2))
py=brentq(lambda p:seq(p)-SY0,1,500); R['py']=py
# first yielded Gauss point vs mesh
for (n,nth) in ((4,2),(8,4),(16,8)):
    p=95.;
    while True:
        h,s=solve(0,[p],n=n,nth=nth)
        if s is not None and s[1][:,0].max()>0: break
        p+=0.5
    R[f'first_{n}']=p
# p=150 consistent: plastic radius, peeq, ur(a)
for n,nth in ((8,4),(16,8)):
    h,s=solve(0,[60.,100.,125.,150.],n=n,nth=nth); sig,sv,u,nodes=s
    # gauss point radii
    rg=[];pe=[]
    nodes_e=mesh(n,nth)[1]
    for e,el in enumerate(nodes_e):
        X=nodes[el]
        for q,(xi,eta) in enumerate(GP):
            N=0.25*np.array([(1-xi)*(1-eta),(1+xi)*(1-eta),(1+xi)*(1+eta),(1-xi)*(1+eta)]); rg.append(np.hypot(*(N@X))); pe.append(sv[e*4+q,0])
    rg=np.array(rg);pe=np.array(pe)
    rp=rg[pe>0].max()
    R[f'c150_{n}']=rp; R[f'ua150_{n}']=float(np.hypot(*u[0:2])); R[f'pmax_{n}']=pe.max()
    R[f'its_{n}']=[len(r)-1 for p,r,ok in h]
# estimate plastic radius, perfectly plastic incompressible
c=brentq(lambda c:2*SY0/np.sqrt(3)*(np.log(c/a)+(1-c*c/b/b)/2)-150,a,b); R['c150_est']=c
# histories for figure at p=150 (increment from 125)
Hs={}
for it in (0,1,2):
    h,_=solve(it,[60.,100.,125.,150.],maxit=40); Hs[it]=[(p,r,ok) for p,r,ok in h]
R['hist']={str(k):[(p,r,ok) for p,r,ok in v] for k,v in Hs.items()}
json.dump(R,open('../out/fe_res.json','w'))
print({k:v for k,v in R.items() if k!='hist'})
for it in (0,1,2): print(it,[ '%.2e'%x for x in Hs[it][3][1][:12]], Hs[it][3][2])
