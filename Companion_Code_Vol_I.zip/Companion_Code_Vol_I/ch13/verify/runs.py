"""Driver runs and closed-form checks for Chapter 13 -> ../out/results.json and text"""
import subprocess, json, numpy as np, re, sys
sys.path.insert(0,'.')
DRV='../out/drv13'
E,NU,SY0,H=210000.,0.3,250.,1000.; G=E/(2*(1+NU)); Et=E*H/(E+H); eY=SY0/E
def run(mode,props,targets,ninc=1,fd=False,itp=False,sig0=None,sv0=None,ntens=6,ndi=3,nshr=3,extra=''):
    P=','.join('%.12gD0'%p for p in props)
    nl=f"&DRV MODE='{mode}', NTENS={ntens}, NDI={ndi}, NSHR={nshr}, NPROPS={len(props)}, PROPS={P}, NSTATV=7, NSDVPR=7, NSEG={len(targets)}, "
    nl+=', '.join(f"TARGET({i+1})={t:.12g}D0" for i,t in enumerate(targets))+f", NINC={ninc}, FDCHK={'.TRUE.' if fd else '.FALSE.'}, ITPRINT={'.TRUE.' if itp else '.FALSE.'}, TOL=1.0D-10, "
    if sig0: nl+='SIG0='+','.join('%.12gD0'%x for x in sig0)+', '
    if sv0: nl+='STATEV0='+','.join('%.12gD0'%x for x in sv0)+', '
    nl+=extra+' /\n'
    out=subprocess.run([DRV],input=nl,capture_output=True,text=True).stdout
    rows=[];its=[];fds=[]
    for l in out.splitlines():
        t=l.split()
        if l.startswith('INC'): rows.append([float(x) for x in t[3:]]); 
        elif l.startswith('IT'): its.append((int(t[1]),int(t[2]),float(t[3])))
        elif l.startswith('FD'): fds.append(float(t[2]))
    return np.array(rows),its,fds,out
def P(it=0,Q=0.,b=0.,nt=0,tab=(),h=H): return [E,NU,SY0,h,Q,b,nt,it]+list(tab)
R={}
# A uniaxial stress bilinear
A={}
for n in (1,5,50):
    rows,its,_,_=run('USTRESS',P(),[0.05],ninc=n)
    s=rows[-1]; sig=s[7]; p=s[16+0]; 
    eps=s[1]; spd=s[14]; sse=s[13]; sv=s[15:22]
    sc=SY0+Et*(eps-eY); pc=(sc-SY0)/H
    A[n]=dict(eps=eps,sig=sig,sig_c=sc,peeq=sv[0],peeq_c=pc,spd=spd,spd_c=SY0*pc+H*pc*pc/2,sse=sse,sse_c=sc**2/(2*E),eps22=s[2],eps22_c=-NU*sc/E-0.5*pc)
R['A']=A
# strain points table (50 incs)
rows,_,_,_=run('USTRESS',P(),[0.05],ninc=50)
R['A_curve']=rows[:,[1,7,16]].tolist()
# B shear
B={}
rows,_,_,_=run('SHEAR',P(),[0.05],ninc=10); s=rows[-1]
gt=G*H/(3*G+H); tauy=SY0/np.sqrt(3); gy=tauy/G
B=dict(gamma=s[1+3],tau=s[7+3],tau_c=tauy+gt*(0.05-gy),peeq=s[15],peeq_c=(np.sqrt(3)*(tauy+gt*(0.05-gy)) -SY0)/H, s11=s[7],s33=s[9])
R['B']=B
# C Voce
Q_,b_,h_=150.,30.,500.
hard=lambda p:SY0+h_*p+Q_*(1-np.exp(-b_*p))
C=[]
rows,_,_,_=run('USTRESS',P(Q=Q_,b=b_,h=h_),[0.03],ninc=30)
from scipy.optimize import brentq
for r_ in rows[[4,9,19,29]]:
    eps=r_[1]; p=brentq(lambda p:hard(p)/E+p-eps,0,eps); C.append(dict(eps=eps,sig=r_[7],sig_c=hard(p),peeq=r_[15],peeq_c=p))
R['C']=C
# D table
tab=[250,0,300,0.05,350,0.1,350,1.0]
rows,_,_,_=run('USTRESS',P(nt=4,tab=tab),[0.05],ninc=10); s=rows[-1]
R['D']=dict(sig=s[7],sig_c=SY0+Et*(s[1]-eY),peeq=s[15])
# E FD at non-proportional state
Ef={}
for it in (0,1,2):
    rows,its,fds,_=run('SHEAR',P(it=it),[0.004],ninc=1,fd=True,sig0=[252,0,0,0,0,0],sv0=[0.002,0.002,-0.001,-0.001,0,0,0])
    Ef[it]=fds
# also elastic state & proportional
rows,its,fds,_=run('SHEAR',P(it=0),[0.0005],ninc=1,fd=True,sig0=[100,0,0,0,0,0],sv0=[0,0,0,0,0,0,0]); Ef['el']=fds
R['E']=Ef
# F convergence
F={}
for tgt in (0.004,0.05):
    for it in (0,1,2):
        _,its,_,_=run('USTRESS',P(it=it),[tgt],ninc=1,itp=True,extra="MAXIT=40, ")
        F[f'{tgt}_{it}']=[x[2] for x in its]
R['F']=F
# G cyclic
ea=0.01; tg=[ea,-ea,ea,-ea,ea,-ea]
rows,_,_,_=run('USTRESS',P(),tg,ninc=20); R['G_curve']=rows[:,[1,7,16,13,14]].tolist()
pk=[];sg=SY0+Et*(ea-eY)
for k in range(6): pk.append(sg); sg=sg+Et*(2*ea-2*sg/E)
Gk=[]
for k in range(6):
    r_=rows[20*(k+1)-1]; Gk.append(dict(eps=r_[1],sig=r_[7],sig_c=pk[k]*(1 if k%2==0 else -1),peeq=r_[15],peeq_c=(pk[k]-SY0)/H if False else None,sse=r_[13],spd=r_[14]))
# plastic strain accumulation closed form: peeq after k half cycles
pc=[(pk[0]-SY0)/H]
for k in range(1,6): pc.append(pc[-1]+(pk[k]-pk[k-1]) / H *0 )
# peeq: p_k = (sigma_k - sy0)/H holds for isotropic hardening (|sigma|=sy at the peak)
for k in range(6): Gk[k]['peeq_c']=(pk[k]-SY0)/H
# work integral by trapezoid over rows
sig=rows[:,7]; eps=rows[:,1]; W=np.concatenate([[0],np.cumsum(0.5*(sig[1:]+sig[:-1])*np.diff(eps))])
W=np.cumsum(np.concatenate([[0.5*sig[0]*eps[0]],0.5*(sig[1:]+sig[:-1])*np.diff(eps)]))
for k in range(6): Gk[k]['work']=W[20*(k+1)-1]
R['G']=Gk
json.dump(R,open('../out/results.json','w'))
def pr(x,ind=0):
    print(json.dumps(x,indent=1)[:6000])
for k in 'ABCDEFG':
    print('==',k); pr(R[k])
