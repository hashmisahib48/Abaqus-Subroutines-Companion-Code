"""Driver runs and closed-form checks for Chapter 13 -> ../out/results.json and text"""
import subprocess, json, numpy as np, re, sys
sys.path.insert(0,'.')
import os; DRV=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','out','drv13')
E,NU,SY0,H=210000.,0.3,250.,1000.; G=E/(2*(1+NU)); Et=E*H/(E+H); eY=SY0/E
def run(mode,props,targets,ninc=1,fd=False,itp=False,sig0=None,sv0=None,ntens=6,ndi=3,nshr=3,extra=''):
    P=','.join('%.12gD0'%p for p in props)
    nl=f"&DRV MODE='{mode}', NTENS={ntens}, NDI={ndi}, NSHR={nshr}, NPROPS={len(props)}, PROPS={P}, NSTATV=7, NSDVPR=7, NSEG={len(targets)}, "
    nl+=', '.join(f"TARGET({i+1})={t:.12g}D0" for i,t in enumerate(targets))+f", NINC={ninc}, FDCHK={'.TRUE.' if fd else '.FALSE.'}, ITPRINT={'.TRUE.' if itp else '.FALSE.'}, TOL=1.0D-10, "
    if sig0: nl+='SIG0='+','.join('%.12gD0'%x for x in sig0)+', '
    if sv0: nl+='STATEV0='+','.join('%.12gD0'%x for x in sv0)+', '
    nl+=extra+' /\n'
    out=subprocess.run([DRV],input=nl,capture_output=True,text=True).stdout
    rows=[];its=[];fds=[]
    for l in out.splitlines():
        t=l.split()
        if l.startswith('INC'): rows.append([float(x) for x in t[3:]]); 
        elif l.startswith('IT'): its.append((int(t[1]),int(t[2]),float(t[3])))
        elif l.startswith('FD'): fds.append(float(t[2]))
    return np.array(rows),its,fds,out
def P(it=0,Q=0.,b=0.,nt=0,tab=(),h=H): return [E,NU,SY0,h,Q,b,nt,it]+list(tab)
R={}
