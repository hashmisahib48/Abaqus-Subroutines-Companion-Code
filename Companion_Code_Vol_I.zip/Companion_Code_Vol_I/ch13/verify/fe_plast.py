"""Q4 plane-strain finite element program (B-bar) that calls the compiled J2 UMAT at its Gauss points.
Thick-walled cylinder a=50, b=100 mm under internal pressure; Newton iteration counts for three tangents."""
import numpy as np, ctypes as C, os, json, sys
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','out')
lib=C.CDLL(os.path.join(OUT,'libj2.so'))
E,NU,SY0,H=210000.,0.3,250.,1000.
def props(it): return np.array([E,NU,SY0,H,0,0,0,it],float)
def ucall(pr,sig,sv,ds):
    sig=sig.copy(); sv=sv.copy(); D=np.zeros((4,4),order='F'); sse=C.c_double(0); spd=C.c_double(0); pn=C.c_double(1)
    i=lambda v:C.byref(C.c_int(v)); p=lambda a:a.ctypes.data_as(C.c_void_p)
    spd.value=0.0
    lib.k13_call_(i(3),i(1),i(4),p(pr),i(len(pr)),p(sig),p(sv),i(5),p(np.array(ds,float)),p(D),C.byref(sse),C.byref(spd),C.byref(pn))
    return sig,sv,D,pn.value
g=1/np.sqrt(3); GP=[(-g,-g),(g,-g),(g,g),(-g,g)]
def shp(xi,eta):
    dN=0.25*np.array([[-(1-eta),-(1-xi)],[(1-eta),-(1+xi)],[(1+eta),(1+xi)],[-(1+eta),(1-xi)]]); return dN
def Bel(X):
    Bs=[];ws=[]
    for xi,eta in GP:
        dN=shp(xi,eta); J=dN.T@X; dJ=np.linalg.det(J); dNx=dN@np.linalg.inv(J).T
        B=np.zeros((4,8))
        for a in range(4):
            B[0,2*a]=dNx[a,0]; B[1,2*a+1]=dNx[a,1]; B[3,2*a]=dNx[a,1]; B[3,2*a+1]=dNx[a,0]
        Bs.append(B); ws.append(dJ)
    bv=sum(w*(B[0]+B[1]) for B,w in zip(Bs,ws))/sum(ws)
    for B in Bs:
        corr=0.5*(bv-(B[0]+B[1])); B[0]+=corr; B[1]+=corr
    return Bs,ws
def mesh(n,nth,a=50.,b=100.):
    rr=np.linspace(a,b,n+1); th=np.linspace(0,np.pi/2,nth+1)
    nodes=np.array([[r*np.cos(t),r*np.sin(t)] for t in th for r in rr])
    elems=[[j*(n+1)+i,j*(n+1)+i+1,(j+1)*(n+1)+i+1,(j+1)*(n+1)+i] for j in range(nth) for i in range(n)]
    fixed=[]
    for i in range(n+1): fixed+= [2*i+1, 2*(nth*(n+1)+i)]
    return nodes,elems,fixed
def loadvec(nodes,n,nth):
    F=np.zeros(2*len(nodes))
    for j in range(nth):
        n1=j*(n+1); n2=(j+1)*(n+1); t=nodes[n2]-nodes[n1]; L=np.linalg.norm(t)
        nrm=np.array([t[1],-t[0]])/L
        if nrm@nodes[n1]<0: nrm=-nrm
        for nn in (n1,n2): F[2*nn:2*nn+2]+=L/2*nrm      # unit pressure
    return F
def solve(it,pl,n=8,nth=4,tol=1e-8,verbose=False,maxit=60):
    nodes,elems,fixed=mesh(n,nth); F1=loadvec(nodes,n,nth); nn=len(nodes)
    BW=[Bel(nodes[e]) for e in elems]; pr=props(it)
    free=np.setdiff1d(np.arange(2*nn),fixed)
    ng=len(elems)*4; sig=np.zeros((ng,4)); sv=np.zeros((ng,5)); u=np.zeros(2*nn); hist=[]; p_prev=0.
    dofs=[np.array([[2*a,2*a+1] for a in e]).ravel() for e in elems]
    for p in pl:
        Fe=p*F1; res=[]; ok=False
        ut=u.copy()
        for k in range(maxit):
            K=np.zeros((2*nn,2*nn)); fint=np.zeros(2*nn); snew=np.zeros_like(sig); vnew=np.zeros_like(sv)
            for e,(Bs,ws) in enumerate(BW):
                for q in range(4):
                    idx=e*4+q; ds=Bs[q]@(ut-u)[dofs[e]]
                    s,v,D,pn=ucall(pr,sig[idx],sv[idx],ds); snew[idx]=s; vnew[idx]=v
                    K[np.ix_(dofs[e],dofs[e])]+=Bs[q].T@D@Bs[q]*ws[q]; fint[dofs[e]]+=Bs[q].T@s*ws[q]
            r=(Fe-fint)[free]; rn=np.linalg.norm(r)/max(np.linalg.norm(Fe[free]),1e-30); res.append(rn)
            if rn<tol: ok=True; break
            ut[free]+=np.linalg.solve(K[np.ix_(free,free)],r)
        if not ok: hist.append((p,res,False)); return hist,None
        sig,sv,u=snew,vnew,ut.copy(); hist.append((p,res,True))
    return hist,(sig,sv,u,nodes)
if __name__=='__main__':
    py=0
    out={}
    pls=[60.,100.,125.,150.,175.]
    for it in (0,1,2):
        h,_=solve(it,pls)
        out[it]=[(p,len(r)-1 if ok else None,r) for p,r,ok in h]
        print(it,[(p,len(r)-1,ok) for p,r,ok in h])
    json.dump({str(k):v for k,v in out.items()},open('../out/fe_conv.json','w'))
