#!/bin/sh
# Builds the Chapter 13 driver (gfortran 13, stub routines)
A=/home/claude/book/lib/aba
F="-ffixed-form -std=legacy -I$A -g -fcheck=all -ffpe-trap=invalid,zero,overflow"
cd "$(dirname "$0")/../code"; mkdir -p ../out
gfortran $F umatdrv.f ex13_umat_j2.f $A/stubs.f -o ../out/drv13 || exit 1
gfortran -c -ffixed-form -std=legacy -I$A ex13_umat_j2.f -o ../out/chk.o || exit 1
