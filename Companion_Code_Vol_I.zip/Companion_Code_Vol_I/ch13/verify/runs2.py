"""Chapter 13: Voce convergence, energy balance of the cyclic run -> ../out/results2.json"""
from runs_base import *
R={}
Q_,b_,h_=150.,30.,500.
F={}
for tgt in (0.03,):
    for it in (0,1,2):
        _,its,_,_=run('USTRESS',P(it=it,Q=Q_,b=b_,h=h_),[tgt],ninc=1,itp=True,extra="MAXIT=40, ")
        F[f'{tgt}_{it}']=[x[2] for x in its]
R['F']=F
# non-proportional start: biaxial-ish state via sig0 and sv0 (prestrained), uniaxial stress continued
for it in (0,1,2):
    _,its,_,_=run('USTRESS',P(it=it),[0.01],ninc=1,itp=True,extra="MAXIT=40, ",sig0=[100,150,0,60,0,0],sv0=[0,0,0,0,0,0,0])
    F[f'np_{it}']=[x[2] for x in its]
ea=0.01; tg=[ea,-ea,ea,-ea,ea,-ea]; out={}
for n in (20,200):
    rows,_,_,_=run('USTRESS',P(),tg,ninc=n)
    sig=rows[:,7]; eps=rows[:,1]
    W=np.cumsum(np.concatenate([[0.5*sig[0]*eps[0]],0.5*(sig[1:]+sig[:-1])*np.diff(eps)]))
    out[n]=[dict(sse=rows[n*(k+1)-1,13],spd=rows[n*(k+1)-1,14],work=W[n*(k+1)-1],peeq=rows[n*(k+1)-1,15]) for k in range(6)]
R['G']=out
json.dump(R,open('../out/results2.json','w'))
print(json.dumps(R,indent=0)[:5000])
for k in range(6):
    o=out[20][k]; p=o['peeq']; print(k,o['spd'], SY0*p+H*p*p/2, o['sse']+o['spd'], out[20][k]['work'], out[200][k]['work'])
