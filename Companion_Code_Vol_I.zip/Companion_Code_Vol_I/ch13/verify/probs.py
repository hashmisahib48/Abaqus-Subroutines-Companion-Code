from runs_base import *
from j2py import step,dev,Cel
from scipy.optimize import brentq
np.set_printoptions(precision=5,suppress=True,linewidth=150)
P_={}
# A1
sn=np.array([150.,50,0,40,0,0]); d=np.array([1.5e-3,0,0,1.0e-3,0,0])
st=sn+Cel()@d; p,s,sn2,q=dev(st); s1,e1,D,dp=step(sn,0.,d)
print('A1 trial',st,'q_tr',q,'dp',dp,'new',s1,'q_new',dev(s1)[3],'theta',1-3*G*dp/q)
rows,_,_,_=run('SHEAR',P(),[0.0],ninc=1,sig0=list(sn))  # dummy
# check with fortran: strain increments with both comps -> use python only plus fortran via t2-like? use driver with sig0, mode USTRAIN no. skip
# A2
eps=0.02; sg=SY0+Et*(eps-eY); print('A2',Et,sg,(sg-SY0)/H, 'resid strain',(sg-SY0)/H)
# A3
ea=0.008; pk=[];sgm=SY0+Et*(ea-eY)
for k in range(4): pk.append(sgm); sgm=sgm+Et*(2*ea-2*sgm/E)
print('A3',pk,[(x-SY0)/H for x in pk])
# B1
print('B1',Et,G*H/(3*G+H),G)
# B3 increment-size
sig0=[252,0,0,0,0,0]; sv0=[0.002,0.002,-0.001,-0.001,0,0,0]
ref=run('SHEAR',P(),[0.01],ninc=1024,sig0=sig0,sv0=sv0)[0][-1]
for n in (1,2,4,8,16,64):
    r_=run('SHEAR',P(),[0.01],ninc=n,sig0=sig0,sv0=sv0)[0][-1]
    print('B3',n,r_[7],r_[10],r_[15],'err',abs(r_[7]-ref[7]),abs(r_[10]-ref[10]))
print('ref',ref[7],ref[10],ref[15])
# C1 equibiaxial plane stress closed form
for e1 in (0.01,):
    p_=brentq(lambda p:(SY0+H*p)*(1-NU)/E+p/2-e1,0,e1); print('C1',e1,p_,SY0+H*p_, 'eps33',-2*NU/(1-NU)*(SY0+H*p_)/E*0.5*0 )
# plane stress uniaxial at 0.01 same as 3D
print('C1b', SY0+Et*(0.01-eY), 'biax onset strain',SY0*(1-NU)/E)
# C2 expected
print('C2: first yield strain',eY, 'tau_y',SY0/np.sqrt(3), G)
