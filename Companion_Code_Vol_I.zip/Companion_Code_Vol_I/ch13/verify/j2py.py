"""Independent Python implementation of the Chapter 13 return map (cross-check of the Fortran routine)."""
import numpy as np
E,NU,SY0,H=210000.,0.3,250.,1000.
G=E/(2*(1+NU)); K=E/(3*(1-2*NU))
def Cel():
    C=np.zeros((6,6)); 
    for i in range(3):
        for j in range(3): C[i,j]=K-2*G/3
        C[i,i]+=2*G
    for i in range(3,6): C[i,i]=G
    return C
def dev(s):
    p=s[:3].sum()/3; d=s.copy(); d[:3]-=p
    sn2=d[:3]@d[:3]+2*d[3:]@d[3:]; return p,d,sn2,np.sqrt(1.5*sn2)
def step(sig,ep,dstrain,hard=lambda p:(SY0+H*p,H)):
    st=sig+Cel()@dstrain; p,s,sn2,q=dev(st); sy,_=hard(ep)
    if q-sy<=1e-10*SY0: return st,ep,Cel(),0.
    dp=(q-sy)/(3*G+hard(ep)[1])
    for _ in range(60):
        syn,hn=hard(ep+dp); g=q-3*G*dp-syn
        if abs(g)<1e-13*SY0: break
        dp+=g/(3*G+hn)
    th=1-3*G*dp/q; thb=3*G/(3*G+hn)-(1-th); n=s/np.sqrt(sn2)
    new=th*s; new[:3]+=p
    D=np.zeros((6,6))
    for i in range(3):
        for j in range(3): D[i,j]=K-2*th*G/3
        D[i,i]+=2*th*G
    for i in range(3,6): D[i,i]=th*G
    D-=2*G*thb*np.outer(n,n)
    return new,ep+dp,D,dp
if __name__=='__main__':
    sig=np.array([100.,10,-5,20,0,0]); d=np.array([2e-3,-5e-4,-5e-4,1e-3,0,0])
    s1,e1,D,dp=step(sig*0,0.,d); print(s1,e1)
    h=1e-6; F=np.zeros((6,6))
    for j in range(6):
        a=d.copy();a[j]+=h;b=d.copy();b[j]-=h
        F[:,j]=(step(sig*0,0.,a)[0]-step(sig*0,0.,b)[0])/(2*h)
    print(np.abs(F-D).max()/np.abs(D).max())
