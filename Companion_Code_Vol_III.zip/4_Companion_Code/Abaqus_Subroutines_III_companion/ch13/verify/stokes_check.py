# independent check of Stokes 2nd-order formulas (Dean & Dalrymple form) by numerical differentiation
import numpy as np
from scipy.optimize import brentq
g=9810.0 # mm/s^2
def waveno(T,d):
    w=2*np.pi/T
    return brentq(lambda k: w*w-g*k*np.tanh(k*d),1e-9,10.0/d*100+1e-3,xtol=1e-22,rtol=1e-15)
def kin(x,z,t,H,T,d,rho=1e-9):
    k=waveno(T,d); w=2*np.pi/T; th=k*x-w*t; zz=z+d
    ch=np.cosh; sh=np.sinh; kd=k*d
    eta=H/2*np.cos(th)+H**2*k/16*ch(kd)/sh(kd)**3*(2+ch(2*kd))*np.cos(2*th)
    A=H/2*w/np.tanh(kd); B=3/16*H**2*w*k/sh(kd)**4
    u=A*ch(k*zz)/ch(kd)*np.cos(th)+B*ch(2*k*zz)*np.cos(2*th)
    ww=A*sh(k*zz)/ch(kd)*np.sin(th)+B*sh(2*k*zz)*np.sin(2*th)
    ax=w*A*ch(k*zz)/ch(kd)*np.sin(th)+2*w*B*ch(2*k*zz)*np.sin(2*th)
    az=-w*A*sh(k*zz)/ch(kd)*np.cos(th)-2*w*B*sh(2*k*zz)*np.cos(2*th)
    pi_=rho*g*H**2*k/2
    p=rho*g*H/2*ch(k*zz)/ch(kd)*np.cos(th)+0.75*pi_/sh(2*kd)*(ch(2*k*zz)/sh(kd)**2-1/3)*np.cos(2*th)-0.25*pi_/sh(2*kd)*(ch(2*k*zz)-1)
    return dict(eta=eta,u=u,w=ww,ax=ax,az=az,p=p,k=k,w_=w)
if __name__=='__main__':
    d=10000.;T=8.0
    for H in (1000.,500.,250.,125.):
        x0,z0,t0=1234.,-3000.,0.7; h=1e-3
        f=lambda x,z,t: kin(x,z,t,H,T,d)
        ux=(f(x0+h,z0,t0)['u']-f(x0-h,z0,t0)['u'])/(2*h); wz=(f(x0,z0+h,t0)['w']-f(x0,z0-h,t0)['w'])/(2*h)
        ut=(f(x0,z0,t0+h*1e-3)['u']-f(x0,z0,t0-h*1e-3)['u'])/(2e-6)
        uz=(f(x0,z0+h,t0)['u']-f(x0,z0-h,t0)['u'])/(2*h)
        wx=(f(x0+h,z0,t0)['w']-f(x0-h,z0,t0)['w'])/(2*h)
        wt=(f(x0,z0,t0+h*1e-3)['w']-f(x0,z0-h*1e-3,t0)['w'] if False else f(x0,z0,t0+h*1e-3)['w']-f(x0,z0,t0-h*1e-3)['w'])/(2e-6)
        px=(f(x0+h,z0,t0)['p']-f(x0-h,z0,t0)['p'])/(2*h); pz=(f(x0,z0+h,t0)['p']-f(x0,z0-h,t0)['p'])/(2*h)
        s=f(x0,z0,t0)
        rho=1e-9
        # Euler residuals using full material derivative; hydrostatic part removed from p (dynamic p)
        rx=px/rho+ut+s['u']*ux+s['w']*uz
        rz=pz/rho+wt+s['u']*wx+s['w']*wz  # dynamic pressure gradient: -rho g z removed, so g cancelled
        rx1=px/rho+ut
        print(H,'cont',ux+wz,'euler_x',rx,'euler_z',rz,'linear-only x',rx1, 'ax',s['ax']-ut,'az',s['az']-wt)
