import numpy as np, subprocess, json
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
RG=2.87e8; CPA=1.0045e9; CVA=CPA-RG; GAM=CPA/CVA; V=6e7; P0=0.30; T0=300.; PA=0.101325; A=2000.; CD=0.7; EPS=1e-3
QC=(2/(GAM+1))**(GAM/(GAM-1))
def psi(q):
    if q<=QC: return np.sqrt(GAM)*(2/(GAM+1))**((GAM+1)/(2*(GAM-1)))
    qe=min(q,1-EPS)
    ps=np.sqrt(2*GAM/(GAM-1)*(qe**(2/GAM)-qe**((GAM+1)/GAM)))
    return ps if q<=1-EPS else ps*(1-q)/EPS
def mdot(p,T): return CD*A*p/np.sqrt(RG*T)*psi(PA/p) if p>PA else 0.0
a0=np.sqrt(GAM*RG*T0)
tau=V/(CD*A*a0)*((GAM+1)/2)**((GAM+1)/(2*(GAM-1)))
def p_closed(t): return P0*(1+(GAM-1)/2*t/tau)**(-2*GAM/(GAM-1))
def T_closed(t): return T0*(1+(GAM-1)/2*t/tau)**(-2)
tchoke=tau*2/(GAM-1)*((PA/QC/P0)**(-(GAM-1)/(2*GAM))-1)
m0=P0*V/(RG*T0)
def rhs(t,y):
    m,T=y; p=m*RG*T/V; md=mdot(p,T)
    return [-md, -md*RG*T/(m*CVA)]
sol=solve_ivp(rhs,[0,0.6],[m0,T0],method='DOP853',rtol=1e-12,atol=1e-16,dense_output=True)
def p_ode(t):
    m,T=sol.sol(t); return m*RG*T/V
# isothermal
tau_iso=V/(CD*A*(2/(GAM+1))**((GAM+1)/(2*(GAM-1)))*np.sqrt(GAM*RG*T0))
sol_i=solve_ivp(lambda t,y:[-mdot(y[0]*RG*T0/V,T0)],[0,0.6],[m0],method='DOP853',rtol=1e-12,atol=1e-16,dense_output=True)
def p_iso_ode(t): return sol_i.sol(t)[0]*RG*T0/V
def run(dt,icav):
    out=subprocess.run(['/tmp/claude-0/tank'],input=f"{dt} {icav}\n",capture_output=True,text=True).stdout.splitlines()[1:]
    return np.array([[float(x) for x in l.split()] for l in out])
if __name__=='__main__':
    R={'gamma':GAM,'qc':QC,'tau':tau,'tchoke':tchoke,'a0':a0,'m0':m0,'tau_iso':tau_iso,'pchoke':PA/QC,'mchoked':CD*A*P0/np.sqrt(RG*T0)*psi(0.0)}
    # unchoke time from ODE
    f=lambda t: p_ode(t)-PA/QC
    R['tchoke_ode']=brentq(f,0.01,0.2,xtol=1e-14)
    errs=[]
    for dt in (1e-3,5e-4,2.5e-4,1.25e-4,6.25e-5):
        d=run(dt,2); t=d[:,0]
        i05=np.argmin(abs(t-0.05)); i03=np.argmin(abs(t-0.3)); i006=np.argmin(abs(t-0.06))
        e=dict(dt=dt,p05=d[i05,1],pc05=p_closed(0.05),err_closed=abs(d[i05,1]-p_closed(0.05)),
               p30=d[i03,1],pode30=float(p_ode(0.3)),err_ode30=abs(d[i03,1]-p_ode(0.3)),
               T05=d[i05,2],Tc05=T_closed(0.05),errT=abs(d[i05,2]-T_closed(0.05)))
        errs.append(e)
    R['conv']=errs
    # isothermal at dt=1e-4
    d=run(1e-4,3); t=d[:,0]; ii=np.argmin(abs(t-0.04))
    R['iso']=dict(p04=d[ii,1],pcl=P0*np.exp(-0.04/tau_iso),pode=float(p_iso_ode(0.04)))
    # reference table at dt=1e-4 adiabatic
    d=run(1e-4,2); R['tab']=[[float(x) for x in d[i]]+[float(p_closed(d[i,0])),float(p_ode(d[i,0]))] for i in [int(np.argmin(abs(d[:,0]-x))) for x in (0,0.02,0.05,0.07,0.08,0.1,0.15,0.2,0.3)]]
    # unchoke time from driver: first t with p<=pchoke
    d=run(1e-4,2); j=np.argmax(d[:,1]<=PA/QC); R['tchoke_drv']=float(d[j-1,0]+(d[j-1,1]-PA/QC)/(d[j-1,1]-d[j,1])*(d[j,0]-d[j-1,0]))
    # mass flow at t=0 closed form
    R['Tfinal']=float(T0*(PA/P0)**((GAM-1)/GAM)); R['Tfinal_drv']=float(d[-1,2]); R['mdot0_drv']=float(d[0,3])
    # print max error over whole run vs ode
    pode=np.array([p_ode(x) for x in d[:,0]]); R['maxrel_ode_1e-4']=float(np.max(abs(d[:,1]-pode)/pode))
    json.dump(R,open('tank.json','w'),indent=1)
    for k,v in R.items(): print(k,v)
