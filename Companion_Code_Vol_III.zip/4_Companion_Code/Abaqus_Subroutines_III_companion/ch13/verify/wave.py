import numpy as np, subprocess, json
from scipy.optimize import brentq
from scipy.integrate import quad
from stokes_check import kin, waveno, g
H=2000.; T=8.; d=15000.; rho=1e-9
def run(exe,inp=None):
    return subprocess.run([exe],input=inp,capture_output=True,text=True).stdout.splitlines()
out=run('/tmp/claude-0/wave')
R={}
# A dispersion
disp=[]
for l in out[1:5]:
    t,dd,k,n=l.split(); t=float(t); dd=float(dd); k=float(k)
    kb=brentq(lambda kk:(2*np.pi/t)**2-g*kk*np.tanh(kk*dd),1e-12,1.0,xtol=1e-18,rtol=1e-15)
    w2=(2*np.pi/t)**2; x0=w2*dd/g; eck=np.sqrt(x0**2+x0/(1+0.6522*x0+0.4622*x0**2+0.0864*x0**4+0.0675*x0**5))
    disp.append(dict(T=t,d=dd,k=k,kb=kb,rel=abs(k-kb)/kb,nit=int(n),kd=k*dd,L=2*np.pi/k,eckart=eck/dd,rel_eck=abs(eck/dd-kb)/kb,
        deep=w2/g,shallow=np.sqrt(w2/(g*dd))))
R['disp']=disp
# B kinematics
rows=[]; mx=0
for l in out[6:11]:
    v=[float(x) for x in l.split()]
    x,y,t=v[:3]; s=kin(x,y-d,t,H,T,d)
    ref=[d+s['eta'],s['u'],s['w'],s['ax'],s['az'],s['p']]
    # dpdz by central difference of independent p
    h=1e-3; dp=(kin(x,y-d+h,t,H,T,d)['p']-kin(x,y-d-h,t,H,T,d)['p'])/(2*h)
    ref.append(dp)
    err=[abs(a-b)/max(abs(b),1e-30) for a,b in zip(v[3:],ref)]
    rows.append(dict(x=x,y=y,t=t,fort=v[3:],ref=ref,relerr=err)); mx=max(mx,max(err[:6]),)
R['kin']=rows; R['kin_maxrel']=mx; R['kin_dpdz_maxrel']=max(r['relerr'][6] for r in rows)
# C Euler
R['euler']=[[float(x) for x in l.split()] for l in out[12:16]]
# D Morison closed forms for Airy
D=500.;Cd=1.;Cm=2.
k=waveno(T,d); w=2*np.pi/T; A1=H/2*w/np.tanh(k*d)
FIamp=rho*Cm*np.pi*D**2/4*(H/2)*g*np.tanh(k*d)
Ic=(d/2+np.sinh(2*k*d)/(4*k))/np.cosh(k*d)**2
FDamp=0.5*rho*Cd*D*A1**2*Ic
def Fcl(t): th=-w*t; return FIamp*np.sin(th)+FDamp*np.cos(th)*abs(np.cos(th))
# moment closed forms: integrate numerically with quad on airy kin (independent)
def Fnum(t,H_=H,stk=True):
    def f(z):
        s=kin(0.,z,t,H_,T,d); return rho*Cm*np.pi*D**2/4*s['ax']+0.5*rho*Cd*D*abs(s['u'])*s['u']
    return quad(f,-d,0,limit=400,points=None)[0]
mA=run('/tmp/claude-0/mor_airy'); mS=run('/tmp/claude-0/mor_stk')
def parse(m): return np.array([[float(x) for x in l.split()] for l in m[1:]])
MA=parse(mA); MS=parse(mS)
R['mor']=dict(FIamp=FIamp,FDamp=FDamp,Ic=Ic,A1=A1,k=k,
   airy_err=max(abs(MA[i,4]-Fcl(MA[i,1])) for i in range(16)),
   FI_err=max(abs(MA[i,2]-FIamp*np.sin(-w*MA[i,1])) for i in range(16)),
   FD_err=max(abs(MA[i,3]-FDamp*np.cos(w*MA[i,1])*abs(np.cos(w*MA[i,1]))) for i in range(16)),
   Fmax_airy_drv=float(MA[:,4].max()),Fmin_airy_drv=float(MA[:,4].min()),
   Fmax_stk_drv=float(MS[:,4].max()),Fmin_stk_drv=float(MS[:,4].min()),
   Mmax_airy=float(MA[:,5].max()),Mmax_stk=float(MS[:,5].max()),
   stk_err_quad=max(abs(MS[i,4]-Fnum(MS[i,1])) for i in (0,3,7,11)),
   )
# finer maximum of closed-form airy F
ts=np.linspace(0,T,20001); Fc=np.array([Fcl(t) for t in ts]); R['mor']['Fmax_cl']=float(Fc.max()); R['mor']['Fmin_cl']=float(Fc.min()); R['mor']['t_Fmax_cl']=float(ts[Fc.argmax()])
R['mor']['table']=[[float(MA[i,1]),float(MA[i,4]),float(Fcl(MA[i,1])),float(MS[i,4])] for i in range(16)]
# Ursell
R['ursell']=H*(2*np.pi/k)**2/d**3
R['k']=k; R['L']=2*np.pi/k; R['kd']=k*d; R['Hmax_stokes_airy_eta']=float(kin(0,0,0,H,T,d)['eta'])
R['eta_crest_airy']=H/2; R['eta_crest_stk']=float(kin(0,0,0,H,T,d)['eta']); R['eta_trough_stk']=float(kin(0,0,T/2,H,T,d)['eta'])
R['u_crest_airy']=A1*np.cosh(k*d)/np.cosh(k*d); 
R['u_crest_stk']=float(kin(0,0,0,H,T,d)['u'])
# vwave compare
vo=run('/tmp/claude-0/vwave'); vw=[[float(x) for x in l.split()] for l in vo[1:]]
uo=[[float(x) for x in l.split()] for l in out[6:11]]
# vwave probes: coords at t=2.5; compare with python independent
vm=0
for r_ in vw:
    x,y=r_[0],r_[1]; s=kin(x,y-d,2.5,H,T,d); ref=[d+s['eta'],s['u'],s['w'],s['ax'],s['az'],s['p']]
    vm=max(vm,max(abs(a-b)/max(abs(b),1e-30) for a,b in zip(r_[2:8],ref)))
R['vwave_maxrel']=vm
json.dump(R,open('wave.json','w'),indent=1,default=float)
print(json.dumps({k_:R[k_] for k_ in ('kin_maxrel','kin_dpdz_maxrel','vwave_maxrel','ursell','k','L','kd','eta_crest_stk','eta_trough_stk','u_crest_stk','u_crest_airy')},indent=1,default=float))
print(json.dumps(R['disp'],indent=0,default=float)); print(R['mor']); print(R['euler'])
