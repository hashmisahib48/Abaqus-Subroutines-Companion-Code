import numpy as np, subprocess, json
from scipy.integrate import solve_ivp
import tank as TK
W,S0,DP1,DP2,FB=0.38,0.50,0.12,0.16,0.03; AFAB=6e4
def phi_pore(e1,e2,al):
    sa=np.sin(al); return max(1-W/(S0*(1+e1)*sa),0)*max(1-W/(S0*(1+e2)*sa),0)
def omega(dp):
    u=min(max((dp-DP1)/(DP2-DP1),0),1); return u*u*(3-2*u)
def area(p,e1=0.02,e2=0.01,al=np.radians(85)):
    return AFAB*(phi_pore(e1,e2,al)+omega(p-TK.PA)*FB)
def mc_open(e1,e2,al,n=20_000_000,seed=1):
    # explicit geometry: lines of family 1 along e1 with perpendicular spacing s2 sin(al); family 2 along e2 with spacing s1 sin(al)
    rng=np.random.default_rng(seed); s1=S0*(1+e1); s2=S0*(1+e2)
    ex=np.array([1,0]); ey=np.array([np.cos(al),np.sin(al)])
    # random points in the plane (large patch), distance to nearest yarn centre-line of each family
    uv=rng.uniform(0,1,(n,2)); pts=uv[:,:1]*np.array([s1,0.0])+uv[:,1:]*(s2*ey)   # one periodic cell
    d1=np.abs(((pts[:,1]+s2*np.sin(al)/2)%(s2*np.sin(al)))-s2*np.sin(al)/2)       # distance to lines along e1
    nrm=np.array([np.sin(al),-np.cos(al)])                                       # normal of e2 lines
    c=pts@nrm; sp=s1*np.sin(al); d2=np.abs(((c+sp/2)%sp)-sp/2)
    return np.mean((d1>W/2)&(d2>W/2))
def rhs(t,y):
    m,T=y; p=m*TK.RG*T/TK.V; A=area(p); md=TK.CD*A*p/np.sqrt(TK.RG*T)*TK.psi(TK.PA/p) if p>TK.PA else 0
    return [-md,-md*TK.RG*T/(m*TK.CVA)]
sol=solve_ivp(rhs,[0,0.4],[TK.m0,TK.T0],method='DOP853',rtol=1e-12,atol=1e-16,dense_output=True)
def pode(t): m,T=sol.sol(t); return m*TK.RG*T/TK.V
def run(dt):
    out=subprocess.run(['/tmp/claude-0/fab'],input=f"{dt}\n",capture_output=True,text=True).stdout.splitlines()
    i=[k for k,l in enumerate(out) if l.startswith('part 2')][0]
    return out[:i],np.array([[float(x) for x in l.split()] for l in out[i+1:]])
R={}
cases=[(0,0,np.pi/2),(0.02,0.01,np.radians(85)),(0.04,0.04,np.pi/2),(-0.03,0,np.pi/2),(0,0,np.radians(60)),(0.05,0,np.radians(45))]
R['pore']=[dict(e1=c[0],e2=c[1],al=float(np.degrees(c[2])),closed=phi_pore(*c),mc=float(mc_open(*c))) for c in cases]
p1,d=run(5e-5)
R['part1_driver']=p1
R['conv']=[]
for dt in (2e-4,1e-4,5e-5,2.5e-5):
    _,d=run(dt); 
    row=dict(dt=dt)
    for tt in (0.02,0.05,0.1):
        i=np.argmin(abs(d[:,0]-tt)); row[f'p{tt}']=float(d[i,1]); row[f'e{tt}']=float(abs(d[i,1]-pode(tt)))
    R['conv'].append(row)
_,d=run(5e-5)
R['tab']=[[float(x) for x in d[np.argmin(abs(d[:,0]-t))]]+[float(pode(t)),float(area(pode(t)))] for t in (0,0.008,0.012,0.02,0.05,0.1)]
R['maxrel']=float(max(abs(d[:,1]-np.array([pode(t) for t in d[:,0]]))/np.array([pode(t) for t in d[:,0]])))
R['t_close']=float(d[np.argmax(d[:,3]<3830),0]); R['A_open']=float(d[0,3]); R['A_pore']=float(AFAB*phi_pore(0.02,0.01,np.radians(85)))
R['p_end']=float(d[-1,1])
# time when seam completely closed (dp<=DP1)
json.dump(R,open('fabric.json','w'),indent=1,default=float)
for p in R['pore']: print(p)
for c in R['conv']: print(c)
print(R['tab']); print(R['maxrel'],R['t_close'],R['A_open'],R['A_pore'])
