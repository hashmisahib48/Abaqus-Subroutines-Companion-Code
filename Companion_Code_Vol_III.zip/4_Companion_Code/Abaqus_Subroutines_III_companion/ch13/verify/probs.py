import numpy as np, json
from scipy.optimize import brentq
RG=2.87e8; CPA=1.0045e9; GAM=1.4; g=9810.; rho=1e-9
def qc(gm=GAM): return (2/(gm+1))**(gm/(gm-1))
def psistar(gm=GAM): return np.sqrt(gm)*(2/(gm+1))**((gm+1)/(2*(gm-1)))
def psi(q):
    if q<=qc(): return psistar()
    return np.sqrt(2*GAM/(GAM-1)*(q**(2/GAM)-q**((GAM+1)/GAM)))
def dpsi(q):
    if q<=qc(): return 0.0
    return 0.5/psi(q)*2*GAM/(GAM-1)*((2/GAM)*q**(2/GAM-1)-((GAM+1)/GAM)*q**(1/GAM))
P={}
# A1
p0,T0,pa,C,A=0.25,320.,0.101325,0.6,1500.
q=pa/p0; m=C*A*p0/np.sqrt(RG*T0)*psi(q); P['A1']=dict(q=q,qc=qc(),mdot=m,E=m*CPA*T0,mdot_kg=m*1e3,Ekw=m*CPA*T0*1e-6)
# A2
V,A,C,T0,p0=4e7,1200.,0.65,300.,0.35
a0=np.sqrt(GAM*RG*T0); tau=V/(C*A*a0)*((GAM+1)/2)**((GAM+1)/(2*(GAM-1)))
pchoke=pa/qc(); tc=2*tau/(GAM-1)*((pchoke/p0)**(-(GAM-1)/(2*GAM))-1)
p05=p0*(1+(GAM-1)/2*0.05/tau)**(-2*GAM/(GAM-1)); T05=T0*(1+(GAM-1)/2*0.05/tau)**-2
P['A2']=dict(tau=tau,pchoke=pchoke,tc=tc,p05=p05,T05=T05,Tinf=T0*(pa/p0)**((GAM-1)/GAM),a0=a0)
# A3
Tw,d,H=6.,8000.,1500.
w=2*np.pi/Tw; k=brentq(lambda k:w*w-g*k*np.tanh(k*d),1e-9,1.)
L=2*np.pi/k; c=w/k; A1=H/2*w/np.tanh(k*d)
P['A3']=dict(k=k,L=L,c=c,kd=k*d,u_swl=A1,u_bed=A1/np.cosh(k*d),p_bed=rho*g*H/2/np.cosh(k*d),a_swl=A1*w)
# B1
qs=[qc(),0.7,0.9]; P['B1']=dict(psistar=psistar(),dpsi_qc=dpsi(qc()),psi07=psi(0.7),dpsi07=dpsi(0.7),dpsi09=dpsi(0.9),psi09=psi(0.9),
   d_dpd=0.7*2000/np.sqrt(RG*300.)*dpsi(0.7))
# B2 buggy routine: see driver
# B3 deep water limit
Tw,d,H=4.,40000.,1000.
w=2*np.pi/Tw; k=brentq(lambda k:w*w-g*k*np.tanh(k*d),1e-9,1.,xtol=1e-22); kd=k*d
E=np.exp(-2*kd); A1=H/2*w/np.tanh(kd); B2=3/16*H*H*w*k
C2_0=8*(np.exp(-2*kd)+np.exp(-6*kd))/(1-E)**4   # z=0
deta=H*H*k/8*(1+E)*(1+4*E+E*E)/(1-E)**3
P['B3']=dict(kd=kd,k=k,du_ratio=B2*C2_0/A1,deta=deta,deta_deep=H*H*k/8,C2_0=C2_0,A1=A1,B2=B2)
# C1 isothermal
V,A,C,T0,p0=6e7,2000.,0.7,300.,0.30
a0=np.sqrt(GAM*RG*T0); tau=V/(C*A*psistar()*np.sqrt(RG*T0)/np.sqrt(GAM)*np.sqrt(GAM)) # = V/(C A phi sqrt(gamma R T))
tau_iso=V/(C*A*((2/(GAM+1))**((GAM+1)/(2*(GAM-1))))*np.sqrt(GAM*RG*T0)); P['C1']=dict(tau=tau_iso,p04=p0*np.exp(-0.04/tau_iso),tc=-tau_iso*np.log(pa/qc()/p0))
# C2 current
Tw,d,U=8.,15000.,1000.
w=2*np.pi/Tw; f=lambda k:(w-k*U)**2-g*k*np.tanh(k*d); k0=brentq(lambda k:w*w-g*k*np.tanh(k*d),1e-9,1.,xtol=1e-22)
k1=brentq(f,1e-7,w/U-1e-9,xtol=1e-22); fa=lambda k:(w+k*U)**2-g*k*np.tanh(k*d); ks=np.linspace(1e-6,2e-3,4000); kk=[x for x,y in zip(ks[:-1],ks[1:]) if fa(x)*fa(y)<0][0]; kn=brentq(fa,kk,kk+(ks[1]-ks[0]),xtol=1e-22)
P['C2']=dict(k0=k0,L0=2*np.pi/k0,k_follow=k1,L_follow=2*np.pi/k1,k_against=kn,L_against=2*np.pi/kn)
json.dump(P,open('probs.json','w'),indent=1,default=float)
for k_,v in P.items(): print(k_,v)
