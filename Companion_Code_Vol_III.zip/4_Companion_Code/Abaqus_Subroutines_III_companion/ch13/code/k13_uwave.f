      SUBROUTINE UWAVE(V, A, PDYN, DPDYNDZ, SURF, LPDYN, LRECOMPUTE,
     1 LUPLOCAL, LUPGLOBAL, LSURF, NDIM, XCUR, XINTERMED, GRAV,
     2 DENSITY, ELEVB, ELEVS, SEED, NSPECTRUM, FREQWAMP, TIME, DTIME,
     3 NOEL, NPT, KSTEP, KINC)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION V(NDIM), A(NDIM), XCUR(NDIM), XINTERMED(NDIM),
     1 FREQWAMP(2, NSPECTRUM), TIME(2)
!     Regular wave, Stokes second order (ITH = 2) or Airy (ITH = 1).
      PARAMETER (ITH = 2)
      PARAMETER (HW = 2000.D0)    ! wave height H, mm
      PARAMETER (PER = 8.D0)      ! wave period, s
      PARAMETER (ANG = 0.D0)      ! direction of travel from x, rad
      DEP = ELEVS - ELEVB                    ! still-water depth
      CALL K13_WAVENO(PER, DEP, GRAV, AK, NIT)
      CA = COS(ANG)
      SA = SIN(ANG)
      IF (NDIM .EQ. 3) THEN
         XH = CA*XCUR(1) + SA*XCUR(2)       ! horizontal, along travel
         Z  = XCUR(3) - ELEVS               ! vertical is z in 3-D
      ELSE
         XH = XCUR(1)
         Z  = XCUR(2) - ELEVS               ! vertical is y in 2-D
      END IF
      Z = MAX(Z, -DEP)
      TT = TIME(2)
      CALL K13_AIRY(XH, Z, TT, HW, PER, DEP, GRAV, DENSITY, AK, UH, W,
     1 AH, AW, P, DPDZ, ETA)
      IF (ITH .EQ. 2) CALL K13_STK2(XH, Z, TT, HW, PER, DEP, GRAV,
     1 DENSITY, AK, UH, W, AH, AW, P, DPDZ, ETA)
      IF (LSURF .EQ. 1) THEN
         SURF = ELEVS + ETA
      ELSE IF (LPDYN .EQ. 1) THEN
         PDYN = P
         DPDYNDZ = DPDZ
      ELSE
         IF (NDIM .EQ. 3) THEN
            V(1) = UH*CA
            V(2) = UH*SA
            V(3) = W
            A(1) = AH*CA
            A(2) = AH*SA
            A(3) = AW
         ELSE
            V(1) = UH
            V(2) = W
            A(1) = AH
            A(2) = AW
         END IF
      END IF
      RETURN
      END
