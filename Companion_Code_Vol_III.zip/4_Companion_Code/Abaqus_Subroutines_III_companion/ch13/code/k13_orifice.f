      SUBROUTINE K13_ORIF(PU,TU,PD,CD,AREA,GAM,RGAS,FM,DFDPU,DFDPD,
     1 DFDTU)
!     Isentropic mass flow rate of an ideal gas through an orifice,
!     from upstream (PU, TU) to downstream pressure PD (absolute).
!     Units: MPa, K, mm^2, mm^2/(s^2 K), tonne/s.
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (EPS = 1.D-3)   ! width of the linear band at PD = PU
      Q  = PD/PU
      QC = (2.D0/(GAM + 1.D0))**(GAM/(GAM - 1.D0))   ! critical ratio
      QL = 1.D0 - EPS
      QE = MIN(MAX(Q, QC), QL)                       ! unchoked range
      PSI  = SQRT(2.D0*GAM/(GAM - 1.D0)*(QE**(2.D0/GAM)
     1       - QE**((GAM + 1.D0)/GAM)))
      DPSI = 0.5D0/PSI*2.D0*GAM/(GAM - 1.D0)*(2.D0/GAM
     1       *QE**(2.D0/GAM - 1.D0) - (GAM + 1.D0)/GAM*QE**(1.D0/GAM))
      IF (Q .LE. QC) THEN                            ! choked
         PSI  = SQRT(GAM)*(2.D0/(GAM + 1.D0))**((GAM + 1.D0)
     1          /(2.D0*(GAM - 1.D0)))
         DPSI = 0.D0
      ELSE IF (Q .GT. QL) THEN                       ! linear band
         DPSI = -PSI/EPS
         PSI  = PSI*(1.D0 - MIN(Q, 1.D0))/EPS
      END IF
      CA  = CD*AREA/SQRT(RGAS*TU)
      FM  = CA*PU*PSI
      DFDPD = CA*DPSI
      DFDPU = CA*(PSI - Q*DPSI)
      DFDTU = -0.5D0*FM/TU
      RETURN
      END
