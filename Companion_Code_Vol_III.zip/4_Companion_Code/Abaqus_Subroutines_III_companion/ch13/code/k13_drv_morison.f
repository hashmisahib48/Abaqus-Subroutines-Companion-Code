      PROGRAM K13MOR
!     In-line force and base moment on a vertical pile (Morison) from
!     the velocity and acceleration returned by UWAVE, integrated from
!     the seabed to the still level by Simpson's rule at x = 0.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (G = 9810.D0, RHO = 1.D-9, SB = 0.D0, SWL = 1.5D4)
      PARAMETER (DIAM = 500.D0)    ! pile diameter, mm
      PARAMETER (CD = 1.D0, CM = 2.D0, PER = 8.D0, PI = 3.14159265D0)
      PARAMETER (NS = 2000)        ! Simpson intervals, even
      DIMENSION V(2), A(2), XC(2), XI(2), FQ(2,1), TM(2)
      WRITE(*,'(A)') 'phase t(s) FI(N) FD(N) F(N) M(N mm)'
      DO 30 IT = 0, 15
         T = PER*IT/16.D0
         TM(1) = T
         TM(2) = T
         FI = 0.D0
         FD = 0.D0
         XM = 0.D0
         DO 20 K = 0, NS
            Y = SB + (SWL - SB)*K/NS
            WT = 2.D0
            IF (K .EQ. 0 .OR. K .EQ. NS) WT = 1.D0
            IF (MOD(K,2) .EQ. 1) WT = 4.D0
            XC(1) = 0.D0
            XC(2) = Y
            CALL UWAVE(V, A, PD, DPD, SU, 0, 0, LUL, LUG, 0, 2, XC, XI,
     1       G, RHO, SB, SWL, 0.D0, 0, FQ, TM, 1.D-2, 1, 1, 1, 1)
            DFI = RHO*CM*PI*DIAM**2/4.D0*A(1)
            DFD = 0.5D0*RHO*CD*DIAM*ABS(V(1))*V(1)
            H = (SWL - SB)/NS
            FI = FI + WT*DFI*H/3.D0
            FD = FD + WT*DFD*H/3.D0
            XM = XM + WT*(DFI + DFD)*(Y - SB)*H/3.D0
   20    CONTINUE
         WRITE(*,'(I3,F8.3,1P,4E16.8)') IT, T, FI, FD, FI + FD, XM
   30 CONTINUE
      END
