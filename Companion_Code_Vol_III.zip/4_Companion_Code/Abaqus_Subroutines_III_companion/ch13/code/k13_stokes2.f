      SUBROUTINE K13_STK2(X, Z, T, H, PER, DEP, G, RHO, AK, U, W, AX,
     1 AZ, P, DPDZ, ETA)
!     Adds the second-order terms of the Stokes wave (Dean and
!     Dalrymple) to the first-order values returned by K13_AIRY.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0)
      OM = 2.D0*PI/PER
      TH = AK*X - OM*T
      E2 = EXP(-2.D0*AK*DEP)
      EZ = EXP(2.D0*AK*Z)
      EN = EXP(-2.D0*AK*(Z + 3.D0*DEP))
      EP = EXP(2.D0*AK*(Z - DEP))
      D4 = (1.D0 - E2)**4
      C2 = 8.D0*(EP + EN)/D4            ! cosh 2k(z+d) / sinh^4 kd
      S2 = 8.D0*(EP - EN)/D4            ! sinh 2k(z+d) / sinh^4 kd
      B2 = 3.D0/16.D0*H*H*OM*AK
      U  = U  + B2*C2*COS(2.D0*TH)
      W  = W  + B2*S2*SIN(2.D0*TH)
      AX = AX + 2.D0*OM*B2*C2*SIN(2.D0*TH)
      AZ = AZ - 2.D0*OM*B2*S2*COS(2.D0*TH)
!     pressure: rho*g*(H**2*k/2) times the bracketed terms
      PK = RHO*G*0.5D0*H*H*AK
      TK = (1.D0 - E2)/(1.D0 + E2)      ! tanh kd
      SD = 2.D0*E2/(1.D0 - E2*E2)       ! 1 / sinh 2kd
      CZ = EZ*(1.D0 + EXP(-4.D0*AK*(Z + DEP)))/(1.D0 - E2*E2)
      SZ = EZ*(1.D0 - EXP(-4.D0*AK*(Z + DEP)))/(1.D0 - E2*E2)
      P  = P + PK*(0.75D0*(0.5D0*C2*TK - SD/3.D0)*COS(2.D0*TH)
     1     - 0.25D0*(CZ - SD))
      DPDZ = DPDZ + PK*(0.75D0*AK*TK*S2*COS(2.D0*TH)
     1     - 0.5D0*AK*SZ)
      ETA = ETA + H*H*AK/8.D0*(1.D0 + E2)*(1.D0 + 4.D0*E2 + E2*E2)
     1      /(1.D0 - E2)**3*COS(2.D0*TH)
      RETURN
      END
