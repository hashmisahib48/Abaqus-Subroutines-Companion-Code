      PROGRAM K13VW
!     Driver for VWAVE: one block of five points, the four calls that
!     Abaqus/Explicit makes (free surface, buoyancy, drag, inertia).
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 5, ND = 2, NP = 8)
      DIMENSION FWS(NB), FUV(NB,ND), FFA(NB,ND), FUP(NB), FUD(NB),
     1 COORD(NB,ND), VEL(NB,ND), SV(NB,1), FV(NB,1), DV(NB,ND),
     2 AQ(1), WC(1), FSV(NB,ND), PROPS(NP)
      CHARACTER*80 SNAME
      DATA PROPS /2000.D0, 8.D0, 0.D0, 1.5D4, 0.D0, 9810.D0, 1.D-9,
     1 2.D0/
      DATA COORD /0.D0, 1234.D0, 5000.D0, 3000.D0, -2500.D0,
     1 15000.D0, 11000.D0, 15000.D0, 3000.D0, 13500.D0/
      DATA TT /0.D0/
      SNAME = 'WETSET'
      DO 5 K = 1, NB
         VEL(K,1) = 0.D0
         VEL(K,2) = 0.D0
         FSV(K,1) = 0.D0
         FSV(K,2) = 0.D0
         DV(K,1) = 0.D0
         DV(K,2) = 1.D0
    5 CONTINUE
      WRITE(*,'(A)') 'x y SURF(IN->OUT) u w ax az p dpdz'
      TT = 2.5D0
      CALL CALLV(0)
      CALL CALLV(1)
      CALL CALLV(2)
      CALL CALLV(3)
      DO 10 K = 1, NB
         WRITE(*,'(2F10.1,1P,7E22.14)') COORD(K,1), COORD(K,2),
     1    FWS(K), FUV(K,1), FUV(K,2), FFA(K,1), FFA(K,2), FUP(K),
     2    FUD(K)
   10 CONTINUE
      CONTAINS
      SUBROUTINE CALLV(IFLAG)
      DO 20 K = 1, NB
         IF (IFLAG .EQ. 0) FWS(K) = PROPS(4)   ! still level comes in
         IF (IFLAG .NE. 0) THEN
            FUV(K,1) = FUV(K,1)
         END IF
   20 CONTINUE
      SS = 1.D0
      SU = 1.D0
      CALL VWAVE(FWS, FUV, FFA, FUP, FUD, SS, SU, 1, 1, NB, ND, NP, 1,
     1 1, 1, 1, 2, 51, SNAME, IFLAG, COORD, VEL, SV, FV, DV, AQ, WC,
     2 FSV, PROPS, 1.D-4, TT, TT)
      END SUBROUTINE
      END
