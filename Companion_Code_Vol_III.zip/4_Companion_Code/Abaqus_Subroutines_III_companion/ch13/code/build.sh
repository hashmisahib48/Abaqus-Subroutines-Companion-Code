#!/bin/sh
# compile every listing and run the drivers (gfortran, stubs in lib/aba)
A=/home/claude/vol3/lib/aba
F="-ffixed-form -ffixed-line-length-none -std=legacy -I$A"
cd "$(dirname "$0")"
T=/tmp/claude-0/ch13; mkdir -p $T
for f in k13_orifice k13_vufluidexch k13_effarea k13_wave k13_airy k13_stokes2 k13_uwave k13_vwave; do gfortran -c $F $f.f -o $T/$f.o || exit 1; done
gfortran $F k13_drv_orif.f k13_vufluidexch.f k13_orifice.f $A/stubs.f -o /tmp/claude-0/orif || exit 1
gfortran $F k13_drv_tank.f k13_vufluidexch.f k13_orifice.f $A/stubs.f -o /tmp/claude-0/tank || exit 1
gfortran $F k13_drv_fabric.f k13_effarea.f k13_vufluidexch.f k13_orifice.f $A/stubs.f -o /tmp/claude-0/fab || exit 1
gfortran $F k13_drv_wave.f k13_uwave.f k13_wave.f k13_airy.f k13_stokes2.f $A/stubs.f -o /tmp/claude-0/wave || exit 1
gfortran $F k13_drv_morison.f k13_uwave.f k13_wave.f k13_airy.f k13_stokes2.f $A/stubs.f -o /tmp/claude-0/mor_stk || exit 1
sed 's/ITH = 2/ITH = 1/' k13_uwave.f > $T/uwave_airy.f
gfortran $F k13_drv_morison.f $T/uwave_airy.f k13_wave.f k13_airy.f k13_stokes2.f $A/stubs.f -o /tmp/claude-0/mor_airy || exit 1
gfortran $F k13_drv_vwave.f k13_vwave.f k13_wave.f k13_airy.f k13_stokes2.f $A/stubs.f -o /tmp/claude-0/vwave || exit 1
/tmp/claude-0/orif > ../verify/out_orif.txt
/tmp/claude-0/wave > ../verify/out_wave.txt
/tmp/claude-0/mor_airy > ../verify/out_mor_airy.txt
/tmp/claude-0/mor_stk > ../verify/out_mor_stk.txt
/tmp/claude-0/vwave > ../verify/out_vwave.txt
echo 5d-5 | /tmp/claude-0/fab > ../verify/out_fab.txt
echo "1d-4 2" | /tmp/claude-0/tank > ../verify/out_tank_adiab.txt
echo "1d-4 3" | /tmp/claude-0/tank > ../verify/out_tank_isoth.txt
echo built
