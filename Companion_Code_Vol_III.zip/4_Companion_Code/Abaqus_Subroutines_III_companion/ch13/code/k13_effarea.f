      SUBROUTINE VUFLUIDEXCHEFFAREA(
     1 NBLOCK, NPROP, PROPS, STEPTIME, TOTALTIME, FLUEXCHNAME,
     2 CMATNAME, LFABRIC, BRAIDANGLE, STRAIN, ORIGAREA, PCAV, CTEMP,
     3 EFFAREA)
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NDIR = 3, NSHR = 1)
      DIMENSION PROPS(NPROP), BRAIDANGLE(NBLOCK),
     1 STRAIN(NBLOCK, NDIR+NSHR), ORIGAREA(NBLOCK), PCAV(2), CTEMP(2),
     2 EFFAREA(NBLOCK)
      CHARACTER*80 FLUEXCHNAME, CMATNAME
!     Open-area fraction of a woven fabric from the yarn strains and
!     the yarn angle, plus a pressure-driven seam opening.
!     PROPS: 1 yarn width W (mm), 2 reference pitch S0 (mm),
!     3 and 4 pressure difference where the seam starts to open and
!     is fully open (MPa), 5 open-area fraction added by the open seam
      W   = PROPS(1)
      S0  = PROPS(2)
      DP1 = PROPS(3)
      DP2 = PROPS(4)
      FB  = PROPS(5)
      U = MIN(MAX((PCAV(1) - PCAV(2) - DP1)/(DP2 - DP1), 0.D0), 1.D0)
      OM = U*U*(3.D0 - 2.D0*U)                  ! smoothstep, 0 to 1
      DO 10 K = 1, NBLOCK
         IF (LFABRIC .EQ. 1) THEN
            SA = SIN(BRAIDANGLE(K))
            F1 = MAX(1.D0 - W/(S0*(1.D0 + STRAIN(K,1))*SA), 0.D0)
            F2 = MAX(1.D0 - W/(S0*(1.D0 + STRAIN(K,2))*SA), 0.D0)
            PHI = F1*F2 + OM*FB
            EFFAREA(K) = EFFAREA(K)*PHI      ! EFFAREA: current area
         END IF
   10 CONTINUE
      RETURN
      END
