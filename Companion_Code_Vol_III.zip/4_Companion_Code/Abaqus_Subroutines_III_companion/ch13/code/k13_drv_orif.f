      PROGRAM K13ORIF
!     Mass flow through the orifice of VUFLUIDEXCH against the pressure
!     ratio, with finite-difference checks of every derivative.
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PROPS(4), PN(2), PO(2), TN(2), TO(2), CV(2), CM(2),
     1 RM(2), CP(2), DCP(2), FLD(1), SO(1), SN(1), DMP(2), DMT(2),
     2 DEP(2), DET(2), DMP2(2), DMT2(2), DEP2(2), DET2(2)
      CHARACTER*80 NAM
      PARAMETER (RG = 2.87D8)      ! gas constant of air, mm^2/(s^2 K)
      PARAMETER (CPA = 1.0045D9)   ! cp of air, mm^2/(s^2 K)
      PARAMETER (PU = 0.30D0)      ! upstream pressure, MPa
      PARAMETER (TU = 300.D0)      ! upstream temperature, K
      PROPS(1) = 0.7D0             ! discharge coefficient
      PROPS(2) = 0.D0              ! K
      NAM = 'VENT'
      DO 5 K = 1, 2
         RM(K) = RG
         CP(K) = CPA
         DCP(K) = 0.D0
         CV(K) = 6.D7
         CM(K) = 0.D0
         TN(K) = TU
         TO(K) = TU
    5 CONTINUE
      WRITE(*,'(A)') '     q          mdot(t/s)        dm/dp1'
     1 //'       dm/dT1        E(mW)'
      DO 100 IQ = 1, 8
         GO TO (11,12,13,14,15,16,17,18), IQ
   11    Q = 0.05D0
         GO TO 20
   12    Q = 0.30D0
         GO TO 20
   13    Q = 0.5282D0
         GO TO 20
   14    Q = 0.5284D0
         GO TO 20
   15    Q = 0.60D0
         GO TO 20
   16    Q = 0.80D0
         GO TO 20
   17    Q = 0.95D0
         GO TO 20
   18    Q = 0.9995D0
   20    PROPS(3) = Q*PU
         PROPS(4) = TU
         PN(1) = PU
         PN(2) = Q*PU
         CALL VUFLUIDEXCH(0, 1, 4, 0.D0, 0.D0, 1.D-4, 2, NAM, 2000.D0,
     1    1.D0, PROPS, 1, PN, PO, TN, TO, CV, CM, RM, CP, DCP, FLD, SO,
     2    SN, XM, XE, DMP, DMT, DEP, DET)
!        central differences
         H = 1.D-6*PU
         PN(1) = PU + H
         CALL VUFLUIDEXCH(0, 1, 4, 0.D0, 0.D0, 1.D-4, 2, NAM, 2000.D0,
     1    1.D0, PROPS, 1, PN, PO, TN, TO, CV, CM, RM, CP, DCP, FLD, SO,
     2    SN, XMP, XEP, DMP2, DMT2, DEP2, DET2)
         PN(1) = PU - H
         CALL VUFLUIDEXCH(0, 1, 4, 0.D0, 0.D0, 1.D-4, 2, NAM, 2000.D0,
     1    1.D0, PROPS, 1, PN, PO, TN, TO, CV, CM, RM, CP, DCP, FLD, SO,
     2    SN, XMM, XEM, DMP2, DMT2, DEP2, DET2)
         FDP = (XMP - XMM)/(2.D0*H)
         FDEP = (XEP - XEM)/(2.D0*H)
         PN(1) = PU
         HT = 1.D-4*TU
         TN(1) = TU + HT
         CALL VUFLUIDEXCH(0, 1, 4, 0.D0, 0.D0, 1.D-4, 2, NAM, 2000.D0,
     1    1.D0, PROPS, 1, PN, PO, TN, TO, CV, CM, RM, CP, DCP, FLD, SO,
     2    SN, XMP, XEP, DMP2, DMT2, DEP2, DET2)
         TN(1) = TU - HT
         CALL VUFLUIDEXCH(0, 1, 4, 0.D0, 0.D0, 1.D-4, 2, NAM, 2000.D0,
     1    1.D0, PROPS, 1, PN, PO, TN, TO, CV, CM, RM, CP, DCP, FLD, SO,
     2    SN, XMM, XEM, DMP2, DMT2, DEP2, DET2)
         TN(1) = TU
         FDT = (XMP - XMM)/(2.D0*HT)
         FDET = (XEP - XEM)/(2.D0*HT)
         WRITE(*,'(F8.4,1P,E16.8,3E14.5)') Q, XM, DMP(1), DMT(1), XE
         WRITE(*,'(A,1P,4E14.5)') '   FD:', FDP, FDT, FDEP, FDET
         WRITE(*,'(A,1P,4E14.5)') '   AN:', DMP(1), DMT(1), DEP(1),
     1    DET(1)
  100 CONTINUE
      END
