      PROGRAM K13BUG
      INCLUDE 'VABA_PARAM.INC'
      DO 10 I = 1, 4
         GO TO (1,2,3,4), I
    1    P1 = 0.30D0
         P2 = 0.101325D0
         GO TO 5
    2    P1 = 0.15D0
         P2 = 0.101325D0
         GO TO 5
    3    P1 = 0.101325D0
         P2 = 0.30D0
         GO TO 5
    4    P1 = 0.30D0
         P2 = 0.29D0
    5    CALL K13_BUG(P1, P2, 26.85D0, 0.7D0, 2000.D0, 0.5D0, FM)
         WRITE(*,'(2F10.5,1P,E16.6)') P1, P2, FM
   10 CONTINUE
      END
