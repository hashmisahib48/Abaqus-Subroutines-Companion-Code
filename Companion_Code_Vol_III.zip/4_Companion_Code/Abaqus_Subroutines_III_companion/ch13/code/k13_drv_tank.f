      PROGRAM K13TANK
!     Blowdown of a rigid gas cavity (an airbag) through the orifice of
!     VUFLUIDEXCH into the ambient. The cavity update is the driver's:
!     mass balance, and for an adiabatic gas the energy balance
!     d(m cv T) = -E dt, advanced with the rates at the start of the
!     increment (forward Euler).
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PROPS(4), PN(2), PO(2), TN(2), TO(2), CV(2), CM(2),
     1 RM(2), CP(2), DCP(2), FLD(1), SO(1), SN(1), DMP(2), DMT(2),
     2 DEP(2), DET(2)
      CHARACTER*80 NAM
      PARAMETER (RG = 2.87D8)      ! gas constant of air, mm^2/(s^2 K)
      PARAMETER (CPA = 1.0045D9)   ! cp of air, mm^2/(s^2 K)
      PARAMETER (VOL = 6.D7)       ! cavity volume, mm^3 (60 litres)
      PARAMETER (P0 = 0.30D0)      ! initial absolute pressure, MPa
      PARAMETER (T0 = 300.D0)      ! initial temperature, K
      PARAMETER (PAMB = 0.101325D0)! ambient pressure, MPa
      PARAMETER (AV = 2000.D0)     ! vent area, mm^2
      PARAMETER (TEND = 0.6D0)     ! s
      READ(*,*) DT, ICAV           ! time step (s); 2 adiabatic, 3 isoth.
      CVA = CPA - RG
      PROPS(1) = 0.7D0
      PROPS(2) = 0.D0
      PROPS(3) = PAMB
      PROPS(4) = T0
      NAM = 'VENT'
      XM = P0*VOL/(RG*T0)
      T  = T0
      NSTEP = NINT(TEND/DT)
      NPR = NINT(0.002D0/DT)
      DO 5 K = 1, 2
         RM(K) = RG
         CP(K) = CPA
         DCP(K) = 0.D0
         CV(K) = VOL
         TN(K) = T0
         TO(K) = T0
    5 CONTINUE
      WRITE(*,'(A)') '   t(s)       p(MPa)       T(K)      mdot(t/s)'
      DO 100 N = 0, NSTEP
         P = XM*RG*T/VOL
         PN(1) = P
         PN(2) = PAMB
         PO(1) = P
         PO(2) = PAMB
         TN(1) = T
         TO(1) = T
         CM(1) = XM
         CALL VUFLUIDEXCH(0, 1, 4, N*DT, N*DT, DT, ICAV, NAM, AV, 1.D0,
     1    PROPS, 1, PN, PO, TN, TO, CV, CM, RM, CP, DCP, FLD, SO, SN,
     2    XDOT, XE, DMP, DMT, DEP, DET)
         IF (MOD(N, NPR) .EQ. 0) WRITE(*,'(F8.4,F12.7,F11.4,1P,E14.6)')
     1    N*DT, P, T, XDOT
         XMN = XM - XDOT*DT
         IF (ICAV .EQ. 2) T = T + (-XE*DT + CVA*T*XDOT*DT)/(XM*CVA)
         XM = XMN
  100 CONTINUE
      END
