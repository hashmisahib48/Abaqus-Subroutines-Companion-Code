      SUBROUTINE K13_WAVENO(PER, DEP, G, AK, NIT)
!     Wave number AK (1/mm) from the dispersion relation
!     w**2 = G*AK*TANH(AK*DEP) by Newton iteration on y = AK*DEP:
!     y*tanh(y) = w**2*DEP/G.  PER in s, DEP in mm, G in mm/s^2.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0)
      W  = 2.D0*PI/PER
      X0 = W*W*DEP/G
      Y  = MAX(X0, SQRT(X0))            ! deep- or shallow-water start
      DO 10 NIT = 1, 50
         TH = TANH(Y)
         F  = Y*TH - X0
         DY = F/(TH + Y*(1.D0 - TH*TH))
         Y  = Y - DY
         IF (ABS(DY) .LT. 1.D-14*Y) GOTO 20
   10 CONTINUE
   20 AK = Y/DEP
      RETURN
      END
