      PROGRAM K13FAB
!     (1) Open-area fraction of VUFLUIDEXCHEFFAREA for a block of
!     fabric points; (2) adiabatic blowdown of a 60 litre cavity
!     through the fabric, the area being updated every increment from
!     the pressure at the start of the increment.
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 6)
      DIMENSION PR(5), PCAV(2), CT(2), BA(NB), STR(NB,4), OA(NB),
     1 EA(NB)
      DIMENSION PROPS(4), PN(2), PO(2), TN(2), TO(2), CV(2), CM(2),
     1 RM(2), CP(2), DCP(2), FLD(1), SO(1), SN(1), DMP(2), DMT(2),
     2 DEP(2), DET(2)
      CHARACTER*80 NAM, MAT
      PARAMETER (PI = 3.14159265358979D0)
      PARAMETER (RG = 2.87D8, CPA = 1.0045D9)  ! mm^2/(s^2 K)
      PARAMETER (VOL = 6.D7, P0 = 0.30D0, T0 = 300.D0, PAMB = 0.101325D0)
      PARAMETER (AFAB = 6.D4)     ! fabric area of the bag, mm^2
      PR(1) = 0.38D0               ! yarn width, mm
      PR(2) = 0.50D0               ! pitch at zero strain, mm
      PR(3) = 0.12D0               ! seam opens from this dp, MPa
      PR(4) = 0.16D0               ! fully open at this dp, MPa
      PR(5) = 0.03D0               ! open fraction of the seam region
      NAM = 'FAB'
      MAT = 'FABRIC'
      PCAV(2) = PAMB
      CT(1) = T0
      CT(2) = T0
      WRITE(*,'(A)') 'part 1: strain1 strain2 angle(deg) dp  phi'
      DO 30 J = 1, 7
         DO 10 K = 1, NB
            OA(K) = 1.D0
            EA(K) = 1.D0
            STR(K,1) = 0.D0
            STR(K,2) = 0.D0
            STR(K,3) = 0.D0
            STR(K,4) = 0.D0
            BA(K) = PI/2.D0
   10    CONTINUE
         STR(2,1) = 0.02D0
         STR(2,2) = 0.01D0
         BA(2) = 85.D0*PI/180.D0
         STR(3,1) = 0.04D0
         STR(3,2) = 0.04D0
         STR(4,1) = -0.03D0
         STR(4,2) = 0.D0
         BA(5) = 60.D0*PI/180.D0
         BA(6) = 45.D0*PI/180.D0
         STR(6,1) = 0.05D0
         DPJ = 0.05D0*(J - 1)
         PCAV(1) = PAMB + DPJ
         CALL VUFLUIDEXCHEFFAREA(NB, 5, PR, 0.D0, 0.D0, NAM, MAT, 1,
     1    BA, STR, OA, PCAV, CT, EA)
         DO 20 K = 1, NB
            IF (J .EQ. 1 .OR. K .EQ. 2) WRITE(*,'(2F8.4,F8.2,F8.3,
     1       F12.8)') STR(K,1), STR(K,2), BA(K)*180.D0/PI, DPJ, EA(K)
   20    CONTINUE
   30 CONTINUE
      WRITE(*,'(A)') 'part 2: t p T area'
      READ(*,*) DT
      PROPS(1) = 0.7D0
      PROPS(2) = 0.D0
      PROPS(3) = PAMB
      PROPS(4) = T0
      XM = P0*VOL/(RG*T0)
      T = T0
      CVA = CPA - RG
      NPR = NINT(0.002D0/DT)
      DO 5 K = 1, 2
         RM(K) = RG
         CP(K) = CPA
         DCP(K) = 0.D0
         CV(K) = VOL
         TN(K) = T0
         TO(K) = T0
    5 CONTINUE
      DO 100 N = 0, NINT(0.4D0/DT)
         P = XM*RG*T/VOL
         PCAV(1) = P
         DO 40 K = 1, NB
            OA(K) = AFAB
            EA(K) = AFAB
            STR(K,1) = 0.02D0
            STR(K,2) = 0.01D0
            STR(K,3) = 0.D0
            STR(K,4) = 0.D0
            BA(K) = 85.D0*PI/180.D0
   40    CONTINUE
         CALL VUFLUIDEXCHEFFAREA(NB, 5, PR, N*DT, N*DT, NAM, MAT, 1, BA,
     1    STR, OA, PCAV, CT, EA)
         PN(1) = P
         PN(2) = PAMB
         PO(1) = P
         PO(2) = PAMB
         TN(1) = T
         TO(1) = T
         CALL VUFLUIDEXCH(0, 1, 4, N*DT, N*DT, DT, 2, NAM, EA(1), 1.D0,
     1    PROPS, 1, PN, PO, TN, TO, CV, CM, RM, CP, DCP, FLD, SO, SN,
     2    XDOT, XE, DMP, DMT, DEP, DET)
         IF (MOD(N, NPR) .EQ. 0) WRITE(*,'(F8.4,F12.7,F11.4,F12.2)')
     1    N*DT, P, T, EA(1)
         T = T + (-XE*DT + CVA*T*XDOT*DT)/(XM*CVA)
         XM = XM - XDOT*DT
  100 CONTINUE
      END
