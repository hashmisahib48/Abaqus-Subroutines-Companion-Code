      SUBROUTINE K13_BUG(P1, P2, T1C, CD, AREA, AMP, FM)
!     Mass flow rate of a vent, from cavity 1 (P1, T1C in deg C) to
!     cavity 2 (P2); meant to behave like the core of VUFLUIDEXCH.
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (GAM = 1.4D0, RG = 2.87D8)
      Q  = P1/P2
      QC = (2.D0/(GAM + 1.D0))**(GAM/(GAM - 1.D0))
      IF (Q .LT. QC) THEN
         PSI = SQRT(GAM)*(2.D0/(GAM + 1.D0))**((GAM + 1.D0)
     1         /(GAM - 1.D0))
      ELSE
         PSI = SQRT(2.D0*GAM/(GAM - 1.D0)*(Q**(2.D0/GAM)
     1         - Q**((GAM + 1.D0)/GAM)))
      END IF
      FM = CD*AREA*P1*PSI/SQRT(RG*T1C)
      RETURN
      END
