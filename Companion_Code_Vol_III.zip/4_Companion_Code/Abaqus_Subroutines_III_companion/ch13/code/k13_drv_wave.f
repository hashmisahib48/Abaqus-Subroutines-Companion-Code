      PROGRAM K13WAVE
!     Driver for UWAVE: (A) dispersion relation, (B) kinematics at
!     probe points called as Abaqus calls the routine, (C) residual of
!     the Euler equation against the wave height, (D) Morison force
!     on a vertical pile by integrating the UWAVE velocity and
!     acceleration.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0)
      PARAMETER (G = 9810.D0, RHO = 1.D-9, SB = 0.D0, SWL = 15000.D0)
      DIMENSION V(2), A(2), XC(2), XI(2), FQ(2,1), TM(2), PTS(3,5)
      DIMENSION Q0(7), QXP(7), QXM(7), QZP(7), QZM(7), QTP(7), QTM(7)
      DIMENSION PERS(4), DEPS(4)
      DATA PERS /8.D0, 4.D0, 12.D0, 8.D0/
      DATA DEPS /1.5D4, 4.D4, 2.D3, 1.D6/
      DATA PTS /0.D0,15000.D0,0.D0,  1234.D0,11000.D0,0.7D0,
     1 5000.D0,15000.D0,2.5D0, 3000.D0,3000.D0,4.1D0,
     2 -2500.D0,13500.D0,6.3D0/
      WRITE(*,'(A)') 'A dispersion: T d k iterations'
      DO 10 I = 1, 4
         CALL K13_WAVENO(PERS(I), DEPS(I), G, AK, NIT)
         WRITE(*,'(2F10.1,1P,E22.14,I4)') PERS(I), DEPS(I), AK, NIT
   10 CONTINUE
      WRITE(*,'(A)') 'B kinematics: x y t SURF u w ax az p dpdz'
      DO 20 I = 1, 5
         XC(1) = PTS(1,I)
         XC(2) = PTS(2,I)
         TM(1) = PTS(3,I)
         TM(2) = PTS(3,I)
         CALL UWAVE(V, A, PD, DPD, SURF, 0, 0, LUL, LUG, 1, 2, XC, XI,
     1    G, RHO, SB, SWL, 0.D0, 0, FQ, TM, 1.D-2, 1, 1, 1, 1)
         CALL UWAVE(V, A, PD, DPD, SU2, 0, 0, LUL, LUG, 0, 2, XC, XI,
     1    G, RHO, SB, SWL, 0.D0, 0, FQ, TM, 1.D-2, 1, 1, 1, 1)
         CALL UWAVE(V, A, PD, DPD, SU2, 1, 0, LUL, LUG, 0, 2, XC, XI,
     1    G, RHO, SB, SWL, 0.D0, 0, FQ, TM, 1.D-2, 1, 1, 1, 1)
         WRITE(*,'(3F10.2,1P,7E22.14)') PTS(1,I), PTS(2,I), PTS(3,I),
     1    SURF, V(1), V(2), A(1), A(2), PD, DPD
   20 CONTINUE
      WRITE(*,'(A)') 'C Euler residual: H  continuity  rx  rz'
      PER = 8.D0
      DEP = 1.5D4
      CALL K13_WAVENO(PER, DEP, G, AK, NIT)
      X0 = 1234.D0
      Z0 = -3000.D0
      T0 = 0.7D0
      HX = 1.D-2
      HT = 1.D-5
      DO 40 IH = 0, 3
         HW = 1000.D0/2.D0**IH
         CALL KINV(X0, Z0, T0, HW, PER, DEP, AK, Q0)
         CALL KINV(X0+HX, Z0, T0, HW, PER, DEP, AK, QXP)
         CALL KINV(X0-HX, Z0, T0, HW, PER, DEP, AK, QXM)
         CALL KINV(X0, Z0+HX, T0, HW, PER, DEP, AK, QZP)
         CALL KINV(X0, Z0-HX, T0, HW, PER, DEP, AK, QZM)
         CALL KINV(X0, Z0, T0+HT, HW, PER, DEP, AK, QTP)
         CALL KINV(X0, Z0, T0-HT, HW, PER, DEP, AK, QTM)
         UX = (QXP(1) - QXM(1))/(2.D0*HX)
         WX = (QXP(2) - QXM(2))/(2.D0*HX)
         UZ = (QZP(1) - QZM(1))/(2.D0*HX)
         WZ = (QZP(2) - QZM(2))/(2.D0*HX)
         UT = (QTP(1) - QTM(1))/(2.D0*HT)
         WT = (QTP(2) - QTM(2))/(2.D0*HT)
         PX = (QXP(5) - QXM(5))/(2.D0*HX)
         PZ = (QZP(5) - QZM(5))/(2.D0*HX)
         RX = PX/RHO + UT + Q0(1)*UX + Q0(2)*UZ
         RZ = PZ/RHO + WT + Q0(1)*WX + Q0(2)*WZ
         WRITE(*,'(F8.1,1P,3E16.6)') HW, UX + WZ, RX, RZ
   40 CONTINUE
      END
      SUBROUTINE KINV(X, Z, T, HW, PER, DEP, AK, Q)
!     Stokes second-order kinematics as used by UWAVE (RHO, G fixed):
!     Q = u, w, ax, az, p, dp/dz, eta
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION Q(7)
      CALL K13_AIRY(X, Z, T, HW, PER, DEP, 9810.D0, 1.D-9, AK, Q(1),
     1 Q(2), Q(3), Q(4), Q(5), Q(6), Q(7))
      CALL K13_STK2(X, Z, T, HW, PER, DEP, 9810.D0, 1.D-9, AK, Q(1),
     1 Q(2), Q(3), Q(4), Q(5), Q(6), Q(7))
      RETURN
      END
