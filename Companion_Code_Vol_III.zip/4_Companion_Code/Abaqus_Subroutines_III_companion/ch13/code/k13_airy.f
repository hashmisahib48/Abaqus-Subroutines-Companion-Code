      SUBROUTINE K13_AIRY(X, Z, T, H, PER, DEP, G, RHO, AK, U, W, AX,
     1 AZ, P, DPDZ, ETA)
!     Airy (linear) wave travelling in +X.  Z is measured from the
!     still level (Z = 0), DEP is the depth, AK the wave number.
!     Units: mm, s, tonne/mm^3, MPa; the pressure is the dynamic part.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0)
      OM = 2.D0*PI/PER
      TH = AK*X - OM*T
      E2 = EXP(-2.D0*AK*DEP)
      EZ = EXP(AK*Z)
      EN = EXP(-AK*(Z + 2.D0*DEP))
      CHR = (EZ + EN)/(1.D0 + E2)         ! cosh k(z+d) / cosh kd
      SHR = (EZ - EN)/(1.D0 + E2)         ! sinh k(z+d) / cosh kd
      A1 = 0.5D0*H*OM*(1.D0 + E2)/(1.D0 - E2)   ! (H/2) w / tanh kd
      U   =  A1*CHR*COS(TH)
      W   =  A1*SHR*SIN(TH)
      AX  =  OM*A1*CHR*SIN(TH)
      AZ  = -OM*A1*SHR*COS(TH)
      P   =  RHO*G*0.5D0*H*CHR*COS(TH)
      DPDZ = RHO*G*0.5D0*H*AK*SHR*COS(TH)
      ETA =  0.5D0*H*COS(TH)
      RETURN
      END
