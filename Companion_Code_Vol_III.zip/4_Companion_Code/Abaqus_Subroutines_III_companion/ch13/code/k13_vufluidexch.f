      SUBROUTINE VUFLUIDEXCH(
     1 NSTATEV, NFIELDV, NPROPS, STEPTIME, TOTALTIME, DT, JCAVTYPE,
     2 FLUEXCHNAME, EFFAREA, AMPLITUDE, PROPS, LEXCHENV,
     3 PCAVNEW, PCAVOLD, CTEMPNEW, CTEMPOLD, CVOL, CMASS, RMIX,
     4 CPMIX, DCPDTEMP, FIELD, STATEOLD, STATENEW, RMASSRATE,
     5 RENERATE, DMASSRATEDPCAV, DMASSRATEDTEMP, DENERATEDPCAV,
     6 DENERATEDTEMP)
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PROPS(NPROPS), PCAVNEW(2), PCAVOLD(2), CTEMPNEW(2),
     1 CTEMPOLD(2), CVOL(2), CMASS(2), RMIX(2), CPMIX(2), DCPDTEMP(2),
     2 FIELD(NFIELDV), STATEOLD(NSTATEV), STATENEW(NSTATEV),
     3 DMASSRATEDPCAV(2), DMASSRATEDTEMP(2), DENERATEDPCAV(2),
     4 DENERATEDTEMP(2)
      CHARACTER*80 FLUEXCHNAME
!     PROPS: 1 discharge coefficient, 2 offset of absolute zero on the
!     temperature scale (-273.15 for deg C, 0 for K), 3 ambient
!     absolute pressure (MPa), 4 ambient temperature (analysis scale)
      DIMENSION PA(2)
      CD = PROPS(1)
      TZ = PROPS(2)
      RMASSRATE = 0.D0
      RENERATE  = 0.D0
      DO 10 K = 1, 2
         DMASSRATEDPCAV(K) = 0.D0
         DMASSRATEDTEMP(K) = 0.D0
         DENERATEDPCAV(K)  = 0.D0
         DENERATEDTEMP(K)  = 0.D0
   10 CONTINUE
      IF (JCAVTYPE .EQ. 1) RETURN        ! orifice law is for gases
      PA(1) = PCAVNEW(1)
      PA(2) = PCAVNEW(2)
      IF (LEXCHENV .EQ. 1) THEN
         PA(2) = PROPS(3)                ! ambient pressure
         IF (PA(1) .LE. PA(2)) RETURN    ! no inflow from the ambient
      END IF
      IU = 1                             ! upstream cavity
      IF (PA(2) .GT. PA(1)) IU = 2
      ID = 3 - IU
      SG = 3.D0 - 2.D0*IU                ! +1: primary -> secondary
      TU = CTEMPNEW(IU) - TZ             ! absolute upstream temperature
      GAM = CPMIX(IU)/(CPMIX(IU) - RMIX(IU))
      CALL K13_ORIF(PA(IU), TU, PA(ID), CD, EFFAREA, GAM, RMIX(IU),
     1 FM, DFU, DFD, DFT)
      H  = CPMIX(IU)*TU                  ! enthalpy carried by the flow
      DH = CPMIX(IU) + TU*DCPDTEMP(IU)
      RMASSRATE = SG*AMPLITUDE*FM
      RENERATE  = RMASSRATE*H
      DMASSRATEDPCAV(IU) = SG*AMPLITUDE*DFU
      IF (LEXCHENV .EQ. 0) DMASSRATEDPCAV(ID) = SG*AMPLITUDE*DFD
      DMASSRATEDTEMP(IU) = SG*AMPLITUDE*DFT
      DO 20 K = 1, 2
         DENERATEDPCAV(K) = H*DMASSRATEDPCAV(K)
   20 CONTINUE
      DENERATEDTEMP(IU) = H*DMASSRATEDTEMP(IU) + RMASSRATE*DH
      RETURN
      END
