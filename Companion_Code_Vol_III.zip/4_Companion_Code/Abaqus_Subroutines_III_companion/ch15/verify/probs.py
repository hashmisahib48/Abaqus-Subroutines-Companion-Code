import numpy as np
from scipy.special import erf
pi=np.pi
# 15A.2 infinite plate, closed form
C=3.0e-13; m=3.; ds=120.; a0=2.; af=20.
N=(af**(1-m/2)-a0**(1-m/2))/((1-m/2)*C*(ds*np.sqrt(pi))**m); print('15A.2 N',N)
# with Kmax=...? K at af
print('   dK at af',ds*np.sqrt(pi*af), 'dK at a0',ds*np.sqrt(pi*a0))
# 15A.3
R=1.5; s=R/3; Z=2*pi*s**2*(1-np.exp(-R**2/(2*s**2))); print('15A.3 Z',Z,'A',1/Z,'w(0.75)',np.exp(-.5*(.75/s)**2)/Z)
# 15B.3
x=1-1/np.sqrt(10); K=2e4; cm=0.02; CL=x*cm; P=K*CL/(1-x); print('15B.3 CL/CLmax',x,'CL',CL,'P',P)
# 15C.1 MMB B=0.25
Ed=120000.;b=25.;h=1.5;L=50.;Pm=50.;R_=0.1;c=5*L/3
den=16*b**2*h**3*L**2*Ed
kI=12*Pm**2*(3*c-L)**2/den; kII=9*Pm**2*(c+L)**2/den
B=kII/(kI+kII); GC=.28+.51*B**1.45
c3=.5;c4=5.;a0=30.;af=40.
Lm=(1-R_)**2*(kI+kII)/GC
Nm=(a0**(1-2*c4)-af**(1-2*c4))/((2*c4-1)*c3*Lm**c4)
print('15C.1 c',c,'B',B,'GC',GC,'N',Nm,'GT(30)',(kI+kII)*900,'GT(40)',(kI+kII)*1600)
# 15C.2 K2/K1=1
from scipy.integrate import quad
def williams(th,K1,K2):
    cc=np.cos(th/2); s_=np.sin(th/2); c3_=np.cos(1.5*th); s3=np.sin(1.5*th)
    return (K1*cc*(1-s_*s3)-K2*s_*(2+cc*c3_), K1*cc*(1+s_*s3)+K2*s_*cc*c3_, K1*cc*s_*c3_+K2*cc*(1-s_*s3))
def ang(t0,t1,K1,K2):
    a=[quad(lambda t:williams(t,K1,K2)[k],t0,t1,epsabs=1e-13)[0] for k in range(3)]
    g=np.degrees(0.5*np.arctan2(2*a[2],a[0]-a[1]))+90
    return g-180 if g>90 else g
print('15C.2',ang(-pi,pi,1,1),ang(-pi/2,pi/2,1,1),np.degrees(2*np.arctan((1-3)/4)))
