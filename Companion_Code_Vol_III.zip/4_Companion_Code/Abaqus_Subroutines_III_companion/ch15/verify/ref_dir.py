"""Limits of the averaged-stress growth angle (polar quadrature) and closed forms for the weights."""
import numpy as np
from scipy.integrate import quad
from scipy.special import erf
def williams(th,K1,K2):
    c=np.cos(th/2); s=np.sin(th/2); c3=np.cos(1.5*th); s3=np.sin(1.5*th)
    return (K1*c*(1-s*s3)-K2*s*(2+c*c3), K1*c*(1+s*s3)+K2*s*c*c3, K1*c*s*c3+K2*c*(1-s*s3))
K1,K2=1.,.5
def ang(th0,th1):
    a=[quad(lambda t:williams(t,K1,K2)[k],th0,th1,epsabs=1e-13)[0] for k in range(3)]
    phi=0.5*np.arctan2(2*a[2],a[0]-a[1]); g=np.degrees(phi)+90
    return g-180 if g>90 else g
print('full disc limit',ang(-np.pi,np.pi),' half disc limit',ang(-np.pi/2,np.pi/2))
print('MTS',np.degrees(2*np.arctan((K1-np.sqrt(K1**2+8*K2**2))/(4*K2))))
# closed forms <x>half and <x^2>full, R=3
R=3.
s=R/3
def mom(w,k): return quad(lambda r:w(r)*r**k,0,R,epsabs=1e-14,epsrel=1e-14)[0]
W={'top hat':lambda r:1.,'gauss':lambda r:np.exp(-.5*(r/s)**2),'quartic':lambda r:(1-(r/R)**2)**2}
for n,w in W.items():
    xh=(2/np.pi)*mom(w,2)/mom(w,1); x2=0.5*mom(w,3)/mom(w,1)
    print(n,'<x>half',xh,'<x2>full',x2)
# Gaussian closed form check
g2=s**3*(np.sqrt(np.pi/2)*erf(R/(s*np.sqrt(2)))-(R/s)*np.exp(-R**2/(2*s**2))); g1=s**2*(1-np.exp(-R**2/(2*s**2)))
print('gauss closed <x>half',(2/np.pi)*g2/g1)
