"""Independent reference values for the Paris-law examples (closed forms and adaptive quadrature)."""
import numpy as np, json
from scipy.integrate import quad
from scipy.optimize import brentq
pi=np.pi
# plate
E=70000.;S=100.;R=0.1;Wf=100.;Kc=1100.;m=3.
Cmm=5e-11*1000/1000**1.5
ds=(1-R)*S
a0=4.
ac1=(Kc/(S*np.sqrt(pi)))**2
N1=(ac1**(1-m/2)-a0**(1-m/2))/((1-m/2)*Cmm*(ds*np.sqrt(pi))**m)
F=lambda a:np.sqrt(1/np.cos(pi*a/Wf))
K=lambda a:S*np.sqrt(pi*a)*F(a)
ac2=brentq(lambda a:K(a)-Kc,a0,49.99)
integ=lambda a:1/(Cmm*((1-R)*K(a))**m)
N2=quad(integ,a0,ac2,epsabs=1e-6,epsrel=1e-12)[0]
# F=1 quadrature check
N1q=quad(lambda a:1/(Cmm*((1-R)*S*np.sqrt(pi*a))**m),a0,ac1,epsrel=1e-13)[0]
# DCB
Ed=120000.;h=3.;dl=1.;a0d=50.;afd=70.;GIC=.28;c3=.5;c4=5.
k=3*Ed*h**3*dl**2/16
Lam=(1-R)**2*k/GIC
Nd=(afd**(4*c4+1)-a0d**(4*c4+1))/((4*c4+1)*c3*Lam**c4)
Gd0=k/a0d**4
# MMB
b=25.;hm=1.5;L=50.;P=100.
c=L*(1+np.sqrt(3)/2)/(3-np.sqrt(3)/2)
den=16*b**2*hm**3*L**2*Ed
kI=12*P**2*(3*c-L)**2/den; kII=9*P**2*(c+L)**2/den
eta=1.45;GIIC=.79
B=kII/(kI+kII)
GC=GIC+(GIIC-GIC)*B**eta
Lm=(1-R)**2*(kI+kII)/GC
a0m=30.;afm=40.
Nm=(a0m**(1-2*c4)-afm**(1-2*c4))/((2*c4-1)*c3*Lm**c4)
out=dict(N1=N1,N1q=N1q,ac1=ac1,N2=N2,ac2=ac2,Nd=Nd,Gd0=Gd0,Nm=Nm,B=B,GC=GC,c=c,GI30=kI*900,GII30=kII*900,Cmm=Cmm,
         c3p=Cmm*Kc**3,GCp=Kc**2/E,K0=K(a0),dadn0=Cmm*((1-R)*K(a0))**m,GTf=(kI+kII)*afm**2,
         Gmax_d_end=k/afd**4, ratio_d0=Gd0/GIC)
json.dump(out,open('ref_paris.json','w'),indent=1)
for k_,v in out.items(): print(k_,v)
