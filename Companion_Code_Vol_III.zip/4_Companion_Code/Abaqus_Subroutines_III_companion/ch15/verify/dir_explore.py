import numpy as np
def williams(x,y,K1,K2):
    r=np.hypot(x,y); th=np.arctan2(y,x); c=np.cos(th/2); s=np.sin(th/2); c3=np.cos(1.5*th); s3=np.sin(1.5*th)
    f=1/np.sqrt(2*np.pi*r)
    sxx=f*(K1*c*(1-s*s3)-K2*s*(2+c*c3))
    syy=f*(K1*c*(1+s*s3)+K2*s*c*c3)
    sxy=f*(K1*c*s*c3+K2*c*(1-s*s3))
    return sxx,syy,sxy
def growth_angle(sxx,syy,sxy):
    phi=0.5*np.arctan2(2*sxy,sxx-syy)   # direction of max principal stress
    # crack grows perpendicular to the max principal stress direction
    ang=np.degrees(phi)+90
    if ang>90: ang-=180
    return ang
def mts(K1,K2): return np.degrees(2*np.arctan((K1-np.sqrt(K1**2+8*K2**2))/(4*K2)))
K1,K2=1.0,0.5
print('MTS',mts(K1,K2))
R=3.0
for h in [R/3,R/6,R/12,R/24]:
    g=0.5/np.sqrt(3)*h
    pts=[]
    n=int(R/h)+1
    for ie in range(-n,n):
        for je in range(-n,n):
            for ig in (-1,1):
                for jg in (-1,1):
                    x=(ie+.5)*h+ig*g; y=(je+.5)*h+jg*g
                    if np.hypot(x,y)<R: pts.append((x,y))
    pts=np.array(pts); x,y=pts.T
    sxx,syy,sxy=williams(x,y,K1,K2)
    r=np.hypot(x,y)
    res=[]
    for name,mask in [('full',np.ones_like(x,bool)),('half',x>0),('ahead60',np.abs(np.arctan2(y,x))<np.pi/3)]:
        for wn,w in [('uni',np.ones_like(r)),('gauss',np.exp(-0.5*(r/(R/3))**2)),('quart',(1-(r/R)**2)**2)]:
            ww=w*mask
            a=[(ww*q).sum()/ww.sum() for q in (sxx,syy,sxy)]
            res.append((name,wn,round(growth_angle(*a),2)))
    print(round(h/R,4),res)
