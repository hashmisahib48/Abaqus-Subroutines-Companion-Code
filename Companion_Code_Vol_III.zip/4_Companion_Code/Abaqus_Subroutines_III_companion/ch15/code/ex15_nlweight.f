      SUBROUTINE UXFEMNONLOCALWEIGHT(WEIGHT, JELNO, NPT, COORDS,
     1 CRACKTIPCOORD, NNCRD, RADIUS, KSTEP, KINC, TIME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), COORDS(NNCRD), CRACKTIPCOORD(NNCRD)
!
!     Normalised radial weight about the crack tip, Eq. 15.8-2.
!     KTYPE: 1 top hat   2 Gaussian cut at R   3 quartic (1-x**2)**2
!     The weight integrates to one over the disc (NNCRD = 2) or the
!     ball (NNCRD = 3) of radius RADIUS; units 1/mm**NNCRD.
      PARAMETER (KTYPE = 2, SIGR = 1.0D0/3.0D0)
      R2 = 0.0D0
      DO K = 1, NNCRD
         R2 = R2 + (COORDS(K) - CRACKTIPCOORD(K))**2
      ENDDO
      R = SQRT(R2)
      WEIGHT = 0.0D0
      IF (RADIUS .LE. 0.0D0 .OR. R .GE. RADIUS) RETURN
      CALL K15_WSHAPE(KTYPE, R/RADIUS, SIGR, S)
      CALL K15_WNORM(KTYPE, NNCRD, RADIUS, SIGR, ZNORM)
      WEIGHT = S/ZNORM
      RETURN
      END
!
      SUBROUTINE K15_WSHAPE(KTYPE, X, SIGR, S)
!     unnormalised shape on 0 <= X = r/R < 1
      INCLUDE 'ABA_PARAM.INC'
      IF (KTYPE .EQ. 1) THEN
         S = 1.0D0
      ELSEIF (KTYPE .EQ. 2) THEN
         S = EXP(-0.5D0*(X/SIGR)**2)
      ELSE
         S = (1.0D0 - X*X)**2
      ENDIF
      RETURN
      END
!
      SUBROUTINE K15_WNORM(KTYPE, ND, RAD, SIGR, ZNORM)
!     integral of the shape over the disc / ball of radius RAD
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0)
      S = SIGR*RAD
      E = EXP(-0.5D0*(RAD/S)**2)
      IF (ND .EQ. 2) THEN
         IF (KTYPE .EQ. 1) ZNORM = PI*RAD**2
         IF (KTYPE .EQ. 2) ZNORM = 2.0D0*PI*S**2*(1.0D0 - E)
         IF (KTYPE .EQ. 3) ZNORM = PI*RAD**2/3.0D0
      ELSE
         IF (KTYPE .EQ. 1) ZNORM = 4.0D0*PI*RAD**3/3.0D0
         IF (KTYPE .EQ. 2) ZNORM = 4.0D0*PI*(S**3*SQRT(PI/2.0D0)*
     1      ERF(RAD/(S*SQRT(2.0D0))) - S**2*RAD*E)
         IF (KTYPE .EQ. 3) ZNORM = 32.0D0*PI*RAD**3/105.0D0
      ENDIF
      RETURN
      END
