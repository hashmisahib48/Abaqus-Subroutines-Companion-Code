      PROGRAM DRV15PARIS
!     Crack-growth driver: calls UMIXMODEFATIGUE (G form) the way a
!     growth increment would and integrates the life, N = sum da/(da/dN).
!     ICASE 1 centre crack, F = 1;  2 centre crack, Feddersen secant;
!           3 DCB, displacement control;  4 MMB, load control (B = 0.5)
!     Units N, mm, MPa.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0)
      DIMENSION PROPS(8), ST(1), PRE(1), DPR(1), IA(1), RA(1), CA(1)
      DIMENSION DAV(6)
      DATA DAV /2.0D0, 1.0D0, 0.5D0, 0.25D0, 0.125D0, 1.0D-3/
      COMMON /CASE/ ICASE
      COMMON /PLATE/ SMAX, RR, E, WF
      COMMON /BEAM/ H, DEL, PM, BW, XL, XC
      ST(1) = 0.0D0
      PRE(1) = 0.0D0
      DPR(1) = 0.0D0
      IA(1) = 0
      RA(1) = 0.0D0
      CA(1) = 0.0D0
      ZERO = 0.0D0
!     --- plate: aluminium-type alloy -------------------------------
      E    = 70000.0D0
      SMAX = 100.0D0
      RR   = 0.1D0
      WF   = 100.0D0
      XKC  = 1100.0D0
      CMM  = 5.0D-11*1000.0D0/1000.0D0**1.5D0
      A0P  = 4.0D0
      GCP  = XKC**2/E
!     --- delamination: carbon/epoxy -------------------------------
      H    = 3.0D0
      DEL  = 1.0D0
      PM   = 100.0D0
      BW   = 25.0D0
      XL   = 50.0D0
      XC   = XL*(1.0D0 + SQRT(3.0D0)/2.0D0)/(3.0D0 - SQRT(3.0D0)/2.0D0)
      DO ICASE = 1, 4
         IF (ICASE .LE. 2) THEN
            E = 70000.0D0
            PROPS(1) = CMM*XKC**3
            PROPS(2) = 1.5D0
            PROPS(3) = 0.01D0
            PROPS(4) = GCP
            PROPS(5) = 2.0D0*GCP
            PROPS(6) = 2.0D0*GCP
            PROPS(7) = 1.0D0
            PROPS(8) = 0.0D0
            A0 = A0P
            IF (ICASE .EQ. 1) AEND = (XKC/(SMAX*SQRT(PI)))**2
            IF (ICASE .EQ. 2) THEN
               AL = A0
               AH = 0.4999D0*WF
               DO IT = 1, 200
                  AM = 0.5D0*(AL + AH)
                  CALL K15_GS(AM, G1, G2, G3, GN1, GN2, GN3)
                  IF (G1 .GT. GCP) THEN
                     AH = AM
                  ELSE
                     AL = AM
                  ENDIF
               ENDDO
               AEND = AM
            ENDIF
         ELSE
            E = 120000.0D0
            PROPS(1) = 0.5D0
            PROPS(2) = 5.0D0
            PROPS(3) = 0.01D0
            PROPS(4) = 0.28D0
            PROPS(5) = 0.79D0
            PROPS(6) = 1.20D0
            PROPS(7) = 1.45D0
            PROPS(8) = 0.0D0
            IF (ICASE .EQ. 3) THEN
               H = 3.0D0
               A0 = 50.0D0
               AEND = 70.0D0
            ELSE
               H = 1.5D0
               A0 = 30.0D0
               AEND = 40.0D0
            ENDIF
         ENDIF
         WRITE(*,'(A,I2,A,F9.4,A,F9.4)') '# case', ICASE, '  a0',
     1    A0, '  aend', AEND
         DO KD = 1, 6
            DA0 = DAV(KD)
            XNL = 0.0D0
            XNT = 0.0D0
            A = A0
            CALL K15_RATE(A, PROPS, R1)
            DO WHILE (A .LT. AEND - 1.0D-12)
               DA1 = MIN(DA0, AEND - A)
               CALL K15_RATE(A + DA1, PROPS, R2)
               XNL = XNL + DA1/R1
               XNT = XNT + 0.5D0*DA1*(1.0D0/R1 + 1.0D0/R2)
               A = A + DA1
               R1 = R2
            ENDDO
            WRITE(*,'(I3,F9.4,2ES18.9)') ICASE, DA0, XNL, XNT
         ENDDO
      ENDDO
      END
!
      SUBROUTINE K15_GS(A, G1, G2, G3, GN1, GN2, GN3)
!     G components at maximum (G1,G2,G3) and minimum (GN1..) load
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0)
      COMMON /CASE/ ICASE
      COMMON /PLATE/ SMAX, RR, E, WF
      COMMON /BEAM/ H, DEL, PM, BW, XL, XC
      G2 = 0.0D0
      G3 = 0.0D0
      IF (ICASE .LE. 2) THEN
         F2 = 1.0D0
         IF (ICASE .EQ. 2) F2 = 1.0D0/COS(PI*A/WF)
         G1 = SMAX**2*PI*A*F2/E
      ELSEIF (ICASE .EQ. 3) THEN
         G1 = 3.0D0*E*H**3*DEL**2/(16.0D0*A**4)
      ELSE
         DENOM = 16.0D0*BW**2*H**3*XL**2*E
         G1 = 12.0D0*PM**2*(3.0D0*XC - XL)**2*A**2/DENOM
         G2 = 9.0D0*PM**2*(XC + XL)**2*A**2/DENOM
      ENDIF
      GN1 = RR**2*G1
      GN2 = RR**2*G2
      GN3 = 0.0D0
      RETURN
      END
!
      SUBROUTINE K15_RATE(A, PROPS, RATE)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(8), ST(1), PRE(1), DPR(1), IA(1), RA(1), CA(1)
      CALL K15_GS(A, G1, G2, G3, GN1, GN2, GN3)
      ST(1) = 0.0D0
      PRE(1) = 0.0D0
      DPR(1) = 0.0D0
      IA(1) = 0
      RA(1) = 0.0D0
      CA(1) = 0.0D0
      CALL UMIXMODEFATIGUE(RATE, G1, G2, G3, GN1, GN2, GN3, 20.0D0,
     1 0.0D0, PRE, DPR, 0, 8, PROPS, 1, ST, 1, IA, 1, RA, 1, CA, 0.0D0)
      RETURN
      END
