      SUBROUTINE UMIXMODEFATIGUE(DADN, GI_MAX, GII_MAX, GIII_MAX,
     1 GI_MIN, GII_MIN, GIII_MIN, TEMP, DTEMP, PREDEF, DPRED,
     2 NFIELD, NPROPS, PROPS, NSTATV, STATEV,
     3 NIARRAY, I_ARRAY, NRARRAY, R_ARRAY, NCARRAY, C_ARRAY, DA)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION PROPS(NPROPS), STATEV(NSTATV), PREDEF(NFIELD),
     1 DPRED(NFIELD), I_ARRAY(NIARRAY), R_ARRAY(NRARRAY),
     2 C_ARRAY(NCARRAY)
!
!     Mixed-mode Paris law, G-based form:
!        DADN = C3 * (DG/GC(B))**C4   for GMAX >= GTH*GC, else 0
!     PROPS: 1 C3 (mm/cycle)   2 C4 (-)   3 GTH/GC (-)
!            4 GIC, 5 GIIC, 6 GIIIC (N/mm)   7 ETA (-)
!            8 IREED (0 Benzeggagh-Kenane, 1 Reeder)
!     G in N/mm; DADN in mm/cycle
      IF (NPROPS .LT. 8) THEN
         WRITE(7,*) 'UMIXMODEFATIGUE: eight constants are required'
         CALL XIT
      ENDIF
      C3   = PROPS(1)
      C4   = PROPS(2)
      GTH  = PROPS(3)
      IREED = NINT(PROPS(8))
!
!     critical equivalent G for the mode mix at maximum load
      CALL K15_GC(GI_MAX, GII_MAX, GIII_MAX, PROPS(4), PROPS(5),
     1 PROPS(6), PROPS(7), IREED, GC, DGCDB, DGCDE, BMIX, XI)
!
!     totals at maximum and minimum load, and the range
      GTMAX = GI_MAX + GII_MAX + GIII_MAX
      GTMIN = GI_MIN + GII_MIN + GIII_MIN
      DG = (SQRT(MAX(GTMAX,0.0D0)) - SQRT(MAX(GTMIN,0.0D0)))**2
!
      DADN = 0.0D0
      IF (GTMAX .GE. GTH*GC .AND. DG .GT. 0.0D0) THEN
         DADN = C3*MIN(DG/GC, 1.0D0)**C4
      ENDIF
      RETURN
      END
!
      SUBROUTINE K15_GC(G1, G2, G3, GIC, GIIC, GIIIC, ETA, IREED,
     1 GC, DGCDB, DGCDE, BMIX, XI)
!     Critical equivalent energy release rate (N/mm), Eq. 15.3-2:
!     BK (IREED = 0) or Reeder (IREED = 1); also dGC/dB and dGC/dETA
      INCLUDE 'ABA_PARAM.INC'
      GT = G1 + G2 + G3
      GS = G2 + G3
      BMIX = 0.0D0
      XI   = 0.0D0
      IF (GT .GT. 0.0D0) BMIX = GS/GT
      IF (GS .GT. 0.0D0) XI = G3/GS
      A = GIIC - GIC
      IF (IREED .EQ. 1) A = A + (GIIIC - GIIC)*XI
      GC = GIC
      DGCDB = 0.0D0
      DGCDE = 0.0D0
      IF (BMIX .GT. 0.0D0) THEN
         BE = BMIX**ETA
         GC = GIC + A*BE
         DGCDB = A*ETA*BMIX**(ETA - 1.0D0)
         DGCDE = A*BE*LOG(BMIX)
      ENDIF
      RETURN
      END
