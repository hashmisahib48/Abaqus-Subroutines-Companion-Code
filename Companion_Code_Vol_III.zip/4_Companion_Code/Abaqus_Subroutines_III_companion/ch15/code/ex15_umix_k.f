      SUBROUTINE UMIXMODEFATIGUE(DADN, KI_MAX, KII_MAX, KIII_MAX,
     1 KI_MIN, KII_MIN, KIII_MIN, TEMP, DTEMP, PREDEF, DPRED,
     2 NFIELD, NPROPS, PROPS, NSTATV, STATEV,
     3 NIARRAY, I_ARRAY, NRARRAY, R_ARRAY, NCARRAY, C_ARRAY, DA)
!
      INCLUDE 'ABA_PARAM.INC'
!
!     K*_MAX / K*_MIN begin with K: integers under ABA_PARAM.INC
      REAL*8 KI_MAX, KII_MAX, KIII_MAX, KI_MIN, KII_MIN, KIII_MIN
      DIMENSION PROPS(NPROPS), STATEV(NSTATV), PREDEF(NFIELD),
     1 DPRED(NFIELD), I_ARRAY(NIARRAY), R_ARRAY(NRARRAY),
     2 C_ARRAY(NCARRAY)
!
!     Stress-intensity-factor form (MIXED MODE BEHAVIOR=USER, K-BASED):
!        DADN = C * DKEFF**M   for DKEFF > DKTH, else 0
!        DKEFF**2 = DKI**2 + DKII**2 + DKIII**2/(1 - NU)  (Irwin)
!     PROPS: 1 C ((mm/cycle)/(MPa*sqrt(mm))**M)  2 M (-)
!            3 DKTH (MPa*sqrt(mm))  4 NU (-)
      C   = PROPS(1)
      XM  = PROPS(2)
      DKTH = PROPS(3)
      XNU = PROPS(4)
      DKI   = KI_MAX   - KI_MIN
      DKII  = KII_MAX  - KII_MIN
      DKIII = KIII_MAX - KIII_MIN
      DKEFF = SQRT(DKI**2 + DKII**2 + DKIII**2/(1.0D0 - XNU))
      DADN = 0.0D0
      IF (DKEFF .GT. DKTH) DADN = C*DKEFF**XM
      RETURN
      END
