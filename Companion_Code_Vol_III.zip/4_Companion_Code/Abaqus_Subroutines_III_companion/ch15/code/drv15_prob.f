      PROGRAM DRV15PROB
!     Numbers for Problems 15A.1, 15B.1 and 15B.2 (N, mm)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION P(8), ST(1), PRE(1), DPR(1), IA(1), RA(1), CA(1)
      ST = 0.0D0
      PRE = 0.0D0
      DPR = 0.0D0
      IA = 0
      RA = 0.0D0
      CA = 0.0D0
!     15A.1: GIC 0.30, GIIC 0.90, eta 2.0, GI = 0.12, GII = 0.18
      P = (/0.2D0, 6.0D0, 0.01D0, 0.30D0, 0.90D0, 0.90D0, 2.0D0, 0.0D0/)
      G1 = 0.12D0
      G2 = 0.18D0
      CALL K15_GC(G1, G2, 0.0D0, 0.30D0, 0.90D0, 0.90D0, 2.0D0, 0, GC,
     1 DB, DE, BM, XI)
      WRITE(*,'(A,4F12.6)') '15A.1 B, GC, GT/GC, dGC/dB ', BM, GC,
     1 (G1+G2)/GC, DB
      CALL UMIXMODEFATIGUE(RATE, G1, G2, 0.0D0, 0.01D0*G1, 0.01D0*G2,
     1 0.0D0, 20.0D0, 0.0D0, PRE, DPR, 0, 8, P, 1, ST, 1, IA, 1, RA,
     2 1, CA, 0.0D0)
      WRITE(*,'(A,ES14.6)') '15A.1 da/dN (R = 0.1) ', RATE
!     15B.1: BK at B = 0.5, eta = 1.45, GIC 0.28, GIIC 0.79
      CALL K15_GC(0.5D0, 0.5D0, 0.0D0, 0.28D0, 0.79D0, 0.79D0, 1.45D0,
     1 0, GC, DB, DE, BM, XI)
      WRITE(*,'(A,3F12.6)') '15B.1 GC, dGC/dB, dGC/dETA ', GC, DB, DE
      END
