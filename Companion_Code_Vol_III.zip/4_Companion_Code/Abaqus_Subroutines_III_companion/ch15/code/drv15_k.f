      PROGRAM DRV15K
!     Same centre-cracked plate through the G-based (argument G) or the
!     K-based (argument K) UMIXMODEFATIGUE: da/dN at three crack lengths
!     and the life by trapezoidal integration (da = 1.0E-3 mm).
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0)
      CHARACTER*1 MODE
      DIMENSION PROPS(8), ST(1), PRE(1), DPR(1), IA(1), RA(1), CA(1)
      DIMENSION AV(3)
      DATA AV /4.0D0, 10.0D0, 20.0D0/
      CALL GET_COMMAND_ARGUMENT(1, MODE)
      E = 70000.0D0
      SMAX = 100.0D0
      RR = 0.1D0
      WF = 100.0D0
      XKC = 1100.0D0
      CMM = 5.0D-11*1000.0D0/1000.0D0**1.5D0
      GCP = XKC**2/E
      ST(1) = 0.0D0
      PRE(1) = 0.0D0
      DPR(1) = 0.0D0
      IA(1) = 0
      RA(1) = 0.0D0
      CA(1) = 0.0D0
      IF (MODE .EQ. 'G') THEN
         PROPS = (/CMM*XKC**3, 1.5D0, 0.01D0, GCP, 2*GCP, 2*GCP,
     1    1.0D0, 0.0D0/)
      ELSE
         PROPS = (/CMM, 3.0D0, 0.0D0, 0.33D0, 0.0D0, 0.0D0, 0.0D0,
     1    0.0D0/)
      ENDIF
      A = 4.0D0
      AEND = 26.19403431860068D0
      DAS = 1.0D-3
      XN = 0.0D0
      CALL RATE(A, R1)
      DO WHILE (A .LT. AEND - 1.0D-12)
         DA1 = MIN(DAS, AEND - A)
         CALL RATE(A + DA1, R2)
         XN = XN + 0.5D0*DA1*(1.0D0/R1 + 1.0D0/R2)
         A = A + DA1
         R1 = R2
      ENDDO
      DO K = 1, 3
         CALL RATE(AV(K), R1)
         WRITE(*,'(A,F6.1,ES16.8)') 'a, da/dN ', AV(K), R1
      ENDDO
      WRITE(*,'(A,ES16.8)') 'N ', XN
      CONTAINS
      SUBROUTINE RATE(A, RT)
      FS = SQRT(1.0D0/COS(PI*A/WF))
      XK = SMAX*SQRT(PI*A)*FS
      IF (MODE .EQ. 'G') THEN
         G = XK**2/E
         CALL UMIXMODEFATIGUE(RT, G, 0.0D0, 0.0D0, RR**2*G, 0.0D0,
     1    0.0D0, 20.0D0, 0.0D0, PRE, DPR, 0, 8, PROPS, 1, ST, 1, IA,
     2    1, RA, 1, CA, 0.0D0)
      ELSE
         CALL UMIXMODEFATIGUE(RT, XK, 0.0D0, 0.0D0, RR*XK, 0.0D0,
     1    0.0D0, 20.0D0, 0.0D0, PRE, DPR, 0, 4, PROPS, 1, ST, 1, IA,
     2    1, RA, 1, CA, 0.0D0)
      ENDIF
      END SUBROUTINE
      END
