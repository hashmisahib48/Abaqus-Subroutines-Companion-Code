      PROGRAM DRV15BUG
!     Problem 15B.2: the faulty routine with the data of 15A.1.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION P6(6), ST(1), PRE(1), DPR(1), IA(1), RA(1), CA(1)
      ST = 0.0D0
      PRE = 0.0D0
      DPR = 0.0D0
      IA = 0
      RA = 0.0D0
      CA = 0.0D0
      P6 = (/0.2D0, 6.0D0, 0.01D0, 0.30D0, 0.90D0, 2.0D0/)
      G1 = 0.12D0
      G2 = 0.18D0
      RATE = 7.7D7
      CALL UMIXMODEFATIGUE(RATE, G1, G2, 0.0D0, 0.01D0*G1, 0.01D0*G2,
     1 0.0D0, 20.0D0, 0.0D0, PRE, DPR, 0, 6, P6, 1, ST, 1, IA, 1, RA,
     2 1, CA, 0.0D0)
      WRITE(*,'(A,ES14.6)') '15B.2 da/dN (faulty routine) ', RATE
      RATE = 7.7D7
      CALL UMIXMODEFATIGUE(RATE, 1.0D-6, 0.0D0, 0.0D0, 0.0D0, 0.0D0,
     1 0.0D0, 20.0D0, 0.0D0, PRE, DPR, 0, 6, P6, 1, ST, 1, IA, 1, RA,
     2 1, CA, 0.0D0)
      WRITE(*,'(A,ES14.6)') '15B.2 below threshold, DADN left as ',RATE
      END
