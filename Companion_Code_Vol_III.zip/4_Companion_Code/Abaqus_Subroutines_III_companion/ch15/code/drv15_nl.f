      PROGRAM DRV15NL
!     Example 15.7-1: weight normalisation and nonlocal averages.
!     Calls UXFEMNONLOCALWEIGHT exactly as Abaqus would (one
!     integration point at a time).  Units mm.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0)
      DIMENSION X(3), TIP(3), TIM(2)
      TIP = 0.0D0
      TIM = 0.0D0
!     --- (a) integral of the weight, polar / spherical midpoint rule
      DO IR = 1, 2
         RAD = 3.0D0
         IF (IR .EQ. 2) RAD = 7.5D0
         NR = 800
         NT = 400
         S2 = 0.0D0
         DO I = 1, NR
            R = (DBLE(I) - 0.5D0)*RAD/NR
            DO J = 1, NT
               T = (DBLE(J) - 0.5D0)*2.0D0*PI/NT
               X(1) = R*COS(T)
               X(2) = R*SIN(T)
               CALL UXFEMNONLOCALWEIGHT(W, 1, 1, X, TIP, 2, RAD, 1, 1,
     1          TIM)
               S2 = S2 + W*R*(RAD/NR)*(2.0D0*PI/NT)
            ENDDO
         ENDDO
         S3 = 0.0D0
         NP = 400
         DO I = 1, NR
            R = (DBLE(I) - 0.5D0)*RAD/NR
            DO J = 1, NP
               TH = (DBLE(J) - 0.5D0)*PI/NP
               X(1) = R*SIN(TH)
               X(2) = 0.0D0
               X(3) = R*COS(TH)
               CALL UXFEMNONLOCALWEIGHT(W, 1, 1, X, TIP, 3, RAD, 1, 1,
     1          TIM)
               S3 = S3 + W*2.0D0*PI*R*R*SIN(TH)*(RAD/NR)*(PI/NP)
            ENDDO
         ENDDO
         WRITE(*,'(A,F5.2,2F14.10)') 'R, int w dA (2D), dV (3D) ',
     1    RAD, S2, S3
      ENDDO
!     --- (b) structured mesh, 2x2 Gauss points per square element,
!         tip at a node; half disc ahead (x > 0) and full disc
      RAD = 3.0D0
      WRITE(*,'(A)') '# h/R   sum(wV)full  sum(wV)half   <x>half'//
     1 '    <x**2>full'
      DO IH = 1, 4
         H = RAD/(3.0D0*2.0D0**(IH-1))
         NE = INT(RAD/H) + 1
         GP = H*0.5D0/SQRT(3.0D0)
         V = H*H/4.0D0
         SF = 0.0D0
         SHA = 0.0D0
         SX = 0.0D0
         SXX = 0.0D0
         DO IE = -NE, NE-1
            DO JE = -NE, NE-1
               DO IG = 1, 2
                  DO JG = 1, 2
                     X(1) = (DBLE(IE) + 0.5D0)*H + (2*IG-3)*GP
                     X(2) = (DBLE(JE) + 0.5D0)*H + (2*JG-3)*GP
                     CALL UXFEMNONLOCALWEIGHT(W, 1, 1, X, TIP, 2, RAD,
     1                1, 1, TIM)
                     SF = SF + W*V
                     SXX = SXX + W*V*X(1)**2
                     IF (X(1) .GT. 0.0D0) THEN
                        SHA = SHA + W*V
                        SX = SX + W*V*X(1)
                     ENDIF
                  ENDDO
               ENDDO
            ENDDO
         ENDDO
         WRITE(*,'(F7.4,2F13.8,2F13.8)') H/RAD, SF, SHA, SX/SHA, SXX/SF
      ENDDO
      END
