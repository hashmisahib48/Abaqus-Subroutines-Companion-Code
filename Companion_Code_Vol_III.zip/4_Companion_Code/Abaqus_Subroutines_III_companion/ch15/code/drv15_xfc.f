      PROGRAM DRV15XFC
!     Example 15.6-1: UXFEMCRACK driven through an opening history
!     (units N, mm, MPa).  The driver keeps OPENMAX and OFFSETOLD as
!     Abaqus would, compares the traction with the closed-form inverse
!     of the hyperbolic law and the stiffness with finite differences,
!     and writes the loop (unit 20) for the figure.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NH = 9, NSUB = 40)
      DIMENSION PROPS(4), DTAB(NH), SNEW(3), SNEW2(3), STIF(3,3)
      DIMENSION DTB(5)
      DATA DTB /0.003D0, 0.002D0, 0.0D0, -0.0015D0, -0.003D0/
      DATA DTAB /0.0D0, 0.04D0, -0.003D0, 0.04D0, -0.003D0,
     1  0.025D0, 0.0D0, 0.04D0, -0.003D0/
      PROPS = (/2.0D4, 0.02D0, 0.1D0, 0.003D0/)
      XKN   = PROPS(1)
      CLMAX = PROPS(2)
      HMAX  = PROPS(4)
      OPENMAX = 0.0D0
      OFFOLD  = 0.0D0
      ERRI = 0.0D0
      ERRK = 0.0D0
      PMAX = 0.0D0
      OPEN(20, FILE='out_xfc_loop.dat')
      DO I = 2, NH
         DO J = 1, NSUB
            DELT = DTAB(I-1) + (DTAB(I) - DTAB(I-1))*DBLE(J)/NSUB
            OPENMAX = MAX(OPENMAX, DELT)
            CALL CALLX(OFFOLD, OFFNEW, DELT, OPENMAX, PROPS, SNEW, STIF)
!           closed-form checks (offset as computed by the model)
            HH = MAX(OFFOLD, MIN(PROPS(3)*OPENMAX, HMAX))
            CL = HH - DELT
            IF (CL .GT. 0.0D0) THEN
               P = -SNEW(1)
               PMAX = MAX(PMAX, P)
               ERRI = MAX(ERRI, ABS(P/(XKN + P/CLMAX) - CL))
               EPS = 1.0D-7
               CALL CALLX(OFFOLD, O2, DELT+EPS, OPENMAX, PROPS, SNEW2,
     1          STIF)
               CALL CALLX(OFFOLD, O2, DELT-EPS, OPENMAX, PROPS, SNEW,
     1          STIF)
               FD = (SNEW2(1) - SNEW(1))/(2.0D0*EPS)
               CALL CALLX(OFFOLD, O2, DELT, OPENMAX, PROPS, SNEW, STIF)
               ERRK = MAX(ERRK, ABS(FD - STIF(1,1))/STIF(1,1))
            ENDIF
            OFFOLD = OFFNEW
            WRITE(20,'(I3,4ES14.6)') I, DELT, OFFNEW, SNEW(1),STIF(1,1)
         ENDDO
      ENDDO
      CLOSE(20)
!     table of the response at the fully developed offset (Table 15.7)
      DO I = 1, 5
         DELT = DTB(I)
         CALL CALLX(0.003D0, O2, DELT, 0.04D0, PROPS, SNEW, STIF)
         WRITE(*,'(A,F8.4,2F12.4,F12.1)') 'tab ', DELT*1000.0D0,
     1    (O2-DELT)*1000.0D0, -SNEW(1), STIF(1,1)
      ENDDO
      WRITE(*,'(A,ES10.3)') 'max |closure(P) - closure| (mm)  ', ERRI
      WRITE(*,'(A,ES10.3)') 'max relative stiffness FD error ', ERRK
      WRITE(*,'(A,F10.3)')  'largest contact pressure (MPa)   ', PMAX
      WRITE(*,'(A,F10.6)')  'final offset (mm)                ', OFFOLD
      END
!
      SUBROUTINE CALLX(OFFOLD, OFFNEW, DELT, OPENMAX, PROPS, SNEW, STIF)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(4), SNEW(3), STIF(3,3), SOLD(3), DELTA(3)
      DIMENSION COORDS(3), TIME1(2), TEMP(1), PREDEF(1), DPRED(1)
      DIMENSION STATEV(1), JMAC(1), JMATYP(1), IA(1), RA(1), CA(1)
      DELTA = 0.0D0
      DELTA(1) = DELT
      SOLD = 0.0D0
      SNEW = 0.0D0
      STIF = 0.0D0
      COORDS = 0.0D0
      TIME1 = 0.0D0
      TEMP = 20.0D0
      PREDEF = 0.0D0
      DPRED = 0.0D0
      STATEV = 0.0D0
      JMAC = 0
      JMATYP = 0
      IA = 0
      RA = 0.0D0
      CALL UXFEMCRACK(OFFOLD, OFFNEW, DELTA, OPENMAX, 1, 1, COORDS,
     1 1, 1, TIME1, 1.0D0, TEMP, TEMP, PREDEF, DPRED, 0, STATEV, 1,
     2 PROPS, 4, JMAC, JMATYP, 1, 1, 0.0D0, 0.0D0, 0.0D0, SOLD, SNEW,
     3 STIF, 0.0D0, 0.0D0, JFLG, 6, 3, 3, 3, 1, IA, 1, RA, 1, CA)
      RETURN
      END
