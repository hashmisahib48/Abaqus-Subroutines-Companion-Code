      PROGRAM DRV15MIX
!     Example 15.3-1: critical equivalent G (BK, Reeder), analytic
!     derivatives against central finite differences.  N, mm.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (GIC = 0.28D0, GIIC = 0.79D0, GIIIC = 1.20D0)
      PARAMETER (ETA = 1.45D0, H = 1.0D-6)
      DIMENSION BV(7)
      DATA BV /0.0D0, 0.1D0, 0.25D0, 0.5D0, 0.75D0, 0.9D0, 1.0D0/
      WRITE(*,'(A)') '# B  GC_BK  GC_REE(xi=0.5)  dGC/dB(Reeder) FD  err'//
     1 '  dGC/dETA(Reeder) FD err'
      ERRMAX = 0.0D0
      DO K = 1, 7
         B = BV(K)
!        modes: G1 = 1-B, G2 = B/2, G3 = B/2 (xi = 0.5), total 1
         G1 = 1.0D0 - B
         G2 = 0.5D0*B
         G3 = 0.5D0*B
         CALL K15_GC(G1,G2,G3,GIC,GIIC,GIIIC,ETA,0,GCBK,DB,DE,BM,XI)
         CALL K15_GC(G1,G2,G3,GIC,GIIC,GIIIC,ETA,1,GCRE,DBR,DER,BM,XI)
         IF (B .GT. 0.0D0 .AND. B .LT. 1.0D0) THEN
!           central differences in B (total fixed at 1, xi fixed)
            BP = B + H
            BM2 = B - H
            CALL K15_GC(1-BP,0.5D0*BP,0.5D0*BP,GIC,GIIC,GIIIC,ETA,1,
     1       GP,D1,D2,BM,XI)
            CALL K15_GC(1-BM2,0.5D0*BM2,0.5D0*BM2,GIC,GIIC,GIIIC,ETA,1,
     1       GM,D1,D2,BM,XI)
            FDB = (GP - GM)/(2.0D0*H)
            CALL K15_GC(G1,G2,G3,GIC,GIIC,GIIIC,ETA+H,1,GP,D1,D2,BM,XI)
            CALL K15_GC(G1,G2,G3,GIC,GIIC,GIIIC,ETA-H,1,GM,D1,D2,BM,XI)
            FDE = (GP - GM)/(2.0D0*H)
            E1 = ABS(FDB - DBR)/ABS(DBR)
            E2 = ABS(FDE - DER)/ABS(DER)
            ERRMAX = MAX(ERRMAX, E1, E2)
            WRITE(*,'(F5.2,2F9.5,2F11.6,ES10.2,2F11.6,ES10.2)')
     1       B, GCBK, GCRE, DBR, FDB, E1, DER, FDE, E2
         ELSE
            WRITE(*,'(F5.2,2F9.5)') B, GCBK, GCRE
         ENDIF
      ENDDO
      WRITE(*,'(A,ES10.2)') '# max relative derivative error ', ERRMAX
!     Reeder with GIIIC = GIIC must equal BK
      CALL K15_GC(0.3D0,0.3D0,0.4D0,GIC,GIIC,GIIC,ETA,0,A,D1,D2,BM,XI)
      CALL K15_GC(0.3D0,0.3D0,0.4D0,GIC,GIIC,GIIC,ETA,1,B2,D1,D2,BM,XI)
      WRITE(*,'(A,2F12.8)') '# BK, Reeder (GIIIC=GIIC): ', A, B2
      END
