      PROGRAM DRV15DIR
!     Example 15.8-2: crack-growth direction from the nonlocal average
!     of the mixed-mode Williams stress field (KI = 1, KII = 0.5, plane
!     stress units arbitrary), weights from UXFEMNONLOCALWEIGHT.
!     The tip is at a node of a square mesh of 2x2-point elements.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0, XK1 = 1.0D0, XK2 = 0.5D0)
      DIMENSION X(3), TIP(3), TIM(2)
      TIP = 0.0D0
      TIM = 0.0D0
      RAD = 3.0D0
      WRITE(*,'(A)') '# h/R  growth angle (deg): full disc, half disc'
      DO IH = 1, 5
         H = RAD/(3.0D0*2.0D0**(IH-1))
         NE = INT(RAD/H) + 1
         GP = H*0.5D0/SQRT(3.0D0)
         DO IW = 1, 2
            SXX = 0.0D0
            SYY = 0.0D0
            SXY = 0.0D0
            SW = 0.0D0
            DO IE = -NE, NE-1
               DO JE = -NE, NE-1
                  DO IG = 1, 2
                     DO JG = 1, 2
                        X(1) = (DBLE(IE)+0.5D0)*H + (2*IG-3)*GP
                        X(2) = (DBLE(JE)+0.5D0)*H + (2*JG-3)*GP
                        IF (IW .EQ. 2 .AND. X(1) .LE. 0.0D0) CYCLE
                        CALL UXFEMNONLOCALWEIGHT(W, 1, 1, X, TIP, 2,
     1                   RAD, 1, 1, TIM)
                        R  = SQRT(X(1)**2 + X(2)**2)
                        TH = ATAN2(X(2), X(1))
                        F  = 1.0D0/SQRT(2.0D0*PI*R)
                        C  = COS(TH/2)
                        S  = SIN(TH/2)
                        C3 = COS(1.5D0*TH)
                        S3 = SIN(1.5D0*TH)
                        TXX = F*(XK1*C*(1-S*S3) - XK2*S*(2+C*C3))
                        TYY = F*(XK1*C*(1+S*S3) + XK2*S*C*C3)
                        TXY = F*(XK1*C*S*C3 + XK2*C*(1-S*S3))
                        SXX = SXX + W*TXX
                        SYY = SYY + W*TYY
                        SXY = SXY + W*TXY
                        SW  = SW + W
                     ENDDO
                  ENDDO
               ENDDO
            ENDDO
            SXX = SXX/SW
            SYY = SYY/SW
            SXY = SXY/SW
            PHI = 0.5D0*ATAN2(2.0D0*SXY, SXX - SYY)*180.0D0/PI
            ANG = PHI + 90.0D0
            IF (ANG .GT. 90.0D0) ANG = ANG - 180.0D0
            IF (IW .EQ. 1) ANG1 = ANG
            IF (IW .EQ. 2) ANG2 = ANG
         ENDDO
         WRITE(*,'(F7.4,2F10.3)') H/RAD, ANG1, ANG2
      ENDDO
      TH0 = 2.0D0*ATAN((XK1 - SQRT(XK1**2 + 8.0D0*XK2**2))/
     1 (4.0D0*XK2))*180.0D0/PI
      WRITE(*,'(A,F10.3)') '# maximum tangential stress (Erdogan-Sih)',
     1 TH0
      END
