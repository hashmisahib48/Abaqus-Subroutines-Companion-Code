import numpy as np, mpmath as mp
from scipy.optimize import brentq
MU0=4e-7*np.pi
def fabry(z,a,b,h,J0):
    c=h/2; zp=z+c; zm=z-c
    f=lambda zz: zz*np.log((b+np.hypot(b,zz))/(a+np.hypot(a,zz)))
    return 0.5*MU0*J0*(f(zp)-f(zm))
# 9A.1
a,b,h,N,I=20.,35.,30.,150,4.
J0=N*I/((b-a)*h); m=np.pi*N*I*(a*a+a*b+b*b)/3
print('9A.1 J0',J0,'m',m,'Bc [mT]',fabry(0,a,b,h,J0)*1e6,'  thin-loop mu0 N I/(2 Rmean) [mT]',MU0*N*I/(2*(a+b)/2)*1e6)
# 9A.2
K=0.05/MU0/1000; print('9A.2 K [A/mm]',K,'turns/mm at 10 A',K/10,'L=3R centre factor',3/np.sqrt(10))
# 9A.3
ph=np.radians(-40); print('9A.3 re,im',20*np.cos(ph),20*np.sin(ph),'i(0.1ms)',20*np.cos(2*np.pi*1e3*1e-4+ph))
for f in (50,400):
    d=np.sqrt(2/(2*np.pi*f*MU0*35.0)); print('  Al delta',f,d)
# 9B.1
print('9B.1 div',-2/45)
# 9C.1 Helmholtz-like pair of Ex 9.4 coils
a,b,h=30.,40.,50.; J0=2.0
d2=lambda zc: (fabry(1e-2+zc,a,b,h,J0)+fabry(1e-2-zc,a,b,h,J0)+fabry(-1e-2+zc,a,b,h,J0)+fabry(-1e-2-zc,a,b,h,J0)-2*(fabry(zc,a,b,h,J0)+fabry(-zc,a,b,h,J0)))/(1e-2)**2
# B(z)=B1(z-zc)+B1(z+zc); use symmetric second derivative at z=0
def B2(zc,dz=0.5):
    B=lambda z: fabry(z-zc,a,b,h,J0)+fabry(z+zc,a,b,h,J0)
    return (B(dz)-2*B(0)+B(-dz))/dz**2
zs=np.linspace(40,120,81); v=[B2(z) for z in zs]
zc=brentq(B2,25,80); print('9C.1 zc (centre to pair-centre)',zc,' coil gap =',2*zc-h,'B0 [mT]',2*fabry(zc,a,b,h,J0)*1e6,' single coil centre',fabry(0,a,b,h,J0)*1e6)
# 9C.2 cylinder at 50 Hz copper, K0=8
import ref_cyl as rc
mp.mp.dps=25
for f in (50.,1000.):
    rc.F=f; rc.OM=2*mp.pi*f; rc.S=mp.sqrt(1j*rc.OM*rc.MU0*rc.SIG); rc.DELTA=mp.sqrt(2/(rc.OM*rc.MU0*rc.SIG))
    Hg=mp.mpf(8)
    print('9C.2 f',f,'delta',mp.nstr(rc.DELTA,6),'P',mp.nstr(rc.power_vol(Hg),8),'|A(Rc)|',mp.nstr(abs(rc.Atheta(rc.RC,Hg)),6),' B(axis) ratio |H(0)/Hg|',mp.nstr(abs(1/mp.besseli(0,rc.S*rc.RC)),6))
