# Closed-form (Bessel) reference for the conducting cylinder in a solenoid sheet.  Units A, mm, N, s.
import mpmath as mp, numpy as np, sys
mp.mp.dps=30
MU0=4e-7*mp.pi; SIG=59.6; RC=10.0; RS=15.0; F=1e3; OM=2*mp.pi*F; PSI=mp.pi/6
S=mp.sqrt(1j*OM*MU0*SIG)                     # s = (1+j)/delta
DELTA=mp.sqrt(2/(OM*MU0*SIG))
def Hfield(r,Hg):  return Hg*mp.besseli(0,S*r)/mp.besseli(0,S*RC)
def Atheta(r,Hg):
    """A_theta = (1/r) int_0^r mu H r' dr'"""
    if r<=RC: return MU0*Hg*mp.besseli(1,S*r)/(S*mp.besseli(0,S*RC))
    ac=MU0*Hg*RC*mp.besseli(1,S*RC)/(S*mp.besseli(0,S*RC))   # = flux_c/(2 pi)
    return (ac+MU0*Hg*(r**2-RC**2)/2)/r
def power_vol(Hg):
    f=lambda r: mp.pi*SIG*OM**2*abs(Atheta(r,Hg))**2*r
    return mp.quad(f,[0,RC])
def power_poynting(Hg):
    E=-1j*OM*Atheta(RC,Hg)
    return -mp.pi*RC*mp.re(E*mp.conj(Hg))
if __name__=="__main__":
    print('delta [mm] =',mp.nstr(DELTA,8),'  Rc/delta =',mp.nstr(RC/DELTA,6))
    # mode 1: sheet K0 e^{j psi}, K0 = 8 A/mm -> Hg = K
    K=8*mp.e**(1j*PSI); Hg=K
    print('mode1 A(Rc) =',mp.nstr(Atheta(RC,Hg),10),'  P vol =',mp.nstr(power_vol(Hg),10),' P Poynting =',mp.nstr(power_poynting(Hg),10))
    # mode 2: A(Rs) = BEXT*Rs/2 * e^{j psi}
    BEXT=1e-5; ARS=BEXT*RS/2*mp.e**(1j*PSI)
    # Hg from  A(Rs) with A(Rs) = Atheta(Rs,Hg) linear in Hg
    Hg2=ARS/Atheta(RS,1)
    print('mode2 Hg =',mp.nstr(Hg2,10),' A(Rc) =',mp.nstr(Atheta(RC,Hg2),10),' P vol =',mp.nstr(power_vol(Hg2),10))
    # unshielded field (no conductor): Hg = BEXT/mu0
    print('  unshielded Hg =',mp.nstr(BEXT/MU0,8),'  |Hg2|/(BEXT/mu0) =',mp.nstr(abs(Hg2)/(BEXT/MU0),8))
    # error of FE
    for mode in (1,2):
        for n in (15,30,60,120,240):
            d=np.loadtxt(f'harm_{mode}_{n:04d}.txt'); r=d[:,0]; a=d[:,1]+1j*d[:,2]
            Hg_=K if mode==1 else Hg2
            ex=np.array([complex(Atheta(x,Hg_)) if x>0 else 0 for x in r])
            print(mode,n,'max rel err of A:',np.max(abs(a-ex))/np.max(abs(ex)))
    # power errors of the FE and the transient runs
    import re
    P1=float(power_vol(K)); P2=float(power_vol(Hg2)); A1=complex(Atheta(RC,K))
    print('power errors, mode 1/2:')
    for line in open('cyl_out.txt'):
        m=re.match(r'HARM mode (\d) n=\s*(\d+)\s+A\(Rc\) =\s+(\S+)\s+(\S+)\s+P =\s+(\S+)',line)
        if m:
            mo,n,pp=int(m[1]),int(m[2]),float(m[5]); ex=P1 if mo==1 else P2
            print(mo,n,'P=%.4f'%pp,'rel err %.2e'%((pp-ex)/ex))
        m=re.match(r'TRAN lag (\d) NS=\s*(\d+)\s+Ahat\(Rc\) =\s+(\S+)\s+(\S+)\s+Pavg =\s+(\S+)',line)
        if m:
            lag,ns=int(m[1]),int(m[2]); ah=complex(float(m[3]),float(m[4])); pp=float(m[5])
            print('TRAN lag',lag,'NS',ns,'|A|/|Aex| = %.5f'%(abs(ah)/abs(A1)),' phase err [deg] = %.3f'%(np.degrees(np.angle(ah/A1))),' P/Pex = %.5f'%(pp/P1),' expected phase lag from load shift w*dt [deg] = %.2f'%(360/ns))
