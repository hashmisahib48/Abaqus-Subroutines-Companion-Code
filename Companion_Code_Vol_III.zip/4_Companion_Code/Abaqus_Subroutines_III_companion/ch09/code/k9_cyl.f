      PROGRAM K9CYL
!
!     Driver for Chapter 9: conducting cylinder (radius RC) inside a
!     solenoid sheet (radius RS), axial field, only A_theta(r) nonzero.
!     Linear elements, weak form  int [ B_z dv_z /mu + j w sigma A v ] r dr
!     Time-harmonic (UDSECURRENT or UDEMPOTENTIAL as the load) and
!     transient (backward Euler, UDSECURRENT with PROC = 2).
!     Units A, mm, N, s;  sigma in A/(mV mm), A in N/A.
!
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (PI=3.141592653589793D0, XMU0=4.D-7*PI)
      PARAMETER (RC=10.D0, RS=15.D0, SIG=59.6D0, FREQ=1.D3)
      CHARACTER*40 FN
      OM=2*PI*FREQ
!     ---------- time-harmonic, both loads, several meshes -----------
      DO 20 MODE=1,2
       DO 10 IM=1,5
        N=15*2**(IM-1)
        CALL HARM(N,MODE,OM,PW)
   10  CONTINUE
   20 CONTINUE
!     ---------- transient, several steps per period -----------------
      DO 40 ILAG=0,1
       DO 30 IS=1,5
        NS=10*2**(IS-1)
        CALL TRAN(60,NS,14,ILAG,OM)
   30  CONTINUE
   40 CONTINUE
      STOP
      END
!
      SUBROUTINE ASSEM(N,OM,D,U,CM,CK)
!     tridiagonal K (CK) and M (CM) of nodes 0..N; D(i) diagonal and
!     U(i) = coupling (i,i+1) of K + j*OM*M  (complex symmetric)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (PI=3.141592653589793D0, XMU0=4.D-7*PI)
      PARAMETER (RC=10.D0, RS=15.D0, SIG=59.6D0)
      COMPLEX*16 D(0:N),U(0:N)
      DIMENSION CM(0:N,2),CK(0:N,2),GX(3),GW(3)
      CALL GL3(GX,GW)
      H=RS/N
      DO 5 I=0,N
         D(I)=0
         U(I)=0
         CM(I,1)=0
         CM(I,2)=0
         CK(I,1)=0
         CK(I,2)=0
    5 CONTINUE
      DO 30 IE=1,N
         R1=(IE-1)*H
         SG=0.D0
         IF (R1+0.5D0*H .LT. RC) SG=SIG
         DO 20 IG=1,3
            R=R1+0.5D0*H*(1+GX(IG))
            WT=0.5D0*H*GW(IG)*R
            S1=(R1+H-R)/H
            S2=(R-R1)/H
            B1=-1.D0/H+S1/R
            B2= 1.D0/H+S2/R
            CK(IE-1,1)=CK(IE-1,1)+B1*B1*WT/XMU0
            CK(IE  ,1)=CK(IE  ,1)+B2*B2*WT/XMU0
            CK(IE-1,2)=CK(IE-1,2)+B1*B2*WT/XMU0
            CM(IE-1,1)=CM(IE-1,1)+SG*S1*S1*WT
            CM(IE  ,1)=CM(IE  ,1)+SG*S2*S2*WT
            CM(IE-1,2)=CM(IE-1,2)+SG*S1*S2*WT
   20    CONTINUE
   30 CONTINUE
      DO 40 I=0,N
         D(I)=CMPLX(CK(I,1),OM*CM(I,1),KIND=8)
         U(I)=CMPLX(CK(I,2),OM*CM(I,2),KIND=8)
   40 CONTINUE
      RETURN
      END
!
      SUBROUTINE GL3(X,W)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION X(3),W(3)
      X(1)=-SQRT(0.6D0)
      X(2)=0.D0
      X(3)=SQRT(0.6D0)
      W(1)=5.D0/9.D0
      W(2)=8.D0/9.D0
      W(3)=5.D0/9.D0
      RETURN
      END
!
      SUBROUTINE HARM(N,MODE,OM,PW)
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (PI=3.141592653589793D0, XMU0=4.D-7*PI)
      PARAMETER (RC=10.D0, RS=15.D0, SIG=59.6D0)
      COMPLEX*16 D(0:N),U(0:N),F(0:N),A(0:N),AN,KC,CP,DDD
      COMPLEX*16 DD(0:N),FF(0:N),AA
      DIMENSION CM(0:N,2),CK(0:N,2),V(3),VI(3),GX(3),GW(3)
      CHARACTER*40 FN
      CHARACTER*2 TAG
      CALL ASSEM(N,OM,D,U,CM,CK)
      DO 5 I=0,N
         F(I)=0
    5 CONTINUE
      IF (MODE.EQ.1) THEN
         CALL CKS(RS,0.D0,0.D0,2,1,0.D0,0.D0,V)
         CALL CKS(RS,0.D0,0.D0,2,2,0.D0,0.D0,VI)
         CALL CKS(RS,0.D0,0.D0,1,1,0.D0,0.D0,V)
         CALL CKS(RS,0.D0,0.D0,1,2,0.D0,0.D0,VI)
         F(N)=RS*CMPLX(V(2),VI(2),KIND=8)
         NU=N
      ELSE
         CALL CAS(RS,0.D0,0.D0,1,1,V)
         CALL CAS(RS,0.D0,0.D0,1,2,VI)
         AN=CMPLX(V(2),VI(2),KIND=8)
         NU=N-1
         F(N-1)=-U(N-1)*AN
      END IF
!     Thomas algorithm for unknowns 1..NU (A(0) = 0)
      DO 6 I=1,NU
         DD(I)=D(I)
         FF(I)=F(I)
    6 CONTINUE
      DO 7 I=2,NU
         CP=U(I-1)/DD(I-1)
         DD(I)=DD(I)-CP*U(I-1)
         FF(I)=FF(I)-CP*FF(I-1)
    7 CONTINUE
      A(0)=0
      A(NU)=FF(NU)/DD(NU)
      DO 8 I=NU-1,1,-1
         A(I)=(FF(I)-U(I)*A(I+1))/DD(I)
    8 CONTINUE
      IF (MODE.EQ.2) A(N)=AN
!     power per unit length (time average of peak phasors)
      H=RS/N
      CALL GL3(GX,GW)
      PW=0.D0
      DO 20 IE=1,N
         R1=(IE-1)*H
         IF (R1+0.5D0*H .GT. RC) GO TO 20
         DO 15 IG=1,3
            R=R1+0.5D0*H*(1+GX(IG))
            AA=((R1+H-R)*A(IE-1)+(R-R1)*A(IE))/H
            PW=PW+PI*SIG*OM*OM*ABS(AA)**2*R*0.5D0*H*GW(IG)
   15    CONTINUE
   20 CONTINUE
      IC=N*2/3
      WRITE(TAG,'(I1,I1)') MODE,0
      WRITE(*,'(A,I1,A,I4,A,2ES16.8,A,ES16.8)') 'HARM mode ',MODE,
     1 ' n=',N,'  A(Rc) = ',A(IC),'  P = ',PW
      WRITE(FN,'(A,I1,A,I4.4,A)') 'harm_',MODE,'_',N,'.txt'
      OPEN(7,FILE=FN)
      DO 30 I=0,N
         WRITE(7,'(F10.5,2ES22.14)') I*H,A(I)
   30 CONTINUE
      CLOSE(7)
      RETURN
      END
!
      SUBROUTINE CKS(X,Y,Z,IPROC,IPHASE,T0,DT,V)
!     one call of UDSECURRENT, NBLOCK = 1
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION V(3),SC(1,3),CO(1,3),IA(6),RA(3)
      CHARACTER*80 CA(1)
      CO(1,1)=X
      CO(1,2)=Y
      CO(1,3)=Z
      IA(5)=IPHASE
      IA(6)=IPROC
      RA(1)=1.D3
      RA(2)=T0
      RA(3)=DT
      IF (IPROC.EQ.1) RA(2)=6283.185307179586D0
      CALL UDSECURRENT(SC,CO,1,IA,6,RA,3,CA,1)
      V(1)=SC(1,1)
      V(2)=SC(1,2)
      V(3)=SC(1,3)
      RETURN
      END
!
      SUBROUTINE CAS(X,Y,Z,IPROC,IPHASE,V)
!     one call of UDEMPOTENTIAL on the surface 'CYLBOUND'
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION V(3),VP(1,3),CO(1,3),IA(6),RA(3)
      CHARACTER*80 CA(1)
      CO(1,1)=X
      CO(1,2)=Y
      CO(1,3)=Z
      CA(1)='CYLBOUND'
      IA(5)=IPHASE
      IA(6)=IPROC
      RA(1)=1.D3
      RA(2)=6283.185307179586D0
      RA(3)=0.D0
      CALL UDEMPOTENTIAL(VP,CO,1,IA,6,RA,3,CA,1)
      V(1)=VP(1,1)
      V(2)=VP(1,2)
      V(3)=VP(1,3)
      RETURN
      END
!
      SUBROUTINE TRAN(N,NS,NP,ILAG,OM)
!     backward Euler, NS steps per period, NP periods; ILAG = 1 emulates
!     a routine that uses the time at the START of the increment
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (PI=3.141592653589793D0, XMU0=4.D-7*PI)
      PARAMETER (RC=10.D0, RS=15.D0, SIG=59.6D0)
      COMPLEX*16 D(0:N),U(0:N),CA1,CA2,CPH
      DIMENSION CM(0:N,2),CK(0:N,2),DR(0:N),UR(0:N),A(0:N),AO(0:N),
     1 FF(0:N),DD(0:N),V(3),GX(3),GW(3)
      CALL ASSEM(N,OM,D,U,CM,CK)
      TP=2*PI/OM
      DT=TP/NS
      DO 5 I=0,N
         DR(I)=CK(I,1)+CM(I,1)/DT
         UR(I)=CK(I,2)+CM(I,2)/DT
         A(I)=0.D0
    5 CONTINUE
      IC=N*2/3
      CA1=0
      PW=0.D0
      T=0.D0
      DO 50 IT=1,NS*NP
         DTX=DT
         IF (ILAG.EQ.1) DTX=0.D0
         CALL CKS(RS,0.D0,0.D0,2,1,T,DTX,V)
         DO 10 I=0,N
            AO(I)=A(I)
   10    CONTINUE
!        right-hand side M*A_old/DT + f
         DO 12 I=1,N
            FF(I)=CM(I,1)*AO(I)/DT
            IF (I.GT.1) FF(I)=FF(I)+CM(I-1,2)*AO(I-1)/DT
            IF (I.LT.N) FF(I)=FF(I)+CM(I,2)*AO(I+1)/DT
   12    CONTINUE
         FF(N)=FF(N)+RS*V(2)
         DO 14 I=1,N
            DD(I)=DR(I)
   14    CONTINUE
         DO 16 I=2,N
            W=UR(I-1)/DD(I-1)
            DD(I)=DD(I)-W*UR(I-1)
            FF(I)=FF(I)-W*FF(I-1)
   16    CONTINUE
         A(0)=0.D0
         A(N)=FF(N)/DD(N)
         DO 18 I=N-1,1,-1
            A(I)=(FF(I)-UR(I)*A(I+1))/DD(I)
   18    CONTINUE
         T=T+DT
         IF (IT.GT.NS*(NP-1)) THEN
!           projection on exp(-j w t) and dissipated power
            CPH=EXP(CMPLX(0.D0,-OM*T,KIND=8))
            CA1=CA1+2.D0/NS*A(IC)*CPH
            H=RS/N
            CALL GL3(GX,GW)
            DO 25 IE=1,N
               R1=(IE-1)*H
               IF (R1+0.5D0*H .GT. RC) GO TO 25
               DO 22 IG=1,3
                  R=R1+0.5D0*H*(1+GX(IG))
                  S1=(R1+H-R)/H
                  S2=(R-R1)/H
                  DA=(S1*(A(IE-1)-AO(IE-1))+S2*(A(IE)-AO(IE)))/DT
                  PW=PW+2*PI*SIG*DA*DA*R*0.5D0*H*GW(IG)/NS
   22          CONTINUE
   25       CONTINUE
         END IF
   50 CONTINUE
      WRITE(*,'(A,I1,A,I4,A,2ES16.8,A,ES16.8)') 'TRAN lag ',ILAG,
     1 ' NS=',NS,'  Ahat(Rc) = ',CA1,'  Pavg = ',PW
      RETURN
      END
