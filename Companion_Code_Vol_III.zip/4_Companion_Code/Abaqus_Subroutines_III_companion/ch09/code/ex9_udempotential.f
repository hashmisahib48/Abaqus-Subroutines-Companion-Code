      SUBROUTINE UDEMPOTENTIAL(VECPOT,COORDS,NBLOCK,
     1 I_ARRAY,NIARRAY,R_ARRAY,NRARRAY,C_ARRAY,NCARRAY)
!
!     Vector potential on a surface, chosen by the surface name:
!       'CYLBOUND' uniform axial field BEXT:  A = (BEXT/2) z x r
!       'FARFIELD' dipole of the coil of Example 9.4-1
!     Units: A, mm, N (A in N/A, B in N/(A mm), MU0 in N/A**2).
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION VECPOT(NBLOCK,*), COORDS(NBLOCK,*),
     1 I_ARRAY(*), R_ARRAY(*)
      CHARACTER*80 C_ARRAY(*)
      PARAMETER (I_PHASE=5, I_PROC=6, IR_T2=2, IR_T3=3)
      PARAMETER (PI=3.141592653589793D0, XMU0=1.2566370614359D-6)
      PARAMETER (BEXT=1.D-5)             ! 10 mT  =  1e-5 N/(A mm)
      PARAMETER (RIN=30.D0, ROUT=40.D0, TURNS=100.D0, CUR0=10.D0)
      PARAMETER (PSI=0.5235987755982988D0, FREQ=1.D3)  ! rad, Hz
!
      CALL K9_WAVE(I_ARRAY(I_PROC), I_ARRAY(I_PHASE), PSI, FREQ,
     1 R_ARRAY(IR_T2), R_ARRAY(IR_T3), W)
      DO K = 1, NBLOCK
         X = COORDS(K,1)
         Y = COORDS(K,2)
         Z = COORDS(K,3)
         IF (C_ARRAY(1)(1:8) .EQ. 'FARFIELD') THEN
            XM = PI*TURNS*CUR0*W*(RIN*RIN + RIN*ROUT + ROUT*ROUT)/3.D0
            R3 = (X*X + Y*Y + Z*Z)**1.5D0
            FAC = XMU0*XM/(4.D0*PI*R3)
         ELSE
            FAC = 0.5D0*BEXT*W
         END IF
         VECPOT(K,1) = -FAC*Y
         VECPOT(K,2) =  FAC*X
         VECPOT(K,3) = 0.D0
      END DO
      RETURN
      END
