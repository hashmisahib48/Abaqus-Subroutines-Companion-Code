      SUBROUTINE UDSECURRENT(SURFACECURRENT,COORDS,NBLOCK,
     1 I_ARRAY,NIARRAY,R_ARRAY,NRARRAY,C_ARRAY,NCARRAY)
!
!     Solenoid sheet: tangential current K = K0 * e_theta on the
!     cylinder r = RS, |z| <= HLEN.  Units: A, mm, s  (K in A/mm).
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION SURFACECURRENT(NBLOCK,*), COORDS(NBLOCK,*),
     1 I_ARRAY(*), R_ARRAY(*)
      CHARACTER*80 C_ARRAY(*)
      PARAMETER (I_PHASE=5, I_PROC=6, IR_T2=2, IR_T3=3)
      PARAMETER (RS=15.D0, HLEN=120.D0)                    ! mm
      PARAMETER (SK0=8.D0)                               ! A/mm, peak
      PARAMETER (PSI=0.5235987755982988D0, FREQ=1.D3)  ! rad, Hz
!
      CALL K9_WAVE(I_ARRAY(I_PROC), I_ARRAY(I_PHASE), PSI, FREQ,
     1 R_ARRAY(IR_T2), R_ARRAY(IR_T3), W)
      DO K = 1, NBLOCK
         X = COORDS(K,1)
         Y = COORDS(K,2)
         Z = COORDS(K,3)
         R = SQRT(X*X + Y*Y)
         SURFACECURRENT(K,1) = 0.D0
         SURFACECURRENT(K,2) = 0.D0
         SURFACECURRENT(K,3) = 0.D0
         IF (ABS(Z) .LE. HLEN .AND. R .GT. 0.D0) THEN
            SURFACECURRENT(K,1) = -SK0*W*Y/R
            SURFACECURRENT(K,2) =  SK0*W*X/R
         END IF
      END DO
      RETURN
      END
