      SUBROUTINE UDECURRENT(BODYCURRENT,PREDEF,COORDS,NBLOCK,
     1 I_ARRAY,NIARRAY,R_ARRAY,NRARRAY,C_ARRAY,NCARRAY)
!
!     Circular coil: azimuthal current density J = J0 * e_theta in
!     RIN <= r <= ROUT, |z - ZC| <= HC/2.  Units: A, mm, s.
!
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION BODYCURRENT(NBLOCK,*), PREDEF(NBLOCK,2,*),
     1 COORDS(NBLOCK,*), I_ARRAY(*), R_ARRAY(*)
      CHARACTER*80 C_ARRAY(*)
      PARAMETER (I_PHASE=6, I_PROC=7, IR_T1=1, IR_T2=2, IR_T3=3)
      PARAMETER (RIN=30.D0, ROUT=40.D0, HC=50.D0, ZC=0.D0)  ! mm
      PARAMETER (TURNS=100.D0, CUR0=10.D0)         ! turns, A (peak)
      PARAMETER (PSI=0.5235987755982988D0, FREQ=1.D3)  ! rad, Hz
!
      CALL K9_WAVE(I_ARRAY(I_PROC), I_ARRAY(I_PHASE), PSI, FREQ,
     1 R_ARRAY(IR_T2), R_ARRAY(IR_T3), W)
      CJ0 = TURNS*CUR0*W/((ROUT - RIN)*HC)             ! A/mm**2
      DO K = 1, NBLOCK
         X = COORDS(K,1)
         Y = COORDS(K,2)
         Z = COORDS(K,3)
         R = SQRT(X*X + Y*Y)
         BODYCURRENT(K,1) = 0.D0
         BODYCURRENT(K,2) = 0.D0
         BODYCURRENT(K,3) = 0.D0
         IF (R .GE. RIN .AND. R .LE. ROUT .AND.
     1       ABS(Z - ZC) .LE. 0.5D0*HC) THEN
            BODYCURRENT(K,1) = -CJ0*Y/R
            BODYCURRENT(K,2) =  CJ0*X/R
         END IF
      END DO
      RETURN
      END
