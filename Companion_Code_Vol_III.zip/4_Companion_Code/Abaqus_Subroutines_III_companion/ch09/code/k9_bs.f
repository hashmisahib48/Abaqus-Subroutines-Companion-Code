      PROGRAM K9BS
!
!     Driver for Chapter 9: calls UDECURRENT, UDSECURRENT and
!     UDEMPOTENTIAL as Abaqus does (NBLOCK = 1, one point per call) at
!     the Gauss points of a polar mesh and integrates the Biot-Savart
!     law.  Units A, mm, N; B in N/(A mm); 1 T = 1e-3 N/(A mm).
!
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI=3.141592653589793D0, XMU0=4.D-7*PI)
      PARAMETER (NPMAX=80000)
      DIMENSION GX(8),GW(8),BB(3),FP(3),BA(3),ZA(5),RRA(6),ZS(4)
      COMMON /K9PTS/ PX(NPMAX),PY(NPMAX),PZ(NPMAX),CX(NPMAX),
     1 CY(NPMAX),CZ(NPMAX),NPT
      COMMON /K9GEO/ RIN,ROUT,HC,TURNS,CUR0
      DATA ZA /0.D0,40.D0,80.D0,150.D0,300.D0/
      DATA RRA /60.D0,80.D0,120.D0,200.D0,400.D0,800.D0/
      DATA ZS /0.D0,60.D0,100.D0,120.D0/
      CALL GL(3,GX,GW)
      RIN=30.D0
      ROUT=40.D0
      HC=50.D0
      TURNS=100.D0
      CUR0=10.D0
      CJ0=TURNS*CUR0/((ROUT-RIN)*HC)
      WRITE(*,'(A,F10.5)') 'J0 [A/mm2] = ',CJ0
!     -------- Example 9.4-1: coil, magnetostatic call (W = 1) ------
      CALL BUILDV(4,5,48,GX,GW,3,3,3)
      WRITE(*,'(A,I7)') 'coil source points ',NPT
      CALL HALFPL(GX,GW,3,4,5,3,3,SUMI)
      WRITE(*,'(A,2F16.8)') 'I half-plane, N*I0 [A]  : ',SUMI,
     1 TURNS*CUR0
      XMZ=0.D0
      DO 10 K=1,NPT
         XMZ=XMZ+0.5D0*(PX(K)*CY(K)-PY(K)*CX(K))
   10 CONTINUE
      XMEX=PI*CJ0*HC*(ROUT**3-RIN**3)/3.D0
      WRITE(*,'(A,2ES20.10)') 'm_z num, exact [A mm2] : ',XMZ,XMEX
      DO 20 IZ=1,5
         FP(1)=0.D0
         FP(2)=0.D0
         FP(3)=ZA(IZ)
         CALL BSB(FP,BB)
         ZP=ZA(IZ)+0.5D0*HC
         ZM=ZA(IZ)-0.5D0*HC
         EX=0.5D0*XMU0*CJ0*(ZP*LOG((ROUT+SQRT(ROUT**2+ZP**2))/
     1    (RIN+SQRT(RIN**2+ZP**2)))-ZM*LOG((ROUT+SQRT(ROUT**2+ZM**2))
     2    /(RIN+SQRT(RIN**2+ZM**2))))
         WRITE(*,'(A,F7.1,2ES18.9,ES11.2)') 'Bz axis z,num,exact[T],rel
     1 ',ZA(IZ),BB(3)*1.D3,EX*1.D3,(BB(3)-EX)/EX
   20 CONTINUE
      CALL LOOP(60.D0,90.D0,GX,GW,CIRC)
      WRITE(*,'(A,2ES20.10)') 'Ampere loop, mu0*N*I0 : ',CIRC,
     1 XMU0*TURNS*CUR0
      CALL LOOP(200.D0,300.D0,GX,GW,CIRC)
      WRITE(*,'(A,2ES20.10)') 'Ampere loop (large)   : ',CIRC,
     1 XMU0*TURNS*CUR0
!     divergence of J by central differences of the routine
      DMAX=0.D0
      HH=1.D-3
      DO 30 K=1,200
         X=33.D0+0.0347D0*K
         Y=1.D0+0.0291D0*K
         Z=-20.D0+0.04D0*K
         CALL CALLJ(X+HH,Y,Z,3,1,BB)
         DV=BB(1)/(2*HH)
         CALL CALLJ(X-HH,Y,Z,3,1,BB)
         DV=DV-BB(1)/(2*HH)
         CALL CALLJ(X,Y+HH,Z,3,1,BB)
         DV=DV+BB(2)/(2*HH)
         CALL CALLJ(X,Y-HH,Z,3,1,BB)
         DV=DV-BB(2)/(2*HH)
         DMAX=MAX(DMAX,ABS(DV))
   30 CONTINUE
      WRITE(*,'(A,ES12.3,A,ES12.3)') 'max |div J| = ',DMAX,
     1 '   J0/ROUT = ',CJ0/ROUT
!     bad distribution J = (1 - x/45) e_x : divergence -1/45 (analytic)
!     time-harmonic: real and imaginary parts of the same point
      CALL CALLJ(35.D0,0.D0,0.D0,1,1,BB)
      CALL CALLJ(35.D0,0.D0,0.D0,1,2,FP)
      WRITE(*,'(A,2ES16.8)') 'harmonic Jy re, im       : ',BB(2),FP(2)
      WRITE(*,'(A,2ES16.8)') '   |J|, J0               : ',
     1 SQRT(BB(2)**2+FP(2)**2),CJ0
      WRITE(*,'(A,2ES16.8)') '   atan2(im,re), psi     : ',
     1 ATAN2(FP(2),BB(2)),0.5235987755982988D0
!     -------- Example 9.7-1: dipole potential against Biot-Savart --
      DO 40 IR=1,6
         RR=RRA(IR)
         FP(1)=RR*SIN(PI/3.D0)
         FP(2)=0.D0
         FP(3)=RR*COS(PI/3.D0)
         CALL BSA(FP,BA)
         CALL CALLA(FP(1),FP(2),FP(3),'FARFIELD',3,1,BB)
         WRITE(*,'(A,F8.1,2ES18.9,ES11.2)') 'A_y R,BS,dipole,rel   ',
     1    RR,BA(2),BB(2),(BB(2)-BA(2))/BA(2)
   40 CONTINUE
!     flux of the uniform-field potential: circulation of A on r = R
      DO 45 IR=1,2
         RR=10.D0+5.D0*IR
         CIRA=0.D0
         DO 44 K=1,360
            TH=(K-0.5D0)*2*PI/360.D0
            CALL CALLA(RR*COS(TH),RR*SIN(TH),0.D0,'CYLBOUND',3,1,BB)
            CIRA=CIRA+(-BB(1)*SIN(TH)+BB(2)*COS(TH))*RR*2*PI/360.D0
   44    CONTINUE
         WRITE(*,'(A,F6.1,2ES18.9)') 'oint A.dl, B*pi*R^2 [N/A*mm] R=',
     1    RR,CIRA,1.D-5*PI*RR**2
   45 CONTINUE
!     -------- Example 9.6-1: solenoid sheet, magnetostatic ---------
      RS=15.D0
      HLEN=120.D0
      SK0=8.D0
      CALL BUILDS(GX,GW,3,96,60,3,3)
      WRITE(*,'(A,I7)') 'sheet source points ',NPT
      CALL HALFPS(GX,GW,3,12,3,3,SUMI)
      WRITE(*,'(A,2F16.8)') 'I through y=0 cut, K0*2L : ',SUMI,
     1 SK0*2*HLEN
      DO 50 IZ=1,4
         FP(1)=0.D0
         FP(2)=0.D0
         FP(3)=ZS(IZ)
         CALL BSB(FP,BB)
         ZP=ZS(IZ)+HLEN
         ZM=ZS(IZ)-HLEN
         EX=0.5D0*XMU0*SK0*(ZP/SQRT(RS**2+ZP**2)-ZM/SQRT(RS**2+ZM**2))
         WRITE(*,'(A,F7.1,2ES18.9,ES11.2)') 'sol Bz z,num,exact[T],rel
     1 ',ZS(IZ),BB(3)*1.D3,EX*1.D3,(BB(3)-EX)/EX
   50 CONTINUE
      WRITE(*,'(A,2ES18.9)') 'mu0*K [T] (infinite), centre finite  : ',
     1 XMU0*SK0*1.D3,XMU0*SK0*HLEN/SQRT(RS**2+HLEN**2)*1.D3
      CALL LOOP(40.D0,150.D0,GX,GW,CIRC)
      WRITE(*,'(A,2ES20.10)') 'sheet Ampere loop, mu0*K*2L   : ',CIRC,
     1 XMU0*SK0*2*HLEN
      CALL LOOP(25.D0,200.D0,GX,GW,CIRC)
      WRITE(*,'(A,2ES20.10)') 'sheet Ampere loop 2           : ',CIRC,
     1 XMU0*SK0*2*HLEN
      STOP
      END
!
      SUBROUTINE GL(N,X,W)
!     Gauss-Legendre nodes and weights on [-1,1] (Newton iteration)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION X(N),W(N)
      PI=3.141592653589793D0
      DO 20 I=1,N
         Z=COS(PI*(I-0.25D0)/(N+0.5D0))
         DO 10 IT=1,100
            P1=1.D0
            P2=0.D0
            DO 5 J=1,N
               P3=P2
               P2=P1
               P1=((2*J-1)*Z*P2-(J-1)*P3)/J
    5       CONTINUE
            PP=N*(Z*P1-P2)/(Z*Z-1.D0)
            DZ=P1/PP
            Z=Z-DZ
            IF (ABS(DZ).LT.1.D-15) GO TO 15
   10    CONTINUE
   15    X(I)=Z
         W(I)=2.D0/((1.D0-Z*Z)*PP*PP)
   20 CONTINUE
      RETURN
      END
!
      SUBROUTINE CALLJ(X,Y,Z,IPROC,IPHASE,V)
!     one call of UDECURRENT with NBLOCK = 1
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION V(3),BC(1,3),PD(1,2,1),CO(1,3),IA(8),RA(3)
      CHARACTER*80 CA(1)
      CO(1,1)=X
      CO(1,2)=Y
      CO(1,3)=Z
      IA(6)=IPHASE
      IA(7)=IPROC
      RA(1)=1.D3
      RA(2)=6283.185307179586D0
      RA(3)=0.D0
      CALL UDECURRENT(BC,PD,CO,1,IA,8,RA,3,CA,1)
      V(1)=BC(1,1)
      V(2)=BC(1,2)
      V(3)=BC(1,3)
      RETURN
      END
!
      SUBROUTINE CALLK(X,Y,Z,IPROC,IPHASE,V)
!     one call of UDSECURRENT with NBLOCK = 1
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION V(3),SC(1,3),CO(1,3),IA(6),RA(3)
      CHARACTER*80 CA(1)
      CO(1,1)=X
      CO(1,2)=Y
      CO(1,3)=Z
      IA(5)=IPHASE
      IA(6)=IPROC
      RA(1)=1.D3
      RA(2)=6283.185307179586D0
      RA(3)=0.D0
      CALL UDSECURRENT(SC,CO,1,IA,6,RA,3,CA,1)
      V(1)=SC(1,1)
      V(2)=SC(1,2)
      V(3)=SC(1,3)
      RETURN
      END
!
      SUBROUTINE CALLA(X,Y,Z,NAME,IPROC,IPHASE,V)
!     one call of UDEMPOTENTIAL with NBLOCK = 1
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION V(3),VP(1,3),CO(1,3),IA(6),RA(3)
      CHARACTER*8 NAME
      CHARACTER*80 CA(1)
      CO(1,1)=X
      CO(1,2)=Y
      CO(1,3)=Z
      CA(1)=NAME
      IA(5)=IPHASE
      IA(6)=IPROC
      RA(1)=1.D3
      RA(2)=6283.185307179586D0
      RA(3)=0.D0
      CALL UDEMPOTENTIAL(VP,CO,1,IA,6,RA,3,CA,1)
      V(1)=VP(1,1)
      V(2)=VP(1,2)
      V(3)=VP(1,3)
      RETURN
      END
!
      SUBROUTINE BUILDV(NR,NZ,NT,GX,GW,NG,NGT,IPROC)
!     Gauss points of a polar mesh (NR x NZ x NT curved bricks, NG
!     points in r and z, NGT in theta) of the coil; stores the current
!     element J*dV at each point.
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NPMAX=80000)
      DIMENSION GX(8),GW(8),V(3),GT(8),GWT(8)
      COMMON /K9PTS/ PX(NPMAX),PY(NPMAX),PZ(NPMAX),CX(NPMAX),
     1 CY(NPMAX),CZ(NPMAX),NPT
      COMMON /K9GEO/ RIN,ROUT,HC,TURNS,CUR0
      PI=3.141592653589793D0
      CALL GL(NGT,GT,GWT)
      NPT=0
      DR=(ROUT-RIN)/NR
      DZ=HC/NZ
      DT=2*PI/NT
      DO 50 IR=1,NR
       DO 40 IZ=1,NZ
        DO 30 IT=1,NT
         DO 25 I=1,NG
          R=RIN+(IR-1)*DR+0.5D0*DR*(1+GX(I))
          DO 24 J=1,NG
           Z=-0.5D0*HC+(IZ-1)*DZ+0.5D0*DZ*(1+GX(J))
           DO 23 K=1,NGT
            TH=(IT-1)*DT+0.5D0*DT*(1+GT(K))
            WV=0.5D0*DR*GW(I)*0.5D0*DZ*GW(J)*0.5D0*DT*GWT(K)*R
            X=R*COS(TH)
            Y=R*SIN(TH)
            CALL CALLJ(X,Y,Z,IPROC,1,V)
            NPT=NPT+1
            PX(NPT)=X
            PY(NPT)=Y
            PZ(NPT)=Z
            CX(NPT)=V(1)*WV
            CY(NPT)=V(2)*WV
            CZ(NPT)=V(3)*WV
   23      CONTINUE
   24     CONTINUE
   25    CONTINUE
   30   CONTINUE
   40  CONTINUE
   50 CONTINUE
      RETURN
      END
!
      SUBROUTINE BUILDS(GX,GW,NG,NZ,NT,NGT,IPROC)
!     Gauss points on the cylinder r = RS, |z| <= HLEN (NZ x NT facets)
!     and the current element K*dA at each point.
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NPMAX=80000)
      DIMENSION GX(8),GW(8),V(3),GT(8),GWT(8)
      COMMON /K9PTS/ PX(NPMAX),PY(NPMAX),PZ(NPMAX),CX(NPMAX),
     1 CY(NPMAX),CZ(NPMAX),NPT
      PI=3.141592653589793D0
      RS=15.D0
      HLEN=120.D0
      CALL GL(NGT,GT,GWT)
      NPT=0
      DZ=2*HLEN/NZ
      DT=2*PI/NT
      DO 40 IZ=1,NZ
       DO 30 IT=1,NT
        DO 25 J=1,NG
         Z=-HLEN+(IZ-1)*DZ+0.5D0*DZ*(1+GX(J))
         DO 23 K=1,NGT
          TH=(IT-1)*DT+0.5D0*DT*(1+GT(K))
          WA=0.5D0*DZ*GW(J)*0.5D0*DT*GWT(K)*RS
          X=RS*COS(TH)
          Y=RS*SIN(TH)
          CALL CALLK(X,Y,Z,IPROC,1,V)
          NPT=NPT+1
          PX(NPT)=X
          PY(NPT)=Y
          PZ(NPT)=Z
          CX(NPT)=V(1)*WA
          CY(NPT)=V(2)*WA
          CZ(NPT)=V(3)*WA
   23    CONTINUE
   25   CONTINUE
   30  CONTINUE
   40 CONTINUE
      RETURN
      END
!
      SUBROUTINE HALFPL(GX,GW,NG,NR,NZ,NGG,IPROC,SUMI)
!     current through the half plane y = 0, x > 0 : int Jy dx dz
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION GX(8),GW(8),V(3)
      COMMON /K9GEO/ RIN,ROUT,HC,TURNS,CUR0
      SUMI=0.D0
      DR=(ROUT-RIN)/NR
      DZ=HC/NZ
      DO 30 IR=1,NR
       DO 20 IZ=1,NZ
        DO 15 I=1,NG
         X=RIN+(IR-1)*DR+0.5D0*DR*(1+GX(I))
         DO 10 J=1,NG
          Z=-0.5D0*HC+(IZ-1)*DZ+0.5D0*DZ*(1+GX(J))
          CALL CALLJ(X,0.D0,Z,IPROC,1,V)
          SUMI=SUMI+V(2)*0.5D0*DR*GW(I)*0.5D0*DZ*GW(J)
   10    CONTINUE
   15   CONTINUE
   20  CONTINUE
   30 CONTINUE
      RETURN
      END
!
      SUBROUTINE HALFPS(GX,GW,NG,NZ,NGG,IPROC,SUMI)
!     current of the sheet across the cut y = 0, x > 0 : int Ky dz
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION GX(8),GW(8),V(3)
      SUMI=0.D0
      HLEN=120.D0
      DZ=2*HLEN/NZ
      DO 20 IZ=1,NZ
       DO 10 J=1,NG
        Z=-HLEN+(IZ-1)*DZ+0.5D0*DZ*(1+GX(J))
        CALL CALLK(15.D0,0.D0,Z,IPROC,1,V)
        SUMI=SUMI+V(2)*0.5D0*DZ*GW(J)
   10  CONTINUE
   20 CONTINUE
      RETURN
      END
!
      SUBROUTINE BSB(P,B)
!     Biot-Savart: B = mu0/(4 pi) sum (dI x R)/|R|**3, R = P - source
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NPMAX=80000)
      DIMENSION P(3),B(3)
      COMMON /K9PTS/ PX(NPMAX),PY(NPMAX),PZ(NPMAX),CX(NPMAX),
     1 CY(NPMAX),CZ(NPMAX),NPT
      PI=3.141592653589793D0
      B(1)=0.D0
      B(2)=0.D0
      B(3)=0.D0
      DO 10 K=1,NPT
         RX=P(1)-PX(K)
         RY=P(2)-PY(K)
         RZ=P(3)-PZ(K)
         R3=(RX*RX+RY*RY+RZ*RZ)**1.5D0
         B(1)=B(1)+(CY(K)*RZ-CZ(K)*RY)/R3
         B(2)=B(2)+(CZ(K)*RX-CX(K)*RZ)/R3
         B(3)=B(3)+(CX(K)*RY-CY(K)*RX)/R3
   10 CONTINUE
      DO 20 I=1,3
         B(I)=B(I)*1.D-7
   20 CONTINUE
      RETURN
      END
!
      SUBROUTINE BSA(P,A)
!     Biot-Savart vector potential A = mu0/(4 pi) sum dI/|R|
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NPMAX=80000)
      DIMENSION P(3),A(3)
      COMMON /K9PTS/ PX(NPMAX),PY(NPMAX),PZ(NPMAX),CX(NPMAX),
     1 CY(NPMAX),CZ(NPMAX),NPT
      A(1)=0.D0
      A(2)=0.D0
      A(3)=0.D0
      DO 10 K=1,NPT
         RR=SQRT((P(1)-PX(K))**2+(P(2)-PY(K))**2+(P(3)-PZ(K))**2)
         A(1)=A(1)+CX(K)/RR
         A(2)=A(2)+CY(K)/RR
         A(3)=A(3)+CZ(K)/RR
   10 CONTINUE
      DO 20 I=1,3
         A(I)=A(I)*1.D-7
   20 CONTINUE
      RETURN
      END
!
      SUBROUTINE LOOP(XO,ZL,GX,GW,CIRC)
!     circulation of B around the rectangle in the plane y = 0:
!     top (0,ZL)->(XO,ZL), down x = XO, bottom back, up the axis
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION GX(8),GW(8),P(3),B(3)
      CIRC=0.D0
      NS=60
      DO 40 ISD=1,4
       DO 30 IS=1,NS
        DO 20 I=1,3
         T=(IS-1+0.5D0*(1+GX(I)))/NS
         WT=0.5D0*GW(I)/NS
         IF (ISD.EQ.1) THEN
            P(1)=XO*T
            P(3)=ZL
            DX=XO
            DZ=0.D0
         ELSE IF (ISD.EQ.2) THEN
            P(1)=XO
            P(3)=ZL-2*ZL*T
            DX=0.D0
            DZ=-2*ZL
         ELSE IF (ISD.EQ.3) THEN
            P(1)=XO-XO*T
            P(3)=-ZL
            DX=-XO
            DZ=0.D0
         ELSE
            P(1)=0.D0
            P(3)=-ZL+2*ZL*T
            DX=0.D0
            DZ=2*ZL
         END IF
         P(2)=0.D0
         CALL BSB(P,B)
         CIRC=CIRC+(B(1)*DX+B(3)*DZ)*WT
   20   CONTINUE
   30  CONTINUE
   40 CONTINUE
      RETURN
      END
