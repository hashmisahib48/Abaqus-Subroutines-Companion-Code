      SUBROUTINE K9_WAVE(IPROC,IPHASE,PSI,FREQ,T0,DT,W)
!
!     Dimensionless waveform of the excitation, shared by the three
!     routines of Chapter 9.  The excitation is the current
!     I(t) = I0*COS(2*PI*FREQ*t + PSI), or its phasor I0*EXP(J*PSI).
!       IPROC  = 1 time-harmonic, 2 transient, 3 magnetostatic
!       IPHASE = 1 real part, 2 imaginary part (time-harmonic only)
!       PSI    phase angle (rad);  FREQ frequency (Hz = 1/s)
!       T0     total time at the start of the increment (s)
!       DT     time increment (s)
!       W      returned factor that multiplies the amplitude
!
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (TWOPI=6.283185307179586D0)
      IF (IPROC .EQ. 1) THEN
         IF (IPHASE .EQ. 1) THEN
            W = COS(PSI)
         ELSE
            W = SIN(PSI)
         END IF
      ELSE IF (IPROC .EQ. 2) THEN
!        backward Euler: the load belongs to the END of the increment
         W = COS(TWOPI*FREQ*(T0 + DT) + PSI)
      ELSE
         W = 1.D0
      END IF
      RETURN
      END
