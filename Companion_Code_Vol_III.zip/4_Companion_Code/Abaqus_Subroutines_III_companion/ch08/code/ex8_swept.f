!     HIT = .TRUE. if the path between arc lengths S0 and S1 passes
!     within AHW of the box (plus half its diagonal): only such
!     elements can receive material in this increment.
      SUBROUTINE K8_SWEPT(BX, S0, S1, HIT)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION BX(6)
      LOGICAL HIT
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      XC = 0.5D0*(BX(1)+BX(2))
      YC = 0.5D0*(BX(3)+BX(4))
      RR = AHW + 0.5D0*SQRT((BX(2)-BX(1))**2 + (BX(4)-BX(3))**2)
      HIT = .FALSE.
      IF (BX(5) .GE. BHT) RETURN
      DO K = 1, NSEG
         SL = CUM(K) - CUM(K-1)
         TA = MAX(0.D0, (S0 - CUM(K-1))/SL)
         TB = MIN(1.D0, (S1 - CUM(K-1))/SL)
         IF (TB .LT. TA) CYCLE
         QX = PX(K-1) + TA*(PX(K)-PX(K-1))
         QY = PY(K-1) + TA*(PY(K)-PY(K-1))
         EX = (TB-TA)*(PX(K)-PX(K-1))
         EY = (TB-TA)*(PY(K)-PY(K-1))
         EE = EX**2 + EY**2
         T  = 0.D0
         IF (EE .GT. 0.D0) T = ((XC-QX)*EX + (YC-QY)*EY)/EE
         T  = MAX(0.D0, MIN(1.D0, T))
         IF (SQRT((XC-QX-T*EX)**2 + (YC-QY-T*EY)**2) .LT. RR) THEN
            HIT = .TRUE.
            RETURN
         ENDIF
      ENDDO
      RETURN
      END
