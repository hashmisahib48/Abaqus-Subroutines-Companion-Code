      SUBROUTINE UEPACTIVATIONFACET(
     1 LFLAG, EPANAME, NOEL, NELEMNODES, IELEMNODES,
     2 MCRD, COORDNODES, UNODES, KSTEP, KINC,
     3 TIME, DT, TEMP, NPREDEF, PREDEF,
     4 NSVARS, SVARS, SOL, SOLINC,
     5 NELEMFACETS, NFACETNODES, JFACETNODES,
     6 VOLFRACT, VOLFRACTADDED, AREAFACETOLD, AREACUTOLD,
     7 NEVENTS,
     8 DELTAAREAFACET, DELTAAREAFACETCSI, DELTAAREAFACETTIME,
     9 AREACUT, AREACUTCSI, AREACUTTIME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      PARAMETER (NEVENTSMAX = 1000)
      CHARACTER*80 EPANAME
      DIMENSION IELEMNODES(NELEMNODES),
     1 COORDNODES(MCRD,NELEMNODES), UNODES(MCRD,NELEMNODES),
     2 TIME(2), SVARS(NSVARS,2), TEMP(2,NELEMNODES),
     3 PREDEF(2,NPREDEF,NELEMNODES), SOL(NELEMNODES),
     4 SOLINC(NELEMNODES), JFACETNODES(NFACETNODES,*),
     5 VOLFRACT(*), VOLFRACTADDED(*), AREAFACETOLD(NELEMFACETS),
     6 DELTAAREAFACET(NELEMFACETS,NEVENTSMAX),
     7 DELTAAREAFACETCSI(MCRD,NELEMFACETS,NEVENTSMAX),
     8 DELTAAREAFACETTIME(NELEMFACETS,NEVENTSMAX),
     9 AREACUT(NEVENTSMAX), AREACUTCSI(MCRD,NEVENTSMAX),
     1 AREACUTTIME(NEVENTSMAX)
      DIMENSION BX(6), RUN(6), FM0(3,6), XM(3), CUTM(3), DA(6)
      DIMENSION DCSI(3,6), IFAX(6), IFEND(6)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      NEVENTS = 0
      IF (VOLFRACT(1) + VOLFRACTADDED(1) .LE. 0.D0) RETURN
      CALL K8_BOX(NELEMNODES, MCRD, COORDNODES, BX)
      PLEN = CUM(NSEG)
      S0 = MIN(VEL*TIME(1), PLEN)
      S1 = MIN(VEL*(TIME(1) + DT), PLEN)
!     axis and end of every facet from its connectivity: the
!     coordinate that is the same at all facet nodes is the normal
      DO IFAC = 1, NELEMFACETS
         DO K = 1, 3
            CMIN =  1.D30
            CMAX = -1.D30
            DO J = 1, NFACETNODES
               CC = COORDNODES(K, JFACETNODES(J,IFAC))
               CMIN = MIN(CMIN, CC)
               CMAX = MAX(CMAX, CC)
            ENDDO
            IF (CMAX - CMIN .LT. 1.D-9*(BX(2*K)-BX(2*K-1))) THEN
               IFAX(IFAC)  = K
               IFEND(IFAC) = 1
               IF (CMIN .GT. 0.5D0*(BX(2*K-1)+BX(2*K))) IFEND(IFAC)=2
            ENDIF
         ENDDO
      ENDDO
!     state at the start of the increment
      DO IFAC = 1, NELEMFACETS
         RUN(IFAC) = AREAFACETOLD(IFAC)
         FM0(1,IFAC) = 0.D0
         FM0(2,IFAC) = 0.D0
         FM0(3,IFAC) = 0.D0
         IF (VOLFRACT(1) .GT. 0.D0) THEN
            CALL K8_FCOV(BX, IFAX(IFAC), IFEND(IFAC), S0, C0, XM)
            FM0(1,IFAC) = XM(1)
            FM0(2,IFAC) = XM(2)
            FM0(3,IFAC) = XM(3)
         ENDIF
      ENDDO
      CUT0 = AREACUTOLD
!     NSUB events of equal duration; an event is kept if it changes
!     a facet or the cut. Exposure time = end of increment - event.
      DO K = 1, NSUB
         SK  = S0 + (S1-S0)*K/NSUB
         TAU = DT*(1.D0 - (K-0.5D0)/NSUB)
         CHG = 0.D0
         DO IFAC = 1, NELEMFACETS
            CALL K8_FCOV(BX, IFAX(IFAC), IFEND(IFAC), SK, C1, XM)
            C1 = MAX(C1, RUN(IFAC))
            DA(IFAC) = C1 - RUN(IFAC)
            DO L = 1, 3
               DCSI(L,IFAC) = 0.D0
               IF (DA(IFAC) .GT. 1.D-10)
     1            DCSI(L,IFAC) = (XM(L) - FM0(L,IFAC))/DA(IFAC)
            ENDDO
            IF (DA(IFAC) .GT. 1.D-10) THEN
               CHG = 1.D0
               RUN(IFAC) = C1
               FM0(1,IFAC) = XM(1)
               FM0(2,IFAC) = XM(2)
               FM0(3,IFAC) = XM(3)
            ELSE
               DA(IFAC) = 0.D0
            ENDIF
         ENDDO
         CALL K8_CUTA(BX, SK, CUT1, CUTM)
         IF (ABS(CUT1-CUT0) .GT. 1.D-10) CHG = 1.D0
         IF (CHG .GT. 0.D0) THEN
            NEVENTS = NEVENTS + 1
            DO IFAC = 1, NELEMFACETS
               DELTAAREAFACET(IFAC,NEVENTS) = DA(IFAC)
               DELTAAREAFACETTIME(IFAC,NEVENTS) = TAU
               DO L = 1, 3
                  DELTAAREAFACETCSI(L,IFAC,NEVENTS) = DCSI(L,IFAC)
               ENDDO
            ENDDO
            AREACUT(NEVENTS)     = CUT1
            AREACUTTIME(NEVENTS) = TAU
            DO L = 1, 3
               AREACUTCSI(L,NEVENTS) = 0.D0
               IF (CUT1 .GT. 0.D0) AREACUTCSI(L,NEVENTS)=CUTM(L)/CUT1
            ENDDO
            CUT0 = CUT1
         ENDIF
      ENDDO
      RETURN
      END
