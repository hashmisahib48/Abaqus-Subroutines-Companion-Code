#!/bin/sh
# compile every listing and driver of Chapter 8 (gfortran 13, stubs from lib/aba)
cd /home/claude/vol3/ch08/code && python3 gen.py
I=/home/claude/vol3/lib/aba; B=/home/claude/vol3/ch08/verify/bin; mkdir -p $B
F="-std=legacy -ffixed-form -I$I"
for f in ex8_geom ex8_uepvol ex8_uepfacet ex8_uepsetup ex8_swept prob_8b2; do gfortran -c $F $f.f -o $B/$f.o || exit 1; done
gfortran $F -O2 k8_drv.f $B/ex8_geom.o $B/ex8_uepvol.o $B/ex8_uepfacet.o $B/ex8_uepsetup.o $B/ex8_swept.o $I/stubs.f -o $B/k8_drv || exit 1
echo built
