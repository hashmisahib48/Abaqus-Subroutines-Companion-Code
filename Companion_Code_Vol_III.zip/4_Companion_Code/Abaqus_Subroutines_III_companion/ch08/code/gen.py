# expands the shared COMMON block into the Fortran sources (src/*.src -> *.f)
import sys,os,glob
BLK='''      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD'''
for f in glob.glob('src/*.src'):
    t=open(f).read().replace("      @K8COMMON@",BLK)
    open(os.path.basename(f)[:-4]+'.f','w').write(t)
