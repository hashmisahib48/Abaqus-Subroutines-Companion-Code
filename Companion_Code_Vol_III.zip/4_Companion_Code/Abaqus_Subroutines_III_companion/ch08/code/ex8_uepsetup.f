      SUBROUTINE UEPACTIVATIONSETUP(LOP, EPANAME, EPAELSETNAME,
     1 JACTIVATINGELEMS, NACTIVATINGELEMS, KSTEP, KINC, TIME, DTIME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION JACTIVATINGELEMS(NACTIVATINGELEMS), TIME(2), DTIME(2)
      CHARACTER*80 EPANAME, EPAELSETNAME
      DIMENSION BX(6)
      LOGICAL HIT
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
!     LOP = 1: start of step, read the toolpath. LOP = 2: start of an
!     increment, thin out the list and limit the advance per increment
      IF (LOP .EQ. 1) THEN
         CALL K8_LOAD(IERR)
         IF (IERR .NE. 0) THEN
            WRITE(*,*) 'EPA_PATH.DAT not found'
            CALL XIT
         ENDIF
         RETURN
      ENDIF
      PLEN = CUM(NSEG)
      ADV  = VEL*DTIME(1)
      DTIME(2) = 1.D0
      IF (ADV .GT. DEL(1)) DTIME(2) = DEL(1)/ADV
      S0 = VEL*TIME(1)
      S1 = MIN(VEL*(TIME(1) + DTIME(1)*DTIME(2)), PLEN)
      IF (S1 .GE. PLEN) RETURN
      NKEEP = 0
      DO K = 1, NACTIVATINGELEMS
         IEL = JACTIVATINGELEMS(K) - NEL0
         IX  = MOD(IEL, NXYZ(1))
         IY  = MOD(IEL/NXYZ(1), NXYZ(2))
         IZ  = IEL/(NXYZ(1)*NXYZ(2))
         BX(1) = XORG(1) + IX*DEL(1)
         BX(2) = BX(1) + DEL(1)
         BX(3) = XORG(2) + IY*DEL(2)
         BX(4) = BX(3) + DEL(2)
         BX(5) = XORG(3) + IZ*DEL(3)
         BX(6) = BX(5) + DEL(3)
         CALL K8_SWEPT(BX, S0, S1, HIT)
         IF (HIT) THEN
            NKEEP = NKEEP + 1
            JACTIVATINGELEMS(NKEEP) = JACTIVATINGELEMS(K)
         ENDIF
      ENDDO
      NACTIVATINGELEMS = NKEEP
      RETURN
      END
