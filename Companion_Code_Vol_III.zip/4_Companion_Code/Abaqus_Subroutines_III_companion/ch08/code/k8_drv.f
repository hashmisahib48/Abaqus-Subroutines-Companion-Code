!     Driver: calls the three routines as Abaqus would, increment by
!     increment, on a block of NX*NY*NZ bricks (chapter 8, section
!     8.9). Reads DT from standard input. Writes
!       vf_hist.csv  : inc, time, S1, element, VOLFRACT   (VF > 0)
!       fac_final.csv: element, 6 facet fractions, 6 time integrals,
!                      cut area, cut time integral, NEVENTS total
!       mass.csv     : inc, time, S1, mass (mm^3), listed elements
      PROGRAM K8_DRV
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NEVENTSMAX = 1000, MAXEL = 20000)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      DIMENSION LFLAGS(4), IELEMNODES(8), COORD(3,8), UNODES(3,8)
      DIMENSION TIME(2), TEMP(2,8), PREDEF(2,1,8), SVARS(1,2)
      DIMENSION SOL(8), SOLINC(8), VOLFRACT(1), VFADD(1), CSIADD(3,1)
      DIMENSION ORI(3,3), EIGEN(6), DTV(2)
      DIMENSION JFN(4,6), AFOLD(6), DAF(6,NEVENTSMAX)
      DIMENSION DCSI(3,6,NEVENTSMAX), DAT(6,NEVENTSMAX)
      DIMENSION CUTE(NEVENTSMAX), CCSI(3,NEVENTSMAX), CTT(NEVENTSMAX)
      DIMENSION VF(MAXEL), AF(6,MAXEL), AINT(6,MAXEL), CUTO(MAXEL)
      DIMENSION CINT(MAXEL), NEVT(MAXEL), LIST(MAXEL), AFB(6,MAXEL)
      DIMENSION CUTB(MAXEL)
      CHARACTER*80 EPANAME, ESET
      DATA JFN /1,2,3,4, 5,8,7,6, 1,5,6,2, 2,6,7,3, 3,7,8,4, 4,8,5,1/
      READ(*,*) DT0
      EPANAME = 'BEAD1'
      ESET = 'DEPOSIT'
      IREAD = 0
      CALL UEPACTIVATIONSETUP(1, EPANAME, ESET, LIST, 0, 1, 0,
     1                        TIME, DTV)
      NEL = NXYZ(1)*NXYZ(2)*NXYZ(3)
      PLEN = CUM(NSEG)
      DO IE = 1, NEL
         VF(IE) = 0.D0
         CUTO(IE) = 0.D0
         CINT(IE) = 0.D0
         NEVT(IE) = 0
         DO IFC = 1, 6
            AF(IFC,IE) = 0.D0
            AINT(IFC,IE) = 0.D0
         ENDDO
      ENDDO
      OPEN(61, FILE='vf_hist.csv')
      OPEN(62, FILE='mass.csv')
      OPEN(64, FILE='events.csv')
      T = 0.D0
      KINC = 0
      VEL1 = VEL
      DO WHILE (VEL*T .LT. PLEN - 1.D-12)
         KINC = KINC + 1
         NL = NEL
         DO IE = 1, NEL
            LIST(IE) = NEL0 + IE - 1
         ENDDO
         DTV(1) = DT0
         TIME(1) = T
         TIME(2) = T
         CALL UEPACTIVATIONSETUP(2, EPANAME, ESET, LIST, NL, 1, KINC,
     1                           TIME, DTV)
         DT = DTV(1)*DTV(2)
!        exposure of the state at the start of the increment
         DO IE = 1, NEL
            CUTB(IE) = CUTO(IE)
            CINT(IE) = CINT(IE) + CUTO(IE)*DT
            DO IFC = 1, 6
               AINT(IFC,IE) = AINT(IFC,IE) + AF(IFC,IE)*DT
            ENDDO
         ENDDO
         DO IL = 1, NL
            IE = LIST(IL) - NEL0 + 1
            IX = MOD(IE-1, NXYZ(1))
            IY = MOD((IE-1)/NXYZ(1), NXYZ(2))
            IZ = (IE-1)/(NXYZ(1)*NXYZ(2))
            X0 = XORG(1) + IX*DEL(1)
            Y0 = XORG(2) + IY*DEL(2)
            Z0 = XORG(3) + IZ*DEL(3)
            X1 = X0 + DEL(1)
            Y1 = Y0 + DEL(2)
            Z1 = Z0 + DEL(3)
            DO IN = 1, 8
               IELEMNODES(IN) = IN
            ENDDO
            COORD(1,1) = X0
            COORD(2,1) = Y0
            COORD(3,1) = Z0
            COORD(1,2) = X1
            COORD(2,2) = Y0
            COORD(3,2) = Z0
            COORD(1,3) = X1
            COORD(2,3) = Y1
            COORD(3,3) = Z0
            COORD(1,4) = X0
            COORD(2,4) = Y1
            COORD(3,4) = Z0
            DO IN = 1, 4
               COORD(1,IN+4) = COORD(1,IN)
               COORD(2,IN+4) = COORD(2,IN)
               COORD(3,IN+4) = Z1
            ENDDO
            VOLFRACT(1) = VF(IE)
            VFADD(1) = 0.D0
            CALL UEPACTIVATIONVOL(LFLAGS, EPANAME, LIST(IL), 8,
     1        IELEMNODES, 3, COORD, UNODES, 1, KINC, TIME, DT, TEMP,
     2        0, PREDEF, 1, SVARS, SOL, SOLINC, VOLFRACT, 0, VFADD,
     3        CSIADD, ORI, EIGEN)
            DO IFC = 1, 6
               AFOLD(IFC) = AF(IFC,IE)
            ENDDO
            CALL UEPACTIVATIONFACET(2, EPANAME, LIST(IL), 8,
     1        IELEMNODES, 3, COORD, UNODES, 1, KINC, TIME, DT, TEMP,
     2        0, PREDEF, 1, SVARS, SOL, SOLINC, 6, 4, JFN, VOLFRACT,
     3        VFADD, AFOLD, CUTO(IE), NEV, DAF, DCSI, DAT, CUTE, CCSI,
     4        CTT)
!           accumulate: facet fractions, time integrals of the area
            DO IV = 1, NEV
               DO IFC = 1, 6
                  AF(IFC,IE) = AF(IFC,IE) + DAF(IFC,IV)
                  AINT(IFC,IE) = AINT(IFC,IE) +
     1                           DAF(IFC,IV)*DAT(IFC,IV)
               ENDDO
            ENDDO
            NEVT(IE) = NEVT(IE) + NEV
            DO IV = 1, NEV
               WRITE(64,'(I5,2(",",I6),9(",",ES13.5))') KINC, IE, IV,
     1           (DAF(IFC,IV),IFC=1,6), DAT(1,IV), CUTE(IV), T
            ENDDO
!           cut: integral of area = old*dt + sum of changes*tau
            CPREV = CUTO(IE)
            CI = 0.D0
            DO IV = 1, NEV
               CI = CI + (CUTE(IV)-CPREV)*CTT(IV)
               CPREV = CUTE(IV)
            ENDDO
            IF (NEV .GT. 0) CUTO(IE) = CPREV
            CINT(IE) = CINT(IE) + CI
            VF(IE) = VF(IE) + VFADD(1)
         ENDDO
         T = T + DT
!        elements outside the list keep their cut area for the time
!        integral (they are idle)
         DO IE = 1, NEL
            IF (VF(IE) .GT. 0.D0) WRITE(61,'(I5,",",F9.5,",",F9.5,
     1        ",",I6,",",F10.7)') KINC, T, MIN(VEL*T,PLEN), IE, VF(IE)
         ENDDO
         RMASS = 0.D0
         DO IE = 1, NEL
            RMASS = RMASS + VF(IE)*DEL(1)*DEL(2)*DEL(3)
         ENDDO
         WRITE(62,'(I5,",",F9.5,",",F9.5,",",F12.6,",",I6)') KINC, T,
     1        MIN(VEL*T,PLEN), RMASS, NL
      ENDDO
      OPEN(63, FILE='fac_final.csv')
      DO IE = 1, NEL
         IF (VF(IE) .GT. 0.D0)
     1     WRITE(63,'(I6,15(",",ES14.6))') IE, (AF(K,IE),K=1,6),
     2        (AINT(K,IE),K=1,6), CUTO(IE), CINT(IE), VF(IE)
      ENDDO
      WRITE(*,'(A,I5,A,F9.5)') ' increments:', KINC, '  final time', T
      END
