      SUBROUTINE UEPACTIVATIONVOL(LFLAGS,
     1 EPANAME, NOEL, NELEMNODES, IELEMNODES,
     2 MCRD, COORDNODES, UNODES,
     3 KSTEP, KINC, TIME, DTIME, TEMP,
     4 NPREDEF, PREDEF, NSVARS, SVARS,
     5 SOL, SOLINC,
     6 VOLFRACT, NVOLUMEADDEVENTS, VOLFRACTADDED,
     7 CSIADDED, ORI, EIGENSTRAINS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION LFLAGS(*), IELEMNODES(NELEMNODES),
     1 COORDNODES(MCRD,NELEMNODES), UNODES(MCRD,NELEMNODES),
     2 TIME(2), SVARS(NSVARS,2), TEMP(2,NELEMNODES),
     3 PREDEF(2,NPREDEF,NELEMNODES), SOL(NELEMNODES),
     4 SOLINC(NELEMNODES), VOLFRACT(*), VOLFRACTADDED(*),
     5 CSIADDED(3,*), ORI(3,3), EIGENSTRAINS(*)
      CHARACTER*80 EPANAME
      DIMENSION BX(6)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
!     Bead of half-ellipse section along the path of EPA_PATH.DAT.
!     The target fraction of the element at the END of the increment
!     is computed from the nozzle position S1 = VEL*(t + dt); the
!     fraction added is target minus VOLFRACT, so that a cut-back
!     or a restart needs no memory in the routine.
      VOLFRACTADDED(1) = 0.D0
      LFLAGS(4) = 0
      IF (IREAD .EQ. 0) CALL K8_LOAD(IERR)
      CALL K8_BOX(NELEMNODES, MCRD, COORDNODES, BX)
      PLEN = CUM(NSEG)
      S1   = MIN(VEL*(TIME(1) + DTIME), PLEN)
      CALL K8_VOLF(BX, S1, FT)
      DF = FT - VOLFRACT(1)
      IF (DF .LT. 0.D0) DF = 0.D0
!     no sliver on first activation, except in the last increment
      IF (VOLFRACT(1) .LE. 0.D0) THEN
         IF (S1 .LT. PLEN .AND. DF .LT. FMIN) DF = 0.D0
         IF (S1 .GE. PLEN .AND. DF .LT. 0.1D0*FMIN) DF = 0.D0
      ENDIF
      VOLFRACTADDED(1) = DF
      RETURN
      END
