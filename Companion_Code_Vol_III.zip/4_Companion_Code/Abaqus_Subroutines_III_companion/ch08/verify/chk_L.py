import sys; sys.path.insert(0,'.')
from lib8 import *
import time
P=PL; L1,L2=7.8,5.1; Ltot=12.9
incs=(12,24,33); S_list=[min(V*0.04*i,Ltot) for i in incs]
t0=time.time(); mcv,tot=mc_vf(P,S_list,N=48_000_000); print('MC time',time.time()-t0,flush=True)
rows=read_hist('caseL'); np.save('mcL.npy',mcv)
for q,inc in enumerate(incs):
    vf=vf_at(rows,inc); err=vf-mcv[q]; sig=np.sqrt(np.maximum(mcv[q]*(1-mcv[q]),1e-12)/np.maximum(tot,1))
    z=err[1:]/np.maximum(sig[1:],1e-4)
    print(inc,S_list[q],'max|err| %.4f  rms %.5f  max|z| %.2f  mass routine %.4f  MC %.4f'%(np.abs(err[1:]).max(),np.sqrt((err[1:]**2).mean()),np.abs(z).max(),vf[1:].sum()*DX*DY*DZ,(mcv[q][1:]*DX*DY*DZ).sum()),' closed form',vol_L(L1,L2) if S_list[q]>=Ltot else '')
