import sys,json; sys.path.insert(0,'.')
from lib8 import *
from conv_S import EX, interior, exact_el, chord, nstar
np.set_printoptions(precision=5,suppress=True,linewidth=150)
a,b=A,B; L1,L2=7.8,5.1
print('section area (pi/2)ab = %.4f mm2; rate at v=10: %.3f mm3/s; mdot(rho 8.0e-9) = %.4e t/s = %.3f g/min'%(np.pi/2*a*b,np.pi/2*a*b*10,np.pi/2*a*b*10*8e-9,np.pi/2*a*b*10*8e-9*1e6*60))
print('dome pair (2pi/3)a2b %.4f ; start dome pi/3 a2 b %.4f; corner pieces: strips %.4f  inner -%.4f  sector %.4f  ends %.4f'%(2*np.pi/3*a*a*b,np.pi/3*a*a*b,np.pi/2*a*b*(L1+L2),2/3*a*a*b,np.pi/6*a*a*b,2*np.pi/3*a*a*b))
print('closed straight L=9.6: %.5f   closed L: %.5f'%(vol_straight(9.6),vol_L(L1,L2)))
print('Earc %.5f  J %.5f ; surf straight %.4f ; surf L %.4f'%(Earc(),Jint(),surf_straight(9.6),surf_L(L1,L2)))
# straight: per-increment checks against exactS
rows=read_hist('caseS'); ex=np.load('exactS.npz'); xs,L=1.3,9.6
for inc in (6,12,24):
    S=min(0.4*inc,L); vf=vf_at(rows,inc)[1:]; e=ex['i%d'%inc]; err=vf-e
    front=np.array([elem_box(i)[0]<xs+S<elem_box(i)[1] for i in range(1,NX*NY*NZ+1)])
    nz_exact=(e>0)&(vf==0)
    print('S=%.1f: max|err| %.5f rms %.6f | front elems max %.5f | others max %.5f | n elems exact>0 but VF=0: %d (max exact %.4f) | mass %.5f exact %.5f'%(S,np.abs(err).max(),np.sqrt((err**2).mean()),np.abs(err[front]).max(),np.abs(err[~front&~nz_exact]).max(),nz_exact.sum(),e[nz_exact].max() if nz_exact.any() else 0,vf.sum()*.1,e.sum()*.1))
# element 541 facets
d='caseS'; fac=read_fac(d); r=fac[541]; cov,I,cut,Ic=EX[541]
print('el 541 box',elem_box(541)); print(' cov routine',r[0:6],'exact',cov); print(' int routine',r[6:12],'exact',I); print(' cut routine %.5f exact %.5f ; int cut routine %.5f exact %.5f'%(r[12],cut,r[13],Ic))
fa=np.array([0.5*0.5,0.5*0.5,0.5*0.4,0.5*0.4,0.5*0.4,0.5*0.4]) # facet areas mm2: z0,z1,y0,x1,y1,x0 -> dx*dy, dx*dy, dx*dz, dy*dz, dx*dz, dy*dz
fa=np.array([0.25,0.25,0.2,0.2,0.2,0.2])
Qr=10*(r[6:12]*fa).sum(); Qe=10*(I*fa).sum(); print(' facets: sum A*dt routine %.5f exact %.5f mm2 s ; Q(10 mW/mm2) routine %.4f exact %.4f mJ'%((r[6:12]*fa).sum(),(I*fa).sum(),Qr,Qe))
print(' cut: Q routine %.4f exact %.4f mJ'%(10*r[13],10*Ic))
E=np.loadtxt('caseS/events.csv',delimiter=','); m=E[:,1]==541; print(' events of 541 (inc, iv, dA3, dA5, tau, cut):'); print(np.c_[E[m,0],E[m,2],E[m,5],E[m,7],E[m,9],E[m,10]])
# convergence table
J=json.load(open('conv_S.json'))
for o in J: print('nc %3d ns %2d vmax %.2e vrms %.2e mass_err %+.2e cov %.2e I %.2e cut %.2e Icut %.2e'%(o['nc'],o['ns'],o['vmax'],o['vrms'],o['mass_err'],o['cov'],o['I'],o['cut'],o['Icut']))
# deferral
for fm in ('1e-09','0.01','0.05','0.1'):
    rows=read_hist('defL_%s'%fm); first={}
    for rr in rows:
        e_=int(rr[3]); 
        if e_ not in first: first[e_]=(rr[4],rr[0])
    fv=np.array([v for v,k in first.values() if k<33]); vf=vf_at(rows,33)
    print('FMIN %s: mass %.5f deficit %.2e rel %.1e ; elements %d ; smallest first fraction before final inc %.4f; n first<0.05: %d'%(fm,vf.sum()*.1,vol_L(L1,L2)-vf.sum()*.1,(vol_L(L1,L2)-vf.sum()*.1)/vol_L(L1,L2),len(first),fv.min(),(fv<0.05).sum()))
M=np.loadtxt('caseL/mass.csv',delimiter=','); print('listed elements per increment: min %d max %d (of 768) ; last %d'%(M[:-1,4].min(),M[:-1,4].max(),M[-1,4]))
