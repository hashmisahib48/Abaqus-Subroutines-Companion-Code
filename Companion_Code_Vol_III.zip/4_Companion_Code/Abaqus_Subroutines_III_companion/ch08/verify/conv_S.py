import sys,subprocess,os,json; sys.path.insert(0,'.')
from lib8 import *
L=9.6; xs,xe,yc=1.3,10.9,3.1; TEND=0.96
def nstar(z): return A*np.sqrt(max(1-(z/B)**2,0)) if z<B else 0.0
def chord(y0,y1,z):
    n=nstar(z); lo=max(y0,yc-n); hi=min(y1,yc+n); return max(hi-lo,0)
def exact_el(ie):
    x0,x1,y0,y1,z0,z1=elem_box(ie); dx,dy,dz=x1-x0,y1-y0,z1-z0; Lx=x1-x0
    cov=np.zeros(6); cov[0]=Lx*chord(y0,y1,z0)/(dx*dy); cov[1]=Lx*chord(y0,y1,z1)/(dx*dy)
    for f,yy in ((2,y0),(4,y1)):
        h=float(Hh(abs(yy-yc))); cov[f]=max(min(z1,h)-z0,0)/dz
    cov[3]=cov[5]=area_rect(y0-yc,y1-yc,z0,z1)/(dy*dz)
    t0=(x0-xs)/V; t1=(x1-xs)/V
    ramp=(TEND-t1)+(t1-t0)/2; step4=TEND-t1; step6=TEND-t0   # facet 4 at x1, facet 6 at x0
    I=cov*ramp; I[3]=cov[3]*step4; I[5]=cov[5]*step6
    cut=Lx*arc_rect(y0-yc,y1-yc,z0,z1); Icut=cut*ramp
    return cov,I,cut,Icut
interior=[ie for ie in range(1,NX*NY*NZ+1) if elem_box(ie)[0]>=xs-1e-9 and elem_box(ie)[1]<=xe+1e-9 and elem_box(ie)[2]<yc+A and elem_box(ie)[3]>yc-A and elem_box(ie)[4]<B]
EX={ie:exact_el(ie) for ie in interior}
def study(nc,ns,fm=1e-9):
    d='conv_S_%d_%d'%(nc,ns); subprocess.run(['./mkcase.sh',d,str(nc),str(ns),str(fm)],check=True)
    subprocess.run('cd %s && echo 0.04 | ../bin/k8_drv > out.txt'%d,shell=True,check=True)
    rows=read_hist(d); vf=vf_at(rows,24); fac=read_fac(d)
    ex=np.load('exactS.npz')['i24']; ev=np.abs(vf[1:]-ex)
    # restrict volume comparison to the same exact reference
    ecov=0;eI=0;ecut=0;eIc=0;rI=0;rIc=0
    for ie in interior:
        cov,I,cut,Ic=EX[ie]; r=fac.get(ie)
        if r is None: r=np.zeros(15)
        ecov=max(ecov,np.abs(r[0:6]-cov).max()); eI=max(eI,np.abs(r[6:12]-I).max())
        ecut=max(ecut,abs(r[12]-cut)); eIc=max(eIc,abs(r[13]-Ic))
    mass_r=vf[1:].sum()*DX*DY*DZ
    return dict(nc=nc,ns=ns,vmax=ev.max(),vrms=np.sqrt((ev**2).mean()),mass_err=mass_r-vol_straight(L),cov=ecov,I=eI,cut=ecut,Icut=eIc)
if __name__=='__main__':
    out=[]
    for nc in (4,8,16,32,64,128):
        o=study(nc,4); out.append(o); print(o,flush=True)
    for ns in (1,2,8,16):
        o=study(32,ns); out.append(o); print(o,flush=True)
    json.dump(out,open('conv_S.json','w'),default=float)
