!     Chapter 8: bead geometry helpers (prefix K8_). Units mm, s.
!     Bead: half-ellipse section, half-width AHW, height BHT, on the
!     substrate z = 0. Point (x,y,z) belongs to the bead built up to
!     path position S if its nearest path point has arc length <= S,
!     its distance D to the path is < AHW and 0 <= z <= H(D), where
!     H(D) = BHT*SQRT(1 - (D/AHW)**2).
      SUBROUTINE K8_LOAD(IERR)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      CHARACTER*256 OUTDIR, FNAME
      CALL GETOUTDIR(OUTDIR, LENOUT)
      FNAME = OUTDIR(1:LENOUT)//'/epa_path.dat'
      OPEN(UNIT=79, FILE=FNAME, STATUS='OLD', ERR=90)
      READ(79,*) AHW, BHT, VEL, FMIN, NCOL, NSUB
      READ(79,*) (NXYZ(K),K=1,3), (DEL(K),K=1,3), (XORG(K),K=1,3),
     1           NEL0
      READ(79,*) NSEG
      READ(79,*) (PX(K), PY(K), K=0,NSEG)
      CLOSE(79)
      CUM(0) = 0.D0
      DO K = 1, NSEG
         CUM(K) = CUM(K-1) + SQRT((PX(K)-PX(K-1))**2 +
     1                            (PY(K)-PY(K-1))**2)
      ENDDO
      IREAD = 1
      IERR  = 0
      RETURN
   90 IERR = 1
      RETURN
      END
!
!     Bead profile: height H at distance D from the path axis, and
!     the inverse, the half-width at height Z. Replace both (and
!     BHT, AHW) for a bead of another section; K8_CUTA assumes the
!     half-ellipse.
      DOUBLE PRECISION FUNCTION K8_H(D)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (RCIRC = 1.0D0, CCIRC = 0.6D0)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      K8_H = 0.D0
      IF (D .LT. AHW) K8_H = SQRT(RCIRC**2 - D**2) - CCIRC
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION K8_NSTAR(Z)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (RCIRC = 1.0D0, CCIRC = 0.6D0)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      K8_NSTAR = 0.D0
      IF (Z .LT. BHT) K8_NSTAR = SQRT(RCIRC**2 - (Z+CCIRC)**2)
      RETURN
      END
!
!     Distance D from (X,Y) to the path, arc length SS of the nearest
!     path point (first segment wins a tie), and the unit gradients
!     GD of D and GS of SS (GS = 0 where SS is locally constant).
      SUBROUTINE K8_NEARG(X, Y, D, SS, GD, GS)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION GD(2), GS(2)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      D = 1.D30
      SS = 0.D0
      GD(1) = 0.D0
      GD(2) = 0.D0
      GS(1) = 0.D0
      GS(2) = 0.D0
      DO K = 1, NSEG
         EX = PX(K) - PX(K-1)
         EY = PY(K) - PY(K-1)
         SL = CUM(K) - CUM(K-1)
         T0 = ((X-PX(K-1))*EX + (Y-PY(K-1))*EY)/SL**2
         T  = MAX(0.D0, MIN(1.D0, T0))
         QX = X - PX(K-1) - T*EX
         QY = Y - PY(K-1) - T*EY
         DD = SQRT(QX**2 + QY**2)
         IF (DD .LT. D - 1.D-12) THEN
            D  = DD
            SS = CUM(K-1) + T*SL
            GD(1) = 0.D0
            GD(2) = 0.D0
            IF (DD .GT. 1.D-12) THEN
               GD(1) = QX/DD
               GD(2) = QY/DD
            ENDIF
            GS(1) = 0.D0
            GS(2) = 0.D0
            IF (T0 .GT. 0.D0 .AND. T0 .LT. 1.D0) THEN
               GS(1) = EX/SL
               GS(2) = EY/SL
            ENDIF
         ENDIF
      ENDDO
      RETURN
      END
!
      SUBROUTINE K8_NEAR(X, Y, D, SS)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION GD(2), GS(2)
      CALL K8_NEARG(X, Y, D, SS, GD, GS)
      RETURN
      END
!
!     Weight of a column for the advancing front: 1 once the whole
!     path is done (the front is then replaced by the end dome)
      DOUBLE PRECISION FUNCTION K8_FW(S, SS, G1, G2, H1, H2)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      DOUBLE PRECISION K8_WT
      IF (S .GE. CUM(NSEG) - 1.D-12) THEN
         K8_FW = 1.D0
      ELSE
         K8_FW = K8_WT(S-SS, G1, G2, H1, H2)
      ENDIF
      RETURN
      END
!
!     Fraction of a cell (sides H1, H2) on the positive side of a
!     straight edge: PHI = signed distance of the cell centre, G1,
!     G2 = components of the edge normal.
      DOUBLE PRECISION FUNCTION K8_WT(PHI, G1, G2, H1, H2)
      INCLUDE 'ABA_PARAM.INC'
      HE = ABS(G1)*H1 + ABS(G2)*H2
      IF (HE .LT. 1.D-12) THEN
         K8_WT = 0.D0
         IF (PHI .GE. -1.D-9) K8_WT = 1.D0
      ELSE
         K8_WT = MAX(0.D0, MIN(1.D0, 0.5D0 + PHI/HE))
      ENDIF
      RETURN
      END
!
!     Bounding box BX = (x0,x1,y0,y1,z0,z1) of the element nodes
!     (elements of the deposit block are axis-aligned bricks).
      SUBROUTINE K8_BOX(NN, MCRD, COORD, BX)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION COORD(MCRD,NN), BX(6)
      DO K = 1, 3
         BX(2*K-1) =  1.D30
         BX(2*K)   = -1.D30
         DO J = 1, NN
            BX(2*K-1) = MIN(BX(2*K-1), COORD(K,J))
            BX(2*K)   = MAX(BX(2*K),   COORD(K,J))
         ENDDO
      ENDDO
      RETURN
      END
!
!     .TRUE. if the box can contain bead material at all
      LOGICAL FUNCTION K8_NEARBOX(BX)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION BX(6)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      XC = 0.5D0*(BX(1)+BX(2))
      YC = 0.5D0*(BX(3)+BX(4))
      HD = 0.5D0*SQRT((BX(2)-BX(1))**2 + (BX(4)-BX(3))**2)
      CALL K8_NEAR(XC, YC, D, SS)
      K8_NEARBOX = (D .LT. AHW + HD) .AND. (BX(5) .LT. BHT)
      RETURN
      END
!
!     Volume fraction F of the box occupied by the bead built up to
!     path position S. Midpoint rule on NCOL x NCOL columns, exact in
!     z; the front s* = S enters each column as a partial weight.
      SUBROUTINE K8_VOLF(BX, S, F)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION BX(6), GD(2), GS(2)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      LOGICAL K8_NEARBOX
      DOUBLE PRECISION K8_WT, K8_FW, K8_H
      F = 0.D0
      IF (.NOT. K8_NEARBOX(BX)) RETURN
      HX = (BX(2)-BX(1))/NCOL
      HY = (BX(4)-BX(3))/NCOL
      SUM = 0.D0
      DO I = 1, NCOL
         X = BX(1) + (I-0.5D0)*HX
         DO J = 1, NCOL
            Y = BX(3) + (J-0.5D0)*HY
            CALL K8_NEARG(X, Y, D, SS, GD, GS)
            H  = K8_H(D)
            ZL = MAX(BX(5), 0.D0)
            ZU = MIN(BX(6), H)
            IF (ZU .GT. ZL) SUM = SUM + (ZU - ZL)*
     1                            K8_FW(S, SS, GS(1), GS(2), HX, HY)
         ENDDO
      ENDDO
      F = SUM*HX*HY/((BX(2)-BX(1))*(BX(4)-BX(3))*(BX(6)-BX(5)))
      RETURN
      END
!
!     Area fraction COV of one facet of the box covered by bead
!     material, and the first moments XM(3) of the covered area in
!     the natural coordinates of the element (divided by the facet
!     area). IAX = axis normal to the facet, IEND = 1 (low) or 2.
      SUBROUTINE K8_FCOV(BX, IAX, IEND, S, COV, XM)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION BX(6), XM(3), P(3), CEN(3), SZ(3), GD(2), GS(2)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      DOUBLE PRECISION K8_WT, K8_FW, K8_H, K8_NSTAR
      DO K = 1, 3
         CEN(K) = 0.5D0*(BX(2*K-1) + BX(2*K))
         SZ(K)  = BX(2*K) - BX(2*K-1)
      ENDDO
      COV = 0.D0
      XM  = 0.D0
      C   = BX(2*IAX-2+IEND)
      P(IAX) = C
      IF (IAX .EQ. 3) THEN
         IF (C .GE. BHT) RETURN
         RC = K8_NSTAR(C)
         HX = SZ(1)/NCOL
         HY = SZ(2)/NCOL
         DO I = 1, NCOL
            P(1) = BX(1) + (I-0.5D0)*HX
            DO J = 1, NCOL
               P(2) = BX(3) + (J-0.5D0)*HY
               CALL K8_NEARG(P(1), P(2), D, SS, GD, GS)
               W = K8_WT(RC-D, GD(1), GD(2), HX, HY)*
     1             K8_FW(S, SS, GS(1), GS(2), HX, HY)/NCOL**2
               COV = COV + W
               XM(1) = XM(1) + W*2.D0*(P(1)-CEN(1))/SZ(1)
               XM(2) = XM(2) + W*2.D0*(P(2)-CEN(2))/SZ(2)
            ENDDO
         ENDDO
         XM(3) = (2*IEND-3)*COV
      ELSE
         IH = 3 - IAX
         HH = SZ(IH)/NCOL
         DO I = 1, NCOL
            P(IH) = BX(2*IH-1) + (I-0.5D0)*HH
            CALL K8_NEARG(P(1), P(2), D, SS, GD, GS)
            H  = K8_H(D)
            ZL = MAX(BX(5), 0.D0)
            ZU = MIN(BX(6), H)
            IF (ZU .GT. ZL) THEN
               IF (IH .EQ. 2) W = K8_FW(S, SS, 0.D0, GS(2), 0.D0, HH)
               IF (IH .EQ. 1) W = K8_FW(S, SS, GS(1), 0.D0, HH, 0.D0)
               FR = W*(ZU-ZL)/SZ(3)/NCOL
               COV = COV + FR
               XM(IH) = XM(IH) + FR*2.D0*(P(IH)-CEN(IH))/SZ(IH)
               XM(3)  = XM(3)  + FR*(ZL+ZU-2.D0*CEN(3))/SZ(3)
            ENDIF
         ENDDO
         XM(IAX) = (2*IEND-3)*COV
      ENDIF
      RETURN
      END
!
!     Narrow the interval [UA,UB] of the parameter U so that
!     LO <= P0 + E*U < HI.
      SUBROUTINE K8_CLIP(P0, E, XLO, XHI, UA, UB)
      INCLUDE 'ABA_PARAM.INC'
      IF (ABS(E) .LT. 1.D-12) THEN
         IF (P0 .LT. XLO .OR. P0 .GE. XHI) UB = UA - 1.D0
      ELSE
         U1 = (XLO-P0)/E
         U2 = (XHI-P0)/E
         UA = MAX(UA, MIN(U1,U2))
         UB = MIN(UB, MAX(U1,U2))
      ENDIF
      RETURN
      END
!
!     Area CUTA (mm^2) of the free bead surface inside the box for
!     the bead built up to S, and its first moment XM(3) / CUTA in
!     natural coordinates. The surface is parametrised by the arc
!     length s and the angle phi of the swept ellipse (n = AHW sin
!     phi, z = BHT cos phi). On straight parts the box limits in z
!     and in the plan are applied analytically; round corners and
!     domes are sampled. A sample is kept if it is nearest to its own
!     path point (this removes the overlap at an inner corner).
      SUBROUTINE K8_CUTA(BX, S, CUTA, XM)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION BX(6), XM(3), CEN(3), SZ(3), P(3)
      PARAMETER (K8MAXV = 50)
      COMMON /K8PTH/ PX(0:K8MAXV), PY(0:K8MAXV), CUM(0:K8MAXV),
     1 AHW, BHT, VEL, FMIN, XORG(3), DEL(3),
     2 NSEG, NCOL, NSUB, NXYZ(3), NEL0, IREAD
      LOGICAL K8_NEARBOX
      PARAMETER (PI = 3.14159265358979D0)
      CUTA = 0.D0
      XM   = 0.D0
      IF (.NOT. K8_NEARBOX(BX)) RETURN
      DO K = 1, 3
         CEN(K) = 0.5D0*(BX(2*K-1) + BX(2*K))
         SZ(K)  = BX(2*K) - BX(2*K-1)
      ENDDO
      DS = MIN(SZ(1), SZ(2))/NCOL
      ZHI = MIN(BX(6), BHT)
      ZLO = MAX(BX(5), 0.D0)
      IF (ZHI .LE. ZLO) RETURN
      PHA = ACOS(ZHI/BHT)
      PHB = ACOS(ZLO/BHT)
      NT  = NCOL
      DPH = (PHB-PHA)/NT
!     straight parts
      DO K = 1, NSEG
         SL = CUM(K) - CUM(K-1)
         EX = (PX(K)-PX(K-1))/SL
         EY = (PY(K)-PY(K-1))/SL
         DO ISG = -1, 1, 2
!           axis-parallel segment: the plan limit of the box acts on
!           n only, so trim the range of phi analytically
            PA = PHA
            PB = PHB
            IF (ABS(EY) .LT. 1.D-12) THEN
               TC = PY(K-1)
               CC = ISG*EX
               TLO = BX(3)
               THI = BX(4)
            ELSEIF (ABS(EX) .LT. 1.D-12) THEN
               TC = PX(K-1)
               CC = -ISG*EY
               TLO = BX(1)
               THI = BX(2)
            ELSE
               CC = 0.D0
            ENDIF
            IF (CC .NE. 0.D0) THEN
               IF (CC .GT. 0.D0) THEN
                  RLO = (TLO-TC)
                  RHI = (THI-TC)
               ELSE
                  RLO = (TC-THI)
                  RHI = (TC-TLO)
               ENDIF
               RLO = MAX(RLO, 0.D0)
               RHI = MIN(RHI, AHW)
               IF (RHI .LE. RLO) CYCLE
               PA = MAX(PA, ASIN(RLO/AHW))
               PB = MIN(PB, ASIN(RHI/AHW))
               IF (PB .LE. PA) CYCLE
            ENDIF
            DPH = (PB-PA)/NT
            DO IP = 1, NT
               PH = PA + (IP-0.5D0)*DPH
               RN = AHW*SIN(PH)
               P(3) = BHT*COS(PH)
               W0 = SQRT((AHW*COS(PH))**2 + (BHT*SIN(PH))**2)*DPH
               X0 = PX(K-1) - ISG*RN*EY
               Y0 = PY(K-1) + ISG*RN*EX
               UA = 0.D0
               UB = MIN(SL, S - CUM(K-1))
               CALL K8_CLIP(X0, EX, BX(1), BX(2), UA, UB)
               CALL K8_CLIP(Y0, EY, BX(3), BX(4), UA, UB)
               IF (UB .LE. UA) CYCLE
               NS  = MAX(1, INT((UB-UA)/DS) + 1)
               DSS = (UB-UA)/NS
               DO IS = 1, NS
                  U = UA + (IS-0.5D0)*DSS
                  P(1) = X0 + U*EX
                  P(2) = Y0 + U*EY
                  CALL K8_KEEP(BX, P, RN, CUM(K-1)+U, KEEP)
                  IF (KEEP .EQ. 1) THEN
                     W = W0*DSS
                     CUTA = CUTA + W
                     DO L = 1, 3
                        XM(L) = XM(L) + W*2.D0*(P(L)-CEN(L))/SZ(L)
                     ENDDO
                  ENDIF
               ENDDO
            ENDDO
         ENDDO
      ENDDO
!     round outer corners, start and end domes: sectors of revolution
      DO K = 0, NSEG
         IF (K .EQ. 0) THEN
            AL1 = ATAN2(PY(1)-PY(0), PX(1)-PX(0)) + 0.5D0*PI
            DAL = PI
            SV  = 0.D0
         ELSEIF (K .EQ. NSEG) THEN
            AL1 = ATAN2(PY(K)-PY(K-1), PX(K)-PX(K-1)) - 0.5D0*PI
            DAL = PI
            SV  = CUM(K)
         ELSE
            E1X = PX(K)-PX(K-1)
            E1Y = PY(K)-PY(K-1)
            E2X = PX(K+1)-PX(K)
            E2Y = PY(K+1)-PY(K)
            CR  = E1X*E2Y - E1Y*E2X
            IF (ABS(CR) .LT. 1.D-12*SQRT(E1X**2+E1Y**2)*
     1          SQRT(E2X**2+E2Y**2)) CYCLE
            SG  = -SIGN(1.D0, CR)
            A1  = ATAN2(SG*E1X, -SG*E1Y)
            A2  = ATAN2(SG*E2X, -SG*E2Y)
            AL1 = A1
            DAL = A2 - A1
            IF (DAL .GT. PI)  DAL = DAL - 2.D0*PI
            IF (DAL .LT. -PI) DAL = DAL + 2.D0*PI
            SV  = CUM(K)
         ENDIF
         IF (SV .GT. S) CYCLE
         DPH = (PHB-PHA)/NT
         NA = MAX(1, INT(ABS(DAL)*AHW/DS*2.D0) + 1)
         DA = DAL/NA
         DO IA = 1, NA
            AL = AL1 + (IA-0.5D0)*DA
            DO IP = 1, NT
               PH = PHA + (IP-0.5D0)*DPH
               RN = AHW*SIN(PH)
               P(3) = BHT*COS(PH)
               P(1) = PX(K) + RN*COS(AL)
               P(2) = PY(K) + RN*SIN(AL)
               W = RN*ABS(DA)*DPH*SQRT((AHW*COS(PH))**2 +
     1                                 (BHT*SIN(PH))**2)
               CALL K8_KEEP(BX, P, RN, SV, KEEP)
               IF (KEEP .EQ. 1) THEN
                  CUTA = CUTA + W
                  DO L = 1, 3
                     XM(L) = XM(L) + W*2.D0*(P(L)-CEN(L))/SZ(L)
                  ENDDO
               ENDIF
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
!
!     KEEP = 1 if sample point P lies in the box BX and is owned by
!     the path point of arc length SV at distance RN
      SUBROUTINE K8_KEEP(BX, P, RN, SV, KEEP)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION BX(6), P(3)
      KEEP = 0
      IF (P(1).LT.BX(1) .OR. P(1).GE.BX(2)) RETURN
      IF (P(2).LT.BX(3) .OR. P(2).GE.BX(4)) RETURN
      IF (P(3).LT.BX(5) .OR. P(3).GE.BX(6)) RETURN
      CALL K8_NEAR(P(1), P(2), D, SS)
      IF (ABS(D-RN).LT.1.D-9 .AND. ABS(SS-SV).LT.1.D-9) KEEP = 1
      RETURN
      END
