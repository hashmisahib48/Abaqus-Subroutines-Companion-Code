import sys; sys.path.insert(0,'.')
from lib8 import *
P=PL; L1,L2=7.8,5.1; Ltot=12.9
fac=read_fac('caseL'); rows=read_hist('caseL')
tot=0; errs=[]; sigs=[]
for ie,r in fac.items():
    S=Ltot; mc=mc_facet(P,ie,S,n=40000)
    e=r[0:6]-mc; errs.append(e); sigs.append(np.sqrt(np.maximum(mc*(1-mc),1e-4)/40000))
errs=np.array(errs); sigs=np.array(sigs)
print('elements',len(fac),'facet cov: max|err| %.4f rms %.5f max|z| %.2f'%(np.abs(errs).max(),np.sqrt((errs**2).mean()),np.abs(errs/sigs).max()))
cut=sum(r[12] for r in fac.values()); print('sum cut area routine %.4f  closed form %.4f  (straight-bead formula for comparison %.4f)'%(cut,surf_L(L1,L2),surf_straight(9.6)))
fs=read_fac('caseS'); cs=sum(r[12] for r in fs.values()); print('straight: cut sum %.4f closed %.4f'%(cs,surf_straight(9.6)))
