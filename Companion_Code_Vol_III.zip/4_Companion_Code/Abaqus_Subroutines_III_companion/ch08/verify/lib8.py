# exact / Monte-Carlo references for the Chapter 8 bead (straight path along x, L path)
import numpy as np, csv, os
from scipy import integrate
A,B,V=0.9,0.6,10.0
DX=DY=0.5; DZ=0.4; NX,NY,NZ=24,16,2
def elem_box(ie):          # ie 1-based
    k=ie-1; ix=k%NX; iy=(k//NX)%NY; iz=k//(NX*NY)
    return ix*DX,(ix+1)*DX,iy*DY,(iy+1)*DY,iz*DZ,(iz+1)*DZ
def Hh(d):  d=np.asarray(d,float); return np.where(d<A,B*np.sqrt(np.clip(1-(d/A)**2,0,None)),0.0)
def G(u):   # integral_0^u H dn
    w=np.clip(u/A,0,1); return 0.5*A*B*(w*np.sqrt(1-w*w)+np.arcsin(w))
def area_rect(y0,y1,z0,z1):
    """area of {y0<=y<=y1, z0<=z<=z1, 0<=z<=H(|y|)} (y relative to bead axis)"""
    yb0=A*np.sqrt(1-(z0/B)**2) if z0<B else 0.0
    yb1=A*np.sqrt(1-(z1/B)**2) if z1<B else 0.0
    def I(u):
        u=abs(u); r=(z1-z0)*min(u,yb1)
        if u>yb1:
            m=min(u,yb0)
            if m>yb1: r+=G(m)-G(yb1)-z0*(m-yb1)
        return r
    F=lambda y: np.sign(y)*I(y)
    return F(y1)-F(y0)
def arc_rect(y0,y1,z0,z1,n=40001):
    """length of the ellipse arc n=A sin(phi), z=B cos(phi) inside the rectangle"""
    ph=(np.arange(n)+0.5)/n*np.pi-np.pi/2
    nn=A*np.sin(ph); zz=B*np.cos(ph); w=np.sqrt((A*np.cos(ph))**2+(B*np.sin(ph))**2)*np.pi/n
    m=(nn>=y0)&(nn<y1)&(zz>=z0)&(zz<z1)
    return w[m].sum()
Earc=lambda: arc_rect(-9,9,-1,9)
def Jint():
    ph=(np.arange(200001)+0.5)/200001*np.pi/2
    return (A*np.sin(ph)*np.sqrt((A*np.cos(ph))**2+(B*np.sin(ph))**2)).sum()*np.pi/2/200001
# ----- paths
PS=[(1.3,3.1),(10.9,3.1)]
PL=[(1.3,1.2),(9.1,1.2),(9.1,6.3)]
def vol_straight(L): return np.pi/2*A*B*L+2*np.pi/3*A*A*B
def vol_L(L1,L2): return np.pi/2*A*B*(L1+L2)-2/3*A*A*B+np.pi/6*A*A*B+2*np.pi/3*A*A*B
def surf_straight(L): return Earc()*L+2*np.pi*Jint()
def surf_L(L1,L2): return Earc()*(L1+L2)-2*Jint()+np.pi/2*Jint()+2*np.pi*Jint()
# ----- readers
def read_hist(d):
    rows=np.loadtxt(os.path.join(d,'vf_hist.csv'),delimiter=',')
    return rows        # inc,time,S1,elem,vf
def vf_at(rows,inc,nel=NX*NY*NZ):
    v=np.zeros(nel+1); m=rows[:,0]==inc; v[rows[m,3].astype(int)]=rows[m,4]; return v
def read_fac(d,nel=NX*NY*NZ):
    r=np.loadtxt(os.path.join(d,'fac_final.csv'),delimiter=','); out={}
    for x in r: out[int(x[0])]=x[1:]
    return out
# ----- MC
def nearest(P,pts):
    """distance to polyline and arc length s* of nearest point, vectorised; pts (N,2)"""
    cum=0.0; best=np.full(len(pts),1e30); bs=np.zeros(len(pts))
    for k in range(len(P)-1):
        a=np.array(P[k]); b=np.array(P[k+1]); e=b-a; L=np.hypot(*e)
        t=np.clip(((pts-a)@e)/L**2,0,1); q=a+t[:,None]*e; dd=np.hypot(*(pts-q).T)
        m=dd<best-1e-12; best[m]=dd[m]; bs[m]=cum+t[m]*L; cum+=L
    return best,bs
def mc_vf(P,S_list,N=40_000_000,seed=1,chunk=4_000_000):
    rng=np.random.default_rng(seed); nel=NX*NY*NZ
    cnt=np.zeros((len(S_list),nel+1)); tot=np.zeros(nel+1)
    for _ in range(N//chunk):
        x=rng.uniform(0,NX*DX,chunk); y=rng.uniform(0,NY*DY,chunk); z=rng.uniform(0,NZ*DZ,chunk)
        ie=(np.floor(x/DX)+NX*(np.floor(y/DY)+NY*np.floor(z/DZ))).astype(int)+1
        d,s=nearest(P,np.c_[x,y]); inb=(d<A)&(z<Hh(d))
        tot+=np.bincount(ie,minlength=nel+1)
        for q,S in enumerate(S_list):
            cnt[q]+=np.bincount(ie[inb&(s<=S)],minlength=nel+1)
    return cnt/np.maximum(tot,1), tot
def mc_facet(P,ie,S,n=40000,seed=7):
    """covered area fraction of the six facets of element ie (Abaqus brick face order) at path position S"""
    rng=np.random.default_rng(seed+ie); x0,x1,y0,y1,z0,z1=elem_box(ie); out=[]
    # faces: 1 z0, 2 z1, 3 y0, 4 x1, 5 y1, 6 x0
    for f in range(6):
        u=rng.uniform(0,1,n); w=rng.uniform(0,1,n)
        if f==0: x=x0+u*(x1-x0); y=y0+w*(y1-y0); z=np.full(n,z0)
        if f==1: x=x0+u*(x1-x0); y=y0+w*(y1-y0); z=np.full(n,z1)
        if f==2: x=x0+u*(x1-x0); z=z0+w*(z1-z0); y=np.full(n,y0)
        if f==3: y=y0+u*(y1-y0); z=z0+w*(z1-z0); x=np.full(n,x1)
        if f==4: x=x0+u*(x1-x0); z=z0+w*(z1-z0); y=np.full(n,y1)
        if f==5: y=y0+u*(y1-y0); z=z0+w*(z1-z0); x=np.full(n,x0)
        d,s=nearest(P,np.c_[x,y]); inb=(d<A)&(z<Hh(d))&(s<=S)
        out.append(inb.mean())
    return np.array(out)
