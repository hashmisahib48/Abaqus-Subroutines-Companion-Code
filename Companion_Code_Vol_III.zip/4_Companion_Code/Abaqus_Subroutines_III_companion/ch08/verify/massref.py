import sys; sys.path.insert(0,'.')
from lib8 import *
# reference mass curve V(S) of the L bead by plan-grid quadrature of H(d) over {s* <= S}
h=0.004; xs=np.arange(0,12,h)+h/2; ys=np.arange(0,8,h)+h/2
X,Y=np.meshgrid(xs,ys); pts=np.c_[X.ravel(),Y.ravel()]
d,s=nearest(PL,pts); m=d<A; Hm=Hh(d[m])*h*h; sm=s[m]
o=np.argsort(sm); sm=sm[o]; cum=np.cumsum(Hm[o])
np.savez('massref_L.npz',s=sm[::50],v=cum[::50],total=cum[-1])
print('grid total',cum[-1],'closed',vol_L(7.8,5.1))
