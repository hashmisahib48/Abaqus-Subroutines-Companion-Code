import sys; sys.path.insert(0,'.')
from lib8 import *
CACHE={}
rows=read_hist('caseS'); L=9.6; xs,xe,yc=1.3,10.9,3.1
# exact volume fraction of an element for the straight bead, interior (non-dome) region and domes
def vf_exact(ie,S):
    x0,x1,y0,y1,z0,z1=elem_box(ie)
    Ve=(x1-x0)*(y1-y0)*(z1-z0)
    # strip part: x in [xs, xs+S] clipped to [xs,xe]
    a=max(x0,xs); b=min(x1,xs+min(S,L),xe)
    v=max(b-a,0)*area_rect(y0-yc,y1-yc,z0,z1)
    # dome parts (start: x<xs ; end: x>xe once S>=L): numerical 2-D integral
    def dome(xc,sgn):
        key=(ie,sgn)
        if key in CACHE: return CACHE[key]
        f=lambda y,x: max(0.0,min(z1,float(Hh(np.hypot(x-xc,y-yc))))-z0)
        lo,hi=(x0,min(x1,xs)) if sgn<0 else (max(x0,xe),x1)
        if hi<=lo: CACHE[key]=0.0; return 0.0
        r=integrate.dblquad(f,lo,hi,y0,y1,epsabs=1e-9,epsrel=1e-8)[0]; CACHE[key]=r; return r
    if x0<xs: v+=dome(xs,-1)
    if S>=L-1e-12 and x1>xe: v+=dome(xe,+1)
    return v/Ve
for inc in (6,12,24):
    S=min(V*0.04*inc,L); vf=vf_at(rows,inc)
    ex=np.array([vf_exact(ie,S) for ie in range(1,NX*NY*NZ+1)])
    err=vf[1:]-ex
    front=np.array([ (elem_box(ie)[0]<xs+S<elem_box(ie)[1]) for ie in range(1,NX*NY*NZ+1)])
    print(inc,round(S,3),'all max %.2e rms %.2e | front-cut max %.2e | others max %.2e'%(np.abs(err).max(),np.sqrt((err**2).mean()),np.abs(err[front]).max(),np.abs(err[~front]).max()),
      'mass routine %.5f exact %.5f'%(vf[1:].sum()*DX*DY*DZ,(ex*DX*DY*DZ).sum()))

S=9.6; vf=vf_at(rows,24); ex=np.array([vf_exact(ie,S) for ie in range(1,NX*NY*NZ+1)]); err=vf[1:]-ex; k=np.argsort(-np.abs(err))[:5]
for q in k: print(q+1,elem_box(q+1),vf[q+1],ex[q],err[q])
np.savez('exactS.npz',**{('i%d'%inc):np.array([vf_exact(ie,min(V*0.04*inc,L)) for ie in range(1,NX*NY*NZ+1)]) for inc in (6,12,24)})
