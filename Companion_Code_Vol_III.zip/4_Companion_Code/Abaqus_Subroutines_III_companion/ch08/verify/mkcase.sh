#!/bin/sh
# usage: mkcase.sh dir ncol nsub fmin  (path type from dir name S or L)
d=$1; nc=$2; ns=$3; fm=${4:-0.01}
mkdir -p $d
printf " 0.9 0.6 10.0 $fm $nc $ns\n 24 16 2  0.5 0.5 0.4  0.0 0.0 0.0  1\n" > $d/epa_path.dat
case $d in
 *S*) printf " 1\n 1.3 3.1\n 10.9 3.1\n" >> $d/epa_path.dat;;
 *L*) printf " 2\n 1.3 1.2\n 9.1 1.2\n 9.1 6.3\n" >> $d/epa_path.dat;;
esac
