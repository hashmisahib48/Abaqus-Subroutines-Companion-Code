import sys,subprocess,json; sys.path.insert(0,'.')
from lib8 import *
L1,L2=7.8,5.1
mc=np.load('mcL.npy')  # [inc12,inc24,inc33]
out=[]
for fm in (1e-9,0.01,0.05,0.10):
    d='defL_%g'%fm; subprocess.run(['./mkcase.sh',d,'32','4',str(fm)],check=True)
    subprocess.run('cd %s && echo 0.04 | ../bin/k8_drv > out.txt'%d,shell=True,check=True)
    rows=read_hist(d); vf=vf_at(rows,33); 
    # first non-zero fraction of every element
    first={}
    for r in rows:
        e=int(r[3]); 
        if e not in first: first[e]=r[4]
    fv=np.array(list(first.values()))
    vf24=vf_at(rows,24)
    o=dict(fmin=fm,mass=vf[1:].sum()*DX*DY*DZ,loss=vol_L(L1,L2)-vf[1:].sum()*DX*DY*DZ,nel=len(first),minfirst=fv.min(),n_lt_5pct=int((fv<0.05).sum()),
           err24=float(np.abs(vf24-mc[1]).max()),err33=float(np.abs(vf-mc[2]).max()))
    out.append(o); print(o)
json.dump(out,open('defer.json','w'))
