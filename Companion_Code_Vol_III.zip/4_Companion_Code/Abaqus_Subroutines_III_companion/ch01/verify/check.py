import numpy as np, math
from scipy.optimize import brentq
np.set_printoptions(linewidth=150)
print('--- steel conversion (Table 1.8)')
k=45.;  c=460.; rho=7850.
kk=k*1.0            # W/mK -> mW/(mm K)
cc=c*1e3*1e3        # J/(kg K) -> mJ/(t K): J->mJ x1e3, per kg -> per t x1e3
rr=rho*1e-12        # kg/m3 -> t/mm3 : 1 kg=1e-3 t, 1 m3=1e9 mm3
print('k',kk,'c',cc,'rho',rr,'rho*c',rr*cc,'alpha',kk/(rr*cc))
h=25.; print('h W/m2K ->',h*1e-3,'mW/mm2K')
sig=5.670374e-8*1e3*1e-6; print('sigma mW/mm2K4',sig)
print('flux 1 MW/m2 ->',1e6*1e3*1e-6,'mW/mm2')
print('latent 270 kJ/kg -> mJ/t',270e3*1e3*1e3)
print('E 210 GPa->MPa',210e3)
print('--- Al (1A.1)')
k=237.;rho=2700.;c=900.
print('k',k,'c',c*1e6,'rho',rho*1e-12,'rhoc',rho*1e-12*c*1e6,'alpha',k/(rho*1e-12*c*1e6))
print('h=10 W/m2K ->',10e-3,' q=5 W/cm2 ->',5*1e3/100,'mW/mm2')
alAl=k/(rho*1e-12*c*1e6)
print('--- 1A.2: Al, q=50 mW/mm2, t=2 s: dT_s',2*50/k*math.sqrt(alAl*2/math.pi), ' at 5 s',2*50/k*math.sqrt(alAl*5/math.pi))
# dT at x=2mm, t=2
def Tex(x,t,q,k,al):
    s=math.sqrt(al*t); return 2*q/k*(s/math.sqrt(math.pi)*math.exp(-x*x/(4*s*s))-0.5*x*math.erfc(x/(2*s)))
print('  dT(x=2mm,t=2)',Tex(2,2,50,k,alAl),' penetration 4sqrt(at)',4*math.sqrt(alAl*2))
print('--- 1A.3 total derivative film+rad at 600C: ')
eps=0.7;hh=0.020;s=5.670374e-11
TK=600+273.15; dr=4*eps*s*TK**3; print('  rad',dr,'film',hh,'sum',dr+hh,' FLUX(1)=',-(hh*(600-20)+eps*s*(TK**4-293.15**4)))
print('--- 1B.1 element matrices h=2 mm steel A=1mm2')
rc=7.85e-9*4.6e8; print(' k/h',45/2,' rho c h/6',rc*2/6,' 2x',2*rc*2/6,' lumped',rc*2/2, ' bound h2/(6a)',4/(6*45/rc),' dt_crit expl',4/(2*45/rc))
print('--- oscillation (consistent, Dirichlet step) h=1mm steel')
al=45/3.611
def step(r,N=40,steps=1):
    # nodes 0..N, T0=1 fixed at node 0, initial 0
    h=1.0; dt=r*h*h/al
    M=np.zeros((N+1,N+1));K=np.zeros_like(M)
    for e in range(N):
        M[e:e+2,e:e+2]+=h/6*np.array([[2,1],[1,2]]); K[e:e+2,e:e+2]+=al/h*np.array([[1,-1],[-1,1]])
    T=np.zeros(N+1);T[0]=1
    A=M/dt+K
    for _ in range(steps):
        b=M@T/dt
        # Dirichlet
        Ar=A.copy(); br=b.copy(); Ar[0,:]=0;Ar[0,0]=1;br[0]=1
        T=np.linalg.solve(Ar,br)
    return T,dt
for r in (0.05,0.1,1/6,0.2,0.5,2.0):
    T,dt=step(r); print(f' r={r:.4f} dt={dt:.5f}s min T={T.min():.4e} at node {T.argmin()}  max={T[1:].max():.4f}')
T,dt=step(0.1); print(T[:8])
print('--- explicit stability, lumped, h=0.5 mm steel')
h=0.5; N=200
M=np.zeros(N+1);K=np.zeros((N+1,N+1))
for e in range(N):
    M[e]+=h/2;M[e+1]+=h/2; K[e:e+2,e:e+2]+=al/h*np.array([[1,-1],[-1,1]])
A=K/M[:,None]; lam=np.linalg.eigvals(A).real.max(); print(' lam_max',lam,' 4a/h2',4*al/h**2,' dtcrit 2/lam',2/lam,' h2/2a',h*h/(2*al))
for f in (0.9,0.99,1.01,1.05):
    dt=f*2/lam; rng=np.random.default_rng(1); T=rng.standard_normal(N+1)
    n0=abs(T).max(); hist=[]
    for k_ in range(1,401):
        T=T-dt*(A@T)
        if k_ in (100,400): hist.append(abs(T).max())
    print(f' dt={f}*crit={dt:.5f}: |T|max after 100, 400 steps:',hist, ' amplification max|1-dt lam|',max(abs(1-dt*np.linalg.eigvals(A).real)))
print('--- skin depth units')
f=1e3; w=2*math.pi*f
sigSI=5.96e7; mu0=4e-7*math.pi
print(' SI delta mm',math.sqrt(2/(w*mu0*sigSI))*1e3)
sigU=sigSI*1e-6; muU=mu0   # N/A^2
print(' sigma consistent',sigU,' mu',muU,' delta mm',math.sqrt(2/(w*muU*sigU)))
J=1.0; print(' Joule J=1 A/mm2: SI',(1e6)**2/sigSI*1e-9*1e3,'mW/mm3; consistent',J*J/sigU)
print('--- lumped capacitance 1C.1: steel half-thickness 5 mm, film h=100 W/m2K sink 20 T0=220')
hh=100e-3; L=5.; kk=45.; rc=3.611; Bi=hh*L/kk
z=brentq(lambda z: z*math.tan(z)-Bi,1e-6,1.0); C1=4*math.sin(z)/(2*z+math.sin(2*z))
tau=rc*L/hh; print(' Bi',Bi,'tau',tau,'zeta1',z,'C1',C1)
for t in (tau,2*tau):
    Fo=kk/rc*t/L**2
    th=C1*math.exp(-z*z*Fo)  # surface? centre: cos(0)=1
    ths=C1*math.cos(z)*math.exp(-z*z*Fo)
    print(f' t={t:.1f} s theta_centre={th:.5f} theta_surface={ths:.5f}  T_centre={20+200*th:.3f} T_surf={20+200*ths:.3f}  lumped {20+200*math.exp(-t/tau):.3f}')
print('--- 1B.2 buggy DFLUX at 1000 C')
epsb=0.8
good=-epsb*5.670374e-11*((1273.15)**4-293.15**4)
bug1=epsb*5.670374e-8*(1000.**4-20.**4)  # all three
print(' good',good,' bug (all)',bug1)
print(' sigma only wrong:',good*1e3,'  degC only:',-epsb*5.670374e-11*(1000.**4-20.**4),' sign only', -good)
print('--- oscillation, face step applied during the first increment (figure version)')
def step2(r,N=40):
    h=1.0; dt=r*h*h/al
    M=np.zeros((N+1,N+1));K=np.zeros_like(M)
    for e in range(N):
        M[e:e+2,e:e+2]+=h/6*np.array([[2,1],[1,2]]); K[e:e+2,e:e+2]+=al/h*np.array([[1,-1],[-1,1]])
    A=M/dt+K; b=np.zeros(N+1); A[0,:]=0;A[0,0]=1;b[0]=1
    return np.linalg.solve(A,b)
for r in (0.05,0.1,1/6,0.5):
    T=step2(r); print(f' r={r:.4f} min={T.min():.4f} at node {T.argmin()}  T[:4]={T[:4]}')
print('--- explicit growth, 600 increments, 1.01 crit, seed 1')
h=0.5;N=200;M=np.zeros(N+1);K=np.zeros((N+1,N+1))
for e in range(N):
    M[e]+=h/2;M[e+1]+=h/2;K[e:e+2,e:e+2]+=al/h*np.array([[1,-1],[-1,1]])
A=K/M[:,None]; lam=np.linalg.eigvals(A).real.max(); dc=2/lam
for f in (0.95,1.01):
    rng=np.random.default_rng(1); T=rng.standard_normal(N+1); n0=abs(T).max()
    for k in range(600): T=T-f*dc*(A@T)
    print(f,' ratio max|T| after 600/initial',abs(T).max()/n0, abs(T).max())
cd=math.sqrt(210000/7.85e-9); print('c_d',cd,'mech dt',0.5/cd,'ratio',0.5*cd/(2*al))
print('--- Terzaghi')
kk=1e-9*1e3; E=2.0; gw=9.81e-6; cv=kk*E/gw; print(' cv mm2/s',cv, ' t90 for H=10 m one-sided drainage (s, years)',0.848*(1e4)**2/cv, 0.848*(1e4)**2/cv/3.15576e7)
