rows=[l.split() for l in open('/home/claude/vol3/ch01/verify/out_flux.txt').read().strip().split('\n')[1:]]
prev=None
for r in rows:
    dt=float(r[1]);e0=float(r[4]);e2=float(r[6]); print(dt,r[2],e0,e2,'ratio',(prev/abs(e0) if prev else None),' energy',r[8],' exact(2mm)',r[9]); prev=abs(e0)
