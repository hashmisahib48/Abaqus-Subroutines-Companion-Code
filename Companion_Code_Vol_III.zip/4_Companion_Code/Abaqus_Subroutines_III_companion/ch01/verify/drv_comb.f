      PROGRAM H1_DRVCOMB
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      INTEGER N, ID, I, NIT
      PARAMETER (N=20, H=0.5D0)
      DIMENSION TOLD(N+1), TNEW(N+1), RH(0:30), DTS(3)
      DIMENSION FLUX(2), FP(2), FM(2), TIME(2), CO(3)
      CHARACTER*80 SNAME
      DATA DTS /1.D0, 10.D0, 100.D0/
      SNAME='S'
      TIME(1)=0.D0
      TIME(2)=0.D0
      CO(1)=0.D0
      CO(2)=0.D0
      CO(3)=0.D0
      CALL DFLUX(FLUX,1000.D0,1,1,TIME,1,1,CO,0,0.D0,0.D0,SNAME)
      CALL DFLUX(FP,1000.001D0,1,1,TIME,1,1,CO,0,0.D0,0.D0,SNAME)
      CALL DFLUX(FM,999.999D0,1,1,TIME,1,1,CO,0,0.D0,0.D0,SNAME)
      WRITE(*,'(A,3ES14.6)') ' F1, F2, FD', FLUX(1), FLUX(2),
     1   (FP(1)-FM(1))/0.002D0
      DO 100 ID = 1, 3
         DO 5 I = 1, N+1
            TOLD(I) = 1000.D0
            TNEW(I) = 1000.D0
    5    CONTINUE
         CALL H1_STEP(N,H,0.2D0,0.5D0,DTS(ID),DTS(ID),1,TOLD,TNEW,30,
     1                1.D-9,RH,NIT)
         WRITE(*,'(A,F7.1,I4,F10.3)') ' dt, NIT, T(0)', DTS(ID), NIT,
     1        TNEW(1)
  100 CONTINUE
      END
