      PROGRAM H1_DRVFILM
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      INTEGER N, IS, I, NIT, NS
      PARAMETER (N=10, H=0.5D0)
      DIMENSION TOLD(N+1), TNEW(N+1), RH(0:30)
      DO 100 NS = 180, 360, 180
         DT = 1.D0
         DO 5 I = 1, N+1
            TOLD(I) = 220.D0
            TNEW(I) = 220.D0
    5    CONTINUE
         DO 20 IS = 1, NS
            CALL H1_STEP(N,H,45.D0,3.611D0,DT,IS*DT,1,TOLD,TNEW,30,
     1                   1.D-9,RH,NIT)
            DO 10 I = 1, N+1
               TOLD(I) = TNEW(I)
   10       CONTINUE
   20    CONTINUE
         WRITE(*,'(A,I5,2F10.3)') ' t, T(0), T(5 mm)', NS, TNEW(1),
     1        TNEW(N+1)
  100 CONTINUE
      END
