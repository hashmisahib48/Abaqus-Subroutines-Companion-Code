      SUBROUTINE DFLUX(FLUX,SOL,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,TEMP,PRESS,SNAME)
!     Radiation to a sink: flux INTO the body is negative when the
!     surface hotter than the sink.  SOL = surface temperature, deg C
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      PARAMETER (EMIS = 0.8D0)       ! emissivity, -
      PARAMETER (SIGMA = 5.670374D-11) ! mW/(mm^2 K^4)
      PARAMETER (TZERO = -273.15D0)  ! absolute zero, deg C
      PARAMETER (TSINK = 20.D0)      ! sink temperature, deg C
      TK = SOL - TZERO
      TA = TSINK - TZERO
      FLUX(1) = -EMIS*SIGMA*(TK**4 - TA**4)
      FLUX(2) = -4.D0*EMIS*SIGMA*TK**3
      RETURN
      END
