      SUBROUTINE H1_STEP(N,H,COND,RHOC,DT,TIME,ICAP,TOLD,TNEW,
     1 NITMAX,TOL,RHIST,NIT)
!     One backward-Euler increment of 1-D transient conduction on a
!     bar of N linear elements of length H (mm), unit cross-section.
!     Node 1 (x = 0) receives the flux of subroutine DFLUX; the far
!     end is insulated.  Newton iteration with the tangent of Eq. 1.4-2.
!     COND mW/(mm K), RHOC mJ/(mm^3 K) = MPa/K, DT and TIME in s,
!     temperatures in deg C, residuals in mW/mm^2.
!     ICAP = 1 consistent heat capacity, 0 lumped.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX=4001)
      DIMENSION TOLD(N+1), TNEW(N+1), RHIST(0:NITMAX)
      DIMENSION RES(NMAX), DL(NMAX), DM(NMAX), DU(NMAX), DTE(NMAX)
      DIMENSION FLUX(2), TM(2), CO(3)
      CHARACTER*80 SNAME
      NN = N + 1
      TM(1) = TIME
      TM(2) = TIME
      CO(1) = 0.D0
      CO(2) = 0.D0
      CO(3) = 0.D0
      SNAME = 'SURF'
      DO 100 IT = 0, NITMAX
         DO 10 I = 1, NN
            RES(I) = 0.D0
            DL(I) = 0.D0
            DM(I) = 0.D0
            DU(I) = 0.D0
   10    CONTINUE
         DO 20 IE = 1, N
            CC = RHOC*H/DT
            IF (ICAP .EQ. 1) THEN
               C11 = CC/3.D0
               C12 = CC/6.D0
            ELSE
               C11 = CC/2.D0
               C12 = 0.D0
            END IF
            CK = COND/H
            DA = TNEW(IE) - TOLD(IE)
            DB = TNEW(IE+1) - TOLD(IE+1)
            RES(IE) = RES(IE) + C11*DA + C12*DB
     1              + CK*(TNEW(IE) - TNEW(IE+1))
            RES(IE+1) = RES(IE+1) + C12*DA + C11*DB
     1              + CK*(TNEW(IE+1) - TNEW(IE))
            DM(IE) = DM(IE) + C11 + CK
            DM(IE+1) = DM(IE+1) + C11 + CK
            DU(IE) = DU(IE) + C12 - CK
            DL(IE+1) = DL(IE+1) + C12 - CK
   20    CONTINUE
!        surface flux at node 1: residual -q, tangent -dq/dT
         FLUX(1) = 0.D0
         FLUX(2) = 0.D0
         CALL DFLUX(FLUX,TNEW(1),1,1,TM,1,1,CO,0,TNEW(1),0.D0,SNAME)
         RES(1) = RES(1) - FLUX(1)
         DM(1) = DM(1) - FLUX(2)
         RMAX = 0.D0
         DO 30 I = 1, NN
            RMAX = MAX(RMAX,ABS(RES(I)))
   30    CONTINUE
         RHIST(IT) = RMAX
         NIT = IT
         IF (RMAX .LT. TOL) RETURN
         IF (IT .EQ. NITMAX) RETURN
!        Thomas algorithm for  J dT = -RES
         DO 40 I = 1, NN
            DTE(I) = -RES(I)
   40    CONTINUE
         DO 50 I = 2, NN
            W = DL(I)/DM(I-1)
            DM(I) = DM(I) - W*DU(I-1)
            DTE(I) = DTE(I) - W*DTE(I-1)
   50    CONTINUE
         DTE(NN) = DTE(NN)/DM(NN)
         DO 60 I = NN-1, 1, -1
            DTE(I) = (DTE(I) - DU(I)*DTE(I+1))/DM(I)
   60    CONTINUE
         DO 70 I = 1, NN
            TNEW(I) = TNEW(I) + DTE(I)
   70    CONTINUE
  100 CONTINUE
      RETURN
      END
