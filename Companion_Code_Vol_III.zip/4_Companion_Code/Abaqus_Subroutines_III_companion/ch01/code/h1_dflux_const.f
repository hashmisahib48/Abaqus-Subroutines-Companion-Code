      SUBROUTINE DFLUX(FLUX,SOL,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,TEMP,PRESS,SNAME)
!     Constant surface flux into the body, independent of temperature
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      PARAMETER (Q0 = 100.D0)   ! mW/mm^2  (= 100 kW/m^2)
      FLUX(1) = Q0
      FLUX(2) = 0.D0
      RETURN
      END
