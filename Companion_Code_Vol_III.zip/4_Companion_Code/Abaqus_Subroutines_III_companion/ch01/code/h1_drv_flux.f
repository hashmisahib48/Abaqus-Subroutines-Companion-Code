      PROGRAM H1_DRVFLUX
!     Example 1.9-1: steel bar, constant flux Q0 at x = 0, T0 = 20 C.
!     Compares the FE solution at t = 10 s with the erfc closed form.
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      INTEGER N
      PARAMETER (N=400, H=0.25D0, COND=45.D0, RHOC=3.6110D0)
      DIMENSION TOLD(N+1), TNEW(N+1), RH(0:20)
      PARAMETER (PI=3.14159265358979324D0, Q0=100.D0, T0=20.D0)
      PARAMETER (TEND=10.D0)
      ALPHA = COND/RHOC
      WRITE(*,'(A,F10.4)') ' alpha mm^2/s =', ALPHA
      DO 100 IR = 1, 5
         NS = 20*2**(IR-1)
         DT = TEND/NS
         DO 5 I = 1, N+1
            TOLD(I) = T0
            TNEW(I) = T0
    5    CONTINUE
         DO 20 IS = 1, NS
            CALL H1_STEP(N,H,COND,RHOC,DT,IS*DT,1,TOLD,TNEW,20,
     1                   1.D-9,RH,NIT)
            DO 10 I = 1, N+1
               TOLD(I) = TNEW(I)
   10       CONTINUE
   20    CONTINUE
         EMAX = 0.D0
         DO 30 I = 1, N+1
            X = (I-1)*H
            S = SQRT(ALPHA*TEND)
            TEX = T0 + 2.D0*Q0/COND*(S/SQRT(PI)*EXP(-X*X/(4.D0*S*S))
     1            - 0.5D0*X*ERFC(X/(2.D0*S)))
            EMAX = MAX(EMAX,ABS(TNEW(I)-TEX))
            IF (I .EQ. 1)  T1 = TNEW(I)
            IF (I .EQ. 1)  E1 = TEX
            IF (I .EQ. 9)  T9 = TNEW(I)
            IF (I .EQ. 9)  E9 = TEX
   30    CONTINUE
         EN = 0.5D0*(TNEW(1)-T0) + 0.5D0*(TNEW(N+1)-T0)
         DO 35 I = 2, N
            EN = EN + (TNEW(I)-T0)
   35    CONTINUE
         EN = EN*RHOC*H
         WRITE(*,'(I5,F9.4,3(F10.4),F10.4,F10.4,I3,F10.3,F8.4)') NS,
     1        DT, T1, E1, T1-E1, T9, T9-E9, NIT, EN, E9
         IF (IR .EQ. 1) THEN
            OPEN(7,FILE='../verify/profile.dat')
            DO 40 I = 1, N+1, 4
               X = (I-1)*H
               S = SQRT(ALPHA*TEND)
               TEX = T0 + 2.D0*Q0/COND*(S/SQRT(PI)*EXP(-X*X/
     1               (4.D0*S*S)) - 0.5D0*X*ERFC(X/(2.D0*S)))
               IF (X .LE. 40.D0) WRITE(7,'(3F12.5)') X, TNEW(I), TEX
   40       CONTINUE
            CLOSE(7)
         END IF
  100 CONTINUE
      END
