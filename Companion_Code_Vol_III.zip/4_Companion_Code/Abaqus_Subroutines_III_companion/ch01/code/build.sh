#!/bin/sh
# compile all listings and run the drivers (gfortran, stubs in lib/aba)
A=/home/claude/vol3/lib/aba
F="-ffixed-form -std=legacy -I$A"
cd "$(dirname "$0")"
for f in h1_dflux_const.f h1_dflux_rad.f h1_fe1d.f; do gfortran -c $F $f -o /tmp/claude-0/$f.o || exit 1; done
gfortran $F h1_drv_flux.f h1_fe1d.f h1_dflux_const.f $A/stubs.f -o /tmp/claude-0/drv_flux && /tmp/claude-0/drv_flux > ../verify/out_flux.txt
gfortran $F h1_drv_rad.f h1_fe1d.f h1_dflux_rad.f $A/stubs.f -o /tmp/claude-0/drv_rad && /tmp/claude-0/drv_rad > ../verify/out_rad.txt
cat ../verify/out_flux.txt ../verify/out_rad.txt
for v in nodrv degc sign; do
  gfortran $F h1_drv_rad.f h1_fe1d.f ../verify/dflux_rad_$v.f $A/stubs.f -o /tmp/claude-0/drv_$v && /tmp/claude-0/drv_$v > ../verify/out_rad_$v.txt
done
