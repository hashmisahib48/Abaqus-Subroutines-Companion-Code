      PROGRAM H1_DRVRAD
!     Example 1.9-2: Newton convergence of one increment with the
!     radiation flux of DFLUX, and finite-difference test of FLUX(2).
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      INTEGER N, IM, I, K, NIT
      PARAMETER (N=20, H=0.5D0, DT=5.D0)
      DIMENSION TOLD(N+1), TNEW(N+1), RH(0:30)
      DIMENSION FLUX(2), FP(2), FM(2), TIME(2), CO(3)
      CHARACTER*80 SNAME
      DIMENSION COND(2), RHOC(2)
      CHARACTER*12 NAM(2)
      DATA COND /45.D0, 0.2D0/, RHOC /3.611D0, 0.5D0/
      DATA NAM /'steel', 'insulation'/
      SNAME = 'SURF'
      TIME(1) = 0.D0
      TIME(2) = 0.D0
      CO(1) = 0.D0
      CO(2) = 0.D0
      CO(3) = 0.D0
!     finite-difference test of FLUX(2) at 1000 C
      DEL = 1.D-3
      CALL DFLUX(FLUX,1000.D0,1,1,TIME,1,1,CO,0,0.D0,0.D0,SNAME)
      CALL DFLUX(FP,1000.D0+DEL,1,1,TIME,1,1,CO,0,0.D0,0.D0,SNAME)
      CALL DFLUX(FM,1000.D0-DEL,1,1,TIME,1,1,CO,0,0.D0,0.D0,SNAME)
      FD = (FP(1)-FM(1))/(2.D0*DEL)
      WRITE(*,'(A,3ES14.6)') ' FLUX(1), FLUX(2), FD:', FLUX(1),
     1      FLUX(2), FD
      WRITE(*,'(A,ES10.2)') ' relative difference FLUX(2) vs FD:',
     1      ABS(FLUX(2)-FD)/ABS(FD)
      DO 100 IM = 1, 2
         DO 5 I = 1, N+1
            TOLD(I) = 1000.D0
            TNEW(I) = 1000.D0
    5    CONTINUE
         CALL H1_STEP(N,H,COND(IM),RHOC(IM),DT,DT,1,TOLD,TNEW,30,
     1                1.D-9,RH,NIT)
         WRITE(*,'(A,A,I3,A,F9.3,A,F9.3)') ' ', NAM(IM), NIT,
     1        ' iterations; T(0), T(L) =', TNEW(1), ' ', TNEW(N+1)
         DO 10 K = 0, NIT
            WRITE(*,'(I4,ES14.4)') K, RH(K)
   10    CONTINUE
  100 CONTINUE
      END
