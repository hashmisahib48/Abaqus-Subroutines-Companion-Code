#!/bin/sh
# compile every listing and driver of Chapter 6 (gfortran 13, stubs from lib/aba) and run the drivers
C=/home/claude/vol3/ch06/code; V=/home/claude/vol3/ch06/verify; B=$V/bin; I=/home/claude/vol3/lib/aba
F="-std=legacy -ffixed-form -ffixed-line-length-none -I$I"
cd $C
for f in ex6_utemp ex6_utemp_sec ex6_vutemp ex6_umasfl ex6_umotion ex6_rot ex6_umotion_tr; do gfortran -c $F $f.f -o $B/$f.o || exit 1; done
mkdir -p $V/work $V/work3
gfortran $F k6_utemp_drv.f ex6_utemp.f $I/stubs.f -o $B/k6_utemp && (cd $V/work && $B/k6_utemp > $V/out_utemp.txt)
gfortran $F k6_vutemp_drv.f ex6_vutemp.f $I/stubs.f -o $B/k6_vutemp && (cd $V/work && $B/k6_vutemp > $V/out_vutemp.txt)
gfortran $F k6_chan.f ex6_umasfl.f $I/stubs.f -o $B/k6_chan && (cd $V/work && $B/k6_chan > $V/out_chan.txt)
gfortran $F k6_sec_drv.f ex6_utemp_sec.f $I/stubs.f -o $B/k6_sec && (cd $V/work && $B/k6_sec > $V/out_sec.txt)
gfortran $F k6_umot_hinge.f ex6_umotion.f ex6_rot.f $I/stubs.f -o $B/k6_hinge && (cd $V/work && $B/k6_hinge > $V/out_hinge.txt)
sed -e 's/TH1 = 120.0D0, TH2 = 0.0D0/TH1 = 70.0D0, TH2 = -35.0D0/' -e 's#DATA XC /0.0D0, 0.0D0, 0.0D0/, DSP /0.0D0, 0.0D0, 0.0D0/#DATA XC /20.0D0, 10.0D0, 0.0D0/, DSP /10.0D0, -5.0D0, 3.0D0/#' -e 's#AX1 /0.0D0, 0.0D0, 1.0D0/, AX2 /1.0D0, 0.0D0, 0.0D0/#AX1 /0.0D0, 0.6D0, 0.8D0/, AX2 /1.0D0, 0.0D0, 0.0D0/#' ex6_umotion.f > $V/ex6_umotion_3d.f
gfortran $F k6_umot_3d.f $V/ex6_umotion_3d.f ex6_rot.f $I/stubs.f -o $B/k6_3d && (cd $V/work3 && $B/k6_3d > $V/out_3d.txt) && python3 $V/chk3d.py >> $V/out_3d.txt
gfortran $F k6_tr_drv.f ex6_umotion_tr.f $I/stubs.f -o $B/k6_tr && (cd $V/work && $B/k6_tr > $V/out_tr.txt)
cat $V/out_*.txt | wc -l
