      PROGRAM K6CHAN
!     Steady heated pipe flow with mass flow rates from UMASFL
!     (Listing 6.5): streamline-upwind Petrov-Galerkin line elements,
!     written for this chapter as a stand-in for a convection/diffusion
!     element.  Equation: a T' - D T'' + s (T - TW) = 0, with
!     a = mdot*c (mW/K), D = k*A (mW mm/K), s = h*P (mW/(mm K)).
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 2001, XL = 5.0D3, BETA = 0.9D0)
      PARAMETER (CP = 4.18D9, COND = 0.6D0, DIAM = 20.0D0)
      PARAMETER (HF = 2.0D0, TW = 80.0D0, TIN = 20.0D0)
      PARAMETER (PI = 3.14159265358979D0)
      DIMENSION FLOW(1), TIME(2), COORDS(3), FM(NMAX), T(NMAX)
      DIMENSION AL(NMAX), D(NMAX), AU(NMAX), R(NMAX), NLIST(6)
      DATA NLIST /10, 20, 40, 80, 160, 320/
      AREA = PI*DIAM**2/4.0D0
      PERI = PI*DIAM
      DK = COND*AREA
      S = HF*PERI
      OPEN (UNIT=21, FILE='prof_chan.txt')
      DO 900 KSTEP = 1, 3
        DO 800 IL = 1, 6
          NEL = NLIST(IL)
          NN = NEL + 1
          H = XL/NEL
          TIME(1) = 1.0D0
          TIME(2) = 1.0D0
          DO 10 N = 1, NN
             COORDS(1) = (N - 1)*H
             COORDS(2) = 0.0D0
             COORDS(3) = 0.0D0
             CALL UMASFL(FLOW, 1, KSTEP, 1, TIME, N, COORDS)
             FM(N) = FLOW(1)
             AL(N) = 0.0D0
             D(N) = 0.0D0
             AU(N) = 0.0D0
             R(N) = 0.0D0
   10     CONTINUE
          A0 = FM(1)*CP
!         the element equations are divided by A0 (scaling only)
          DO 100 IE = 1, NEL
             A = 0.5D0*(FM(IE) + FM(IE+1))*CP
             PE = A*H/(2.0D0*DK)
             TAU = 0.5D0*H*(1.0D0/TANH(PE) - 1.0D0/PE)
             DO 90 IA = 1, 2
                SA = -1.0D0 + 2.0D0*(IA - 1)
                DO 80 IB = 1, 2
                   SB = -1.0D0 + 2.0D0*(IB - 1)
                   AMASS = H/6.0D0*(1.0D0 + (1 - ABS(IA-IB)))
                   EK = A*0.5D0*SB + S*AMASS + (DK + TAU*A)/H*SA*SB
     1                  + TAU*S*0.5D0*SA
                   EK = EK/A0
                   I = IE + IA - 1
                   J = IE + IB - 1
                   IF (J .EQ. I) D(I) = D(I) + EK
                   IF (J .EQ. I-1) AL(I) = AL(I) + EK
                   IF (J .EQ. I+1) AU(I) = AU(I) + EK
   80           CONTINUE
                R(IE+IA-1) = R(IE+IA-1) + S*TW*(0.5D0*H + TAU*SA)/A0
   90        CONTINUE
  100     CONTINUE
          D(1) = 1.0D0
          AU(1) = 0.0D0
          R(1) = TIN
          DO 20 I = 2, NN
             W = AL(I)/D(I-1)
             D(I) = D(I) - W*AU(I-1)
             R(I) = R(I) - W*R(I-1)
   20     CONTINUE
          T(NN) = R(NN)/D(NN)
          DO 30 I = NN - 1, 1, -1
             T(I) = (R(I) - AU(I)*T(I+1))/D(I)
   30     CONTINUE
!         closed forms: constant and linearly decreasing flow
          IF (KSTEP .LT. 3) THEN
             TCF = TW - (TW - TIN)*EXP(-S*XL/A0)
          ELSE
             TCF = TW - (TW - TIN)*(1.0D0 - BETA)**(S*XL/(BETA*A0))
          ENDIF
          WRITE (*,'(I2,I5,E11.3,F14.2,2F12.5,E12.3)') KSTEP, NEL, PE, A0,
     1       T(NN), TCF, T(NN) - TCF
          IF (NEL .EQ. 40) THEN
             DO 40 N = 1, NN
                X = (N - 1)*H
                IF (KSTEP .LT. 3) THEN
                   TC = TW - (TW - TIN)*EXP(-S*X/A0)
                ELSE
                   TC = TW - (TW - TIN)*(1.0D0 - BETA*X/XL)**
     1                  (S*XL/(BETA*A0))
                ENDIF
                WRITE (21,'(I2,F9.2,2F12.5)') KSTEP, X, T(N), TC
   40        CONTINUE
          ENDIF
  800   CONTINUE
  900 CONTINUE
      END
