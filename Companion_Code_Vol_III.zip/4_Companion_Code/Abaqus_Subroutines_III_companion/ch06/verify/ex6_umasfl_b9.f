      SUBROUTINE UMASFL(FLOW,KFLOW,KSTEP,KINC,TIME,NODE,COORDS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION FLOW(KFLOW), TIME(2), COORDS(3)
!
!     Water in a round pipe.  Units: tonne, mm, s.
      PARAMETER (RHO = 1.0D-9, VEL = 500.0D0, DIAM = 20.0D0)
!        RHO density (t/mm^3); VEL mean velocity (mm/s); DIAM (mm)
      PARAMETER (XL = 5.0D3, BETA = 0.9D0)
!        XL pipe length (mm); BETA fraction of the flow withdrawn
      PARAMETER (PI = 3.14159265358979D0)
!
      AREA = PI*DIAM**2/4.0D0
      FM = RHO*VEL*AREA
!        FM mass flow rate through the section (t/s)
      IF (KSTEP .EQ. 2) FM = 0.5D0*FM
      IF (KSTEP .EQ. 3) FM = FM*(1.0D0 - BETA*COORDS(1)/XL)
!
      IF (KFLOW .EQ. 1) THEN
         FLOW(1) = FM
      ELSE
         FLOW(1) = FM/AREA
         DO 10 K = 2, KFLOW
            FLOW(K) = 0.0D0
   10    CONTINUE
      ENDIF
!
      RETURN
      END
