import numpy as np, mpmath as mp
from math import *
E=2.1e5; al=1.2e-5; L=400; DT0=300; w=20; v=10; xst=-60
print('delta_max (pulse inside) mm', al*DT0*w*sqrt(pi), ' sigma_plateau MPa', -E*al*DT0*w*sqrt(pi)/L)
print('E*alpha MPa/K',E*al)
# time window with pulse centre fully inside: xc between 2w..L-2w
for tag,xc in (('xc=2w',40),('xc=L-2w',360)): print(tag,'t=',(xc-xst)/v)
# peak of stress from history
d=np.loadtxt('work/hist_utemp.txt'); i=np.argmin(d[:,3]); print('FE peak sigma',d[i,3],'at t',d[i,0],'cf',d[i,4], 'delta max',d[:,1].max(),d[:,2].max())
print('t pulse centre enters at x=0:',(0-xst)/v,'leaves x=L:',(L-xst)/v)
# end of history: residual
print('last row',d[-1])
# channel
rho=1e-9; vel=500; D=20; A=pi*D**2/4; P=pi*D; c=4.18e9; k=0.6; h=2.0; Lc=5000
md=rho*vel*A; a=md*c; s=h*P; Dk=k*A
print('A',A,'P',P,'mdot t/s',md,'kg/s',md*1e3,'a=mdot c',a,'s',s,'kA',Dk,'NTU',s*Lc/a,'Dk*s/a^2',Dk*s/a**2,'Pe_L',a*Lc/Dk)
for name,aa,fn in (('1',a,None),('2',a/2,None)):
    ntu=s*Lc/aa; print('step',name,'NTU',ntu,'Tout',80-60*exp(-ntu))
beta=.5; ex=s*Lc/(beta*a); print('step3 exponent',ex,'Tout',80-60*(1-beta)**ex)
# exact with diffusion, BC T(0)=20, T'(L)=0
mp.mp.dps=60
def exact(aa,Dk=Dk,s=s,Lc=Lc):
    aa,Dk,s,Lc=map(mp.mpf,(aa,Dk,s,Lc))
    rp=(aa+mp.sqrt(aa*aa+4*Dk*s))/(2*Dk); rm=(aa-mp.sqrt(aa*aa+4*Dk*s))/(2*Dk)
    # theta=T-Tw= C1 e^{rp x}+C2 e^{rm x}; theta(0)=-60 ; theta'(L)=0
    # C2 = -60 - C1 ; rp C1 e^{rp L} + rm C2 e^{rm L}=0
    C1=-(60)*rm*mp.e**(rm*Lc)*(-1)/( rp*mp.e**(rp*Lc) - rm*mp.e**(rm*Lc))
    # solve: rp C1 Ep + rm(-60-C1)Em=0 -> C1 (rp Ep - rm Em)=60 rm Em
    C1=60*rm*mp.e**(rm*Lc)/(rp*mp.e**(rp*Lc)-rm*mp.e**(rm*Lc)); C2=-60-C1
    th=C1*mp.e**(rp*Lc)+C2*mp.e**(rm*Lc); return 80+th
print('with axial conduction Tout(step1)',exact(a),' pure',80-60*exp(-s*Lc/a), 'diff', exact(a)-(80-60*exp(-s*Lc/a)))
# Peclet etc
print('residence time',Lc/vel,'s; element Pe at 40 el', a*(Lc/40)/(2*Dk))
print('G kg/mm2/s',rho*vel,'t/(mm2 s)')
print('sigma SI', 5.670374e-8*1e3/1e6)
# hinge
sig=5.670374e-11
for phi in (30,150): F=1-sin(radians(phi)/2); print(phi,F,100*F*sig*(800**4-400**4))
print('omega',[v/300 for v in (5e3,1e4,2e4,2.7778e4)], 'km/h', [v*3.6/1000 for v in (5e3,1e4,2e4,2.7778e4)])
