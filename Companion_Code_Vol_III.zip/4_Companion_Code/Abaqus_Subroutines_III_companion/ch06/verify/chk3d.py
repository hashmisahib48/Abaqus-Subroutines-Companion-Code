import numpy as np
from scipy.spatial.transform import Rotation as Rot
XC=np.array([20.,10.,0.]); DSP=np.array([10.,-5.,3.])
pts=[]
for i in (0,1):
  for j in (0,1):
    for k in (0,1): pts.append([20+50*i,10+40*j,30*k])
pts=np.array(pts,float)
a1=np.array([0,.6,.8]); a2=np.array([1.,0,0])
d=np.loadtxt('/home/claude/vol3/ch06/verify/work3/u3d.txt')
err=0
for row in d:
    n=int(row[0])-1; p=row[1]
    R=Rot.from_rotvec(a2*np.radians(-35)*p)*Rot.from_rotvec(a1*np.radians(70)*p)
    x=XC+DSP*p+R.apply(pts[n]-XC)
    err=max(err,np.abs(x-pts[n]-row[2:]).max())
print('max |u_routine - u_scipy| =',err)
