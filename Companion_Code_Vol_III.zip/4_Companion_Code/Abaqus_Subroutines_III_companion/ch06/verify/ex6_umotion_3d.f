      SUBROUTINE UMOTION(U,KSTEP,KINC,TIME,NODE,JDOF)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), XN(3), XC(3), AX1(3), AX2(3), DSP(3),
     1 R1(3,3), R2(3,3)
      COMMON /K6_REF/ XREF(3,10000)
      INTEGER IFIRST
      SAVE IFIRST
      DATA IFIRST /0/
!
!     Rigid motion of a node set: two rotations at once and a
!     translation, Eq. (6.8-1).  Units: mm, s, degrees.
      PARAMETER (PI = 3.14159265358979D0, DEG = PI/180.0D0)
      PARAMETER (TP = 1.0D0, TH1 = 70.0D0, TH2 = -35.0D0)
!        TP step period (s); TH1, TH2 rotations at p = 1 (deg)
      DATA XC /20.0D0, 10.0D0, 0.0D0/, DSP /10.0D0, -5.0D0, 3.0D0/
      DATA AX1 /0.0D0, 0.6D0, 0.8D0/, AX2 /1.0D0, 0.0D0, 0.0D0/
!        XC pivot (mm); DSP translation at p = 1 (mm); AX1, AX2 axes
!
      IF (IFIRST .EQ. 0) THEN
         CALL K6_LOADREF('k6_nodes.txt')
         IFIRST = 1
      ENDIF
      P = MIN(MAX(TIME(1)/TP, 0.0D0), 1.0D0)
      CALL K6_ROT(AX1, TH1*DEG*P, R1)
      CALL K6_ROT(AX2, TH2*DEG*P, R2)
      DO 20 I = 1, 3
         XN(I) = XC(I) + DSP(I)*P
         DO 10 J = 1, 3
         DO 10 K = 1, 3
            XN(I) = XN(I) + R2(I,J)*R1(J,K)*(XREF(K,NODE) - XC(K))
   10    CONTINUE
   20 CONTINUE
      U = XN(JDOF) - XREF(JDOF,NODE)
!
      RETURN
      END
