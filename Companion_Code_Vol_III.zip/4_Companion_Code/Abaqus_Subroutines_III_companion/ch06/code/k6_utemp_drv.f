      PROGRAM K6UDRV
!     Thermal-stress driver for UTEMP (Listing 6.2): a bar of linear
!     two-node elements, temperatures from UTEMP at every node and
!     increment as Abaqus would request them.  Units N, mm, s, degC.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 2001)
      PARAMETER (XLEN = 400.0D0, EMOD = 2.1D5, ALPHA = 1.2D-5)
      PARAMETER (TREF = 20.0D0, DTMAX = 300.0D0, W = 20.0D0)
      PARAMETER (V = 10.0D0, XST = -60.0D0, PI = 3.14159265358979D0)
      DIMENSION TE(1), TIME(2), COORDS(3), X(NMAX), TN(NMAX)
      DIMENSION B(NMAX), C(NMAX), A(NMAX), F(NMAX), UF(NMAX), UX(NMAX)
      DIMENSION NLIST(6)
      DATA NLIST /10, 20, 40, 80, 160, 320/
      DTINC = 0.5D0
      NINC = 104
      OPEN (UNIT=20, FILE='hist_utemp.txt')
      DO 500 IL = 1, 6
         NEL = NLIST(IL)
         NN = NEL + 1
         H = XLEN/NEL
         EDEL = 0.0D0
         EDSG = 0.0D0
         SPK = 0.0D0
         DO 400 KINC = 1, NINC
            TT = KINC*DTINC
            TIME(1) = TT
            TIME(2) = TT
            DO 100 N = 1, NN
               X(N) = (N - 1)*H
               COORDS(1) = X(N)
               COORDS(2) = 0.0D0
               COORDS(3) = 0.0D0
               CALL UTEMP(TE, 1, 1, KINC, TIME, N, COORDS)
               TN(N) = TE(1)
  100       CONTINUE
!           thermal load, element by element: EA*eth*[-1,+1]
            DO 110 N = 1, NN
               F(N) = 0.0D0
  110       CONTINUE
            DO 120 IE = 1, NEL
               ETH = ALPHA*(0.5D0*(TN(IE) + TN(IE+1)) - TREF)
               F(IE) = F(IE) - EMOD*ETH
               F(IE+1) = F(IE+1) + EMOD*ETH
  120       CONTINUE
!           (a) free bar: u(1) = 0
            CALL K6_SOLVE(NN, EMOD/H, F, 1, 0, UF)
!           (b) bar fixed at both ends
            CALL K6_SOLVE(NN, EMOD/H, F, 1, 1, UX)
            DEL = UF(NN) - UF(1)
            SIG = EMOD*((UX(2) - UX(1))/H - ALPHA*(0.5D0*(TN(1)
     1            + TN(2)) - TREF))
            XC = XST + V*TT
            DCF = ALPHA*DTMAX*W*SQRT(PI)/2.0D0*(ERF((XLEN - XC)/W)
     1            - ERF((0.0D0 - XC)/W))
            SCF = -EMOD*DCF/XLEN
            EDEL = MAX(EDEL, ABS(DEL - DCF))
            EDSG = MAX(EDSG, ABS(SIG - SCF))
            SPK = MIN(SPK, SIG)
            IF (NEL .EQ. 160) WRITE (20,'(F8.2,4E16.8)') TT, DEL,
     1         DCF, SIG, SCF
  400    CONTINUE
         WRITE (*,'(I6,F8.2,3E14.5)') NEL, H/W, EDEL, EDSG, SPK
  500 CONTINUE
      END
!
      SUBROUTINE K6_SOLVE(NN, CK, F, IFIX1, IFIXN, U)
!     tridiagonal solve of the bar equations, u(1)=0 and optionally
!     u(NN)=0; CK = EA/h per unit EA (E/h), uniform elements
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(NN), U(NN), AL(2001), D(2001), AU(2001), R(2001)
      DO 10 I = 1, NN
         D(I) = 2.0D0*CK
         AL(I) = -CK
         AU(I) = -CK
         R(I) = F(I)
   10 CONTINUE
      D(1) = CK
      D(NN) = CK
      IF (IFIX1 .EQ. 1) THEN
         D(1) = 1.0D0
         AU(1) = 0.0D0
         R(1) = 0.0D0
         R(2) = R(2) - 0.0D0
      ENDIF
      IF (IFIXN .EQ. 1) THEN
         D(NN) = 1.0D0
         AL(NN) = 0.0D0
         R(NN) = 0.0D0
      ENDIF
!     eliminate the coupling of rows 2 and NN-1 to the fixed ends
      IF (IFIX1 .EQ. 1) AL(2) = 0.0D0
      IF (IFIXN .EQ. 1) AU(NN-1) = 0.0D0
      DO 20 I = 2, NN
         W = AL(I)/D(I-1)
         D(I) = D(I) - W*AU(I-1)
         R(I) = R(I) - W*R(I-1)
   20 CONTINUE
      U(NN) = R(NN)/D(NN)
      DO 30 I = NN - 1, 1, -1
         U(I) = (R(I) - AU(I)*U(I+1))/D(I)
   30 CONTINUE
      RETURN
      END
