      SUBROUTINE VUTEMP(TEMP, NBLOCK, NCOMP, NFIELD,
     1 KSTEP, JFLAGS, JNODEUID, TIME, FIELD,
     2 COORDS, U, V, A)
!
      INCLUDE 'VABA_PARAM.INC'
!
      PARAMETER (i_utmp_Current = 1, i_utmp_Increment = 2,
     1 i_utmp_Period = 3, i_utmp_Total = 4, n_utmp_Time = 4)
      PARAMETER (i_utmp_kInc = 1, i_utmp_kPass = 2, n_utmp_Flags = 2)
      PARAMETER (n_utmp_SolU = 7, n_utmp_SolV = 7, n_utmp_SolA = 7)
      DIMENSION TEMP(NBLOCK,NCOMP), FIELD(NBLOCK,NCOMP,NFIELD)
      DIMENSION JFLAGS(n_utmp_Flags), JNODEUID(NBLOCK),
     1 TIME(n_utmp_Time), COORDS(3,NBLOCK)
      DIMENSION U(n_utmp_SolU,NBLOCK), V(n_utmp_SolV,NBLOCK),
     1 A(n_utmp_SolA,NBLOCK)
!
!     Relaxation of every node towards a target temperature that rises
!     linearly along x, Eq. (6.5-1).  Units: mm, s, degC.
      PARAMETER (TA = 20.0D0, DTX = 100.0D0, XL = 400.0D0)
!        TA target at x = 0 (degC); DTX rise of the target over XL (K)
      PARAMETER (TAU = 30.0D0)
!        TAU relaxation time (s)
!
      DT = TIME(i_utmp_Increment)
      F = EXP(-DT/TAU)
      DO 100 KM = 1, NBLOCK
         TINF = TA + DTX*COORDS(1,KM)/XL
         TEMP(KM,1) = TINF + (TEMP(KM,1) - TINF)*F
  100 CONTINUE
!
      RETURN
      END
