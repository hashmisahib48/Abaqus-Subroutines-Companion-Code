      PROGRAM K6TR
!     Calls the transport form of UMOTION (Listing 6.9) for four steps.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2)
      PARAMETER (PI = 3.14159265358979D0)
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      DO 10 KSTEP = 1, 4
         U = -1.0D0
         CALL UMOTION(U, KSTEP, 1, TIME, 1, 0)
         WRITE (*,'(I3,F12.4,F12.2)') KSTEP, U, U*30.0D0/PI
   10 CONTINUE
      END
