      SUBROUTINE UMOTION(U,KSTEP,KINC,TIME,NODE,JDOF)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), VSPD(4)
!
!     Rolling speed from the travel speed of a free-rolling wheel,
!     Eq. (6.8-2).  Units: mm, s, rad.
      PARAMETER (REFF = 300.0D0)
!        REFF effective rolling radius (mm)
      DATA VSPD /5.0D3, 1.0D4, 2.0D4, 2.7778D4/
!        VSPD travel speed of steps 1 to 4 (mm/s)
!
      IF (JDOF .EQ. 0) THEN
         U = VSPD(MIN(KSTEP,4))/REFF
      ENDIF
!
      RETURN
      END
