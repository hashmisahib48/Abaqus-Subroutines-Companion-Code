      PROGRAM K6M3D
!     Kinematic test of UMOTION for two simultaneous rotations and a
!     translation (Eq. 6.8-1): a cube of 8 nodes. Writes the nodal
!     displacements at p = 0.25, 0.5 and 1 for a comparison made outside
!     this program and checks that all pair distances are preserved.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), XC(3,8), X1(3,8), X2(3,8), XP(3,8), XM(3,8)
      OPEN (UNIT=70, FILE='k6_nodes.txt')
      N = 0
      DO 5 I = 0, 1
         DO 5 J = 0, 1
            DO 5 K = 0, 1
               N = N + 1
               XC(1,N) = 20.0D0 + 50.0D0*I
               XC(2,N) = 10.0D0 + 40.0D0*J
               XC(3,N) = 30.0D0*K
               WRITE (70,*) N, XC(1,N), XC(2,N), XC(3,N)
    5 CONTINUE
      CLOSE (70)
      OPEN (UNIT=71, FILE='u3d.txt')
      DO 100 IP = 1, 3
         P = 0.25D0*IP
         IF (IP .EQ. 3) P = 1.0D0
         TIME(1) = P
         TIME(2) = P
         DO 20 N = 1, 8
            DO 10 JD = 1, 3
               CALL UMOTION(U, 1, 1, TIME, N, JD)
               X1(JD,N) = XC(JD,N) + U
   10       CONTINUE
            WRITE (71,'(I2,F6.2,3F18.12)') N, P, (X1(JD,N)-XC(JD,N),
     1         JD=1,3)
   20    CONTINUE
         DMAX = 0.0D0
         DO 40 N = 1, 8
            DO 40 M = N + 1, 8
               D0 = SQRT((XC(1,N)-XC(1,M))**2 + (XC(2,N)-XC(2,M))**2
     1              + (XC(3,N)-XC(3,M))**2)
               D1 = SQRT((X1(1,N)-X1(1,M))**2 + (X1(2,N)-X1(2,M))**2
     1              + (X1(3,N)-X1(3,M))**2)
               DMAX = MAX(DMAX, ABS(D1 - D0))
   40    CONTINUE
         WRITE (*,'(A,F6.2,A,E10.3)') 'p =', P,
     1      '  max change of a pair distance (mm):', DMAX
  100 CONTINUE
      END
