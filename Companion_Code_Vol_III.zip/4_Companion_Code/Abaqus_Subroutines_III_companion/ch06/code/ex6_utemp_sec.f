      SUBROUTINE UTEMP(TEMP,NSECPT,KSTEP,KINC,TIME,NODE,COORDS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TEMP(NSECPT), TIME(2), COORDS(3)
!
!     Shell section given as a reference value and a gradient
!     (NSECPT = 2): TEMP(1) mid-surface temperature (degC),
!     TEMP(2) gradient through the thickness (K/mm), ramped in 10 s.
!     A solid node (no section) takes TEMP(1) only.
      PARAMETER (TREF = 20.0D0, TMID = 70.0D0, GRAD = 10.0D0)
      PARAMETER (TRAMP = 10.0D0)
!
      S = MIN(TIME(1)/TRAMP, 1.0D0)
      TEMP(1) = TREF + S*(TMID - TREF)
      IF (NSECPT .GE. 2) TEMP(2) = S*GRAD
!
      RETURN
      END
