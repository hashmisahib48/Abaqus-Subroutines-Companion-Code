      SUBROUTINE UTEMP(TEMP,NSECPT,KSTEP,KINC,TIME,NODE,COORDS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TEMP(NSECPT), TIME(2), COORDS(3)
!
!     Gaussian temperature pulse travelling along x, Eq. (6.3-1).
!     Units: mm, s, degC.
      PARAMETER (T0 = 20.0D0)
!        T0    initial temperature (degC)
      PARAMETER (DTMAX = 300.0D0, W = 20.0D0, V = 10.0D0)
!        DTMAX peak temperature rise (K); W pulse half-width (mm)
!        V     speed of the pulse (mm/s)
      PARAMETER (XST = -60.0D0)
!        XST   centre of the pulse at step time zero (mm)
!
      XC = XST + V*TIME(1)
      TEMP(1) = T0 + DTMAX*EXP(-((COORDS(1) - XC)/W)**2)
!
      RETURN
      END
