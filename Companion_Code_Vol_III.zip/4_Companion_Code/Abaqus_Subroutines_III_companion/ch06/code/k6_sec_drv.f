      PROGRAM K6SEC
!     Calls the section form of UTEMP (Listing 6.3) for a shell node
!     (NSECPT = 2) and for a solid node of the same model (NSECPT = 2
!     is the maximum over the model; only TEMP(1) is used there).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TEMP(2), TIME(2), COORDS(3)
      DATA COORDS /0.0D0, 0.0D0, 0.0D0/
      DO 10 K = 0, 4
         TT = 2.5D0*K
         TIME(1) = TT
         TIME(2) = TT
         TEMP(1) = -999.0D0
         TEMP(2) = -999.0D0
         CALL UTEMP(TEMP, 2, 1, K, TIME, 1, COORDS)
         WRITE (*,'(F6.2,2F10.3)') TT, TEMP(1), TEMP(2)
   10 CONTINUE
      END
