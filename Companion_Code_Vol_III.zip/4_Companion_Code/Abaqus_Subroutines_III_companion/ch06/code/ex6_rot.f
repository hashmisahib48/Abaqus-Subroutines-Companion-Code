      SUBROUTINE K6_ROT(AX, ANG, R)
!     Rotation matrix about the unit vector AX by ANG (rad), Rodrigues
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION AX(3), R(3,3)
      C = COS(ANG)
      S = SIN(ANG)
      DO 20 I = 1, 3
         DO 10 J = 1, 3
            R(I,J) = (1.0D0 - C)*AX(I)*AX(J)
   10    CONTINUE
         R(I,I) = R(I,I) + C
   20 CONTINUE
      R(1,2) = R(1,2) - S*AX(3)
      R(2,1) = R(2,1) + S*AX(3)
      R(1,3) = R(1,3) + S*AX(2)
      R(3,1) = R(3,1) - S*AX(2)
      R(2,3) = R(2,3) - S*AX(1)
      R(3,2) = R(3,2) + S*AX(1)
      RETURN
      END
!
      SUBROUTINE K6_LOADREF(FNAME)
!     Reference coordinates of the moved nodes: one line per node,
!     node number and X, Y, Z (mm), free format
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) FNAME
      COMMON /K6_REF/ XREF(3,10000)
      OPEN (UNIT=77, FILE=FNAME, STATUS='OLD')
   10 READ (77, *, END=20) N, X, Y, Z
      XREF(1,N) = X
      XREF(2,N) = Y
      XREF(3,N) = Z
      GO TO 10
   20 CLOSE (77)
      RETURN
      END
