      PROGRAM K6VDRV
!     Driver for VUTEMP (Listing 6.4): nodes are passed in blocks, TEMP
!     carries the temperature of the previous increment, as in
!     Abaqus/Explicit.  Compared with the closed form of Eq. 6.5-1 and
!     with a forward-Euler update of the same relaxation.
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NN = 41, TA = 20.0D0, DTX = 100.0D0, XL = 400.0D0)
      PARAMETER (TAU = 30.0D0, TEND = 120.0D0)
      DIMENSION TEMP(NN,1), TREF(NN,1), FIELD(NN,1,1), JFLAGS(2),
     1 JNODEUID(NN), TIME(4), COORDS(3,NN), U(7,NN), V(7,NN), A(7,NN)
      DIMENSION TFE(NN), DTL(3), NBL(3)
      DATA DTL /15.0D0, 30.0D0, 60.0D0/, NBL /7, 16, 41/
      DO 600 IB = 1, 3
         NB = NBL(IB)
         DO 500 ID = 1, 3
            DT = DTL(ID)
            NINC = NINT(TEND/DT)
            DO 10 N = 1, NN
               TEMP(N,1) = TA
               TFE(N) = TA
               COORDS(1,N) = (N - 1)*XL/(NN - 1)
               COORDS(2,N) = 0.0D0
               COORDS(3,N) = 0.0D0
               JNODEUID(N) = N
   10       CONTINUE
            EEX = 0.0D0
            EFE = 0.0D0
            DO 400 KINC = 1, NINC
               T1 = KINC*DT
               TIME(1) = T1
               TIME(2) = DT
               TIME(3) = TEND
               TIME(4) = T1
               JFLAGS(1) = KINC
               JFLAGS(2) = 1
!              blocks of NB nodes, the last one shorter
               DO 300 N1 = 1, NN, NB
                  NBK = MIN(NB, NN - N1 + 1)
                  CALL K6_VBLOCK(TEMP, N1, NBK, NN, JFLAGS, JNODEUID,
     1               TIME, FIELD, COORDS, U, V, A)
  300          CONTINUE
               DO 350 N = 1, NN
                  TINF = TA + DTX*COORDS(1,N)/XL
                  TFE(N) = TFE(N) + (TINF - TFE(N))*DT/TAU
                  TCF = TINF + (TA - TINF)*EXP(-T1/TAU)
                  EEX = MAX(EEX, ABS(TEMP(N,1) - TCF))
                  EFE = MAX(EFE, ABS(TFE(N) - TCF))
  350          CONTINUE
  400       CONTINUE
            WRITE (*,'(I4,F7.1,2E14.5)') NB, DT, EEX, EFE
  500    CONTINUE
  600 CONTINUE
      END
!
      SUBROUTINE K6_VBLOCK(TEMP, N1, NBK, NN, JFLAGS, JNODEUID, TIME,
     1 FIELD, COORDS, U, V, A)
!     copies a block of NBK nodes out of the global arrays, calls
!     VUTEMP and copies the temperatures back
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION TEMP(NN,1), FIELD(NN,1,1), JFLAGS(2), JNODEUID(NN),
     1 TIME(4), COORDS(3,NN), U(7,NN), V(7,NN), A(7,NN)
      DIMENSION TB(NBK,1), FB(NBK,1,1), JB(NBK), CB(3,NBK),
     1 UB(7,NBK), VB(7,NBK), AB(7,NBK)
      DO 10 K = 1, NBK
         TB(K,1) = TEMP(N1+K-1,1)
         FB(K,1,1) = 0.0D0
         JB(K) = JNODEUID(N1+K-1)
         CB(1,K) = COORDS(1,N1+K-1)
         CB(2,K) = COORDS(2,N1+K-1)
         CB(3,K) = COORDS(3,N1+K-1)
   10 CONTINUE
      DO 20 K = 1, NBK
         DO 20 L = 1, 7
            UB(L,K) = 0.0D0
            VB(L,K) = 0.0D0
            AB(L,K) = 0.0D0
   20 CONTINUE
      CALL VUTEMP(TB, NBK, 1, 1, 1, JFLAGS, JB, TIME, FB, CB, UB, VB,
     1 AB)
      DO 30 K = 1, NBK
         TEMP(N1+K-1,1) = TB(K,1)
   30 CONTINUE
      RETURN
      END
