      PROGRAM K6HING
!     Hinged radiating strips: UMOTION (Listing 6.8) moves strip 2 about
!     the hinge; the view factor from the crossed-string method is
!     compared with F12 = 1 - sin(phi/2).  Units mm, s, degrees.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0, DEG = PI/180.0D0)
      PARAMETER (WID = 100.0D0, PHI0 = 30.0D0, TH1 = 120.0D0)
      PARAMETER (SIGM = 5.670374D-11, T1 = 800.0D0, T2 = 400.0D0)
      DIMENSION TIME(2), XA1(3), XB1(3), XA2(3), XB2(3)
      OPEN (UNIT=70, FILE='k6_nodes.txt')
      WRITE (70,*) 201, 0.0D0, 0.0D0, 0.0D0
      WRITE (70,*) 202, WID*COS(PHI0*DEG), WID*SIN(PHI0*DEG), 0.0D0
      CLOSE (70)
      XA1 = 0.0D0
      XB1 = 0.0D0
      XB1(1) = WID
      EMAX = 0.0D0
      DO 100 K = 0, 8
         P = K/8.0D0
         TIME(1) = P
         TIME(2) = P
         DO 10 JD = 1, 3
            CALL UMOTION(U, 1, K, TIME, 201, JD)
            XA2(JD) = 0.0D0 + U
            CALL UMOTION(U, 1, K, TIME, 202, JD)
            XB2(JD) = U
   10    CONTINUE
         XB2(1) = XB2(1) + WID*COS(PHI0*DEG)
         XB2(2) = XB2(2) + WID*SIN(PHI0*DEG)
         CR = DIST(XA1,XB2) + DIST(XB1,XA2)
         UN = DIST(XA1,XA2) + DIST(XB1,XB2)
         F12 = (CR - UN)/(2.0D0*DIST(XA1,XB1))
         PHI = PHI0 + TH1*P
         FCF = 1.0D0 - SIN(0.5D0*PHI*DEG)
         Q12 = WID*F12*SIGM*(T1**4 - T2**4)
         EMAX = MAX(EMAX, ABS(F12 - FCF))
         WRITE (*,'(F7.3,F8.2,2F12.6,E11.2,F10.3)') P, PHI, F12, FCF,
     1      F12 - FCF, Q12
  100 CONTINUE
      WRITE (*,'(A,E11.3)') 'max |F12 - closed form| = ', EMAX
      END
      DOUBLE PRECISION FUNCTION DIST(A, B)
      DOUBLE PRECISION A(3), B(3)
      DIST = SQRT((A(1)-B(1))**2 + (A(2)-B(2))**2 + (A(3)-B(3))**2)
      END
