"""Independent references for Chapter 12 (scipy, not the Fortran routines)."""
import numpy as np, json, glob
from scipy.optimize import brentq
O={}
# ---------- cavity ----------
K0,KP,AL,V0=2200.,7.,2.1e-4,1e6
rho=lambda p,T: 1e-9*(1+KP*p/K0)**(1/KP)*np.exp(-AL*(T-20))
def pcav(T,Cw,DV):
    m=rho(0,20)*V0
    return brentq(lambda p: m/rho(p,T)-(V0+DV+Cw*p),-0.5*K0/KP,2000.)
def rd(f):
    return np.array([[float(x) for x in l.split()[:2]] for l in open(f).read().splitlines()[1:10]])
for name,(Cw,DV) in {'rigid':(0,0),'wall':(40,0),'piston':(0,-50)}.items():
    d=rd(f'out_cav_{name}.txt'); ref=np.array([pcav(T,Cw,DV) for T in d[:,0]])
    O['cav_'+name+'_maxerr']=float(np.max(abs(d[:,1]-ref))); O['cav_'+name+'_p30']=float(pcav(30,Cw,DV)); O['cav_'+name+'_p40']=float(pcav(40,Cw,DV))
O['cav_rigid_closed_30']=K0/KP*(np.exp(AL*KP*10)-1)
O['cav_piston_closed_20']=K0/KP*(((V0/(V0-50))*1.0)**KP-1)
# linear (constant K) estimate for wall case, 10 K
O['cav_wall_lin_30']=AL*10/(1/K0+40/V0)
O['cav_rigid_lin_30']=AL*10*K0
# ---------- friction ----------
def colebrook(Re,rel):
    g=lambda f: 1/np.sqrt(f)+2*np.log10(rel/3.7+2.51/(Re*np.sqrt(f)))
    return brentq(g,1e-4,1.0,xtol=1e-15,rtol=1e-14)
def haaland(Re,rel): return 1/(-1.8*np.log10((rel/3.7)**1.11+6.9/Re))**2
rows=[l.split() for l in open('out_fric.txt').read().splitlines()[1:26]]
mx=0
for l in rows:
    Re=float(l[0]); f=float(l[1])
    if Re>=4000: mx=max(mx,abs(f/colebrook(Re,0.046/100)-1))
O['fric_routine_vs_colebrook_maxrel']=mx
# Haaland error map
Res=np.logspace(np.log10(4e3),8,200); rels=[0,1e-5,1e-4,1e-3,1e-2,5e-2]
err={}
for rel in rels:
    e=[haaland(R,rel)/colebrook(R,rel)-1 for R in Res]; err[rel]=(min(e),max(e))
O['haal_err']={str(k):v for k,v in err.items()}
O['haal_absmax']=max(max(abs(a),abs(b)) for a,b in err.values())
# ---------- network ----------
RH=1e-9
def branch(IB,Q,nu,nel,val,t,laminar_only=False):
    L,D=(5e4,100.) if IB==1 else (8e4,80.)
    A=np.pi*D*D/4; v=Q/A; Re=max(v*D/nu,1.)
    rel=0.046/D
    fl=64/Re
    if Re<=2000: f=fl
    else:
        ft=colebrook(Re,rel)
        if Re>=4000: f=ft
        else:
            u=(Re-2000)/2000; w=u*u*(3-2*u); f=(1-w)*fl+w*ft
    K=nel*(800/Re+0.4*(1+25.4/D))
    if val:
        u=min(max((t-10)/20,0),1); s=u*u*(3-2*u); x=1-0.95*s
        K+=0.2/x**2
    return (f*L/D+K)*0.5*RH*v*v
def net(nu,Q,t,n1,n2,v1,v2):
    h=lambda q1: branch(1,q1,nu,n1,v1,t)-branch(2,Q-q1,nu,n2,v2,t)
    q1=brentq(h,1e-6*Q,(1-1e-6)*Q,xtol=1e-6,rtol=1e-14); return q1,Q-q1,branch(1,q1,nu,n1,v1,t)
cases={'lam':(1000,2e6,0,0,0,0,0),'rough':(1e-4,3e7,0,2,1,0,1)}
for t in [0,10,15,20,25,30,40]: cases['t%d'%t]=(1.0,3e7,t,2,1,0,1)
mxd=0; res={}
for k,c in cases.items():
    r=net(*c); l=open(f'out_net_{k}.txt').read().split()
    fo=[float(l[0]),float(l[1]),float(l[2])]
    mxd=max(mxd,max(abs(fo[j]/r[j]-1) for j in range(3)))
    res[k]=dict(Q1=r[0],Q2=r[1],dp=r[2],iterHC=int(l[5]),iterNW=int(l[6]))
O['net_maxrel']=mxd; O['net']=res
# closed forms
mu=1000*RH
G=lambda D,L: np.pi*D**4/(128*mu*L)
g1,g2=G(100,5e4),G(80,8e4)
O['lam_cf']=dict(Q1=2e6*g1/(g1+g2),Q2=2e6*g2/(g1+g2),dp=2e6/(g1+g2))
fr=lambda D:(1/(-2*np.log10(0.046/D/3.7)))**2
R=lambda L,D,K:(fr(D)*L/D+K)*0.5*RH/(np.pi*D*D/4)**2
Kel=0.4*(1+25.4/100); Kel2=0.4*(1+25.4/80)
R1=R(5e4,100,2*Kel); R2=R(8e4,80,Kel2+0.2/0.05**2)
R2o=R(8e4,80,Kel2+0.2)
# rough case is at t=0 -> valve open (x=1)
R2=R2o
O['rough_cf']=dict(Q1=3e7/(1+np.sqrt(R1/R2)),dp=R1*(3e7/(1+np.sqrt(R1/R2)))**2)
# valve fully closed limit : all flow in branch 1
O['closed_dp_branch1_3e7']=branch(1,3e7,1.0,2,0,0)
O['q2_fraction']={k:res[k]['Q2']/3e7 for k in res}
json.dump(O,open('numbers.json','w'),indent=1,default=float)
print(json.dumps(O,indent=1,default=float))
