      SUBROUTINE UFLUIDPIPEFRICTION(FRICTION,FLOW,RHO,VISC,ROUGH,DIA,
     1 AREA,NDIM,JELNO,KSTEP,KINC,TIME,COORDS,NIARRAY,I_ARRAY,
     2 NRARRAY,R_ARRAY,NCARRAY,C_ARRAY)
!     Darcy friction factor: 64/Re (laminar), Colebrook (turbulent),
!     smooth blend for 2000 < Re < 4000.  FLOW in mm^3/s, RHO in
!     t/mm^3, VISC in t/(mm s), ROUGH and DIA in mm, AREA in mm^2.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(2*NDIM), I_ARRAY(NIARRAY)
      DIMENSION R_ARRAY(NRARRAY)
      CHARACTER*80 C_ARRAY(NCARRAY)
      PARAMETER (RELAM = 2.D3, RETUR = 4.D3)   ! transition, -
      V  = ABS(FLOW)/AREA                      ! mm/s
      RE = MAX(RHO*V*DIA/VISC, 1.D0)
      FLAM = 64.D0/RE
      IF (RE .LE. RELAM) THEN
         FRICTION = FLAM
      ELSE
         FTUR = 0.25D0/LOG10(ROUGH/DIA/3.7D0+5.74D0/RE**0.9D0)**2
         IF (RE .GE. RETUR) THEN
            FRICTION = FTUR
         ELSE
            U = (RE - RELAM)/(RETUR - RELAM)
            W = U*U*(3.D0 - 2.D0*U)
            FRICTION = (1.D0 - W)*FLAM + W*FTUR
         ENDIF
      ENDIF
      RETURN
      END
!
      SUBROUTINE K12_HAAL(RE, REL, F)
!     Haaland (1983) explicit approximation; REL = roughness/diameter
      INCLUDE 'ABA_PARAM.INC'
      X = -1.8D0*LOG10((REL/3.7D0)**1.11D0 + 6.9D0/RE)
      F = 1.D0/(X*X)
      RETURN
      END
!
      SUBROUTINE K12_COLEB(RE, REL, F)
!     Colebrook equation, Newton iteration on X = 1/SQRT(F)
      INCLUDE 'ABA_PARAM.INC'
      CALL K12_HAAL(RE, REL, F)
      X = 1.D0/SQRT(F)
      A = REL/3.7D0
      B = 2.51D0/RE
      DO 10 IT = 1, 20
         ARG = A + B*X
         FX  = X + 2.D0*LOG10(ARG)
         DFX = 1.D0 + 2.D0*B/(LOG(10.D0)*ARG)
         DX  = -FX/DFX
         X   = X + DX
         IF (ABS(DX) .LT. 1.D-13*X) GOTO 20
   10 CONTINUE
   20 F = 1.D0/(X*X)
      RETURN
      END
