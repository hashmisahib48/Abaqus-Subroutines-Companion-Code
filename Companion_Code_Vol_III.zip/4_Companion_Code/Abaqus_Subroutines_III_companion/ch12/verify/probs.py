import numpy as np, json
from scipy.optimize import brentq
exec(open('ref.py').read().split('# ---------- cavity')[0])
exec("def colebrook(Re,rel):\n    g=lambda f: 1/np.sqrt(f)+2*np.log10(rel/3.7+2.51/(Re*np.sqrt(f)))\n    return brentq(g,1e-4,1.0,xtol=1e-15,rtol=1e-14)\ndef haaland(Re,rel): return 1/(-1.8*np.log10((rel/3.7)**1.11+6.9/Re))**2")
P={}
# A1
K0,KP,AL=1500.,9.,7e-4; P['A1_exact']=K0/KP*(np.exp(AL*KP*15)-1); P['A1_lin']=K0*AL*15
# A2
D=50.;e=0.15;Q=5e6;A=np.pi*D*D/4;v=Q/A;Re=v*D/1.0
fc=colebrook(Re,e/D);fh=haaland(Re,e/D);rho=1e-9
dp=lambda f:f*1e5/D*0.5*rho*v*v
P['A2']=dict(v=v,Re=Re,fc=fc,fh=fh,dpc=dp(fc),dph=dp(fh))
# A3
Re3=5000.;P['A3_K']=800/Re3+0.4*(1+25.4/50)
u=(22-10)/20;s=u*u*(3-2*u);x=1-0.95*s;P['A3_x']=x;P['A3_Kv']=0.2/x**2
# B1 newton history
K0,KP,AL,V0=2200.,7.,2.1e-4,1e6
rho=lambda p,T: 1e-9*(1+KP*p/K0)**(1/KP)*np.exp(-AL*(T-20))
m=rho(0,20)*V0;Cw=40.;p=0.;hist=[]
pex=brentq(lambda p: m/rho(p,30)-(V0+Cw*p),0,50,xtol=1e-14)
for k in range(5):
    R=m/rho(p,30)-(V0+Cw*p);Cp=1/(K0+KP*p);dR=-(m/rho(p,30))*Cp-Cw;p=p-R/dR;hist.append((p,abs(p-pex)))
P['B1']=hist;P['B1_pex']=pex
# C1 Swamee-Jain error
sj=lambda Re,rel:0.25/np.log10(rel/3.7+5.74/Re**0.9)**2
mx=0;arg=None
for rel in np.logspace(-6,-2,9):
    for R in np.logspace(np.log10(5e3),8,120):
        e_=sj(R,rel)/colebrook(R,rel)-1
        if abs(e_)>abs(mx): mx=e_;arg=(R,rel)
P['C1_maxerr']=mx;P['C1_arg']=arg
# C2 valve time for Q2/Q=0.25 (ref solver)
src=open('ref.py').read()
exec(src[src.index('# ---------- network'):src.index('cases=')])
fr=lambda t: net(1.0,3e7,t,2,1,0,1)[1]/3e7-0.25
P['C2_t']=brentq(fr,20,30); 
P['C2_x']=1-0.95*(lambda u:u*u*(3-2*u))((P['C2_t']-10)/20)
P['q2frac_at_t']={t:net(1.0,3e7,t,2,1,0,1)[1]/3e7 for t in (0,20,25,30)}
json.dump(P,open('probs.json','w'),indent=1,default=float);print(json.dumps(P,indent=1,default=float))
