import numpy as np, json
from scipy.optimize import brentq
src=open('ref.py').read()
exec(src[src.index('# ---------- network'):src.index('cases=')])
def colebrook(Re,rel):
    g=lambda f: 1/np.sqrt(f)+2*np.log10(rel/3.7+2.51/(Re*np.sqrt(f)))
    return brentq(g,1e-4,1.0,xtol=1e-15,rtol=1e-14)
def haaland(Re,rel): return 1/(-1.8*np.log10((rel/3.7)**1.11+6.9/Re))**2
rows=[l.split() for l in open('out_fric.txt').read().splitlines()[1:26]]
print('table 12.6')
for l in rows:
    Re=float(l[0])
    if abs(np.log10(Re)-round(np.log10(Re)))<1e-9 or abs(np.log10(Re)-3.5)<1e-9:
        f=float(l[1]);fh=float(l[2]); print(f'{Re:9.3e} {f:.6f} {fh:.6f} {100*(fh/f-1):+.2f}%  K={float(l[3]):.4f}')
# Ex 12.6-1 pressure drop per 100 m at Re=1e5, D=100, nu=1
Re=1e5;D=100.;v=Re*1.0/D; fc=colebrook(Re,0.046/D);fh=haaland(Re,0.046/D)
print('v mm/s',v,'Q L/s',v*np.pi*D*D/4/1e6,'fc',fc,'fh',fh,'dp/100m MPa',fc*1e5/D*0.5*1e-9*v*v,'kPa',fc*1e5/D*0.5*1e-9*v*v*1e3, fh*1e5/D*0.5*1e-9*v*v*1e3)
# elbow
print('K inf D100',0.4*(1+25.4/100),'D25',0.4*(1+25.4/25),'Re cross',800/(0.4*(1+25.4/100)),800/(0.4*(1+25.4/25)))
print('elbow dp at Re=1e5 D100: Pa',0.5096*1000*1.0**2/2*(1) , 'v=',1e5*1/100/1000,'m/s')
# network
nu=1.0;Q=3e7
for t in [0,10,15,20,25,30,40]:
    q1,q2,dp=net(nu,Q,t,2,1,0,1); dp2=branch(2,q2,nu,1,1,t)
    u=min(max((t-10)/20,0),1); x=1-0.95*u*u*(3-2*u)
    A1=np.pi*100**2/4;A2=np.pi*80**2/4
    print(t,round(x,5),q1/1e6,q2/1e6,dp*1e3,'q2/Q',q2/Q,'dp diff rel',abs(dp-dp2)/dp,'Re1',q1/A1*100/nu,'Re2',q2/A2*80/nu)
