      PROGRAM BUG
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(6), IA(1), RA(1)
      CHARACTER*80 CA(1)
      PARAMETER (PI = 3.14159265358979D0)
      DIA = 100.D0
      AREA = 0.25D0*PI*DIA*DIA
      DO 10 K = 1, 4
         IF (K .EQ. 1) RE = 1.D5
         IF (K .EQ. 2) RE = -1.D5
         IF (K .EQ. 3) RE = 1.D3
         IF (K .EQ. 4) RE = 0.D0
         Q = RE*1.D-9/(1.D-9*DIA)*AREA
         CALL UFLUIDPIPEFRICTION(F,Q,1.D-9,1.D-9,0.046D0,DIA,AREA,3,1,
     1    1,1,TIME,COORDS,1,IA,1,RA,1,CA)
         WRITE(*,'(1P,2E14.6)') RE, F
   10 CONTINUE
      END
