      SUBROUTINE UFLUIDCONNECTORVALVE(VALVEOPENING,COORDS,FLOW,RHO,
     1 VISC,DIA,AREA,NDIM,JELNO,KSTEP,KINC,TIME,NIARRAY,I_ARRAY,
     2 NRARRAY,R_ARRAY,NCARRAY,C_ARRAY)
!     Valve 202 closes from fully open to OMIN between total times
!     T1 and T2 (cubic smoothstep); all other valves stay open.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(2*NDIM), I_ARRAY(NIARRAY)
      DIMENSION R_ARRAY(NRARRAY)
      CHARACTER*80 C_ARRAY(NCARRAY)
      PARAMETER (JVALVE = 202)         ! element number of the valve
      PARAMETER (T1 = 10.D0, T2 = 30.D0)  ! closing from T1 to T2, s
      PARAMETER (OMIN = 0.05D0)        ! final opening, 0 shut, 1 open
      VALVEOPENING = 1.D0
      IF (JELNO .EQ. JVALVE) THEN
         U = MIN(MAX((TIME(2) - T1)/(T2 - T1), 0.D0), 1.D0)
         S = U*U*(3.D0 - 2.D0*U)
         VALVEOPENING = 1.D0 - (1.D0 - OMIN)*S
      ENDIF
      RETURN
      END
