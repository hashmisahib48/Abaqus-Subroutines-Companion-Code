      SUBROUTINE UFLUIDCONNECTORLOSS(AK1,AK2,COORDS,FLOW,RHO,VISC,DIA,
     1 AREA,NDIM,JELNO,KSTEP,KINC,TIME,NIARRAY,I_ARRAY,NRARRAY,
     2 R_ARRAY,NCARRAY,C_ARRAY)
!     Hooper 2K loss of a 90-degree elbow, K = K1/Re + KINF*(1+1/ID),
!     ID in inches.  The elbow is symmetric: AK1 = AK2.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(2*NDIM), I_ARRAY(NIARRAY)
      DIMENSION R_ARRAY(NRARRAY)
      CHARACTER*80 C_ARRAY(NCARRAY)
      PARAMETER (XK1 = 800.D0)    ! Hooper K1, -
      PARAMETER (XKINF = 0.40D0)  ! Hooper K-infinity, -
      PARAMETER (XIN = 25.4D0)    ! mm per inch
      V  = ABS(FLOW)/AREA                      ! mm/s
      RE = MAX(RHO*V*DIA/VISC, 1.D0)
      AK = XK1/RE + XKINF*(1.D0 + XIN/DIA)
      AK1 = AK
      AK2 = AK
      RETURN
      END
