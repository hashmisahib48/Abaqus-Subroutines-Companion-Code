      PROGRAM K12CAV
!     Closed cavity filled with the liquid of UFLUID: pressure as the
!     temperature rises, Newton iteration on the cavity pressure.
!     Residual R(p) = m/rho(p,T) - (V0 + DV + CW*p),  dR/dp uses CP.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2)
      CHARACTER*80 FLNAME
      PARAMETER (V0 = 1.0D6)       ! initial cavity volume, mm^3
      PARAMETER (T0 = 20.D0)
      READ(*,*) CW, DV             ! wall compliance, added volume
      PN = 1.D30                   ! PNEWDT, reset before each call
      CALL UFLUID(RHOI,CP,CT,PN,EN,0.D0,0.D0,0.D0,T0,0.D0,T0,TIME,
     1 1.D0,1,1,1,FLNAME,0)
      XM = RHOI*V0
      P = 0.D0
      WRITE(*,'(A)') '  T/degC   p/MPa     iters   residual'
      DO 100 K = 0, 8
         T = T0 + 2.5D0*K
         DO 50 IT = 1, 20
            CALL UFLUID(RHO,CP,CT,PN,EN,P,0.D0,0.D0,T,0.D0,T0,TIME,
     1       1.D0,1,1,1,FLNAME,0)
            RES = XM/RHO - (V0 + DV + CW*P)
            DRES = -(XM/RHO)*CP - CW
            DP = -RES/DRES
            P = P + DP
            IF (ABS(DP) .LT. 1.D-12*MAX(1.D0,ABS(P))) GOTO 60
   50    CONTINUE
   60    WRITE(*,'(F8.2,F12.6,I6,1P,E12.3)') T, P, IT, RES
  100 CONTINUE
!     one increment from p = 0 to 30 deg C: pressure after each update
      P = 0.D0
      WRITE(*,'(A)') 'jump to 30 C: iteration, p'
      DO 70 IT = 1, 4
         CALL UFLUID(RHO,CP,CT,PN,EN,P,0.D0,0.D0,30.D0,0.D0,T0,TIME,
     1    1.D0,1,1,1,FLNAME,0)
         RES = XM/RHO - (V0 + DV + CW*P)
         DRES = -(XM/RHO)*CP - CW
         P = P - RES/DRES
         WRITE(*,'(I4,F16.10)') IT, P
   70 CONTINUE
!     finite-difference check of CP and CT at p = 20 MPa, T = 35 deg C
      P1 = 20.D0
      T1 = 35.D0
      H = 1.D-3
      CALL UFLUID(R0,CP,CT,PN,EN,P1,0.D0,0.D0,T1,0.D0,T0,TIME,1.D0,
     1 1,1,1,FLNAME,0)
      CALL UFLUID(RP,CPP,CTP,PN,EN,P1+H,0.D0,0.D0,T1,0.D0,T0,TIME,
     1 1.D0,1,1,1,FLNAME,0)
      CALL UFLUID(RM,CPP,CTP,PN,EN,P1-H,0.D0,0.D0,T1,0.D0,T0,TIME,
     1 1.D0,1,1,1,FLNAME,0)
      CPFD = (RP - RM)/(2.D0*H)/R0
      CALL UFLUID(RP,CPP,CTP,PN,EN,P1,0.D0,0.D0,T1+H,0.D0,T0,TIME,
     1 1.D0,1,1,1,FLNAME,0)
      CALL UFLUID(RM,CPP,CTP,PN,EN,P1,0.D0,0.D0,T1-H,0.D0,T0,TIME,
     1 1.D0,1,1,1,FLNAME,0)
      CTFD = (RP - RM)/(2.D0*H)/R0
      WRITE(*,'(A,1P,3E14.6)') 'rho,CP,CPfd ', R0, CP, CPFD
      WRITE(*,'(A,1P,3E14.6)') 'CT,CTfd,rel ', CT, CTFD,
     1 ABS(CT-CTFD)/ABS(CT)
      WRITE(*,'(A,1P,E10.2)') 'relative error CP ', ABS(CP-CPFD)/CP
      END
