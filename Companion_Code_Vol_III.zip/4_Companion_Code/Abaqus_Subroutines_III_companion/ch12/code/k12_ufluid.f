      SUBROUTINE UFLUID(RHO,CP,CT,PNEWDT,ENER,PRESS,DPRESS,PRESSI,
     1 TEMP,DTEMP,TEMPI,TIME,DTIME,KSTEP,KINC,NONUM,FLNAME,LFLAG)
!     Liquid with a pressure-dependent bulk modulus K(p) = K0 + KP*p
!     (Murnaghan) and a constant thermal expansion ALPHA.
!     Units: N, mm, MPa, tonne, s, deg C.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2)
      CHARACTER*80 FLNAME
      PARAMETER (RHO0 = 1.0D-9)   ! density at p = 0, T0, t/mm^3
      PARAMETER (XK0  = 2200.D0)  ! bulk modulus at p = 0, MPa
      PARAMETER (XKP  = 7.0D0)    ! dK/dp, dimensionless
      PARAMETER (ALPHA = 2.1D-4)  ! volumetric expansion, 1/K
      PARAMETER (T0 = 20.D0)      ! reference temperature, deg C
      PARAMETER (PLIM = -0.9D0*XK0/XKP)  ! lowest admissible p, MPa
!     keep 1 + KP*p/K0 > 0; below PLIM ask for a smaller increment
      IF (PRESS .LT. PLIM) PNEWDT = MIN(PNEWDT, 0.5D0)
      PP = MAX(PRESS, PLIM)
      G  = 1.D0 + XKP*PP/XK0
      RHO = RHO0*G**(1.D0/XKP)*EXP(-ALPHA*(TEMP - T0))
      CP  = 1.D0/(XK0 + XKP*PP)   ! (1/rho) d rho/dp, 1/MPa
      CT  = -ALPHA                ! (1/rho) d rho/dT, 1/K
      RETURN
      END
