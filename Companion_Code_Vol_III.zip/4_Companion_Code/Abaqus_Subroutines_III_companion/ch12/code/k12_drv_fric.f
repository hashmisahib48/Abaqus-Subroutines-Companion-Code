      PROGRAM K12FRIC
!     Tabulate the friction routine, the Haaland approximation and the
!     elbow loss against Reynolds number (D = 100 mm, e = 0.046 mm).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2), COORDS(6), IA(1), RA(1)
      CHARACTER*80 CA(1)
      PARAMETER (PI = 3.14159265358979D0)
      RH = 1.0D-9
      VISC = 1.0D-9                    ! 1 mm^2/s
      DIA = 100.D0
      EPS = 0.046D0
      AREA = 0.25D0*PI*DIA*DIA
      WRITE(*,'(A)') '      Re        f_routine    f_Haaland    K_elbow'
      DO 10 K = 0, 24
         RE = 10.D0**(2.0D0 + 0.25D0*K)        ! 1e2 ... 1e8
         V  = RE*VISC/(RH*DIA)
         Q  = V*AREA
         CALL UFLUIDPIPEFRICTION(F,Q,RH,VISC,EPS,DIA,AREA,3,1,1,1,
     1    TIME,COORDS,1,IA,1,RA,1,CA)
         CALL K12_HAAL(RE, EPS/DIA, FH)
         CALL UFLUIDCONNECTORLOSS(AK1,AK2,COORDS,Q,RH,VISC,DIA,AREA,3,
     1    1,1,1,TIME,1,IA,1,RA,1,CA)
         WRITE(*,'(1P,E10.3,3E13.5)') RE, F, FH, AK1
   10 CONTINUE
!     valve schedule
      WRITE(*,'(A)') '  t/s   opening'
      DO 20 K = 0, 8
         TIME(2) = 5.D0*K
         CALL UFLUIDCONNECTORVALVE(X,COORDS,Q,RH,VISC,DIA,AREA,3,202,
     1    1,1,TIME,1,IA,1,RA,1,CA)
         WRITE(*,'(F6.1,F10.5)') TIME(2), X
   20 CONTINUE
!     monotonicity of the pressure drop: slope of ln(f*Re**2) vs ln(Re)
      SMIN = 1.D30
      SMAX = -1.D30
      DO 30 K = 0, 280
         RE = 10.D0**(1.D0 + K/40.D0)
         V  = RE*VISC/(RH*DIA)
         Q  = V*AREA
         CALL UFLUIDPIPEFRICTION(F1,Q*EXP(-1.D-6),RH,VISC,EPS,DIA,AREA,
     1    3,1,1,1,TIME,COORDS,1,IA,1,RA,1,CA)
         CALL UFLUIDPIPEFRICTION(F2,Q*EXP(1.D-6),RH,VISC,EPS,DIA,AREA,
     1    3,1,1,1,TIME,COORDS,1,IA,1,RA,1,CA)
         SL = (LOG(F2) - LOG(F1))/2.D-6 + 2.D0
         IF (SL .GT. SMAX) THEN
            SMAX = SL
            RMAX = RE
         ENDIF
         IF (SL .LT. SMIN) THEN
            SMIN = SL
            RMIN = RE
         ENDIF
   30 CONTINUE
      WRITE(*,'(A,F10.4,A,1P,E10.3)') 'min dln(dp)/dln(Q) = ', SMIN,
     1 '  at Re = ', RMIN
      WRITE(*,'(A,F10.4,A,1P,E10.3)') 'max dln(dp)/dln(Q) = ', SMAX,
     1 '  at Re = ', RMAX
      END
