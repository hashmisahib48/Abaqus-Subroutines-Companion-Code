      PROGRAM K12NET
!     Two parallel branches between nodes A and B carry the flow Q.
!     The branch head losses call the routines of Listings 12.2-12.4.
!     Hardy-Cross and Newton solve for the flow split.
      INCLUDE 'ABA_PARAM.INC'
      COMMON /NETD/ RHO, VISC, TTIME, NEL(2), IVAL(2)
      PARAMETER (RH = 1.0D-9)          ! t/mm^3
      READ(*,*) ENU, QT, TTIME, NEL(1), NEL(2), IVAL(1), IVAL(2)
      RHO  = RH
      VISC = ENU*RH                    ! t/(mm s); nu in mm^2/s
!     Hardy-Cross: dQ = -h/(2 sum dp/Q)
      Q1 = 0.5D0*QT
      DO 10 IT = 1, 50
         Q2 = QT - Q1
         CALL K12_BR(1, Q1, DP1)
         CALL K12_BR(2, Q2, DP2)
         H  = DP1 - DP2
         DQ = -H/(2.D0*(DP1/Q1 + DP2/Q2))
         Q1 = Q1 + DQ
         IF (ABS(DQ) .LT. 1.D-10*QT) GOTO 20
   10 CONTINUE
   20 ITHC = IT
      QHC = Q1
!     Newton with a central-difference derivative of h(Q1)
      Q1 = 0.5D0*QT
      DO 30 IT = 1, 50
         CALL K12_H(QT, Q1, H)
         DEL = 1.D-6*QT
         CALL K12_H(QT, Q1 + DEL, HP)
         CALL K12_H(QT, Q1 - DEL, HM)
         DQ = -H*2.D0*DEL/(HP - HM)
         Q1 = Q1 + DQ
         IF (ABS(DQ) .LT. 1.D-10*QT) GOTO 40
   30 CONTINUE
   40 ITNW = IT
      Q2 = QT - Q1
      CALL K12_BR(1, Q1, DP1)
      WRITE(*,'(1P,5E16.8,2I4)') Q1, Q2, DP1, QHC, Q1-QHC, ITHC, ITNW
      END
!
      SUBROUTINE K12_H(QT, Q1, H)
      INCLUDE 'ABA_PARAM.INC'
      CALL K12_BR(1, Q1, DP1)
      CALL K12_BR(2, QT - Q1, DP2)
      H = DP1 - DP2
      RETURN
      END
!
      SUBROUTINE K12_BR(IB, Q, DP)
!     Pressure drop of branch IB at the flow Q (mm^3/s), MPa
      INCLUDE 'ABA_PARAM.INC'
      COMMON /NETD/ RHO, VISC, TTIME, NEL(2), IVAL(2)
      DIMENSION TIME(2), COORDS(6), IA(1), RA(1)
      CHARACTER*80 CA(1)
      PARAMETER (PI = 3.14159265358979D0, EPS = 0.046D0)
      PARAMETER (XKV0 = 0.2D0)         ! valve K, fully open
      TIME(1) = TTIME
      TIME(2) = TTIME
      IF (IB .EQ. 1) THEN
         XL = 5.0D4                    ! mm
         DIA = 100.D0                  ! mm
         JEL = 101
      ELSE
         XL = 8.0D4
         DIA = 80.D0
         JEL = 102
      ENDIF
      AREA = 0.25D0*PI*DIA*DIA
      CALL UFLUIDPIPEFRICTION(F,Q,RHO,VISC,EPS,DIA,AREA,3,JEL,1,1,
     1 TIME,COORDS,1,IA,1,RA,1,CA)
      CALL UFLUIDCONNECTORLOSS(AK1,AK2,COORDS,Q,RHO,VISC,DIA,AREA,3,
     1 JEL,1,1,TIME,1,IA,1,RA,1,CA)
      XK = NEL(IB)*AK1
      IF (IVAL(IB) .EQ. 1) THEN
         CALL UFLUIDCONNECTORVALVE(X,COORDS,Q,RHO,VISC,DIA,AREA,3,202,
     1    1,1,TIME,1,IA,1,RA,1,CA)
         XK = XK + XKV0/(X*X)          ! driver law K = K0/x^2
      ENDIF
      V  = Q/AREA
      DP = (F*XL/DIA + XK)*0.5D0*RHO*V*V
      RETURN
      END
