#!/bin/sh
# compile all listings and run the drivers (gfortran, stubs in lib/aba)
A=/home/claude/vol3/lib/aba
F="-ffixed-form -std=legacy -I$A"
cd "$(dirname "$0")"
T=/tmp/claude-0/ch12; mkdir -p $T
for f in k12_ufluid.f k12_pipefric.f k12_connloss.f k12_valve.f; do gfortran -c $F $f -o $T/$f.o || exit 1; done
gfortran $F k12_drv_cav.f k12_ufluid.f $A/stubs.f -o $T/cav || exit 1
for c in "rigid:0 0" "wall:40 0" "piston:0 -50"; do n=${c%%:*}; echo "${c#*:}" | $T/cav > ../verify/out_cav_$n.txt; done
gfortran $F k12_drv_fric.f k12_pipefric.f k12_connloss.f k12_valve.f $A/stubs.f -o $T/fric || exit 1
$T/fric > ../verify/out_fric.txt
gfortran $F k12_drv_net.f k12_pipefric.f k12_connloss.f k12_valve.f $A/stubs.f -o $T/net || exit 1
# nu, Q, t, nel1, nel2, valve1, valve2
echo "1000 2e6 0 0 0 0 0" | $T/net > ../verify/out_net_lam.txt
echo "1e-4 3e7 0 2 1 0 1"  | $T/net > ../verify/out_net_rough.txt
for t in 0 10 15 20 25 30 40; do echo "1.0 3e7 $t 2 1 0 1" | $T/net > ../verify/out_net_t$t.txt; done
