      SUBROUTINE UPSD(PSD,PSDR,PSDI,FREQ,KSTEP)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 PSD
!     user coding to define PSDR and PSDI
      RETURN
      END
