      SUBROUTINE UPOREP(UW0,COORDS,NODE)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION COORDS(3)
!     user coding to define UW0
      RETURN
      END
