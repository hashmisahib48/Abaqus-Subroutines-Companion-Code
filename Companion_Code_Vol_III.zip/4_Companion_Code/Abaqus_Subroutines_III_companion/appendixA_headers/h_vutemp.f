      SUBROUTINE VUTEMP(TEMP,NBLOCK,NCOMP,NFIELD,
     1 KSTEP,JFLAGS,JNODEUID,TIME,FIELD,
     2 COORDS,U,V,A)
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (n_utmp_Time = 4, n_utmp_Flags = 2)
      PARAMETER (n_utmp_SolU = 7, n_utmp_SolV = 7, n_utmp_SolA = 7)
      DIMENSION TEMP(NBLOCK,NCOMP),FIELD(NBLOCK,NCOMP,NFIELD)
      DIMENSION JFLAGS(n_utmp_Flags),JNODEUID(NBLOCK),
     1 TIME(n_utmp_Time),COORDS(3,NBLOCK)
      DIMENSION U(n_utmp_SolU,NBLOCK),V(n_utmp_SolV,NBLOCK),
     1 A(n_utmp_SolA,NBLOCK)
!     user coding to define TEMP(1:NBLOCK,1:NCOMP)
      RETURN
      END
