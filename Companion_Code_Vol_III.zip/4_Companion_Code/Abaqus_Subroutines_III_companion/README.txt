Companion files for Abaqus User Subroutines III: Thermal, Fluid and Specialised Analyses
by Dr. Mudassar Hussain Hashmi

chNN/code           Fortran routines, drivers and input excerpts of Chapter NN
chNN/verify         Python scripts that compute the closed-form and reference values quoted in the chapter
include             stub ABA_PARAM.INC, VABA_PARAM.INC and stubs.f for compiling and testing outside Abaqus
                    (gfortran; Explicit routines need -ffixed-line-length-none)
appendixA_headers   interface headers of the 41 routines

The drivers test the routines outside Abaqus. Check every interface against the
Abaqus User Subroutines Reference Guide of your release before use.
