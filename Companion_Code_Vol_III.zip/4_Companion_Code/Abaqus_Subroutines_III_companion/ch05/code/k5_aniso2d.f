!     Driver: steady 2-D conduction with UMATHT (Listing 5.1) on an
!     NEL x NEL mesh of 4-node quadrilaterals, 2x2 Gauss points, Newton
!     iteration with the tangent -(DFDT N_j + DFDG grad N_j).
!     Exact solution: Kirchhoff variable THETA harmonic for K-hat.
!     Arguments: NEL, IDFDT (1 use DFDT, 0 set DFDT = 0)
      PROGRAM K5ANI
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      CHARACTER*12 ARG
      PARAMETER (NMX = 33*33)
      DIMENSION DUDG(2),FLUX(2),DFDT(2),DFDG(2,2),STATEV(1),
     1 DTEMDX(2),TIME(2),PREDEF(1),DPRED(1),PROPS(9),COORDS(3)
      DIMENSION T(NMX), RES(NMX), AJ(NMX,NMX), DT(NMX), ISB(NMX)
      DIMENSION XN(NMX), YN(NMX), EX(NMX)
      DIMENSION GP(2), BX(4), BY(4), SH(4), IX(4), IY(4), NODE(4)
      PARAMETER (PI = 3.14159265358979D0, ALEN = 100.D0)
      COMMON /EXC/ P, XLAM, XKAP, BETA, TREF
      CALL GETARG(1, ARG)
      READ(ARG,*) NEL
      CALL GETARG(2, ARG)
      READ(ARG,*) IDFDT
      CMNAME = 'ANISO'
      PROPS = (/ 4.D0, 0.5D0, 0.5D0, 1.D-2, 1.D-2, 1.D-2,
     1           20.D0, 30.D0, 1.D9 /)
      BETA = PROPS(4)
      TREF = PROPS(7)
      CA = COS(PROPS(8)*PI/180.D0)
      SA = SIN(PROPS(8)*PI/180.D0)
      XXX = PROPS(1)*CA*CA + PROPS(2)*SA*SA
      YYY = PROPS(1)*SA*SA + PROPS(2)*CA*CA
      XYY = (PROPS(1) - PROPS(2))*SA*CA
      P    = PI/ALEN
      XLAM = P*SQRT(XXX*YYY - XYY**2)/YYY
      XKAP = P*XYY/YYY
      NODEN = NEL + 1
      NN = NODEN*NODEN
      H = ALEN/NEL
      GP = (/ -1.D0/SQRT(3.D0), 1.D0/SQRT(3.D0) /)
      TIME = 0.D0
      DO 10 J = 0, NEL
         DO 10 I = 0, NEL
            K = J*NODEN + I + 1
            XN(K) = I*H
            YN(K) = J*H
            ISB(K) = 0
            IF (I.EQ.0 .OR. J.EQ.0 .OR. I.EQ.NEL .OR. J.EQ.NEL)
     1         ISB(K) = 1
            CALL K5_EXACT(XN(K), YN(K), EX(K))
            T(K) = TREF + 40.D0
            IF (ISB(K) .EQ. 1) T(K) = EX(K)
   10 CONTINUE
      NIT = 0
      DO 200 IT = 1, 30
         RES(1:NN) = 0.D0
         AJ(1:NN,1:NN) = 0.D0
         DO 100 IEY = 1, NEL
            DO 100 IEX = 1, NEL
               NODE(1) = (IEY-1)*NODEN + IEX
               NODE(2) = NODE(1) + 1
               NODE(3) = NODE(2) + NODEN
               NODE(4) = NODE(1) + NODEN
               DO 90 IG = 1, 2
                  DO 90 JG = 1, 2
                     XI = GP(IG)
                     ET = GP(JG)
                     SH = 0.25D0*(/ (1-XI)*(1-ET), (1+XI)*(1-ET),
     1                              (1+XI)*(1+ET), (1-XI)*(1+ET) /)
                     BX = (2.D0/H)*0.25D0*(/ -(1-ET), (1-ET),
     1                                        (1+ET), -(1+ET) /)
                     BY = (2.D0/H)*0.25D0*(/ -(1-XI), -(1+XI),
     1                                        (1+XI), (1-XI) /)
                     W = (H/2.D0)**2
                     TG = 0.D0
                     DTEMDX = 0.D0
                     DO 20 A = 1, 4
                        TG = TG + SH(A)*T(NODE(A))
                        DTEMDX(1) = DTEMDX(1) + BX(A)*T(NODE(A))
                        DTEMDX(2) = DTEMDX(2) + BY(A)*T(NODE(A))
   20                CONTINUE
                     U = 0.D0
                     CALL UMATHT(U,DUDT,DUDG,FLUX,DFDT,DFDG,STATEV,
     1                 TG,0.D0,DTEMDX,TIME,1.D0,PREDEF,DPRED,CMNAME,2,
     2                 1,PROPS,9,COORDS,PNEWDT,1,1,1,1,1,1)
                     IF (IDFDT .EQ. 0) DFDT = 0.D0
                     DO 40 A = 1, 4
                        RES(NODE(A)) = RES(NODE(A)) - W*(BX(A)*FLUX(1)
     1                                              + BY(A)*FLUX(2))
                        DO 30 B = 1, 4
                           AJ(NODE(A),NODE(B)) = AJ(NODE(A),NODE(B))
     1                      - W*( (BX(A)*DFDT(1)+BY(A)*DFDT(2))*SH(B)
     2                      + BX(A)*(DFDG(1,1)*BX(B)+DFDG(1,2)*BY(B))
     3                      + BY(A)*(DFDG(2,1)*BX(B)+DFDG(2,2)*BY(B)))
   30                   CONTINUE
   40                CONTINUE
   90          CONTINUE
  100    CONTINUE
         DO 110 K = 1, NN
            IF (ISB(K) .EQ. 1) THEN
               AJ(K,1:NN) = 0.D0
               AJ(K,K) = 1.D0
               RES(K) = 0.D0
            END IF
  110    CONTINUE
         RMAX = MAXVAL(ABS(RES(1:NN)))
         IF (IT .GT. 1 .AND. DMAX .LT. 1.D-9) EXIT
         DT(1:NN) = -RES(1:NN)
         CALL K5_SOLVE(AJ, DT, NN, NMX)
         DMAX = MAXVAL(ABS(DT(1:NN)))
         T(1:NN) = T(1:NN) + DT(1:NN)
         NIT = IT
  200 CONTINUE
      EMAX = MAXVAL(ABS(T(1:NN) - EX(1:NN)))
      WRITE(*,'(I5,I4,I5,ES12.3)') NEL, IDFDT, NIT, EMAX
      END

      SUBROUTINE K5_EXACT(X, Y, TEX)
      INCLUDE 'ABA_PARAM.INC'
      COMMON /EXC/ P, XLAM, XKAP, BETA, TREF
      TH = 60.D0 + 45.D0*EXP(-XLAM*Y)*COS(P*X - XKAP*Y)
      TEX = TREF + (-1.D0 + SQRT(1.D0 + 2.D0*BETA*TH))/BETA
      RETURN
      END

      SUBROUTINE K5_SOLVE(A, B, N, NMX)
!     Gaussian elimination without pivoting (diagonally dominant).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(NMX,NMX), B(NMX)
      DO 20 K = 1, N-1
         DO 10 I = K+1, MIN(N, K+40)
            IF (A(I,K) .NE. 0.D0) THEN
               W = A(I,K)/A(K,K)
               A(I,K:MIN(N,K+40)) = A(I,K:MIN(N,K+40))
     1                              - W*A(K,K:MIN(N,K+40))
               B(I) = B(I) - W*B(K)
            END IF
   10    CONTINUE
   20 CONTINUE
      DO 40 I = N, 1, -1
         S = B(I)
         DO 30 J = I+1, MIN(N, I+40)
            S = S - A(I,J)*B(J)
   30    CONTINUE
         B(I) = S/A(I,I)
   40 CONTINUE
      RETURN
      END
