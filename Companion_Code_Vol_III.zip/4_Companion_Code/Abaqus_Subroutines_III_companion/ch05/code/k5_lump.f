!     Driver: lumped body cooled by a film, UMATHT of Listing 5.3.
!     RHO*dU/dt = -HV*(T - TINF).  Backward Euler, Newton on T.
!     Arguments: TAU(s)  DT(s)  TEND(s)
      PROGRAM K5LMP
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      CHARACTER*16 ARG
      DIMENSION DUDG(1),FLUX(1),DFDT(1),DFDG(1,1),STATEV(1),SV0(1),
     1 DTEMDX(1),TIME(2),PREDEF(1),DPRED(1),PROPS(7),COORDS(3)
      PARAMETER (RHO = 9.D-10,          ! density, t/mm^3
     1           HV = 4.D-3,            ! h*A/V, mW/(mm^3 K)
     2           TINF = 20.D0, TSTART = 70.D0)
      CMNAME = 'KIN'
      CALL GETARG(1, ARG)
      READ(ARG,*) TAU
      CALL GETARG(2, ARG)
      READ(ARG,*) DT
      CALL GETARG(3, ARG)
      READ(ARG,*) TEND
      PROPS = (/ 0.25D0, 0.15D0, 2.D9, 2.D11, 50.D0, 2.D0, TAU /)
      DTEMDX = 0.D0
      TIME = 0.D0
      T = TSTART
      STATEV(1) = 1.D0
      U = 0.D0
      TT = 0.D0
      NSTEP = 0
      NITS = 0
      OPEN(10, FILE='lump.txt')
      WRITE(10,'(F9.1,F10.4,F8.4)') TT, T, STATEV(1)
   10 CONTINUE
      SV0(1) = STATEV(1)
      TNEW = T
      DO 30 IT = 1, 25
         STATEV(1) = SV0(1)
         UN = U
         CALL UMATHT(UN,DUDT,DUDG,FLUX,DFDT,DFDG,STATEV,T,TNEW-T,
     1     DTEMDX,TIME,DT,PREDEF,DPRED,CMNAME,1,1,PROPS,7,COORDS,
     2     PNEWDT,1,1,1,1,1,NSTEP+1)
         G = RHO*(UN - U)/DT + HV*(TNEW - TINF)
         DG = RHO*DUDT/DT + HV
         TNEW = TNEW - G/DG
         IF (ABS(G/DG) .LT. 1.D-10) GO TO 40
   30 CONTINUE
      STOP 'no convergence'
   40 CONTINUE
      NITS = NITS + IT
      STATEV(1) = SV0(1)
      UN = U
      CALL UMATHT(UN,DUDT,DUDG,FLUX,DFDT,DFDG,STATEV,T,TNEW-T,
     1  DTEMDX,TIME,DT,PREDEF,DPRED,CMNAME,1,1,PROPS,7,COORDS,
     2  PNEWDT,1,1,1,1,1,NSTEP+1)
      U = UN
      T = TNEW
      TT = TT + DT
      NSTEP = NSTEP + 1
      WRITE(10,'(F9.1,F10.4,F8.4)') TT, T, STATEV(1)
      IF (TT .LT. TEND - 1.D-9) GO TO 10
      CLOSE(10)
      WRITE(*,'(A,F7.1,A,F6.1,A,I5,A,F6.2)') 'tau', TAU, '  dt', DT,
     1   '  steps', NSTEP, '  newton/step', DBLE(NITS)/NSTEP
      END
