!     Driver: one block of VUMATHT (Listing 5.5) against UMATHT of
!     Listing 5.2 for the same six points; link with both files.
      PROGRAM K5VDR
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 6)
      CHARACTER*80 CMNAME
      DIMENSION NELEM(NB), COORDMP(NB,3), DENS(NB), PROPS(7),
     1 TOLD(NB), FOLD(NB,1), SOLD(NB,1), EOLD(NB), TNEW(NB),
     2 GNEW(NB,1), FNEW(NB,1), SNEW(NB,1), FLX(NB,1), ENEW(NB),
     3 DEDT(NB,2), CEFF(NB)
      DIMENSION DUDG(1),FLUX(1),DFDT(1),DFDG(1,1),STATEV(1),
     1 DTEMDX(1),TIME(2),PREDEF(1),DPRED(1),COORDS(3)
      DATA TOLD /20.D0, 47.D0, 49.5D0, 50.D0, 50.8D0, 62.D0/
      DATA TNEW /25.D0, 55.D0, 49.9D0, 50.6D0, 53.D0, 58.D0/
      DATA GNEW /1.D0, -2.D0, 0.5D0, 3.D0, -1.5D0, 0.2D0/
      PROPS = (/ 0.25D0, 0.15D0, 2.D9, 2.2D9, 2.D11, 50.D0, 1.D0 /)
      CMNAME = 'PCM'
      EOLD = 1.D10
      FOLD = 0.D0
      SOLD = 0.D0
      CALL VUMATHT(NB, NELEM, 1, 1, 1, 1, 0, 0, 7, CMNAME, 5.D0,
     1  5.D0, 1.D0, COORDMP, DENS, PROPS, TOLD, FOLD, SOLD, EOLD,
     2  TNEW, GNEW, FNEW, SNEW, FLX, ENEW, DEDT, CEFF)
      DUMAX = 0.D0
      FXMAX = 0.D0
      DO 10 K = 1, NB
         U = EOLD(K)
         DTEMDX(1) = GNEW(K,1)
         CALL UMATHT(U,DUDT,DUDG,FLUX,DFDT,DFDG,STATEV,TOLD(K),
     1     TNEW(K)-TOLD(K),DTEMDX,TIME,1.D0,PREDEF,DPRED,CMNAME,1,1,
     2     PROPS,7,COORDS,PNEWDT,1,1,1,1,1,1)
         DUMAX = MAX(DUMAX, ABS(U - ENEW(K)))
         FXMAX = MAX(FXMAX, ABS(FLUX(1) - FLX(K,1)))
         WRITE(*,'(I3,2F7.1,ES13.5,ES13.5,ES13.5)') K, TOLD(K),
     1     TNEW(K), ENEW(K), DEDT(K,1), DEDT(K,2)
   10 CONTINUE
      WRITE(*,'(A,2ES10.2)') 'max |dU|, max |dFLUX| :', DUMAX, FXMAX
!     first call of the analysis (TOTALTIME = 0): U(0) = 0 reference
      EOLD = 0.D0
      CALL VUMATHT(NB, NELEM, 1, 1, 1, 1, 0, 0, 7, CMNAME, 0.D0,
     1  0.D0, 0.D0, COORDMP, DENS, PROPS, TNEW, FOLD, SOLD, EOLD,
     2  TNEW, GNEW, FNEW, SNEW, FLX, ENEW, DEDT, CEFF)
      WRITE(*,'(A,ES12.4,A,ES12.4)') 'first call, T=25 degC: U =',
     1   ENEW(1), '   cs*T =', 2.D9*25.D0
!     scan of the apparent capacity
      CMAX = 0.D0
      DO 20 K = 0, 6000
         T = 40.D0 + K*0.002D0
         CALL K5_PCM(T, PROPS, UH, CAP, FL, DFL)
         CMAX = MAX(CMAX, CAP)
   20 CONTINUE
      WRITE(*,'(A,ES11.4,A,ES11.4)') 'max dU/dT =', CMAX,
     1   '   sensible cs =', PROPS(3)
      END
