!     Driver: central-difference test of the derivatives of UMATHT.
!     Link with ONE UMATHT file.  Argument 1: A (aniso), P (pcm), K (kin)
      PROGRAM K5FDCK
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      CHARACTER*8 ARG
      PARAMETER (NT = 3, NPT0 = 8)
      DIMENSION DUDG(NT),FLUX(NT),DFDT(NT),DFDG(NT,NT),STATEV(1),
     1 DTEMDX(NT),TIME(2),PREDEF(1),DPRED(1),PROPS(12),COORDS(3)
      DIMENSION FP(NT),FM(NT),F0(NT),G0(NT),TT(NPT0),DTT(NPT0)
      DIMENSION GG(NT,NPT0), DUA(NT), DFA(NT), DFG(NT,NT)
      DATA TT  /20.D0, 49.D0, 49.7D0, 50.D0, 50.6D0, 51.2D0,
     1          60.D0, 90.D0/
      DATA DTT /3.D0, 0.1D0, 0.6D0, -0.5D0, 0.5D0, 4.D0, -9.3D0, 1.D0/
      DATA GG / 1.2D0,-0.7D0, 0.4D0,  0.3D0, 2.1D0,-1.D0,
     1          -0.9D0, 0.5D0, 0.2D0,  1.5D0, 1.5D0, 0.D0,
     2           0.1D0, 0.8D0,-1.3D0,  2.0D0,-0.4D0, 0.7D0,
     3           0.6D0, 0.6D0, 0.6D0, -1.1D0, 0.2D0, 0.9D0 /
      CALL GETARG(1, ARG)
      CMNAME = 'TEST'
      NSTAT = 1
      NPR = 9
      IF (ARG(1:1) .EQ. 'A') THEN
         PROPS(1:9) = (/ 4.D0, 0.5D0, 0.3D0, 3.D-3, 1.D-3, -2.D-3,
     1                   20.D0, 30.D0, 1.D9 /)
      ELSE IF (ARG(1:1) .EQ. 'P') THEN
         PROPS(1:7) = (/ 0.25D0, 0.15D0, 2.D9, 2.2D9, 2.D11, 50.D0,
     1                   1.D0 /)
         NPR = 7
      ELSE
         PROPS(1:7) = (/ 0.25D0, 0.15D0, 2.D9, 2.D11, 50.D0, 1.D0,
     1                   60.D0 /)
         NPR = 7
      END IF
      NTGRD = 3
      TIME(1) = 0.D0
      TIME(2) = 0.D0
      H  = 1.D-5
      DT = 20.D0
      EMAX1 = 0.D0
      EMAX2 = 0.D0
      EMAX3 = 0.D0
      EMAX4 = 0.D0
      DO 100 IP = 1, NPT0
         T0 = TT(IP)
         DT0 = DTT(IP)
         F00 = 0.2D0*MOD(IP,3)
         STATEV(1) = F00
         U0 = 0.D0
         CALL UMATHT(U0,DUDT,DUDG,F0,DFDT,DFDG,STATEV,T0,DT0,GG(1,IP),
     1    TIME,DT,PREDEF,DPRED,CMNAME,NTGRD,NSTAT,PROPS,NPR,COORDS,
     2    PNEWDT,1,1,1,1,1,1)
!        d/dDTEMP : U, FLUX
         STATEV(1) = F00
         UP = 0.D0
         CALL UMATHT(UP,DUDT2,DUA,FP,DFA,DFG,STATEV,T0,DT0+H,GG(1,IP),
     1    TIME,DT,PREDEF,DPRED,CMNAME,NTGRD,NSTAT,PROPS,NPR,COORDS,
     2    PNEWDT,1,1,1,1,1,1)
         STATEV(1) = F00
         UM = 0.D0
         CALL UMATHT(UM,DUDT2,DUA,FM,DFA,DFG,STATEV,T0,DT0-H,GG(1,IP),
     1    TIME,DT,PREDEF,DPRED,CMNAME,NTGRD,NSTAT,PROPS,NPR,COORDS,
     2    PNEWDT,1,1,1,1,1,1)
         E1 = ABS((UP-UM)/(2*H) - DUDT)/MAX(1.D0,ABS(DUDT))
         EMAX1 = MAX(EMAX1,E1)
         DO 10 I = 1, NTGRD
            E2 = ABS((FP(I)-FM(I))/(2*H) - DFDT(I))
     1           /MAX(1.D-3,ABS(DFDT(I)))
            IF (ABS(DFDT(I)) .LT. 1.D-9 .AND.
     1          ABS(FP(I)-FM(I)) .LT. 1.D-9) E2 = 0.D0
            EMAX2 = MAX(EMAX2,E2)
   10    CONTINUE
!        d/dg : U (DUDG) and FLUX (DFDG)
         DO 30 J = 1, NTGRD
            DO 20 K = 1, NTGRD
               G0(K) = GG(K,IP)
   20       CONTINUE
            G0(J) = G0(J) + H
            STATEV(1) = F00
            UP = 0.D0
            CALL UMATHT(UP,DUDT2,DUA,FP,DFA,DFG,STATEV,T0,DT0,G0,
     1       TIME,DT,PREDEF,DPRED,CMNAME,NTGRD,NSTAT,PROPS,NPR,COORDS,
     2       PNEWDT,1,1,1,1,1,1)
            G0(J) = G0(J) - 2*H
            STATEV(1) = F00
            UM = 0.D0
            CALL UMATHT(UM,DUDT2,DUA,FM,DFA,DFG,STATEV,T0,DT0,G0,
     1       TIME,DT,PREDEF,DPRED,CMNAME,NTGRD,NSTAT,PROPS,NPR,COORDS,
     2       PNEWDT,1,1,1,1,1,1)
            EMAX3 = MAX(EMAX3, ABS((UP-UM)/(2*H) - DUDG(J)))
            DO 25 I = 1, NTGRD
               EMAX4 = MAX(EMAX4, ABS((FP(I)-FM(I))/(2*H)
     1                 - DFDG(I,J))/MAX(1.D-3,ABS(DFDG(I,J))))
   25       CONTINUE
   30    CONTINUE
  100 CONTINUE
      WRITE(*,'(A,A1,4ES11.2)') 'max rel/abs deviation  ', ARG(1:1),
     1   EMAX1, EMAX3, EMAX2, EMAX4
      END
