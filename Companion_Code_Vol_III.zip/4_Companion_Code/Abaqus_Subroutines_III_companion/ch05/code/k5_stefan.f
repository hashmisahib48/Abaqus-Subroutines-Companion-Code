!     Driver: 1-D transient conduction with phase change through UMATHT
!     (Listing 5.2).  Solid wall at x = 0 held at TWALL, liquid initially
!     at TINIT, far end insulated.  Backward Euler, Newton with the
!     tangent  (RHO/DT) N_i DUDT N_j - B_i (DFDT N_j + DFDG B_j).
!     Arguments: DEL(K) H(mm) DTMAX(s) TEND(s) ISCH(1 Gauss, 2 nodal) 
!                [TINIT(degC), default 70]
      PROGRAM K5STF
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      CHARACTER*16 ARG
      PARAMETER (NMX = 4001)
      DIMENSION DUDG(1),FLUX(1),DFDT(1),DFDG(1,1),STATEV(1),
     1 DTEMDX(1),TIME(2),PREDEF(1),DPRED(1),PROPS(7),COORDS(3)
      DIMENSION TO(NMX), TN(NMX), RES(NMX), DL(NMX), DM(NMX), DU(NMX)
      DIMENSION DX(NMX), UOLD(2,NMX), UNEW(2,NMX), XI(2), NIT(100000)
      PARAMETER (RHO = 9.D-10,          ! density, t/mm^3
     1           XLEN = 120.D0,         ! bar length, mm
     2           TWALL = 20.D0, TM = 50.D0)
      CMNAME = 'PCM'
      CALL GETARG(1, ARG)
      READ(ARG,*) DEL
      CALL GETARG(2, ARG)
      READ(ARG,*) H
      CALL GETARG(3, ARG)
      READ(ARG,*) DTMAX
      CALL GETARG(4, ARG)
      READ(ARG,*) TEND
      CALL GETARG(5, ARG)
      READ(ARG,*) ISCH
      CALL GETARG(6, ARG)
      TINIT = 70.D0
      IF (ARG .NE. ' ') READ(ARG,*) TINIT
      GROW = 1.2D0
      PROPS = (/ 0.25D0, 0.15D0, 2.0D9, 2.2D9, 2.0D11, TM, DEL /)
      N = NINT(XLEN/H)
      NN = N + 1
      IF (ISCH .EQ. 1) THEN
         XI = (/ -1.D0/SQRT(3.D0), 1.D0/SQRT(3.D0) /)
      ELSE
         XI = (/ -1.D0, 1.D0 /)
      END IF
      TO(1:NN) = TINIT
      TO(1) = TWALL
      UOLD(1:2,1:N) = 0.D0
      TIME = 0.D0
      T = 0.D0
      DT = 0.01D0
      QCUM = 0.D0
      NSTEP = 0
      NCUT = 0
      NITS = 0
      NEXT = 1
      XF = 0.D0
      OPEN(10, FILE='front.txt')
      WRITE(10,'(A)') '# t(s)  front(mm)  Qcum(mJ/mm2)  newton'
 50   CONTINUE
      IF (T + DT .GT. TEND) DT = TEND - T
      TN(1:NN) = TO(1:NN)
      TN(1) = TWALL
      DO 300 IT = 1, 16
         RES(1:NN) = 0.D0
         DL(1:NN) = 0.D0
         DM(1:NN) = 0.D0
         DU(1:NN) = 0.D0
         DO 100 IE = 1, N
            DO 90 IG = 1, 2
               SH1 = 0.5D0*(1.D0 - XI(IG))
               SH2 = 0.5D0*(1.D0 + XI(IG))
               B1 = -1.D0/H
               B2 = 1.D0/H
               W = 0.5D0*H
               TG = SH1*TN(IE) + SH2*TN(IE+1)
               TGO = SH1*TO(IE) + SH2*TO(IE+1)
               DTEMDX(1) = B1*TN(IE) + B2*TN(IE+1)
               U = UOLD(IG,IE)
               TIME(1) = T
               TIME(2) = T
               CALL UMATHT(U,DUDT,DUDG,FLUX,DFDT,DFDG,STATEV,TGO,
     1           TG-TGO,DTEMDX,TIME,DT,PREDEF,DPRED,CMNAME,1,1,PROPS,
     2           7,COORDS,PNEWDT,IE,IG,1,1,1,NSTEP+1)
               UNEW(IG,IE) = U
               S1 = RHO*(U - UOLD(IG,IE))/DT
               RES(IE)   = RES(IE)   + W*(SH1*S1 - B1*FLUX(1))
               RES(IE+1) = RES(IE+1) + W*(SH2*S1 - B2*FLUX(1))
               C = RHO*DUDT/DT
               A11 = W*(SH1*C*SH1 - B1*(DFDT(1)*SH1 + DFDG(1,1)*B1))
               A12 = W*(SH1*C*SH2 - B1*(DFDT(1)*SH2 + DFDG(1,1)*B2))
               A21 = W*(SH2*C*SH1 - B2*(DFDT(1)*SH1 + DFDG(1,1)*B1))
               A22 = W*(SH2*C*SH2 - B2*(DFDT(1)*SH2 + DFDG(1,1)*B2))
               DM(IE) = DM(IE) + A11
               DU(IE) = DU(IE) + A12
               DL(IE+1) = DL(IE+1) + A21
               DM(IE+1) = DM(IE+1) + A22
 90         CONTINUE
 100     CONTINUE
         R0 = RES(1)
         DM(1) = 1.D0
         DU(1) = 0.D0
         RES(1) = 0.D0
         RMAX = 0.D0
!        Thomas algorithm for  J dT = -RES
         RES(1:NN) = -RES(1:NN)
         DO 150 I = 2, NN
            W2 = DL(I)/DM(I-1)
            DM(I) = DM(I) - W2*DU(I-1)
            RES(I) = RES(I) - W2*RES(I-1)
 150     CONTINUE
         RES(NN) = RES(NN)/DM(NN)
         DO 160 I = NN-1, 1, -1
            RES(I) = (RES(I) - DU(I)*RES(I+1))/DM(I)
 160     CONTINUE
         DMAX = MAXVAL(ABS(RES(1:NN)))
         TN(1:NN) = TN(1:NN) + RES(1:NN)
         IF (DMAX .LT. 1.D-9) GO TO 310
 300  CONTINUE
!     no convergence: cut the increment back (Abaqus: PNEWDT)
      NCUT = NCUT + 1
      DT = 0.25D0*DT
      IF (DT .LT. 1.D-6) THEN
         WRITE(*,'(A,F10.3,A)') 'FAILED at t =', T, ' s'
         STOP
      END IF
      GO TO 50
 310  CONTINUE
      NITS = NITS + IT
      NSTEP = NSTEP + 1
      QCUM = QCUM + R0*DT
      T = T + DT
      UOLD(1:2,1:N) = UNEW(1:2,1:N)
      TO(1:NN) = TN(1:NN)
      IF (T .GE. 10.D0*NEXT .OR. T .GE. TEND - 1.D-9) THEN
         DO 320 I = 1, N
            IF (TO(I) .LT. TM .AND. TO(I+1) .GE. TM) THEN
               XF = (I-1)*H + H*(TM - TO(I))/(TO(I+1) - TO(I))
            END IF
 320     CONTINUE
         WRITE(10,'(F10.2,F12.5,F14.4,I4)') T, XF, -QCUM, IT
         NEXT = INT(T/10.D0) + 1
      END IF
      DT = MIN(DTMAX, GROW*DT)
      IF (T .LT. TEND - 1.D-9) GO TO 50
      CLOSE(10)
!     profile and energy summary
      OPEN(11, FILE='profile.txt')
      DO 330 I = 1, NN
         WRITE(11,'(F10.4,F12.6)') (I-1)*H, TO(I)
 330  CONTINUE
      CLOSE(11)
      ESTORE = 0.D0
      DO 340 IE = 1, N
         ESTORE = ESTORE + 0.5D0*H*RHO*(UOLD(1,IE) + UOLD(2,IE))
 340  CONTINUE
      WRITE(*,'(A,I6,A,I4,A,F8.3,A,ES11.3)') 'steps', NSTEP, '  cutbacks', NCUT,
     1  '  newton/step', DBLE(NITS)/NSTEP, '  |dE - Q|/Q',
     2  ABS(ESTORE - QCUM)/ABS(QCUM)
      END
