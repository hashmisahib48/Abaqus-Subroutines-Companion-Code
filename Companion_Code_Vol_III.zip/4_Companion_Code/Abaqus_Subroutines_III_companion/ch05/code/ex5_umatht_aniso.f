      SUBROUTINE UMATHT(U,DUDT,DUDG,FLUX,DFDT,DFDG,
     1 STATEV,TEMP,DTEMP,DTEMDX,TIME,DTIME,PREDEF,DPRED,
     2 CMNAME,NTGRD,NSTATV,PROPS,NPROPS,COORDS,PNEWDT,
     3 NOEL,NPT,LAYER,KSPT,KSTEP,KINC)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION DUDG(NTGRD),FLUX(NTGRD),DFDT(NTGRD),
     1 DFDG(NTGRD,NTGRD),STATEV(NSTATV),DTEMDX(NTGRD),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3)
      DIMENSION AK(3), AKD(3), E(3,3)
!     Orthotropic conductivity, own temperature law per axis.
!     PROPS: 1-3 K1,K2,K3 at TREF, mW/(mm K); 4-6 B1,B2,B3, 1/K;
!            7 TREF, degC; 8 ANGLE of axis 1 from x, deg;
!            9 C specific heat, mJ/(t K)
      PARAMETER (FMIN = 0.05D0,       ! lowest factor on K, -
     1           PI   = 3.14159265358979D0)
      TN = TEMP + DTEMP                    ! end of increment, degC
      CA = COS(PROPS(8)*PI/180.D0)
      SA = SIN(PROPS(8)*PI/180.D0)
      DO 10 M = 1, 3
         FAC = 1.D0 + PROPS(3+M)*(TN - PROPS(7))
         DFC = PROPS(3+M)
         IF (FAC .LT. FMIN) THEN
            FAC = FMIN
            DFC = 0.D0
         END IF
         AK(M)  = PROPS(M)*FAC             ! K_m(T)
         AKD(M) = PROPS(M)*DFC             ! dK_m/dT
   10 CONTINUE
      E = RESHAPE((/ CA, SA, 0.D0, -SA, CA, 0.D0, 0.D0, 0.D0,
     1   1.D0 /), (/ 3, 3 /))             ! columns = axes
      DO 40 I = 1, NTGRD
         FLUX(I) = 0.D0
         DFDT(I) = 0.D0
         DUDG(I) = 0.D0
         DO 30 J = 1, NTGRD
            CT  = E(I,1)*E(J,1)*AK(1) + E(I,2)*E(J,2)*AK(2)
     1          + E(I,3)*E(J,3)*AK(3)
            DCT = E(I,1)*E(J,1)*AKD(1) + E(I,2)*E(J,2)*AKD(2)
     1          + E(I,3)*E(J,3)*AKD(3)
            FLUX(I)   = FLUX(I) - CT*DTEMDX(J)
            DFDT(I)   = DFDT(I) - DCT*DTEMDX(J)
            DFDG(I,J) = -CT
   30    CONTINUE
   40 CONTINUE
      U    = U + PROPS(9)*DTEMP
      DUDT = PROPS(9)
      RETURN
      END
