      SUBROUTINE UMATHT(U,DUDT,DUDG,FLUX,DFDT,DFDG,
     1 STATEV,TEMP,DTEMP,DTEMDX,TIME,DTIME,PREDEF,DPRED,
     2 CMNAME,NTGRD,NSTATV,PROPS,NPROPS,COORDS,PNEWDT,
     3 NOEL,NPT,LAYER,KSPT,KSTEP,KINC)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION DUDG(NTGRD),FLUX(NTGRD),DFDT(NTGRD),
     1 DFDG(NTGRD,NTGRD),STATEV(NSTATV),DTEMDX(NTGRD),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3)
!     Melting with relaxation of the liquid fraction (Eqs. 5.8-1,2)
!     STATEV(1) = liquid fraction F.  PROPS: 1 KS, 2 KL, mW/(mm K);
!     3 C, mJ/(t K); 4 LAT, mJ/t; 5 TM, degC; 6 DEL, K; 7 TAU, s.
      FOLD = STATEV(1)
      CALL K5_FEQ(TEMP+DTEMP, PROPS, FEQ, DFEQ)
      EX = 0.D0
      IF (PROPS(7) .GT. 0.D0) EX = EXP(-DTIME/PROPS(7))
      FNEW = FEQ + (FOLD - FEQ)*EX         ! exact for constant T
      DFN  = (1.D0 - EX)*DFEQ              ! dFNEW/dT
      COND = PROPS(1) + (PROPS(2) - PROPS(1))*FNEW
      DCND = (PROPS(2) - PROPS(1))*DFN
      U    = U + PROPS(3)*DTEMP + PROPS(4)*(FNEW - FOLD)
      DUDT = PROPS(3) + PROPS(4)*DFN
      DO 20 I = 1, NTGRD
         DUDG(I) = 0.D0
         FLUX(I) = -COND*DTEMDX(I)
         DFDT(I) = -DCND*DTEMDX(I)
         DO 10 J = 1, NTGRD
            DFDG(I,J) = 0.D0
   10    CONTINUE
         DFDG(I,I) = -COND
   20 CONTINUE
      STATEV(1) = FNEW
      RETURN
      END

      SUBROUTINE K5_FEQ(T, PROPS, FEQ, DFEQ)
!     Equilibrium liquid fraction: smooth step over TM -/+ DEL.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*)
      W = 2.D0*PROPS(6)
      S = MIN(1.D0, MAX(0.D0, (T - PROPS(5) + PROPS(6))/W))
      FEQ  = S*S*(3.D0 - 2.D0*S)
      DFEQ = 0.D0
      IF (S .GT. 0.D0 .AND. S .LT. 1.D0) DFEQ = 6.D0*S*(1.D0 - S)/W
      RETURN
      END
