import numpy as np, subprocess
from scipy.integrate import solve_ivp
RHO=9e-10; HV=4e-3; TINF=20.; C=2e9; L=2e11; TM=50.; DEL=2.
def feq(T):
    s=np.clip((T-TM+DEL)/(2*DEL),0,1); return s*s*(3-2*s)
def dfeq(T):
    s=(T-TM+DEL)/(2*DEL); return 6*s*(1-s)/(2*DEL) if 0<s<1 else 0.
def ref(tau,tgrid):
    if tau==0:
        f=lambda t,y:[-HV*(y[0]-TINF)/RHO/(C+L*dfeq(y[0]))]
        s=solve_ivp(f,[0,tgrid[-1]],[70.],t_eval=tgrid,method='Radau',rtol=1e-12,atol=1e-12)
        return s.y[0]
    def f(t,y):
        T,fl=y; fd=(feq(T)-fl)/tau
        return [(-HV*(T-TINF)/RHO - L*fd)/C, fd]
    s=solve_ivp(f,[0,tgrid[-1]],[70.,1.],t_eval=tgrid,method='Radau',rtol=1e-12,atol=1e-12)
    return s.y[0]
def fe(tau,dt,tend=6000):
    subprocess.run(['/tmp/claude-0/b5/lmp',str(tau),str(dt),str(tend)],cwd='/tmp/claude-0/b5/w2',capture_output=True)
    return np.loadtxt('/tmp/claude-0/b5/w2/lump.txt')
if __name__=='__main__':
    for tau in (0,30,300):
        print('tau',tau)
        for dt in (40,20,10,5):
            d=fe(tau,dt); r=ref(tau,d[:,0]); e=np.abs(d[:,1]-r)
            print('  dt %4d  max|dT|=%.4f K at t=%.0f'%(dt,e.max(),d[e.argmax(),0]))
    # table of values
    t=np.array([500,1000,1500,2000,2500,3000.])
    for tau in (0,30,300): print(tau,np.round(ref(tau,t),3))
    # time to reach 30 degC
    for tau in (0,30,300):
        tg=np.arange(0,6000.5,0.5); r=ref(tau,tg); print(tau,'t(30C)=',tg[np.argmax(r<30)])
