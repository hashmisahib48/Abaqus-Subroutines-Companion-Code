      SUBROUTINE UMATHT(U,DUDT,DUDG,FLUX,DFDT,DFDG,
     1 STATEV,TEMP,DTEMP,DTEMDX,TIME,DTIME,PREDEF,DPRED,
     2 CMNAME,NTGRD,NSTATV,PROPS,NPROPS,COORDS,PNEWDT,
     3 NOEL,NPT,LAYER,KSPT,KSTEP,KINC)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION DUDG(NTGRD),FLUX(NTGRD),DFDT(NTGRD),
     1 DFDG(NTGRD,NTGRD),STATEV(NSTATV),DTEMDX(NTGRD),
     2 TIME(2),PREDEF(1),DPRED(1),PROPS(NPROPS),COORDS(3)
!     Melting with a mushy zone (Eqs. 5.5-1 to 5.5-4), no state.
!     PROPS: 1 KS, 2 KL, mW/(mm K); 3 CS, 4 CL, mJ/(t K);
!     5 LAT, mJ/t; 6 TM, degC; 7 DEL, K (half-width of the zone).
!     U(0 degC) = 0.
      CALL K5_PCM(TEMP+DTEMP, PROPS, UN, CAP, FL, DFL)
      CALL K5_PCM(TEMP,       PROPS, U0, CAP0, FL0, DFL0)
      U    = UN
      DUDT = CAP                           ! c + L df/dT
      COND = PROPS(1) + (PROPS(2) - PROPS(1))*FL
      DCND = (PROPS(2) - PROPS(1))*DFL
      DO 20 I = 1, NTGRD
         DUDG(I) = 0.D0
         FLUX(I) = -COND*DTEMDX(I)
         DFDT(I) = -DCND*DTEMDX(I)
         DO 10 J = 1, NTGRD
            DFDG(I,J) = 0.D0
   10    CONTINUE
         DFDG(I,I) = -COND
   20 CONTINUE
      RETURN
      END

      SUBROUTINE K5_PCM(T, PROPS, UH, CAP, FL, DFL)
!     Energy UH(T), apparent capacity CAP = dUH/dT, liquid fraction
!     FL(T) (cubic smooth step) and DFL = dFL/dT.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*)
      TLO = PROPS(6) - PROPS(7)            ! zone starts, degC
      W   = 2.D0*PROPS(7)                  ! width of the zone, K
      S   = MIN(1.D0, MAX(0.D0, (T - TLO)/W))
      FL  = S*S*(3.D0 - 2.D0*S)
      DFL = 0.D0
      IF (S .GT. 0.D0 .AND. S .LT. 1.D0) DFL = 6.D0*S*(1.D0 - S)/W
      IF (T .GE. TLO + W) THEN             ! integral of FL over T
         FINT = 0.5D0*W + (T - TLO - W)
      ELSE
         FINT = W*(S**3 - 0.5D0*S**4)
      END IF
      UH  = PROPS(3)*T + (PROPS(4) - PROPS(3))*FINT + PROPS(5)*FL
      CAP = PROPS(3) + (PROPS(4) - PROPS(3))*FL + PROPS(5)*DFL
      RETURN
      END
