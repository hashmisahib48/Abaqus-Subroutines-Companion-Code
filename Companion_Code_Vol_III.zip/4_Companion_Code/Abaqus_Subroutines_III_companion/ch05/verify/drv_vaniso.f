      PROGRAM VANI
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 8)
      CHARACTER*80 CMNAME
      DIMENSION NELEM(NB), COORDMP(NB,3), DENS(NB), PROPS(9),
     1 TOLD(NB), FOLD(NB,1), SOLD(NB,1), EOLD(NB), TNEW(NB),
     2 GNEW(NB,3), FNEW(NB,1), SNEW(NB,1), FLX(NB,3), ENEW(NB),
     3 DEDT(NB,2), CEFF(NB)
      DIMENSION DUDG(3),FLUX(3),DFDT(3),DFDG(3,3),STATEV(1),
     1 DTEMDX(3),TIME(2),PREDEF(1),DPRED(1),COORDS(3)
      PROPS = (/ 4.D0, 0.5D0, 0.3D0, 3.D-3, 1.D-3, -2.D-3, 20.D0,
     1           30.D0, 1.D9 /)
      CMNAME = 'ANISO'
      DO 5 K = 1, NB
         TOLD(K) = 20.D0 + 11.D0*K
         TNEW(K) = TOLD(K) + 3.D0*SIN(1.D0*K)
         EOLD(K) = 1.D3*K
         GNEW(K,1) = 1.D0*COS(1.D0*K)
         GNEW(K,2) = 0.7D0*SIN(2.D0*K)
         GNEW(K,3) = 0.3D0*K - 1.D0
    5 CONTINUE
      FOLD = 0.D0
      SOLD = 0.D0
      CALL VUMATHT(NB, NELEM, 1, 1, 1, 3, 0, 0, 9, CMNAME, 5.D0,
     1  5.D0, 1.D0, COORDMP, DENS, PROPS, TOLD, FOLD, SOLD, EOLD,
     2  TNEW, GNEW, FNEW, SNEW, FLX, ENEW, DEDT, CEFF)
      DMAX = 0.D0
      DO 10 K = 1, NB
         U = EOLD(K)
         DTEMDX = GNEW(K,1:3)
         CALL UMATHT(U,DUDT,DUDG,FLUX,DFDT,DFDG,STATEV,TOLD(K),
     1     TNEW(K)-TOLD(K),DTEMDX,TIME,1.D0,PREDEF,DPRED,CMNAME,3,1,
     2     PROPS,9,COORDS,PNEWDT,1,1,1,1,1,1)
         DMAX = MAX(DMAX, ABS(U-ENEW(K))/ABS(U))
         DO 8 I = 1, 3
            DMAX = MAX(DMAX, ABS(FLUX(I)-FLX(K,I))/ABS(FLUX(I)))
    8    CONTINUE
   10 CONTINUE
      WRITE(*,'(A,ES10.2)') 'max relative difference VUMATHT-UMATHT:',
     1  DMAX
      END
