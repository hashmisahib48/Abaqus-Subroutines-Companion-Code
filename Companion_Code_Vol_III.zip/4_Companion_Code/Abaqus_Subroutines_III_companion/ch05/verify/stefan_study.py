import subprocess, numpy as np, os, sys, json
sys.path.insert(0,'/home/claude/vol3/ch05/verify')
import neumann as N
EXE='/tmp/claude-0/b5/stf'; W='/tmp/claude-0/b5/w1'
def run(dl,h,dt,tend=3600,isch=1,exe=EXE):
    out=subprocess.run([exe,str(dl),str(h),str(dt),str(tend),str(isch)],capture_output=True,text=True,cwd=W).stdout.strip()
    pr=np.loadtxt(W+'/profile.txt'); fr=np.loadtxt(W+'/front.txt')
    x,T=pr[:,0],pr[:,1]
    te=N.temp(x,tend)
    err=np.abs(T-te)
    s_fe=fr[-1,1]; s_ex=N.front(tend); q_fe=fr[-1,2]; q_ex=N.heat(tend)
    # front-position history error
    sh=np.abs(fr[fr[:,0]>=100,1]-N.front(fr[fr[:,0]>=100,0])).max()
    return dict(out=out,smax=err.max(),s_fe=s_fe,s_ex=s_ex,ds=s_fe-s_ex,dq=(q_fe-q_ex)/q_ex*100,dshist=sh,x=x,T=T,fr=fr)
if __name__=='__main__':
    print('exact front %.4f mm, Q %.3f'%(N.front(3600),N.heat(3600)))
    print('--- vary half-width DEL (h=0.1, dt=10, Gauss)')
    for dl in (2.0,1.0,0.5,0.25):
        r=run(dl,0.1,10); print(dl,r['out'],'ds=%.4f dq=%.3f%% Tmax=%.3f'%(r['ds'],r['dq'],r['smax']))
    print('--- vary h (DEL=1, dt=10)')
    for h in (0.4,0.2,0.1,0.05):
        r=run(1.0,h,10); print(h,r['out'],'ds=%.4f dq=%.3f%% Tmax=%.3f'%(r['ds'],r['dq'],r['smax']))
    print('--- vary dt (DEL=1,h=0.1)')
    for dt in (80,40,20,10,5):
        r=run(1.0,0.1,dt); print(dt,r['out'],'ds=%.4f dq=%.3f%% Tmax=%.3f'%(r['ds'],r['dq'],r['smax']))
    print('--- nodal quadrature')
    for dt in (40,10):
        r=run(1.0,0.1,dt,isch=2); print(dt,r['out'],'ds=%.4f dq=%.3f%% Tmax=%.3f'%(r['ds'],r['dq'],r['smax']))
