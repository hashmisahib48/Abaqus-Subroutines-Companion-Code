import numpy as np
from scipy.special import erf, erfc
from scipy.optimize import brentq
# Material W (paraffin-like PCM), N-mm-t-s-degC
RHO=9.0e-10; KS=0.25; KL=0.15; CS=2.0e9; CL=2.2e9; LAT=2.0e11; TM=50.0; TW=20.0; TI=70.0
AS=KS/(RHO*CS); AL=KL/(RHO*CL)
def lam():
    r=np.sqrt(AS/AL)
    def f(l):
        return (KS*(TM-TW)*np.exp(-l*l)/(np.sqrt(np.pi*AS)*erf(l))
                -KL*(TI-TM)*np.exp(-l*l*AS/AL)/(np.sqrt(np.pi*AL)*erfc(l*r))
                -RHO*LAT*l*np.sqrt(AS))
    return brentq(f,1e-6,3.0,xtol=1e-14)
LAM=lam()
def front(t): return 2*LAM*np.sqrt(AS*t)
def temp(x,t):
    x=np.asarray(x,float); s=front(t); r=np.sqrt(AS/AL)
    Ts=TW+(TM-TW)*erf(x/(2*np.sqrt(AS*t)))/erf(LAM)
    Tl=TI-(TI-TM)*erfc(x/(2*np.sqrt(AL*t)))/erfc(LAM*r)
    return np.where(x<=s,Ts,Tl)
def heat(t):  # heat extracted at wall per unit area, mJ/mm^2
    return 2*KS*(TM-TW)*np.sqrt(t)/(np.sqrt(np.pi*AS)*erf(LAM))
if __name__=='__main__':
    print('alpha_s %.5f alpha_l %.5f mm2/s  lambda %.8f'%(AS,AL,LAM))
    for t in (100,600,1800,3600): print(t,'s(t)=%.5f mm  Q=%.4f mJ/mm2'%(front(t),heat(t)))
    print('Stefan number solid c(Tm-Tw)/L = %.3f'%(CS*(TM-TW)/LAT))
