      SUBROUTINE UEXTERNALDB(LOP,LRESTART,TIME,DTIME,KSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2)
      COMMON /K2_TINC/ DTINC
!     LOP = 1: start of an attempt at an increment (Volume I, 10.2)
      IF (LOP .EQ. 1) DTINC = DTIME
!
      RETURN
      END
!
      SUBROUTINE DFLUX(FLUX,SOL,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,TEMP,PRESS,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      COMMON /K2_TINC/ DTINC
!     Rectangular pulse of uniform flux, averaged over the increment
!     Q0 (mW/mm^2), T1, T2 (s): on during T1 < t < T2
      PARAMETER (Q0 = 10.0D0, T1 = 0.0D0, T2 = 0.5D0)
!
      TE = TIME(1)
      TS = TE - DTINC
      ON = MAX(0.0D0, MIN(TE,T2) - MAX(TS,T1))
      FLUX(1) = Q0*ON/DTINC
      FLUX(2) = 0.0D0
!
      RETURN
      END
