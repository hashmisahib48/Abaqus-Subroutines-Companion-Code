      PROGRAM DRVFD
!     Finite-difference check of FLUX(2) = dq/dT of ex2_7_tflux.f
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FLUX(2), TIME(2), COORDS(3), FP(2), FM(2)
      CHARACTER*80 SNAME
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      COORDS(1) = 0.0D0
      COORDS(2) = 0.0D0
      COORDS(3) = 0.0D0
      SNAME = 'HOT'
      WRITE(*,'(A)') '   T(degC)      q        FLUX(2)     FD(h=1e-3)'
     1   //'   abs.err'
      DO 10 K = 1, 7
         T = 20.0D0 + 300.0D0*(K-1)
         H = 1.0D-3*MAX(1.0D0,ABS(T))
         CALL DFLUX(FLUX,T,1,1,TIME,1,1,COORDS,0,T,0.0D0,SNAME)
         CALL DFLUX(FP,T+H,1,1,TIME,1,1,COORDS,0,T,0.0D0,SNAME)
         CALL DFLUX(FM,T-H,1,1,TIME,1,1,COORDS,0,T,0.0D0,SNAME)
         FD = (FP(1)-FM(1))/(2.0D0*H)
         WRITE(*,'(F9.1,3ES13.5,ES10.2)') T, FLUX(1), FLUX(2), FD,
     1      ABS(FD-FLUX(2))
   10 CONTINUE
      END
