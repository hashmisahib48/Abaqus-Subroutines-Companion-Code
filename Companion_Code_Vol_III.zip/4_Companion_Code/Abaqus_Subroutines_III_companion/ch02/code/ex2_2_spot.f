      SUBROUTINE DFLUX(FLUX,SOL,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,TEMP,PRESS,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!
!     Gaussian laser spot, Eq. (2.3-3), centred on the origin of the
!     loaded surface (axisymmetric: r = COORDS(1), surface at y = 0)
!     ETA (-), P (mW = N.mm/s), W (mm), FLUX in mW/mm^2
      PARAMETER (ETA = 0.35D0, P = 2.0D5, W = 1.0D0)
      PARAMETER (PI = 3.14159265358979D0)
!
      FLUX(1) = 0.0D0
      FLUX(2) = 0.0D0
      IF (INDEX(SNAME,'SPOT') .GT. 0) THEN
         R2 = COORDS(1)**2 + COORDS(2)**2
         FLUX(1) = 2.0D0*ETA*P/(PI*W**2)*EXP(-2.0D0*R2/W**2)
      ENDIF
!
      RETURN
      END
