      SUBROUTINE DFLUX(FLUX,SOL,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,TEMP,PRESS,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!     Absorbed beam minus radiation, Eq. (2.7-2); T in degC
!     XI (mW/mm^2), AL0 (-), GAM (1/K), EPS (-)
!     SIG Stefan-Boltzmann (mW/(mm^2.K^4)), TINF (degC), TZERO (K)
      PARAMETER (XI = 1700.0D0, AL0 = 0.35D0, GAM = 2.0D-4)
      PARAMETER (EPS = 0.8D0, SIG = 5.670374D-11)
      PARAMETER (TINF = 20.0D0, TZERO = 273.15D0, TREF = 20.0D0)
      T   = SOL
      TK  = T + TZERO
      TIK = TINF + TZERO
      AL  = AL0*(1.0D0 + GAM*(T - TREF))
      FLUX(1) = AL*XI - EPS*SIG*(TK**4 - TIK**4)
      FLUX(2) = AL0*GAM*XI - 4.0D0*EPS*SIG*TK**3
      RETURN
      END
