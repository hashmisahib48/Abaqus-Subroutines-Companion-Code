      PROGRAM DRVVD
!     VDFLUX (block of points, amplitude 0.5) against DFLUX
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 6)
      DIMENSION CC(NB,2), VEL(NB,2), JUID(NB), DC(NB,2,2), TMP(NB),
     1 VAL(NB)
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      SNAME = 'SPOT'
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      COORDS(3) = 0.0D0
      DO 10 K = 1, NB
         CC(K,1) = 0.4D0*(K-1)
         CC(K,2) = 0.0D0
         VEL(K,1) = 0.0D0
         VEL(K,2) = 0.0D0
         JUID(K) = K
         TMP(K) = 20.0D0
   10 CONTINUE
      CALL VDFLUX(NB,2,1,1,0.0D0,0.0D0,JUID,0.5D0,TMP,CC,VEL,DC,0,
     1   SNAME,VAL)
      DMAX = 0.0D0
      DO 20 K = 1, NB
         COORDS(1) = CC(K,1)
         COORDS(2) = CC(K,2)
         CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,0,20.0D0,0.0D0,
     1      SNAME)
         WRITE(*,'(F6.2,2ES16.8)') CC(K,1), VAL(K), 0.5D0*FLUX(1)
         DMAX = MAX(DMAX, ABS(VAL(K)-0.5D0*FLUX(1)))
   20 CONTINUE
      WRITE(*,'(A,ES10.2)') 'max |VDFLUX - 0.5*DFLUX| = ', DMAX
      END
