      SUBROUTINE DFLUX(FLUX,SOL,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,TEMP,PRESS,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!
!     Units: mW, mm, s.  Three non-uniform fluxes in one routine
      PARAMETER (ETA = 0.35D0, P = 2.0D5, W = 1.0D0)     ! spot
      PARAMETER (RF = 0.40D0, XMU = 2.0D0, XI = 100.0D0) ! absorption
      PARAMETER (YTOP = 0.0D0)           ! free surface at y = 0 (mm)
      PARAMETER (QF = 20.0D0, XL = 40.0D0)               ! face S2NU
      PARAMETER (PI = 3.14159265358979D0)
!
      FLUX(1) = 0.0D0
      FLUX(2) = 0.0D0
!
      IF (JLTYP .EQ. 0) THEN
!        surface-based flux (*DSFLUX): select by surface name
         IF (INDEX(SNAME,'SPOT') .GT. 0) THEN
            R2 = COORDS(1)**2 + COORDS(2)**2
            FLUX(1) = 2.0D0*ETA*P/(PI*W**2)*EXP(-2.0D0*R2/W**2)
         ENDIF
      ELSE IF (JLTYP .EQ. 1) THEN
!        BFNU: volumetric absorption, Beer-Lambert, per unit volume
         DEPTH = MAX(YTOP - COORDS(2), 0.0D0)
         FLUX(1) = (1.0D0 - RF)*XMU*XI*EXP(-XMU*DEPTH)
      ELSE IF (JLTYP .EQ. 12) THEN
!        S2NU: face 2 of an element set, linear in x
         FLUX(1) = QF*COORDS(1)/XL
      ENDIF
!
      RETURN
      END
