      PROGRAM DRVMUL
!     Resultants of the three fluxes of ex2_5_multi.f
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      PARAMETER (PI = 3.14159265358979D0)
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      COORDS(3) = 0.0D0
!     (1) body flux, depth integral over 0 < d < 5 mm, Simpson, 2000 pts
      SNAME = ' '
      N = 2000
      H = 5.0D0/N
      S = 0.0D0
      DO 10 K = 0, N
         COORDS(1) = 0.0D0
         COORDS(2) = -H*K
         CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,1,20.0D0,0.0D0,
     1      SNAME)
         WGT = 2.0D0
         IF (MOD(K,2) .EQ. 1) WGT = 4.0D0
         IF (K .EQ. 0 .OR. K .EQ. N) WGT = 1.0D0
         S = S + WGT*FLUX(1)
   10 CONTINUE
      S = S*H/3.0D0
      EX = 0.6D0*100.0D0*(1.0D0 - EXP(-2.0D0*5.0D0))
      WRITE(*,'(A,2F12.6)') 'body flux per area: routine, exact ', S, EX
!     (2) spot: radial integral of q 2 pi r dr to r = 6 mm (Simpson)
      SNAME = 'SPOT'
      N = 6000
      H = 6.0D0/N
      S = 0.0D0
      DO 20 K = 0, N
         COORDS(1) = H*K
         COORDS(2) = 0.0D0
         CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,0,20.0D0,0.0D0,
     1      SNAME)
         WGT = 2.0D0
         IF (MOD(K,2) .EQ. 1) WGT = 4.0D0
         IF (K .EQ. 0 .OR. K .EQ. N) WGT = 1.0D0
         S = S + WGT*FLUX(1)*2.0D0*PI*COORDS(1)
   20 CONTINUE
      S = S*H/3.0D0
      WRITE(*,'(A,2F12.3)') 'spot power (mW): routine, ETA*P  ', S,
     1   0.35D0*2.0D5
!     (3) face S2NU: other labels must return zero for this entry
      SNAME = 'SPOT'
      COORDS(1) = 20.0D0
      COORDS(2) = 0.0D0
      CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,12,20.0D0,0.0D0,
     1   SNAME)
      WRITE(*,'(A,F10.4)') 'S2NU at x = 20 mm (expected 10):  ', FLUX(1)
      CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,13,20.0D0,0.0D0,
     1   SNAME)
      WRITE(*,'(A,F10.4)') 'S3NU (no branch, expected 0):     ', FLUX(1)
      END
