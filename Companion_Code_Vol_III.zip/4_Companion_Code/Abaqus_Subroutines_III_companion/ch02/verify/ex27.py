import numpy as np, sys, json
sys.path.insert(0,'.'); from dfl import DFlux
from scipy.optimize import brentq
d=DFlux('ex2_7_tflux.f')
k=3.0; L=10.0; Tb=20.0; ne=10; h=L/ne
q=lambda T:d(T)[0]; dq=lambda T:d(T)[1]
g=lambda T0:q(T0)-k*(T0-Tb)/L
T0x=brentq(g,Tb,3000.0,xtol=1e-12); print('closed-form root T0 =',T0x,' q =',q(T0x),' dq/dT=',dq(T0x),' k/L=',k/L)
# scan for uniqueness
Ts=np.linspace(20,3000,3000); gs=np.array([g(t) for t in Ts]); print('sign changes of g:',int(np.sum(np.diff(np.sign(gs))!=0)))
Kc=np.zeros((ne+1,ne+1))
for e in range(ne): Kc[e:e+2,e:e+2]+=k/h*np.array([[1,-1],[-1,1]])
free=np.arange(0,ne)  # node ne fixed at Tb
def newton(derivs,maxit=80,damp=None):
    T=np.full(ne+1,Tb); hist=[]
    for it in range(maxit):
        R=Kc@T; R[0]-=q(T[0]); Rn=np.linalg.norm(R[free])
        hist.append((Rn,T[0]))
        if Rn<1e-6*595: break
        J=Kc.copy(); J[0,0]-=derivs(T[0])
        dT=np.linalg.solve(J[np.ix_(free,free)],-R[free]); T[free]+=dT
    return hist
def fd(T,hh=1e-3): return (q(T+hh)-q(T-hh))/(2*hh)
res={}
for name,fn in [('exact',dq),('fd',fd),('zero',lambda T:0.0),('half',lambda T:0.5*dq(T)),('wrong sign',lambda T:-dq(T))]:
    H=newton(fn); res[name]=H
    print(f'{name:11s} iterations {len(H)-1 if H[-1][0]<1e-6*595 else "no conv"}  final T0 {H[-1][1]:.6f}  residuals',' '.join(f'{x[0]:.1e}' for x in H[:12]))
json.dump({n:[list(x) for x in H] for n,H in res.items()},open('../out/ex27.json','w'))
