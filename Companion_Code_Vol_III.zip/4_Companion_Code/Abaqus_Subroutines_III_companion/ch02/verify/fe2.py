"""Axisymmetric (r,z) transient heat conduction, bilinear quads, backward Euler.
Surface flux supplied through a callable (the compiled DFLUX).  Units: mm, s, mW, mJ, degC."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sl
def graded(l,fine,L,g=1.25):
    x=[0.0]
    while x[-1]<fine-1e-9: x.append(x[-1]+l)
    h=l
    while x[-1]<L-1e-9: h*=g; x.append(min(x[-1]+h,L))
    return np.array(x)
class Axi:
    def __init__(s,rn,zn,k,rhoc):
        s.rn,s.zn,s.k,s.rc=rn,zn,k,rhoc; s.nr,s.nz=len(rn),len(zn)
        s.id=lambda i,j:j*s.nr+i; s.N=s.nr*s.nz
        gp=[-1/np.sqrt(3),1/np.sqrt(3)]
        I=[];J=[];Kv=[];Cv=[]
        for j in range(s.nz-1):
            for i in range(s.nr-1):
                r0,r1,z0,z1=rn[i],rn[i+1],zn[j],zn[j+1]; hr,hz=r1-r0,z1-z0
                nd=[s.id(i,j),s.id(i+1,j),s.id(i+1,j+1),s.id(i,j+1)]
                Ke=np.zeros((4,4));Ce=np.zeros((4,4))
                for xi in gp:
                    for et in gp:
                        N=0.25*np.array([(1-xi)*(1-et),(1+xi)*(1-et),(1+xi)*(1+et),(1-xi)*(1+et)])
                        dNx=0.25*np.array([-(1-et),(1-et),(1+et),-(1+et)])*2/hr
                        dNz=0.25*np.array([-(1-xi),-(1+xi),(1+xi),(1-xi)])*2/hz
                        r=r0+(1+xi)*hr/2; w=2*np.pi*r*hr*hz/4
                        Ke+=k*w*(np.outer(dNx,dNx)+np.outer(dNz,dNz)); Ce+=rhoc*w*np.outer(N,N)
                for a in range(4):
                    for b in range(4): I.append(nd[a]);J.append(nd[b]);Kv.append(Ke[a,b]);Cv.append(Ce[a,b])
        s.K=sp.csr_matrix((Kv,(I,J)),shape=(s.N,s.N)); s.C=sp.csr_matrix((Cv,(I,J)),shape=(s.N,s.N))
        s.top=[s.id(i,0) for i in range(s.nr)]
        s.fixed=[s.id(i,s.nz-1) for i in range(s.nr)]+[s.id(s.nr-1,j) for j in range(s.nz)]
        s.free=np.setdiff1d(np.arange(s.N),s.fixed)
    def weights(s,rule='nodal'):
        """weights of the surface nodes on z=0 (axisymmetric edge areas); rule nodal = int N_a dA (row-sum lumping)"""
        w=np.zeros(s.nr)
        for i in range(s.nr-1):
            r0,r1=s.rn[i],s.rn[i+1]; l=r1-r0
            w[i]+=2*np.pi*l*(r0/2+l/6); w[i+1]+=2*np.pi*l*(r0/2+l/3)
        return w
    def gauss_load(s,q):
        """consistent load with 2-point Gauss per edge, q(r) evaluated at Gauss points"""
        f=np.zeros(s.nr); g=1/np.sqrt(3)
        for i in range(s.nr-1):
            r0,r1=s.rn[i],s.rn[i+1]; l=r1-r0
            for xi in (-g,g):
                r=r0+(1+xi)*l/2; N=np.array([(1-xi)/2,(1+xi)/2]); f[i:i+2]+=N*q(r)*2*np.pi*r*l/2
        return f
    def run(s,qfun,T0,times,rule='nodal'):
        """qfun(r_array,t,Tsurf)->flux at surface nodes; returns centre temperature history"""
        T=np.full(s.N,T0,float); w=s.weights(); hist=[(0.0,T0)]; t=0.0
        for tn in times[1:]:
            dt=tn-t; A=(s.C/dt+s.K).tocsr(); 
            f=np.zeros(s.N); f[s.top]=w*qfun(s.rn,tn,T[s.top])
            rhs=s.C@T/dt+f; Tn=T.copy(); Tn[s.fixed]=T0
            Aff=A[s.free][:,s.free]; Tn[s.free]=sl.spsolve(Aff.tocsc(),(rhs-A[:,s.fixed]@Tn[s.fixed])[s.free])
            T=Tn; t=tn; hist.append((t,T[0]))
        return np.array(hist),T
