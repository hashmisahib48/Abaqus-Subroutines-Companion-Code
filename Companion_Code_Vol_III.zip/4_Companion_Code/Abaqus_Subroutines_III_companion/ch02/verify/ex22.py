import numpy as np, sys
sys.path.insert(0,'.'); from dfl import DFlux; from fe2 import *
from scipy.special import erfc
d=DFlux('ex2_2_spot.f')
k=45.0; rhoc=7.85e-9*4.6e8; al=k/rhoc; eta,P,w=0.35,2e5,1.0; q0=2*eta*P/(np.pi*w**2)
print('rho*c =',rhoc,'mJ/(mm^3 K)  alpha =',al,'mm2/s  q0 =',q0,'mW/mm2')
Tss=eta*P/(np.sqrt(2*np.pi)*k*w); print('steady centre rise',Tss)
def exact(t): return eta*P/(np.sqrt(2*np.pi)*k*w)*(2/np.pi)*np.arctan(np.sqrt(8*al*t)/w)
# resultants by nodal rule
print('\nresultant of nodal rule, relative error:')
for l in [0.25,0.5,0.75,1.0,1.5,2.0,3.0]:
    rn=graded(l,6.0,6.0,1.0000001) if False else np.arange(0,6.0+1e-9,l)
    ax=Axi(rn,np.array([0,1.0]),k,rhoc); wn=ax.weights()
    Q=sum(wn[i]*d(20.0,(rn[i],0,0))[0] for i in range(len(rn)))
    f=ax.gauss_load(lambda r:d(20.0,(r,0,0))[0]); 
    print(f'l/w={l/w:5.2f}  nodal {Q/(eta*P)-1:+.3e}   gauss2 {f.sum()/(eta*P)-1:+.3e}')
# FE solves
tt=0.5*(np.arange(0,51)/50.0)**2
for l in [0.5,0.25,0.125]:
    rn=graded(l,4.0,16.0); zn=graded(l,4.0,16.0); ax=Axi(rn,zn,k,rhoc)
    qf=lambda r,t,T:np.array([d(T[0],(x,0,0),(t,t))[0] for x in r])
    h,T=ax.run(qf,20.0,tt)
    print(f'\nl={l} nodes {ax.N}')
    for t in [0.005,0.05,0.1,0.25,0.5]:
        kk=np.argmin(abs(h[:,0]-t)); print(f'  t={h[kk,0]:.4f}  FE rise {h[kk,1]-20:9.3f}  exact {exact(h[kk,0]):9.3f}  err {(h[kk,1]-20)/exact(h[kk,0])-1:+.4f}')
