import numpy as np, sys, ctypes as C, json
sys.path.insert(0,'.'); from dfl import DFlux
d=DFlux('ex2_6_pulse.f'); dtinc=C.c_double.in_dll(d.lib,'k2_tinc_')
k=45.0; rhoc=3.611; L=2.0; ne=20; h=L/ne; Q0=10.0; ton=0.5
Kc=np.zeros((ne+1,ne+1)); Cc=np.zeros((ne+1,ne+1))
for e in range(ne):
    Kc[e:e+2,e:e+2]+=k/h*np.array([[1,-1],[-1,1]]); Cc[e:e+2,e:e+2]+=rhoc*h/6*np.array([[2,1],[1,2]])
def run(dt,avg,tend=1.2):
    n=int(np.ceil(tend/dt-1e-9)); T=np.zeros(ne+1); A=np.linalg.inv(Cc/dt+Kc); e=0.0; hist=[(0,0.0)]
    for m in range(1,n+1):
        t=m*dt; dtinc.value=dt if avg else 1e-9
        f=np.zeros(ne+1); f[0]=d(0.0,(0,0,0),(t,t),sname='X')[0]
        T=A@(Cc@T/dt+f); hist.append((t,float(np.ones(ne+1)@Cc@T/(rhoc*L)))); 
    return hist
Eex=Q0*ton/(rhoc*L); print('exact mean rise after pulse',Eex)
rows=[]
for dt in [0.05,0.07,0.12,0.2,0.3]:
    a=run(dt,False)[-1][1]; b=run(dt,True)[-1][1]; rows.append((dt,a,b))
    print(f'dt={dt:5.2f}  end-of-increment {a:.5f} ({a/Eex-1:+.3%})   averaged {b:.5f} ({b/Eex-1:+.3%})')
json.dump({'rows':rows,'Eex':Eex,'hist_end':run(0.12,False),'hist_avg':run(0.12,True),'hist_fine':run(0.005,False)},open('../out/ex26.json','w'))
