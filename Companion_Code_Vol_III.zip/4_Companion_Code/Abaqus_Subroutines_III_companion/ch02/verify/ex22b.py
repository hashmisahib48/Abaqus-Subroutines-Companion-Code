import numpy as np, sys
sys.path.insert(0,'.'); from dfl import DFlux; from fe2 import *
d=DFlux('ex2_2_spot.f')
k=45.0; rhoc=7.85e-9*4.6e8; al=k/rhoc; eta,P,w=0.35,2e5,1.0
def exact(t): return eta*P/(np.sqrt(2*np.pi)*k*w)*(2/np.pi)*np.arctan(np.sqrt(8*al*t)/w)
for l,ns in [(0.125,100),(0.0625,50),(0.0625,100),(0.0625,200)]:
    tt=0.5*(np.arange(0,ns+1)/ns)**2
    rn=graded(l,4.0,16.0,1.2); zn=graded(l,4.0,16.0,1.2); ax=Axi(rn,zn,k,rhoc)
    wn=ax.weights(); Q=sum(wn[i]*d(20.0,(rn[i],0,0))[0] for i in range(len(rn)))
    qf=lambda r,t,T:np.array([d(T[0],(x,0,0),(t,t))[0] for x in r])
    h,T=ax.run(qf,20.0,tt)
    print(f'l={l} ns={ns} nodes {ax.N} resultant err {Q/(eta*P)-1:+.4f}')
    for t in [0.05,0.5]:
        kk=np.argmin(abs(h[:,0]-t)); print(f'  t={h[kk,0]:.4f}  FE {h[kk,1]-20:9.3f} exact {exact(h[kk,0]):9.3f} err {(h[kk,1]-20)/exact(h[kk,0])-1:+.4f}')
