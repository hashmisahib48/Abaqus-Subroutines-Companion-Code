import numpy as np, sys, json
sys.path.insert(0,'.'); from dfl import DFlux; from fe2 import *
d=DFlux('ex2_2_spot.f')
k=45.0; rhoc=7.85e-9*4.6e8; al=k/rhoc; eta,P,w=0.35,2e5,1.0
def exact(t): return eta*P/(np.sqrt(2*np.pi)*k*w)*(2/np.pi)*np.arctan(np.sqrt(8*al*t)/w)
out={'rows':[], 'hist':None}
ns=100; tt=0.5*(np.arange(0,ns+1)/ns)**2
for l in [0.5,0.25,0.125,0.0625]:
    rn=graded(l,4.0,16.0,1.2); zn=graded(l,4.0,16.0,1.2); ax=Axi(rn,zn,k,rhoc)
    wn=ax.weights(); Q=sum(wn[i]*d(20.0,(rn[i],0,0))[0] for i in range(len(rn)))
    qf=lambda r,t,T:np.array([d(T[0],(x,0,0),(t,t))[0] for x in r])
    h,T=ax.run(qf,20.0,tt)
    e=lambda t:(lambda kk:(h[kk,1]-20)/exact(h[kk,0])-1)(np.argmin(abs(h[:,0]-t)))
    row=[l,ax.N,Q/(eta*P)-1,e(0.0968) if False else e(0.1),e(0.5)]
    out['rows'].append(row); print(row)
    if l==0.0625: out['hist']=[[a,b-20] for a,b in h.tolist()]
out['tt']=[0.0]+list(np.linspace(0.002,0.5,100)); out['ex']=[0.0]+[exact(t) for t in out['tt'][1:]]
# quadrature curves
lw=np.linspace(0.2,3.0,60)
def planar(l,shift):  # nodal sum of exp(-2x^2/w^2) on grid with offset, relative to w*sqrt(pi/2)
    n=int(10/l); x=(np.arange(-n,n+1)+shift)*l; return l*np.sum(np.exp(-2*x**2/w**2))/(w*np.sqrt(np.pi/2))-1
def axis(l):
    rn=np.arange(0,8.0+1e-9,l); ax=Axi(rn,np.array([0,1.0]),k,rhoc); wn=ax.weights()
    return sum(wn[i]*np.exp(-2*rn[i]**2/w**2) for i in range(len(rn)))/(np.pi*w**2/2)-1
out['quad']={'lw':lw.tolist(),'node':[planar(l,0) for l in lw],'mid':[planar(l,0.5) for l in lw],'axi':[axis(l) for l in lw]}
# poisson check
for l in [0.5,1.0,2.0]:
    ps=2*sum(np.exp(-np.pi**2*m**2*w**2/(2*l**2)) for m in range(1,8)); print('poisson',l,ps, planar(l,0))
json.dump(out,open('../out/ex22.json','w'))
