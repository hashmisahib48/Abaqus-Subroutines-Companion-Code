"""ctypes access to the chapter's DFLUX listings (compiled as shared objects)."""
import ctypes as C, subprocess, os, numpy as np
CODE=os.path.join(os.path.dirname(__file__),'..','code'); OUT=os.path.join(os.path.dirname(__file__),'..','out')
A='/home/claude/vol3/lib/aba'
class DFlux:
    def __init__(self,src):
        so=os.path.join(OUT,src.replace('.f','.so')); os.makedirs(OUT,exist_ok=True)
        subprocess.run(['gfortran','-shared','-fPIC','-ffixed-form','-std=legacy','-I'+A,'-O1',os.path.join(CODE,src),'-o',so],check=True)
        self.lib=C.CDLL(so); self.f=self.lib.dflux_
        self.f.argtypes=[C.c_void_p]*12+[C.c_size_t]
    def __call__(self,sol,coords=(0,0,0),time=(0,0),jltyp=0,sname='SPOT',kinc=1):
        flux=(C.c_double*2)(0,0); s=C.c_double(sol); ks=C.c_int(1); ki=C.c_int(kinc)
        t=(C.c_double*2)(*time); noel=C.c_int(1); npt=C.c_int(1); co=(C.c_double*3)(*coords)
        jl=C.c_int(jltyp); tmp=C.c_double(sol); pr=C.c_double(0)
        sn=C.create_string_buffer(sname.ljust(80).encode(),80)
        self.f(flux,C.byref(s),C.byref(ks),C.byref(ki),t,C.byref(noel),C.byref(npt),co,C.byref(jl),C.byref(tmp),C.byref(pr),sn,80)
        return flux[0],flux[1]
