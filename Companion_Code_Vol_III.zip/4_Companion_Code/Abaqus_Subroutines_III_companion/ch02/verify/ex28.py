import numpy as np, ctypes as C, subprocess, os, json
CODE='../code'; OUT='../out'; A='/home/claude/vol3/lib/aba'
so=OUT+'/vd.so'
subprocess.run(['gfortran','-shared','-fPIC','-ffixed-form','-std=legacy','-ffixed-line-length-none','-I'+A,CODE+'/ex2_8_vdflux.f','-o',so],check=True)
lib=C.CDLL(so); f=lib.vdflux_; f.argtypes=[C.c_void_p]*15+[C.c_size_t]
def vdflux(amp,sname,x=0.0):
    nb=C.c_int(1); nd=C.c_int(2); ks=C.c_int(1); ki=C.c_int(1); st=C.c_double(0); tt=C.c_double(0)
    ju=(C.c_int*1)(1); am=C.c_double(amp); tmp=(C.c_double*1)(20.0); cc=(C.c_double*2)(x,0.0); vel=(C.c_double*2)(0,0)
    dc=(C.c_double*4)(*([0.0]*4)); jl=C.c_int(0); sn=C.create_string_buffer(sname.ljust(80).encode(),80); val=(C.c_double*1)(0)
    f(C.byref(nb),C.byref(nd),C.byref(ks),C.byref(ki),C.byref(st),C.byref(tt),ju,C.byref(am),tmp,cc,vel,dc,C.byref(jl),sn,val,80)
    return val[0]
print('HOTFACE amp 0.5:',vdflux(0.5,'HOTFACE'),' SPOT r=0.4 amp 1:',vdflux(1.0,'SPOT',0.4))
k=45.0; rhoc=3.611; h=0.1; ne=400; dtc=h*h*rhoc/(2*k); dt=0.8*dtc; tr=0.2; q0=1000.0
print('critical dt',dtc,'dt used',dt)
def run(use_amp):
    T=np.zeros(ne+1); m=np.full(ne+1,rhoc*h); m[0]*=0.5; m[-1]*=0.5; t=0.0; out=[]
    n=int(round(tr/dt))
    for s in range(n+1):
        t=s*dt; out.append((t,T[0]))
        amp=t/tr if use_amp else 1.0   # amplitude passed to VDFLUX
        f=np.zeros(ne+1); f[0]=vdflux(amp,'HOTFACE')
        q=np.zeros(ne+1); q[1:-1]=k*(T[2:]-2*T[1:-1]+T[:-2])/h; q[0]=k*(T[1]-T[0])/h; q[-1]=0
        T=T+dt*(f+q)/m
    return np.array(out)
ex=lambda t:4*(q0/tr)*t**1.5/(3*np.sqrt(np.pi*rhoc*k))
H=run(True)
for t in [0.05,0.1,0.2]:
    kk=np.argmin(abs(H[:,0]-t)); print(f't={H[kk,0]:.4f} explicit {H[kk,1]:.4f}  exact {ex(H[kk,0]):.4f}  rel {H[kk,1]/ex(H[kk,0])-1:+.4f}')
print('forgot amplitude (constant q0): rise at 0.2 =',run(False)[-1,1] if False else None)
json.dump(H.tolist(),open(OUT+'/ex28.json','w'))
