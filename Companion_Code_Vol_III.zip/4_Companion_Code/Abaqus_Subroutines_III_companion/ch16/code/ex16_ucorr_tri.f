      SUBROUTINE UCORR(PSD,CORRR,CORRI,KSTEP,LCASE,JNODE1,JDOF1,
     1 JNODE2,JDOF2,COOR1,COOR2)
!     Linear taper of the correlation: valid on a line, not on a surface
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION COOR1(3), COOR2(3)
      CHARACTER*80 PSD
      PARAMETER (RC=200.D0)        ! correlation length, mm
      R = SQRT((COOR1(1)-COOR2(1))**2 + (COOR1(2)-COOR2(2))**2 +
     1         (COOR1(3)-COOR2(3))**2)
      CORRR = MAX(0.D0, 1.D0 - R/RC)
      CORRI = 0.D0
      RETURN
      END
