      SUBROUTINE K16_GAM(F,DX,R,GR,GI)
!     Coherence of a travelling, decaying pattern at frequency F (Hz)
!     DX = x1 - x2 along the travel direction (mm), R = distance (mm)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (TWOPI=6.283185307179586D0)
      PARAMETER (CDEC=0.5D0)       ! decay constant of the coherence
      PARAMETER (UCONV=2.0D4)      ! convection speed, mm/s
!
      COH = EXP(-CDEC*F*R/UCONV)   ! magnitude, 1 at R = 0
      PH  = TWOPI*F*DX/UCONV       ! phase delay, rad
      GR  =  COH*COS(PH)
      GI  = -COH*SIN(PH)           ! Hermitian: sign follows DX
!
      RETURN
      END
