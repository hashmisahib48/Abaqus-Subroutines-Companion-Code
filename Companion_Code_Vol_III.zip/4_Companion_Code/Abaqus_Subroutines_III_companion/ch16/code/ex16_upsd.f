      SUBROUTINE UPSD(PSD,PSDR,PSDI,FREQ,KSTEP)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 PSD
      DOUBLE PRECISION K16_PSDG
!     FREQ arrives in rad/time (rad/s); the profile is in Hz
      PARAMETER (TWOPI=6.283185307179586D0)
!
      FHZ  = FREQ/TWOPI
!     base acceleration PSD in g**2/Hz (TYPE=BASE, G=9810. mm/s**2)
      PSDR = K16_PSDG(FHZ)
      PSDI = 0.D0
!
      RETURN
      END
