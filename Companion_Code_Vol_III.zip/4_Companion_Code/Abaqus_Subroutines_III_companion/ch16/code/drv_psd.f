!     Driver 1: UPSD at Abaqus-style call, numerical integral vs closed form
      PROGRAM DRVPSD
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 PSD
      DIMENSION FT(9)
      DOUBLE PRECISION K16_MSQ, K16_PSDG
      PARAMETER (TWOPI=6.283185307179586D0)
      PSD = 'BASE1'
!     (a) sample values
      DATA FT /10.D0,20.D0,40.D0,80.D0,200.D0,350.D0,1000.D0,2000.D0,
     1   3000.D0/
      DO K = 1, 9
        F = FT(K)
        CALL UPSD(PSD,PSDR,PSDI,F*TWOPI,1)
        WRITE(*,'(A,F8.1,A,ES14.6,A,ES10.2)') 'f(Hz)=',F,'  W=',PSDR,
     1     '  Im=',PSDI
      END DO
!     (b) integral over the segments and over the whole range
      NUM = 2000000
      CALL INTEG(20.D0,80.D0,NUM,S1)
      CALL INTEG(80.D0,350.D0,NUM,S2)
      CALL INTEG(350.D0,2000.D0,NUM,S3)
      WRITE(*,'(A,3ES16.8)') 'numeric seg  ', S1,S2,S3
      WRITE(*,'(A,3ES16.8)') 'closed form  ', K16_MSQ(20.D0,80.D0),
     1  K16_MSQ(80.D0,350.D0),K16_MSQ(350.D0,2000.D0)
      ST = S1+S2+S3
      SC = K16_MSQ(20.D0,2000.D0)
      WRITE(*,'(A,2ES16.8,A,ES10.2)') 'total       ',ST,SC,'  rel diff',
     1   ABS(ST-SC)/SC
      WRITE(*,'(A,2F12.6)') 'g_rms (num, closed)', SQRT(ST), SQRT(SC)
      WRITE(*,'(A,F12.6)') 'g_rms 100-1000 Hz', SQRT(K16_MSQ(100.D0,
     1   1000.D0))
      WRITE(*,'(A)') 'mean square per segment (g2):'
      WRITE(*,'(3F12.6)') K16_MSQ(20.D0,80.D0),K16_MSQ(80.D0,350.D0),
     1   K16_MSQ(350.D0,2000.D0)
!     level at the breakpoints (g2/Hz)
      WRITE(*,'(A,4ES14.6)') 'W at 20,80,350,2000 ',K16_PSDG(20.D0),
     1  K16_PSDG(80.D0),K16_PSDG(350.D0),K16_PSDG(2000.D0)
      END
      SUBROUTINE INTEG(A,B,N,S)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (TWOPI=6.283185307179586D0)
      CHARACTER*80 PSD
      PSD='BASE1'
!     composite midpoint rule in ln f
      H = LOG(B/A)/N
      S = 0.D0
      DO K = 1, N
        F = A*EXP((K-0.5D0)*H)
        CALL UPSD(PSD,PSDR,PSDI,F*TWOPI,1)
        S = S + PSDR*F*H
      END DO
      RETURN
      END
