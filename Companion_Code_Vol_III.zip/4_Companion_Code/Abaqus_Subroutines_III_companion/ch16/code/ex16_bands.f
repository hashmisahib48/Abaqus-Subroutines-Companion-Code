      BLOCK DATA K16_BD
!     Frequency bands: band K covers FE(K-1) <= f < FE(K), centre FC(K)
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K16BND/ FE(0:12), FC(12), NB
      DATA NB /9/
      DATA FE /20.D0, 42.2D0, 51.6D0, 168.9D0, 206.4D0, 379.9D0,
     1   464.4D0, 675.5D0, 825.6D0, 1000.D0, 3*0.D0/             ! Hz
      DATA FC /29.1D0, 46.9D0, 93.4D0, 187.6D0, 280.D0, 422.2D0,
     1   560.1D0, 750.5D0, 908.6D0, 3*0.D0/                      ! Hz
      END
!
      SUBROUTINE UPSD(PSD,PSDR,PSDI,FREQ,KSTEP)
!     PSD of the force: 1 N**2/Hz in band K for the function BANDK
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 PSD
      COMMON /K16BND/ FE(0:12), FC(12), NB
      PARAMETER (TWOPI=6.283185307179586D0)
!
      READ(PSD(5:5),'(I1)') K              ! 'BAND3' -> 3
      F = FREQ/TWOPI
      PSDR = 0.D0
      PSDI = 0.D0
      IF (F .GE. FE(K-1) .AND. F .LT. FE(K)) PSDR = 1.D0
!
      RETURN
      END
