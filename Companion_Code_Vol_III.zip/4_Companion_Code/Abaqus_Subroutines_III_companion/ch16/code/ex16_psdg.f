      DOUBLE PRECISION FUNCTION K16_PSDG(F)
!     Breakpoint PSD, log-log interpolation. F in Hz, result g**2/Hz
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FB(4), SL(3)
      PARAMETER (W0=2.5D-3)                   ! g**2/Hz at FB(1)
      PARAMETER (DBOCT=3.010299956639812D0)   ! 10*LOG10(2), dB/octave
      DATA FB /20.D0, 80.D0, 350.D0, 2000.D0/ ! breakpoints, Hz
      DATA SL /6.D0, 0.D0, -3.D0/             ! slopes, dB/octave
!
      K16_PSDG = 0.D0
      IF (F .LT. FB(1) .OR. F .GT. FB(4)) RETURN
      WK = W0
      DO K = 1, 3
        EN = SL(K)/DBOCT                      ! exponent
        IF (F .LE. FB(K+1)) THEN
          K16_PSDG = WK*(F/FB(K))**EN
          RETURN
        END IF
        WK = WK*(FB(K+1)/FB(K))**EN           ! next breakpoint level
      END DO
!
      RETURN
      END
