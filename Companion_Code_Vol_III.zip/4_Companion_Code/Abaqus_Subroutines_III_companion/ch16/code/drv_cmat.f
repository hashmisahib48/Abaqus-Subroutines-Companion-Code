!     Driver 4: assemble the cross-correlation matrix pair by pair with
!     UCORR, as Abaqus does, test the Hermitian symmetry and write the
!     matrix for an eigenvalue test (python, verify/psd_test.py).
!     Input: ICASE (1 line of 19 nodes, 2 grid of 9 x 9 nodes), file name
      PROGRAM DRVCM
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX=81)
      CHARACTER*80 PSD, FNAME
      DIMENSION XY(3,NMAX), CR(NMAX,NMAX), CI(NMAX,NMAX)
      READ(*,*) ICASE, FNAME
      PSD = 'BAND1'
      IF (ICASE .EQ. 1) THEN
        N = 19
        DO I = 1, N
          XY(1,I) = 50.D0*I
          XY(2,I) = 0.D0
          XY(3,I) = 0.D0
        END DO
      ELSE
        N = 81
        DO I = 1, N
          XY(1,I) = 50.D0*MOD(I-1,9)
          XY(2,I) = 50.D0*((I-1)/9)
          XY(3,I) = 0.D0
        END DO
      END IF
      HERM = 0.D0
      DO I = 1, N
        DO J = 1, N
          CALL UCORR(PSD,A,B,1,1,I,3,J,3,XY(1,I),XY(1,J))
          CR(I,J) = A
          CI(I,J) = B
        END DO
      END DO
      DO I = 1, N
        DO J = 1, N
          HERM = MAX(HERM, ABS(CR(I,J)-CR(J,I)), ABS(CI(I,J)+CI(J,I)))
        END DO
      END DO
      WRITE(*,'(A,I3,A,ES10.2)') 'N =', N, '   max Hermitian violation',
     1   HERM
      OPEN(7, FILE=FNAME)
      DO I = 1, N
        WRITE(7,'(81ES24.16)') (CR(I,J), J=1,N)
      END DO
      DO I = 1, N
        WRITE(7,'(81ES24.16)') (CI(I,J), J=1,N)
      END DO
      CLOSE(7)
      END
