      SUBROUTINE UCORR(PSD,CORRR,CORRI,KSTEP,LCASE,JNODE1,JDOF1,
     1 JNODE2,JDOF2,COOR1,COOR2)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION COOR1(3), COOR2(3)
      CHARACTER*80 PSD
      PARAMETER (FREF=47.D0)       ! frequency of the coherence, Hz
!
      CORRR = 0.D0
      CORRI = 0.D0
!     forces in different directions are taken as independent
      IF (JDOF1 .NE. JDOF2) RETURN
      DX = COOR1(1) - COOR2(1)
      DY = COOR1(2) - COOR2(2)
      DZ = COOR1(3) - COOR2(3)
      R  = SQRT(DX*DX + DY*DY + DZ*DZ)
      CALL K16_GAM(FREF,DX,R,CORRR,CORRI)
!
      RETURN
      END
