#!/bin/sh
# builds and runs the Chapter 16 drivers (gfortran, stubs); outputs in ../out
A=/home/claude/vol3/lib/aba; F="-ffixed-form -std=legacy -I$A -O2"; cd "$(dirname "$0")"; mkdir -p ../out
gfortran $F drv_psd.f ex16_upsd.f ex16_psdg.f ex16_msq.f $A/stubs.f -o ../out/drv_psd && ../out/drv_psd
gfortran $F drv_miles.f ex16_upsd.f ex16_psdg.f $A/stubs.f -o ../out/drv_miles && ../out/drv_miles > ../out/miles.txt
for v in b s; do u=ex16_ucorr_b.f; [ $v = s ] && u=ex16_ucorr.f; gfortran $F drv_beam.f $u ex16_gam.f ex16_bands.f $A/stubs.f -o ../out/drv_beam_$v; done
gfortran $F drv_cmat.f ex16_ucorr.f ex16_gam.f $A/stubs.f -o ../out/drv_cmat
gfortran $F drv_cmat.f ex16_ucorr_tri.f $A/stubs.f -o ../out/drv_cmat_tri
gfortran $F drv_cmat.f prob_16b2_bug.f $A/stubs.f -o ../out/drv_cmat_bug
sh ../out/run_beam.sh
