      DOUBLE PRECISION FUNCTION K16_MSQ(F1,F2)
!     Closed-form integral of K16_PSDG from F1 to F2 (Hz), g**2
      INCLUDE 'ABA_PARAM.INC'
      DOUBLE PRECISION K16_PSDG
      DIMENSION FB(4), SL(3)
      PARAMETER (DBOCT=3.010299956639812D0, ZERO=0.D0, ONE=1.D0)
      DATA FB /20.D0, 80.D0, 350.D0, 2000.D0/
      DATA SL /6.D0, 0.D0, -3.D0/
!
      K16_MSQ = ZERO
      DO K = 1, 3
        A = MAX(F1, FB(K))
        B = MIN(F2, FB(K+1))
        IF (B .GT. A) THEN
          EN = SL(K)/DBOCT
          WA = K16_PSDG(A)
          IF (ABS(EN + ONE) .LT. 1.D-9) THEN
            K16_MSQ = K16_MSQ + WA*A*LOG(B/A)
          ELSE
            P = EN + ONE
            K16_MSQ = K16_MSQ + WA*A*((B/A)**P - ONE)/P
          END IF
        END IF
      END DO
!
      RETURN
      END
