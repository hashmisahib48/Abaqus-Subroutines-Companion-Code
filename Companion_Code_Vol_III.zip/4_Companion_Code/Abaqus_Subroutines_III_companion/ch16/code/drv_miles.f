!     Driver 2: base-excited single-DOF oscillator. RMS of the absolute
!     acceleration (g) and of the relative displacement (mm) by numerical
!     integration of |H|**2 * S, with S from UPSD, against Miles' equation.
      PROGRAM DRVMIL
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 PSD
      DIMENSION FN(4), QQ(2)
      PARAMETER (PI=3.141592653589793D0, TWOPI=6.283185307179586D0)
      PARAMETER (GACC=9810.D0)          ! mm/s**2 per g
      DATA FN /50.D0, 100.D0, 300.D0, 1000.D0/, QQ /10.D0, 50.D0/
      PSD = 'BASE1'
!     (a) flat PSD 0.04 g**2/Hz (UPSD not used), 0 -> infinity
      W = 0.04D0
      DO IQ = 1, 2
        Z = 0.5D0/QQ(IQ)
        FNI = 100.D0
        CALL RMSFLAT(FNI,Z,W,A1,ZD1)
        EXACT = SQRT(W*PI*FNI*(1.D0+4.D0*Z*Z)/(4.D0*Z))
        AMILES = SQRT(0.5D0*PI*FNI*QQ(IQ)*W)
        WRITE(*,'(A,F6.1,A,3F12.6)') 'flat Q=',QQ(IQ),
     1    ' num/exact/Miles g_rms:',A1,EXACT,AMILES
!       relative displacement, mm
        WN = TWOPI*FNI
        ZMIL = SQRT(0.5D0*PI*FNI*QQ(IQ)*W*GACC**2/WN**4)
        WRITE(*,'(A,2ES14.6)') '   rel. displacement (mm) num, Eq:',
     1    ZD1,ZMIL
      END DO
!     (b) the breakpoint profile through UPSD, 20-2000 Hz
      DO IQ = 1, 2
        Z = 0.5D0/QQ(IQ)
        DO JF = 1, 4
          CALL RMSPROF(FN(JF),Z,A2)
          CALL UPSD(PSD,WR,WI,TWOPI*FN(JF),1)
          AMILES = SQRT(0.5D0*PI*FN(JF)*QQ(IQ)*WR)
          WRITE(*,'(A,F6.1,F8.1,3F12.6)') 'prof Q,fn,num,Miles,ratio ',
     1      QQ(IQ),FN(JF),A2,AMILES,A2/AMILES
        END DO
      END DO
      END
!
      SUBROUTINE RMSFLAT(FN,Z,W,A,ZD)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (TWOPI=6.283185307179586D0, GACC=9810.D0)
      NPT = 4000000
      H = LOG(1.D8)/NPT                  ! f from 1e-4 fn to 1e4 fn
      S = 0.D0
      SD = 0.D0
      DO K = 1, NPT
        F = FN*1.D-4*EXP((K-0.5D0)*H)
        R = F/FN
        T = (1.D0 + (2.D0*Z*R)**2)/((1.D0-R*R)**2 + (2.D0*Z*R)**2)
        S = S + T*W*F*H
        SD = SD + W*GACC**2/((TWOPI*FN)**4*((1.D0-R*R)**2
     1     + (2.D0*Z*R)**2))*F*H
      END DO
      A = SQRT(S)
      ZD = SQRT(SD)
      RETURN
      END
!
      SUBROUTINE RMSPROF(FN,Z,A)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (TWOPI=6.283185307179586D0)
      CHARACTER*80 PSD
      PSD = 'BASE1'
      NPT = 2000000
      H = LOG(2000.D0/20.D0)/NPT
      S = 0.D0
      DO K = 1, NPT
        F = 20.D0*EXP((K-0.5D0)*H)
        CALL UPSD(PSD,WR,WI,F*TWOPI,1)
        R = F/FN
        T = (1.D0 + (2.D0*Z*R)**2)/((1.D0-R*R)**2 + (2.D0*Z*R)**2)
        S = S + T*WR*F*H
      END DO
      A = SQRT(S)
      RETURN
      END
