      SUBROUTINE UCORR(PSD,CORRR,CORRI,KSTEP,LCASE,JNODE1,JDOF1,
     1 JNODE2,JDOF2,COOR1,COOR2)
!     Executable part as in Listing 16.4; the coherence is evaluated at
!     the centre frequency of the band that belongs to the load case.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION COOR1(3), COOR2(3)
      CHARACTER*80 PSD
      COMMON /K16BND/ FE(0:12), FC(12), NB
!
      CORRR = 0.D0
      CORRI = 0.D0
      IF (JDOF1 .NE. JDOF2) RETURN
      DX = COOR1(1) - COOR2(1)
      DY = COOR1(2) - COOR2(2)
      DZ = COOR1(3) - COOR2(3)
      R  = SQRT(DX*DX + DY*DY + DZ*DZ)
      CALL K16_GAM(FC(LCASE),DX,R,CORRR,CORRI)
!
      RETURN
      END
