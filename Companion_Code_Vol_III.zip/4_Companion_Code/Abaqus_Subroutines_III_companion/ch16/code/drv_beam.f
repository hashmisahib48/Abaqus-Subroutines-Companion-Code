!     Driver 3: simply supported beam under N correlated nodal forces.
!     RMS mid-span displacement from the modal CSD, with the correlation
!     matrix taken from UCORR (ITYPE 1), from the exact coherence (2) or
!     the identity (0, TYPE=UNCORRELATED). Input: ITYPE, NB, FE(0:NB),
!     FC(1:NB). Force PSD 1 N**2/Hz at every node, in the bands of UPSD.
      PROGRAM DRVBEAM
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NN=19, NM=8, NF=100000)
      PARAMETER (PI=3.141592653589793D0, TWOPI=2.D0*PI)
      PARAMETER (RL=1000.D0, EE=210000.D0, AA=400.D0)
      PARAMETER (XI=13333.333333333D0, RHO=7.85D-9, ZETA=0.02D0)
      COMMON /K16BND/ FE(0:12), FC(12), NB
      CHARACTER*80 PSD
      DIMENSION X(NN), PHI(NM,NN), WR(NM)
      COMPLEX*16 C(NN,NN), CB(NN,NN,12), QB(NM,NM,12), Q(NM,NM)
      COMPLEX*16 H(NM), QQ
      READ(*,*) ITYPE, NB
      READ(*,*) (FE(K),K=0,NB)
      READ(*,*) (FC(K),K=1,NB)
      HH = RL/(NN+1)
      RMASS = RHO*AA*RL/2.D0
      DO J = 1, NN
        X(J) = J*HH
      END DO
      DO MR = 1, NM
        WR(MR) = (MR*PI/RL)**2*SQRT(EE*XI/(RHO*AA))
        DO J = 1, NN
          PHI(MR,J) = SIN(MR*PI*X(J)/RL)
        END DO
      END DO
!     per-band matrices, assembled the way Abaqus does: pair by pair
      DO K = 1, NB
        PSD = 'BAND1'
        WRITE(PSD(5:5),'(I1)') K
        DO I = 1, NN
          DO J = 1, NN
            IF (ITYPE .EQ. 0 .AND. I .NE. J) THEN
              CB(I,J,K) = (0.D0,0.D0)
            ELSE
              CALL UCORR(PSD,CR,CI,1,K,I,2,J,2,(/X(I),0.D0,0.D0/),
     1                   (/X(J),0.D0,0.D0/))
              CB(I,J,K) = DCMPLX(CR,CI)
            END IF
          END DO
        END DO
        CALL MODAL(NN,NM,PHI,CB(1,1,K),QB(1,1,K))
      END DO
      DF = LOG(FE(NB)/FE(0))
      SUM = 0.D0
      DO KF = 1, NF
        F = FE(0)*EXP((KF-0.5D0)*DF/NF)
        W = TWOPI*F
        DFF = F*DF/NF
        DO MR = 1, NM
          H(MR) = 1.D0/(RMASS*DCMPLX(WR(MR)**2-W*W,
     1       2.D0*ZETA*WR(MR)*W))
        END DO
        IF (ITYPE .EQ. 2) THEN
          DO I = 1, NN
            DO J = 1, NN
              CALL K16_GAM(F,X(I)-X(J),ABS(X(I)-X(J)),CR,CI)
              C(I,J) = DCMPLX(CR,CI)
            END DO
          END DO
          CALL MODAL(NN,NM,PHI,C,Q)
          PS = 1.D0
        ELSE
!         band of this frequency through UPSD (BANDk window)
          PS = 0.D0
          DO K = 1, NB
            PSD = 'BAND1'
            WRITE(PSD(5:5),'(I1)') K
            CALL UPSD(PSD,PR,PIM,W,1)
            IF (PR .NE. 0.D0) THEN
              KB = K
              PS = PR
            END IF
          END DO
          IF (PS .EQ. 0.D0) CYCLE
          DO MR = 1, NM
            DO MS = 1, NM
              Q(MR,MS) = QB(MR,MS,KB)
            END DO
          END DO
        END IF
        DO MR = 1, NM
          DO MS = 1, NM
            QQ = Q(MR,MS)*H(MR)*DCONJG(H(MS))
            SUM = SUM + PS*SIN(MR*PI/2.D0)*SIN(MS*PI/2.D0)*DBLE(QQ)*DFF
          END DO
        END DO
      END DO
      WRITE(*,'(A,I2,A,ES16.8)') 'ITYPE',ITYPE,'  sigma_mid (mm) ',
     1  SQRT(SUM)
      END
!
      SUBROUTINE MODAL(NN,NM,PHI,C,Q)
!     Q = PHI * C * PHI**T  (modal force CSD)
      COMPLEX*16 C(NN,NN), Q(NM,NM)
      DOUBLE PRECISION PHI(NM,NN)
      DO MR = 1, NM
        DO MS = 1, NM
          Q(MR,MS) = (0.D0,0.D0)
          DO I = 1, NN
            DO J = 1, NN
              Q(MR,MS) = Q(MR,MS) + PHI(MR,I)*C(I,J)*PHI(MS,J)
            END DO
          END DO
        END DO
      END DO
      RETURN
      END
