import numpy as np; from scipy.integrate import quad
d=10*np.log10(2); fb=[20,80,350,2000]; sl=[6,0,-3]; W=[2.5e-3]
for k in range(3): W.append(W[-1]*(fb[k+1]/fb[k])**(sl[k]/d))
def S(f):
    for k in range(3):
        if f<=fb[k+1]: return W[k]*(f/fb[k])**(sl[k]/d)
    return 0
def rms(fn,Q):
    z=.5/Q
    g=lambda f: S(f)*(1+(2*z*f/fn)**2)/((1-(f/fn)**2)**2+(2*z*f/fn)**2)
    pts=sorted(set([80,350]+[fn*(1+x) for x in (-1/Q,-.5/Q,0,.5/Q,1/Q) if 20<fn*(1+x)<2000]))
    edges=[20]+[p for p in pts if 20<p<2000]+[2000]
    return np.sqrt(sum(quad(g,a,b,epsrel=1e-12,limit=400)[0] for a,b in zip(edges[:-1],edges[1:])))
for Q in (10,50):
    for fn in (50,100,300,1000):
        print(Q,fn,'%.6f'%rms(fn,Q),'miles %.6f'%np.sqrt(np.pi/2*fn*Q*S(fn)))
