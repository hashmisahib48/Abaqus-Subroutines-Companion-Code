# independent check of the breakpoint PSD (Python, SciPy quad)
import numpy as np; from scipy.integrate import quad
d=10*np.log10(2); fb=[20,80,350,2000]; sl=[6,0,-3]; W=[2.5e-3]
for k in range(3): W.append(W[-1]*(fb[k+1]/fb[k])**(sl[k]/d))
def S(f):
    for k in range(3):
        if f<=fb[k+1]: return W[k]*(f/fb[k])**(sl[k]/d)
    return 0
tot=0
for k in range(3):
    v=quad(S,fb[k],fb[k+1],epsabs=1e-14,epsrel=1e-14)[0]; tot+=v; print(k+1,v)
print('W',W); print('ms',tot,'grms',tot**.5)
print('exps',[s/d for s in sl])
print('100-1000',quad(S,100,350)[0]+quad(S,350,1000)[0])
