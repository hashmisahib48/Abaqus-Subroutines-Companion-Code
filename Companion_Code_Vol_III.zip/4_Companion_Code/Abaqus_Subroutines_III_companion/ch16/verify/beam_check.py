# Independent evaluation of the beam response (NumPy), same data as drv_beam.f
import numpy as np
L=1000.;E=210000.;A=400.;I=A*A/12.;rho=7.85e-9;zeta=.02;NN=19;NM=8
x=np.arange(1,NN+1)*L/(NN+1); m=rho*A*L/2
wr=(np.arange(1,NM+1)*np.pi/L)**2*np.sqrt(E*I/(rho*A)); fr=wr/2/np.pi
phi=np.sin(np.outer(np.arange(1,NM+1),np.pi*x/L)); phim=np.sin(np.arange(1,NM+1)*np.pi/2)
U=2e4; cd=.5
def gam(f,dx=None):
    dx=x[:,None]-x[None,:]; R=abs(dx)
    return np.exp(-cd*f*R/U)*np.exp(-1j*2*np.pi*f*dx/U)
def sigma(Cof,fa,fb,n=400000,win=None):
    f=fa*np.exp((np.arange(n)+.5)*np.log(fb/fa)/n); df=f*np.log(fb/fa)/n
    w=2*np.pi*f; H=1/(m*(wr[:,None]**2-w[None]**2+2j*zeta*wr[:,None]*w[None]))
    tot=0.
    # group frequencies by identical C (bands) to keep it fast
    if callable(Cof):
        for k in range(0,n,1):  # slow path avoided: use chunks
            pass
    return None
def var_const(C,fa,fb,n=200000):
    f=fa*np.exp((np.arange(n)+.5)*np.log(fb/fa)/n); df=f*np.log(fb/fa)/n
    w=2*np.pi*f; H=1/(m*(wr[:,None]**2-w[None]**2+2j*zeta*wr[:,None]*w[None]))
    Q=phi@C@phi.T
    # sum_rs phim_r phim_s Re(Q_rs H_r H_s^*)
    HH=H*phim[:,None]
    v=np.einsum('rf,rs,sf->f',HH,Q,HH.conj()).real
    return (v*df).sum()
def var_exact(fa,fb,n=60000):
    f=fa*np.exp((np.arange(n)+.5)*np.log(fb/fa)/n); df=f*np.log(fb/fa)/n
    w=2*np.pi*f; H=1/(m*(wr[:,None]**2-w[None]**2+2j*zeta*wr[:,None]*w[None]))*phim[:,None]
    tot=0.;
    dxm=x[:,None]-x[None,:]; R=abs(dxm)
    for k in range(n):
        C=np.exp(-cd*f[k]*R/U)*np.exp(-1j*2*np.pi*f[k]*dxm/U)
        Q=phi@C@phi.T
        tot+=(H[:,k]@Q@H[:,k].conj()).real*df[k]
    return tot
if __name__=='__main__':
    print('f_r',fr[:5],'m',m)
    print('uncorrelated',np.sqrt(var_const(np.eye(NN),20,1000)))
    print('fully corr',np.sqrt(var_const(np.ones((NN,NN)),20,1000)))
    print('single band 47',np.sqrt(var_const(gam(47.),20,1000)))
    def banded(E_,F_):
        return np.sqrt(sum(var_const(gam(fc),a,b) for a,b,fc in zip(E_[:-1],E_[1:],F_)))
    print('modal bands',banded([20,94,281,563,1000],[47,188,422,750]))
    for nb in (1,2,4,8):
        e=20*50**(np.arange(nb+1)/nb); print('log',nb,banded(e,np.sqrt(e[:-1]*e[1:])))
    print('exact',np.sqrt(var_exact(20,1000)))
