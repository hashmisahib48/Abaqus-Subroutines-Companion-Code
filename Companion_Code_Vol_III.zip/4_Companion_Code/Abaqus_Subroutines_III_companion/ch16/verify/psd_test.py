import numpy as np,sys
def load(f):
    a=np.loadtxt(f); n=a.shape[1]; return a[:n]+1j*a[n:]
out={}
for f in ('c_line','c_grid','t_line','t_grid'):
    C=load('/home/claude/vol3/ch16/out/%s.txt'%f); Hm=np.abs(C-C.conj().T).max()
    ev=np.linalg.eigvalsh((C+C.conj().T)/2); out[f]=ev
    print(f,C.shape[0],'herm %.1e'%Hm,'min eig %.5f'%ev.min(),'max eig %.4f'%ev.max())
np.savez('/home/claude/vol3/ch16/out/eigs.npz',**out)
