import numpy as np, json
d=10*np.log10(2); fb=np.array([20,80,350,2000.]); sl=[6,0,-3]; W=[2.5e-3]
for k in range(3): W.append(W[-1]*(fb[k+1]/fb[k])**(sl[k]/d))
def S(f):
    f=np.asarray(f,float); out=np.zeros_like(f)
    for k in range(3):
        m=(f>=fb[k])&(f<=fb[k+1]); out[m]=W[k]*(f[m]/fb[k])**(sl[k]/d)
    return out
fn,Q=100.,50.; z=.5/Q
def integrand(f): r=f/fn; return S(f)*(1+(2*z*r)**2)/((1-r*r)**2+(2*z*r)**2)
def grid(a,b,n,kind):
    t=np.linspace(0,1,n)
    if kind=='lin': return a+(b-a)*t
    if kind=='cos': return a+(b-a)*0.5*(1-np.cos(np.pi*t))
    if kind=='log': return a*(b/a)**t
def rmsN(n,kind):
    tot=0
    for a,b in ((20,fn),(fn,2000)):
        f=grid(a,b,n,kind); y=integrand(f); tot+=np.trapezoid(y,f)
    return np.sqrt(tot)

out={'N':[5,10,20,40,80,160,320]}
for Qv in (10.,50.):
    fn=100.; Q=Qv; z=.5/Q
    ref=rmsN(200000,'lin'); out['ref%d'%Qv]=ref
    for k in ('lin','cos'): out['%s%d'%(k,Qv)]=[abs(rmsN(n,k)/ref-1) for n in out['N']]
json.dump(out,open('../out/npts.json','w'))
print(out)
