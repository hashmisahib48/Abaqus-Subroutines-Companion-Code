import numpy as np
from scipy.integrate import quad
d=10*np.log10(2)
# A1
fb=[20,200,1000,2000]; sl=[3,0,-6]; W=[0.005]
for k in range(3): W.append(W[-1]*(fb[k+1]/fb[k])**(sl[k]/d))
n=[s/d for s in sl]; print('A1 W',W,'n',n)
ms=0
for k in range(3):
    a,b=fb[k],fb[k+1]; p=n[k]+1
    v=W[k]*a*np.log(b/a) if abs(p)<1e-9 else W[k]*a*((b/a)**p-1)/p
    print(' seg',v); ms+=v
print(' ms',ms,'grms',ms**.5, 'octaves',np.log2(200/20),np.log2(2))
# A2 SDOF fn=200 Q=25 W=0.02
fn,Q,Wf=200.,25.,0.02; z=.5/Q; G=9810.
print('A2 miles',np.sqrt(np.pi/2*fn*Q*Wf),'exact',np.sqrt(np.pi/4/z*fn*Wf*(1+4*z*z)),'3sigma',3*np.sqrt(np.pi/2*fn*Q*Wf))
wn=2*np.pi*fn; print(' relative disp mm',np.sqrt(np.pi/2*fn*Q*Wf*G**2/wn**4)*0+np.sqrt(np.pi/2*fn*Q*Wf*G**2/wn**4*1.0)) 
print(' Wa',Wf*G**2, 'PSD per rad/s',Wf*G**2/2/np.pi)
# A3 three nodes at 0,100,200 at f=50
U=2e4;cd=.5
def gam(f,x1,x2):
    dx=x1-x2;R=abs(dx);return np.exp(-cd*f*R/U)*np.exp(-1j*2*np.pi*f*dx/U)
x=[0,100,200];C=np.array([[gam(50,a,b) for b in x] for a in x]);print('A3',np.round(C,5));print(np.linalg.eigvalsh(C))
# B1
for Qv in (2,5,10,25): print('B1',Qv,np.sqrt(1+1/Qv**2))
# C1 linear interpolation
f=np.array([20,80,350,2000.]);Wl=np.array([2.5e-3,0.039622329811527836,0.039622329811527836,0.006975382971907854])
lin=sum(0.5*(Wl[k]+Wl[k+1])*(f[k+1]-f[k]) for k in range(3)); print('C1 linear',lin,lin**.5, 'ref',35.98373026787356**.5, lin**.5/35.98373026787356**.5-1)
# C2 correlation between directions
s=7.966189
for rho in (0,0.5,1,-0.5): print('C2',rho,s*np.sqrt(2*(1+rho)))
print('C2 ratio uncorr', s*np.sqrt(2))
