import sys,os; sys.path.insert(0,'.')
from fe3d import *
g=Grid(graded(-4,10,1,-10,20),graded(0,4,1,0,10),graded(0,4,1,0,10),zsign=-1.0)
os.makedirs(OUT+'/dt2',exist_ok=True); os.chdir(OUT+'/dt2'); g.table('k7_elems.dat')
u=Umd(['ex7_goldak.f','k7_util.f','ex7_setup.f'],name='dt2'); u.setup(1,1,(0,0),0.25)
for dt in [0.1,0.125,0.25,0.5]:
    act,r=u.setup(2,1,(1.0,1.0),dt); print(dt,'v*dt',6*dt,'DT(2) on return',r,'active',len(act))
