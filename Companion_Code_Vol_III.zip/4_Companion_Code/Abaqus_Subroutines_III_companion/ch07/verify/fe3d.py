"""Trilinear-brick heat conduction on a rectilinear grid (Kronecker-product matrices), backward Euler.
Units: mm, s, mW, mJ, K.  Nodes ordered ix fastest.  Used only as the test bench for UMDFLUX/UMDFLUXSETUP."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sl, ctypes as C, subprocess, os
LIB='/home/claude/vol3/lib/aba'; CODE='/home/claude/vol3/ch07/code'; OUT='/home/claude/vol3/ch07/out'
K_=45.0; RHOC=3.611
def graded(fine0,fine1,h,lo,hi,g=1.3):
    """uniform spacing h on [fine0,fine1], geometric growth g outwards to lo and hi"""
    n=int(round((fine1-fine0)/h)); x=list(fine0+h*np.arange(n+1))
    s=h
    while x[-1]<hi-1e-9: s*=g; x.append(min(x[-1]+s,hi))
    s=h
    while x[0]>lo+1e-9: s*=g; x.insert(0,max(x[0]-s,lo))
    return np.array(x)
def m1(x):
    n=len(x); h=np.diff(x); M=sp.lil_matrix((n,n)); K=sp.lil_matrix((n,n))
    for e in range(n-1):
        M[e:e+2,e:e+2]+=h[e]/6*np.array([[2,1],[1,2]]); K[e:e+2,e:e+2]+=1/h[e]*np.array([[1,-1],[-1,1]])
    return M.tocsr(),K.tocsr()
class Grid:
    # sx,sy,sz: sign of depth: z coordinate given to Abaqus = zsign*zgrid
    def __init__(s,x,y,z,zsign=1.0,k=K_,rhoc=RHOC):
        s.x,s.y,s.z=x,y,z; s.nx,s.ny,s.nz=len(x),len(y),len(z); s.zsign=zsign
        s.N=s.nx*s.ny*s.nz; s.cx,s.cy,s.cz=s.nx-1,s.ny-1,s.nz-1
        Mx,Kx=m1(x); My,Ky=m1(y); Mz,Kz=m1(z)
        kr=lambda a,b,c: sp.kron(c,sp.kron(b,a),format='csr')
        s.M=rhoc*kr(Mx,My,Mz); s.K=k*(kr(Kx,My,Mz)+kr(Mx,Ky,Mz)+kr(Mx,My,Kz))
    def nid(s,i,j,k): return i+s.nx*(j+s.ny*k)
    def label(s,i,j,k): return 1+i+s.cx*(j+s.cy*k)
    def cell(s,lab):
        l=lab-1; i=l%s.cx; j=(l//s.cx)%s.cy; k=l//(s.cx*s.cy); return i,j,k
    # Abaqus corner order: bottom face (u=-1) nodes 1-4, top face (u=+1) nodes 5-8, u along +z (Abaqus)
    OFF=[(0,0),(1,0),(1,1),(0,1)]
    def cell_nodes_coords(s,lab):
        if not hasattr(s,'_cc'): s._cc={}
        if lab in s._cc: return s._cc[lab]
        i,j,k=s.cell(lab); nid=[];crd=[]
        # depth index: zsign=-1 -> Abaqus z=-depth; u=+1 (top) = smaller depth = index k
        layers=[k+1,k] if s.zsign<0 else [k,k+1]
        for kk in layers:
            for (a,b) in s.OFF:
                nid.append(s.nid(i+a,j+b,kk)); crd.append((s.x[i+a],s.y[j+b],s.zsign*s.z[kk]))
        s._cc[lab]=(np.array(nid),np.array(crd,dtype=float)); return s._cc[lab]
    def table(s,path):
        with open(path,'w') as f:
            for lab in range(1,s.cx*s.cy*s.cz+1):
                _,c=s.cell_nodes_coords(lab)
                f.write('%d %.9g %.9g %.9g %.9g %.9g %.9g\n'%(lab,c[:,0].min(),c[:,0].max(),c[:,1].min(),c[:,1].max(),c[:,2].min(),c[:,2].max()))
    def bnodes(s,faces):
        m=np.zeros((s.nz,s.ny,s.nx),bool)
        if 'x0' in faces: m[:,:,0]=1
        if 'x1' in faces: m[:,:,-1]=1
        if 'y0' in faces: m[:,0,:]=1
        if 'y1' in faces: m[:,-1,:]=1
        if 'z0' in faces: m[0,:,:]=1
        if 'z1' in faces: m[-1,:,:]=1
        return m.ravel()
    def xyz(s):
        Z,Y,X=np.meshgrid(s.z,s.y,s.x,indexing='ij'); return X.ravel(),Y.ravel(),Z.ravel()
G8=np.array([(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)],float)
def shape(c): return 0.125*(1+G8[:,0]*c[0])*(1+G8[:,1]*c[1])*(1+G8[:,2]*c[2])
GP2=np.array([-1,1])/np.sqrt(3)
def shape_many(c):
    c=np.atleast_2d(c); return 0.125*(1+G8[None,:,0]*c[:,0,None])*(1+G8[None,:,1]*c[:,1,None])*(1+G8[None,:,2]*c[:,2,None])
def nodal(flux,cs,ce):
    """nodal power vector (8) of events: stationary -> N(csi); moving -> mean over the path (2-point Gauss in the path parameter)"""
    if not len(flux): return np.zeros(8)
    mov=np.abs(ce-cs).max(1)>1e-14
    S=np.where(mov[:,None],0.5*(shape_many(cs+(ce-cs)*(0.5+0.5*GP2[0]))+shape_many(cs+(ce-cs)*(0.5+0.5*GP2[1]))),shape_many(cs))
    return flux@S
class Umd:
    """ctypes host for a compiled UMDFLUX + UMDFLUXSETUP"""
    def __init__(s,srcs,incdir=None,name='lib',defs=None):
        so=os.path.join(OUT,name+'.so'); os.makedirs(OUT,exist_ok=True)
        cmd=['gfortran','-shared','-fPIC','-O1','-ffixed-form','-std=legacy','-I'+LIB,'-I'+CODE]+[os.path.join(CODE,f) for f in srcs]+[LIB+'/stubs.f','-o',so]
        subprocess.run(cmd,check=True); s.lib=C.CDLL(so)
        s.f=s.lib.umdflux_; s.f.argtypes=[C.c_void_p]*28
        s.su=s.lib.umdfluxsetup_; s.su.argtypes=[C.c_void_p]*8+[C.c_size_t]
    def setup(s,lop,kinc,time,dt,cap=500000):
        j=(C.c_int*cap)(); n=C.c_int(0); lp=C.c_int(lop); ks=C.c_int(1); ki=C.c_int(kinc)
        t=(C.c_double*2)(*time); d=(C.c_double*2)(dt,1e30)
        nm=C.create_string_buffer(b'WELDSET'.ljust(80),80)
        s.su(C.byref(lp),nm,j,C.byref(n),C.byref(ks),C.byref(ki),t,d,80)
        return list(j[:n.value]),d[1]
    def call(s,crd,t_total,dt,amp=1.0,noel=1,cap=64,sol=None):
        nn=8; crd=np.ascontiguousarray(crd,dtype=np.float64)
        jf=(C.c_int*2)(1,0); am=C.c_double(amp); ne=C.c_int(noel); nen=C.c_int(nn); iel=(C.c_int*nn)(*range(1,nn+1))
        mcrd=C.c_int(3); un=np.zeros((nn,3)); ks=C.c_int(1); ki=C.c_int(1)
        tm=(C.c_double*2)(t_total,t_total); d2=(C.c_double*2)(dt,1.0); jl=C.c_int(1)
        temp=np.zeros((nn,2)); npd=C.c_int(0); pre=np.zeros(nn*2+2); nsv=C.c_int(1); sv=(C.c_double*2)(0,0)
        so=np.zeros(nn) if sol is None else np.ascontiguousarray(sol,dtype=np.float64); dso=np.zeros(nn)
        nip=C.c_int(8); vol=C.c_double(1.0); vi=(C.c_double*8)(); nh=C.c_int(cap)
        fl=np.zeros(cap); df=np.zeros(cap); cs=np.zeros((cap,3)); ce=np.zeros((cap,3))
        P=lambda a:a.ctypes.data_as(C.c_void_p)
        s.f(jf,C.byref(am),C.byref(ne),C.byref(nen),iel,C.byref(mcrd),P(crd),P(un),C.byref(ks),C.byref(ki),tm,d2,C.byref(jl),P(temp),C.byref(npd),P(pre),C.byref(nsv),sv,P(so),P(dso),C.byref(nip),C.byref(vol),vi,C.byref(nh),P(fl),P(df),P(cs),P(ce))
        n=nh.value; return fl[:n].copy(),cs[:n].copy(),ce[:n].copy(),d2[1]
def step_load(g,umd,t1,dt,active):
    F=np.zeros(g.N); tot=0.0; nev=0
    for lab in active:
        nid,crd=g.cell_nodes_coords(lab)
        fl,cs,ce,_=umd.call(crd,t1,dt)
        if len(fl)==0: continue
        F[nid]+=nodal(fl,cs,ce); tot+=fl.sum(); nev+=len(fl)
    return F,tot,nev
class Stepper:
    """theta = 1: backward Euler; theta = 0.5: Crank-Nicolson.  F is the mean nodal power over the step."""
    def __init__(s,g,dt,fixed,theta=1.0):
        s.g=g; s.dt=dt; s.fx=fixed; s.fr=~fixed; s.th=theta
        A=(g.M/dt+theta*g.K).tocsr(); s.B=(g.M/dt-(1-theta)*g.K).tocsr()
        s.Aff=A[s.fr][:,s.fr].tocsc(); s.Afd=A[s.fr][:,s.fx]; s.lu=sl.splu(s.Aff)
    def advance(s,T,F,Td=None):
        rhs=s.B@T+F
        Tn=T.copy()
        if Td is not None: Tn[s.fx]=Td
        r=rhs[s.fr]-(s.Afd@Tn[s.fx] if s.fx.any() else 0)
        Tn[s.fr]=s.lu.solve(r); return Tn
