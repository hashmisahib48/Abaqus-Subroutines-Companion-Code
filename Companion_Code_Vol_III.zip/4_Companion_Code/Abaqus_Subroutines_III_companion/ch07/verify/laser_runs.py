import sys, json; sys.path.insert(0,'/home/claude/vol3/ch07/verify')
from laser import *
cases=[('gauss',0.25,0.005,0.5),('gauss',0.25,0.005,1.0),('gauss',0.25,0.01,0.5),('gauss',0.25,0.0025,0.5),('gauss',0.5,0.005,0.5),('gauss',0.5,0.01,0.5),
       ('point',0.5,0.005,0.5),('point',1.0,0.005,0.5),('point',0.5,0.01,0.5),('point',0.25,0.005,0.5)]
out=[]
for (m,ell,dt,th) in cases:
    g,T,inf=run(m,ell,dt,th); P_,Tf=probes(g,T); w=WL if m=='gauss' else 0.0
    ex=ref.src_T(np.array([[p[0],p[1],p[2]] for p in P_]),TEND,segs(w),w)
    tot=sum(s[2]*(s[1]-s[0]) for s in segs(w))
    out.append(dict(model=m,ell=ell,dt=dt,theta=th,fe=[float(a) for a in Tf],ex=[float(a) for a in ex],E_in=inf['E_in'],E_ex=tot,nact=[int(min(inf['nact'])),int(max(inf['nact']))],nev=inf['nev'],N=g.N,time=inf['time']))
    json.dump(out,open('/home/claude/vol3/ch07/out/laser_runs.json','w'),indent=1); print(m,ell,dt,th,'done',flush=True)
