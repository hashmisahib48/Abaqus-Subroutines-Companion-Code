import sys, json; sys.path.insert(0,'/home/claude/vol3/ch07/verify')
import laser as L
from laser import *
out={}
pr=(3.0,1.0,1.0); pr2=(3.0,3.0,0.0)
def hist(model,ell,dt,th):
    g=build(ell); import os
    # reuse run() but record history: copy of loop
    wd=os.path.join(OUT,'laser_'+model); os.makedirs(wd,exist_ok=True); os.chdir(wd); g.table('k7_elems.dat')
    with open('k7_events.dat','w') as f:
        for e in EV: f.write('%g %g %g %g\n'%e)
    src='ex7_laser.f' if model=='gauss' else 'ex7_point.f'
    umd=Umd([src,'ex7_lsetup.f','k7_util.f'],name='laser_'+model); umd.setup(1,1,(0,0),dt)
    X,Y,Z=g.xyz(); fixed=g.bnodes(['x0','x1','y0','y1','z1']); st=Stepper(g,dt,fixed,th); T=np.zeros(g.N)
    w=WL if model=='gauss' else 0.0; sg=segs(w); pts=np.c_[X[fixed],Y[fixed],Z[fixed]]
    ids=[g.nid(int(np.argmin(abs(g.x-p[0]))),int(np.argmin(abs(g.y-p[1]))),int(np.argmin(abs(g.z-p[2])))) for p in (pr,pr2)]
    H=[[0.0,0.0,0.0]]
    for n in range(1,int(round(TEND/dt))+1):
        t1=n*dt; act,_=umd.setup(2,n,(t1,t1),dt); F,tot,ne=step_load(g,umd,t1,dt,act)
        T=st.advance(T,F,ref.src_T(pts,t1,sg,w)); H.append([t1,T[ids[0]],T[ids[1]]])
    return np.array(H).tolist()
tt=np.linspace(0.0005,TEND,140)
out['ex_g']=[[float(t)]+[float(ref.src_T(np.array([list(p)]),t,segs(WL),WL)[0]) for p in (pr,pr2)] for t in tt]
out['gauss_cn']=hist('gauss',0.25,0.005,0.5); out['gauss_be']=hist('gauss',0.25,0.005,1.0); out['point']=hist('point',0.25,0.005,0.5)
json.dump(out,open('/home/claude/vol3/ch07/out/laser_hist.json','w')); print('done')
