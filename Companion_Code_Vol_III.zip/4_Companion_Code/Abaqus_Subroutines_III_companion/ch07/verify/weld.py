import sys, os, time, json, numpy as np
sys.path.insert(0,'/home/claude/vol3/ch07/verify')
from fe3d import *; import ref
Q=1.5e6; V=6.0; TEND=8.0
def run(dt,ell=1.0,bc='dirichlet',theta=1.0):
    x=graded(-4,62,ell,-50,112); y=graded(0,12,ell,0,50); z=graded(0,12,ell,0,50)
    g=Grid(x,y,z,zsign=-1.0)
    wd=os.path.join(OUT,'weld'); os.makedirs(wd,exist_ok=True); os.chdir(wd)
    g.table('k7_elems.dat')
    umd=Umd(['ex7_goldak.f','k7_util.f','ex7_setup.f'],name='weld')
    umd.setup(1,1,(0,0),dt)
    X,Y,Z=g.xyz()
    fixed=g.bnodes(['x0','x1','y1','z1']) if bc=='dirichlet' else np.zeros(g.N,bool)
    st=Stepper(g,dt,fixed,theta); T=np.zeros(g.N); nst=int(round(TEND/dt)); E_in=0.0; nev_tot=0; nact=[]
    pts=np.c_[X[fixed],Y[fixed],Z[fixed]]
    t0=time.time()
    for n in range(1,nst+1):
        t1=n*dt
        act,ds=umd.setup(2,n,(t1,t1),dt)
        F,tot,nev=step_load(g,umd,t1,dt,act); E_in+=tot*dt; nact.append(len(act)); nev_tot+=nev
        Td=ref.src_T(pts,t1,[(0,t1,Q,0,0,V*t1,0)]) if fixed.any() else None
        T=st.advance(T,F,Td)
    stored=float(T@(g.M@np.ones(g.N))) if False else float(np.ones(g.N)@(g.M@T))
    return g,T,dict(E_in=E_in,stored=stored,nact=nact,nev=nev_tot,time=time.time()-t0)
def probe(g,T,xs):
    pts=[(-20,0,0),(-40,0,0),(0,12,0),(-20,12,0),(-20,0,12),(0,0,12)]
    res=[]
    for (a,b,c) in pts:
        i=np.argmin(abs(g.x-(xs+a))); j=np.argmin(abs(g.y-b)); k=np.argmin(abs(g.z-c))
        assert abs(g.x[i]-(xs+a))<1e-9 and abs(g.y[j]-b)<1e-9 and abs(g.z[k]-c)<1e-9
        res.append(T[g.nid(i,j,k)])
    return pts,np.array(res)
if __name__=='__main__':
    dt=float(sys.argv[1]) if len(sys.argv)>1 else 0.125
    g,T,inf=run(dt)
    print('nodes',g.N,'time',inf['time'],'active elems first/last',inf['nact'][0],inf['nact'][-1],'max',max(inf['nact']))
    print('E_in',inf['E_in'],'expected',Q/2*TEND,'ratio',inf['E_in']/(Q/2*TEND))
    xs=V*TEND; pts,Tf=probe(g,T,xs)
    segs=[(0,TEND,Q,0,0,xs,0)]
    for p,tf in zip(pts,Tf):
        tr=ref.src_T(np.array([[xs+p[0],p[1],p[2]]]),TEND,segs)[0]; ro=ref.ros(p[0],p[1],p[2],Q,V)
        print(p,round(tf,2),round(tr,2),round(ro,2),'FE/transient',round(tf/tr,4),'FE/Rosenthal',round(tf/ro,4))
