import sys, json; sys.path.insert(0,'/home/claude/vol3/ch07/verify')
from weld import *
out={}
xs=V*TEND; segs=[(0,TEND,Q,0,0,xs,0)]
cases=[(0.25,1.0),(0.125,1.0),(0.0625,1.0),(0.25,0.5),(0.125,0.5),(0.0625,0.5),(0.03125,1.0)]
for dt,th in cases:
    g,T,inf=run(dt,theta=th); pts,Tf=probe(g,T,xs)
    P=np.array([[xs+p[0],p[1],p[2]] for p in pts])
    gt=ref.gold_T(P,TEND,Q,V,4.0,3.0,3.0,9.0); pt=ref.src_T(P,TEND,segs); ro=[float(ref.ros(p[0],p[1],p[2],Q,V)) for p in pts]
    prof=[float(T[g.nid(i,0,0)]) for i in range(g.nx)]
    out['%g_%g'%(dt,th)]=dict(dt=dt,theta=th,pts=pts,fe=[float(a) for a in Tf],gold=[float(a) for a in gt],pt=[float(a) for a in pt],ros=ro,E_in=inf['E_in'],nact=[inf['nact'][0],max(inf['nact'])],nev=inf['nev'],time=inf['time'],N=g.N,ncell=int(g.cx*g.cy*g.cz),x=[float(v) for v in g.x],prof=prof)
    json.dump(out,open('/home/claude/vol3/ch07/out/weld_runs.json','w'),indent=1)
    print(dt,th,'done',inf['time'],flush=True)
g,T,inf=run(0.25,bc='none',theta=0.5)
out['insulated']=dict(E_in=inf['E_in'],stored=inf['stored'],expected=Q/2*TEND)
json.dump(out,open('/home/claude/vol3/ch07/out/weld_runs.json','w'),indent=1); print('insulated done',inf['E_in'],inf['stored'],flush=True)
