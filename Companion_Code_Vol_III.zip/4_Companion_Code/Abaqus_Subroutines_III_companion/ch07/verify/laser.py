import sys, os, time, json, numpy as np
sys.path.insert(0,'/home/claude/vol3/ch07/verify')
from fe3d import *; import ref
P=2.0e5; ETA=0.35; WL=0.25
EV=[(0.00,1.0,1.0,P),(0.04,5.0,1.0,0.0),(0.05,5.0,1.5,P),(0.09,1.0,1.5,0.0),(0.10,1.0,2.0,P),(0.14,5.0,2.0,0.0)]
TEND=0.14
def segs(w):
    return [(EV[k][0],EV[k+1][0],ETA*EV[k][3],EV[k][1],EV[k][2],EV[k+1][1],EV[k+1][2]) for k in range(len(EV)-1)]
def build(ell):
    x=graded(0,6,ell,-6,12); y=graded(0,3,ell,-6,9); z=graded(0,1.5,ell,0,8)
    return Grid(x,y,z,zsign=-1.0)
def run(model,ell,dt,theta=0.5,bc=True):
    """model 'gauss' (ex7_laser.f, w = 0.25 mm) or 'point' (ex7_point.f)"""
    g=build(ell); wd=os.path.join(OUT,'laser_'+model); os.makedirs(wd,exist_ok=True); os.chdir(wd)
    g.table('k7_elems.dat')
    with open('k7_events.dat','w') as f:
        for e in EV: f.write('%g %g %g %g\n'%e)
    src='ex7_laser.f' if model=='gauss' else 'ex7_point.f'
    umd=Umd([src,'ex7_lsetup.f','k7_util.f'],name='laser_'+model)
    umd.setup(1,1,(0,0),dt)
    X,Y,Z=g.xyz(); fixed=g.bnodes(['x0','x1','y0','y1','z1']) if bc else np.zeros(g.N,bool)
    st=Stepper(g,dt,fixed,theta); T=np.zeros(g.N); nst=int(round(TEND/dt+1e-9)); E_in=0.0; nev=0; nact=[]
    pts=np.c_[X[fixed],Y[fixed],-Z[fixed]*-1] if False else np.c_[X[fixed],Y[fixed],Z[fixed]]
    w=WL if model=='gauss' else 0.0
    Tb_old=ref.src_T(pts,0.0+1e-30,segs(w),w) if False else np.zeros(fixed.sum())
    t0=time.time(); sg=segs(w)
    for n in range(1,nst+1):
        t1=n*dt; act,_=umd.setup(2,n,(t1,t1),dt)
        F,tot,ne=step_load(g,umd,t1,dt,act); E_in+=tot*dt; nev+=ne; nact.append(len(act))
        Td=ref.src_T(pts,t1,sg,w) if fixed.any() else None
        T=st.advance(T,F,Td)
    return g,T,dict(E_in=E_in,nact=nact,nev=nev,time=time.time()-t0)
def probes(g,T):
    P_=[(3.0,3.0,0.0),(3.0,0.0,0.0),(3.0,1.0,1.0),(3.0,2.0,1.0),(6.0,1.0,0.0)]
    r=[]
    for (a,b,c) in P_:
        i=np.argmin(abs(g.x-a)); j=np.argmin(abs(g.y-b)); k=np.argmin(abs(g.z-c))
        assert abs(g.x[i]-a)<1e-9 and abs(g.y[j]-b)<1e-9 and abs(g.z[k]-c)<1e-9,(a,b,c)
        r.append(T[g.nid(i,j,k)])
    return P_,np.array(r)
if __name__=='__main__':
    model=sys.argv[1]; ell=float(sys.argv[2]); dt=float(sys.argv[3]); th=float(sys.argv[4]) if len(sys.argv)>4 else 0.5
    g,T,inf=run(model,ell,dt,th); P_,Tf=probes(g,T)
    w=WL if model=='gauss' else 0.0
    print('nodes',g.N,'time %.1f'%inf['time'],'active',min(inf['nact']),max(inf['nact']))
    tot=sum(s[2]*(s[1]-s[0]) for s in segs(w))
    print('E_in',inf['E_in'],'eta*P*t_on',tot,'ratio',inf['E_in']/tot)
    for p,tf in zip(P_,Tf):
        tr=ref.src_T(np.array([[p[0],p[1],p[2]]]),TEND,segs(w),w)[0]
        print(p,round(tf,3),round(tr,3),round(tf/tr-1,4))
