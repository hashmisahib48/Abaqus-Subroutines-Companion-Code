import sys, json; sys.path.insert(0,'/home/claude/vol3/ch07/verify')
from weld import *
out={}
xs=V*TEND
for dt,th in [(0.125,1.0),(0.125,0.5)]:
    g,T,inf=run(dt,theta=th)
    j=0;k=0; xa=g.x; Ta=np.array([T[g.nid(i,0,0)] for i in range(g.nx)])
    out['%g_%g'%(dt,th)]=dict(x=[float(v) for v in xa],T=[float(v) for v in Ta])
json.dump(out,open('/home/claude/vol3/ch07/out/weld_prof.json','w'))
print('prof done')
