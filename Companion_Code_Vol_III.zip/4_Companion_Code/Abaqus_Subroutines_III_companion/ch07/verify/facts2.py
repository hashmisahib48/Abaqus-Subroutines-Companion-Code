import numpy as np, sys; sys.path.insert(0,'.')
from scipy import stats
from ref import *
# 7A.1
a,b,cf,cr,Q=5.,4.,2.,10.,1.8e6
ff=2*cf/(cf+cr); fr=2*cr/(cf+cr); q0=6*np.sqrt(3)*(2/(cf+cr))*Q/(a*b*np.pi*np.sqrt(np.pi))
print('7A.1 ff fr',ff,fr,'q0 mW/mm3',q0,'front/rear fractions',ff/2,fr/2,'centroid',(cf-cr)/np.sqrt(3*np.pi))
# peak at depth b below? value at (xi=0,y=a,z=0): fraction of peak exp(-3)
print(' q at y=a:',q0*np.exp(-3))
# 7A.2
Q2=2.5e6; v=8.0
for (xi,y,z) in [(-30,0,0),(0,10,0),(-30,10,0),(10,0,0)]:
    print('7A.2',(xi,y,z),ros(xi,y,z,Q2,v))
print(' R for 100K on axis behind:',Q2/(2*np.pi*45*100))
# 7B.3
for E in [10,20,30]: print('7B.3 exponent',E,'chi2 sf',stats.chi2.sf(2*E,3))
# 7C.2
bx=[(0.3,1.3),(-0.2,0.8),(-0.5,0.0)]
tot=0
for ex in [(0,1),(1,2)]:
    for ey in [(0,1),(-1,0)]:
        ox=max(0,min(bx[0][1],ex[1])-max(bx[0][0],ex[0])); oy=max(0,min(bx[1][1],ey[1])-max(bx[1][0],ey[0])); f=ox*oy
        print('7C.2 elem',ex,ey,f,1e5*f); tot+=f
print(tot)
# 7A.3
for (xa,xb) in [(1.0,2.0),(2.0,3.0),(3.0,4.0)]:
    lo=max(1.2,xa);hi=min(3.7,xb); frac=(hi-lo)/2.5; print('7A.3',xa,xb,frac,7e4*frac,2*(lo-xa)-1,2*(hi-xa)-1)
