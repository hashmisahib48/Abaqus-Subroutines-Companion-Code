"""Closed-form references: moving point source on an insulated half-space (units mm, s, mW, mJ, K)."""
import numpy as np
from scipy.integrate import quad
K_=45.0; RHOC=3.611; AL=K_/RHOC
def ros(xi,y,z,Q,v,k=K_,al=AL):
    R=np.sqrt(xi**2+y**2+z**2)
    return Q/(2*np.pi*k*R)*np.exp(-v*(xi+R)/(2*al))
def pt_transient(x,y,z,t,path,al=AL,rhoc=RHOC):
    """T-T0 at (x,y,z) at time t for a point source on the surface z=0 of an insulated half-space.
    path = list of (t0,t1,P,x0,y0,x1,y1): straight segment with constant power P (mW) and speed; superposition by quadrature."""
    tot=0.0
    for (t0,t1,P,xa,ya,xb,yb) in path:
        if P==0 or t0>=t: continue
        te=min(t1,t)
        def f(tau):
            s=t-tau; u=(tau-t0)/(t1-t0)
            xs=xa+u*(xb-xa); ys=ya+u*(yb-ya)
            R2=(x-xs)**2+(y-ys)**2+z**2
            return P*2/(rhoc*(4*np.pi*al*s)**1.5)*np.exp(-R2/(4*al*s))
        v,_=quad(f,t0,te,limit=400,epsabs=1e-12,epsrel=1e-10)
        tot+=v
    return tot
if __name__=='__main__':
    Q=1.5e6; v=5.0
    for tt in [10,20,30,40,60]:
        path=[(0,tt,Q,0,0,v*tt,0)]
        xs=v*tt
        for (dx,y,z) in [(-20,0,0),(-10,0,0),(0,10,0),(-20,10,0),(-10,0,10)]:
            T=pt_transient(xs+dx,y,z,tt,path); R=ros(dx,y,z,Q,v)
            print(tt,(dx,y,z),round(T,2),round(R,2),round(T/R,4))

_GL=np.polynomial.legendre.leggauss(160)
def src_T(pts,t,segs,w=0.0,al=AL,rhoc=RHOC):
    """Vectorised T-T0 at pts (n,3: x,y,z with z = depth >= 0) at time t, surface source (Gaussian of 1/e^2 radius w, or point if w=0)
    on an insulated half-space, along straight segments segs = [(t0,t1,P,xa,ya,xb,yb)], P in mW (absorbed).  Exact; Gauss-Legendre in u=sqrt(t-tau)."""
    pts=np.atleast_2d(pts); out=np.zeros(len(pts)); sig2=w*w/4.0
    for (t0,t1,P,xa,ya,xb,yb) in segs:
        if P==0 or t0>=t: continue
        te=min(t1,t); ulo=np.sqrt(t-te); uhi=np.sqrt(t-t0)
        u=0.5*(uhi-ulo)*_GL[0]+0.5*(uhi+ulo); wu=0.5*(uhi-ulo)*_GL[1]
        tau=t-u**2; f=(tau-t0)/(t1-t0)
        xs=xa+f*(xb-xa); ys=ya+f*(yb-ya)
        r2=(pts[:,0,None]-xs[None])**2+(pts[:,1,None]-ys[None])**2; z2=pts[:,2,None]**2
        v2=2*al*u**2+sig2
        # (4 pi al u^2)^(-1/2) exp(-z^2/(4 al u^2)) / (2 pi v2) exp(-r2/(2 v2)) * 2u du  *  2P/rhoc
        integ=(4*np.pi*al)**-0.5/u*np.exp(-z2/(4*al*u**2))/(2*np.pi*v2)*np.exp(-r2/(2*v2))*2*u
        out+=2*P/rhoc*(integ*wu).sum(1)
    return out

from scipy.special import erfc
_GL2=np.polynomial.legendre.leggauss(240)
def gold_T(pts,t,Q,v,a,b,cf,cr,x0=0.0,al=AL,rhoc=RHOC):
    """Exact T-T0 for the Goldak double ellipsoid (Eq. 7.2-1) moving at speed v along +x from x0 at time 0, on an insulated half-space
    (depth z>=0).  The Gaussian factors are convolved analytically with the heat kernel; the front/rear halves give erfc terms.
    pts (n,3): x,y,z(depth) ; Q = absorbed power (mW)."""
    pts=np.atleast_2d(pts); kap=2.0/(cf+cr); K=6*np.sqrt(3)*Q*kap/(a*b*np.pi*np.sqrt(np.pi))
    tau=0.5*t*_GL2[0]+0.5*t; wt=0.5*t*_GL2[1]; s=(t-tau)[None,:]
    xr=pts[:,0,None]-(x0+v*tau[None,:]); y=pts[:,1,None]; z=pts[:,2,None]
    def conv_half(c,sign):
        a_=3.0/c**2; b_=1.0/(4*al*s); ab=a_+b_; xi0=b_*xr/ab
        # int over xi>0 (sign=+1) or xi<0 (sign=-1) of exp(-a xi^2) (4 pi al s)^-1/2 exp(-b (xr-xi)^2) d xi
        pref=np.sqrt(np.pi/ab)/np.sqrt(4*np.pi*al*s)*np.exp(-a_*b_*xr**2/ab)
        return pref*0.5*erfc(-sign*np.sqrt(ab)*xi0)
    Cx=conv_half(cf,+1)+conv_half(cr,-1)
    gy=lambda c,w:(1+4*al*s*3/c**2)**-0.5*np.exp(-(3/c**2)*w**2/(1+4*al*s*3/c**2))
    integ=Cx*gy(a,y)*gy(b,z)
    return K/rhoc*(integ*wt[None,:]).sum(1)
