import numpy as np, sys; sys.path.insert(0,'.')
from scipy import integrate, stats
from ref import *
def gq(dx,y,z,Q,a,b,cf,cr):
    c=cf if dx>=0 else cr; f=2*c/(cf+cr)
    return 6*np.sqrt(3)*f*Q/(a*b*c*np.pi*np.sqrt(np.pi))*np.exp(-3*((dx/c)**2+(y/a)**2+(z/b)**2))
Q=1.5e6;a,b,cf,cr=4.,3.,3.,9.
ff=2*cf/(cf+cr); fr=2*cr/(cf+cr)
print('ff,fr',ff,fr,'peak front',gq(0,0,0,Q,a,b,cf,cr),'rear side at 0-',gq(-1e-12,0,0,Q,a,b,cf,cr))
# energy integral via Gauss-Legendre product on half space (z>=0), tails to 6 sigma
def gl(n,lo,hi):
    x,w=np.polynomial.legendre.leggauss(n); return 0.5*(hi-lo)*x+0.5*(hi+lo),0.5*(hi-lo)*w
def integ(Q,a,b,cf,cr,n=120,full=False):
    tot=0
    for lo,hi,c in [(0,10*cf,cf),(-10*cr,0,cr)]:
        xs,wx=gl(n,lo,hi)
        ys,wy=gl(n,-10*a,10*a); zs,wz=gl(n,-10*b if full else 0,10*b)
        X,Y,Z=np.meshgrid(xs,ys,zs,indexing='ij'); W=wx[:,None,None]*wy[None,:,None]*wz[None,None,:]
        f=np.vectorize(lambda x,y,z:gq(x,y,z,Q,a,b,cf,cr))
        c_=np.where(X>=0,cf,cr); F=2*c_/(cf+cr)
        q=6*np.sqrt(3)*F*Q/(a*b*c_*np.pi*np.sqrt(np.pi))*np.exp(-3*((X/c_)**2+(Y/a)**2+(Z/b)**2))
        tot+=(q*W).sum()
    return tot
print('half space integral / Q',integ(Q,a,b,cf,cr)/Q,' full space / Q',integ(Q,a,b,cf,cr,full=True)/Q)
# front/rear power split in half space
def split(n=100):
    r=[]
    for lo,hi,c in [(0,10*cf,cf),(-10*cr,0,cr)]:
        xs,wx=gl(n,lo,hi); ys,wy=gl(n,-10*a,10*a); zs,wz=gl(n,0,10*b)
        X,Y,Z=np.meshgrid(xs,ys,zs,indexing='ij'); W=wx[:,None,None]*wy[None,:,None]*wz[None,None,:]
        c_=c; F=2*c_/(cf+cr)
        q=6*np.sqrt(3)*F*Q/(a*b*c_*np.pi*np.sqrt(np.pi))*np.exp(-3*((X/c_)**2+(Y/a)**2+(Z/b)**2)); r.append((q*W).sum()/Q)
    return r
print('front,rear fractions',split())
print('chi2 sf(40,3)',stats.chi2.sf(40,3), 'exp(-20)',np.exp(-20))
# fraction of power with |y|<a, depth< b
print('frac inside |y|<a', 1-2*stats.norm.sf(a/ (a/np.sqrt(6))),'(erf)')
# Rosenthal numbers
k=45.;al=AL
print('alpha',al,'k/rhoc',45/3.611)
print('Rosenthal (-20,0,0)',ros(-20,0,0,Q,6.0),'(-40,0,0)',ros(-40,0,0,Q,6.))
