      PROGRAM DRVGLD
!     Calls UMDFLUX (ex7_goldak.f) for every element of a brick mesh of
!     size ELL and sums the powers of all events: the resultant of
!     Eq. (7.2-1).  Usage: drv_goldak ELL OFFSET (OFFSET = shift of the
!     mesh in units of ELL in x and y).
      INCLUDE 'ABA_PARAM.INC'
      INCLUDE 'K7_WELD.INC'
      PARAMETER (NMAX = 64)
      DIMENSION JFLAGS(2), IEL(8), CRD(3,8), UN(3,8), TIME(2), DT(2)
      DIMENSION TEMP(2,8), PREDEF(2,1,8), SVARS(1,2), SOL(8), DSOL(8)
      DIMENSION VOLINT(8), FLUX(NMAX), DFDT(NMAX)
      DIMENSION CS(3,NMAX), CE(3,NMAX)
      CHARACTER*32 ARG
      CALL GETARG(1,ARG)
      READ(ARG,*) ELL
      CALL GETARG(2,ARG)
      READ(ARG,*) OFF
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      DT(1) = 0.0D0
      DT(2) = 1.0D0
      TOT = 0.0D0
      VTOT = 0.0D0
      NX = INT(30.0D0/ELL)
      NY = INT(20.0D0/ELL)
      NZ = INT(20.0D0/ELL)
      DO 30 K = -NZ, -1
      DO 30 J = -NY, NY
      DO 30 I = -NX, NX
         X0 = (I + OFF)*ELL
         Y0 = (J + OFF)*ELL
         Z0 = K*ELL
         CALL BRICK(X0,Y0,Z0,ELL,CRD)
         NEV = NMAX
         CALL UMDFLUX(JFLAGS,1.0D0,1,8,IEL,3,CRD,UN,1,1,TIME,DT,1,TEMP,
     1      0,PREDEF,1,SVARS,SOL,DSOL,8,ELL**3,VOLINT,NEV,FLUX,DFDT,
     2      CS,CE)
         DO 20 N = 1, NEV
            TOT = TOT + FLUX(N)
   20    CONTINUE
   30 CONTINUE
      WRITE(*,'(A,F8.3,A,F6.3,A,ES14.6)') 'ell', ELL, '  offset', OFF,
     1   '  Q/Q0 - 1 =', TOT/QABS - 1.0D0
      END
!
      SUBROUTINE BRICK(X0,Y0,Z0,H,CRD)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION CRD(3,8), SG(8), TG(8), UG(8)
      DATA SG /0.D0,1.D0,1.D0,0.D0,0.D0,1.D0,1.D0,0.D0/
      DATA TG /0.D0,0.D0,1.D0,1.D0,0.D0,0.D0,1.D0,1.D0/
      DATA UG /0.D0,0.D0,0.D0,0.D0,1.D0,1.D0,1.D0,1.D0/
      DO 10 N = 1, 8
         CRD(1,N) = X0 + H*SG(N)
         CRD(2,N) = Y0 + H*TG(N)
         CRD(3,N) = Z0 + H*UG(N)
   10 CONTINUE
      RETURN
      END
