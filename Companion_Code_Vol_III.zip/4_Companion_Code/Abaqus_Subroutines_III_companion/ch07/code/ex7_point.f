      SUBROUTINE UMDFLUX(JFLAGS,AMPLITUDE,NOEL,NELEMNODES,IELEMNODES,
     1 MCRD,COORDNODES,UNODES,KSTEP,KINC,TIME,DT,JLTYP,TEMP,NPREDEF,
     2 PREDEF,NSVARS,SVARS,SOL,DSOL,NINTP,VOLELM,VOLINT,NHEATEVENTS,
     3 FLUX,DFLUXDT,CSISTART,CSIEND)
!
      INCLUDE 'ABA_PARAM.INC'
      INCLUDE 'K7_LASER.INC'
!
      DIMENSION JFLAGS(*), IELEMNODES(NELEMNODES)
      DIMENSION COORDNODES(MCRD,NELEMNODES), UNODES(MCRD,NELEMNODES)
      DIMENSION TIME(2), DT(2), TEMP(2,NELEMNODES)
      DIMENSION PREDEF(2,NPREDEF,NELEMNODES), SVARS(NSVARS,2)
      DIMENSION SOL(NELEMNODES), DSOL(NELEMNODES), VOLINT(NINTP)
      DIMENSION FLUX(NHEATEVENTS), DFLUXDT(NHEATEVENTS)
      DIMENSION CSISTART(3,NHEATEVENTS), CSIEND(3,NHEATEVENTS)
      DIMENSION XLO(3), XHI(3), PA(2), PB(2)
!     Concentrated laser: the part of every straight piece of the
!     toolpath that lies inside this brick is one moving event.  The
!     power is averaged over the increment: flux = eta*P*(time inside)
!     /DT(1).  Pieces on a shared face are given to the upper element.
      NCAP = NHEATEVENTS
      NHEATEVENTS = 0
      IF (NELEMNODES .NE. 8 .OR. MCRD .NE. 3) RETURN
      DO 5 K = 1, 3
         XLO(K) = MINVAL(COORDNODES(K,1:8))
         XHI(K) = MAXVAL(COORDNODES(K,1:8))
    5 CONTINUE
      IF (XHI(3) .LT. ZTOP - 1.0D-9 .OR. XLO(3) .GT. ZTOP) RETURN
      T1 = TIME(2)
      T0 = T1 - DT(1)
      N = 0
      DO 50 K = 1, NEVS - 1
         IF (EVP(K) .LE. 0.0D0) GOTO 50
         TA = MAX(T0, EVT(K))
         TB = MIN(T1, EVT(K+1))
         IF (TB .LE. TA) GOTO 50
         FA = (TA - EVT(K))/(EVT(K+1) - EVT(K))
         FB = (TB - EVT(K))/(EVT(K+1) - EVT(K))
         PA(1) = EVX(K) + FA*(EVX(K+1) - EVX(K))
         PA(2) = EVY(K) + FA*(EVY(K+1) - EVY(K))
         PB(1) = EVX(K) + FB*(EVX(K+1) - EVX(K))
         PB(2) = EVY(K) + FB*(EVY(K+1) - EVY(K))
         U0 = 0.0D0
         U1 = 1.0D0
         DO 20 L = 1, 2
            D = PB(L) - PA(L)
            IF (ABS(D) .LT. 1.0D-14) THEN
               IF (PA(L) .LT. XLO(L) .OR. PA(L) .GE. XHI(L)) GOTO 50
            ELSE
               UA = (XLO(L) - PA(L))/D
               UB = (XHI(L) - PA(L))/D
               U0 = MAX(U0, MIN(UA,UB))
               U1 = MIN(U1, MAX(UA,UB))
            ENDIF
   20    CONTINUE
         IF (U1 .LE. U0) GOTO 50
         N = N + 1
         IF (N .GT. NCAP) CALL XIT
         FLUX(N) = AMPLITUDE*ETA*EVP(K)*(U1 - U0)*(TB - TA)/DT(1)
         DFLUXDT(N) = 0.0D0
         DO 30 L = 1, 2
            CSISTART(L,N) = 2.0D0*(PA(L) + U0*(PB(L) - PA(L))
     1         - XLO(L))/(XHI(L) - XLO(L)) - 1.0D0
            CSIEND(L,N) = 2.0D0*(PA(L) + U1*(PB(L) - PA(L))
     1         - XLO(L))/(XHI(L) - XLO(L)) - 1.0D0
   30    CONTINUE
         CSISTART(3,N) = 1.0D0
         CSIEND(3,N) = 1.0D0
   50 CONTINUE
      NHEATEVENTS = N
      RETURN
      END
