      SUBROUTINE UMDFLUX(JFLAGS,AMPLITUDE,NOEL,NELEMNODES,IELEMNODES,
     1 MCRD,COORDNODES,UNODES,KSTEP,KINC,TIME,DT,JLTYP,TEMP,NPREDEF,
     2 PREDEF,NSVARS,SVARS,SOL,DSOL,NINTP,VOLELM,VOLINT,NHEATEVENTS,
     3 FLUX,DFLUXDT,CSISTART,CSIEND)
!
      INCLUDE 'ABA_PARAM.INC'
      INCLUDE 'K7_WELD.INC'
!
      DIMENSION JFLAGS(*), IELEMNODES(NELEMNODES)
      DIMENSION COORDNODES(MCRD,NELEMNODES), UNODES(MCRD,NELEMNODES)
      DIMENSION TIME(2), DT(2), TEMP(2,NELEMNODES)
      DIMENSION PREDEF(2,NPREDEF,NELEMNODES), SVARS(NSVARS,2)
      DIMENSION SOL(NELEMNODES), DSOL(NELEMNODES), VOLINT(NINTP)
      DIMENSION FLUX(NHEATEVENTS), DFLUXDT(NHEATEVENTS)
      DIMENSION CSISTART(3,NHEATEVENTS), CSIEND(3,NHEATEVENTS)
      DIMENSION GX(NG), GW(NG), XN(8), DN(8,3), XJ(3,3), XLO(3), XHI(3)
      DOUBLE PRECISION K7_QG
!     Goldak source of Eq. (7.2-1): the element is sampled at NG**3
!     Gauss points; each point is a stationary event of power q*dV.
      NCAP = NHEATEVENTS
      NHEATEVENTS = 0
      IF (NELEMNODES .NE. 8 .OR. MCRD .NE. 3) RETURN
      XS = X0W + VW*(TIME(2) - 0.5D0*DT(1))
!     skip the element if even its nearest point lies where the
!     exponent of Eq. (7.2-1) is below -20
      DO 10 K = 1, 3
         XLO(K) = MINVAL(COORDNODES(K,1:8))
         XHI(K) = MAXVAL(COORDNODES(K,1:8))
   10 CONTINUE
      DX = MAX(XLO(1) - XS, 0.0D0, XS - XHI(1))
      IF (XS .LT. XLO(1)) THEN
         DX = DX/CFG
      ELSE
         DX = DX/CRG
      ENDIF
      DY = MAX(XLO(2), 0.0D0, -XHI(2))/AG
      DZ = MAX(-XHI(3), 0.0D0)/BG
      IF (3.0D0*(DX**2 + DY**2 + DZ**2) .GT. 20.0D0) RETURN
      IF (NG**3 .GT. NCAP) CALL XIT
      CALL K7_GAUSS(NG,GX,GW)
      N = 0
      DO 40 KK = 1, NG
      DO 40 JJ = 1, NG
      DO 40 II = 1, NG
         CALL K7_HEX8(GX(II),GX(JJ),GX(KK),XN,DN)
         DO 30 K = 1, 3
         DO 30 L = 1, 3
            XJ(K,L) = DOT_PRODUCT(DN(1:8,L),COORDNODES(K,1:8))
   30    CONTINUE
         DETJ = XJ(1,1)*(XJ(2,2)*XJ(3,3) - XJ(2,3)*XJ(3,2))
     1        - XJ(1,2)*(XJ(2,1)*XJ(3,3) - XJ(2,3)*XJ(3,1))
     2        + XJ(1,3)*(XJ(2,1)*XJ(3,2) - XJ(2,2)*XJ(3,1))
         XP = DOT_PRODUCT(XN,COORDNODES(1,1:8))
         YP = DOT_PRODUCT(XN,COORDNODES(2,1:8))
         ZP = DOT_PRODUCT(XN,COORDNODES(3,1:8))
         N = N + 1
         QV = K7_QG(XP - XS, YP, -ZP, QABS, AG, BG, CFG, CRG)
         FLUX(N) = AMPLITUDE*QV*GW(II)*GW(JJ)*GW(KK)*DETJ
         DFLUXDT(N) = 0.0D0
         CSISTART(1,N) = GX(II)
         CSISTART(2,N) = GX(JJ)
         CSISTART(3,N) = GX(KK)
         CSIEND(1:3,N) = CSISTART(1:3,N)
   40 CONTINUE
      NHEATEVENTS = N
      RETURN
      END
