      PROGRAM DRVLAS
!     Energy of the laser routines on the toolpath alone: UMDFLUXSETUP
!     (ex7_lsetup.f) selects the elements, UMDFLUX (ex7_laser.f or
!     ex7_point.f) is called for each, and the powers are summed over
!     all increments.  Needs k7_elems.dat and k7_events.dat in ./
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXEL = 400000, NMAX = 64)
      DIMENSION JACT(MAXEL), TIME(2), DT(2), CRD(3,8), UN(3,8)
      DIMENSION JFLAGS(2), IEL(8), TEMP(2,8), PREDEF(2,1,8)
      DIMENSION SVARS(1,2), SOL(8), DSOL(8), VOLINT(8)
      DIMENSION FLUX(NMAX), DFDT(NMAX), CS(3,NMAX), CE(3,NMAX)
      DIMENSION SG(8), TG(8), UG(8)
      CHARACTER*80 SNAME
      COMMON /K7ELM/ BOX(6,MAXEL), LABEL(MAXEL), NEL
      DATA SG /0.D0,1.D0,1.D0,0.D0,0.D0,1.D0,1.D0,0.D0/
      DATA TG /0.D0,0.D0,1.D0,1.D0,0.D0,0.D0,1.D0,1.D0/
      DATA UG /0.D0,0.D0,0.D0,0.D0,1.D0,1.D0,1.D0,1.D0/
      SNAME = 'WELDSET'
      DT(1) = 0.005D0
      DT(2) = 1.0D0
      CALL UMDFLUXSETUP(1,SNAME,JACT,NACT,1,0,TIME,DT)
      ETOT = 0.0D0
      DO 30 KINC = 1, 28
         TIME(2) = KINC*DT(1)
         TIME(1) = TIME(2)
         CALL UMDFLUXSETUP(2,SNAME,JACT,NACT,1,KINC,TIME,DT)
         DO 20 K = 1, NACT
            N = JACT(K)
            DO 10 L = 1, 8
               CRD(1,L) = BOX(1,N) + (BOX(2,N) - BOX(1,N))*SG(L)
               CRD(2,L) = BOX(3,N) + (BOX(4,N) - BOX(3,N))*TG(L)
               CRD(3,L) = BOX(5,N) + (BOX(6,N) - BOX(5,N))*UG(L)
   10       CONTINUE
            NEV = NMAX
            CALL UMDFLUX(JFLAGS,1.0D0,N,8,IEL,3,CRD,UN,1,KINC,TIME,DT,
     1         1,TEMP,0,PREDEF,1,SVARS,SOL,DSOL,8,1.0D0,VOLINT,NEV,
     2         FLUX,DFDT,CS,CE)
            DO 15 L = 1, NEV
               ETOT = ETOT + FLUX(L)*DT(1)
   15       CONTINUE
   20    CONTINUE
   30 CONTINUE
      WRITE(*,'(A,F12.4)') 'energy delivered, mJ (exact 8400): ',
     1   ETOT
      END
