      DOUBLE PRECISION FUNCTION K7_INTQ(GX,GY,T0,T1)
!     Time integral over (T0,T1) of the Gaussian surface flux at the
!     point (GX,GY), Eq. (7.8-1), for the event-series toolpath; mJ/mm^2
      INCLUDE 'ABA_PARAM.INC'
      INCLUDE 'K7_LASER.INC'
      PARAMETER (PI = 3.14159265358979D0)
      K7_INTQ = 0.0D0
      DO 10 K = 1, NEVS - 1
         IF (EVP(K) .LE. 0.0D0) GOTO 10
         TA = MAX(T0, EVT(K))
         TB = MIN(T1, EVT(K+1))
         IF (TB .LE. TA) GOTO 10
         FA = (TA - EVT(K))/(EVT(K+1) - EVT(K))
         FB = (TB - EVT(K))/(EVT(K+1) - EVT(K))
         PAX = EVX(K) + FA*(EVX(K+1) - EVX(K))
         PAY = EVY(K) + FA*(EVY(K+1) - EVY(K))
         DX = (FB - FA)*(EVX(K+1) - EVX(K))
         DY = (FB - FA)*(EVY(K+1) - EVY(K))
         RL = SQRT(DX**2 + DY**2)
         RX = GX - PAX
         RY = GY - PAY
         IF (RL .LT. 1.0D-12) THEN
            VAL = (TB - TA)*EXP(-2.0D0*(RX**2 + RY**2)/WL**2)
         ELSE
            S0 = (RX*DX + RY*DY)/RL
            H2 = RX**2 + RY**2 - S0**2
            SPEED = RL/(TB - TA)
            VAL = EXP(-2.0D0*H2/WL**2)/SPEED*0.5D0*WL*SQRT(0.5D0*PI)
     1         *(ERF(SQRT(2.0D0)*(RL - S0)/WL) + ERF(SQRT(2.0D0)*S0/WL))
         ENDIF
         K7_INTQ = K7_INTQ + 2.0D0*ETA*EVP(K)/(PI*WL**2)*VAL
   10 CONTINUE
      RETURN
      END
!
      SUBROUTINE UMDFLUX(JFLAGS,AMPLITUDE,NOEL,NELEMNODES,IELEMNODES,
     1 MCRD,COORDNODES,UNODES,KSTEP,KINC,TIME,DT,JLTYP,TEMP,NPREDEF,
     2 PREDEF,NSVARS,SVARS,SOL,DSOL,NINTP,VOLELM,VOLINT,NHEATEVENTS,
     3 FLUX,DFLUXDT,CSISTART,CSIEND)
!
      INCLUDE 'ABA_PARAM.INC'
      INCLUDE 'K7_LASER.INC'
!
      DIMENSION JFLAGS(*), IELEMNODES(NELEMNODES)
      DIMENSION COORDNODES(MCRD,NELEMNODES), UNODES(MCRD,NELEMNODES)
      DIMENSION TIME(2), DT(2), TEMP(2,NELEMNODES)
      DIMENSION PREDEF(2,NPREDEF,NELEMNODES), SVARS(NSVARS,2)
      DIMENSION SOL(NELEMNODES), DSOL(NELEMNODES), VOLINT(NINTP)
      DIMENSION FLUX(NHEATEVENTS), DFLUXDT(NHEATEVENTS)
      DIMENSION CSISTART(3,NHEATEVENTS), CSIEND(3,NHEATEVENTS)
      DIMENSION GX(NGL), GW(NGL), XN(8), DN(8,3), XJ(3,2)
      DOUBLE PRECISION K7_INTQ
!     Gaussian spot on the top face (nodes 5-8) of a brick.  Every
!     Gauss point of the face is a stationary event carrying the
!     power averaged over the increment.
      NCAP = NHEATEVENTS
      NHEATEVENTS = 0
      IF (NELEMNODES .NE. 8 .OR. MCRD .NE. 3) RETURN
      IF (MINVAL(COORDNODES(3,5:8)) .LT. ZTOP - 1.0D-9) RETURN
      IF (NGL**2 .GT. NCAP) CALL XIT
      T1 = TIME(2)
      T0 = T1 - DT(1)
      CALL K7_GAUSS(NGL,GX,GW)
      N = 0
      DO 40 JJ = 1, NGL
      DO 40 II = 1, NGL
         CALL K7_HEX8(GX(II),GX(JJ),1.0D0,XN,DN)
         DO 30 K = 1, 3
         DO 30 L = 1, 2
            XJ(K,L) = DOT_PRODUCT(DN(1:8,L),COORDNODES(K,1:8))
   30    CONTINUE
         DA = SQRT((XJ(2,1)*XJ(3,2) - XJ(3,1)*XJ(2,2))**2
     1      + (XJ(3,1)*XJ(1,2) - XJ(1,1)*XJ(3,2))**2
     2      + (XJ(1,1)*XJ(2,2) - XJ(2,1)*XJ(1,2))**2)
         XP = DOT_PRODUCT(XN,COORDNODES(1,1:8))
         YP = DOT_PRODUCT(XN,COORDNODES(2,1:8))
         N = N + 1
         FLUX(N) = AMPLITUDE*K7_INTQ(XP,YP,T0,T1)/DT(1)
     1      *GW(II)*GW(JJ)*DA
         DFLUXDT(N) = 0.0D0
         CSISTART(1,N) = GX(II)
         CSISTART(2,N) = GX(JJ)
         CSISTART(3,N) = 1.0D0
         CSIEND(1:3,N) = CSISTART(1:3,N)
   40 CONTINUE
      NHEATEVENTS = N
      RETURN
      END
