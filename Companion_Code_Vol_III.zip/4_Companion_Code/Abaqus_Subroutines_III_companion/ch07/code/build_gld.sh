#!/bin/sh
# build_gld.sh NG  -> out/drv_goldak_NG   (NG replaces the Gauss count of K7_WELD.INC)
D=/home/claude/vol3/ch07; mkdir -p $D/out/b$1; cd $D/out/b$1
cp $D/code/*.f . ; sed "s/NG = 3/NG = $1/" $D/code/K7_WELD.INC > K7_WELD.INC
gfortran -O1 -ffixed-form -std=legacy -I/home/claude/vol3/lib/aba drv_goldak.f ex7_goldak.f k7_util.f /home/claude/vol3/lib/aba/stubs.f -o ../drv_goldak_$1
