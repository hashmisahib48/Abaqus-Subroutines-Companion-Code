      SUBROUTINE UMDFLUXSETUP(LOP,CMBFNUELSETNAME,JFLUXACTIVEELEMS,
     1 NFLUXACTIVEELEMS,KSTEP,KINC,TIME,DT)
!
      INCLUDE 'ABA_PARAM.INC'
      INCLUDE 'K7_WELD.INC'
!
      PARAMETER (MAXEL = 400000)
      PARAMETER (DSMAX = 1.0D0)     ! largest travel per increment, mm
      DIMENSION JFLUXACTIVEELEMS(*), TIME(2), DT(2)
      CHARACTER*80 CMBFNUELSETNAME
      CHARACTER*256 OUTDIR
      COMMON /K7ELM/ BOX(6,MAXEL), LABEL(MAXEL), NEL
!     LOP = 1: read the element table (label and bounding
!     box) written from the mesh. LOP = 2: list the elements
!     that the source can reach in this increment.
      IF (LOP .EQ. 1) THEN
         CALL GETOUTDIR(OUTDIR,LENOUT)
         OPEN(UNIT=107, FILE=OUTDIR(1:LENOUT)//'/k7_elems.dat',
     1      STATUS='OLD')
         NEL = 0
   10    READ(107,*,END=20) L, (BOX(K,NEL+1), K = 1, 6)
         NEL = NEL + 1
         LABEL(NEL) = L
         GOTO 10
   20    CLOSE(107)
      ELSEIF (LOP .EQ. 2) THEN
         XA = X0W + VW*(TIME(2) - DT(1))
         XB = X0W + VW*TIME(2)
         NFLUXACTIVEELEMS = 0
         DO 30 N = 1, NEL
            DX = MAX(BOX(1,N) - XB, XA - BOX(2,N), 0.0D0)
            IF (BOX(1,N) .GT. XB) THEN
               DX = DX/CFG
            ELSE
               DX = DX/CRG
            ENDIF
            DY = MAX(BOX(3,N), -BOX(4,N), 0.0D0)/AG
            DZ = MAX(-BOX(6,N), 0.0D0)/BG
            IF (3.0D0*(DX**2 + DY**2 + DZ**2) .LE. 20.0D0) THEN
               NFLUXACTIVEELEMS = NFLUXACTIVEELEMS + 1
               JFLUXACTIVEELEMS(NFLUXACTIVEELEMS) = LABEL(N)
            ENDIF
   30    CONTINUE
         IF (VW*DT(1) .GT. DSMAX) DT(2) = DSMAX/(VW*DT(1))
      ENDIF
      RETURN
      END
