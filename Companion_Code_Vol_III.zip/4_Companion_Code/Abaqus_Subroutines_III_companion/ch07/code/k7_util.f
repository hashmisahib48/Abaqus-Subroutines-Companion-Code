      DOUBLE PRECISION FUNCTION K7_QG(DX,Y,Z,Q,A,B,CF,CR)
!     Goldak double-ellipsoid power density, Eq. (7.2-1), mW/mm^3.
!     DX = x - x_source (front DX > 0), Y transverse, Z = depth >= 0.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0)
      IF (DX .GE. 0.0D0) THEN
         C = CF
      ELSE
         C = CR
      ENDIF
      F = 2.0D0*C/(CF + CR)
      K7_QG = 6.0D0*SQRT(3.0D0)*F*Q/(A*B*C*PI*SQRT(PI))
     1   *EXP(-3.0D0*((DX/C)**2 + (Y/A)**2 + (Z/B)**2))
      RETURN
      END
!
      SUBROUTINE K7_GAUSS(N,X,W)
!     Gauss-Legendre points and weights on (-1,1), N = 1,...,4
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(N), W(N)
      IF (N .EQ. 1) THEN
         X(1) = 0.0D0
         W(1) = 2.0D0
      ELSEIF (N .EQ. 2) THEN
         X(1) = -1.0D0/SQRT(3.0D0)
         W(1) = 1.0D0
      ELSEIF (N .EQ. 3) THEN
         X(1) = -SQRT(0.6D0)
         X(2) = 0.0D0
         W(1) = 5.0D0/9.0D0
         W(2) = 8.0D0/9.0D0
      ELSE
         X(1) = -SQRT(3.0D0/7.0D0 + 2.0D0/7.0D0*SQRT(1.2D0))
         X(2) = -SQRT(3.0D0/7.0D0 - 2.0D0/7.0D0*SQRT(1.2D0))
         W(1) = 0.5D0 - SQRT(30.0D0)/36.0D0
         W(2) = 0.5D0 + SQRT(30.0D0)/36.0D0
      ENDIF
      DO 10 I = 1, N/2
         X(N+1-I) = -X(I)
         W(N+1-I) = W(I)
   10 CONTINUE
      RETURN
      END
!
      SUBROUTINE K7_HEX8(S,T,U,XN,DN)
!     Trilinear shape functions XN(8) and derivatives DN(8,3) of the
!     8-node brick (Abaqus node order: bottom face 1-4, top face 5-8)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XN(8), DN(8,3), SG(8), TG(8), UG(8)
      DATA SG /-1.D0, 1.D0, 1.D0,-1.D0,-1.D0, 1.D0, 1.D0,-1.D0/
      DATA TG /-1.D0,-1.D0, 1.D0, 1.D0,-1.D0,-1.D0, 1.D0, 1.D0/
      DATA UG /-1.D0,-1.D0,-1.D0,-1.D0, 1.D0, 1.D0, 1.D0, 1.D0/
      DO 10 K = 1, 8
         XN(K) = 0.125D0*(1.D0+SG(K)*S)*(1.D0+TG(K)*T)*(1.D0+UG(K)*U)
         DN(K,1) = 0.125D0*SG(K)*(1.D0+TG(K)*T)*(1.D0+UG(K)*U)
         DN(K,2) = 0.125D0*TG(K)*(1.D0+SG(K)*S)*(1.D0+UG(K)*U)
         DN(K,3) = 0.125D0*UG(K)*(1.D0+SG(K)*S)*(1.D0+TG(K)*T)
   10 CONTINUE
      RETURN
      END
