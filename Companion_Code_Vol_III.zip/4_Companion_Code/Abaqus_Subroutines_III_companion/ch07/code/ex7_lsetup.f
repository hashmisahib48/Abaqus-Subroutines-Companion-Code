      SUBROUTINE UMDFLUXSETUP(LOP,CMBFNUELSETNAME,JFLUXACTIVEELEMS,
     1 NFLUXACTIVEELEMS,KSTEP,KINC,TIME,DT)
!
      INCLUDE 'ABA_PARAM.INC'
      INCLUDE 'K7_LASER.INC'
!
      PARAMETER (MAXEL = 400000)
!     reach of the spot: exp(-18) = 1.5E-8
      PARAMETER (RC = 3.0D0*WL)
      DIMENSION JFLUXACTIVEELEMS(*), TIME(2), DT(2)
      CHARACTER*80 CMBFNUELSETNAME
      CHARACTER*256 OUTDIR
      COMMON /K7ELM/ BOX(6,MAXEL), LABEL(MAXEL), NEL
      IF (LOP .EQ. 1) THEN
         CALL GETOUTDIR(OUTDIR,LENOUT)
         OPEN(UNIT=107, FILE=OUTDIR(1:LENOUT)//'/k7_elems.dat',
     1      STATUS='OLD')
         NEL = 0
   10    READ(107,*,END=20) L, (BOX(K,NEL+1), K = 1, 6)
         NEL = NEL + 1
         LABEL(NEL) = L
         GOTO 10
   20    CLOSE(107)
         OPEN(UNIT=107, FILE=OUTDIR(1:LENOUT)//'/k7_events.dat',
     1      STATUS='OLD')
         NEVS = 0
   30    READ(107,*,END=40) EVT(NEVS+1), EVX(NEVS+1), EVY(NEVS+1),
     1      EVP(NEVS+1)
         NEVS = NEVS + 1
         GOTO 30
   40    CLOSE(107)
      ELSEIF (LOP .EQ. 2) THEN
         T1 = TIME(2)
         T0 = T1 - DT(1)
         NFLUXACTIVEELEMS = 0
         DO 70 N = 1, NEL
            IF (BOX(6,N) .LT. ZTOP - 1.0D-9) GOTO 70
            DO 60 K = 1, NEVS - 1
               IF (EVP(K) .LE. 0.0D0) GOTO 60
               IF (MIN(T1,EVT(K+1)) .LE. MAX(T0,EVT(K))) GOTO 60
               XLO = MIN(EVX(K),EVX(K+1)) - RC
               XHI = MAX(EVX(K),EVX(K+1)) + RC
               YLO = MIN(EVY(K),EVY(K+1)) - RC
               YHI = MAX(EVY(K),EVY(K+1)) + RC
               IF (BOX(2,N) .LT. XLO .OR. BOX(1,N) .GT. XHI) GOTO 60
               IF (BOX(4,N) .LT. YLO .OR. BOX(3,N) .GT. YHI) GOTO 60
               NFLUXACTIVEELEMS = NFLUXACTIVEELEMS + 1
               JFLUXACTIVEELEMS(NFLUXACTIVEELEMS) = LABEL(N)
               GOTO 70
   60       CONTINUE
   70    CONTINUE
      ENDIF
      RETURN
      END
