      SUBROUTINE DFLOW(FLOW,U,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!
!     Recharge pulse through surface INFIL.  FLOW is the effective
!     velocity of the pore fluid OUT of the model, so inflow is
!     negative.  Units: mm, s.
      PARAMETER (Q0 = 5.0D-7)       ! recharge velocity, mm/s
      PARAMETER (T1 = 2.0D6)        ! duration of the pulse, s
!
      FLOW = 0.0D0
      IF (INDEX(SNAME,'INFIL') .GT. 0) THEN
         IF (TIME(2) .LE. T1) FLOW = -Q0
      ENDIF
      RETURN
      END
