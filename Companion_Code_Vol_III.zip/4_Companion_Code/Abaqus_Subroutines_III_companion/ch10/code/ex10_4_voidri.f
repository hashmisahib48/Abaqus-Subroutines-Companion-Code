      SUBROUTINE VOIDRI(EZERO,COORDS,NOEL)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION COORDS(3)
      DOUBLE PRECISION K10_SEFF
!
!     Void ratio of a normally consolidated, saturated clay deposit
!     from its compression line  e = E1 - CC*LOG10(S/S1),  evaluated
!     at the vertical effective stress of the self-weight profile.
!     Units: N, mm, MPa.
      PARAMETER (YTOP = 20000.0D0)  ! ground surface = water table, mm
      PARAMETER (E1 = 1.80D0)       ! void ratio at S1
      PARAMETER (CC = 0.65D0)       ! compression index (log10)
      PARAMETER (S1 = 0.010D0)      ! reference effective stress, MPa
!
      DEPTH = MAX(0.0D0, YTOP - COORDS(2))
      S = K10_SEFF(DEPTH)
      EZERO = E1 - CC*LOG10(S/S1)
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION K10_SEFF(DEPTH)
!     Vertical effective stress (MPa) at DEPTH (mm) below the ground
!     surface: Newton solution of Eq. (10.4-4),
!        G(S) - G(S0) = (GS-1)*GAMMAW*DEPTH,
!        G(S) = (1+E1+C)*S - C*S*LN(S/S1),   C = CC/LN(10).
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (GAMMAW = 9.81D-6)  ! N/mm^3
      PARAMETER (GS = 2.70D0)       ! specific gravity of the grains
      PARAMETER (E1 = 1.80D0, CC = 0.65D0, S1 = 0.010D0)
      PARAMETER (S0 = 0.002D0)      ! effective stress at ground, MPa
      C = CC/LOG(10.0D0)
      RHS = (GS - 1.0D0)*GAMMAW*DEPTH
     1      + (1.0D0 + E1 + C)*S0 - C*S0*LOG(S0/S1)
      S = S0 + (GS - 1.0D0)*GAMMAW*DEPTH/(1.0D0 + E1)  ! start value
      DO 10 IT = 1, 50
         G = (1.0D0 + E1 + C)*S - C*S*LOG(S/S1) - RHS
         DG = 1.0D0 + E1 - C*LOG(S/S1)         ! = 1 + e(S) > 0
         DS = G/DG
         S = MAX(0.5D0*S, S - DS)
         IF (ABS(DS) .LT. 1.0D-13*S) GO TO 20
   10 CONTINUE
   20 K10_SEFF = S
      RETURN
      END
