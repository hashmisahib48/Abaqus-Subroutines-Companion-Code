      PROGRAM DRV10I
!     Calls UPOREP and VOIDRI as Abaqus would, at the depths of
!     Table 10.3 and on a fine grid, and tests the consistency of
!     the initial state: Eq. (10.4-2).
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (GAMMAW = 9.81D-6, GS = 2.70D0, YTOP = 20000.0D0)
      DIMENSION CO(3), ZD(8)
      DOUBLE PRECISION K10_SEFF
      DATA ZD /0.D0,1000.D0,2500.D0,5000.D0,7500.D0,10000.D0,
     1 15000.D0,20000.D0/
      CO(1) = 0.0D0
      CO(3) = 0.0D0
      WRITE(*,'(A)') '  z(m)   s_v(MPa)   e        u(MPa)  '//
     1 'sigma_v(MPa)  gsat(kN/m3)'
      DO 10 K = 1, 8
         CO(2) = YTOP - ZD(K)
         CALL VOIDRI(E,CO,1)
         CALL UPOREP(U,CO,1)
         S = K10_SEFF(ZD(K))
         GSAT = (GS + E)/(1.0D0 + E)*GAMMAW*1.0D6
         WRITE(*,'(F7.1,F11.6,F9.4,F10.5,F11.6,F11.3)') ZD(K)/1.D3,
     1    S, E, U, S + U, GSAT
   10 CONTINUE
!     equilibrium: d(sigma_v)/dz = gamma_sat, central differences
      EMAX = 0.0D0
      DO 20 K = 1, 199
         Z = 100.0D0*K
         H = 1.0D-2
         CO(2) = YTOP - Z
         CALL VOIDRI(E,CO,1)
         GSAT = (GS + E)/(1.0D0 + E)*GAMMAW
         CO(2) = YTOP - Z - H
         CALL UPOREP(U2,CO,1)
         CO(2) = YTOP - Z + H
         CALL UPOREP(U1,CO,1)
         DSIG = (K10_SEFF(Z+H) - K10_SEFF(Z-H) + U2 - U1)/(2.0D0*H)
         EMAX = MAX(EMAX, ABS(DSIG - GSAT)/GSAT)
   20 CONTINUE
      WRITE(*,'(A,1PE10.2)') 'max rel. error of d(sigma_v)/dz-gsat:',
     1 EMAX
!     equilibrium of the whole column: sigma_v(20 m) = int gsat dz
      SUMG = 0.0D0
      N = 20000
      DO 30 K = 1, N
         CO(2) = YTOP - (K - 0.5D0)
         CALL VOIDRI(E,CO,1)
         SUMG = SUMG + (GS + E)/(1.0D0 + E)*GAMMAW
   30 CONTINUE
      CO(2) = YTOP - 20000.0D0
      CALL UPOREP(U,CO,1)
      WRITE(*,'(A,F10.6,A,F10.6)') 'int gsat dz + s0 =',
     1 SUMG + K10_SEFF(0.0D0), '  s_v+u at 20 m =', K10_SEFF(2.D4)+U
      END
