#!/bin/sh
# compile all listings and run the drivers (gfortran, stubs in lib/aba)
A=/home/claude/vol3/lib/aba
F="-ffixed-form -std=legacy -I$A"
T=/tmp/claude-0/ch10; mkdir -p $T
cd "$(dirname "$0")"
for f in ex10_4_uporep.f ex10_4_voidri.f ex10_5_dflow.f ex10_6_flow.f h10_fe1d.f; do gfortran -c $F $f -o $T/$f.o || exit 1; done
gfortran $F drv10_init.f ex10_4_uporep.f ex10_4_voidri.f -o $T/drv_init && $T/drv_init > ../verify/out_init.txt
gfortran $F drv10_fe.f h10_fe1d.f ex10_5_dflow.f ex10_6_flow.f ex10_4_uporep.f $A/stubs.f -o $T/drv_fe || exit 1
gfortran -c $F prob_10b2_bug.f -o $T/bug.o || exit 1
sed 's/         H = SMEARK\/(GAMMAW\*SMEART)/         H = SMEARK\/(GAMMAW*SMEART)\/(1.0D0 + TIME(2)\/TCLOG)/; s/      PARAMETER (HLAKE = 1.0D0)     ! open water, mm^3\/(N s)/      PARAMETER (HLAKE = 1.0D0)\n      PARAMETER (TCLOG = 2.0D8)     ! clogging time constant, s/' ex10_6_flow.f > ../verify/flow_clog.f
gfortran $F ../verify/flow_clog.f -c -o $T/clog.o || exit 1
gfortran $F drv10_fe.f h10_fe1d.f ex10_5_dflow.f ../verify/flow_clog.f ex10_4_uporep.f $A/stubs.f -o $T/drv_clog || exit 1
echo $T/drv_fe
