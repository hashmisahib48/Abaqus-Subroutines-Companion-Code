      PROGRAM DRV10F
!     Driver for the 1-D consolidation column: reads the case from
!     the standard input, advances it with H10_STEP (which calls
!     DFLOW or FLOW) and writes the history and the profiles.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 4001, GAMMAW = 9.81D-6)
      PARAMETER (PERM = 1.0D-6, EOED = 2.0D0)  ! mm/s, MPa
      DIMENSION U(NMAX), UO(NMAX), TOUT(400), CO(3)
      CHARACTER*40 FNAME
      READ(*,*) FNAME
      READ(*,*) ICASE, XL, N, DT0, GROW, DTMAX, U0, Y0
      READ(*,*) NOUT
      READ(*,*) (TOUT(K), K = 1, NOUT)
      OPEN(10, FILE = TRIM(FNAME)//'_hist.dat')
      OPEN(11, FILE = TRIM(FNAME)//'_prof.dat')
      NN = N + 1
      H = XL/N
      ITOP = 2
      GRAV = 0.0D0
      IF (ICASE .EQ. 2) ITOP = 1
      IF (ICASE .EQ. 5) ITOP = 6
      IF (ICASE .EQ. 3) ITOP = 3
      IF (ICASE .EQ. 4) ITOP = 4
      IF (ICASE .EQ. 3 .OR. ICASE .EQ. 4) GRAV = 1.0D0
      CO(1) = 0.0D0
      CO(3) = 0.0D0
      DO 10 I = 1, NN
         U(I) = U0
         IF (ICASE .EQ. 3 .OR. ICASE .EQ. 4) THEN
            CO(2) = Y0 + (I - 1)*H
            CALL UPOREP(U(I),CO,I)
         ENDIF
         UO(I) = U(I)
   10 CONTINUE
      UREF = U(1)
      T = 0.0D0
      DT = DT0
      QOUT = 0.0D0
      K = 1
      DO 100 ISTEP = 1, 2000000
         DTUSE = MIN(DT, TOUT(K) - T)
         TNEW = T + DTUSE
         CALL H10_STEP(N,XL,Y0,PERM,EOED,GRAV,ITOP,DTUSE,TNEW,UO,U,
     1    NIT)
         CALL H10_QN(ITOP,Y0+XL,TNEW,U(NN),Q,DQ)
         QOUT = QOUT + Q*DTUSE
         T = TNEW
         DO 20 I = 1, NN
            UO(I) = U(I)
   20    CONTINUE
         DT = MIN(DT*GROW, DTMAX)
         IF (ABS(T - TOUT(K)) .LE. 1.0D-9*TOUT(K)) THEN
!           integral of (U - U0) by the trapezoidal rule (exact for
!           piecewise linear fields), stored fluid volume change
            SU = 0.0D0
            DO 30 I = 1, N
               SU = SU + 0.5D0*H*(U(I) + U(I+1))
   30       CONTINUE
            WRITE(10,'(1P,6E16.8)') T, U(NN), U(1), U((NN+1)/2), SU,
     1       QOUT
            WRITE(11,'(A,1PE16.8)') '# t = ', T
            DO 40 I = 1, NN
               WRITE(11,'(1P,2E16.8)') Y0 + (I - 1)*H, U(I)
   40       CONTINUE
            K = K + 1
            IF (K .GT. NOUT) GO TO 200
         ENDIF
  100 CONTINUE
  200 CLOSE(10)
      CLOSE(11)
      END
