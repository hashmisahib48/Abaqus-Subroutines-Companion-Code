      SUBROUTINE H10_QN(ITYPE,Y,TIME,U,Q,DQ)
!     Outward pore-fluid velocity Q (mm/s) through a boundary point
!     and its derivative DQ = dQ/dU, obtained by calling DFLOW or
!     FLOW with the arguments Abaqus would pass.
!       ITYPE = 0  impervious            1  DFLOW, surface INFIL
!               2  FLOW, TOPDRAIN        3  FLOW, LAKE
!               4  FLOW, LAKEHS          5  DFLOW, surface BASE
!               6  FLOW, DRAINED
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TM(2), CO(3)
      CHARACTER*80 SNAME
      TM(1) = TIME
      TM(2) = TIME
      CO(1) = 0.0D0
      CO(2) = Y
      CO(3) = 0.0D0
      Q = 0.0D0
      DQ = 0.0D0
      IF (ITYPE .EQ. 1 .OR. ITYPE .EQ. 5) THEN
         IF (ITYPE .EQ. 1) SNAME = 'INFIL'
         IF (ITYPE .EQ. 5) SNAME = 'BASE'
         CALL DFLOW(Q,U,1,1,TM,1,1,CO,0,SNAME)
      ELSE IF (ITYPE .GE. 2) THEN
         IF (ITYPE .EQ. 2) SNAME = 'TOPDRAIN'
         IF (ITYPE .EQ. 3) SNAME = 'LAKE'
         IF (ITYPE .EQ. 4) SNAME = 'LAKEHS'
         IF (ITYPE .EQ. 6) SNAME = 'DRAINED'
         HH = 0.0D0
         SK = 0.0D0
         CALL FLOW(HH,SK,U,1,1,TM,1,1,CO,0,SNAME)
         Q = HH*(U - SK)
         DQ = HH
      ENDIF
      RETURN
      END
!
      SUBROUTINE H10_STEP(N,XL,Y0,PERM,EOED,GRAV,ITOP,DT,TNEW,
     1 UOLD,U,NIT)
!     One backward-Euler increment of 1-D consolidation on N linear
!     elements, base at Y0, top at Y0+XL (mm), unit cross-section.
!     Residual (Eq. 10.3-1):  M (U-UOLD)/DT + K U + G + Q = 0, with
!     M = (1/EOED) int N N, K = (PERM/GAMMAW) int N'N', G the weight
!     of the fluid (GRAV = 1, total pressure) and Q the boundary
!     terms from DFLOW/FLOW.  Tridiagonal Newton iteration.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (GAMMAW = 9.81D-6, NMAX = 4001)
      DIMENSION UOLD(N+1), U(N+1)
      DIMENSION R(NMAX), A(NMAX), B(NMAX), C(NMAX)
      NN = N + 1
      H = XL/N
      D = PERM/GAMMAW
      DO 100 NIT = 1, 20
         DO 10 I = 1, NN
            R(I) = 0.0D0
            A(I) = 0.0D0
            B(I) = 0.0D0
            C(I) = 0.0D0
   10    CONTINUE
         DO 20 IE = 1, N
            CM = H/(6.0D0*EOED*DT)
            CK = D/H
            R(IE) = R(IE) + (2.0D0*CM + CK)*U(IE) - 2.0D0*CM*UOLD(IE)
     1       + (CM - CK)*U(IE+1) - CM*UOLD(IE+1) - GRAV*D*GAMMAW
            R(IE+1) = R(IE+1) + (CM - CK)*U(IE) - CM*UOLD(IE)
     1       + (2.0D0*CM + CK)*U(IE+1) - 2.0D0*CM*UOLD(IE+1)
     2       + GRAV*D*GAMMAW
            B(IE) = B(IE) + 2.0D0*CM + CK
            B(IE+1) = B(IE+1) + 2.0D0*CM + CK
            C(IE) = C(IE) + CM - CK
            A(IE+1) = A(IE+1) + CM - CK
   20    CONTINUE
         CALL H10_QN(5,Y0,TNEW,U(1),Q,DQ)
         R(1) = R(1) + Q
         B(1) = B(1) + DQ
         CALL H10_QN(ITOP,Y0+XL,TNEW,U(NN),Q,DQ)
         R(NN) = R(NN) + Q
         B(NN) = B(NN) + DQ
!        Thomas algorithm for the correction, J*DU = -R
         DO 30 I = 2, NN
            W = A(I)/B(I-1)
            B(I) = B(I) - W*C(I-1)
            R(I) = R(I) - W*R(I-1)
   30    CONTINUE
         R(NN) = -R(NN)/B(NN)
         DUMAX = ABS(R(NN))
         U(NN) = U(NN) + R(NN)
         DO 40 I = NN-1, 1, -1
            R(I) = (-R(I) - C(I)*R(I+1))/B(I)
            DUMAX = MAX(DUMAX, ABS(R(I)))
            U(I) = U(I) + R(I)
   40    CONTINUE
         IF (DUMAX .LT. 1.0D-13) RETURN
  100 CONTINUE
      RETURN
      END
