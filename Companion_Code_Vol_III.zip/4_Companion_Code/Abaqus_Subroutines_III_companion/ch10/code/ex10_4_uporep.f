      SUBROUTINE UPOREP(UW0,COORDS,NODE)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION COORDS(3)
!
!     Hydrostatic pore pressure below a water table, Y vertical (up).
!     Total pore pressure, tension positive.  Units: N, mm, MPa.
      PARAMETER (GAMMAW = 9.81D-6)  ! unit weight of water, N/mm^3
      PARAMETER (YW = 20000.0D0)    ! water table elevation, mm
!
      UW0 = GAMMAW*MAX(0.0D0, YW - COORDS(2))
      RETURN
      END
