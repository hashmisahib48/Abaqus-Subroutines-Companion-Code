import numpy as np
from check import *
from scipy.optimize import brentq
# 10A.1 water table 3 m below ground (ground y=10000? ) 
print('10A.1 u at 8 m depth (WT at 3 m):',GW*5000,' at 2 m:',0.0,' at 10 m',GW*7000)
# 10A.2 filter layer
kg=2e-3; tg=4.0; H=kg/(GW*tg); L=5000.; k=1e-6; D=k/GW; Bi=H*L/D; print('10A.2 H',H,'Bi',Bi,'H*h/D (h=50)',H*50/D)
# 10A.3 double drained 4 m: k 2e-7, E 5
cv=2e-7*5/GW; Hd=2000.; T90=0.848081; print('10A.3 cv',cv,'t90',T90*Hd**2/cv,'days',T90*Hd**2/cv/86400,' t50',0.19673*Hd**2/cv/86400)
# 10B.1
q0=5e-7;T1=2e6;cvv=0.20387359836901123;Dd=1e-6/9.81e-6
print('10B.1 u(0,T1)',2*q0/Dd*np.sqrt(cvv*T1/np.pi)/1,' stored',q0*T1)
# 10B.3 Newton iterations at 20 m
GS=2.7;E1=1.8;CC=0.65;S1=0.01;S0=0.002;c=CC/np.log(10)
def its(depth,start='lin'):
    rhs=(GS-1)*9.81e-6*depth+(1+E1+c)*S0-c*S0*np.log(S0/S1)
    s=S0+(GS-1)*9.81e-6*depth/(1+E1); n=0
    while True:
        n+=1; g=(1+E1+c)*s-c*s*np.log(s/S1)-rhs; dg=1+E1-c*np.log(s/S1); ds=g/dg; s=max(0.5*s,s-ds)
        print('   it',n,s,ds)
        if abs(ds)<1e-13*s or n>50: return n,s
print('10B.3',its(20000.))
# 10C.1 T90 vs Bi
from check import U_rob
for Bi in (1,10,100,1000,1e5):
    print('Bi',Bi,'T90',brentq(lambda T:U_rob(T,Bi)-0.9,1e-4,20))
