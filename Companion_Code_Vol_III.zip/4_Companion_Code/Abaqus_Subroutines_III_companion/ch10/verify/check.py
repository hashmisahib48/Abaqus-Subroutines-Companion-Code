import numpy as np, subprocess, os, json
from scipy.optimize import brentq
from scipy.special import erfc
np.set_printoptions(linewidth=150)
EXE='/tmp/claude-0/ch10/drv_fe'; OUT='/tmp/claude-0/ch10/run'; os.makedirs(OUT,exist_ok=True)
GW=9.81e-6; K=1e-6; E=2.0; D=K/GW; CV=K*E/GW
def run(name,case,XL,N,dt0,grow,dtmax,u0,y0,touts):
    inp=f"'{OUT}/{name}'\n{case} {XL} {N} {dt0} {grow} {dtmax} {u0} {y0}\n{len(touts)}\n"+" ".join(repr(float(t)) for t in touts)+"\n"
    subprocess.run([EXE],input=inp,text=True,check=True,cwd='/tmp/claude-0/ch10')
    h=np.loadtxt(f"{OUT}/{name}_hist.dat"); 
    prof={}; cur=None
    for line in open(f"{OUT}/{name}_prof.dat"):
        if line.startswith('#'): cur=float(line.split('=')[1]); prof[cur]=[]
        else: prof[cur].append([float(x) for x in line.split()])
    return h,{t:np.array(v) for t,v in prof.items()}
# ---------- Robin consolidation (Bi finite) and Terzaghi (Bi inf)
def lam(Bi,n=400):
    out=[]
    for m in range(n):
        a=m*np.pi+1e-12; b=m*np.pi+np.pi/2-1e-12
        out.append(brentq(lambda x:x*np.tan(x)-Bi,a,b))
    return np.array(out)
def U_rob(Tv,Bi):
    l=lam(Bi); A=2*np.sin(l)/(l+np.sin(l)*np.cos(l))
    return 1-np.sum(A*np.sin(l)/l*np.exp(-l**2*Tv))
def ubase_rob(Tv,Bi):
    l=lam(Bi); A=2*np.sin(l)/(l+np.sin(l)*np.cos(l))
    return np.sum(A*np.exp(-l**2*Tv))
def u_rob(x,Tv,Bi):   # x = distance from the impervious base / L
    l=lam(Bi); A=2*np.sin(l)/(l+np.sin(l)*np.cos(l))
    return np.sum(A*np.cos(np.outer(x,l))*np.exp(-l**2*Tv),axis=1)
def U_terz(Tv):
    M=(2*np.arange(2000)+1)*np.pi/2; return 1-np.sum(2/M**2*np.exp(-M**2*Tv))
def tv_for(U,f): return brentq(lambda T:f(T)-U,1e-6,10)
if __name__=='__main__':
    L=10000.; N=200
    Hsm=5e-8/(GW*5.0); Bi_s=Hsm*L/D; Bi_d=1.0*L/D
    print('cv',CV,'D',D,'Bi smear',Bi_s,'Bi drained',Bi_d,'L2/cv',L**2/CV)
    Tvs=np.array([0.005,0.01,0.02,0.05,0.1,0.2,0.3,0.5,0.848,1.0,1.5])
    res={}
    for name,case,Bi in (('terz',5,Bi_d),('smear',1,Bi_s)):
        for dt0f,grow in ((1e-5,1.04),(2.5e-6,1.02)):
            t=Tvs*L**2/CV
            h,pr=run(name,case,L,N,dt0f*L**2/CV,grow,0.01*L**2/CV,1.0,0.0,t)
            Uf=1-h[:,4]/(L*1.0)
            Ue=np.array([U_rob(T,Bi) for T in Tvs]); Ut=np.array([U_terz(T) for T in Tvs])
            ub=np.array([ubase_rob(T,Bi) for T in Tvs])
            print(name,'dt0f',dt0f,'grow',grow)
            for T,a,b_,c,d_,e_ in zip(Tvs,Uf,Ue,Ut,h[:,2],ub): print(f'  Tv={T:6.3f} U_FE={a:.5f} U_ser(Bi)={b_:.5f} U_Terz={c:.5f}  u_base FE={d_:.5f} ser={e_:.5f}')
            print('  max |U_FE-U_ser| =',np.abs(Uf-Ue).max(),' max base err',np.abs(h[:,2]-ub).max())
            # conservation: stored change = outflow
            m=(1.0*L-h[:,4])/E ; print('  conservation: stored',m[-1],' outflow',h[-1,5],' rel',abs(m[-1]-h[-1,5])/m[-1])
            res[(name,dt0f)]=(Tvs,Uf,Ue)
    print('T90 terz',tv_for(0.9,U_terz),' T90 smear',tv_for(0.9,lambda T:U_rob(T,Bi_s)),' T50 terz',tv_for(0.5,U_terz),'T50 smear',tv_for(0.5,lambda T:U_rob(T,Bi_s)))
    print('t90 terz (s)',tv_for(0.9,U_terz)*L**2/CV,'  t90 smear',tv_for(0.9,lambda T:U_rob(T,Bi_s))*L**2/CV)
