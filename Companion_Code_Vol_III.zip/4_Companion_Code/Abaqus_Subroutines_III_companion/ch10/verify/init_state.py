# independent check of Example 10.3-1: numerical ODE solution of the NC clay deposit
import numpy as np
from scipy.integrate import solve_ivp
GW=9.81e-6; GS=2.70; E1=1.80; CC=0.65; S1=0.01; S0=0.002   # N/mm3, -, -, MPa, MPa
A=(GS-1)*GW
def e_of_s(s): return E1-CC*np.log10(s/S1)
def rhs(z,s): return A/(1+e_of_s(s))
zs=np.array([0,1000,2500,5000,7500,10000,15000,20000.])
sol=solve_ivp(rhs,[0,20000],[S0],t_eval=zs,rtol=1e-12,atol=1e-14)
for z,s in zip(zs,sol.y[0]):
    u=GW*z; print(f"{z/1000:6.1f} m  s={s:.6f}  e={e_of_s(s):.4f}  u={u:.5f}  sv={s+u:.6f}  gsat={(GS+e_of_s(s))/(1+e_of_s(s))*GW*1e6:.3f} kN/m3")
# layer means (4 layers of 5 m): mean e
zz=np.linspace(0,20000,20001); s=solve_ivp(rhs,[0,20000],[S0],t_eval=zz,rtol=1e-12,atol=1e-14).y[0]
e=e_of_s(s)
for k in range(4):
    m=(zz>=5000*k)&(zz<=5000*(k+1)); print(k,e[m].mean(), GS*1e-9/(1+e[m].mean()), np.trapezoid(e[m],zz[m])/5000)
