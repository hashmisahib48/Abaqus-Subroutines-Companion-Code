import numpy as np
from check import *
Lt=1000.; y0=19000.; P=2e6; a=GW*1000.; w=2*np.pi/P; nper=12; per=32
touts=np.arange(1,nper*per+1)*P/per
for div in (400,800,1600):
    h,pr=run('tidx',3,Lt,100,P/div,1.0,P/div,0.0,y0,touts)
    def tex(x,t):
        kap=np.sqrt(1j*w/CV); B=a/(np.cosh(kap*Lt)+D*kap*np.sinh(kap*Lt)); return np.imag(B*np.cosh(kap*x)*np.exp(1j*w*t))
    errs=[]
    for t in touts[(nper-1)*per:]:
        p=pr[t]; ee=p[:,1]-GW*(20000.-p[:,0]); errs.append(np.abs(ee-tex(p[:,0]-y0,t)).max())
    kap=np.sqrt(1j*w/CV); B=a/(np.cosh(kap*Lt)+D*kap*np.sinh(kap*Lt))
    bs=np.array([pr[t][0,1]-GW*(20000.-y0) for t in touts[(nper-1)*per:]])
    print(div,'max err MPa',max(errs),'rel a',max(errs)/a,'base amp FE/a',(bs.max()-bs.min())/2/a,'exact',abs(B)/a/abs(np.cosh(0)), 'lag deg',np.degrees(-np.angle(B)),'a',a)
