      SUBROUTINE FLOW(H,SINK,U,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION TIME(2), COORDS(3)
      CHARACTER*80 SNAME
!
!     Seepage q = H*(U - SINK), outward positive.  N, mm, s.
      PARAMETER (GAMMAW = 9.81D-6)  ! unit weight of water, N/mm^3
      PARAMETER (SMEARK = 5.0D-8)   ! permeability of the smear, mm/s
      PARAMETER (SMEART = 5.0D0)    ! thickness of the smear, mm
      PARAMETER (HLAKE = 1.0D0)
      PARAMETER (TCLOG = 2.0D8)     ! clogging time constant, s
      PARAMETER (YW = 20000.0D0)    ! mean water level, mm
      PARAMETER (TIDEA = 1000.0D0)  ! tidal amplitude, mm
      PARAMETER (TIDEP = 2.0D6)     ! tidal period, s
      PARAMETER (TWOPI = 6.283185307179586D0)
!
      H = 0.0D0
      SINK = 0.0D0
      IF (INDEX(SNAME,'TOPDRAIN') .GT. 0) THEN
!        drain behind a smear zone; excess pore pressure
         H = SMEARK/(GAMMAW*SMEART)/(1.0D0 + TIME(2)/TCLOG)
      ELSE IF (INDEX(SNAME,'DRAINED') .GT. 0) THEN
!        free drainage: H far above (permeability/gamma_w)/h
         H = HLAKE
      ELSE IF (INDEX(SNAME,'LAKEHS') .GT. 0) THEN
!        still lake; total pore pressure
         H = HLAKE
         SINK = GAMMAW*(YW - COORDS(2))
      ELSE IF (INDEX(SNAME,'LAKE') .GT. 0) THEN
!        tidal lake; total pore pressure
         H = HLAKE
         SINK = GAMMAW*(YW + TIDEA*SIN(TWOPI*TIME(2)/TIDEP)
     1          - COORDS(2))
      ENDIF
      RETURN
      END
