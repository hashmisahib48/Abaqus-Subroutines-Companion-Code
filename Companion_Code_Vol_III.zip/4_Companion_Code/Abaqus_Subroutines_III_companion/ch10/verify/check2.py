import numpy as np
from check import *
L=10000.; N=200
T1=2e6; Q0=5e-7; P=2e6
# ---- A: dt0 / criterion and convergence study (Terzaghi, drained)
h_=L/N; dtcrit=h_**2/(6*CV); print('h^2/(6cv)=',dtcrit,'s  = Tv',dtcrit*CV/L**2)
for dt0 in (0.3*dtcrit,1.0*dtcrit,3*dtcrit,10*dtcrit):
    h,pr=run('osc',5,L,N,dt0,1.0,dt0,1.0,0.0,[dt0])
    p=list(pr.values())[0]; print(f' dt={dt0:9.1f}  u(node 2)={p[-2,1]:.5f}  u(node3)={p[-3,1]:.5f}  min u={p[:,1].min():.5f}')
Tvs=np.array([0.01,0.05,0.1,0.2,0.5,0.848,1.0])
Ue=np.array([U_terz(T) for T in Tvs])
print('convergence, dtmax in Tv units')
for N_ in (200,400):
  for dm in (0.01,0.005,0.0025,0.00125):
    h,pr=run('cv',5,L,N_,1e-6*L**2/CV,1.02,dm*L**2/CV,1.0,0.0,Tvs*L**2/CV)
    Uf=1-h[:,4]/L; err=np.abs(Uf-Ue)
    print(f' N={N_} dtmax={dm:8.5f} max err={err.max():.5f}  err at 0.848={err[5]:.5f}')
# ---- B: pulse (DFLOW)
Lp=10000.; Np=1000
touts=np.array([0.5e6,1e6,2e6,3e6,5e6,8e6])
h,pr=run('pulse',2,Lp,Np,100.,1.05,2e4,0.0,0.0,touts)
def f(x,t):
    if t<=0: return np.zeros_like(x)
    s=np.sqrt(CV*t); return 2*Q0/D*(s/np.sqrt(np.pi)*np.exp(-x**2/(4*s**2))-x/2*erfc(x/(2*s)))
def upulse(x,t): return f(x,t)-(f(x,t-T1) if t>T1 else 0)
for k,t in enumerate(touts):
    p=pr[t]; x=Lp-p[:,0]; ex=upulse(x,t); 
    print(f' t={t:9.3g} top FE={p[-1,1]:.6e} exact={ex[-1]:.6e}  max|err|={np.abs(p[:,1]-ex).max():.3e} (rel to peak {np.abs(p[:,1]-ex).max()/ex.max():.4f})  stored vs inflow: {h[k,4]/E:.6e} {-h[k,5]:.6e}')
# ---- C: tidal
Lt=1000.; Nt=100; y0=19000.
nper=12; per=16
touts=np.arange(1,nper*per+1)*P/per
h,pr=run('tide',3,Lt,Nt,P/400,1.0,P/400,0.0,y0,touts)
a=GW*1000.; w=2*np.pi/P
def tide_exact(x,t,H):
    kap=np.sqrt(1j*w/CV); B=H*a/(H*np.cosh(kap*Lt)+D*kap*np.sinh(kap*Lt)); return np.imag(B*np.cosh(kap*x)*np.exp(1j*w*t)), B
for H in (1.0,):
    uex,B=tide_exact(np.array([0.0,Lt]),0,H)
    # excess pressure from the profile at last period
    last=[t for t in touts if t>(nper-1)*P+1]
    errs=[]
    for t in last:
        p=pr[t]; x=p[:,0]-y0; hs=GW*(20000.-p[:,0]); ee=p[:,1]-hs
        ex,_=tide_exact(x,t,H); errs.append(np.abs(ee-ex).max())
    print(' tidal: |B|/a at base',abs(B)/a,' phase lag (rad)',-np.angle(B),'; max err in last cycle',max(errs),' rel to a',max(errs)/a)
    # amplitude of base node from FE
    bs=np.array([pr[t][0,1]-GW*(20000.-y0) for t in last]); ts=np.array(last)
    print(' FE base amplitude/a',(bs.max()-bs.min())/2/a, ' attenuation exact',abs(B)/a)
    # amplitude at top node
    tp=np.array([pr[t][-1,1] for t in last]); print(' FE top amplitude/a',(tp.max()-tp.min())/2/a, 'exact', abs(H*a*np.cosh(np.sqrt(1j*w/CV)*Lt)/(H*np.cosh(np.sqrt(1j*w/CV)*Lt)+D*np.sqrt(1j*w/CV)*np.sinh(np.sqrt(1j*w/CV)*Lt))/a))
    # phase of base from zero crossing: lag in fraction of period
print('delta',np.sqrt(2*CV/w),' L/delta',Lt/np.sqrt(2*CV/w))
# ---- D: hydrostatic equilibrium
h,pr=run('hs',4,Lt,Nt,1e4,1.5,1e7,0.0,y0,[1e5,1e7,1e9])
for t,p in pr.items():
    hs=GW*(20000.-p[:,0]); print(' hydrostatic: t=%.0e max|u-u_hs|=%.2e MPa  (u_hs max %.5f)'%(t,np.abs(p[:,1]-hs).max(),hs.max()))
print('q out cum',h[:,5])
