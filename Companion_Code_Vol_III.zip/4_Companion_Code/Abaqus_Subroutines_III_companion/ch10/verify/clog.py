import numpy as np, subprocess
from check import *
import check
from scipy.integrate import solve_ivp
check.EXE='/tmp/claude-0/ch10/drv_clog'
L=10000.; Tv=np.array([0.2,0.5,0.848,1.5])
h,pr=check.run('clog',1,L,200,1e-6*L**2/CV,1.02,0.00125*L**2/CV,1.0,0.0,Tv*L**2/CV)
print('FE  U:',1-h[:,4]/L)
# independent finite-volume check (method of lines, scipy BDF)
N=2000; dx=L/N; x=(np.arange(N)+0.5)*dx
H0=5e-8/(GW*5.0); TC=2e8
def rhs(t,u):
    Ht=H0/(1+t/TC)
    # fluxes between cells: v=-D du/dx ; base x=0 impervious, top x=L: out flux Ht*(u_face)
    flux=np.zeros(N+1); flux[1:N]=-D*(u[1:]-u[:-1])/dx
    # face value at top: D*(u_N - uf)/(dx/2) = Ht*uf
    uf=D*u[-1]/(dx/2)/(Ht+D/(dx/2)); flux[N]=Ht*uf
    return -(flux[1:]-flux[:-1])/dx*CV/D*0+(-(flux[1:]-flux[:-1])/dx)*E
sol=solve_ivp(rhs,[0,Tv.max()*L**2/CV],np.ones(N),t_eval=Tv*L**2/CV,method='BDF',rtol=1e-10,atol=1e-12)
print('FV  U:',1-sol.y.mean(axis=0))
