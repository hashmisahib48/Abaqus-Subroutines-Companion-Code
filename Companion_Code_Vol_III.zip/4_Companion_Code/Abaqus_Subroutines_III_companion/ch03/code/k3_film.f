      SUBROUTINE FILM(H,SINK,TEMP,JSTEP,JINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,FIELD,NFIELD,SNAME,JUSERNODE,AREA)
!     Natural-convection film on a vertical plate, ambient ramps up
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION H(2), TIME(2), COORDS(3), FIELD(NFIELD)
      CHARACTER*80 SNAME
      PARAMETER (T0 = 20.0D0)       ! ambient at t = 0, deg C
      PARAMETER (T1 = 50.0D0)       ! ambient at t = TRAMP, deg C
      PARAMETER (TRAMP = 3600.0D0)  ! s
      PARAMETER (XL = 0.30D0)       ! plate height, m
      PARAMETER (A0 = 0.825D0)      ! Churchill-Chu constant
      PARAMETER (UNIT = 1.0D-3)     ! W/(m^2 K) -> mW/(mm^2 K)
!
      TIN = T0 + (T1 - T0)*MIN(TIME(2)/TRAMP, 1.0D0)
      CALL K3_HCC(TEMP - TIN, TIN, XL, A0, HW, DHW)
      H(1) = UNIT*HW                ! mW/(mm^2 K)
      H(2) = UNIT*DHW               ! mW/(mm^2 K^2)
      SINK = TIN                    ! deg C
      RETURN
      END
