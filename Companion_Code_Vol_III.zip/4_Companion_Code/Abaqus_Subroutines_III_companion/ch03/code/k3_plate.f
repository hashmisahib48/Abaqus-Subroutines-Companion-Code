!     Driver: 1-D transient conduction through the half-thickness of
!     a plate (symmetry plane at node 1), FILM called at the surface
!     node exactly as Abaqus calls it, backward Euler + Newton.
!     Units: mm, tonne, s, mJ, mW, deg C.
      SUBROUTINE K3_PLATE(FSUB, NE, DTI, TEND, TI, ISW2, IHIST, IRES,
     1 TSURF, TMEAN, NITTOT, NITMAX)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      EXTERNAL FSUB
      PARAMETER (RHOC = 2.43D0)  ! rho*c = 2.7E-9*9.0E8 mJ/(mm^3 K)
      PARAMETER (XK = 237.0D0)   ! mW/(mm K)
      PARAMETER (HALF = 2.5D0)   ! half thickness, mm
      PARAMETER (TOLR = 1.0D-9)  ! residual tolerance, mW/mm^2
      DIMENSION TH(201), TO(201), CAP(201), A(201), B(201), C(201),
     1 R(201), DTH(201), TIME(2), COORDS(3), FIELD(1), H(2)
      CHARACTER*80 SNAME
      N = NE + 1
      DX = HALF/NE
      G = XK/DX
      DO I = 1, N
         CAP(I) = RHOC*DX
         TH(I) = TI
      ENDDO
      CAP(1) = 0.5D0*CAP(1)
      CAP(N) = 0.5D0*CAP(N)
      NINC = NINT(TEND/DTI)
      NITTOT = 0
      NITMAX = 0
      T = 0.0D0
      IF (IHIST .GT. 0) WRITE(IHIST,'(4ES16.8)') 0.D0, TH(N), TH(1),
     1 0.D0
      DO KINC = 1, NINC
         T = T + DTI
         TIME(1) = T
         TIME(2) = T
         DO I = 1, N
            TO(I) = TH(I)
         ENDDO
         DO IT = 1, 40
            CALL FSUB(H, SINK, TH(N), 1, KINC, TIME, 1, 1, COORDS, 0,
     1       FIELD, 0, SNAME, 0, 0.0D0)
            DO I = 1, N
               A(I) = 0.0D0
               C(I) = 0.0D0
               B(I) = CAP(I)/DTI
               R(I) = CAP(I)*(TH(I) - TO(I))/DTI
            ENDDO
            DO I = 1, NE
               F = G*(TH(I) - TH(I+1))
               R(I) = R(I) + F
               R(I+1) = R(I+1) - F
               B(I) = B(I) + G
               B(I+1) = B(I+1) + G
               C(I) = -G
               A(I+1) = -G
            ENDDO
            Q = H(1)*(TH(N) - SINK)
            R(N) = R(N) + Q
            B(N) = B(N) + H(1) + ISW2*(TH(N) - SINK)*H(2)
            RMAX = 0.0D0
            DO I = 1, N
               RMAX = MAX(RMAX, ABS(R(I)))
            ENDDO
            IF (IRES .GT. 0 .AND. KINC .EQ. 1) WRITE(IRES,'(I4,ES16.8)')
     1       IT - 1, RMAX
            IF (RMAX .LT. TOLR) GOTO 20
!           Thomas algorithm for J*dth = -R
            DO I = 1, N
               DTH(I) = -R(I)
            ENDDO
            DO I = 2, N
               W = A(I)/B(I-1)
               B(I) = B(I) - W*C(I-1)
               DTH(I) = DTH(I) - W*DTH(I-1)
            ENDDO
            DTH(N) = DTH(N)/B(N)
            DO I = N-1, 1, -1
               DTH(I) = (DTH(I) - C(I)*DTH(I+1))/B(I)
            ENDDO
            DO I = 1, N
               TH(I) = TH(I) + DTH(I)
            ENDDO
         ENDDO
 20      NITTOT = NITTOT + IT - 1
         NITMAX = MAX(NITMAX, IT - 1)
         IF (IHIST .GT. 0) WRITE(IHIST,'(4ES16.8)') T, TH(N), TH(1),
     1    SINK
      ENDDO
      TSURF = TH(N)
      S = 0.0D0
      DO I = 1, N
         S = S + CAP(I)*TH(I)
      ENDDO
      TMEAN = S/(RHOC*HALF)
      RETURN
      END
!
      PROGRAM K3PLT
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      EXTERNAL FILM, K3_FILMC, K3_FILMB, K3_FILMT
      DIMENSION DTL(6)
      DATA DTL /480.D0, 240.D0, 120.D0, 60.D0, 30.D0, 15.D0/
      OPEN(11, FILE='../verify/plate_c_hist.txt')
      OPEN(12, FILE='../verify/plate_n_hist.txt')
      OPEN(13, FILE='../verify/plate_res_n1.txt')
      OPEN(14, FILE='../verify/plate_res_n0.txt')
      OPEN(15, FILE='../verify/plate_dt.txt')
      OPEN(16, FILE='../verify/plate_res_b1.txt')
      OPEN(17, FILE='../verify/plate_res_b0.txt')
      OPEN(18, FILE='../verify/plate_t_hist.txt')
!     histories at dt = 30 s
      CALL K3_PLATE(K3_FILMC,8,30.D0,3600.D0,150.D0,1,11,0,TS,TM,NT,NM)
      CALL K3_PLATE(FILM,8,30.D0,3600.D0,150.D0,1,12,0,TS,TM,NT,NM)
      CALL K3_PLATE(K3_FILMT,8,30.D0,3600.D0,150.D0,1,18,0,TS,TM,NT,NM)
!     time-step study (surface T, mean T, total its, max its/inc)
      DO K = 1, 7
         DT1 = 1.D0
         IF (K .LE. 6) DT1 = DTL(K)
         CALL K3_PLATE(K3_FILMC,8,DT1,3600.D0,150.D0,1,0,0,TS,TM,NT,NM)
         WRITE(15,'(A,F8.1,2F16.9,2I6)') 'C ', DT1, TS, TM, NT, NM
         CALL K3_PLATE(FILM,8,DT1,3600.D0,150.D0,1,0,0,TS,TM,NT,NM)
         WRITE(15,'(A,F8.1,2F16.9,2I6)') 'N ', DT1, TS, TM, NT, NM
         CALL K3_PLATE(K3_FILMT,8,DT1,3600.D0,150.D0,1,0,0,TS,TM,NT,NM)
         WRITE(15,'(A,F8.1,2F16.9,2I6)') 'T ', DT1, TS, TM, NT, NM
      ENDDO
!     Newton iterations with (ISW2=1) and without (0) H(2)
      DO K = 1, 3
         DTT = 3600.D0
         IF (K .EQ. 2) DTT = 900.D0
         IF (K .EQ. 3) DTT = 300.D0
         DO ISW = 1, 0, -1
            CALL K3_PLATE(FILM,8,DTT,3600.D0,150.D0,ISW,0,0,TS,TM,NT,NM)
            WRITE(15,'(A,F8.1,I3,F16.9,2I6)') 'I ', DTT, ISW, TS, NT, NM
         ENDDO
      ENDDO
      CALL K3_PLATE(FILM,8,3600.D0,3600.D0,150.D0,1,0,13,TS,TM,NT,NM)
      CALL K3_PLATE(FILM,8,3600.D0,3600.D0,150.D0,0,0,14,TS,TM,NT,NM)
!     strongly nonlinear film, 100 s increments
      DO ISW = 1, 0, -1
         CALL K3_PLATE(K3_FILMB,8,100.D0,3600.D0,150.D0,ISW,0,16+1-ISW,
     1    TS,TM,NT,NM)
         WRITE(15,'(A,F8.1,I3,F16.9,2I6)') 'B ', 100.D0, ISW, TS, NT, NM
      ENDDO
      END
