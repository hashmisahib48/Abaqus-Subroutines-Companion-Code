!     Driver: surface dispatch of k3_multi.f and derivative check
      PROGRAM K3MT
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION H(2), H2(2), H3(2), TIME(2), COORDS(3), FIELD(1)
      CHARACTER*80 SNAME, SN(4)
      DATA SN /'ASSEMBLY_VERT_SIDES','TOPF','BOTF','CLAMP'/
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      DO K = 1, 4
         DO TS = 25.0D0, 120.0D0, 19.0D0
            CALL FILM(H,SINK,TS,1,1,TIME,1,1,COORDS,0,FIELD,0,SN(K),0,
     1       0.0D0)
            CALL FILM(H2,SINK,TS+1.0D-4,1,1,TIME,1,1,COORDS,0,FIELD,0,
     1       SN(K),0,0.0D0)
            CALL FILM(H3,SINK,TS-1.0D-4,1,1,TIME,1,1,COORDS,0,FIELD,0,
     1       SN(K),0,0.0D0)
            FD = (H2(1) - H3(1))/2.0D-4
            WRITE(*,'(A12,F7.1,3ES14.5)') SN(K), TS, H(1)*1.D3, H(2)*1.D3
     1       , (FD - H(2))*1.D3
         ENDDO
      ENDDO
!     third branch (Ra > 4.6E6) of K3_HHOR, direct call
      CALL K3_HHOR(60.0D0,20.0D0,0.30D0,1.0D0,HA,DA)
      CALL K3_HHOR(60.0D0+1.0D-4,20.0D0,0.30D0,1.0D0,HB,DB)
      CALL K3_HHOR(60.0D0-1.0D-4,20.0D0,0.30D0,1.0D0,HC,DC)
      WRITE(*,'(A,3ES14.5)') 'UP, L=0.3, dT=60: h, dh, FD-dh ', HA,
     1 DA, (HB-HC)/2.0D-4 - DA
      END
