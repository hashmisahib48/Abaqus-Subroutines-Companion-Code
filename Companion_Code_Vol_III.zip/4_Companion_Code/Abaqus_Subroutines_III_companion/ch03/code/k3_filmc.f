      SUBROUTINE K3_FILMC(H,SINK,TEMP,JSTEP,JINC,TIME,NOEL,NPT,
     1 COORDS,JLTYP,FIELD,NFIELD,SNAME,JUSERNODE,AREA)
!     Constant film coefficient, linearly ramped sink (first FILM)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION H(2), TIME(2), COORDS(3), FIELD(NFIELD)
      CHARACTER*80 SNAME
      PARAMETER (HC = 8.0D-3)       ! mW/(mm^2 K) = 8 W/(m^2 K)
      PARAMETER (T0 = 20.0D0)       ! sink at t = 0, deg C
      PARAMETER (RATE = 30.0D0/3600.0D0)   ! sink rise, K/s
!
      H(1) = HC
      H(2) = 0.0D0
      SINK = T0 + RATE*TIME(2)
      RETURN
      END
!
      SUBROUTINE K3_FILMB(H,SINK,TEMP,JSTEP,JINC,TIME,NOEL,NPT,
     1 COORDS,JLTYP,FIELD,NFIELD,SNAME,JUSERNODE,AREA)
!     Strongly nonlinear film, h = HB*(T - TS)**3 (problem 3C.1)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION H(2), TIME(2), COORDS(3), FIELD(NFIELD)
      CHARACTER*80 SNAME
      PARAMETER (HB = 2.0D-7)       ! mW/(mm^2 K^4)
      PARAMETER (TS = 20.0D0)       ! sink, deg C
!
      DT = TEMP - TS
      H(1) = HB*ABS(DT)**3
      H(2) = 3.0D0*HB*DT*ABS(DT)
      SINK = TS
      RETURN
      END
!
      SUBROUTINE K3_FILMT(H,SINK,TEMP,JSTEP,JINC,TIME,NOEL,NPT,
     1 COORDS,JLTYP,FIELD,NFIELD,SNAME,JUSERNODE,AREA)
!     Churchill-Chu large-Ra limit h ~ dT**(1/3), constant ambient
!     (test of the power-law closed form, Table in section 3.6)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION H(2), TIME(2), COORDS(3), FIELD(NFIELD)
      CHARACTER*80 SNAME
      CALL K3_HCC(TEMP - 20.0D0, 20.0D0, 0.30D0, 0.0D0, HW, DHW)
      H(1) = 1.0D-3*HW
      H(2) = 1.0D-3*DHW
      SINK = 20.0D0
      RETURN
      END
!
      SUBROUTINE K3_FILMF(H,SINK,TEMP,JSTEP,JINC,TIME,NOEL,NPT,
     1 COORDS,JLTYP,FIELD,NFIELD,SNAME,JUSERNODE,AREA)
!     Churchill-Chu film on a vertical fin 60 mm high, ambient 20 C
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION H(2), TIME(2), COORDS(3), FIELD(NFIELD)
      CHARACTER*80 SNAME
      CALL K3_HCC(TEMP - 20.0D0, 20.0D0, 0.060D0, 0.825D0, HW, DHW)
      H(1) = 1.0D-3*HW
      H(2) = 1.0D-3*DHW
      SINK = 20.0D0
      RETURN
      END
