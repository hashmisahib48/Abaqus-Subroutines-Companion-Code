!     Driver: VFILM (blocks) against FILM (one point at a time)
      PROGRAM K3VDRV
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (NB = 136)
      DIMENSION JE(NB), JN(NB), TEMP(NB), FLD(NB,1), CC(NB,3),
     1 AR(NB), HV(NB), SKV(NB), H(2), TIME(2), COORDS(3), FIELD(1)
      CHARACTER*80 SNAME
      DIFFH = 0.0D0
      DIFFS = 0.0D0
      DO KT = 1, 5
         TOT = 900.0D0*KT
         TIME(1) = TOT
         TIME(2) = TOT
         DO K = 1, NB
            TEMP(K) = 20.0D0 + 130.0D0*DBLE(K-1)/DBLE(NB-1)
            JE(K) = K
            JN(K) = 0
         ENDDO
         SNAME = 'PLATE'
         CALL VFILM(NB, 3, 1, KT, TOT, TOT, JE, JN, 1, TEMP, FLD, CC,
     1    AR, 11, SNAME, HV, SKV)
         DO K = 1, NB
            CALL FILM(H, SINK, TEMP(K), 1, KT, TIME, K, 1, COORDS, 11,
     1       FIELD, 0, SNAME, 0, 0.0D0)
            DIFFH = MAX(DIFFH, ABS(H(1) - HV(K))/H(1))
            DIFFS = MAX(DIFFS, ABS(SINK - SKV(K)))
         ENDDO
      ENDDO
      WRITE(*,'(A,ES10.2)') 'max rel diff h    ', DIFFH
      WRITE(*,'(A,ES10.2)') 'max abs diff sink ', DIFFS
      END
