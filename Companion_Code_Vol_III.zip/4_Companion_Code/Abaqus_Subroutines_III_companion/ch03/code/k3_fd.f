!     Driver: hand value, derivative check (central differences) of K3_HCC
      PROGRAM K3FD
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION H(2), TIME(2), COORDS(3), FIELD(1)
      CHARACTER*80 SNAME
      TINF = 20.0D0
      XL = 0.30D0
      CALL K3_HCC(50.0D0, TINF, XL, 0.825D0, HV, DHV)
      WRITE(*,'(A,2ES24.15)') 'HAND dT=50 : h, dh/dT  ', HV, DHV
      CALL K3_HCC(50.0D0, TINF, XL, 0.0D0, HV, DHV)
      WRITE(*,'(A,2ES24.15)') 'A0=0 dT=50 : h, dh/dT  ', HV, DHV
!     finite-difference test of the derivative: dh/dT and d(q)/dT
      WORST1 = 0.0D0
      WORST2 = 0.0D0
      DO I = -400, 400
         DT = 0.25D0*I + 0.123D0
         EPS = 1.0D-5*MAX(1.0D0,ABS(DT))
         CALL K3_HCC(DT, TINF, XL, 0.825D0, H0, D0)
         CALL K3_HCC(DT+EPS, TINF, XL, 0.825D0, HP, DP)
         CALL K3_HCC(DT-EPS, TINF, XL, 0.825D0, HM, DM)
         FD = (HP - HM)/(2.0D0*EPS)
         QP = HP*(DT+EPS)
         QM = HM*(DT-EPS)
         FQ = (QP - QM)/(2.0D0*EPS)
         AQ = H0 + DT*D0
         E1 = ABS(D0-FD)/MAX(ABS(FD),1.0D-3)
         E2 = ABS(AQ-FQ)/ABS(FQ)
         WORST1 = MAX(WORST1,E1)
         WORST2 = MAX(WORST2,E2)
      ENDDO
      WRITE(*,'(A,ES10.2)') 'max rel err dh/dT   ', WORST1
      WRITE(*,'(A,ES10.2)') 'max rel err dq/dT   ', WORST2
!     the FILM routine itself, through the Abaqus-style argument list
      TIME(1) = 0.0D0
      TIME(2) = 1800.0D0
      CALL FILM(H, SINK, 70.0D0, 1, 1, TIME, 1, 1, COORDS, 0, FIELD, 0,
     1 SNAME, 0, 0.0D0)
      WRITE(*,'(A,3ES24.15)') 'FILM T=70,t=1800: H1,H2,SINK ',
     1 H(1), H(2), SINK
!     table for the figure
      OPEN(10, FILE='../verify/out_h_table.txt')
      DO I = -80, 80, 2
         DT = DBLE(I)
         CALL K3_HCC(DT, TINF, XL, 0.825D0, H0, D0)
         CALL K3_HCC(DT, TINF, XL, 0.0D0, H1, D1)
         WRITE(10,'(6ES18.9)') DT, H0, D0, H1, D1
      ENDDO
      CLOSE(10)
      END
