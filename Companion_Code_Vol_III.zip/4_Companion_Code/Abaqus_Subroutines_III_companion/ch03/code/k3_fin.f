!     Driver: steady straight fin, FILM called at every node.
!     Fin: k = 237 mW/(mm K), thickness 3 mm, height w = 60 mm,
!     length 200 mm, base at 120 deg C, tip insulated.
      SUBROUTINE K3_FIN(FSUB, N, ISW2, IOUT, QB, TTIP, NIT)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      EXTERNAL FSUB
      PARAMETER (XK = 237.0D0)   ! mW/(mm K)
      PARAMETER (AC = 180.0D0)   ! cross section 3 x 60, mm^2
      PARAMETER (PER = 120.0D0)  ! film perimeter 2 x 60, mm
      PARAMETER (XLEN = 200.0D0) ! mm
      PARAMETER (TB = 120.0D0)   ! base temperature, deg C
      DIMENSION TH(401), A(401), B(401), C(401), R(401), DTH(401),
     1 TIME(2), COORDS(3), FIELD(1), H(2), WT(401)
      CHARACTER*80 SNAME
      NN = N + 1
      DX = XLEN/N
      G = XK*AC/DX
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      DO I = 1, NN
         TH(I) = TB
         WT(I) = PER*DX
      ENDDO
      WT(1) = 0.5D0*WT(1)
      WT(NN) = 0.5D0*WT(NN)
      NIT = 0
      DO IT = 1, 60
         DO I = 1, NN
            A(I) = 0.0D0
            C(I) = 0.0D0
            B(I) = 0.0D0
            R(I) = 0.0D0
         ENDDO
         QB = 0.0D0
         DO I = 1, NN
            CALL FSUB(H, SINK, TH(I), 1, 1, TIME, 1, 1, COORDS, 0,
     1       FIELD, 0, SNAME, 0, 0.0D0)
            Q = H(1)*(TH(I) - SINK)
            R(I) = WT(I)*Q
            B(I) = WT(I)*(H(1) + ISW2*(TH(I) - SINK)*H(2))
            QB = QB + R(I)
         ENDDO
         DO I = 1, N
            F = G*(TH(I) - TH(I+1))
            R(I) = R(I) + F
            R(I+1) = R(I+1) - F
            B(I) = B(I) + G
            B(I+1) = B(I+1) + G
            C(I) = -G
            A(I+1) = -G
         ENDDO
!        node 1: prescribed temperature
         R(1) = 0.0D0
         B(1) = 1.0D0
         C(1) = 0.0D0
         RMAX = 0.0D0
         DO I = 2, NN
            RMAX = MAX(RMAX, ABS(R(I)))
         ENDDO
         IF (IOUT .GT. 0) WRITE(IOUT,'(I4,ES16.8)') IT-1, RMAX
         IF (RMAX .LT. 1.0D-9) GOTO 20
         DO I = 1, NN
            DTH(I) = -R(I)
         ENDDO
         DO I = 2, NN
            W = A(I)/B(I-1)
            B(I) = B(I) - W*C(I-1)
            DTH(I) = DTH(I) - W*DTH(I-1)
         ENDDO
         DTH(NN) = DTH(NN)/B(NN)
         DO I = NN-1, 1, -1
            DTH(I) = (DTH(I) - C(I)*DTH(I+1))/B(I)
         ENDDO
         DO I = 1, NN
            TH(I) = TH(I) + DTH(I)
         ENDDO
      ENDDO
 20   NIT = IT - 1
!     heat entering the base = film loss over the whole fin
      TTIP = TH(NN)
      IF (IOUT .LT. 0) THEN
         DO I = 1, NN
            WRITE(-IOUT,'(2ES18.9)') DX*(I-1), TH(I)
         ENDDO
      ENDIF
      RETURN
      END
!
      PROGRAM K3FINP
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      EXTERNAL K3_FILMC, K3_FILMF
      OPEN(21, FILE='../verify/fin_c_prof.txt')
      OPEN(22, FILE='../verify/fin_n_prof.txt')
      OPEN(23, FILE='../verify/fin_res1.txt')
      OPEN(24, FILE='../verify/fin_res0.txt')
      OPEN(25, FILE='../verify/fin_table.txt')
      DO N = 10, 160, 150
         NH = N
         CALL K3_FIN(K3_FILMC,N,1,0,QB,TT,NIT)
         WRITE(25,'(A,I5,2ES20.10,I4)') 'C', N, QB, TT, NIT
      ENDDO
      DO N = 10, 160, 30
         CALL K3_FIN(K3_FILMC,N,1,0,QB,TT,NIT)
         WRITE(25,'(A,I5,2ES20.10,I4)') 'C', N, QB, TT, NIT
      ENDDO
      CALL K3_FIN(K3_FILMC,40,1,-21,QB,TT,NIT)
      CALL K3_FIN(K3_FILMF,40,1,-22,QB,TT,NIT)
      DO N = 10, 160, 30
         CALL K3_FIN(K3_FILMF,N,1,0,QB,TT,NIT)
         WRITE(25,'(A,I5,2ES20.10,I4)') 'N', N, QB, TT, NIT
         CALL K3_FIN(K3_FILMF,N,0,0,QB,TT,NI0)
         WRITE(25,'(A,I5,2ES20.10,I4)') 'M', N, QB, TT, NI0
      ENDDO
      CALL K3_FIN(K3_FILMF,40,1,23,QB,TT,NIT)
      CALL K3_FIN(K3_FILMF,40,0,24,QB,TT,NIT)
      END
