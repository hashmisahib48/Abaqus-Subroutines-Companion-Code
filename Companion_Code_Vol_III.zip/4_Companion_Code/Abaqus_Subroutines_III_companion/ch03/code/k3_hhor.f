      SUBROUTINE K3_HHOR(DTS, TINF, XL, UP, H, DH)
!     Horizontal plate, XL = area/perimeter (m).  UP = 1: heated
!     surface faces up (or cooled faces down); UP = 0: the other case.
!     UP: Nu = max(0.54 Ra**(1/4), 0.15 Ra**(1/3));  else 0.27 Ra**(1/4)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (DTMIN = 1.0D-2)       ! K
!
      CALL K3_PROP(TINF, XL, XK, PR, RA1)
      DTE = SQRT(DTS*DTS + DTMIN*DTMIN)
      RA = RA1*DTE
      DRA = RA1*DTS/DTE                 ! dRa/d(surface temperature)
      XN = 0.27D0*RA**0.25D0
      DN = 0.25D0*XN/RA*DRA
      IF (UP .GT. 0.5D0) THEN
         XN = 0.54D0*RA**0.25D0
         DN = 0.25D0*XN/RA*DRA
         X3 = 0.15D0*RA**(1.0D0/3.0D0)
         IF (X3 .GT. XN) THEN
            XN = X3
            DN = X3/(3.0D0*RA)*DRA
         ENDIF
      ENDIF
      H = XN*XK/XL
      DH = DN*XK/XL
      RETURN
      END
