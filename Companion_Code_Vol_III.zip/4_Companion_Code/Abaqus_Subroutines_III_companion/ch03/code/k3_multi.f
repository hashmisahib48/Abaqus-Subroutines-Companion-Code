      SUBROUTINE FILM(H,SINK,TEMP,JSTEP,JINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,FIELD,NFIELD,SNAME,JUSERNODE,AREA)
!     Several film surfaces selected by name (surface-based *SFILM)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION H(2), TIME(2), COORDS(3), FIELD(NFIELD)
      CHARACTER*80 SNAME
      PARAMETER (TAMB = 20.0D0)     ! ambient, deg C
      PARAMETER (UNIT = 1.0D-3)     ! W/(m^2 K) -> mW/(mm^2 K)
!
      SINK = TAMB
      H(1) = 0.0D0
      H(2) = 0.0D0
      IF (INDEX(SNAME,'VERT') .GT. 0) THEN
         CALL K3_HCC(TEMP - TAMB, TAMB, 0.30D0, 0.825D0, HW, DHW)
      ELSE IF (INDEX(SNAME,'TOPF') .GT. 0) THEN
         CALL K3_HHOR(TEMP - TAMB, TAMB, 0.05D0, 1.0D0, HW, DHW)
      ELSE IF (INDEX(SNAME,'BOTF') .GT. 0) THEN
         CALL K3_HHOR(TEMP - TAMB, TAMB, 0.05D0, 0.0D0, HW, DHW)
      ELSE
         HW = 15.0D0                ! other surfaces: forced, W/(m^2 K)
         DHW = 0.0D0
      ENDIF
      H(1) = UNIT*HW
      H(2) = UNIT*DHW
      RETURN
      END
