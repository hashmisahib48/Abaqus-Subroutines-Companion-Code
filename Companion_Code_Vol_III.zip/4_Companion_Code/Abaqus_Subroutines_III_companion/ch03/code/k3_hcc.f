      SUBROUTINE K3_PROP(TINF, XL, XK, PR, RA1)
!     Air at ambient temperature TINF (deg C), ideal gas at 1 atm
!     XK  = conductivity, W/(m K);  PR = Prandtl number
!     RA1 = Rayleigh number per kelvin of temperature difference
!           for a surface of characteristic length XL (m)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (GRAV = 9.81D0)        ! m/s^2
      PARAMETER (CPAIR = 1007.0D0)     ! J/(kg K)
      PARAMETER (PATM = 101325.0D0)    ! Pa
      PARAMETER (RGAS = 287.05D0)      ! J/(kg K)
!
      TK = TINF + 273.15D0
      XMU = 1.716D-5*(TK/273.15D0)**1.5D0*(273.15D0 + 110.4D0)
     1      /(TK + 110.4D0)                         ! Pa s
      XK = 0.0241D0*(TK/273.15D0)**1.5D0*(273.15D0 + 194.0D0)
     1      /(TK + 194.0D0)                         ! W/(m K)
      RHO = PATM/(RGAS*TK)                          ! kg/m^3
      PR = XMU*CPAIR/XK
      RA1 = GRAV*XL**3*RHO**2*CPAIR/(TK*XMU*XK)
      RETURN
      END
!
      SUBROUTINE K3_HCC(DTS, TINF, XL, A0, H, DH)
!     Vertical plate, Churchill-Chu: h = (k/L)*(A0 + C1*Ra**(1/6))**2
!     DTS = surface minus ambient temperature (K)    [in]
!     A0  = 0.825 (full law) or 0 (large-Ra limit)   [in]
!     H   = film coefficient, W/(m^2 K)              [out]
!     DH  = dH/d(surface temperature), W/(m^2 K^2)   [out]
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (DTMIN = 1.0D-2)       ! K, smoothing of |dT|
!
      CALL K3_PROP(TINF, XL, XK, PR, RA1)
      C1 = 0.387D0/(1.0D0 + (0.492D0/PR)**(9.0D0/16.0D0))
     1      **(8.0D0/27.0D0)
      DTE = SQRT(DTS*DTS + DTMIN*DTMIN)             ! smooth |dT|
      S = (RA1*DTE)**(1.0D0/6.0D0)                  ! Ra**(1/6)
      B = A0 + C1*S
      H = XK/XL*B*B
      DH = XK/XL*2.0D0*B*C1*S/(6.0D0*DTE)*(DTS/DTE)
      RETURN
      END
