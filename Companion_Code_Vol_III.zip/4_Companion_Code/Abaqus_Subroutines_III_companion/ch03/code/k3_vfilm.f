      SUBROUTINE VFILM(NBLOCK,NDIM,KSTEP,KINC,STEPTIME,TOTALTIME,
     1 JELEMUID,JNODEUID,NUMEXFV,TEMP,FIELD,CURCOORDS,AREANODE,
     2 JLTYP,SNAME,H,SINK)
!     Vector form of the natural-convection film of Listing 3.3
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION JELEMUID(NBLOCK), JNODEUID(NBLOCK), TEMP(NBLOCK),
     1 FIELD(NBLOCK,NUMEXFV), CURCOORDS(NBLOCK,NDIM),
     2 AREANODE(NBLOCK), H(NBLOCK), SINK(NBLOCK)
      CHARACTER*80 SNAME
      PARAMETER (T0 = 20.0D0)       ! ambient at t = 0, deg C
      PARAMETER (T1 = 50.0D0)       ! ambient at t = TRAMP, deg C
      PARAMETER (TRAMP = 3600.0D0)  ! s
      PARAMETER (XL = 0.30D0)       ! plate height, m
      PARAMETER (A0 = 0.825D0)      ! Churchill-Chu constant
      PARAMETER (UNIT = 1.0D-3)     ! W/(m^2 K) -> mW/(mm^2 K)
!
      TIN = T0 + (T1 - T0)*MIN(TOTALTIME/TRAMP, 1.0D0)
      DO K = 1, NBLOCK
         CALL K3_HCC(TEMP(K) - TIN, TIN, XL, A0, HW, DHW)
         H(K) = UNIT*HW             ! mW/(mm^2 K)
         SINK(K) = TIN              ! deg C
      ENDDO
      RETURN
      END
