import numpy as np, json
from ref import *
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
R={}
# ---- plate time-step study
rows=[l.split() for l in open('plate_dt.txt')]
dts={}
for r in rows:
    if r[0] in 'CNT': dts.setdefault(r[0],[]).append((float(r[1]),float(r[2]),float(r[3]),int(r[4]),int(r[5])))
ex={'C':lumped_const(3600.),'N':lumped_nl(3600.).sol(3600.)[0],'T':lumped_power(3600.)[0]}
R['exact']=ex
for key in 'CNT':
    print(key,'exact',ex[key])
    prev=None
    for dt,ts,tm,nt,nm in dts[key]:
        e=tm-ex[key]
        o='' if prev is None or dt==1.0 else '%.2f'%np.log2(prev/e)
        print('  dt=%6.1f  Tmean=%.6f  err=%.5f  Ts-Tm=%.2e order=%s its=%d'%(dt,tm,e,ts-tm,o,nt)); prev=e
    R['dt_'+key]=dts[key]
# ---- Newton iteration study
for r in rows:
    if r[0] in 'IB': print(r)
# ---- fin
kk,Ac,P,Lf,Tb=237.,180.,120.,200.,120.
def fin_const(h=8e-3):
    m=np.sqrt(h*P/(kk*Ac)); th=Tb-20
    return np.sqrt(h*P*kk*Ac)*th*np.tanh(m*Lf), th/np.cosh(m*Lf)+20, m
print('fin const',fin_const())
def hq(th,L=0.06):
    return hcc(th,20.,L,0.825)[0]*1e-3*th
def shoot(tt):
    f=lambda x,y:[y[1],P*hq(y[0]-20)/(kk*Ac)]
    s=solve_ivp(f,[Lf,0],[tt,0.0],method='DOP853',rtol=1e-12,atol=1e-12)
    return s.y[0,-1],s.y[1,-1]
tt=brentq(lambda t:shoot(t)[0]-Tb,30.,Tb-0.01,xtol=1e-12)
th0,dth0=shoot(tt)
print('fin NL tip',tt,'Qb',-kk*Ac*dth0)
R['fin_c']=fin_const(); R['fin_n']=(-kk*Ac*dth0,tt)
rows=[l.split() for l in open('fin_table.txt')]
for r in rows: print(r)
# Biot / lumped checks
print('Bi',8e-3*2.5/237)
json.dump(R,open('results.json','w'),default=float)
