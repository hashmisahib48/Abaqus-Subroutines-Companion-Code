import sys; sys.path.insert(0,'/home/claude/vol3/lib'); sys.path.insert(0,'/home/claude/vol3/ch03/verify')
from figstyle import *
import numpy as np, matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, Polygon
from ref import *
import os; os.chdir('/home/claude/vol3/ch03')
FS=7.8
def tx(ax,x,y,s,fs=FS,**k):
    k.setdefault('fontsize',fs); ax.text(x,y,s,**k)

# ---------- Fig 3.2-1  film condition and Newton linearisation
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.3),dpi=240,gridspec_kw={'width_ratios':[1,1.1]})
a1.set_aspect('equal'); a1.axis('off'); a1.set_xlim(-0.2,6.2); a1.set_ylim(-0.9,4.6)
a1.add_patch(Rectangle((0,0),2.3,3.6,fc=LB,ec=BLUE,lw=1))
tx(a1,1.15,1.8,'body\n$\\theta$',ha='center',va='center',color=NAVY,fs=9)
for y in (0.6,1.8,3.0): arr(a1,(2.35,y),(3.7,y),c=RED,lw=1.2,ms=7)
tx(a1,3.1,3.85,'$q=h\\,(\\theta-\\theta_s)$',ha='center',color=RED,fs=8.4)
a1.plot([3.95,3.95],[0,3.6],color=GREY,lw=0.8,ls='--')
tx(a1,4.1,1.8,'sink\n$\\theta_s(t)$',ha='left',va='center',color=GREY,fs=8.4)
tx(a1,2.9,-0.75,'(a) flux leaves the body',ha='center',color=GREY,fs=7.6)
th=np.linspace(20,150,200); ts=20.
hq=np.array([hcc(x-ts,ts,0.3)[0] for x in th]); q=hq*(th-ts)
a2.plot(th,q,color=BLUE,lw=1.4)
t0=110.; h0,_,_,_=hcc(t0-ts,ts,0.3); q0=h0*(t0-ts); eps=1e-4
dq=(hcc(t0-ts+eps,ts,0.3)[0]*(t0-ts+eps)-hcc(t0-ts-eps,ts,0.3)[0]*(t0-ts-eps))/(2*eps)
xs=np.array([40,150]); a2.plot(xs,q0+dq*(xs-t0),color=RED,lw=1,ls='-')
a2.plot(xs,q0+h0*(xs-t0),color=OR,lw=1,ls='--')
a2.plot([ts,t0],[0,q0],color=GREY,lw=0.7,ls=':')
a2.plot(t0,q0,'o',color=NAVY,ms=3.5)
tx(a2,38,900,'tangent: $H(1)+(\\theta-\\theta_s)H(2)$',color=RED,ha='left',va='center',fs=7.6)
tx(a2,38,800,'slope $H(1)$ only',color=OR,ha='left',va='center',fs=7.6)
tx(a2,118,150,'dotted: secant $h$',color=GREY,ha='left',fs=7.6)
a2.set_xlabel('surface temperature $\\theta$  ($^\\circ$C)\n(b) the Newton slope of the film',fontsize=8); a2.set_ylabel('$q$  (W/m$^2$)',fontsize=8); a2.tick_params(labelsize=7.4)
a2.set_xlim(20,150); a2.set_ylim(0,1000)
fig.subplots_adjust(wspace=0.32); save(fig,'fig_film.png')

# ---------- Fig 3.3-1  call sequence flowchart
fig,ax=plt.subplots(figsize=(4.9,2.35),dpi=240); ax.set_xlim(-2,101); ax.set_ylim(-3,48); ax.axis('off')
def bx(x,y,w,h,t,fc=LB,ec=BLUE,tc=NAVY,fs=7.6,b=False): box(ax,x,y,w,h,t,fc=fc,ec=ec,fs=fs,tc=tc,bold=b,r=1.2)
def ar(p,q,c=GREY): arr(ax,p,q,c=c,lw=0.9,ms=6)
bx(0,31,29,14,'estimate $\\theta$ at each\nsurface point\n(TEMP), time $t_{n+1}$')
bx(35,31,29,14,'FILM\nuser code',fc='#FDF0E0',ec=OR,b=True)
bx(70,31,30,14,'$H(1)$, $H(2)$, SINK\n$q=H(1)(\\theta-\\mathrm{SINK})$',fc=LB,fs=7.4)
bx(70,9,30,15,'film terms of $R$, $K$:\n$\\partial q/\\partial\\theta=H(1)$\n$+(\\theta-\\mathrm{SINK})H(2)$',fc=LB,fs=7.2)
bx(35,9,29,15,'solve\n$K\\,\\Delta\\theta=-R$\n$\\theta\\leftarrow\\theta+\\Delta\\theta$',fc=LB)
bx(0,9,29,15,'converged?',fc='#E3F4EA',ec=GREEN,b=True)
ar((29,38),(35,38)); ar((64,38),(70,38)); ar((85,31),(85,24)); ar((70,16.5),(64,16.5)); ar((35,16.5),(29,16.5))
ar((14.5,24),(14.5,31)); tx(ax,16,27.2,'no',color=GREY,ha='left',fs=7.6)
ar((14.5,9),(14.5,2)); tx(ax,16,3,'yes: next increment',color=GREEN,ha='left',fs=7.6,va='center')
save(fig,'fig_flow.png')

# ---------- Fig 3.4-1  h and derivative
D=np.loadtxt('verify/out_h_table.txt')
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.2),dpi=240)
m=D[:,0]!=0
a1.plot(D[:,0],D[:,1],color=BLUE,lw=1.4,label='$A_0=0.825$'); a1.plot(D[:,0],D[:,3],color=OR,lw=1.2,ls='--',label='$A_0=0$ ($\\Delta T^{1/3}$)')
a1.set_xlabel('$\\Delta\\theta=\\theta-\\theta_s$  (K)\n(a) film coefficient',fontsize=8); a1.set_ylabel('$h$  (W/m$^2$K)',fontsize=8); a1.tick_params(labelsize=7.4); a1.legend(fontsize=7.2,loc='upper center',handlelength=1.6)
a1.set_ylim(0,9.5); dh_fd=np.gradient(D[:,1],D[:,0])
a2.plot(D[:,0],D[:,2],color=BLUE,lw=1.4,label='$\\partial h/\\partial\\theta$ (routine)')
a2.plot(D[::5,0],np.gradient(D[:,1],D[:,0])[::5],'o',color=RED,ms=2.8,mfc='none',label='central difference')
a2.set_xlabel('$\\Delta\\theta$  (K)\n(b) derivative $H(2)$',fontsize=8); a2.set_ylabel('$\\partial h/\\partial\\theta$  (W/m$^2$K$^2$)',fontsize=8); a2.tick_params(labelsize=7.4); a2.legend(fontsize=7.2,loc='upper center',handlelength=1.6)
a2.set_ylim(-0.25,0.28); a2.axhline(0,color=GRID,lw=0.6); fig.subplots_adjust(wspace=0.4); save(fig,'fig_h.png')

# ---------- Fig 3.5-1  plate results
C=np.loadtxt('verify/plate_c_hist.txt'); N=np.loadtxt('verify/plate_n_hist.txt')
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.25),dpi=240)
a1.plot(N[:,0]/60,np.where(N[:,0]==0,20.,N[:,3]),color=GREY,lw=1,ls=':',label='sink $\\theta_s(t)$')
a1.plot(C[:,0]/60,C[:,1],color=OR,lw=1.3,label='constant $h=8$')
a1.plot(N[:,0]/60,N[:,1],color=BLUE,lw=1.3,label='Churchill–Chu $h(\\Delta\\theta)$')
tt=np.linspace(0,3600,13); s=lumped_nl(3600.)
a1.plot(tt/60,s.sol(tt)[0],'o',color=RED,ms=2.8,mfc='none',label='lumped reference')
a1.plot(tt/60,lumped_const(tt),'o',color=RED,ms=2.8,mfc='none')
a1.set_xlabel('time  (min)\n(a) histories, $\\Delta t=30$ s',fontsize=8); a1.set_ylabel('surface temperature  ($^\\circ$C)',fontsize=8); a1.tick_params(labelsize=7.4); a1.legend(fontsize=7,loc='upper right',handlelength=1.5)
rows=[l.split() for l in open('verify/plate_dt.txt') if l[0] in 'CNT']
ex={'C':lumped_const(3600.),'N':s.sol(3600.)[0],'T':lumped_power(3600.)[0]}
lab={'C':('constant $h$',OR,'s'),'N':('Churchill–Chu',BLUE,'o'),'T':('$h\\propto\\Delta\\theta^{1/3}$',GREEN,'^')}
for k in 'CNT':
    pts=[(float(r[1]),abs(float(r[3])-ex[k])) for r in rows if r[0]==k]
    a2.loglog([p[0] for p in pts],[p[1] for p in pts],marker=lab[k][2],color=lab[k][1],ms=3.2,lw=1,label=lab[k][0])
dd=np.array([1,480]); a2.loglog(dd,0.0112*dd,color=GREY,lw=0.7,ls='--'); tx(a2,60,0.0112*60*0.42,'slope 1',color=GREY,fs=7.2,rotation=35)
a2.set_xlabel('time increment $\\Delta t$  (s)\n(b) error of the driver',fontsize=8); a2.set_ylabel('error at 3600 s  (K)',fontsize=8); a2.tick_params(labelsize=7.4); a2.legend(fontsize=7,loc='lower right',handlelength=1.5)
fig.subplots_adjust(wspace=0.38); save(fig,'fig_plate.png')

# ---------- Fig 3.6-1 Newton convergence
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.2),dpi=240)
def rd(f): return np.loadtxt(f)
for ax,(f1,f0,title) in zip((a1,a2),(('verify/plate_res_n1.txt','verify/plate_res_n0.txt','(a) Churchill–Chu, $\\Delta t=3600$ s'),('verify/plate_res_b1.txt','verify/plate_res_b0.txt','(b) $h\\propto\\Delta\\theta^{3}$, $\\Delta t=100$ s'))):
    d1=rd(f1); d0=rd(f0)[:16]
    ax.semilogy(d1[:,0],d1[:,1],'o-',color=BLUE,ms=3,lw=1,label='with $H(2)$')
    ax.semilogy(d0[:,0],d0[:,1],'s-',color=RED,ms=3,lw=1,label='$H(2)=0$')
    ax.axhline(1e-9,color=GREY,lw=0.6,ls=':'); ax.set_xlabel('iteration\n'+title,fontsize=8); ax.tick_params(labelsize=7.4)
    ax.legend(fontsize=7.2,handlelength=1.5,loc='upper right' if ax is a1 else 'lower right'); ax.set_ylim(1e-11,1e3)
a1.set_ylabel('max residual  (mW/mm$^2$)',fontsize=8); fig.subplots_adjust(wspace=0.32); save(fig,'fig_newton.png')

# ---------- Fig 3.7-1 fin
fig,(a2,a1)=plt.subplots(1,2,figsize=(4.9,2.25),dpi=240)
xx=np.linspace(0,200,201); m=np.sqrt(8e-3*120/(237*180))
a2.plot(xx,20+100*np.cosh(m*(200-xx))/np.cosh(m*200),color=OR,lw=1.3,label='constant $h=8$ (closed form)')
Fc=np.loadtxt('verify/fin_c_prof.txt'); Fn=np.loadtxt('verify/fin_n_prof.txt')
from scipy.integrate import solve_ivp
kk,Ac,P,Lf=237.,180.,120.,200.
hq=lambda th:hcc(th,20.,0.06,0.825)[0]*1e-3*th
tt=87.06578611677432
s=solve_ivp(lambda x,y:[y[1],P*hq(y[0]-20)/(kk*Ac)],[Lf,0],[tt,0.0],method='DOP853',rtol=1e-11,atol=1e-11,dense_output=True)
a2.plot(xx,s.sol(xx)[0],color=BLUE,lw=1.3,label='Churchill–Chu (shooting)')
a2.plot(Fn[::4,0],Fn[::4,1],'o',color=RED,ms=2.6,mfc='none',label='driver, 40 elements')
a2.plot(Fc[::4,0],Fc[::4,1],'o',color=RED,ms=2.6,mfc='none')
a2.set_xlabel('distance from base  (mm)\n(a) temperature along the fin',fontsize=8); a2.set_ylabel('temperature  ($^\\circ$C)',fontsize=8); a2.tick_params(labelsize=7.4); a2.legend(fontsize=7,loc='upper right',handlelength=1.5)
a2.set_ylim(75,125)
rows=[l.split() for l in open('verify/fin_table.txt')]
qc=14959.591912912134; qn=15414.61612840027
for key,ex,col,mk,lab in (('C',qc,OR,'s','constant $h$'),('N',qn,BLUE,'o','Churchill–Chu')):
    pts=sorted(set((int(r[1]),abs(float(r[2])/ex-1)) for r in rows if r[0]==key))
    a1.loglog([p[0] for p in pts],[p[1] for p in pts],marker=mk,color=col,ms=3.2,lw=1,label=lab)
nn=np.array([10,160]); a1.loglog(nn,0.0009*(10/nn)**2,color=GREY,lw=0.7,ls='--'); tx(a1,16,0.0009*(10/16)**2*0.3,'slope $-2$',color=GREY,fs=7.2,rotation=-33)
a1.set_xlabel('number of elements\n(b) error of the heat loss $Q$',fontsize=8); a1.set_ylabel('relative error of $Q$',fontsize=8); a1.tick_params(labelsize=7.4); a1.legend(fontsize=7,loc='lower left',handlelength=1.5)
fig.subplots_adjust(wspace=0.4); save(fig,'fig_fin.png')
print('figs ok')
