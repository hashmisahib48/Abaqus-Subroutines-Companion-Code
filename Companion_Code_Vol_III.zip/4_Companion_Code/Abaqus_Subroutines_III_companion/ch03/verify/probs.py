from ref import *
import numpy as np
from scipy.integrate import solve_ivp
# A.1
h,Ra,Pr,Nu=hcc(50.,25.,0.5)
eps=1e-4; dh=(hcc(50+eps,25.,0.5)[0]-hcc(50-eps,25.,0.5)[0])/(2*eps)
print('A1 Ra=%.4e Pr=%.4f Nu=%.3f h=%.4f dh=%.5f'%(Ra,Pr,Nu,h,dh), 'mW units',h*1e-3,dh*1e-3)
# A.2 steel 10 mm, ell=5 mm, h=10
rho=7.85e-9; c=4.6e8; k=45.; ell=5.; hh=10e-3
tau=rho*c*ell/hh; Bi=hh*ell/k; t=tau*np.log(180/10)
print('A2 tau=%.1f Bi=%.2e t(180->10)=%.1f s=%.1f min  rhoc=%.3f'%(tau,Bi,t,t/60,rho*c))
# A.3
h0,h1=10.,0.02; th=200.; ts=20.
hv=h0+h1*th; q=hv*(th-ts); J=hv+(th-ts)*h1
print('A3 h=%.2f q=%.1f J=%.2f ratio=%.3f'%(hv,q,J,J/hv))
# B.1
print('B1 ratios', 50*0.03481436578683450/5.803818982691333, 50*0.03132523905128080/4.698786045643554)
# B.3 backward Euler lumped
tau=rhoc*hh/8e-3 if False else 2.43*2.5/8e-3
for dt in (60.,30.):
    lam=dt/tau; th=150.; 
    for n in range(int(3600/dt)):
        ts=20+30*(n+1)*dt/3600; th=(th+lam*ts)/(1+lam)
    print('B3 dt',dt,th, th-lumped_const(3600.))
print('exact',lumped_const(3600.))
# C.1 mixed convection
hf=12.
def f(t,y):
    ts=20+30*min(t/3600,1); dT=y[0]-ts
    hn=hcc(dT,ts,0.3)[0]; hm=(hn**3+hf**3)**(1/3)
    return [-hm*1e-3*dT/(2.43*2.5)]
s=solve_ivp(f,[0,3600],[150.],method='DOP853',rtol=1e-12,atol=1e-12)
print('C1 mixed T(3600)=',s.y[0,-1])
hn=hcc(100,20.,.3)[0]; print('hn(100)=',hn, (hn**3+hf**3)**(1/3))
# C.2
for dT in (10,30,50,80):
    a=hcc(dT,20.,0.3)[0]; b=hcc(dT,20.,0.3,Tprop=20+dT/2,beta_T=293.15+dT/2)[0]
    print('C2',dT,round(a,3),round(b,3),round((a/b-1)*100,2))
# example numbers
print('h at 130K',hcc(130,20,.3)[0],'at 20K..',hcc(30,50,.3)[0])
print('Ra(50K,0.3)',hcc(50,20,.3)[1])
# h at start/end of plate example
print('start',hcc(130.,20.,.3)[0],'end',hcc(46.4-50,50.,.3)[0])
