import sys; sys.path.insert(0,'/home/claude/vol3/lib'); sys.path.insert(0,'/home/claude/vol3/ch03/verify')
from figstyle import *
import numpy as np, matplotlib.pyplot as plt, os
from matplotlib.patches import Rectangle
from ref import *
os.chdir('/home/claude/vol3/ch03')
def tx(ax,x,y,s,fs=8,**k): k.setdefault('fontsize',fs); ax.text(x,y,s,**k)
# A1 vertical plate
fig,ax=new(2.0,2.0); ax.set_xlim(-2.5,6); ax.set_ylim(-1,11)
ax.add_patch(Rectangle((0,0),0.6,10,fc=LB,ec=BLUE,lw=1))
for y in (1.5,4,6.5,9): arr(ax,(0.9,y),(1.5,y+1.2),c=RED,lw=0.9,ms=6); arr(ax,(0.9,y+0.6),(1.6,y+2.2),c=RED,lw=0.9,ms=6)
ax.annotate('',xy=(-0.9,10),xytext=(-0.9,0),arrowprops=dict(arrowstyle='<->',color=GREY,lw=0.7)); tx(ax,-1.15,5,'$L$ = 0.5 m',rotation=90,va='center',ha='right',color=GREY)
tx(ax,0.3,-0.9,'$\\theta_s$ = 75 $^\\circ$C',ha='center',color=NAVY,fs=8.4); tx(ax,4.0,10.9,'air, $\\theta_\\infty$ = 25 $^\\circ$C',ha='center',color=GREY,fs=8.4)
tx(ax,3.6,3.5,'rising\nplume',color=RED,fs=8,ha='center'); save(fig,'p_3A1.png')
# A2 steel plate
fig,ax=new(2.3,1.8); ax.set_xlim(-3,9); ax.set_ylim(-3,5)
ax.add_patch(Rectangle((0,-1.5),1.0,5,fc=LB,ec=BLUE,lw=1)); 
for y in (-0.5,1,2.5): arr(ax,(1.05,y),(2.6,y),c=RED,lw=0.9,ms=6); arr(ax,(-0.05,y),(-1.6,y),c=RED,lw=0.9,ms=6)
tx(ax,0.5,0.9,'steel',rotation=90,ha='center',va='center',color=NAVY,fs=8)
tx(ax,3.3,2.5,'$h$ = 10 W/m$^2$K',color=RED,fs=8.4,va='center'); tx(ax,3.3,1,'$\\theta_s$ = 20 $^\\circ$C',color=GREY,fs=8.4,va='center')
ax.annotate('',xy=(1,-2.2),xytext=(0,-2.2),arrowprops=dict(arrowstyle='<->',color=GREY,lw=0.7)); tx(ax,0.5,-3.0,'10 mm',ha='center',color=GREY,fs=8)
tx(ax,3.3,-0.7,'$\\theta_0$ = 200 $^\\circ$C',color=NAVY,fs=8.4,va='center'); save(fig,'p_3A2.png')
# A3 q(theta)
fig,ax=plt.subplots(figsize=(2.2,1.65),dpi=240)
th=np.linspace(20,300,100); q=(10+0.02*th)*(th-20)
ax.plot(th,q,color=BLUE,lw=1.4); t0=200; q0=(10+0.02*t0)*(t0-20); J=(10+0.02*t0)+(t0-20)*0.02
ax.plot(th,q0+J*(th-t0),color=RED,lw=0.9,ls='--'); ax.plot(t0,q0,'o',color=NAVY,ms=3.5)
ax.set_xlabel('$\\theta$  ($^\\circ$C)',fontsize=8); ax.set_ylabel('$q$  (W/m$^2$)',fontsize=8); ax.tick_params(labelsize=7.4); ax.set_ylim(0,6000)
tx(ax,30,5200,'$h=10+0.02\\,\\theta$ W/m$^2$K,  $\\theta_s$ = 20 $^\\circ$C',color=NAVY,fs=7.6); tx(ax,200,q0-700,'$\\theta$ = 200 $^\\circ$C',color=NAVY,ha='left',fs=7.6); save(fig,'p_3A3.png')
# B1 ratio
fig,ax=plt.subplots(figsize=(2.2,1.65),dpi=240)
dT=np.linspace(0.5,100,300)
for A0,c,l in ((0.825,BLUE,'$A_0=0.825$'),(0,OR,'$A_0=0$')):
    r=[]
    for d in dT:
        e=1e-5; h=hcc(d,20.,0.3,A0,dtmin=0)[0]; dh=(hcc(d+e,20.,0.3,A0,dtmin=0)[0]-hcc(d-e,20.,0.3,A0,dtmin=0)[0])/(2*e); r.append(d*dh/h)
    ax.plot(dT,r,color=c,lw=1.3,label=l)
ax.axhline(1/3,color=GREY,lw=0.6,ls=':'); ax.set_ylim(0,0.4)
ax.set_xlabel('$\\Delta\\theta$  (K)',fontsize=8); ax.set_ylabel('$\\Delta\\theta\\,H(2)/H(1)$',fontsize=8); ax.tick_params(labelsize=7.4); ax.legend(fontsize=7.4,loc='lower right',handlelength=1.5); save(fig,'p_3B1.png')
# B3 BE staircase
fig,ax=plt.subplots(figsize=(2.2,1.65),dpi=240)
tt=np.linspace(0,3600,200); ax.plot(tt/60,lumped_const(tt),color=BLUE,lw=1.3,label='exact, Eq. 3.2-5')
tau=2.43*2.5/8e-3; dt=240.; th=150.; ts_=[0];ys=[150.]
for n in range(int(3600/dt)):
    t1=(n+1)*dt; Ts=20+30*t1/3600; th=(th+dt/tau*Ts)/(1+dt/tau); ts_.append(t1); ys.append(th)
ax.plot(np.array(ts_)/60,ys,'s-',color=RED,ms=2.8,lw=0.8,label='backward Euler, $\\Delta t$ = 240 s')
ax.plot(tt/60,20+30*tt/3600,color=GREY,lw=0.8,ls=':',label='sink')
ax.set_xlabel('time  (min)',fontsize=8); ax.set_ylabel('$\\theta$  ($^\\circ$C)',fontsize=8); ax.tick_params(labelsize=7.4); ax.legend(fontsize=7,handlelength=1.5); save(fig,'p_3B3.png')
# C1 mixed
fig,ax=plt.subplots(figsize=(2.2,1.65),dpi=240)
dT=np.linspace(0.5,130,200); hn=np.array([hcc(d,20.,0.3)[0] for d in dT])
ax.plot(dT,hn,color=BLUE,lw=1.2,label='natural $h_n$'); ax.plot(dT,0*dT+12,color=OR,lw=1.2,label='forced $h_f$ = 12'); ax.plot(dT,(hn**3+12**3)**(1/3),color=RED,lw=1.4,label='$(h_n^3+h_f^3)^{1/3}$')
ax.set_xlabel('$\\Delta\\theta$  (K)',fontsize=8); ax.set_ylabel('$h$  (W/m$^2$K)',fontsize=8); ax.tick_params(labelsize=7.4); ax.set_ylim(0,16); ax.legend(fontsize=7,loc='center right',bbox_to_anchor=(1,0.42),handlelength=1.5); save(fig,'p_3C1.png')
# C2 boundary layer / film temperature
fig,ax=plt.subplots(figsize=(2.2,1.65),dpi=240)
y=np.linspace(0,1,100); T=1-np.exp(-5*y)*(1+0*y)
ax.plot(y,T,color=BLUE,lw=1.4); ax.axhline(0.5,color=GREY,lw=0.6,ls=':'); ax.axhline(1,color=GREY,lw=0.6,ls=':')
ax.set_yticks([0,0.5,1]); ax.set_yticklabels(['$\\theta_s$','$\\theta_f=\\frac{1}{2}(\\theta_s+\\theta_\\infty)$','$\\theta_\\infty$']); ax.set_xticks([]); ax.tick_params(labelsize=7.4)
ax.set_xlabel('distance from plate',fontsize=8); ax.set_ylabel('air temperature',fontsize=8); ax.spines['left'].set_visible(True); save(fig,'p_3C2.png')
# D1 stratified room
fig,ax=new(2.0,2.0); ax.set_xlim(-1,8); ax.set_ylim(-1,10)
ax.add_patch(Rectangle((0,0),0.6,8,fc=LB,ec=BLUE,lw=1)); 
z=np.linspace(0,8,50); Tz=2.2+2.0*z/8
ax.plot(0.9+Tz,z,color=RED,lw=1.3); ax.plot([0.9,0.9],[0,8],color=GREY,lw=0.6,ls=':')
for zz in (1,3,5,7): arr(ax,(0.65,zz),(1.0+2.2+2.0*zz/8-0.1,zz),c=OR,lw=0.8,ms=5)
tx(ax,5.6,8.4,'$\\theta_s(z)$',color=RED,ha='center'); tx(ax,0.3,-0.9,'wall',ha='center',color=NAVY); tx(ax,2.4,3.5,'',fs=6)
ax.annotate('',xy=(7.6,8),xytext=(7.6,0),arrowprops=dict(arrowstyle='<->',color=GREY,lw=0.7)); tx(ax,7.8,4,'$z$',color=GREY,va='center'); save(fig,'p_3D1.png')
print('ok')
