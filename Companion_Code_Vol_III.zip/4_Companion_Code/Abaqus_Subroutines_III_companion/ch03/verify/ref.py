"""Independent references for Chapter 3 (closed forms, ODE solutions, fin shooting)."""
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.optimize import brentq
g=9.81; cp=1007.0
def air(Tc):
    T=Tc+273.15
    mu=1.716e-5*(T/273.15)**1.5*(273.15+110.4)/(T+110.4)
    k=0.0241*(T/273.15)**1.5*(273.15+194.0)/(T+194.0)
    rho=101325.0/(287.05*T); nu=mu/rho; al=k/(rho*cp)
    return T,k,nu,al,nu/al
def hcc(dT,Tinf,L,A0=0.825,dtmin=1e-2,Tprop=None,beta_T=None):
    """Churchill-Chu, W/m2K; properties at Tprop (default Tinf)."""
    Tp=Tinf if Tprop is None else Tprop
    T,k,nu,al,Pr=air(Tp)
    beta=1.0/(T if beta_T is None else beta_T)
    d=np.sqrt(dT**2+dtmin**2)
    Ra=g*beta*d*L**3/(nu*al)
    Nu=(A0+0.387*Ra**(1/6)/(1+(0.492/Pr)**(9/16))**(8/27))**2
    return Nu*k/L, Ra, Pr, Nu
# plate data (mm, t, s, mJ): aluminium 5 mm
rhoc=2.43; hh=2.5; k=237.0
tau_c=rhoc*hh/8e-3
def lumped_const(t,th0=150.,T0=20.,r=30/3600.,h=8e-3):
    tau=rhoc*hh/h
    Ti=T0+r*t
    return Ti-r*tau+(th0-T0+r*tau)*np.exp(-t/tau)
def lumped_nl(tend,th0=150.,L=0.3,A0=0.825):
    f=lambda t,y:[-(hcc(y[0]-(20+30*min(t/3600,1)),20+30*min(t/3600,1),L,A0)[0]*1e-3*(y[0]-(20+30*min(t/3600,1))))/(rhoc*hh)]
    s=solve_ivp(f,[0,tend],[th0],method='DOP853',rtol=1e-12,atol=1e-12,dense_output=True)
    return s
def lumped_power(t,th0=150.,L=0.3):
    # h = Cp*dT^(1/3), constant sink 20
    h1=hcc(100.0,20.,L,0.0,dtmin=0.0)[0]/100.0**(1/3)*1e-3  # mW/mm2/K^(4/3)
    a=h1/(rhoc*hh)
    th=th0-20
    return 20+(th**(-1/3)+a*t/3)**(-3), h1
if __name__=='__main__':
    # hand check
    h,Ra,Pr,Nu=hcc(50.0,20.,0.3)
    print('hand dT=50: Ra=%.6e Pr=%.5f Nu=%.5f h=%.9f'%(Ra,Pr,Nu,h))
    T,kk,nu,al,Pr_=air(20.); print('air20: k=%.5f nu=%.4e al=%.4e Pr=%.4f beta=%.5f'%(kk,nu,al,Pr_,1/T))
    # film-temperature properties
    hf=hcc(50.0,20.,0.3,Tprop=45.,beta_T=273.15+45)[0]; print('film-temp props h=%.4f (ambient props %.4f, diff %.2f%%)'%(hf,h,(h/hf-1)*100))
    for dT in (10,30,80):
        a=hcc(dT,20.,0.3)[0]; b=hcc(dT,20.,0.3,Tprop=20+dT/2,beta_T=293.15+dT/2)[0]; print(dT,a,b,(a/b-1)*100)
    print('const lumped t=3600:',lumped_const(3600.))
    s=lumped_nl(3600.); print('nl lumped t=3600:',s.sol(3600.)[0])
    print('power:',lumped_power(3600.))
    print('tau',tau_c, 'Bi=',8e-3*hh/k)
    print('Bi nl: h(150-20)=',hcc(130.,20.,.3)[0])
