import sys; sys.path.insert(0,'/home/claude/vol3/lib'); from mkeq import mkeq
E={
 'e321':r'$q=h(\theta)\,\left(\theta-\theta_s\right)$',
 'e322':r'$R_a^{\,\mathrm{film}}=\int_{\Gamma}N_a\,q\,d\Gamma\;\approx\;\sum_p w_p\,J_p\,N_a(\xi_p)\,q\!\left(\theta_p,t_{n+1}\right)$',
 'e323':r'$K_{ab}^{\,\mathrm{film}}=\int_{\Gamma}N_aN_b\,\frac{\partial q}{\partial\theta}\,d\Gamma \qquad \frac{\partial q}{\partial\theta}=h+\left(\theta-\theta_s\right)\frac{\partial h}{\partial\theta}=H(1)+\left(\theta-\theta_s\right)H(2)$',
 'e324':r'$\rho\,c\,\ell\,\frac{d\theta}{dt}=-h\,(\theta-\theta_s) \qquad \tau=\frac{\rho c\,\ell}{h} \qquad \mathrm{Bi}=\frac{h\,\ell}{k} \qquad \ell=\frac{V}{A}$',
 'e325':r'$\theta(t)=\theta_s(t)-r\tau+\left[\theta_0-\theta_s(0)+r\tau\right]e^{-t/\tau} \qquad \theta_s(t)=\theta_s(0)+r\,t$',
 'e341':r'$\mathrm{Ra}=\frac{g\,\beta\,\Delta\theta\,L^{3}}{\nu\,\alpha}\qquad \mathrm{Nu}=\left[A_0+\frac{0.387\,\mathrm{Ra}^{1/6}}{\left[1+(0.492/\mathrm{Pr})^{9/16}\right]^{8/27}}\right]^{2}\qquad h=\mathrm{Nu}\,\frac{k}{L}$',
 'e342':r'$h=\frac{k}{L}\left(A_0+C_1\,\mathrm{Ra}^{1/6}\right)^{2}\qquad C_1=\frac{0.387}{\left[1+(0.492/\mathrm{Pr})^{9/16}\right]^{8/27}}$',
 'e343':r'$\frac{\partial h}{\partial\theta}=\frac{k}{L}\;2\left(A_0+C_1\mathrm{Ra}^{1/6}\right)C_1\,\frac{\mathrm{Ra}^{1/6}}{6\,\Delta\theta}$',
 'e344':r'$\Delta\theta_e=\sqrt{\Delta\theta^{2}+\delta^{2}}\qquad \frac{\partial h}{\partial\theta}=\frac{k}{L}\,\frac{2\,B\,C_1\,S}{6\,\Delta\theta_e}\,\frac{\Delta\theta}{\Delta\theta_e}\qquad S=\mathrm{Ra}_1^{1/6}\Delta\theta_e^{1/6},\;B=A_0+C_1S$',
 'e351':r'$h=C\,|\Delta\theta|^{1/3}\;\Rightarrow\;\theta_e^{-1/3}(t)=\theta_{e0}^{-1/3}+\frac{C}{3\,\rho c\,\ell}\,t \qquad \theta_e=\theta-\theta_s=\mathrm{const}$',
 'e361':r'$\frac{\theta-\theta_s}{\theta_b-\theta_s}=\frac{\cosh m(L-x)}{\cosh mL}\qquad Q=\sqrt{h\,P\,k\,A_c}\;(\theta_b-\theta_s)\tanh mL\qquad m=\sqrt{\frac{hP}{kA_c}}$',
 'e362':r'$k A_c\,\frac{d^{2}\theta}{dx^{2}}=P\,q(\theta)\qquad Q=\sqrt{2\,k A_c\,P\int_{\theta_t}^{\theta_b}q(\vartheta)\,d\vartheta}$',
 'e371':r'$\mathbf{C}\,\frac{\boldsymbol{\theta}_{n+1}-\boldsymbol{\theta}_n}{\Delta t}+\mathbf{K}_c\,\boldsymbol{\theta}_{n+1}+\mathbf{R}^{\,\mathrm{film}}(\boldsymbol{\theta}_{n+1},t_{n+1})=\mathbf{0}$',
}
mkeq(E,'/home/claude/vol3/ch03')
