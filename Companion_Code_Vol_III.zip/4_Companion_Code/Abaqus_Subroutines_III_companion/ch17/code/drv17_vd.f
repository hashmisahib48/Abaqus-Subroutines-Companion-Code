      PROGRAM DRV17V
!     Problem 17C.1: block-size independence of VDFLUX and agreement
!     with DFLUX (surface SPOT); amplitude scaling of HOTFACE.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 64)
      DIMENSION CUR(NMAX,3), VEL(NMAX,3), DIR(NMAX,3,3), TMP(NMAX),
     1 VAL(NMAX), JUID(NMAX), FLUX(2), TIME(2), COORDS(3), VREF(NMAX)
      CHARACTER*80 SNAME
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      COORDS(3) = 0.0D0
      DO 10 K = 1, NMAX
         CUR(K,1) = 0.05D0*(K - 1)
         CUR(K,2) = 0.0D0
         CUR(K,3) = 0.0D0
         VEL(K,1) = 0.0D0
         VEL(K,2) = 0.0D0
         VEL(K,3) = 0.0D0
         TMP(K) = 20.0D0
         JUID(K) = 1
         COORDS(1) = CUR(K,1)
         COORDS(2) = 0.0D0
         SNAME = 'SPOT'
         CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,0,20.0D0,0.0D0,
     1    SNAME)
         VREF(K) = FLUX(1)
   10 CONTINUE
      DO 40 IB = 1, 3
         NB = 1
         IF (IB .EQ. 2) NB = 7
         IF (IB .EQ. 3) NB = 64
         DMAX = 0.0D0
         DO 30 K0 = 1, NMAX, NB
            NK = MIN(NB, NMAX - K0 + 1)
            CALL K17_VCALL(NK,CUR(K0,1),VAL,'SPOT',1.0D0)
            DO 20 K = 1, NK
               DMAX = MAX(DMAX, ABS(VAL(K) - VREF(K0+K-1)))
   20       CONTINUE
   30    CONTINUE
         WRITE(*,'(A,I3,1PE12.3)') 'VD', NB, DMAX
   40 CONTINUE
      CALL K17_VCALL(1,CUR(1,1),VAL,'HOTFACE',0.5D0)
      WRITE(*,'(A,1PE14.6)') 'HOT', VAL(1)
      CALL K17_VCALL(1,CUR(1,1),VAL,'SPOT',0.5D0)
      WRITE(*,'(A,1P,2E14.6)') 'AMP', VAL(1), VREF(1)
      END
!
      SUBROUTINE K17_VCALL(NK,X,VAL,SN,AMP)
!     X is the first column of CURCOORDS(NMAX,3): pass NK points
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 64)
      DIMENSION X(NMAX), VAL(NMAX), C(NK,3), V(NK,3), D(NK,3,3),
     1 T(NK), JU(NK), VL(NK)
      CHARACTER*(*) SN
      CHARACTER*80 SNAME
      SNAME = SN
      DO 10 K = 1, NK
         C(K,1) = X(K)
         C(K,2) = 0.0D0
         C(K,3) = 0.0D0
         V(K,1) = 0.0D0
         V(K,2) = 0.0D0
         V(K,3) = 0.0D0
         T(K) = 20.0D0
         JU(K) = 1
   10 CONTINUE
      CALL VDFLUX(NK, 3, 1, 1, 0.0D0, 0.0D0, JU, AMP, T, C, V, D, 0,
     1 SNAME, VL)
      DO 20 K = 1, NK
         VAL(K) = VL(K)
   20 CONTINUE
      RETURN
      END
