      SUBROUTINE DFLUX(FLUX,SOL,KSTEP,KINC,TIME,NOEL,NPT,COORDS,
     1 JLTYP,TEMP,PRESS,SNAME)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      COMMON /K17_TINC/ DTINC
!
!     Units: mW, mm, s, degC.  Three fluxes selected by surface name
      PARAMETER (ETA = 0.35D0, P = 2.0D5, W = 1.0D0)      ! SPOT
      PARAMETER (Q0 = 10.0D0, T1 = 0.0D0, T2 = 0.5D0)     ! PULSE
      PARAMETER (XI = 300.0D0, AL0 = 0.35D0, GAM = 2.0D-4)! HOTLOSS
      PARAMETER (EPS = 0.8D0, SIG = 5.670374D-11)   ! mW/(mm^2 K^4)
      PARAMETER (TINF = 20.0D0, TZERO = 273.15D0, TREF = 20.0D0)
      PARAMETER (PI = 3.14159265358979D0)
!
      FLUX(1) = 0.0D0
      FLUX(2) = 0.0D0
      IF (INDEX(SNAME,'SPOT') .GT. 0) THEN
!        Gaussian spot, power ETA*P, 1/e^2 radius W
         R2 = COORDS(1)**2 + COORDS(2)**2
         FLUX(1) = 2.0D0*ETA*P/(PI*W**2)*EXP(-R2/W**2)
      ELSE IF (INDEX(SNAME,'HOTLOSS') .GT. 0) THEN
!        absorbed beam minus radiation, FLUX(2) = dFLUX(1)/dT
         TK  = SOL + TZERO
         TIK = TINF + TZERO
         AL  = AL0*(1.0D0 + GAM*(SOL - TREF))
         FLUX(1) = AL*XI - EPS*SIG*(TK**4 - TIK**4)
         FLUX(2) = AL0*GAM*XI - EPS*SIG*TK**3
      ELSE
!        rectangular pulse, mean over the increment (Section 2.6)
         TE = TIME(1)
         TS = TE - DTINC
         ON = MAX(0.0D0, MIN(TE,T2) - MAX(TS,T1))
         IF (TE .GT. T1 .AND. TE .LE. T2) FLUX(1) = Q0
      ENDIF
      RETURN
      END
!
      SUBROUTINE UEXTERNALDB(LOP,LRESTART,TIME,DTIME,KSTEP,KINC)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TIME(2)
      COMMON /K17_TINC/ DTINC
!     LOP = 1: start of an attempt at an increment (Volume I, 10.2)
      IF (LOP .EQ. 1) DTINC = DTIME
      RETURN
      END
