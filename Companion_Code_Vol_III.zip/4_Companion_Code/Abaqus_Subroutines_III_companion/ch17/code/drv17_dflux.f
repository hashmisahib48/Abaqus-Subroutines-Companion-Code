      PROGRAM DRV17D
!     Verification harness for the DFLUX routine of ex17_dflux.f.
!     MODE 1: report (Examples 17.2-1, 17.3-1, 17.4-1)
!     MODE 2: matrix of tests D1-D7 (one line per test: flag, metric)
!     MODE 3: finite-difference step sweep; MODE 4: one bar run
!     Units mW, mm, s, degC.
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K17_K/ KINC
      KINC = 1
      READ(*,*) MODE
      IF (MODE .EQ. 1) CALL K17_REPORT
      IF (MODE .EQ. 2) CALL K17_MATRIX
      IF (MODE .EQ. 3) CALL K17_SWEEP
      IF (MODE .EQ. 4) CALL K17_ONE
      END
!
      SUBROUTINE K17_Q(SN,SOL,X,Y,T,DT,F1,F2)
!     call DFLUX the way Abaqus would, after UEXTERNALDB (LOP = 1)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      COMMON /K17_K/ KINC
      CHARACTER*(*) SN
      CHARACTER*80 SNAME
      TIME(1) = T
      TIME(2) = T
      COORDS(1) = X
      COORDS(2) = Y
      COORDS(3) = 0.0D0
      SNAME = SN
      CALL UEXTERNALDB(1,0,TIME,DT,1,KINC)
      CALL DFLUX(FLUX,SOL,1,KINC,TIME,1,1,COORDS,0,SOL,0.0D0,SNAME)
      F1 = FLUX(1)
      F2 = FLUX(2)
      RETURN
      END
!
      SUBROUTINE K17_BAR(DT0,MODE,TEND,EIN,EST,ELOST,T1,TL)
!     Bar 0 < x < 20 mm, 20 linear elements, consistent capacity,
!     backward Euler.  Flux PULSE enters at x = 0, film H at x = 20.
!     MODE 1: constant increment DT0; MODE 2: increments DT0*(1,4,2,3)
!     repeated.  EIN: energy supplied by DFLUX*DT, EST: stored energy,
!     ELOST: lost through the film (mJ per mm^2).
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (N = 21, RC = 3.6107D0, XK = 45.0D0, XL = 20.0D0)
      PARAMETER (HF = 0.5D0, TINF = 20.0D0)
      DIMENSION A(N), B(N), C(N), R(N), T(N), W(4)
      COMMON /K17_K/ KINC
      DATA W /1.0D0, 4.0D0, 2.0D0, 3.0D0/
      HE = XL/(N - 1)
      DO 5 I = 1, N
         T(I) = TINF
    5 CONTINUE
      TIME = 0.0D0
      EIN = 0.0D0
      ELOST = 0.0D0
      KI = 0
      DO WHILE (TIME .LT. TEND - 1.0D-12)
         KI = KI + 1
         KINC = KI
         DT = DT0
         IF (MODE .EQ. 2) DT = DT0*W(MOD(KI-1,4)+1)
         DT = MIN(DT, TEND - TIME)
         TN = TIME + DT
         CALL K17_Q('PULSE',TINF,0.0D0,0.0D0,TN,DT,QF,DQ)
         DO 10 I = 1, N
            A(I) = 0.0D0
            B(I) = 0.0D0
            C(I) = 0.0D0
            R(I) = 0.0D0
   10    CONTINUE
         DO 20 IE = 1, N - 1
            CM = RC*HE/(6.0D0*DT)
            CK = XK/HE
            B(IE) = B(IE) + 2.0D0*CM + CK
            B(IE+1) = B(IE+1) + 2.0D0*CM + CK
            C(IE) = C(IE) + CM - CK
            A(IE+1) = A(IE+1) + CM - CK
            R(IE) = R(IE) + (2.0D0*T(IE) + T(IE+1))*CM
            R(IE+1) = R(IE+1) + (T(IE) + 2.0D0*T(IE+1))*CM
   20    CONTINUE
         R(1) = R(1) + QF
         B(N) = B(N) + HF
         R(N) = R(N) + HF*TINF
         DO 30 I = 2, N
            WW = A(I)/B(I-1)
            B(I) = B(I) - WW*C(I-1)
            R(I) = R(I) - WW*R(I-1)
   30    CONTINUE
         T(N) = R(N)/B(N)
         DO 40 I = N - 1, 1, -1
            T(I) = (R(I) - C(I)*T(I+1))/B(I)
   40    CONTINUE
         EIN = EIN + QF*DT
         ELOST = ELOST + HF*(T(N) - TINF)*DT
         TIME = TN
      END DO
      KINC = 1
      EST = 0.0D0
      DO 50 I = 1, N
         WI = 1.0D0
         IF (I .EQ. 1 .OR. I .EQ. N) WI = 0.5D0
         EST = EST + RC*HE*WI*(T(I) - TINF)
   50 CONTINUE
      T1 = T(1)
      TL = T(N)
      RETURN
      END
!
      SUBROUTINE K17_LUMP(TH,DT0,TEND,TFIN)
!     Lumped plate, C dT/dt = FLUX(PULSE) - H (T - TINF), theta
!     scheme (TH = 1 backward Euler, 0.5 Crank-Nicolson) with the
!     increment mean of the flux.  C = 3.6107 mJ/(mm^2 K), H = 0.5.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (C = 3.6107D0, HF = 0.5D0, TINF = 20.0D0)
      T = TINF
      TIME = 0.0D0
      DO WHILE (TIME .LT. TEND - 1.0D-12)
         DT = MIN(DT0, TEND - TIME)
         TN = TIME + DT
         CALL K17_Q('PULSE',TINF,0.0D0,0.0D0,TN,DT,QF,DQ)
         T = (C/DT*T + QF - HF*((1.0D0-TH)*(T - TINF) - TH*TINF))
     1       /(C/DT + TH*HF)
         TIME = TN
      END DO
      TFIN = T
      RETURN
      END
!
      FUNCTION K17_EXACT(TEND)
!     exact lumped solution, pulse 0 < t < 0.5
      INCLUDE 'ABA_PARAM.INC'
      REAL*8 K17_EXACT
      PARAMETER (C = 3.6107D0, HF = 0.5D0, TINF = 20.0D0)
      PARAMETER (Q0 = 10.0D0, T2 = 0.5D0)
      TAU = C/HF
      DTP = Q0/HF*(1.0D0 - EXP(-T2/TAU))
      K17_EXACT = TINF + DTP*EXP(-(TEND - T2)/TAU)
      RETURN
      END
!
      SUBROUTINE K17_ORDER(TH,N0,TEND,P,E)
!     observed order from five halvings of the increment, starting
!     from DT = TEND/N0; P(1:5) orders, E(1:6) relative errors
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION P(5), E(6)
      REAL*8 K17_EXACT
      EX = K17_EXACT(TEND)
      DO 10 K = 1, 6
         DT = TEND/(N0*2.0D0**(K-1))
         CALL K17_LUMP(TH,DT,TEND,TF)
         E(K) = ABS(TF - EX)/(EX - 20.0D0)
   10 CONTINUE
      DO 20 K = 1, 5
         P(K) = LOG(E(K)/E(K+1))/LOG(2.0D0)
   20 CONTINUE
      RETURN
      END
!
      SUBROUTINE K17_REPORT
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION P(5), E(6)
      EXD = 5.0D0
!     (a) energy balance of the bar
      DO 10 IC = 1, 4
         IF (IC .EQ. 1) DT0 = 0.3D0
         IF (IC .EQ. 2) DT0 = 0.07D0
         IF (IC .EQ. 3) DT0 = 0.06D0
         IF (IC .EQ. 4) DT0 = 0.25D0
         MD = 1
         IF (IC .GE. 3) MD = 2
         CALL K17_BAR(DT0,MD,2.0D0,EIN,EST,ELOST,T1,TL)
         WRITE(*,'(A,I1,F8.4,I2,1P,6E18.10)') 'BAR ', IC, DT0, MD,
     1    EIN, EST, ELOST, EIN - EST - ELOST, T1, TL
   10 CONTINUE
!     (b) order of accuracy: aligned (N0 = 8) and misaligned (N0 = 7)
      DO 20 IM = 1, 2
         TEND = 2.0D0
         N0 = 8
         IF (IM .EQ. 2) THEN
            TEND = 2.1D0
            N0 = 7
         ENDIF
         DO 30 ITH = 1, 2
            TH = 1.0D0
            IF (ITH .EQ. 2) TH = 0.5D0
            CALL K17_ORDER(TH,N0,TEND,P,E)
            WRITE(*,'(A,2I2,1P,6E14.6)') 'ERR ', IM, ITH, E
            WRITE(*,'(A,2I2,5F10.4)') 'ORD ', IM, ITH, P
   30    CONTINUE
   20 CONTINUE
!     (c) Newton iterations for the temperature-dependent flux
      CALL K17_NEWTON
      RETURN
      END
!
      SUBROUTINE K17_NEWTON
!     C dT/dt = FLUX(T), lumped plate, backward Euler, 2 s increments.
!     JOPT: 1 exact FLUX(2); 2 central difference of FLUX(1);
!     3 FLUX(2) = 0; 4 radiation term of FLUX(2) omitted;
!     5 sign of FLUX(2) reversed.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (C = 3.6107D0, DT = 2.0D0, NINC = 30)
      DIMENSION RH(30)
      DO 100 JOPT = 1, 5
         T = 20.0D0
         NTOT = 0
         NMAX = 0
         DO 90 KI = 1, NINC
            TOLD = T
            DO 80 IT = 1, 60
               CALL K17_Q('HOTLOSS',T,0.0D0,0.0D0,KI*DT,DT,F1,F2)
               RES = C*(T - TOLD)/DT - F1
               IF (KI .EQ. 1 .AND. IT .LE. 30) RH(IT) = ABS(RES)
               IF (ABS(RES) .LT. 1.0D-9) GOTO 85
               IF (JOPT .EQ. 2) THEN
                  CALL K17_Q('HOTLOSS',T+0.01D0,0.0D0,0.0D0,KI*DT,DT,
     1             FP,DUM)
                  CALL K17_Q('HOTLOSS',T-0.01D0,0.0D0,0.0D0,KI*DT,DT,
     1             FM,DUM)
                  F2 = (FP - FM)/0.02D0
               ELSE IF (JOPT .EQ. 3) THEN
                  F2 = 0.0D0
               ELSE IF (JOPT .EQ. 4) THEN
                  F2 = 0.35D0*2.0D-4*300.0D0
               ELSE IF (JOPT .EQ. 5) THEN
                  F2 = -F2
               ENDIF
               T = T - RES/(C/DT - F2)
   80       CONTINUE
   85       NTOT = NTOT + IT - 1
            NMAX = MAX(NMAX, IT - 1)
            IF (KI .EQ. 1) NFIRST = IT - 1
   90    CONTINUE
         WRITE(*,'(A,I2,3I5,F12.6)') 'NEW ', JOPT, NTOT, NMAX, NFIRST,T
         WRITE(*,'(A,I2,1P,12E12.3)') 'RES ', JOPT,
     1    (RH(K), K = 1, MIN(NFIRST+1,12))
  100 CONTINUE
      RETURN
      END
!
      SUBROUTINE K17_MATRIX
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0, SG = 5.670374D-11)
      DIMENSION P(5), E(6), XOK(8)
!     ---- D1 closed forms, written independently of the routine ----
      EMAX = 0.0D0
      Q00 = 1.4D5/PI
      CALL K17_Q('SPOT',20.0D0,0.0D0,0.0D0,0.1D0,0.1D0,F1,F2)
      EMAX = MAX(EMAX, ABS(F1/Q00 - 1.0D0))
      CALL K17_Q('SPOT',20.0D0,0.6D0,0.8D0,0.1D0,0.1D0,F1,F2)
      EMAX = MAX(EMAX, ABS(F1/(Q00*EXP(-2.0D0)) - 1.0D0))
      CALL K17_Q('HOTLOSS',20.0D0,0.0D0,0.0D0,0.1D0,0.1D0,F1,F2)
      EMAX = MAX(EMAX, ABS(F1/105.0D0 - 1.0D0))
      TK = 1273.15D0
      TI = 293.15D0
      REF = 0.35D0*(1.0D0 + 2.0D-4*980.0D0)*300.0D0
     1      - 0.8D0*SG*((TK*TK)**2 - (TI*TI)**2)
      CALL K17_Q('HOTLOSS',1000.0D0,0.0D0,0.0D0,0.1D0,0.1D0,F1,F2)
      EMAX = MAX(EMAX, ABS(F1/REF - 1.0D0))
      CALL K17_Q('PULSE',20.0D0,0.0D0,0.0D0,0.25D0,0.05D0,F1,F2)
      EMAX = MAX(EMAX, ABS(F1/10.0D0 - 1.0D0))
      WRITE(*,'(A,I2,1PE14.5)') 'D1', MERGE(1,0,EMAX .LT. 1.0D-10),EMAX
!     ---- D2 spot power ----
      N = 6000
      H = 6.0D0/N
      S = 0.0D0
      DO 10 K = 0, N
         CALL K17_Q('SPOT',20.0D0,H*K,0.0D0,0.1D0,0.1D0,F1,F2)
         WGT = 2.0D0
         IF (MOD(K,2) .EQ. 1) WGT = 4.0D0
         IF (K .EQ. 0 .OR. K .EQ. N) WGT = 1.0D0
         S = S + WGT*F1*2.0D0*PI*H*K
   10 CONTINUE
      S = S*H/3.0D0
      ERR = S/7.0D4 - 1.0D0
      WRITE(*,'(A,I2,1PE14.5)') 'D2', MERGE(1,0,ABS(ERR) .LT. 1.0D-6),
     1 ERR
!     ---- D3 labels ----
      FMAX = 0.0D0
      DO 20 K = 1, 4
         CALL K17_Q(' ',500.0D0,0.2D0,0.1D0,0.25D0,0.05D0,F1,F2)
         IF (K .EQ. 2) CALL K17_Q('TOP',500.0D0,0.2D0,0.1D0,0.25D0,
     1    0.05D0,F1,F2)
         IF (K .EQ. 3) CALL K17_Q('OTHER',500.0D0,0.2D0,0.1D0,0.25D0,
     1    0.05D0,F1,F2)
         IF (K .EQ. 4) CALL K17_Q('BOTTOM',500.0D0,0.2D0,0.1D0,
     1    0.25D0,0.05D0,F1,F2)
         FMAX = MAX(FMAX, ABS(F1), ABS(F2))
   20 CONTINUE
      WRITE(*,'(A,I2,1PE14.5)') 'D3', MERGE(1,0,FMAX .EQ. 0.0D0),FMAX
!     ---- D4 energy of the pulse in the bar ----
      EWORST = 0.0D0
      RWORST = 0.0D0
      DO 30 IC = 1, 3
         IF (IC .EQ. 1) THEN
            DT0 = 0.3D0
            MD = 1
         ELSE IF (IC .EQ. 2) THEN
            DT0 = 0.07D0
            MD = 1
         ELSE
            DT0 = 0.06D0
            MD = 2
         ENDIF
         CALL K17_BAR(DT0,MD,2.0D0,EIN,EST,ELOST,T1,TL)
         EWORST = MAX(EWORST, ABS(EIN/5.0D0 - 1.0D0))
         RWORST = MAX(RWORST, ABS(EIN - EST - ELOST)/5.0D0)
   30 CONTINUE
      WRITE(*,'(A,I2,1P,2E14.5)') 'D4',
     1 MERGE(1,0,EWORST .LT. 1.0D-10 .AND. RWORST .LT. 1.0D-10),
     2 EWORST, RWORST
!     ---- D5 finite differences of FLUX(2) ----
      DMAX = 0.0D0
      DO 40 K = 1, 4
         TT = 20.0D0
         IF (K .EQ. 2) TT = 300.0D0
         IF (K .EQ. 3) TT = 800.0D0
         IF (K .EQ. 4) TT = 1500.0D0
         CALL K17_Q('HOTLOSS',TT,0.0D0,0.0D0,0.1D0,0.1D0,F1,F2)
         CALL K17_Q('HOTLOSS',TT+0.01D0,0.0D0,0.0D0,0.1D0,0.1D0,FP,
     1    DUM)
         CALL K17_Q('HOTLOSS',TT-0.01D0,0.0D0,0.0D0,0.1D0,0.1D0,FM,
     1    DUM)
         FD = (FP - FM)/0.02D0
         DMAX = MAX(DMAX, ABS(FD - F2)/MAX(ABS(F2), 1.0D-3))
   40 CONTINUE
      WRITE(*,'(A,I2,1PE14.5)') 'D5', MERGE(1,0,DMAX .LT. 1.0D-5),DMAX
!     ---- D6 signs and limits ----
      IOK = 1
      FOLD = 1.0D30
      DO 50 K = 0, 100
         CALL K17_Q('SPOT',20.0D0,0.05D0*K,0.0D0,0.1D0,0.1D0,F1,F2)
         CALL K17_Q('SPOT',20.0D0,0.0D0,0.05D0*K,0.1D0,0.1D0,FY,F2)
         IF (F1 .LT. 0.0D0 .OR. F1 .GT. FOLD*(1.0D0+1.0D-12)) IOK = 0
         IF (ABS(F1 - FY) .GT. 1.0D-12*ABS(F1)) IOK = 0
         FOLD = F1
   50 CONTINUE
      CALL K17_Q('PULSE',20.0D0,0.0D0,0.0D0,1.0D0,0.1D0,F1,F2)
      IF (F1 .NE. 0.0D0) IOK = 0
      CALL K17_Q('PULSE',20.0D0,0.0D0,0.0D0,0.55D0,0.1D0,F1,F2)
      IF (ABS(F1 - 5.0D0) .GT. 1.0D-12) IOK = 0
      DO 60 K = 0, 20
         TT = 20.0D0 + 80.0D0*K
         CALL K17_Q('HOTLOSS',TT,0.0D0,0.0D0,0.1D0,0.1D0,F1,F2)
         AB = 0.35D0*(1.0D0 + 2.0D-4*(TT - 20.0D0))*300.0D0
         IF (F1 .GT. AB*(1.0D0 + 1.0D-12)) IOK = 0
   60 CONTINUE
      WRITE(*,'(A,I2,I4)') 'D6', IOK, IOK
!     ---- D7 observed order, misaligned pulse: BE 1, CN 2 ----
      CALL K17_ORDER(1.0D0,7,2.1D0,P,E)
      PBE = P(5)
      CALL K17_ORDER(0.5D0,7,2.1D0,P,E)
      PCN = P(5)
      WRITE(*,'(A,I2,1P,2E14.5)') 'D7',
     1 MERGE(1,0,ABS(PBE - 1.0D0) .LT. 0.1D0 .AND.
     2 ABS(PCN - 2.0D0) .LT. 0.1D0), PBE, PCN
      RETURN
      END
!
      SUBROUTINE K17_SWEEP
!     relative error of the central difference of FLUX(1) against
!     FLUX(2) as a function of the step H (K), at three temperatures
      INCLUDE 'ABA_PARAM.INC'
      DO 20 IT = 1, 3
         TT = 100.0D0
         IF (IT .EQ. 2) TT = 800.0D0
         IF (IT .EQ. 3) TT = 1500.0D0
         CALL K17_Q('HOTLOSS',TT,0.0D0,0.0D0,0.1D0,0.1D0,F1,F2)
         DO 10 K = 0, 16
            H = 10.0D0**(1.0D0 - K)
            CALL K17_Q('HOTLOSS',TT+H,0.0D0,0.0D0,0.1D0,0.1D0,FP,DUM)
            CALL K17_Q('HOTLOSS',TT-H,0.0D0,0.0D0,0.1D0,0.1D0,FM,DUM)
            WRITE(*,'(A,F8.1,1P,E10.1,2E16.8)') 'SWP ', TT, H, F2,
     1       ABS((FP - FM)/(2.0D0*H) - F2)/ABS(F2)
   10    CONTINUE
   20 CONTINUE
      RETURN
      END
!
      SUBROUTINE K17_ONE
!     one bar run: DT0, MODE, TEND from the standard input
      INCLUDE 'ABA_PARAM.INC'
      READ(*,*) DT0, MD, TEND
      CALL K17_BAR(DT0,MD,TEND,EIN,EST,ELOST,T1,TL)
      WRITE(*,'(A,1P,5E18.10)') 'ONE ', EIN, EST, ELOST, T1, TL
      RETURN
      END
