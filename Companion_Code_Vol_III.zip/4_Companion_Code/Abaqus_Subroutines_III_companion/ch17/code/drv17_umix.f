      PROGRAM DRV17U
!     Verification harness for UMIXMODEFATIGUE (energy form) of
!     ex17_umix.f.  MODE 1: report (Section 17.5 tables).
!     MODE 2: matrix of tests U1-U7.  Units N, mm, MPa.
      INCLUDE 'ABA_PARAM.INC'
      READ(*,*) MODE
      IF (MODE .EQ. 1) CALL K17_REPORT
      IF (MODE .EQ. 2) CALL K17_MATRIX
      END
!
      SUBROUTINE K17_CALL(PROPS,GM1,GM2,GM3,GN1,GN2,GN3,DADN)
!     call the routine as Abaqus would at the end of a cycle
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(8), ST(1), PRE(1), DPR(1), IA(1), RA(1), CA(1)
      ST(1) = 0.0D0
      PRE(1) = 0.0D0
      DPR(1) = 0.0D0
      IA(1) = 0
      RA(1) = 0.0D0
      CA(1) = 0.0D0
      DADN = -1.0D30
      CALL UMIXMODEFATIGUE(DADN, GM1, GM2, GM3, GN1, GN2, GN3, 20.0D0,
     1 0.0D0, PRE, DPR, 0, 8, PROPS, 1, ST, 1, IA, 1, RA, 1, CA, 0.0D0)
      RETURN
      END
!
      SUBROUTINE K17_PROP(IC,PROPS)
!     IC 1: carbon/epoxy interface; IC 2: aluminium plate
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(8)
      IF (IC .EQ. 1) THEN
         PROPS(1) = 0.5D0
         PROPS(2) = 5.0D0
         PROPS(3) = 0.01D0
         PROPS(4) = 0.28D0
         PROPS(5) = 0.79D0
         PROPS(6) = 1.20D0
         PROPS(7) = 1.45D0
         PROPS(8) = 0.0D0
      ELSE
         GC = 1100.0D0**2/70000.0D0
         PROPS(1) = 5.0D-11*1000.0D0/1000.0D0**1.5D0*1100.0D0**3
         PROPS(2) = 1.5D0
         PROPS(3) = 0.01D0
         PROPS(4) = GC
         PROPS(5) = 2.0D0*GC
         PROPS(6) = 2.0D0*GC
         PROPS(7) = 1.0D0
         PROPS(8) = 0.0D0
      ENDIF
      RETURN
      END
!
      SUBROUTINE K17_GA(IC,A,G1,G2,G3,GN1,GN2,GN3)
!     energy release rates at maximum (G) and minimum (GN) load
!     IC 1: centre crack, F = 1, SMAX = 100 MPa, R = 0.1, E = 70000
!     IC 2: DCB in displacement control (E = 120000, H = 3, d = 1)
!     IC 3: synthetic mode mix that changes with a (a = 30 ... 50)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0, RR = 0.1D0)
      G2 = 0.0D0
      G3 = 0.0D0
      IF (IC .EQ. 1) THEN
         G1 = 100.0D0**2*PI*A/70000.0D0
      ELSE IF (IC .EQ. 2) THEN
         G1 = 3.0D0*120000.0D0*27.0D0*1.0D0/(16.0D0*A**4)
      ELSE
         G1 = 0.10D0*30.0D0/A
         G2 = 0.04D0*A/30.0D0
      ENDIF
      GN1 = RR**2*G1
      GN2 = RR**2*G2
      GN3 = 0.0D0
      RETURN
      END
!
      SUBROUTINE K17_RATE(IC,A,PROPS,RATE)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(8)
      CALL K17_GA(IC,A,G1,G2,G3,GN1,GN2,GN3)
      CALL K17_CALL(PROPS,G1,G2,G3,GN1,GN2,GN3,RATE)
      RETURN
      END
!
      SUBROUTINE K17_LIFE(IC,PROPS,A0,AF,DA0,IDIR,XNE,XNT)
!     N = integral da/(da/dN) by the explicit rule (rate at the
!     start of the increment) and by the trapezoidal rule.
!     IDIR = 1 forward from A0, IDIR = -1 backward from AF.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(8)
      XNE = 0.0D0
      XNT = 0.0D0
      NI = NINT((AF - A0)/DA0 + 0.4999999D0)
      DA = (AF - A0)/NI
      DO 10 K = 1, NI
         IF (IDIR .EQ. 1) THEN
            AA = A0 + (K-1)*DA
            AB = AA + DA
         ELSE
            AB = AF - (K-1)*DA
            AA = AB - DA
         ENDIF
         CALL K17_RATE(IC,AA,PROPS,RA)
         CALL K17_RATE(IC,AB,PROPS,RB)
         IF (IDIR .EQ. 1) XNE = XNE + DA/RA
         IF (IDIR .EQ. -1) XNE = XNE + DA/RB
         XNT = XNT + 0.5D0*DA*(1.0D0/RA + 1.0D0/RB)
   10 CONTINUE
      RETURN
      END
!
      SUBROUTINE K17_REPORT
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0)
      DIMENSION PROPS(8), DAV(6), EE(6), ET(6)
      DATA DAV /2.0D0, 1.0D0, 0.5D0, 0.25D0, 0.125D0, 0.0625D0/
!     plate: closed form, Eq. 15.2-5 with F = 1
      CALL K17_PROP(2,PROPS)
      A0 = 4.0D0
      AF = (1100.0D0/(100.0D0*SQRT(PI)))**2
      DS = 90.0D0
      XM = 3.0D0
      CMM = 5.0D-11*1000.0D0/1000.0D0**1.5D0
      XNX = (AF**(1.0D0-XM/2.0D0) - A0**(1.0D0-XM/2.0D0))
     1 /((1.0D0-XM/2.0D0)*CMM*(DS*SQRT(PI))**XM)
      WRITE(*,'(A,3F14.6,F16.4)') 'PLATE', A0, AF, 0.0D0, XNX
      DO 10 K = 1, 6
         CALL K17_LIFE(1,PROPS,A0,AF,DAV(K),1,EE(K),ET(K))
         WRITE(*,'(A,F8.4,1P,4E18.9)') 'LIFE1', DAV(K), EE(K), ET(K),
     1    EE(K)/XNX - 1.0D0, ET(K)/XNX - 1.0D0
   10 CONTINUE
      DO 15 K = 1, 5
         WRITE(*,'(A,F8.4,2F10.4)') 'ORD1', DAV(K),
     1    LOG((EE(K)/XNX-1.0D0)/(EE(K+1)/XNX-1.0D0))/LOG(2.0D0),
     2    LOG((ET(K)/XNX-1.0D0)/(ET(K+1)/XNX-1.0D0))/LOG(2.0D0)
   15 CONTINUE
!     DCB, falling G; reference from the trapezoidal sum at 1/512
      CALL K17_PROP(1,PROPS)
      CALL K17_LIFE(2,PROPS,50.0D0,70.0D0,20.0D0/20480.0D0,1,XE,XR)
      DO 20 K = 1, 6
         CALL K17_LIFE(2,PROPS,50.0D0,70.0D0,DAV(K),1,EE(K),ET(K))
         WRITE(*,'(A,F8.4,1P,4E18.9)') 'LIFE2', DAV(K), EE(K), ET(K),
     1    EE(K)/XR - 1.0D0, ET(K)/XR - 1.0D0
   20 CONTINUE
      WRITE(*,'(A,1PE20.10)') 'REF2 ', XR
      DO 25 K = 1, 5
         WRITE(*,'(A,F8.4,2F10.4)') 'ORD2', DAV(K),
     1    LOG((EE(K)/XR-1.0D0)/(EE(K+1)/XR-1.0D0))/LOG(2.0D0),
     2    LOG((ET(K)/XR-1.0D0)/(ET(K+1)/XR-1.0D0))/LOG(2.0D0)
   25 CONTINUE
!     mix that changes with a: forward, backward, in halves
      CALL K17_LIFE(3,PROPS,30.0D0,50.0D0,20.0D0/20480.0D0,1,XE,XR)
      CALL K17_LIFE(3,PROPS,30.0D0,50.0D0,0.25D0,1,XF,TF)
      CALL K17_LIFE(3,PROPS,30.0D0,50.0D0,0.25D0,-1,XB,TB)
      CALL K17_LIFE(3,PROPS,30.0D0,40.0D0,0.25D0,1,X1,T1)
      CALL K17_LIFE(3,PROPS,40.0D0,50.0D0,0.25D0,1,X2,T2)
      WRITE(*,'(A,1P,6E18.9)') 'MIX3', XR, TF, TB, T1 + T2, XF, XB
      DO 30 K = 1, 6
         CALL K17_LIFE(3,PROPS,30.0D0,50.0D0,DAV(K),1,EE(K),ET(K))
         WRITE(*,'(A,F8.4,1P,4E18.9)') 'LIFE3', DAV(K), EE(K), ET(K),
     1    EE(K)/XR - 1.0D0, ET(K)/XR - 1.0D0
   30 CONTINUE
      CALL K17_KFORM
      RETURN
      END
!
      SUBROUTINE K17_KFORM
!     G form and K form (renamed copy of Listing 15.4) agree for
!     mode I: C_K = C3/(E' GIC)**C4, M = 2 C4
      INCLUDE 'ABA_PARAM.INC'
      REAL*8 DKI, XK0, XKM
      DIMENSION PROPS(8), PK(4), ST(1), PRE(1), DPR(1), IA(1), RA(1),
     1 CA(1)
      CALL K17_PROP(2,PROPS)
      EP = 70000.0D0
      PK(1) = PROPS(1)/(EP*PROPS(4))**PROPS(2)
      PK(2) = 2.0D0*PROPS(2)
      PK(3) = 0.0D0
      PK(4) = 0.3D0
      DMAX = 0.0D0
      ST(1) = 0.0D0
      PRE(1) = 0.0D0
      DPR(1) = 0.0D0
      IA(1) = 0
      RA(1) = 0.0D0
      CA(1) = 0.0D0
      DO 10 K = 1, 40
         DKI = 20.0D0 + 15.0D0*K
         XK0 = DKI/(1.0D0 - 0.1D0)
         XKM = 0.1D0*XK0
         GM = XK0**2/EP
         GN = XKM**2/EP
         CALL K17_CALL(PROPS,GM,0.0D0,0.0D0,GN,0.0D0,0.0D0,RG)
         CALL K17_UMIXK(RK, XK0, 0.0D0, 0.0D0, XKM, 0.0D0, 0.0D0,
     1    20.0D0, 0.0D0, PRE, DPR, 0, 4, PK, 1, ST, 1, IA, 1, RA, 1,
     2    CA, 0.0D0)
         IF (RG .GT. 0.0D0) DMAX = MAX(DMAX, ABS(RK/RG - 1.0D0))
   10 CONTINUE
      WRITE(*,'(A,1PE14.5)') 'KFORM', DMAX
      RETURN
      END
!
      SUBROUTINE K17_MATRIX
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979324D0, RR = 0.1D0)
      DIMENSION PROPS(8), PS(8), DAV(4), EE(4), ET(4), RT(60)
      REAL*8 K17_REF
      DATA DAV /1.0D0, 0.5D0, 0.25D0, 0.125D0/
      CALL K17_PROP(1,PROPS)
      GIC = 0.28D0
      GIIC = 0.79D0
      GIIIC = 1.20D0
      C3 = 0.5D0
      C4 = 5.0D0
      ETA = 1.45D0
!     ---- U1 closed forms ----
      EMAX = 0.0D0
!     (a) mode I
      G = 0.10D0
      GN = RR**2*G
      CALL K17_CALL(PROPS,G,0.0D0,0.0D0,GN,0.0D0,0.0D0,D)
      X = (SQRT(G) - SQRT(GN))**2/GIC
      EMAX = MAX(EMAX, ABS(D/(C3*X**C4) - 1.0D0))
!     (b) mode II
      G = 0.30D0
      GN = RR**2*G
      CALL K17_CALL(PROPS,0.0D0,G,0.0D0,0.0D0,GN,0.0D0,D)
      X = (SQRT(G) - SQRT(GN))**2/GIIC
      EMAX = MAX(EMAX, ABS(D/(C3*X**C4) - 1.0D0))
!     (c) B = 0.5, GI = GII
      G = 0.10D0
      CALL K17_CALL(PROPS,G,G,0.0D0,RR**2*G,RR**2*G,0.0D0,D)
      GCB = GIC + (GIIC - GIC)*0.5D0**ETA
      X = (SQRT(2.0D0*G) - SQRT(2.0D0*RR**2*G))**2/GCB
      EMAX = MAX(EMAX, ABS(D/(C3*X**C4) - 1.0D0))
!     (d) Reeder, pure mode III
      PS = PROPS
      PS(8) = 1.0D0
      G = 0.50D0
      CALL K17_CALL(PS,0.0D0,0.0D0,G,0.0D0,0.0D0,RR**2*G,D)
      X = (SQRT(G) - SQRT(RR**2*G))**2/GIIIC
      EMAX = MAX(EMAX, ABS(D/(C3*X**C4) - 1.0D0))
!     (e) minimum load of a different mix (closure): mix from GMAX
      CALL K17_CALL(PROPS,0.10D0,0.0D0,0.0D0,0.0D0,1.0D-3,0.0D0,D)
      X = (SQRT(0.10D0) - SQRT(1.0D-3))**2/GIC
      EMAX = MAX(EMAX, ABS(D/(C3*X**C4) - 1.0D0))
      WRITE(*,'(A,I2,1PE14.5)') 'U1', MERGE(1,0,EMAX .LT. 1.0D-12),EMAX
!     ---- U2 units: all energies and toughnesses times 1000 ----
      EMAX = 0.0D0
      DO 10 K = 1, 4
         G1 = 0.005D0
         IF (K .EQ. 2) G1 = 0.03D0
         IF (K .EQ. 3) G1 = 0.1D0
         IF (K .EQ. 4) G1 = 0.0033D0
         G2 = 0.5D0*G1
         CALL K17_CALL(PROPS,G1,G2,0.0D0,RR**2*G1,RR**2*G2,0.0D0,D1)
         PS = PROPS
         PS(4) = 1.0D3*GIC
         PS(5) = 1.0D3*GIIC
         PS(6) = 1.0D3*GIIIC
         CALL K17_CALL(PS,1.0D3*G1,1.0D3*G2,0.0D0,1.0D3*RR**2*G1,
     1    1.0D3*RR**2*G2,0.0D0,D2)
         EMAX = MAX(EMAX, ABS(D2 - D1)/MAX(D1, 1.0D-300))
   10 CONTINUE
      WRITE(*,'(A,I2,1PE14.5)') 'U2', MERGE(1,0,EMAX .LT. 1.0D-12),EMAX
!     ---- U3 critical G of the mode mix (K15_GC) ----
      EMAX = 0.0D0
      CALL K15_GC(1.0D0,0.0D0,0.0D0,GIC,GIIC,GIIIC,ETA,0,GC,A1,A2,
     1 BM,XI)
      EMAX = MAX(EMAX, ABS(GC/GIC - 1.0D0))
      CALL K15_GC(0.0D0,1.0D0,0.0D0,GIC,GIIC,GIIIC,ETA,0,GC,A1,A2,
     1 BM,XI)
      EMAX = MAX(EMAX, ABS(GC/GIIC - 1.0D0))
      CALL K15_GC(0.7D0,0.3D0,0.0D0,GIC,GIIC,GIIIC,ETA,0,GC,A1,A2,
     1 BM,XI)
      EMAX = MAX(EMAX, ABS(GC/(GIC + (GIIC-GIC)*0.3D0**ETA) - 1.0D0))
      CALL K15_GC(0.0D0,0.0D0,1.0D0,GIC,GIIC,GIIIC,ETA,1,GC,A1,A2,
     1 BM,XI)
      EMAX = MAX(EMAX, ABS(GC/GIIIC - 1.0D0))
      CALL K15_GC(0.4D0,0.3D0,0.3D0,GIC,GIIC,GIIIC,ETA,1,GC,A1,A2,
     1 BM,XI)
      GR = GIC + (GIIC - GIC + (GIIIC-GIIC)*0.5D0)*0.6D0**ETA
      EMAX = MAX(EMAX, ABS(GC/GR - 1.0D0))
      WRITE(*,'(A,I2,1PE14.5)') 'U3', MERGE(1,0,EMAX .LT. 1.0D-12),EMAX
!     ---- U4 derivatives of GC by central differences ----
      EMAX = 0.0D0
      DO 20 K = 1, 3
         B = 0.2D0 + 0.3D0*(K-1)
         CALL K15_GC(1.0D0-B,B,0.0D0,GIC,GIIC,GIIIC,ETA,0,GC,DB,DE,
     1    BM,XI)
         H = 1.0D-6
         CALL K15_GC(1.0D0-B-H,B+H,0.0D0,GIC,GIIC,GIIIC,ETA,0,GP,
     1    A1,A2,BM,XI)
         CALL K15_GC(1.0D0-B+H,B-H,0.0D0,GIC,GIIC,GIIIC,ETA,0,GM,
     1    A1,A2,BM,XI)
         EMAX = MAX(EMAX, ABS((GP-GM)/(2.0D0*H)/DB - 1.0D0))
         CALL K15_GC(1.0D0-B,B,0.0D0,GIC,GIIC,GIIIC,ETA+H,0,GP,A1,A2,
     1    BM,XI)
         CALL K15_GC(1.0D0-B,B,0.0D0,GIC,GIIC,GIIIC,ETA-H,0,GM,A1,A2,
     1    BM,XI)
         EMAX = MAX(EMAX, ABS((GP-GM)/(2.0D0*H)/DE - 1.0D0))
   20 CONTINUE
      WRITE(*,'(A,I2,1PE14.5)') 'U4', MERGE(1,0,EMAX .LT. 1.0D-6),EMAX
!     ---- U5 limits ----
      IOK = 1
      GCI = GIC
      CALL K17_CALL(PROPS,0.1D0,0.0D0,0.0D0,0.1D0,0.0D0,0.0D0,D)
      IF (D .NE. 0.0D0) IOK = 0
      CALL K17_CALL(PROPS,0.5D0*0.01D0*GCI,0.0D0,0.0D0,0.0D0,0.0D0,
     1 0.0D0,D)
      IF (D .NE. 0.0D0) IOK = 0
      CALL K17_CALL(PROPS,1.05D0*0.01D0*GCI,0.0D0,0.0D0,0.0D0,0.0D0,
     1 0.0D0,D)
      IF (.NOT. (D .GT. 0.0D0)) IOK = 0
      CALL K17_CALL(PROPS,3.0D0*GCI,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,D)
      IF (ABS(D/C3 - 1.0D0) .GT. 1.0D-12) IOK = 0
      DO 30 K = 1, 60
         G = 1.0D-3*1.12D0**K
         CALL K17_CALL(PROPS,G,0.3D0*G,0.0D0,RR**2*G,RR**2*0.3D0*G,
     1    0.0D0,RT(K))
         IF (RT(K) .LT. 0.0D0) IOK = 0
         IF (K .GT. 1) THEN
            IF (RT(K) .LT. RT(K-1)) IOK = 0
         ENDIF
   30 CONTINUE
      WRITE(*,'(A,I2,I4)') 'U5', IOK, IOK
!     ---- U6 plate life against the closed form ----
      CALL K17_PROP(2,PS)
      A0 = 4.0D0
      AF = (1100.0D0/(100.0D0*SQRT(PI)))**2
      XM = 3.0D0
      CMM = 5.0D-11*1000.0D0/1000.0D0**1.5D0
      XNX = (AF**(1.0D0-XM/2.0D0) - A0**(1.0D0-XM/2.0D0))
     1 /((1.0D0-XM/2.0D0)*CMM*(90.0D0*SQRT(PI))**XM)
      CALL K17_LIFE(1,PS,A0,AF,0.01D0,1,XE,XT)
      ERR = XT/XNX - 1.0D0
      WRITE(*,'(A,I2,1PE14.5)') 'U6', MERGE(1,0,ABS(ERR) .LT. 1.0D-5),
     1 ERR
!     ---- U7 order in the increment, order of evaluation ----
      DO 40 K = 1, 4
         CALL K17_LIFE(3,PROPS,30.0D0,50.0D0,DAV(K),1,EE(K),ET(K))
   40 CONTINUE
      CALL K17_LIFE(3,PROPS,30.0D0,50.0D0,20.0D0/20480.0D0,1,XE,XR)
      P1 = LOG((EE(3)/XR-1.0D0)/(EE(4)/XR-1.0D0))/LOG(2.0D0)
      P2 = LOG((ET(3)/XR-1.0D0)/(ET(4)/XR-1.0D0))/LOG(2.0D0)
      CALL K17_LIFE(3,PROPS,30.0D0,50.0D0,0.25D0,1,XF,TF)
      CALL K17_LIFE(3,PROPS,30.0D0,50.0D0,0.25D0,-1,XB,TB)
      CALL K17_LIFE(3,PROPS,30.0D0,40.0D0,0.25D0,1,X1,T1)
      CALL K17_LIFE(3,PROPS,40.0D0,50.0D0,0.25D0,1,X2,T2)
      ADD = MAX(ABS(TF/TB - 1.0D0), ABS(TF/(T1+T2) - 1.0D0))
!     independent reference: Simpson on the Benzeggagh-Kenane rate
      NS = 2000
      HS = 20.0D0/NS
      SS = 0.0D0
      DO 50 K = 0, NS
         WGT = 2.0D0
         IF (MOD(K,2) .EQ. 1) WGT = 4.0D0
         IF (K .EQ. 0 .OR. K .EQ. NS) WGT = 1.0D0
         SS = SS + WGT/K17_REF(30.0D0 + HS*K)
   50 CONTINUE
      SS = SS*HS/3.0D0
      ERR = XR/SS - 1.0D0
      WRITE(*,'(A,I2,1P,4E14.5)') 'U7', MERGE(1,0,ABS(P1-1.0D0) .LT.
     1 0.15D0 .AND. ABS(P2-2.0D0) .LT. 0.15D0 .AND. ADD .LT. 1.0D-12
     2 .AND. ABS(ERR) .LT. 1.0D-6), P1, P2, ADD, ERR
      RETURN
      END
!
      FUNCTION K17_REF(A)
!     rate of the changing-mix case, BK law written out directly
      INCLUDE 'ABA_PARAM.INC'
      REAL*8 K17_REF
      G1 = 0.10D0*30.0D0/A
      G2 = 0.04D0*A/30.0D0
      GT = G1 + G2
      B = G2/GT
      GC = 0.28D0 + (0.79D0 - 0.28D0)*B**1.45D0
      DG = (SQRT(GT) - SQRT(1.0D-2*GT))**2
      K17_REF = 0.5D0*MIN(DG/GC, 1.0D0)**5
      RETURN
      END
