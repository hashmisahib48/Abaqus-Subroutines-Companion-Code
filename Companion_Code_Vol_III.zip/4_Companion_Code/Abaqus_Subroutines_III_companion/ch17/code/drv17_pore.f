      PROGRAM DRV17P
!     Water balance of the consolidation column of Chapter 10.
!     The drain is the surface TOPDRAIN of FLOW (ex10_6_flow.f), the
!     base is impervious.  Excess pore pressure U0 (MPa) is uniform
!     at t = 0.  Per unit area (mm^3/mm^2 = mm):
!       expelled   VOUT = sum of Q*DT, Q = outward velocity from FLOW
!       stored     VST  = (U0*XL - integral of U dy)/EOED
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 4001, GAMMAW = 9.81D-6)
      PARAMETER (PERM = 1.0D-6, EOED = 2.0D0)  ! mm/s, MPa
      PARAMETER (XL = 1.0D4, N = 200, U0 = 0.1D0)
      DIMENSION U(NMAX), UO(NMAX), TOUT(60)
      READ(*,*) DT0, GROW, DTMAX, NOUT
      READ(*,*) (TOUT(K), K = 1, NOUT)
      NN = N + 1
      H = XL/N
      DO 10 I = 1, NN
         U(I) = U0
         UO(I) = U0
   10 CONTINUE
      T = 0.0D0
      DT = DT0
      VOUT = 0.0D0
      K = 1
      NS = 0
      DO 100 ISTEP = 1, 2000000
         DTUSE = MIN(DT, TOUT(K) - T)
         TNEW = T + DTUSE
         CALL H10_STEP(N,XL,0.0D0,PERM,EOED,0.0D0,2,DTUSE,TNEW,UO,U,
     1    NIT)
         CALL H10_QN(2,XL,TNEW,U(NN),Q,DQ)
         VOUT = VOUT + Q*DTUSE
         NS = NS + 1
         T = TNEW
         DO 20 I = 1, NN
            UO(I) = U(I)
   20    CONTINUE
         DT = MIN(DT*GROW, DTMAX)
         IF (ABS(T - TOUT(K)) .LE. 1.0D-9*TOUT(K)) THEN
            SU = 0.0D0
            DO 30 I = 1, N
               SU = SU + 0.5D0*H*(U(I) + U(I+1))
   30       CONTINUE
            VST = (U0*XL - SU)/EOED
            WRITE(*,'(A,I6,1P,5E18.9)') 'POR', NS, T, VOUT, VST,
     1       (VOUT - VST)/(U0*XL/EOED), VOUT/(U0*XL/EOED)
            K = K + 1
            IF (K .GT. NOUT) GOTO 200
         ENDIF
  100 CONTINUE
  200 CONTINUE
      END
