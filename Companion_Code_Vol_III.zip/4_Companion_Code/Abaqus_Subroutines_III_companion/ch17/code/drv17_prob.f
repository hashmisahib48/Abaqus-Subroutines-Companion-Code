      PROGRAM DRV17PR
!     Problem 17A.1: spot with ETA = 0.40, P = 1.5E5 mW, W = 0.8 mm
!     (constants changed in a copy of ex17_dflux.f).  Prints the
!     centre flux, the flux at R90 and the power inside R90.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0)
      DIMENSION FLUX(2), TIME(2), COORDS(3)
      CHARACTER*80 SNAME
      TIME(1) = 0.1D0
      TIME(2) = 0.1D0
      COORDS(2) = 0.0D0
      COORDS(3) = 0.0D0
      SNAME = 'SPOT'
      COORDS(1) = 0.0D0
      CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,0,20.0D0,0.0D0,SNAME)
      Q0 = FLUX(1)
      R90 = 0.8D0*SQRT(LOG(10.0D0)/2.0D0)
      COORDS(1) = R90
      CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,0,20.0D0,0.0D0,SNAME)
      QR = FLUX(1)
      N = 4000
      H = R90/N
      S = 0.0D0
      DO 10 K = 0, N
         COORDS(1) = H*K
         CALL DFLUX(FLUX,20.0D0,1,1,TIME,1,1,COORDS,0,20.0D0,0.0D0,
     1    SNAME)
         WGT = 2.0D0
         IF (MOD(K,2) .EQ. 1) WGT = 4.0D0
         IF (K .EQ. 0 .OR. K .EQ. N) WGT = 1.0D0
         S = S + WGT*FLUX(1)*2.0D0*PI*H*K
   10 CONTINUE
      S = S*H/3.0D0
      WRITE(*,'(A,1P,5E16.8)') 'A1', Q0, R90, QR, S, S/(0.4D0*1.5D5)
      END
