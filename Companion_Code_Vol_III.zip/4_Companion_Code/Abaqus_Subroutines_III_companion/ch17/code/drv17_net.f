      PROGRAM DRV17N
!     Three pipes in parallel between nodes A and B (Chapter 12
!     routines).  Units: N, mm, s, tonne; flow in mm^3/s, DP in MPa.
!     MODE 1: split of QT (read) and the checks N1-N3
!     MODE 2: properties of the friction law, N4-N6
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K17_NET/ RHO, VISC
      READ(*,*) MODE, ENU
      RHO = 1.0D-9
      VISC = ENU*RHO
      IF (MODE .EQ. 1) THEN
         READ(*,*) QT
         CALL K17_SPLIT(QT)
      ELSE
         CALL K17_PROPS
      ENDIF
      END
!
      SUBROUTINE K17_DP(IB,Q,DP)
!     signed pressure drop of branch IB at the signed flow Q
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K17_NET/ RHO, VISC
      DIMENSION TIME(2), COORDS(6), IA(1), RA(1)
      CHARACTER*80 CA(1)
      PARAMETER (PI = 3.14159265358979D0, EPS = 0.046D0)
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      IF (IB .EQ. 1) THEN
         XL = 5.0D4
         DIA = 100.0D0
         NEL = 2
      ELSE IF (IB .EQ. 2) THEN
         XL = 8.0D4
         DIA = 80.0D0
         NEL = 1
      ELSE
         XL = 3.0D4
         DIA = 60.0D0
         NEL = 0
      ENDIF
      AREA = 0.25D0*PI*DIA*DIA
      CALL UFLUIDPIPEFRICTION(F,Q,RHO,VISC,EPS,DIA,AREA,3,IB,1,1,
     1 TIME,COORDS,1,IA,1,RA,1,CA)
      CALL UFLUIDCONNECTORLOSS(AK1,AK2,COORDS,Q,RHO,VISC,DIA,AREA,3,
     1 IB,1,1,TIME,1,IA,1,RA,1,CA)
      V = Q/AREA
      DP = (F*XL/DIA + NEL*AK1)*0.5D0*RHO*V*ABS(V)
      RETURN
      END
!
      SUBROUTINE K17_QOF(IB,DP,Q)
!     flow of branch IB for a given pressure drop (bisection)
      INCLUDE 'ABA_PARAM.INC'
      QL = 0.0D0
      QH = 1.0D10
      SG = SIGN(1.0D0, DP)
      DO 10 IT = 1, 200
         QM = 0.5D0*(QL + QH)
         CALL K17_DP(IB,QM,D)
         IF (D .LT. ABS(DP)) THEN
            QL = QM
         ELSE
            QH = QM
         ENDIF
   10 CONTINUE
      Q = SG*0.5D0*(QL + QH)
      RETURN
      END
!
      SUBROUTINE K17_SPLIT(QT)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION QB(3), D(3)
      SG = SIGN(1.0D0, QT)
      DL = 0.0D0
      DH = 1.0D3
      DO 10 IT = 1, 200
         DM = 0.5D0*(DL + DH)
         S = 0.0D0
         DO 5 IB = 1, 3
            CALL K17_QOF(IB,DM,QB(IB))
            S = S + QB(IB)
    5    CONTINUE
         IF (S .LT. ABS(QT)) THEN
            DL = DM
         ELSE
            DH = DM
         ENDIF
   10 CONTINUE
      DPN = SG*0.5D0*(DL + DH)
      S = 0.0D0
      XCLS = 0.0D0
      DO 20 IB = 1, 3
         CALL K17_QOF(IB,DPN,QB(IB))
         CALL K17_DP(IB,QB(IB),D(IB))
         S = S + QB(IB)
         XCLS = MAX(XCLS, ABS(D(IB)/DPN - 1.0D0))
   20 CONTINUE
      WRITE(*,'(A,1P,6E16.8)') 'SPLIT', QT, DPN, QB(1), QB(2), QB(3),
     1 S/QT - 1.0D0
      WRITE(*,'(A,1P,2E16.8)') 'LOOP ', XCLS, S/QT - 1.0D0
      RETURN
      END
!
      SUBROUTINE K17_PROPS
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K17_NET/ RHO, VISC
      DIMENSION TIME(2), COORDS(6), IA(1), RA(1)
      CHARACTER*80 CA(1)
      PARAMETER (PI = 3.14159265358979D0, EPS = 0.046D0)
      DIA = 100.0D0
      AREA = 0.25D0*PI*DIA*DIA
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      EVEN = 0.0D0
      DO 10 K = 1, 40
         RE = 10.0D0**(1.0D0 + 0.1D0*K)
         Q = RE*VISC*AREA/(RHO*DIA)
         CALL UFLUIDPIPEFRICTION(F1,Q,RHO,VISC,EPS,DIA,AREA,3,1,1,1,
     1    TIME,COORDS,1,IA,1,RA,1,CA)
         CALL UFLUIDPIPEFRICTION(F2,-Q,RHO,VISC,EPS,DIA,AREA,3,1,1,1,
     1    TIME,COORDS,1,IA,1,RA,1,CA)
         EVEN = MAX(EVEN, ABS(F1/F2 - 1.0D0))
   10 CONTINUE
      WRITE(*,'(A,1PE14.5)') 'EVEN ', EVEN
      XJMP = 0.0D0
      FOLD = 0.0D0
      DO 20 K = 0, 6000
         RE = 1000.0D0 + K
         Q = RE*VISC*AREA/(RHO*DIA)
         CALL UFLUIDPIPEFRICTION(F1,Q,RHO,VISC,EPS,DIA,AREA,3,1,1,1,
     1    TIME,COORDS,1,IA,1,RA,1,CA)
         IF (K .GT. 0) XJMP = MAX(XJMP, ABS(F1/FOLD - 1.0D0))
         FOLD = F1
         IF (MOD(K,50) .EQ. 0) WRITE(*,'(A,F8.0,1PE14.5)') 'FRIC',RE,F1
   20 CONTINUE
      WRITE(*,'(A,1PE14.5)') 'XJMP ', XJMP
!     slope of the pressure drop: exponent n = d ln DP / d ln Q
      XNMIN = 1.0D30
      XNMAX = -1.0D30
      DO 40 IB = 1, 3
         DO 30 K = 0, 700
            Q = 10.0D0**(2.0D0 + 0.01D0*K)
            CALL K17_DP(IB,Q*1.0001D0,DPP)
            CALL K17_DP(IB,Q/1.0001D0,DPM)
            XN = LOG(DPP/DPM)/(2.0D0*LOG(1.0001D0))
            XNMIN = MIN(XNMIN, XN)
            XNMAX = MAX(XNMAX, XN)
   30    CONTINUE
   40 CONTINUE
      WRITE(*,'(A,1P,2E14.5)') 'EXPON', XNMIN, XNMAX
      RETURN
      END
