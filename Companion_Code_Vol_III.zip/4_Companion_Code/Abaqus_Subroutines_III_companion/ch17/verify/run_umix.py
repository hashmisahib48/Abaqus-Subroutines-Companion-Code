import subprocess, json, re
R='/home/claude/vol3/ch17'; A='/home/claude/vol3/lib/aba'
src=open(R+'/code/ex17_umix.f').read()
CALLK="""      CALL K15_GC(GI_MAX, GII_MAX, GIII_MAX, PROPS(4), PROPS(5),
     1 PROPS(6), PROPS(7), IREED, GC, DGCDB, DGCDE, BMIX, XI)
"""
F={
 'G1':('range taken as Gmax - Gmin',"DG = (SQRT(MAX(GTMAX,0.0D0)) - SQRT(MAX(GTMIN,0.0D0)))**2","DG = GTMAX - GTMIN"),
 'G2':('mix from the mode I fraction',"IF (GT .GT. 0.0D0) BMIX = GS/GT","IF (GT .GT. 0.0D0) BMIX = G1/GT"),
 'G3':('threshold in absolute units',"IF (GTMAX .GE. GTH*GC .AND.","IF (GTMAX .GE. GTH .AND."),
 'G4':('DADN not set to zero',"      DADN = 0.0D0\n      IF (GTMAX","      IF (GTMAX"),
 'G5':('ratio not limited to 1',"DADN = C3*MIN(DG/GC, 1.0D0)**C4","DADN = C3*(DG/GC)**C4"),
 'G6':('derivative with exponent eta',"DGCDB = A*ETA*BMIX**(ETA - 1.0D0)","DGCDB = A*ETA*BMIX**ETA"),
 'G7':('exponent c4/2, as for K',"DADN = C3*MIN(DG/GC, 1.0D0)**C4","DADN = C3*MIN(DG/GC, 1.0D0)**(0.5D0*C4)"),
 'G8':('mix from the minimum load',CALLK,CALLK.replace('GI_MAX, GII_MAX, GIII_MAX','GI_MIN, GII_MIN, GIII_MIN')),
 'G9':('eta read from PROPS(6)',"PROPS(6), PROPS(7), IREED, GC","PROPS(6), PROPS(6), IREED, GC"),
 'G10':('toughness kept from the first call',CALLK,"      IF (.NOT. SET) THEN\n"+CALLK+"         SET = .TRUE.\n      ENDIF\n"),
}
def build(tag,text):
    f=f'{R}/build/um_{tag}.f'; open(f,'w').write(text); exe=f'{R}/build/um_{tag}'
    r=subprocess.run(['gfortran','-ffixed-form','-std=legacy','-I'+A,R+'/code/drv17_umix.f',f,R+'/build/umixk.f',A+'/stubs.f','-o',exe],capture_output=True,text=True)
    if r.returncode: raise SystemExit(tag+r.stderr[:2500])
    return exe
def run(exe,mode): return subprocess.run([exe],input=f'{mode}\n',capture_output=True,text=True,timeout=300).stdout
def parse(out):
    d={}
    for ln in out.splitlines():
        m=re.match(r'(U\d)\s+(\d)\s+(.*)',ln)
        if m: d[m.group(1)]=(int(m.group(2)),m.group(3).split())
    return d
res={'base':parse(run(build('base',src),2)),'faults':{},'labels':{}}
for k,(lab,a,b) in F.items():
    assert a in src,(k,a)
    t=src.replace(a,b,1)
    if k=='G10': t=t.replace("      INCLUDE 'ABA_PARAM.INC'\n!\n      DIMENSION PROPS(NPROPS)","      INCLUDE 'ABA_PARAM.INC'\n!\n      LOGICAL SET\n      SAVE SET, GC\n      DATA SET /.FALSE./\n      DIMENSION PROPS(NPROPS)",1); assert 'SAVE SET' in t
    exe=build(k,t); res['faults'][k]=parse(run(exe,2)); res['labels'][k]=lab
res['rep']=run(f'{R}/build/um_base',1)
json.dump(res,open(R+'/verify/out/umix.json','w'),indent=1)
open(R+'/verify/out/umix_rep.txt','w').write(res['rep'])
T=['U%d'%i for i in range(1,8)]
print('base',[res['base'][t][0] for t in T])
for k in F: print(k,[res['faults'][k].get(t,(None,))[0] for t in T],res['labels'][k])
