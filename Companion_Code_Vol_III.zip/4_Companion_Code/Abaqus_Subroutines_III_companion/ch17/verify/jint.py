import numpy as np, json
E=210000.0; nu=0.3; K=100.0; mu=E/(2*(1+nu)); kap=3-4*nu
Ep=E/(1-nu**2); Jex=K**2/Ep
Cm=E/((1+nu)*(1-2*nu))*np.array([[1-nu,nu,0],[nu,1-nu,0],[0,0,(1-2*nu)/2]])
def disp(r,t):
    f=K/(2*mu)*np.sqrt(r/(2*np.pi))
    return np.array([f*np.cos(t/2)*(kap-1+2*np.sin(t/2)**2), f*np.sin(t/2)*(kap+1-2*np.cos(t/2)**2)])
def mesh(rr,nth):
    # nodes: tip, then rings 1..NR with nth+1 nodes (seam duplicated)
    th=np.linspace(-np.pi,np.pi,nth+1); X=[(0.0,0.0)]; U=[(0.0,0.0)]; ring=[0]
    idx={}
    for j,r in enumerate(rr,1):
        for i,t in enumerate(th):
            idx[(j,i)]=len(X); X.append((r*np.cos(t),r*np.sin(t))); U.append(tuple(disp(r,t))); ring.append(j)
    tri=[]; strip=[]
    for i in range(nth):          # tip fan, strip 1
        tri.append((0,idx[(1,i)],idx[(1,i+1)])); strip.append(1)
    for j in range(1,len(rr)):
        for i in range(nth):
            a,b,c,d=idx[(j,i)],idx[(j+1,i)],idx[(j+1,i+1)],idx[(j,i+1)]
            tri.append((a,b,c)); strip.append(j+1); tri.append((a,c,d)); strip.append(j+1)
    return np.array(X),np.array(U),np.array(ring),np.array(tri),np.array(strip)
def Jstrips(rr,nth):
    X,U,ring,tri,strip=mesh(rr,nth); out={}
    for k in range(1,len(rr)+1):
        q=(ring<=k-1).astype(float); J=0.0
        for e,s in zip(tri,strip):
            if s!=k: continue
            xy=X[e]; A2=np.linalg.det(np.array([[1,*xy[0]],[1,*xy[1]],[1,*xy[2]]])); A=abs(A2)/2
            G=np.linalg.solve(np.array([[1,*xy[0]],[1,*xy[1]],[1,*xy[2]]]),np.eye(3))[1:,:]  # dN/dx : 2x3
            u=U[e]                       # 3x2
            gu=G@u                       # gu[j,i]=du_i/dx_j
            eps=np.array([gu[0,0],gu[1,1],gu[0,1]+gu[1,0]]); sg=Cm@eps
            W=0.5*sg@eps
            S=np.array([[sg[0],sg[2]],[sg[2],sg[1]]])
            gq=G@q[e]
            for jj in range(2):
                J+=A*((S[:,0]*gu[0,:]).sum()*gq[0]*(jj==0)+(S[:,1]*gu[0,:]).sum()*gq[1]*(jj==1)) if False else 0
            # (sigma_ij u_i,1 - W delta_1j) q,j
            t1=sum(S[i_,j_]*gu[0,i_]*gq[j_] for i_ in range(2) for j_ in range(2)); t2=W*gq[0]
            J+=A*(t1-t2)
        out[k]=J
    return out
if __name__=='__main__':
    res={'Jex':Jex,'cases':{}}
    for name,(rr,nth) in {'h1_n16':(np.arange(1,11)*1.0,16),'h1_n32':(np.arange(1,11)*1.0,32),'h1_n64':(np.arange(1,11)*1.0,64),'h1_n128':(np.arange(1,11)*1.0,128)}.items():
        o=Jstrips(rr,nth); res['cases'][name]={k:v/Jex for k,v in o.items()}
        print(name,[round(v/Jex,4) for v in o.values()])
    json.dump(res,open('out/jint.json','w'),indent=1)
