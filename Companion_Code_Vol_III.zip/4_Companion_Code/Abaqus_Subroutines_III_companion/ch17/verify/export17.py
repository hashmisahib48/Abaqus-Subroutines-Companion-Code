import json, re
V='/home/claude/vol3/ch17/verify/out/'
def lines(f,key): return [l.split() for l in open(V+f) if l.startswith(key)]
B={}
B['bar']=[[float(x) for x in l[1:]] for l in lines('dflux_rep.txt','BAR')]      # ic, dt, md, ein, est, elost, res, t1, tl
B['bar6']=[[float(x) for x in l[1:]] for l in lines('dflux_rep_F6.txt','BAR')]
B['err']={f'{l[1]}{l[2]}':[float(x) for x in l[3:]] for l in lines('dflux_rep.txt','ERR')}
B['ord']={f'{l[1]}{l[2]}':[float(x) for x in l[3:]] for l in lines('dflux_rep.txt','ORD')}
B['err6']={f'{l[1]}{l[2]}':[float(x) for x in l[3:]] for l in lines('dflux_rep_F6.txt','ERR')}
B['ord6']={f'{l[1]}{l[2]}':[float(x) for x in l[3:]] for l in lines('dflux_rep_F6.txt','ORD')}
B['newton']={int(l[1]):[int(l[2]),int(l[3]),int(l[4]),float(l[5])] for l in lines('dflux_rep.txt','NEW')}
B['res']={int(l[1]):[float(x) for x in l[2:]] for l in lines('dflux_rep.txt','RES')}
D=json.load(open(V+'dflux.json')); U=json.load(open(V+'umix.json'))
B['dbase']=D['base']; B['dfaults']=D['faults']; B['ubase']=U['base']; B['ufaults']=U['faults']
B['life']={k:[[float(x) for x in l[1:]] for l in lines('umix_rep.txt',k)] for k in ('LIFE1','LIFE2','LIFE3','ORD1','ORD2')}
B['plate']=[float(x) for x in lines('umix_rep.txt','PLATE')[0][1:]]
B['ref2']=float(lines('umix_rep.txt','REF2')[0][1]); B['mix3']=[float(x) for x in lines('umix_rep.txt','MIX3')[0][1:]]; B['kform']=float(lines('umix_rep.txt','KFORM')[0][1])
B['jint']=json.load(open(V+'jint.json')); F=json.load(open(V+'fluid.json')); B['fluid']=F
def nparse(txt):
    d={}
    for l in txt.splitlines():
        p=l.split()
        if p and p[0]=='SPLIT': d['split']=[float(x) for x in p[1:]]
        if p and p[0]=='LOOP': d['loop']=[float(x) for x in p[1:]]
        if p and p[0] in('EVEN','XJMP'): d[p[0]]=float(p[1])
        if p and p[0]=='EXPON': d['expon']=[float(x) for x in p[1:]]
    return d
B['net']={k:nparse(v) for k,v in F['net'].items()}; B['netp']=nparse(F['props']); B['net_f1']={k:nparse(v) for k,v in F['net_f1'].items()}; B['netp_f1']=nparse(F['props_f1'])
json.dump(B,open(V+'book.json','w'),indent=1)
print(B['net'],B['netp'],B['net_f1'],B['netp_f1'])
# sweep minima
sw={}
for l in open(V+'dflux_sweep.txt'):
    p=l.split(); sw.setdefault(p[1],[]).append((float(p[2]),float(p[4]),float(p[3])))
B['sweep']={T:{'hmin':min(v,key=lambda x:x[1])[0],'emin':min(v,key=lambda x:x[1])[1],'f2':v[0][2]} for T,v in sw.items()}
B['sw800_1e8']=[x for x in sw['800.0'] if abs(x[0]-1e-8)<1e-12][0][1]
B['probs']={}
json.dump(B,open(V+'book.json','w'),indent=1)
print(B['sweep'])
