import subprocess, json, re, os
R='/home/claude/vol3/ch17'; A='/home/claude/vol3/lib/aba'
src=open(R+'/code/ex17_dflux.f').read()
F={
 'F1':('Gaussian amplitude lacks the factor 2',"FLUX(1) = 2.0D0*ETA*P/(PI*W**2)*EXP","FLUX(1) = ETA*P/(PI*W**2)*EXP"),
 'F2':('exponent without the factor 2',"EXP(-2.0D0*R2/W**2)\n      ELSE IF (INDEX(SNAME,'HOTLOSS')","EXP(-R2/W**2)\n      ELSE IF (INDEX(SNAME,'HOTLOSS')"),
 'F3':('power in W, not mW',"P = 2.0D5","P = 2.0D2"),
 'F4':('spot cut off at r = 2w',"         FLUX(1) = 2.0D0*ETA*P/(PI*W**2)*EXP(-2.0D0*R2/W**2)\n","         FLUX(1) = 2.0D0*ETA*P/(PI*W**2)*EXP(-2.0D0*R2/W**2)\n         IF (R2 .GT. 4.0D0*W**2) FLUX(1) = 0.0D0\n"),
 'F5':('pulse applied to every other label',"ELSE IF (INDEX(SNAME,'PULSE') .GT. 0) THEN","ELSE"),
 'F6':('pulse sampled at the end of the increment',"FLUX(1) = Q0*ON/DTINC","IF (TE .GT. T1 .AND. TE .LE. T2) FLUX(1) = Q0"),
 'F7':('DTINC kept from the first increment',"IF (LOP .EQ. 1) DTINC = DTIME","IF (LOP .EQ. 1 .AND. KINC .EQ. 1) DTINC = DTIME"),
 'F8':('radiation term of FLUX(2) lacks the factor 4',"- 4.0D0*EPS*SIG*TK**3","- EPS*SIG*TK**3"),
 'F9':('sign of the radiation loss reversed',"FLUX(1) = AL*XI - EPS*SIG*(TK**4 - TIK**4)","FLUX(1) = AL*XI + EPS*SIG*(TK**4 - TIK**4)"),
}
def build(tag,text):
    f=f'{R}/build/dfl_{tag}.f'; open(f,'w').write(text)
    exe=f'{R}/build/dfl_{tag}'
    r=subprocess.run(['gfortran','-ffixed-form','-std=legacy','-I'+A,R+'/code/drv17_dflux.f',f,A+'/stubs.f','-o',exe],capture_output=True,text=True)
    if r.returncode: raise SystemExit(r.stderr[:2000])
    return exe
def run(exe,mode):
    return subprocess.run([exe],input=f'{mode}\n',capture_output=True,text=True,timeout=120).stdout
def parse(out):
    d={}
    for ln in out.splitlines():
        m=re.match(r'(D\d)\s+(\d)\s+(.*)',ln)
        if m: d[m.group(1)]=(int(m.group(2)),m.group(3).split())
    return d
res={'base':parse(run(build('base',src),2)),'faults':{},'labels':{}}
for k,(lab,a,b) in F.items():
    assert a in src,(k,a)
    exe=build(k,src.replace(a,b,1)); out=run(exe,2); res['faults'][k]=parse(out); res['labels'][k]=lab
    if k=='F6': res['rep_F6']=run(exe,1)
res['rep']=run(f'{R}/build/dfl_base',1)
json.dump(res,open(R+'/verify/out/dflux.json','w'),indent=1)
T=['D%d'%i for i in range(1,8)]
print('base',[res['base'][t][0] for t in T])
for k in F: print(k,[res['faults'][k][t][0] for t in T],res['labels'][k])
open(R+'/verify/out/dflux_rep.txt','w').write(res['rep']); open(R+'/verify/out/dflux_rep_F6.txt','w').write(res['rep_F6'])
