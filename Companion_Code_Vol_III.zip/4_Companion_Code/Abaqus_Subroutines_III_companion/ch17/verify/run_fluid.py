import subprocess, json, numpy as np
from scipy.optimize import brentq
R='/home/claude/vol3/ch17'; A='/home/claude/vol3/lib/aba'
GW=9.81e-6; K=1e-6; E=2.0; D=K/GW; CV=K*E/GW; L=1e4
def lam(Bi,n=300):
    out=[]
    for m in range(n):
        a=m*np.pi+1e-12; b=m*np.pi+np.pi/2-1e-12
        out.append(brentq(lambda x:x*np.tan(x)-Bi,a,b))
    return np.array(out)
def U_rob(Tv,Bi):
    l=lam(Bi); A_=2*np.sin(l)/(l+np.sin(l)*np.cos(l))
    return 1-np.sum(A_*np.sin(l)/l*np.exp(-l**2*Tv))
src=open(R+'/code/ex10_6_flow.f').read()
a="H = SMEARK/(GAMMAW*SMEART)"; assert a in src
open(R+'/build/flow_low.f','w').write(src.replace(a,"H = 0.01D0*SMEARK/(GAMMAW*SMEART)"))
subprocess.run(['sh',R+'/build/mkpore.sh',R+'/build/flow_low.f',R+'/build/pore_low'],check=True)
subprocess.run(['sh',R+'/build/mkpore.sh',R+'/code/ex10_6_flow.f',R+'/build/pore'],check=True)
Hs=5e-8/(GW*5.0); Bi=Hs*L/D
def run(exe,inp):
    out=subprocess.run([exe],input=inp,capture_output=True,text=True).stdout
    return [list(map(float,l.split()[1:])) for l in out.splitlines() if l.startswith('POR')]
TO=[2e7,1e8,3e8,5e8,5e9]
res={'Bi':Bi,'Bilow':0.01*Bi,'cv':CV,'tout':TO,'cases':{}}
inp=lambda dt,g,dm:f"{dt} {g} {dm} {len(TO)}\n"+" ".join(repr(t) for t in TO)+"\n"
for name,dt in (('dt1e5',1e5),('dt1e6',1e6),('dt1e7',1e7)):
    res['cases'][name]=run(R+'/build/pore',inp(dt,1.0,dt))
res['cases']['var']=run(R+'/build/pore',inp(1e4,1.15,2e7))
res['low']=run(R+'/build/pore_low',inp(1e6,1.0,1e6))
res['closed']=[U_rob(CV*t/L**2,Bi) for t in TO]
res['closedlow']=[U_rob(CV*t/L**2,0.01*Bi) for t in TO]
res['declared']=0.1*L/E
# network
def net(exe,mode,txt): return subprocess.run([exe],input=txt,capture_output=True,text=True).stdout
res['net']={}
for q in (2e5,8e5,3e7,-3e7):
    res['net'][str(q)]=net(R+'/build/net',1,f"1 1.0\n{q}\n")
res['props']=net(R+'/build/net',2,"2 1.0\n")
subprocess.run(['gfortran','-ffixed-form','-std=legacy','-I'+A,R+'/code/drv17_net.f',R+'/build/fric_f1.f',R+'/code/k12_connloss.f',A+'/stubs.f','-o',R+'/build/net_f1'],check=True)
res['net_f1']={str(q):net(R+'/build/net_f1',1,f"1 1.0\n{q}\n") for q in (3e7,-3e7)}
res['props_f1']=net(R+'/build/net_f1',2,"2 1.0\n")
json.dump(res,open(R+'/verify/out/fluid.json','w'),indent=1)
print('Bi',Bi,res['declared'])
for k,v in res['cases'].items(): print(k,[ (x[0],round(x[4],6),x[3]) for x in v])
print('low',[(x[0],round(x[4],6)) for x in res['low']]); print('closed',res['closed']); print('closedlow',res['closedlow'])
