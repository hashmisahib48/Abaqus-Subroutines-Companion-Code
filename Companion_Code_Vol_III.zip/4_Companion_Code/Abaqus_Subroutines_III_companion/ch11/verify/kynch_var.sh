#!/bin/sh
# FV runs for Problems 11B.3 (c0 = 0.1, 100 s) and 11C.2 (c0 = 0.4, 1000 s): sed on the driver, files to /tmp
A=/home/claude/vol3/lib/aba; F="-ffixed-form -std=legacy -I$A"; T=/tmp/claude-0/kv; mkdir -p $T; cd $T
for v in "0.1D0 100.0D0 a" "0.4D0 1000.0D0 b"; do set -- $v
  sed "s/C0 = 0.2D0/C0 = $1/;s/TOUT = 200.0D0/TOUT = $2/;s#../verify/kynch_#$T/kynch_$3_#" /home/claude/vol3/ch11/code/k11_drv_kynch.f > d_$3.f
  gfortran -O2 $F d_$3.f /home/claude/vol3/ch11/code/k11_settling.f $A/stubs.f -o d_$3 && ./d_$3 | tail -2
done
python3 - <<'PY'
import numpy as np
v0=2.8203357600000007; cm=.67; n=4.65; H=300.
v=lambda c: v0*(1-c/cm)**n
for tag,c0,t,cmid in (('a',0.1,100.,0.5*(0.1+0.3366131924342023)),('b',0.4,1000.,0.535)):
    d=np.loadtxt(f'/tmp/claude-0/kv/kynch_{tag}_0800.dat'); z,c=d[:,0],d[:,1]; dz=H/800
    j=np.where((c[:-1]>=0.5*c0)&(c[1:]<0.5*c0))[0][-1]; zt=z[j]+(c[j]-0.5*c0)/(c[j]-c[j+1])*dz
    j=np.where((c[:-1]>=cmid)&(c[1:]<cmid))[0]; 
    zs=z[j[0]]+(c[j[0]]-cmid)/(c[j[0]]-c[j[0]+1])*dz if len(j) else float('nan')
    print(tag,'z_top',zt,'exact',H-v(c0)*t,'shock/bed crossing',zs)
PY
