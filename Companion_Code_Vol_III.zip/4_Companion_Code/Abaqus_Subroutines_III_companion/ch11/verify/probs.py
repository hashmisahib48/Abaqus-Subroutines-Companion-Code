import numpy as np
from scipy.optimize import brentq
print('--- 11A.1')
R0,AF=50.,6250.; pi,pb,Vo,dt=8.,2.,0.05,2.
dp=pi-pb; RO=R0+AF*Vo; s=np.sqrt(RO**2+4*AF*dp*dt); x=2*dp*dt/(RO+s); C=2/(RO+s); dC=-4*AF*dt/(s*(RO+s)**2)
print('RO',RO,'s',s,'x',x,'Vnew',Vo+x,'C',C,'q',C*dp,'dC/dpint',dC,'1/s',1/s,'C+dC*dp',C+dC*dp)
print('--- 11A.2')
rs,rw,mu,g,d,w=2.65e-9,1.0e-9,2e-8,9810.,0.3,5.
vs=(rs-rw)*g*d**2/(18*mu); re=rw*vs*d/mu; wall=(1-d/w)**2
print('vS',vs,'Re',re,'t for 1000 mm',1000/vs,'wall',wall,'v wall',vs*wall,'v c=0.1',vs*wall*(1-.1/.67)**4.65, 'min gap for ratio 3',3*d)
print('--- 11A.3')
cm,n=0.67,4.65
print('c half (cm form)',cm*(1-0.5**(1/n)),' (1-c)^n form',1-0.5**(1/n))
print('--- 11B.3 c0=0.1')
v0=2.8203357600000007
v=lambda c: v0*(1-c/cm)**n; f=lambda c:c*v(c)
fp=lambda c: v0*(1-c/cm)**(n-1)*(1-c/cm-n*c/cm)
for c0 in (0.1,):
    g_=lambda cs: f(c0)-f(cs)+fp(cs)*(cs-c0)
    xs=np.linspace(c0+1e-4,cm-1e-3,2000); gv=g_(xs); idx=np.where(np.sign(gv[:-1])!=np.sign(gv[1:]))[0]
    print('sign changes',xs[idx])
    cs=brentq(g_,xs[idx[0]],xs[idx[0]+1]); sig=(f(c0)-f(cs))/(cs-c0)
    H=300.
    print('c0',c0,'v(c0)',v(c0),'cs',cs,'sigma',sig,'lam(c0)',-fp(c0),'t*',H/(v(c0)+sig),'-f\'(cs)',-fp(cs))
    t=100.; zs=sig*t; zt=H-v(c0)*t
    cc=np.linspace(cs,cm,200001); z=-fp(cc)*t; o=np.argsort(z); mass=np.trapezoid(cc[o],z[o])+c0*(zt-zs)
    print('mass ratio at t=100',mass/(c0*H),'ztop',zt,'zs',zs)
print('--- 11C.1')
AF0,beta,pref=6250.,0.5,1.
for dp in (5.,):
    A=AF0*(1+dp/pref)**beta
    V=(-R0+np.sqrt(R0**2+2*A*dp*100))/A
    print('AF(dp)',A,'V(100)',V,'CL',np.sqrt(dp/(2*A)))
    # backward Euler check
    N=200000; dt=100/N; Vv=0.
    for k in range(N):
        RO=R0+A*Vv; s=np.sqrt(RO**2+4*A*dp*dt); Vv+=2*dp*dt/(RO+s)
    print('BE',Vv)
print('--- 11C.2 c0=0.4 (no shock: fan only)')
c0=0.4; H=300.; t=1000.
vc=v(c0)
print('v(c0)',vc,"-f'(c0)",-fp(c0),'t*',H/(vc-fp(c0)),'z_top(1000)',H-vc*t,'fan top',-fp(c0)*t,'z(c=0.5)',-fp(0.5)*t,'z(c=0.535)',-fp(0.535)*t)
print('FV (800 cells) crossings: c=0.5 at 59.06, 0.535 at 27.99, z_top 259.15  (kynch_var.sh)')
