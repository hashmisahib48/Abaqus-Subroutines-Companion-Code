import numpy as np
from scipy.optimize import brentq
rho_s,rho_w,d,mu,g=2.65e-9,1.0e-9,0.4,5e-8,9810.0
w=40.0; fw=(1-d/w)**2; n=4.65; cm=0.67
v0=(rho_s-rho_w)*g*d**2/(18*mu)*fw
v=lambda c: v0*(1-c/cm)**n
f=lambda c: c*v(c)
fp=lambda c: v0*(1-c/cm)**(n-1)*(1-c/cm-n*c/cm)
c0=0.2; H=300.; t=200.
# tangency: f(c0)-f(cs) = -f'(cs)(cs-c0)
g_=lambda cs: f(c0)-f(cs)+fp(cs)*(cs-c0)
cs=brentq(g_,0.2001,0.66)
sig=(f(c0)-f(cs))/(cs-c0)
print('v0',v0,'v(c0)',v(c0),'cs',cs,'sigma',sig,'lam(cs)',-fp(cs))
print('ztop',H-v(c0)*t,'zshock',sig*t,'t*',H/(v(c0)+sig))
# mass check of exact profile: bed fan c(z)=: z/t=-fp(c)
zs=sig*t
# integral of fan: sum over c from cs..cm
cc=np.linspace(cs,cm,200001); z=-fp(cc)*t

# z decreasing with c: integrate c dz from z=0.. zs
order=np.argsort(z); m_fan=np.trapezoid(cc[order],z[order])
mass=m_fan+c0*(H-v(c0)*t-zs)
print('mass exact/(c0 H)',mass/(c0*H))
# fan top width
print('fan z range',z.min(),z.max())
np.savez('kynch_exact.npz',cs=cs,sig=sig,v0=v0,vc0=v(c0))
# ---- compare with Godunov profiles from the Fortran driver
import os
res=[]
def exact(z):
    zt=H-v(c0)*t
    out=np.where(z>zt,0.0,c0)
    out=np.where(z<zs,np.nan,out)
    # fan: solve -fp(c)*t=z
    for k,zz in enumerate(z):
        if zz<zs:
            out[k]=brentq(lambda c:-fp(c)*t-zz,cs,cm) if zz>0 else cm
    return out
for N in (100,200,400,800):
    dat=np.loadtxt(f'kynch_{N:04d}.dat'); z=dat[:,0]; c=dat[:,1]; dz=H/N
    # top interface: crossing c0/2 from the top
    j=np.where((c[:-1]>=0.5*c0)&(c[1:]<0.5*c0))[0][-1]
    zt_n=z[j]+(c[j]-0.5*c0)/(c[j]-c[j+1])*dz
    cmid=0.4
    j=np.where((c[:-1]>=cmid)&(c[1:]<cmid))[0][0]
    zs_n=z[j]+(c[j]-cmid)/(c[j]-c[j+1])*dz
    L1=np.sum(np.abs(c-exact(z)))*dz/(c0*H)
    print(f'N={N:4d} z_top={zt_n:9.4f} (exact {H-v(c0)*t:9.4f}) z(c=0.4)={zs_n:9.4f} (exact {-fp(0.4)*t:9.4f}) relL1={L1:.4f}')
