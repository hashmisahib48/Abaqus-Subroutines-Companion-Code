# Independent checks of the chapter-11 drivers (closed forms)
import numpy as np
from scipy.optimize import brentq
print('--- leak-off closed form, constant pressure difference')
R0,AF,T=50.,6250.,100.
for dp in (2,5,8):
    V=(-R0+np.sqrt(R0**2+2*AF*dp*T))/AF; CL=np.sqrt(dp/(2*AF))
    print(f'DP={dp} V(100)={V:.6f}  2 C_L sqrt(T)={2*CL*np.sqrt(T):.6f} C_L={CL:.6f} mm/sqrt(s) ratio={V/(2*CL*np.sqrt(T)):.5f}')
print('V ratio 8 MPa/2 MPa', ((-R0+np.sqrt(R0**2+2*AF*8*T))/(-R0+np.sqrt(R0**2+2*AF*2*T))), 'sqrt(4)=2')
print('--- time at which cake resistance equals clean-wall resistance, V=R0/AF =',R0/AF,'mm; t(DP=5)=',(R0*(R0/AF)+AF*(R0/AF)**2/2)/5,'s')
print('--- Stokes table')
rs,rw,d,mu,g=2.65e-9,1e-9,0.4,5e-8,9810.
vs=(rs-rw)*g*d**2/(18*mu); fw=(1-d/40.)**2
print('v_Stokes',vs,'wall',fw,'v0',vs*fw, 'Re',rw*vs*d/mu)
for c in (0,.1,.2,.3,.4,.5,.6,.67):
    print(f'{c:5.2f} {vs*fw*(1-c/.67)**4.65:.7e}')
print('--- Schiller-Naumann')
for d,mu in ((0.2,1e-9),(0.4,1e-9),(0.4,5e-8)):
    vs=(rs-rw)*g*d**2/(18*mu)
    f=lambda v: v*(1+0.15*(rw*v*d/mu)**0.687)-vs
    vt=brentq(f,1e-9,vs*2); re=rw*vt*d/mu
    print(d,mu,'VS',vs,'VT',vt,'Re',re)
    for c in (0,.1,.3,.5):
        n=4.65 if re<.2 else 4.35*re**-.03 if re<1 else 4.45*re**-.1 if re<500 else 2.39
        print(f'{c:5.2f} {vt*(1-c/.67)**n*(1-d/1e6)**2:.7e}')
