!     Driver 3: finite-difference check of DC_BOT, DC_TOP.
!     Central differences of C_BOT, C_TOP with respect to P_INT, P_BOT
!     and P_TOP at fixed starting STATEV; also the identity
!     d(Q)/d(DP) = C + DC*DP = 1/S for the flux Q = C*DP.
      PROGRAM K11DRV3
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PERM(2), PGRAD(2), ANM(3), TANG(3,2), TIME(2),
     1 PREDEF(1), DPRED(1), DCB(3), DCT(3), STATEV(2), SV(2)
      DIMENSION PI(4), PB(4), VV(4), DTV(4), AA(3), BB(3)
      DATA PI /10.0D0, 5.0D0, 3.0D0, 20.0D0/
      DATA PB /2.0D0, 1.0D0, 2.5D0, 0.0D0/
      DATA VV /0.0D0, 0.05D0, 0.3D0, 0.1D0/
      DATA DTV /1.0D0, 0.1D0, 10.0D0, 1.0D-3/
      HH = 1.0D-5
      EMAX = 0.0D0
      DO 10 K = 1, 4
        SV(1) = VV(K)
        SV(2) = VV(K)
        CALL EVAL(PI(K), PB(K), PB(K), DTV(K), SV, CB0, CT0, DCB, DCT)
        CALL EVAL(PI(K)+HH, PB(K), PB(K), DTV(K), SV, C1, C2, AA, BB)
        CALL EVAL(PI(K)-HH, PB(K), PB(K), DTV(K), SV, C3, C4, AA, BB)
        FDB = (C1-C3)/(2.0D0*HH)
        FDT = (C2-C4)/(2.0D0*HH)
        CALL EVAL(PI(K), PB(K)+HH, PB(K), DTV(K), SV, C1, C2, AA, BB)
        CALL EVAL(PI(K), PB(K)-HH, PB(K), DTV(K), SV, C3, C4, AA, BB)
        FDP = (C1-C3)/(2.0D0*HH)
        E1 = ABS(FDB-DCB(2))/ABS(DCB(2))
        E2 = ABS(FDP-DCB(3))/ABS(DCB(3))
        E3 = ABS(FDT-DCT(2))/ABS(DCT(2))
        EMAX = MAX(EMAX, E1, E2, E3)
        DP = PI(K) - PB(K)
        RO = 50.0D0 + 6250.0D0*VV(K)
        S = SQRT(RO*RO + 4.0D0*6250.0D0*DP*DTV(K))
        WRITE(*,'(I2,3ES13.5,3ES10.2,2ES13.5)') K, DCB(2), FDB,
     1   DCB(3), E1, E2, E3, CB0+DCB(2)*DP, 1.0D0/S
10    CONTINUE
      WRITE(*,'(A,ES10.2)') 'max relative error of DC =', EMAX
      END
      SUBROUTINE EVAL(PI, PB, PT, DT, SV, CB, CT, DCB, DCT)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PERM(2), PGRAD(2), ANM(3), TANG(3,2), TIME(2),
     1 PREDEF(1), DPRED(1), DCB(3), DCT(3), STATEV(2), SV(2)
      STATEV(1) = SV(1)
      STATEV(2) = SV(2)
      CALL UFLUIDLEAKOFF(PERM,PGRAD,0.5D0,PI,PB,PT,ANM,TANG,TIME,DT,
     1 20.0D0,0.0D0,PREDEF,DPRED,CB,CT,DCB,DCT,STATEV,2,1,1,1,1)
      END
