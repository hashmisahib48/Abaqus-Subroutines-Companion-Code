      SUBROUTINE S11_VTERM(VS, RHOW, D, VMU, VT, RE)
!     Terminal velocity with the Schiller-Naumann drag law:
!       VT*(1 + 0.15*RE**0.687) = VS,  RE = RHOW*VT*D/VMU
!     VS Stokes velocity [mm/s]; RHOW [tonne/mm^3]; D [mm];
!     VMU [MPa s].  Newton's method, started from VS.
      INCLUDE 'ABA_PARAM.INC'
      VT = VS
      DO 10 IT = 1, 30
         RE  = RHOW*VT*D/VMU
         FAC = 1.0D0 + 0.15D0*RE**0.687D0
         RES = VT*FAC - VS
         DER = 1.0D0 + 0.15D0*1.687D0*RE**0.687D0
         DV  = RES/DER
         VT  = VT - DV
         IF (ABS(DV) .LT. 1.0D-12*VS) GOTO 20
10    CONTINUE
20    RE = RHOW*VT*D/VMU
      RETURN
      END
!
      FUNCTION S11_RZN(RE)
!     Richardson-Zaki exponent for an unbounded suspension
      INCLUDE 'ABA_PARAM.INC'
      IF (RE .LT. 0.2D0) THEN
         S11_RZN = 4.65D0
      ELSE IF (RE .LT. 1.0D0) THEN
         S11_RZN = 4.35D0*RE**(-0.03D0)
      ELSE IF (RE .LT. 500.0D0) THEN
         S11_RZN = 4.45D0*RE**(-0.1D0)
      ELSE
         S11_RZN = 2.39D0
      ENDIF
      RETURN
      END
!
      SUBROUTINE USETTLING(KSTEP, KINC, NOEL, NPT, COORDS, NDIR,
     1 RHOS, RHOW, DIAMP, RMINGAPOVERDP, DCRACK, CVN, JTYPEFLUID,
     2 CONSK, ALPHA, TAU, EFFMU, CVTAKENASSOLID, GRAV, VM, VSET,
     3 TEMP, FIELD, STATEV, NFIELD, NSTATV, IVSETDIR, I_ARRAY,
     4 NIARRAY, R_ARRAY, NRARRAY, C_ARRAY, NCARRAY)
!     Executable part: terminal velocity from the drag law, then
!     the Richardson-Zaki factor with the exponent for that Re.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION VM(2), VSET(3), GRAV(2), COORDS(*)
      DIMENSION FIELD(NFIELD), STATEV(NSTATV)
      DIMENSION I_ARRAY(*), R_ARRAY(*)
      CHARACTER*80 C_ARRAY(*)
!
      GMAG = SQRT(GRAV(1)**2 + GRAV(2)**2)
      VS   = (RHOS - RHOW)*GMAG*DIAMP**2/(18.0D0*EFFMU)
      CALL S11_VTERM(VS, RHOW, DIAMP, EFFMU, VT, RE)
      CV   = MIN(MAX(CVN, 0.0D0), CVTAKENASSOLID)
      RZN  = S11_RZN(RE)
      WALL = 0.0D0
      IF (DCRACK .GT. DIAMP) WALL = (1.0D0 - DIAMP/DCRACK)**2
      VSET(1) = VT*(1.0D0 - CV/CVTAKENASSOLID)**RZN*WALL
      VSET(2) = 0.0D0
      VSET(3) = 0.0D0
      IVSETDIR = 1
      RETURN
      END
