!     Driver 2: one pore-pressure cohesive element reduced to a cell.
!     Storage S*dp/dt = -(Qb + Qt), Qb = C_BOT*(p - PR), Qt likewise,
!     pressure p solved by Newton's method with the Jacobian of
!     Abaqus: dR/dp = S + DT*(C + DC(2)*(p-PR)) summed over faces.
!     ITYPE = 1: exact Jacobian; 2: C only (DC ignored).
      PROGRAM A11DRV2
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PERM(2), PGRAD(2), ANM(3), TANG(3,2), TIME(2),
     1 PREDEF(1), DPRED(1), DC_BOT(3), DC_TOP(3), STATEV(2), SV0(2)
      PARAMETER (S = 0.05D0, P0 = 10.0D0, PR = 2.0D0)  ! mm/MPa, MPa
      PARAMETER (TEND = 100.0D0)
      DIMENSION NSV(4)
      CHARACTER*40 NAME
      DATA NSV /10, 20, 50, 100/
!     reference: RA4 with 200000 steps
      CALL REF(PREF, VBR, VTR)
      WRITE(*,'(A,3ES14.6)') 'REF p,Vb,Vt(100 s)=',PREF,VBR,VTR
      DO 50 IT = 1, 2
       DO 40 IS = 1, 4
        NS = NSV(IS)
        DT = TEND/NS
        STATEV(1) = 0.0D0
        STATEV(2) = 0.0D0
        P = P0
        NIT = 0
        IF (IT .EQ. 1 .AND. (NS .EQ. 20 .OR. NS .EQ. 100)) THEN
           WRITE(NAME,'(A,I3.3,A)') '../verify/cell_', NS, '.dat'
           OPEN(8, FILE=NAME)
        ENDIF
        DO 30 K = 1, NS
          SV0(1) = STATEV(1)
          SV0(2) = STATEV(2)
          PN = P
          DO 20 ITER = 1, 50
            STATEV(1) = SV0(1)
            STATEV(2) = SV0(2)
            CALL UFLUIDLEAKOFF(PERM,PGRAD,0.5D0,PN,PR,PR,ANM,TANG,
     1       TIME,DT,20.0D0,0.0D0,PREDEF,DPRED,CB,CT,DC_BOT,DC_TOP,
     2       STATEV,2,1,1,1,K)
            RES = S*(PN-P) + DT*(CB+CT)*(PN-PR)
            IF (IT .EQ. 1) THEN
               DJ = S + DT*(CB + CT + (DC_BOT(2)+DC_TOP(2))*(PN-PR))
            ELSE
               DJ = S + DT*(CB + CT)
            ENDIF
            IF (K .EQ. 1 .AND. IS .EQ. 1) WRITE(*,'(A,I2,I3,ES12.3)')
     1       '   hist',IT,ITER,ABS(RES)
            IF (ABS(RES) .LT. 1.0D-10) GOTO 25
            PN = PN - RES/DJ
            NIT = NIT + 1
20        CONTINUE
25        P = PN
          IF (IT .EQ. 1 .AND. (NS .EQ. 20 .OR. NS .EQ. 100))
     1     WRITE(8,'(2ES14.6)') K*DT, P
30      CONTINUE
        IF (IT .EQ. 1 .AND. (NS .EQ. 20 .OR. NS .EQ. 100)) CLOSE(8)
        WRITE(*,'(A,I2,I5,F9.5,2ES13.5,I6,A,F6.2)') 'RUN',IT,NS,DT,P,
     1   (P-PREF)/PREF,NIT,'  iter/step',DBLE(NIT)/NS
40     CONTINUE
50    CONTINUE
      END
!
      SUBROUTINE REF(P, VB, VT)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (S = 0.05D0, P0 = 10.0D0, PR = 2.0D0, TEND = 100.0D0)
      PARAMETER (R0B=50.0D0,AFB=6250.0D0,R0T=50.0D0,AFT=9375.0D0)
      PARAMETER (N = 200000)
      DIMENSION Y(3), A1(3), A2(3), A3(3), A4(3), W(3)
      Y(1) = P0
      Y(2) = 0.0D0
      Y(3) = 0.0D0
      H = TEND/N
      OPEN(9, FILE='../verify/cell_ref.dat')
      WRITE(9,'(2ES14.6)') 0.0D0, Y(1)
      DO 10 J = 1, N
        CALL F(Y, A1)
        W = Y + 0.5D0*H*A1
        CALL F(W, A2)
        W = Y + 0.5D0*H*A2
        CALL F(W, A3)
        W = Y + H*A3
        CALL F(W, A4)
        Y = Y + H*(A1 + 2.0D0*A2 + 2.0D0*A3 + A4)/6.0D0
        IF (MOD(J, 2000) .EQ. 0) WRITE(9,'(2ES14.6)') J*H, Y(1)
10    CONTINUE
      CLOSE(9)
      P = Y(1)
      VB = Y(2)
      VT = Y(3)
      END
      SUBROUTINE F(Y, D)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (S = 0.05D0, PR = 2.0D0)
      PARAMETER (R0B=50.0D0,AFB=6250.0D0,R0T=50.0D0,AFT=9375.0D0)
      DIMENSION Y(3), D(3)
      QB = (Y(1)-PR)/(R0B + AFB*Y(2))
      QT = (Y(1)-PR)/(R0T + AFT*Y(3))
      D(1) = -(QB + QT)/S
      D(2) = QB
      D(3) = QT
      END
