#!/bin/sh
# compile all listings and run the drivers (gfortran, stubs in lib/aba)
A=/home/claude/vol3/lib/aba
F="-ffixed-form -std=legacy -I$A"
cd "$(dirname "$0")"
T=/tmp/claude-0; mkdir -p $T
gfortran -c $F k11_leakoff.f -o $T/k11a.o || exit 1
gfortran -c $F k11_settling.f -o $T/k11b.o || exit 1
gfortran -c $F k11_settling_re.f -o $T/k11c.o || exit 1
gfortran $F k11_drv_carter.f k11_leakoff.f $A/stubs.f -o $T/d1 && $T/d1 > ../verify/out_carter.txt
gfortran $F k11_drv_cell.f k11_leakoff.f $A/stubs.f -o $T/d2 && $T/d2 > ../verify/out_cell.txt
gfortran $F k11_drv_fd.f k11_leakoff.f $A/stubs.f -o $T/d3 && $T/d3 > ../verify/out_fd.txt
gfortran $F k11_drv_settle.f k11_settling.f $A/stubs.f -o $T/d4 && $T/d4 > ../verify/out_settle.txt
gfortran -O2 $F k11_drv_kynch.f k11_settling.f $A/stubs.f -o $T/d5 && $T/d5 > ../verify/out_kynch.txt
gfortran $F k11_drv_re.f k11_settling_re.f $A/stubs.f -o $T/d6 && $T/d6 > ../verify/out_re.txt
cd ../verify && python3 kynch_exact.py > out_kynch_exact.txt && python3 check11.py > out_check.txt && cat out_check.txt
