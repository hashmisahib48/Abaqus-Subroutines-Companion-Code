!     Driver 6: USETTLING with drag law; water-like fluid, d = 0.2 mm
      PROGRAM K11DRV6
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION COORDS(3), VM(2), VSET(3), GRAV(2), FIELD(1),
     1 STATEV(1), IA(1), RA(1)
      CHARACTER*80 CA(1)
      DIMENSION CVL(4), DD(3), VMUL(3)
      DATA CVL /0.0D0, 0.1D0, 0.3D0, 0.5D0/
      DATA DD /0.2D0, 0.4D0, 0.4D0/
      DATA VMUL /1.0D-9, 1.0D-9, 5.0D-8/
      GRAV(1) = 9810.0D0
      GRAV(2) = 0.0D0
      DO 20 ID = 1, 3
        VS = 1.65D-9*9810.0D0*DD(ID)**2/(18.0D0*VMUL(ID))
        CALL S11_VTERM(VS, 1.0D-9, DD(ID), VMUL(ID), VT, RE)
        WRITE(*,'(A,F4.1,ES9.1,3ES14.6,F8.4)') 'd,mu,VS,VT,Re,n',
     1   DD(ID), VMUL(ID), VS, VT, RE, S11_RZN(RE)
        DO 10 K = 1, 4
          CALL USETTLING(1,1,1,1,COORDS,2,2.65D-9,1.0D-9,DD(ID),1.0D0,
     1     1.0D6,CVL(K),1,0.0D0,0.0D0,0.0D0,VMUL(ID),0.67D0,GRAV,VM,
     2     VSET,20.0D0,FIELD,STATEV,1,1,IVS,IA,1,RA,1,CA,1)
          WRITE(*,'(F6.2,ES15.7)') CVL(K), VSET(1)
10      CONTINUE
20    CONTINUE
      END
