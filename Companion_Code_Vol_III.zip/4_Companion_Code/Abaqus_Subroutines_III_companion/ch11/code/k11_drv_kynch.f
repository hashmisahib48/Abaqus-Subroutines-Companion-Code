!     Driver 5: batch settling (Kynch) in a closed column, 0 < z < H.
!     Particle flux downward  F(c) = c*VSET(1;c)  is obtained from
!     USETTLING.  Godunov scheme for  c_t - F(c)_z = 0, zero flux at
!     both ends.  Profiles at TOUT go to ../verify and are compared
!     with the exact solution (kynch_exact.py).
      PROGRAM K11DRV5
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NT = 400, H = 300.0D0, C0 = 0.2D0, CM = 0.67D0)
      PARAMETER (TOUT = 200.0D0)
      DIMENSION COORDS(3), VM(2), VSET(3), GRAV(2), FIELD(1),
     1 STATEV(1), IA(1), RA(1)
      DIMENSION FT(0:NT), C(2000), FL(0:2000)
      CHARACTER*80 CA(1)
      CHARACTER*40 NAME
      DIMENSION NCL(4)
      DATA NCL /100, 200, 400, 800/
      GRAV(1) = 9810.0D0
      GRAV(2) = 0.0D0
      DO 5 K = 0, NT
        CC = CM*DBLE(K)/NT
        CALL USETTLING(1,1,1,1,COORDS,2,2.65D-9,1.0D-9,0.4D0,1.0D0,
     1   40.0D0,CC,1,0.0D0,0.0D0,0.0D0,5.0D-8,CM,GRAV,VM,VSET,20.0D0,
     2   FIELD,STATEV,1,1,IVS,IA,1,RA,1,CA,1)
        FT(K) = CC*VSET(1)
5     CONTINUE
      CALL USETTLING(1,1,1,1,COORDS,2,2.65D-9,1.0D-9,0.4D0,1.0D0,
     1 40.0D0,C0,1,0.0D0,0.0D0,0.0D0,5.0D-8,CM,GRAV,VM,VSET,20.0D0,
     2 FIELD,STATEV,1,1,IVS,IA,1,RA,1,CA,1)
      V0 = VSET(1)
      WRITE(*,'(A,ES14.6)') 'v(c0) =', V0
      VMAX = 0.0D0
      DO 6 K = 1, NT
        VMAX = MAX(VMAX, ABS(FT(K)-FT(K-1))/(CM/NT))
6     CONTINUE
      DO 100 IR = 1, 4
        N = NCL(IR)
        DZ = H/N
        DT0 = 0.4D0*DZ/VMAX
        DO 10 J = 1, N
          C(J) = C0
10      CONTINUE
        T = 0.0D0
15      IF (T .GE. TOUT - 1.0D-9) GOTO 50
        DT = MIN(DT0, TOUT - T)
        FL(0) = 0.0D0
        FL(N) = 0.0D0
        DO 20 J = 1, N-1
          FL(J) = GOD(C(J), C(J+1), FT, NT, CM)
20      CONTINUE
        DO 30 J = 1, N
          C(J) = C(J) - DT/DZ*(FL(J) - FL(J-1))
30      CONTINUE
        T = T + DT
        GOTO 15
50      CONTINUE
        XM = 0.0D0
        DO 80 J = 1, N
          XM = XM + C(J)*DZ
80      CONTINUE
        WRITE(*,'(A,I5,A,ES10.2)') 'N=',N,'  mass error',XM/(C0*H)-1.0D0
        WRITE(NAME,'(A,I4.4,A)') '../verify/kynch_', N, '.dat'
        OPEN(7, FILE=NAME)
        DO 90 J = 1, N
          WRITE(7,'(2ES14.6)') (J-0.5D0)*DZ, C(J)
90      CONTINUE
        CLOSE(7)
100   CONTINUE
      END
!
      FUNCTION GOD(CL, CR, FT, NT, CM)
!     Godunov flux (upward, G = -F) between left (lower) and right
!     (upper) states, by scanning the tabulated F.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FT(0:NT)
      I1 = NINT(MIN(CL,CR)/CM*NT)
      I2 = NINT(MAX(CL,CR)/CM*NT)
      G = -FT(I1)
      IF (CL .LE. CR) THEN
        DO 10 I = I1, I2
          G = MIN(G, -FT(I))
10      CONTINUE
      ELSE
        DO 20 I = I1, I2
          G = MAX(G, -FT(I))
20      CONTINUE
      ENDIF
      GOD = G
      END
