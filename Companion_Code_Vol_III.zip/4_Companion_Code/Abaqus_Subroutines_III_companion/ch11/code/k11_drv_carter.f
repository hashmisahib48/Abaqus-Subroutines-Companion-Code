!     Driver 1: constant pressure difference, fixed increments.
!     Compares the leaked volume of UFLUIDLEAKOFF (bottom face) with
!     the closed form V = (-R0 + SQRT(R0**2 + 2*AF*DP*T))/AF.
      PROGRAM K11DRV1
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PERM(2), PGRAD(2), ANM(3), TANG(3,2), TIME(2),
     1 PREDEF(1), DPRED(1), DC_BOT(3), DC_TOP(3), STATEV(2)
      PARAMETER (R0 = 50.0D0, AF = 6250.0D0, TEND = 100.0D0)
      DIMENSION DPV(3), NSV(4), VT(3)
      DATA DPV /2.0D0, 5.0D0, 8.0D0/
      DATA NSV /10, 100, 1000, 10000/
      DO 30 ID = 1, 3
        DP = DPV(ID)
        VEX = (-R0 + SQRT(R0*R0 + 2.0D0*AF*DP*TEND))/AF
        CL  = SQRT(DP/(2.0D0*AF))
        WRITE(*,'(A,F5.1,A,ES14.6,A,ES12.5)') 'DP=',DP,
     1   '  V_exact(100 s)=',VEX,'  C_L=',CL
        DO 20 IS = 1, 4
          NS = NSV(IS)
          DT = TEND/NS
          STATEV(1) = 0.0D0
          STATEV(2) = 0.0D0
          DO 10 K = 1, NS
            CALL UFLUIDLEAKOFF(PERM,PGRAD,0.5D0,DP+1.0D0,1.0D0,
     1       1.0D0+DP,ANM,TANG,TIME,DT,20.0D0,
     2       0.0D0,PREDEF,DPRED,CB,CT,DC_BOT,DC_TOP,STATEV,2,1,1,1,K)
10        CONTINUE
          WRITE(*,'(A,I6,A,ES14.6,A,ES10.2)') '   steps',NS,
     1     '  V=',STATEV(1),'  rel.err=',(STATEV(1)-VEX)/VEX
20      CONTINUE
30    CONTINUE
!     trajectories V(t) for the three pressure differences, DT = 1 s
      OPEN(7, FILE='../verify/carter_traj.dat')
      DO 50 ID = 1, 3
        STATEV(1) = 0.0D0
        STATEV(2) = 0.0D0
        VT(ID) = 0.0D0
50    CONTINUE
      DO 70 K = 1, 100
        DO 60 ID = 1, 3
          DP = DPV(ID)
          STATEV(1) = VT(ID)
          CALL UFLUIDLEAKOFF(PERM,PGRAD,0.5D0,1.0D0+DP,1.0D0,
     1     1.0D0+DP,ANM,TANG,TIME,1.0D0,20.0D0,0.0D0,PREDEF,DPRED,CB,
     2     CT,DC_BOT,DC_TOP,STATEV,2,1,1,1,K)
          VT(ID) = STATEV(1)
60      CONTINUE
        WRITE(7,'(F8.2,3ES14.6)') DBLE(K), VT
70    CONTINUE
      CLOSE(7)
      END
