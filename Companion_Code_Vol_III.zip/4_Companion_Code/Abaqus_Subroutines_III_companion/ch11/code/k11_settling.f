      SUBROUTINE USETTLING(KSTEP, KINC, NOEL, NPT, COORDS, NDIR,
     1 RHOS, RHOW, DIAMP, RMINGAPOVERDP, DCRACK, CVN, JTYPEFLUID,
     2 CONSK, ALPHA, TAU, EFFMU, CVTAKENASSOLID, GRAV, VM, VSET,
     3 TEMP, FIELD, STATEV, NFIELD, NSTATV, IVSETDIR, I_ARRAY,
     4 NIARRAY, R_ARRAY, NRARRAY, C_ARRAY, NCARRAY)
!     Hindered settling: Stokes velocity x Richardson-Zaki factor
!     x an assumed wall factor.  Units: N, mm, MPa, tonne, s.
!       RHOS, RHOW  densities               [tonne/mm^3]
!       DIAMP, DCRACK  particle diameter, gap opening     [mm]
!       EFFMU  apparent viscosity                         [MPa s]
!       GRAV   gravity in the fracture plane              [mm/s^2]
!       VSET(1)  settling speed (IVSETDIR = 1)            [mm/s]
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION VM(2), VSET(3), GRAV(2), COORDS(*)
      DIMENSION FIELD(NFIELD), STATEV(NSTATV)
      DIMENSION I_ARRAY(*), R_ARRAY(*)
      CHARACTER*80 C_ARRAY(*)
      PARAMETER (RZN = 4.65D0)         ! Richardson-Zaki n, Re<0.2
!
      GMAG = SQRT(GRAV(1)**2 + GRAV(2)**2)
      VSTOKES = (RHOS - RHOW)*GMAG*DIAMP**2/(18.0D0*EFFMU)
      CV = MIN(MAX(CVN, 0.0D0), CVTAKENASSOLID)
      HIND = (1.0D0 - CV/CVTAKENASSOLID)**RZN
      WALL = 0.0D0
      IF (DCRACK .GT. DIAMP) WALL = (1.0D0 - DIAMP/DCRACK)**2
      VSET(1) = VSTOKES*HIND*WALL
      VSET(2) = 0.0D0
      VSET(3) = 0.0D0
      IVSETDIR = 1
      RETURN
      END
