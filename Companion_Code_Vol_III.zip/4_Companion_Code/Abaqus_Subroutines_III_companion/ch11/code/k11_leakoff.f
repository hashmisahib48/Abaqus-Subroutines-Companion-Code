      SUBROUTINE K11_CAKE(DP, DT, VOLD, R0, AF, VNEW, C, DCDP)
!     Fouling leak-off: flux Q = DP/(R0 + AF*V), V = leaked volume
!     per unit area, advanced by backward Euler (Eq. 11.4-1).
!     DP = p_int - p_side [MPa]; DT [s]; VOLD, VNEW: V at start and
!     end of the increment [mm]; R0 [MPa s/mm]; AF [MPa s/mm^2]
!     C = Q/DP [mm/(s MPa)]; DCDP = dC/dDP at fixed VOLD
      INCLUDE 'ABA_PARAM.INC'
      RO = R0 + AF*VOLD
      IF (DP .LE. 1.0D-12 .OR. DT .LE. 0.0D0) THEN
         VNEW = VOLD
         C    = 1.0D0/RO
         DCDP = 0.0D0
      ELSE
         S    = SQRT(RO*RO + 4.0D0*AF*DP*DT)
         VNEW = VOLD + 2.0D0*DP*DT/(RO + S)
         C    = 2.0D0/(RO + S)
         DCDP = -4.0D0*AF*DT/(S*(RO + S)**2)
      ENDIF
      RETURN
      END
!
      SUBROUTINE UFLUIDLEAKOFF(PERM, PGRAD, DN, P_INT, P_BOT, P_TOP,
     1 ANM, TANG, TIME, DTIME, TEMP, DTEMP, PREDEF, DPRED, C_BOT,
     2 C_TOP, DC_BOT, DC_TOP, STATEV, NSTATV, NOEL, NPT, KSTEP, KINC)
!     Leak-off with fouling on both faces; STATEV(1), STATEV(2):
!     leaked volume per area, bottom and top [mm]; N, mm, MPa, s.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PERM(2), PGRAD(2), ANM(3), TANG(3,2), TIME(2),
     1 PREDEF(1), DPRED(1), DC_BOT(3), DC_TOP(3), STATEV(NSTATV)
!     R0 [MPa s/mm], AF [MPa s/mm^2]; bottom (B) and top (T) faces
      PARAMETER (R0B = 50.0D0, AFB = 6250.0D0)
      PARAMETER (R0T = 50.0D0, AFT = 9375.0D0)
!
      CALL K11_CAKE(P_INT-P_BOT, DTIME, STATEV(1), R0B, AFB,
     1              VB, C_BOT, DB)
      CALL K11_CAKE(P_INT-P_TOP, DTIME, STATEV(2), R0T, AFT,
     1              VT, C_TOP, DTP)
      STATEV(1) = VB
      STATEV(2) = VT
      DC_BOT(1) = 0.0D0          ! d C / d DN
      DC_BOT(2) = DB             ! d C / d P_INT
      DC_BOT(3) = -DB            ! d C / d P_BOT
      DC_TOP(1) = 0.0D0
      DC_TOP(2) = DTP
      DC_TOP(3) = -DTP
      RETURN
      END
