!     Driver: conducting slab with internal heat generation by HETVAL.
!     Half slab 0 <= x <= A, symmetry at x = 0, T = TA at x = A.
!     2-node elements, 2 Gauss points, backward Euler, Newton with
!     FLUX(2) in the tangent (JMODE = 1) or without it (JMODE = 0).
!     Materials: RHOC (mJ/mm^3/K), COND (mW/mm/K)  [Material R]
!     usage:  k4_slab MODE A TA N DT0 DTMAX TEND JMODE
!       MODE 1: transient, trace in slab_trace.txt
!       MODE 2: critical half-thickness by bisection (pseudo-transient)
      MODULE K4M
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NMAX = 800, RHOC = 2.16D0, COND = 0.25D0)
      DIMENSION TOLDN(NMAX+1), TN(NMAX+1), SVO(2,NMAX), SVN(2,NMAX)
      REAL*8 QW, GENT
      INTEGER NIT, NINC, NCUT
      END MODULE K4M
!
      SUBROUTINE K4_STEP(A, N, DT, JMODE, OK, TIME0, ENB)
      USE K4M
      IMPLICIT REAL*8 (A-H,O-Z)
      LOGICAL OK
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),TIME(2),SV(1),FLUX(2),PREDEF(1),DPRED(1)
      DIMENSION RES(NMAX+1), DG(NMAX+1), UG(NMAX+1), BG(NMAX+1)
      DIMENSION GP(2)
      CMNAME = 'REACTIVE'
      TIME(1) = TIME0
      TIME(2) = TIME0
      H = A/N
      GP(1) = -1.0D0/SQRT(3.0D0)
      GP(2) =  1.0D0/SQRT(3.0D0)
      OK = .FALSE.
      DO IT = 1, 16
         NIT = NIT + 1
         RES(1:N+1) = 0.0D0
         DG(1:N+1) = 0.0D0
         UG(1:N+1) = 0.0D0
         GEN = 0.0D0
         STO = 0.0D0
         DO IE = 1, N
            DO IG = 1, 2
               XI = GP(IG)
               S1 = 0.5D0*(1.0D0 - XI)
               S2 = 0.5D0*(1.0D0 + XI)
               W  = 0.5D0*H
               TG  = S1*TN(IE) + S2*TN(IE+1)
               TGO = S1*TOLDN(IE) + S2*TOLDN(IE+1)
               TEMP(1) = TG
               TEMP(2) = TG - TGO
               SV(1) = SVO(IG,IE)
               CALL HETVAL(CMNAME,TEMP,TIME,DT,SV,FLUX,PREDEF,DPRED)
               F1 = FLUX(1)
               F2 = FLUX(2)
               IF (JMODE .EQ. 0) F2 = 0.0D0
               SVN(IG,IE) = SV(1)
               GEN = GEN + W*F1
               STO = STO + W*RHOC*(TG-TGO)/DT
               DTX = (TN(IE+1) - TN(IE))/H
               CAP = RHOC/DT - F2
               DO IA = 0, 1
                  SA  = S1 + IA*(S2 - S1)
                  DNA = (2*IA - 1)/H
                  RES(IE+IA) = RES(IE+IA) + W*(RHOC*(TG-TGO)/DT*SA
     1                         + COND*DTX*DNA - F1*SA)
                  DG(IE+IA)  = DG(IE+IA) + W*(CAP*SA*SA + COND*DNA*DNA)
               ENDDO
               UG(IE) = UG(IE) + W*(CAP*S1*S2 - COND/(H*H))
            ENDDO
         ENDDO
!        reaction at the wall node and heat balance of the increment
         ENB = ABS(-RES(N+1) - (GEN - STO))
         QW = -RES(N+1)
         GENT = GEN
!        solve the tridiagonal system for nodes 1..N (symmetric)
         BG(1:N) = -RES(1:N)
         DO K = 2, N
            FAC = UG(K-1)/DG(K-1)
            DG(K) = DG(K) - FAC*UG(K-1)
            BG(K) = BG(K) - FAC*BG(K-1)
         ENDDO
         BG(N) = BG(N)/DG(N)
         DO K = N-1, 1, -1
            BG(K) = (BG(K) - UG(K)*BG(K+1))/DG(K)
         ENDDO
         DMAX = 0.0D0
         DO K = 1, N
            TN(K) = TN(K) + BG(K)
            DMAX = MAX(DMAX, ABS(BG(K)))
         ENDDO
         IF (.NOT. (TN(1) - TOLDN(N+1) .LT. 400.0D0)) RETURN
         IF (DMAX .LT. 1.0D-8) THEN
            OK = .TRUE.
            RETURN
         ENDIF
      ENDDO
      RETURN
      END
!
!     one run; ITYPE 1: transient to TEND; ITYPE 2: pseudo-transient
!     steady-state attempt, ISTAT = 1 steady, 0 runaway
      SUBROUTINE K4_RUN(A, TA, N, DT0, DTMAX, GROW, TEND, JMODE, ITYPE,
     1                  ISTAT, ENBMAX)
      USE K4M
      IMPLICIT REAL*8 (A-H,O-Z)
      LOGICAL OK
      TN(1:N+1) = TA
      TOLDN(1:N+1) = TA
      SVO(:,1:N) = 0.0D0
      NIT = 0; NINC = 0; NCUT = 0
      T = 0.0D0
      DTC = DT0
      ENBMAX = 0.0D0
      ISTAT = -1
      IF (ITYPE .EQ. 1) OPEN(11,FILE='slab_trace.txt')
      DO WHILE (T .LT. TEND .AND. ISTAT .LT. 0)
         DT = MIN(DTC, TEND - T)
         TOLDN(1:N+1) = TN(1:N+1)
         CALL K4_STEP(A, N, DT, JMODE, OK, T+DT, ENB)
         IF (.NOT. OK) THEN
            NCUT = NCUT + 1
            IF (ITYPE .EQ. 2 .AND. .NOT. (TN(1) - TA .LT. 60.0D0))
     1         ISTAT = 0
            TN(1:N+1) = TOLDN(1:N+1)
            DTC = 0.25D0*DT
            IF (DTC .LT. 1.0D-3) ISTAT = 0
         ELSE
            NINC = NINC + 1
            ENBMAX = MAX(ENBMAX, ENB)
            T = T + DT
            SVO(:,1:N) = SVN(:,1:N)
            DTC = MIN(DTMAX, GROW*DT)
            IF (ITYPE .EQ. 1) WRITE(11,'(4ES16.8)') T, TN(1), SVN(1,1),
     1         TN(N/2+1)
            IF (ITYPE .EQ. 2) THEN
               DMX = MAXVAL(ABS(TN(1:N+1) - TOLDN(1:N+1)))
               IF (TN(1) - TA .GT. 60.0D0) ISTAT = 0
               IF (DMX/DT .LT. 1.0D-10) ISTAT = 1
            ENDIF
         ENDIF
      ENDDO
      IF (ITYPE .EQ. 1) CLOSE(11)
      IF (ISTAT .LT. 0) ISTAT = 1
      RETURN
      END
!
      PROGRAM K4SLAB
      USE K4M
      IMPLICIT REAL*8 (A-H,O-Z)
      CHARACTER*32 ARG
      CALL GETARG(1,ARG); READ(ARG,*) MODE
      CALL GETARG(2,ARG); READ(ARG,*) A
      CALL GETARG(3,ARG); READ(ARG,*) TA
      CALL GETARG(4,ARG); READ(ARG,*) N
      CALL GETARG(5,ARG); READ(ARG,*) DT0
      CALL GETARG(6,ARG); READ(ARG,*) DTMAX
      CALL GETARG(7,ARG); READ(ARG,*) TEND
      CALL GETARG(8,ARG); READ(ARG,*) JMODE
      IF (MODE .EQ. 1) THEN
         CALL K4_RUN(A,TA,N,DT0,DTMAX,1.5D0,TEND,JMODE,1,ISTAT,ENB)
         WRITE(*,'(A,I7,A,I7,A,I5,A,ES9.2,A,F9.3)') 'inc', NINC,
     1     '  iter', NIT, '  cutbacks', NCUT, '  maxbal', ENB,
     2     '  Tcentre(end)', TN(1)
         WRITE(*,'(A,2ES15.7)') 'wall flux, generation', QW, GENT
      ELSE IF (MODE .EQ. 3) THEN
         CALL K4_RUN(A,TA,N,DT0,DTMAX,1.3D0,TEND,JMODE,2,ISTAT,ENB)
         WRITE(*,'(A,I3,A,I7,A,I6,A,F9.3)') 'istat', ISTAT, ' inc',
     1     NINC, ' cut', NCUT, ' Tc', TN(1)
      ELSE
         ALO = 2.0D0
         AHI = 2000.0D0
         DO K = 1, 40
            AM = 0.5D0*(ALO + AHI)
            CALL K4_RUN(AM,TA,N,DT0,DTMAX,1.3D0,TEND,JMODE,2,ISTAT,
     1                  ENB)
            IF (ISTAT .EQ. 1) THEN
               ALO = AM
            ELSE
               AHI = AM
            ENDIF
         ENDDO
         WRITE(*,'(A,F10.5,A,I4)') 'a_cr =', 0.5D0*(ALO+AHI),
     1     '  N =', N
      ENDIF
      END
