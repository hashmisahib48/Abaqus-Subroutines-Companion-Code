!     Driver: adiabatic block heated by a prescribed current density
!     (Listing 4.8), backward Euler.  usage: k4_joule DT TEND JMODE
      PROGRAM K4JOULE
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      CHARACTER*32 ARG
      DIMENSION TEMP(2),TIME(2),STATEV(1),FLUX(2),PREDEF(1),DPRED(1)
      PARAMETER (RHOC = 3.611D0)
      CALL GETARG(1,ARG); READ(ARG,*) DT
      CALL GETARG(2,ARG); READ(ARG,*) TEND
      CALL GETARG(3,ARG); READ(ARG,*) JMODE
      CMNAME = 'WIRE'
      PREDEF(1) = 5.0D0
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      TOLD = 20.0D0
      NSTEP = NINT(TEND/DT)
      NIT = 0
      DO N = 1, NSTEP
         TNEW = TOLD
         DO IT = 1, 50
            TEMP(1) = TNEW
            TEMP(2) = TNEW - TOLD
            CALL HETVAL(CMNAME,TEMP,TIME,DT,STATEV,FLUX,PREDEF,DPRED)
            RES = RHOC*(TNEW - TOLD)/DT - FLUX(1)
            DF = FLUX(2)
            IF (JMODE .EQ. 0) DF = 0.0D0
            D = -RES/(RHOC/DT - DF)
            TNEW = TNEW + D
            IF (ABS(D) .LT. 1.0D-9) GOTO 10
         ENDDO
 10      NIT = NIT + IT
         TOLD = TNEW
      ENDDO
      RLAM = 0.17D0*25.0D0*4.0D-3/RHOC
      TEX = 20.0D0 - 250.0D0 + 250.0D0*EXP(RLAM*TEND)
      WRITE(*,'(F8.3,I6,I7,F10.3,F10.3,F9.3)') DT, NSTEP, NIT, TOLD,
     1   TEX, TOLD-TEX
      END
