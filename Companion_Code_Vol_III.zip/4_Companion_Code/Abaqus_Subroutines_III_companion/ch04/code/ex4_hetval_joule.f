      SUBROUTINE HETVAL(CMNAME,TEMP,TIME,DTIME,STATEV,FLUX,
     1 PREDEF,DPRED)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),STATEV(*),PREDEF(*),TIME(2),FLUX(2),
     1 DPRED(*)
!
!     Joule heating of a prescribed current density, Eq. (4.9-1)
!     PREDEF(1) = current density J in A/mm^2 (field variable 1)
      PARAMETER (RHO0  = 0.17D0,    ! resistivity at TREF, mOhm*mm
     1           ALPHT = 4.0D-3,    ! temperature coefficient, 1/K
     2           TREF  = 20.0D0)    ! reference temperature, degC
!
      RJ      = RHO0*(1.0D0 + ALPHT*(TEMP(1) - TREF))
      FLUX(1) = RJ*PREDEF(1)**2         ! mW/mm^3
      FLUX(2) = RHO0*ALPHT*PREDEF(1)**2
      RETURN
      END
