!     Driver: finite-difference test of FLUX(2) of the midpoint variant
!     (prob_4c1_mid.f); TEMP(2) = TEMP(1) - TN changes with TEMP(1)
      PROGRAM K4FDMID
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),TIME(2),STATEV(1),FLUX(2),PREDEF(1),DPRED(1)
      DIMENSION FP(2), FM(2), F0(2)
      CMNAME = 'REACTIVE'
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      TN = 130.0D0
      A0 = 0.3D0
      DT = 40.0D0
      T1 = 140.0D0
      H = 1.0D-3
      TEMP(1) = T1
      TEMP(2) = T1 - TN
      STATEV(1) = A0
      CALL HETVAL(CMNAME,TEMP,TIME,DT,STATEV,F0,PREDEF,DPRED)
      TEMP(1) = T1 + H
      TEMP(2) = T1 + H - TN
      STATEV(1) = A0
      CALL HETVAL(CMNAME,TEMP,TIME,DT,STATEV,FP,PREDEF,DPRED)
      TEMP(1) = T1 - H
      TEMP(2) = T1 - H - TN
      STATEV(1) = A0
      CALL HETVAL(CMNAME,TEMP,TIME,DT,STATEV,FM,PREDEF,DPRED)
      FD = (FP(1) - FM(1))/(2.0D0*H)
      WRITE(*,'(A,ES14.6)') 'FLUX(1)  ', F0(1)
      WRITE(*,'(A,ES14.6)') 'FLUX(2)  ', F0(2)
      WRITE(*,'(A,ES14.6)') 'central  ', FD
      END
