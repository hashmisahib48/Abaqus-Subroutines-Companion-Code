!     Driver: adiabatic block with HETVAL (Listing 4.1), backward Euler
!     arguments: T0(degC) DTNOM(s) TEND(s) JMODE
!     JMODE = 1 FLUX(2), 2 frozen alpha, 0 no derivative
!     Heat balance of the increment: RHOC*(T1-T0)/DT = FLUX(1).
!     Failed increments are cut back by 1/4 (as Abaqus does) and the
!     increment then grows by 1.5 after each success, up to DTNOM.
      SUBROUTINE K4_STEP(TOLD, ALD, DT, JMODE, TNEW, ALN, NIT, OK)
      INCLUDE 'ABA_PARAM.INC'
      LOGICAL OK
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),TIME(2),SV(1),FLUX(2),PREDEF(1),DPRED(1)
      PARAMETER (RHOC = 2.16D0, RHOQ = 432.0D0, TZERO = 273.15D0)
      CMNAME = 'REACTIVE'
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      TNEW = TOLD
      OK = .FALSE.
      DO NIT = 1, 16
         TEMP(1) = TNEW
         TEMP(2) = TNEW - TOLD
         SV(1) = ALD
         CALL HETVAL(CMNAME,TEMP,TIME,DT,SV,FLUX,PREDEF,DPRED)
         RES = RHOC*(TNEW - TOLD)/DT - FLUX(1)
         TK = TNEW + TZERO
         DF = FLUX(2)
         IF (JMODE .EQ. 2) DF = RHOQ*(1.0D0-ALD)*
     1      5.0D9*EXP(-12000.0D0/TK)*12000.0D0/TK**2
         IF (JMODE .EQ. 0) DF = 0.0D0
         DTN = -RES/(RHOC/DT - DF)
         TNEW = TNEW + DTN
         IF (TNEW .GT. TOLD + 200.0D0 .OR. TNEW .LT. TOLD) RETURN
         IF (ABS(DTN) .LT. 1.0D-9) THEN
            OK = .TRUE.
            TEMP(1) = TNEW
            TEMP(2) = TNEW - TOLD
            SV(1) = ALD
            CALL HETVAL(CMNAME,TEMP,TIME,DT,SV,FLUX,PREDEF,DPRED)
            ALN = SV(1)
            RETURN
         ENDIF
      ENDDO
      NIT = 16
      RETURN
      END
!
      PROGRAM K4ADIAB
      IMPLICIT REAL*8 (A-H,O-Z)
      LOGICAL OK
      CHARACTER*32 ARG
      PARAMETER (RHOC = 2.16D0, RHOQ = 432.0D0)
      CALL GETARG(1,ARG); READ(ARG,*) T0
      CALL GETARG(2,ARG); READ(ARG,*) DTNOM
      CALL GETARG(3,ARG); READ(ARG,*) TEND
      CALL GETARG(4,ARG); READ(ARG,*) JMODE
      TCROSS = 150.0D0
      T = 0.0D0
      TOLD = T0
      ALD = 0.0D0
      DTC = DTNOM
      NINC = 0
      NIT = 0
      NCUT = 0
      TCR = -1.0D0
      EBAL = 0.0D0
      OPEN(10,FILE='adiab_trace.txt')
      DO WHILE (T .LT. TEND - 1.0D-6)
         DT = MIN(DTC, TEND - T)
         CALL K4_STEP(TOLD, ALD, DT, JMODE, TNEW, ALN, NI, OK)
         NIT = NIT + NI
         IF (.NOT. OK) THEN
            NCUT = NCUT + 1
            DTC = 0.25D0*DT
            IF (DTC .LT. 1.0D-3) STOP 'no convergence'
         ELSE
            NINC = NINC + 1
            EBAL = MAX(EBAL, ABS(RHOC*(TNEW-T0) - RHOQ*ALN))
            IF (TCR .LT. 0.0D0 .AND. TNEW .GE. TCROSS)
     1         TCR = T + DT*(TCROSS-TOLD)/(TNEW-TOLD)
            T = T + DT
            WRITE(10,'(2ES16.8,F12.8)') T, TNEW, ALN
            TOLD = TNEW
            ALD = ALN
            DTC = MIN(DTNOM, 1.5D0*DT)
         ENDIF
      ENDDO
      CLOSE(10)
      WRITE(*,'(F7.1,F8.2,I6,I6,I8,F13.3,ES10.2,F10.4)') T0, DTNOM,
     1   JMODE, NINC, NIT, TCR, EBAL, TOLD
      WRITE(*,'(A,I5)') '   cutbacks:', NCUT
      END
