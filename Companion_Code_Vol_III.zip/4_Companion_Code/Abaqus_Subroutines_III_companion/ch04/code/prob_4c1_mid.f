      SUBROUTINE HETVAL(CMNAME,TEMP,TIME,DTIME,STATEV,FLUX,
     1 PREDEF,DPRED)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),STATEV(*),PREDEF(*),TIME(2),FLUX(2),
     1 DPRED(*)
!
!     Midpoint variant of Listing 4.1 (Problem 4C.1): the rate constant
!     is evaluated at the mean temperature of the increment.
      PARAMETER (RHOQ  = 432.0D0,   ! rho*Q, mJ/mm^3
     1           AFAC  = 5.0D9,     ! pre-exponential factor, 1/s
     2           THETA = 12000.0D0, ! activation energy/R, K
     3           TZERO = 273.15D0)  ! absolute zero offset, K
!
      ALPHA0 = STATEV(1)
      TM     = TEMP(1) - 0.5D0*TEMP(2) + TZERO
      RK     = AFAC*EXP(-THETA/TM)
      IF (DTIME .GT. 0.0D0) THEN
         ALPHA1   = 1.0D0 - (1.0D0 - ALPHA0)*EXP(-RK*DTIME)
         FLUX(1)  = RHOQ*(ALPHA1 - ALPHA0)/DTIME
         FLUX(2)  = 0.5D0*RHOQ*(1.0D0 - ALPHA1)*RK*THETA/TM**2
         STATEV(1)= ALPHA1
      ELSE
         FLUX(1)  = RHOQ*(1.0D0 - ALPHA0)*RK
         FLUX(2)  = FLUX(1)*THETA/TM**2
      ENDIF
      RETURN
      END
