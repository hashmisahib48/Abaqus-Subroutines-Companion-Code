!     Driver: Newton iteration of one increment with HETVAL
!     usage: k4_newton TN ALPHAN DT JMODE
!     JMODE = 1 FLUX(2), 2 frozen alpha, 0 no derivative
!     prints the iterate and the correction of every iteration
      PROGRAM K4NEWTON
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      CHARACTER*32 ARG
      DIMENSION TEMP(2),TIME(2),SV(1),FLUX(2),PREDEF(1),DPRED(1)
      PARAMETER (RHOC = 2.16D0, RHOQ = 432.0D0, TZERO = 273.15D0)
      CALL GETARG(1,ARG); READ(ARG,*) TOLD
      CALL GETARG(2,ARG); READ(ARG,*) ALD
      CALL GETARG(3,ARG); READ(ARG,*) DT
      CALL GETARG(4,ARG); READ(ARG,*) JMODE
      CMNAME = 'REACTIVE'
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      TNEW = TOLD
      DO IT = 1, 60
         TEMP(1) = TNEW
         TEMP(2) = TNEW - TOLD
         SV(1) = ALD
         CALL HETVAL(CMNAME,TEMP,TIME,DT,SV,FLUX,PREDEF,DPRED)
         RES = RHOC*(TNEW - TOLD)/DT - FLUX(1)
         TK = TNEW + TZERO
         DF = FLUX(2)
         IF (JMODE .EQ. 2) DF = RHOQ*(1.0D0-ALD)*
     1      5.0D9*EXP(-12000.0D0/TK)*12000.0D0/TK**2
         IF (JMODE .EQ. 0) DF = 0.0D0
         DTN = -RES/(RHOC/DT - DF)
         TNEW = TNEW + DTN
         WRITE(*,'(I4,F16.9,ES14.4)') IT, TNEW, ABS(DTN)
         IF (ABS(DTN) .LT. 1.0D-9) GOTO 10
      ENDDO
 10   CONTINUE
      END
