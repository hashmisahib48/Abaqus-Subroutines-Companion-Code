      SUBROUTINE HETVAL(CMNAME,TEMP,TIME,DTIME,STATEV,FLUX,
     1 PREDEF,DPRED)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),STATEV(*),PREDEF(*),TIME(2),FLUX(2),
     1 DPRED(*)
!
!     Temperature-dependent source without depletion, Eq. (4.2-7)
!     FLUX(1) = RHOQ*A*exp(-THETA/T),  FLUX(2) = FLUX(1)*THETA/T**2
      PARAMETER (RHOQ  = 432.0D0,   ! rho*Q, mJ/mm^3
     1           AFAC  = 5.0D9,     ! pre-exponential factor, 1/s
     2           THETA = 12000.0D0, ! activation energy/R, K
     3           TZERO = 273.15D0)  ! absolute zero offset, K
!
      TK      = TEMP(1) + TZERO
      FLUX(1) = RHOQ*AFAC*EXP(-THETA/TK)
      FLUX(2) = FLUX(1)*THETA/TK**2
      RETURN
      END
