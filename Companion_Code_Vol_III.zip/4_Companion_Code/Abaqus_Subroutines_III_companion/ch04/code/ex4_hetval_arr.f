      SUBROUTINE HETVAL(CMNAME,TEMP,TIME,DTIME,STATEV,FLUX,
     1 PREDEF,DPRED)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),STATEV(*),PREDEF(*),TIME(2),FLUX(2),
     1 DPRED(*)
!     First-order Arrhenius reaction with depletion, Eqs. (4.2-4)
!     STATEV(1) = conversion ALPHA; temperatures in degC
      PARAMETER (RHOQ  = 432.0D0,   ! rho*Q, mJ/mm^3
     1           AFAC  = 5.0D9,     ! pre-exponential factor, 1/s
     2           THETA = 12000.0D0, ! activation energy/R, K
     3           TZERO = 273.15D0)  ! absolute zero offset, K
      ALPHA0 = STATEV(1)
      TK     = TEMP(1) + TZERO
      RK     = AFAC*EXP(-THETA/TK)
      IF (DTIME .GT. 0.0D0) THEN
         ALPHA1   = 1.0D0 - (1.0D0 - ALPHA0)*EXP(-RK*DTIME)
         FLUX(1)  = RHOQ*(ALPHA1 - ALPHA0)/DTIME
         FLUX(2)  = RHOQ*(1.0D0 - ALPHA1)*RK*THETA/TK**2
         STATEV(1)= ALPHA1
      ELSE
!        zero time increment: rate of the current state, no update
         FLUX(1)  = RHOQ*(1.0D0 - ALPHA0)*RK
         FLUX(2)  = FLUX(1)*THETA/TK**2
      ENDIF
      RETURN
      END
