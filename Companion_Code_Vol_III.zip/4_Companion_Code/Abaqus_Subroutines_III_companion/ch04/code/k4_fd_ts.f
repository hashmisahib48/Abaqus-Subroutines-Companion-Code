!     Driver: finite-difference test of FLUX(2) of HETVAL (Listing 4.3)
      PROGRAM K4FDTS
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),TIME(2),STATEV(1),FLUX(2),PREDEF(1),DPRED(1)
      DIMENSION FP(2), FM(2), F0(2)
      CMNAME = 'ZEROORDER'
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      TEMP(2) = 0.0D0
      H = 1.0D-3
      DO T0 = 20.0D0, 140.0D0, 40.0D0
         TEMP(1) = T0
         CALL HETVAL(CMNAME,TEMP,TIME,1.0D0,STATEV,F0,PREDEF,DPRED)
         TEMP(1) = T0 + H
         CALL HETVAL(CMNAME,TEMP,TIME,1.0D0,STATEV,FP,PREDEF,DPRED)
         TEMP(1) = T0 - H
         CALL HETVAL(CMNAME,TEMP,TIME,1.0D0,STATEV,FM,PREDEF,DPRED)
         FD = (FP(1) - FM(1))/(2.0D0*H)
         WRITE(*,'(F7.1,3ES14.6,ES10.2)') T0, F0(1), F0(2), FD,
     1      ABS(F0(2)-FD)/ABS(FD)
      ENDDO
      END
