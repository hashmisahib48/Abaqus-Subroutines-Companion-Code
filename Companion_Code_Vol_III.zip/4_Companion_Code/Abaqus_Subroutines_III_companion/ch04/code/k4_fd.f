!     Driver: finite-difference test of FLUX(2) of HETVAL (Listing 4.1)
      PROGRAM K4FD
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION TEMP(2),TIME(2),STATEV(1),FLUX(2),PREDEF(1),DPRED(1)
      DIMENSION CASE(4,4), FP(2), FM(2), F0(2)
      DATA CASE / 40.0D0, 0.0D0, 600.0D0, 0.0D0,
     1            60.0D0, 0.3D0, 600.0D0, 0.0D0,
     2           120.0D0, 0.3D0, 600.0D0, 0.0D0,
     3           200.0D0, 0.0D0,  60.0D0, 0.0D0 /
      CMNAME = 'REACTIVE'
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      H = 1.0D-3
      DO IC = 1, 4
         T0 = CASE(1,IC)
         A0 = CASE(2,IC)
         DT = CASE(3,IC)
         TEMP(2) = 0.0D0
         TEMP(1) = T0
         STATEV(1) = A0
         CALL HETVAL(CMNAME,TEMP,TIME,DT,STATEV,F0,PREDEF,DPRED)
         A1 = STATEV(1)
         TEMP(1) = T0 + H
         STATEV(1) = A0
         CALL HETVAL(CMNAME,TEMP,TIME,DT,STATEV,FP,PREDEF,DPRED)
         TEMP(1) = T0 - H
         STATEV(1) = A0
         CALL HETVAL(CMNAME,TEMP,TIME,DT,STATEV,FM,PREDEF,DPRED)
         FD = (FP(1) - FM(1))/(2.0D0*H)
         TK = T0 + 273.15D0
         RK = 5.0D9*EXP(-12000.0D0/TK)
         FNAIVE = 432.0D0*(1.0D0 - A0)*RK*12000.0D0/TK**2
         WRITE(*,'(F7.1,F6.2,F7.1,ES11.3,ES12.4,3ES13.5,ES10.2)')
     1      T0, A0, DT, RK*DT, F0(1), F0(2), FD, FNAIVE,
     2      ABS(F0(2)-FD)/ABS(FD)
      ENDDO
      END
