!     Driver: adiabatic material points with VHETVAL (Listing 4.6),
!     forward Euler in temperature: RHOC*(TNEW-TOLD) = DT*FLUX
!     usage: k4_vdrv DT TEND   (four points, T0 = 40, 60, 80, 100 degC)
      PROGRAM K4VDRV
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 4, RHOC = 2.16D0)
      CHARACTER*80 CMNAME
      CHARACTER*32 ARG
      DIMENSION NELEM(NB), COORDMP(NB,3), DENSITY(NB), PROPS(4)
      DIMENSION TEMPOLD(NB), FIELDOLD(NB,1), STATEOLD(NB,1)
      DIMENSION TEMPNEW(NB), TEMPGRADNEW(NB,1), FIELDNEW(NB,1)
      DIMENSION STATENEW(NB,1), FLUX(NB), TCR(NB), T0(NB), EB(NB)
      DATA T0 / 40.0D0, 60.0D0, 80.0D0, 100.0D0 /
      CALL GETARG(1,ARG); READ(ARG,*) DT
      CALL GETARG(2,ARG); READ(ARG,*) TEND
      CMNAME = 'REACTIVE'
      PROPS(1) = 432.0D0
      PROPS(2) = 5.0D9
      PROPS(3) = 12000.0D0
      PROPS(4) = 273.15D0
      DO K = 1, NB
         TEMPOLD(K) = T0(K)
         STATEOLD(K,1) = 0.0D0
         TCR(K) = -1.0D0
         EB(K) = 0.0D0
      ENDDO
      NSTEP = NINT(TEND/DT)
      DO N = 1, NSTEP
         TEMPNEW = TEMPOLD
         CALL VHETVAL(NB,NELEM,1,1,1,1,1,1,4,CMNAME,(N-1)*DT,N*DT,DT,
     1      COORDMP,DENSITY,PROPS,TEMPOLD,FIELDOLD,STATEOLD,
     2      TEMPNEW,TEMPGRADNEW,FIELDNEW,STATENEW,FLUX)
         DO K = 1, NB
            TNEW = TEMPOLD(K) + DT*FLUX(K)/RHOC
            IF (TCR(K) .LT. 0.0D0 .AND. TNEW .GE. 150.0D0)
     1         TCR(K) = (N-1)*DT + DT*(150.0D0-TEMPOLD(K))/
     2                  (TNEW-TEMPOLD(K))
            EB(K) = MAX(EB(K), ABS(RHOC*(TNEW-T0(K))
     1              - 432.0D0*STATENEW(K,1)))
            TEMPOLD(K) = TNEW
            STATEOLD(K,1) = STATENEW(K,1)
         ENDDO
      ENDDO
      WRITE(*,'(F8.2,4F13.2,ES10.2,4F8.2)') DT, TCR, MAXVAL(EB),
     1   TEMPOLD
      END
