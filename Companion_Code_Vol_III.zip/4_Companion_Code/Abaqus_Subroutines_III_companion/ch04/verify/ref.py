"""Reference solutions for Chapter 4 (independent of the Fortran routines)."""
import numpy as np
from scipy.integrate import quad, solve_ivp
from scipy.optimize import brentq, minimize_scalar
# Material R: units N, mm, tonne, s; temperatures in K inside this module
RHO=1.2e-9; CP=1.8e9; KC=0.25; QSP=3.6e11; RHOQ=RHO*QSP; THETA=12000.0; AF=5.0e9
RHOC=RHO*CP; DTAD=QSP/CP; ZERO=273.15
def kr(T): return AF*np.exp(-THETA/T)
# ---- adiabatic block, first order reaction with depletion:  dT/dt = kr(T) (Tf - T)
def adiabatic(T0C):
    T0=T0C+ZERO; Tf=T0+DTAD
    def tof(T): return quad(lambda s:1.0/(kr(s)*(Tf-s)),T0,T,epsabs=0,epsrel=1e-13,limit=400)[0]
    return T0,Tf,tof
def adiabatic_ode(T0C,tend,rtol=1e-12):
    T0=T0C+ZERO; Tf=T0+DTAD
    f=lambda t,y:[kr(y[0])*(Tf-y[0])]
    return solve_ivp(f,[0,tend],[T0],method='Radau',rtol=rtol,atol=1e-10,dense_output=True)
def t_ignition_ode(T0C):
    """time of maximum dT/dt (thermal runaway) from the accurate solution"""
    T0,Tf,tof=adiabatic(T0C)
    # d/dT of rate kr(T)(Tf-T)=0:  kr'(Tf-T)=kr  ->  THETA/T^2 (Tf-T)=1
    Tm=brentq(lambda T:THETA/T**2*(Tf-T)-1.0,T0,Tf-1e-9)
    return tof(Tm),Tm
def t_ad_FK(T0C):
    """Frank-Kamenetskii adiabatic induction time, zero-order, linearised exponent"""
    T0=T0C+ZERO
    return RHOC*T0**2/(RHOQ*THETA*kr(T0))
# ---- steady slab with source r(T)=RHOQ*kr(T): exact critical half-thickness
def Fint(T,Ta): return RHOQ*quad(kr,Ta,T,epsrel=1e-13)[0]
def a_of_Tc(Tc,Ta):
    F=Fint(Tc,Ta)
    g=lambda T:1.0/np.sqrt(max(F-Fint(T,Ta),1e-300))
    # integrate with substitution T=Tc-(Tc-Ta)*s^2 to remove the end singularity
    h=lambda s:2*s*(Tc-Ta)*g(Tc-(Tc-Ta)*s*s)
    return np.sqrt(KC/2)*quad(h,0,1,epsrel=1e-11,limit=200)[0]
def critical_slab(TaC):
    Ta=TaC+ZERO
    res=minimize_scalar(lambda x:-a_of_Tc(Ta+x,Ta),bounds=(2.0,40.0),method='bounded',options={'xatol':1e-10})
    return -res.fun,res.x   # a_cr (mm), centre rise at criticality (K)
def delta_fk(a,TaC):
    Ta=TaC+ZERO
    return THETA/Ta**2*RHOQ*kr(Ta)*a*a/KC
def a_fk(TaC,dc=0.8785):
    Ta=TaC+ZERO
    return np.sqrt(dc*KC*Ta**2/(THETA*RHOQ*kr(Ta)))
# ---- reaction-diffusion in the half slab (method of lines), depleting reaction
def slab_mol(a,TaC,N=200,tend=3.0e6,rtol=1e-9):
    Ta=TaC+ZERO; x=np.linspace(0,a,N+1); h=x[1]-x[0]
    def f(t,y):
        T=y[:N+1]; al=y[N+1:]
        r=RHOQ*kr(T)*(1-al)
        dT=np.zeros(N+1)
        dT[1:-1]=KC*(T[2:]-2*T[1:-1]+T[:-2])/h**2
        dT[0]=KC*2*(T[1]-T[0])/h**2
        dT=(dT+r)/RHOC; dT[-1]=0
        dal=kr(T)*(1-al); dal[-1]=0
        return np.concatenate([dT,dal])
    y0=np.concatenate([np.full(N+1,Ta),np.zeros(N+1)])
    ts=np.linspace(0,tend,2001)
    s=solve_ivp(f,[0,tend],y0,method='BDF',t_eval=ts,rtol=rtol,atol=1e-9)
    return s.t,s.y[0],s.y[N+1]   # centre temperature (K), centre conversion
if __name__=='__main__':
    print('rho c',RHOC,'dTad',DTAD,'rhoQ',RHOQ)
    for T0C in (40,60,80):
        T0,Tf,tof=adiabatic(T0C); ti,Tm=t_ignition_ode(T0C)
        print(T0C,'k0',kr(T0),'t_FK',t_ad_FK(T0C),'t_ign',ti,'Tm-ZERO',Tm-ZERO)
    acr,xc=critical_slab(60); print('a_cr exact',acr,'centre rise',xc,'a_FK',a_fk(60),'delta at acr',delta_fk(acr,60))
