import subprocess, numpy as np, sys
sys.path.insert(0,'.')
from ref import *
from scipy.integrate import solve_ivp
def peak_mol(a,N=60,tend=1.5e6):
    Ta=60+ZERO; h=a/N
    def f(t,y):
        T=y[:N+1]; al=y[N+1:]
        r=RHOQ*kr(T)*(1-al); dT=np.zeros(N+1)
        dT[1:-1]=KC*(T[2:]-2*T[1:-1]+T[:-2])/h**2; dT[0]=KC*2*(T[1]-T[0])/h**2
        dT=(dT+r)/RHOC; dT[-1]=0; dal=kr(T)*(1-al); dal[-1]=0
        return np.concatenate([dT,dal])
    y0=np.concatenate([np.full(N+1,Ta),np.zeros(N+1)])
    ev=lambda t,y:y[0]-(150+ZERO); ev.terminal=True
    s=solve_ivp(f,[0,tend],y0,method='BDF',rtol=1e-8,atol=1e-8,events=ev)
    return s.t_events[0].size>0
def peak_fe(a,N=40,dtmax=100,tend=1.5e6):
    subprocess.run(['./bin/slab_arr','1',str(a),'60',str(N),'30',str(dtmax),str(tend),'1'],capture_output=True,text=True)
    d=np.loadtxt('slab_trace.txt'); return d[:,1].max()>150
for name,fn in (('MOL',peak_mol),('FE',peak_fe)):
    lo,hi=65.0,100.0
    for _ in range(14):
        m=0.5*(lo+hi)
        if fn(m): hi=m
        else: lo=m
    print(name,'critical a (ignition above 150 C)',0.5*(lo+hi))
