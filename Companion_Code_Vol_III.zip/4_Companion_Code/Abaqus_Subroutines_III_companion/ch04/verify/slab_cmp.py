import subprocess, numpy as np, sys, json
sys.path.insert(0,'.')
from ref import *
def fe(a,N,dtmax,j=1,dt0=60,tend=3e6):
    o=subprocess.run(['/tmp/slab_arr','1',str(a),'60',str(N),str(dt0),str(dtmax),str(tend),str(j)],capture_output=True,text=True,cwd='/tmp').stdout
    d=np.loadtxt('/tmp/slab_trace.txt'); return o,d
def cross(t,T,lev):
    i=np.argmax(T>=lev)
    if T[i]<lev: return None
    return t[i-1]+(t[i]-t[i-1])*(lev-T[i-1])/(T[i]-T[i-1])
out={}
for a in (70,80,90,100):
    t,Tc,al=slab_mol(a,60,N=100,tend=3.0e6,rtol=1e-10)
    Tc=Tc-ZERO
    o1,d1=fe(a,40,3600); o2,d2=fe(a,80,300)
    row={}
    for name,(tt,T) in {'mol':(t,Tc),'fe40':(d1[:,0],d1[:,1]),'fe80':(d2[:,0],d2[:,1])}.items():
        row[name]=(float(T.max()), cross(tt,T,150.0))
    out[a]=row; print(a,row)
json.dump(out,open('slab_cmp.json','w'))
