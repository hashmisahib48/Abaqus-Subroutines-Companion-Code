#!/bin/sh
# compile every listing and driver of Chapter 4 (gfortran 13, stubs from lib/aba)
C=/home/claude/vol3/ch04/code; B=/home/claude/vol3/ch04/verify/bin; I=/home/claude/vol3/lib/aba
F="-std=legacy -ffixed-form -ffixed-line-length-none -I$I"
cd $C
for f in ex4_hetval_arr ex4_hetval_ts ex4_hetval_joule ex4_vhetval_arr; do gfortran -c $F $f.f -o $B/$f.o || exit 1; done
gfortran $F k4_fd.f ex4_hetval_arr.f -o $B/k4_fd
gfortran $F k4_fd_ts.f ex4_hetval_ts.f -o $B/k4_fd_ts
gfortran $F k4_adiab.f ex4_hetval_arr.f -o $B/k4_adiab
gfortran $F k4_slab.f ex4_hetval_arr.f -o $B/slab_arr
gfortran $F k4_slab.f ex4_hetval_ts.f -o $B/slab_ts
gfortran $F k4_vdrv.f ex4_vhetval_arr.f -o $B/k4_vdrv
gfortran $F k4_newton.f ex4_hetval_arr.f -o $B/k4_newton
gfortran $F k4_joule.f ex4_hetval_joule.f -o $B/k4_joule
gfortran $F k4_fd_mid.f prob_4c1_mid.f -o $B/k4_fd_mid
gfortran $F k4_adiab.f prob_4c1_mid.f -o $B/k4_adiab_mid
echo built
