import subprocess, numpy as np, sys, json
sys.path.insert(0,'.')
from ref import *
from scipy.integrate import solve_ivp
def mol(a,N,tend=3e5):
    Ta=60+ZERO; x=np.linspace(0,a,N+1); h=x[1]-x[0]
    def f(t,y):
        T=y[:N+1]; al=y[N+1:]
        r=RHOQ*kr(T)*(1-al); dT=np.zeros(N+1)
        dT[1:-1]=KC*(T[2:]-2*T[1:-1]+T[:-2])/h**2; dT[0]=KC*2*(T[1]-T[0])/h**2
        dT=(dT+r)/RHOC; dT[-1]=0; dal=kr(T)*(1-al); dal[-1]=0
        return np.concatenate([dT,dal])
    y0=np.concatenate([np.full(N+1,Ta),np.zeros(N+1)])
    ts=np.arange(0,tend,20.0)
    s=solve_ivp(f,[0,tend],y0,method='BDF',t_eval=ts,rtol=1e-11,atol=1e-10)
    return s.t,s.y[0]-ZERO
def cross(t,T,lev):
    i=np.argmax(T>=lev); return t[i-1]+(t[i]-t[i-1])*(lev-T[i-1])/(T[i]-T[i-1])
def fe(a,N,dtmax,tend=3e5):
    subprocess.run(['/tmp/slab_arr','1',str(a),'60',str(N),'30',str(dtmax),str(tend),'1'],capture_output=True,text=True,cwd='/tmp')
    return np.loadtxt('/tmp/slab_trace.txt')
a=90
for N in (50,100,200):
    t,T=mol(a,N); print('MOL N',N,'t150',cross(t,T,150.0),'peak',T.max())
for dtm in (3600,1200,400,100,25):
    d=fe(a,100,dtm); print('FE N=100 dtmax',dtm,'t150',cross(d[:,0],d[:,1],150.0))
