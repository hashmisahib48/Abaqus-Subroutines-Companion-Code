import subprocess, numpy as np, sys, json
sys.path.insert(0,'.')
from ref import *
B='/home/claude/vol3/ch04/verify/bin/'
def run(a): return subprocess.run(a,capture_output=True,text=True,cwd='work').stdout
import os; os.makedirs('work',exist_ok=True)
R={}
ex=adiabatic(60)[2](150+ZERO); R['t150']=ex
ti,Tm=t_ignition_ode(60); R['tign']=(ti,Tm-ZERO); R['tFK']=t_ad_FK(60)
print('exact t150',ex,'t_ign',ti,Tm-ZERO,'FK',t_ad_FK(60),'k0',kr(60+ZERO),'1/k0',1/kr(60+ZERO))
rows=[]
for dt in (1600,400,100,25,6.25):
    r=[]
    for j in (1,2,0):
        o=run([B+'k4_adiab','60',str(dt),'80000',str(j)]).split('\n')
        f=o[0].split(); cut=int(o[1].split()[-1])
        r.append((int(f[3]),int(f[4]),cut,float(f[5]),float(f[6])))
    rows.append((dt,r)); print(dt,r)
R['jac']=rows
for T0 in (40,60,80,100):
    print('exact t150 T0',T0,adiabatic(T0)[2](150+ZERO))
vrows=[]
for dt in (100,25,6.25,1.5625):
    f=run([B+'k4_vdrv',str(dt),'3.0e6']).split(); vrows.append([float(x) for x in f]); print(f)
