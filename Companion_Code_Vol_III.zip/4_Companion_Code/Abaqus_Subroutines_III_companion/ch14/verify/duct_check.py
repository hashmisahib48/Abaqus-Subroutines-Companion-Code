# independent check of the ductile UDMGINI driver (Python closed forms, numpy eigen-decomposition)
import numpy as np, subprocess, os, math
A='/home/claude/vol3/lib/aba'; C='/home/claude/vol3/ch14/code'; T='/tmp/claude-0'
D1,D2,D3,D4,D5,D6=1.3,1.6,0.5,1.2,1.0,0.5
def ef(eta,thb):
    a1=D1*math.exp(-D2*eta); a3=D3*math.exp(-D4*eta); a5=D5*math.exp(-D6*eta)
    return (0.5*(a1+a5)-a3)*thb**2+0.5*(a1-a5)*thb+a3
out=subprocess.run([T+'/drvd'],capture_output=True,text=True).stdout.strip().split('\n')
rows={}
for l in out:
    if l.startswith('REPEAT'): print(l); continue
    p=l.split(); rows.setdefault(p[0],[]).append([float(x) for x in p[1:]]) if not p[0].startswith('TENS') else rows.setdefault('TENS+SHR',[]).append([float(x) for x in p[1:]])
st={'UNIAXIAL':(1/3,1.0),'SHEAR':(0.0,0.0),'PLANESTR':(1/math.sqrt(3),0.0),'PE-2D':(1/math.sqrt(3),0.0),'PS-BIAX':(2/3,-1.0)}
mx=0
for k,(eta,thb) in st.items():
    for r in rows[k]:
        ref=r[0]/ef(eta,thb); mx=max(mx,abs(ref-r[1]))
    print(k,'eps_f=%.5f'%ef(eta,thb),'driver D(p=0.5)=%.6f'%rows[k][-1][1],'closed %.6f'%(0.5/ef(eta,thb)),'p at D=1: %.5f'%ef(eta,thb))
tr=rows['TENS+SHR']
for r in tr:
    p=r[0]
    ref=min(p,0.15)/ef(1/3,1.0)+max(p-0.15,0)/ef(0,0.0)
    mx=max(mx,abs(ref-r[1]))
print('two-stage D(0.35)=%.6f closed %.6f'%(tr[-1][1],0.15/ef(1/3,1.0)+0.2/ef(0,0.0)))
print('max |D_driver - D_closed| = %.2e'%mx)
print('compression D =',rows['COMPRESS'][-1][1])
# random states for K14_PRIN / K14_INV
rng=np.random.default_rng(14)
V=rng.normal(size=(5000,6))*100
np.savetxt(C+'/prin_in.txt',V)
os.system(f'cd {C} && gfortran -ffixed-form -std=legacy -I{A} drv_prin.f ex14_invar.f ex14_prin.f {A}/stubs.f -o {T}/drvp && {T}/drvp > {T}/prin_out.txt')
R=np.loadtxt(T+'/prin_out.txt'); e1=e2=e3=0
for v,r in zip(V,R):
    S=np.array([[v[0],v[3],v[4]],[v[3],v[1],v[5]],[v[4],v[5],v[2]]])
    w,U=np.linalg.eigh(S); n=U[:,-1]
    e1=max(e1,abs(w[-1]-r[0])); e2=max(e2,1-abs(n@r[1:4]))
    p=np.trace(S)/3; s=S-p*np.eye(3); q=math.sqrt(1.5*np.sum(s*s)); xi=13.5*np.linalg.det(s)/q**3
    e3=max(e3,abs(xi-r[5]),abs(p/q-r[4]),abs((1-2/math.pi*math.acos(max(-1,min(1,xi))))-r[6]))
print('5000 random states: max |S1 err| %.2e, max 1-|n.n_ref| %.2e, max invariant err %.2e'%(e1,e2,e3))
