# independent check of UDAMAGEMF law: Hashin-Shtrikman lower-bound form of the sphere composite
import numpy as np, subprocess, math, json
T='/tmp/claude-0'
Em,num,Ei,nui,c,kap=3500.,0.35,72000.,0.22,0.3,0.1
def KG(E,nu): return E/(3*(1-2*nu)), E/(2*(1+nu))
def E_hs(Em,num,Ei,nui,c):
    Km,Gm=KG(Em,num); Ki,Gi=KG(Ei,nui)
    K=Km+c/(1/(Ki-Km)+3*(1-c)/(3*Km+4*Gm))
    G=Gm+c/(1/(Gi-Gm)+6*(Km+2*Gm)*(1-c)/(5*Gm*(3*Km+4*Gm)))
    return 9*K*G/(3*K+G)
E0=E_hs(Em,num,Ei,nui,c); print('E_eff(0) = %.4f MPa'%E0)
rows=np.array([[float(x) for x in l.split()] for l in subprocess.run([T+'/drvm'],capture_output=True,text=True).stdout.strip().split('\n')])
mx=0; mx2=0
for dl,dm,s1,s2,sm in rows:
    ref=1-E_hs(Em*(1-dm),num,Ei*(1-kap*dm),nui,c)/E0
    mx=max(mx,abs(ref-sm))
    dref=4*(dl-1)/(dl*3) if dl<4 else dm
    mx2=max(mx2,abs(dref-dm),abs(s2-kap*dm),abs(s1-dm))
print('max |SDEGMACRO - D_HS| = %.2e ; max micro/damage-law error %.2e'%(mx,mx2))
for dl,dm,s1,s2,sm in rows[[3,6,9]]:
    print('delta=%.2f d_m=%.4f SDEGMICRO(incl)=%.4f SDEGMACRO=%.4f  vol-weighted=%.4f  max-rule=%.4f'%(dl,dm,s2,sm,(1-c)*dm+c*kap*dm,max(dm,s2)))
print('limits: c->0 (c=1e-9) D/d_m =',(1-E_hs(Em*0.5,num,Ei*0.95,nui,1e-9)/E_hs(Em,num,Ei,nui,1e-9))/0.5)
# dilute bound check: D(d_m) for kappa=0 on a fine grid for the figure
d=np.linspace(0,1,101)
Dmt=[1-E_hs(Em*(1-x)+1e-12,num,Ei*(1-kap*x),nui,c)/E0 for x in d]
json.dump({'d':list(d),'Dmt':Dmt},open('/home/claude/vol3/ch14/verify/mf_curve.json','w'))
print('D at d=0.5: %.4f'%(1-E_hs(Em*0.5,num,Ei*(1-kap*0.5),nui,c)/E0))
# a fibre composite for contrast: rule of mixtures along fibres
Ef,cf=72000,0.4
for dm in (0.5,):
    Dl=1-((1-cf)*Em*(1-dm)+cf*Ef)/((1-cf)*Em+cf*Ef); print('fibre direction, matrix d=0.5: loss %.4f'%Dl)
