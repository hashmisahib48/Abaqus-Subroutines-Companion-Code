# independent check of the Hashin UDMGINI: closed-form off-axis strength + random 3-D states
import numpy as np, subprocess, os, math
A='/home/claude/vol3/lib/aba'; C='/home/claude/vol3/ch14/code'; T='/tmp/claude-0'
XT,XC,YT,YC,SL,ST=1500.,1200.,40.,200.,80.,50.
out=np.array([[float(x) for x in l.split()] for l in subprocess.run([T+'/drvh'],capture_output=True,text=True).stdout.strip().split('\n')])
mx=0; nmax=0
for ph,sg,sf,im,*n in out:
    c,s=math.cos(math.radians(ph)),math.sin(math.radians(ph))
    if sg>0:
        ft=1/math.sqrt(c**4/XT**2+s*s*c*c/SL**2) if c>1e-12 else 1e99
        mt=1/math.sqrt(s**4/YT**2+s*s*c*c/SL**2) if s>1e-12 else 1e99
        ref=min(ft,mt); mech=1 if ft<mt else 3
    else:
        fc=XC/c**2 if c>1e-12 else 1e99
        a=s**4/(4*ST**2)+s*s*c*c/SL**2; b=((YC/(2*ST))**2-1)*s*s/YC
        mc=(b+math.sqrt(b*b+4*a))/(2*a) if a>0 else 1e99   # |sigma|
        ref=min(fc,mc); mech=2 if fc<mc else 4
    mx=max(mx,abs(ref-sf)/ref)
    e1=np.array([c,s,0]); e2=np.array([-s,c,0]); e3=np.array([0,0,1.])
    a0=math.radians(53); nref={1:e1,2:e1,3:e2,4:math.cos(a0)*e2+math.sin(a0)*e3}[mech]
    nmax=max(nmax,np.linalg.norm(np.array(n)-nref))
    if mech!=im: print('mechanism mismatch at',ph,sg,mech,im)
print('off-axis strength: max relative error %.2e; max normal error %.2e'%(mx,nmax))
# tabulate a few for the book
for ph in (0,5,10,30,60,90):
    for sg in (1,-1):
        r=[o for o in out if o[0]==ph and o[1]==sg][0]; print(int(ph),int(sg),'%.2f'%r[2],int(r[3]))
# crossover angle FT/MT for tension
from scipy.optimize import brentq
f=lambda p:(math.cos(p)**4/XT**2+math.sin(p)**2*math.cos(p)**2/SL**2)-(math.sin(p)**4/YT**2+math.sin(p)**2*math.cos(p)**2/SL**2)
print('FT/MT crossover angle: %.3f deg'%math.degrees(brentq(f,0.01,1.5)))
# random states
rng=np.random.default_rng(7)
V=rng.normal(size=(5000,6))*np.array([600,60,60,50,50,50]); np.savetxt(C+'/hashr_in.txt',V)
os.system(f'cd {C} && gfortran -ffixed-form -std=legacy -I{A} drv_hashr.f ex14_hashin.f ex14_invar.f {A}/stubs.f -o {T}/drvhr && {T}/drvhr > {T}/hashr_out.txt')
R=np.loadtxt(T+'/hashr_out.txt')
def hashin(v):
    s11,s22,s33,t12,t13,t23=v; sm=s22+s33; tl=(t12**2+t13**2)/SL**2; tt=(t23**2-s22*s33)/ST**2
    ft=fc=mt=mc=0.
    if s11>=0: ft=(s11/XT)**2+tl
    else: fc=(s11/XC)**2
    if sm>=0: mt=sm**2/YT**2+tt+tl
    else: mc=((YC/(2*ST))**2-1)*sm/YC+sm**2/(4*ST**2)+tt+tl
    return [math.sqrt(max(x,0)) for x in (ft,fc,mt,mc)]
print('random states: max |FINDEX diff| = %.2e'%max(abs(np.array(hashin(v))-r).max() for v,r in zip(V,R)))
