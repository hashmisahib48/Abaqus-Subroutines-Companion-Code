# numbers for the problems of Chapter 14 (independent Python)
import numpy as np, math
from scipy.integrate import quad
D1,D2,D3,D4,D5,D6=1.3,1.6,0.5,1.2,1.0,0.5
def ef(eta,thb):
    a1=D1*math.exp(-D2*eta); a3=D3*math.exp(-D4*eta); a5=D5*math.exp(-D6*eta)
    return (0.5*(a1+a5)-a3)*thb**2+0.5*(a1-a5)*thb+a3
eA=ef(1/3,1); eB=ef(0,0); eC=ef(1/math.sqrt(3),0)
print('A.1: eps_f A,B,C = %.5f %.5f %.5f'%(eA,eB,eC))
D1_=0.2/eA; D2_=D1_+0.05/eC; D3_=D2_+0.1/eB
print('D after stages: %.5f %.5f %.5f ; extra shear strain to D=1: %.5f -> total shear eps %.5f'%(D1_,D2_,D3_,(1-D3_)*eB,0.1+(1-D3_)*eB))
# A.2
XT,XC,YT,YC,SL,ST=1500.,1200.,40.,200.,80.,50.
ft=math.sqrt((900/XT)**2+(40/SL)**2); mt=math.sqrt((25/YT)**2+(40/SL)**2)
print('A.2: FT %.4f MT %.4f; lambda_f = %.4f'%(ft,mt,1/max(ft,mt)))
# A.3
def KG(E,nu): return E/(3*(1-2*nu)), E/(2*(1+nu))
def Emt(Em,num,Ei,nui,c):
    Km,Gm=KG(Em,num); Ki,Gi=KG(Ei,nui)
    K=Km+c*(Ki-Km)/(1+(1-c)*(Ki-Km)/(Km+4*Gm/3)); f=Gm*(9*Km+8*Gm)/(6*(Km+2*Gm))
    G=Gm+c*(Gi-Gm)/(1+(1-c)*(Gi-Gm)/(Gm+f)); return 9*K*G/(3*K+G)
E0=Emt(3500,.35,72000,.22,.3)
dm=0.6; kap=0.1
print('A.3: macro %.4f  incl %.3f  vol %.4f'%(1-Emt(3500*(1-dm),.35,72000*(1-kap*dm),.22,.3)/E0,kap*dm,0.7*dm+0.3*kap*dm))
# B.1 non-proportional: psi from 90 to 0 deg linearly in p over [0,0.3]
def eta_th(psi):
    s11=math.cos(psi); t=math.sin(psi); q=math.sqrt(s11**2+3*t**2)
    p=s11/3; s=np.array([[s11-p,t,0],[t,-p,0],[0,0,-p]])
    xi=13.5*np.linalg.det(s)/q**3; xi=max(-1,min(1,xi))
    return p/q, 1-2/math.pi*math.acos(xi)
def integrand(p):
    psi=(math.pi/2)*(1-p/0.3); e,t=eta_th(psi); return 1/ef(e,t)
ex=quad(integrand,0,0.3,epsabs=1e-13,epsrel=1e-13)[0]
print('B.1 exact D = %.6f'%ex)
for N in (1,2,4,8,16,32):
    h=0.3/N; endp=sum(h*integrand((k+1)*h) for k in range(N)); mid=sum(h*integrand((k+0.5)*h) for k in range(N)); beg=sum(h*integrand(k*h) for k in range(N))
    print(N,'end %.6f err %.2e | mid %.6f err %.2e'%(endp,endp-ex,mid,mid-ex))
# B.3 band widths
import math
print('B.3 widths sqrt-index %.5f  quadratic-index %.5f'%(1.05-0.95, math.sqrt(1.05)-math.sqrt(0.95)))
# C.2
print('C.2: sigma_mt(30)=%.3f'%(1/math.sqrt(math.sin(math.radians(30))**4/YT**2+(math.sin(math.radians(30))*math.cos(math.radians(30)))**2/SL**2)))
# min MC
ph=np.radians(np.linspace(0.1,89.9,2000)); c,s=np.cos(ph),np.sin(ph)
a=s**4/(4*ST**2)+s*s*c*c/SL**2; b=((YC/(2*ST))**2-1)*s*s/YC; mc=(b+np.sqrt(b*b+4*a))/(2*a)
print('min sigma_mc %.3f at %.2f deg'%(mc.min(),np.degrees(ph[mc.argmin()])))
# 14.2 pure shear tie
print('tau12=80: FT=%.3f MT=%.3f'%(math.sqrt((80/SL)**2),math.sqrt((80/SL)**2)))
