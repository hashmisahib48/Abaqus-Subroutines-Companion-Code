#!/bin/sh
# compile every listing and run the drivers of Chapter 14 (gfortran, stubs in lib/aba)
A=/home/claude/vol3/lib/aba; F="-ffixed-form -std=legacy -I$A"; T=/tmp/claude-0
cd "$(dirname "$0")"
for f in ex14_ductile ex14_hashin ex14_udamagemf ex14_invar ex14_prin ex14_mt; do gfortran -c $F $f.f -o $T/$f.o || exit 1; done
gfortran $F drv_ductile.f ex14_ductile.f ex14_invar.f ex14_prin.f $A/stubs.f -o $T/drvd || exit 1
gfortran $F drv_hashin.f ex14_hashin.f ex14_invar.f $A/stubs.f -o $T/drvh || exit 1
gfortran $F drv_mf.f ex14_udamagemf.f ex14_mt.f ex14_invar.f $A/stubs.f -o $T/drvm || exit 1
python3 ../verify/duct_check.py > ../verify/out_duct.txt; python3 ../verify/hashin_check.py > ../verify/out_hashin.txt; python3 ../verify/mf_check.py > ../verify/out_mf.txt
cat ../verify/out_duct.txt ../verify/out_hashin.txt ../verify/out_mf.txt
