      SUBROUTINE K14_FULL(NDI,NSHR,V,SH,A)
!     Voigt vector -> symmetric 3x3; SH = 1 (stress) or 0.5 (strain)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION V(NDI+NSHR),A(3,3)
      DO I=1,3
        DO J=1,3
          A(I,J)=0.D0
        END DO
      END DO
      DO I=1,NDI
        A(I,I)=V(I)
      END DO
      A(1,2)=SH*V(NDI+1)
      IF (NSHR .GE. 3) THEN
        A(1,3)=SH*V(NDI+2)
        A(2,3)=SH*V(NDI+3)
      END IF
      A(2,1)=A(1,2)
      A(3,1)=A(1,3)
      A(3,2)=A(2,3)
      RETURN
      END

      SUBROUTINE K14_INV(A,ETA,XI,THB,Q)
!     triaxiality, Lode parameters (Vol. I, Eq. 7.6-1 to 7.6-3)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3),S(3,3)
      PARAMETER (PI=3.14159265358979D0)
      P=(A(1,1)+A(2,2)+A(3,3))/3.D0
      DO I=1,3
        DO J=1,3
          S(I,J)=A(I,J)
        END DO
        S(I,I)=S(I,I)-P
      END DO
      Q=SQRT(1.5D0*(S(1,1)**2+S(2,2)**2+S(3,3)**2
     1 +2.D0*(S(1,2)**2+S(1,3)**2+S(2,3)**2)))
      ETA=0.D0
      XI=0.D0
      THB=0.D0
      IF (Q .LT. 1.D-6) RETURN
      DET=S(1,1)*(S(2,2)*S(3,3)-S(2,3)**2)
     1 -S(1,2)*(S(1,2)*S(3,3)-S(2,3)*S(1,3))
     2 +S(1,3)*(S(1,2)*S(2,3)-S(2,2)*S(1,3))
      ETA=P/Q
      XI=MAX(-1.D0,MIN(1.D0,13.5D0*DET/Q**3))
      THB=1.D0-2.D0/PI*ACOS(XI)
      RETURN
      END

      DOUBLE PRECISION FUNCTION K14_LOCUS(PROPS,ETA,THB)
!     fracture strain of the locus, Eq. 14.4-1
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*)
      A1=PROPS(1)*EXP(-PROPS(2)*ETA)
      A3=PROPS(3)*EXP(-PROPS(4)*ETA)
      A5=PROPS(5)*EXP(-PROPS(6)*ETA)
      K14_LOCUS=(0.5D0*(A1+A5)-A3)*THB**2+0.5D0*(A1-A5)*THB+A3
      RETURN
      END

      SUBROUTINE K14_ERR(TEXT)
      CHARACTER*(*) TEXT
      DIMENSION INTV(1),REALV(1)
      CHARACTER*8 CHARV(1)
      CALL STDB_ABQERR(-3,TEXT,INTV,REALV,CHARV)
      RETURN
      END
