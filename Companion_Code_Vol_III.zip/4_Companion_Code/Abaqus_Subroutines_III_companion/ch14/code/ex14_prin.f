      SUBROUTINE K14_PRIN(NSHR,A,EN,S1)
!     largest principal stress S1 and its unit direction EN. For
!     NSHR = 1 (2-D) only the in-plane stresses are considered.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3),EN(3),W(3,3),V(3,3)
      EN(1)=1.D0
      EN(2)=0.D0
      EN(3)=0.D0
      IF (NSHR .EQ. 1) THEN
        TH=0.5D0*ATAN2(2.D0*A(1,2),A(1,1)-A(2,2))
        EN(1)=COS(TH)
        EN(2)=SIN(TH)
        S1=A(1,1)*EN(1)**2+A(2,2)*EN(2)**2+2.D0*A(1,2)*EN(1)*EN(2)
        RETURN
      END IF
      DO I=1,3
        DO J=1,3
          W(I,J)=A(I,J)
          V(I,J)=0.D0
        END DO
        V(I,I)=1.D0
      END DO
      DO SWEEP=1,30
        OFF=ABS(W(1,2))+ABS(W(1,3))+ABS(W(2,3))
        IF (OFF .LT. 1.D-14*(ABS(W(1,1))+ABS(W(2,2))+ABS(W(3,3))
     1   +1.D-300)) GO TO 20
        DO IP=1,2
          DO IQ=IP+1,3
            IF (ABS(W(IP,IQ)) .LT. 1.D-300) CYCLE
            TH=0.5D0*(W(IQ,IQ)-W(IP,IP))/W(IP,IQ)
            T=SIGN(1.D0,TH)/(ABS(TH)+SQRT(1.D0+TH*TH))
            C=1.D0/SQRT(1.D0+T*T)
            SN=T*C
            DO K=1,3
              WKP=W(K,IP)
              WKQ=W(K,IQ)
              W(K,IP)=C*WKP-SN*WKQ
              W(K,IQ)=SN*WKP+C*WKQ
            END DO
            DO K=1,3
              WPK=W(IP,K)
              WQK=W(IQ,K)
              W(IP,K)=C*WPK-SN*WQK
              W(IQ,K)=SN*WPK+C*WQK
            END DO
            DO K=1,3
              VKP=V(K,IP)
              VKQ=V(K,IQ)
              V(K,IP)=C*VKP-SN*VKQ
              V(K,IQ)=SN*VKP+C*VKQ
            END DO
          END DO
        END DO
      END DO
   20 CONTINUE
      IMAX=1
      IF (W(2,2) .GT. W(IMAX,IMAX)) IMAX=2
      IF (W(3,3) .GT. W(IMAX,IMAX)) IMAX=3
      S1=W(IMAX,IMAX)
      DO K=1,3
        EN(K)=V(K,IMAX)
      END DO
      RETURN
      END
