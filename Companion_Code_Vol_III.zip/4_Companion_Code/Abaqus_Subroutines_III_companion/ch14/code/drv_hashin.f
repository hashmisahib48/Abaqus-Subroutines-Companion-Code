!     Driver: off-axis strength of a ply from the Hashin UDMGINI.
!     Uniaxial stress SIG along global x, fibres at angle PHI to x.
!     Prints phi, sign, failing stress, governing mechanism, normal.
      PROGRAM DRVHASH
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (PI=3.14159265358979D0)
      DIMENSION PROPS(7),FINDEX(4),FNORMAL(3,4),STRESS(6),STRAIN(6)
      DIMENSION STRAINEE(6),STATEV(1),TIME(2),PREDEF(1),DPRED(1)
      DIMENSION COORDS(3),DROT(3,3),ORI(3,3),JMAC(1),JMATYP(1)
      DIMENSION LXFEM(3)
      DATA PROPS/1500.D0,1200.D0,40.D0,200.D0,80.D0,50.D0,53.D0/
      DATA LXFEM/1,1,0/
      DROT=0.D0
      DO I=1,3
        DROT(I,I)=1.D0
      END DO
      DO ISG=1,2
        SG=3.D0-2.D0*ISG
        DO IP=0,18
          PHI=5.D0*IP*PI/180.D0
          C=COS(PHI)
          S=SIN(PHI)
          ORI=0.D0
          ORI(1,1)=C
          ORI(2,1)=S
          ORI(1,2)=-S
          ORI(2,2)=C
          ORI(3,3)=1.D0
          SLO=0.D0
          SHI=5000.D0
          DO IT=1,200
            SIG=0.5D0*(SLO+SHI)*SG
            STRESS=0.D0
            STRESS(1)=SIG*C*C
            STRESS(2)=SIG*S*S
            STRESS(4)=-SIG*S*C
            CALL UDMGINI(FINDEX,4,FNORMAL,3,3,6,PROPS,7,STATEV,1,
     1       STRESS,STRAIN,STRAINEE,LXFEM,TIME,0.D0,0.D0,0.D0,PREDEF,
     2       DPRED,0,COORDS,1,1,1,1,1,1,0,0,0.D0,0.D0,0.D0,0.D0,0.D0,
     3       0.D0,JMAC,JMATYP,0,0,1.D0,DROT,ORI)
            FM=MAXVAL(FINDEX)
            IF (FM .GE. 1.D0) THEN
              SHI=0.5D0*(SLO+SHI)
            ELSE
              SLO=0.5D0*(SLO+SHI)
            END IF
          END DO
          SIG=SHI*SG
          STRESS(1)=SIG*C*C
          STRESS(2)=SIG*S*S
          STRESS(4)=-SIG*S*C
          CALL UDMGINI(FINDEX,4,FNORMAL,3,3,6,PROPS,7,STATEV,1,
     1     STRESS,STRAIN,STRAINEE,LXFEM,TIME,0.D0,0.D0,0.D0,PREDEF,
     2     DPRED,0,COORDS,1,1,1,1,1,1,0,0,0.D0,0.D0,0.D0,0.D0,0.D0,
     3     0.D0,JMAC,JMATYP,0,0,1.D0,DROT,ORI)
          IM=MAXLOC(FINDEX,1)
          WRITE(*,'(F6.1,F5.0,F12.4,I3,3F10.5)') 5.D0*IP,SG,SHI,IM,
     1     (FNORMAL(K,IM),K=1,3)
        END DO
      END DO
      END
