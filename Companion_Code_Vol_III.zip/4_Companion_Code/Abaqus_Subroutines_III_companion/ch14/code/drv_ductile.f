!     Driver for the ductile UDMGINI: proportional and two-stage paths
!     (J2 flow, linear hardening), called as Abaqus would call it.
!     Output: name, eps_p, FINDEX(1), FINDEX(2), eta, theta, normal
      PROGRAM DRVDUCT
      INCLUDE 'ABA_PARAM.INC'
      COMMON /REP/ RMAX
      DIMENSION U1(4),U2(4)
      RMAX=0.D0
      U1=(/1.D0,0.D0,0.D0,0.D0/)
      CALL PATH('UNIAXIAL',U1,0.5D0,U1,0.D0,50,3,6,30.D0)
      U1=(/0.D0,0.D0,0.D0,1.D0/)
      CALL PATH('SHEAR   ',U1,0.5D0,U1,0.D0,50,3,6,30.D0)
      U1=(/1.D0,0.5D0,0.D0,0.D0/)
      CALL PATH('PLANESTR',U1,0.5D0,U1,0.D0,50,3,6,30.D0)
      U1=(/-1.D0,0.D0,0.D0,0.D0/)
      CALL PATH('COMPRESS',U1,0.5D0,U1,0.D0,50,3,6,30.D0)
      U1=(/1.D0,0.D0,0.D0,0.D0/)
      U2=(/0.D0,0.D0,0.D0,1.D0/)
      CALL PATH('TENS+SHR',U1,0.15D0,U2,0.2D0,50,3,6,30.D0)
      U1=(/1.D0,0.5D0,0.D0,0.D0/)
      CALL PATH('PE-2D   ',U1,0.5D0,U1,0.D0,50,3,4,0.D0)
      U1=(/1.D0,1.D0,0.D0,0.D0/)
      CALL PATH('PS-BIAX ',U1,0.5D0,U1,0.D0,50,2,3,0.D0)
      WRITE(*,'(A,E10.3)') 'REPEAT-CALL max difference ',RMAX
      END

      SUBROUTINE STATE(U,SY,DP,NDI,NTENS,STRESS,STRAINEE,DEPV)
!     stress on the line U (unit direction) at yield level SY, elastic
!     strain, and plastic strain DP*1.5*s/q for the equivalent strain DP
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (E=210000.D0,XNU=0.3D0)
      DIMENSION U(4),STRESS(NTENS),STRAINEE(NTENS),DEPV(NTENS)
      DIMENSION V(6),S(3),UU(3)
      NSHR=NTENS-NDI
      UU=U(1:3)
      PM=(UU(1)+UU(2)+UU(3))/3.D0
      Q=SQRT(1.5D0*((UU(1)-PM)**2+(UU(2)-PM)**2+(UU(3)-PM)**2
     1 +2.D0*U(4)**2))
      F=SY/Q
      DO K=1,NDI
        STRESS(K)=UU(K)*F
      END DO
      STRESS(NDI+1)=U(4)*F
      TR=0.D0
      DO K=1,NDI
        TR=TR+STRESS(K)
      END DO
      DO K=1,NDI
        STRAINEE(K)=((1.D0+XNU)*STRESS(K)-XNU*TR)/E
        S(1)=STRESS(K)-F*PM
        DEPV(K)=1.5D0*DP*S(1)/SY
      END DO
      STRAINEE(NDI+1)=2.D0*(1.D0+XNU)*STRESS(NDI+1)/E
      DEPV(NDI+1)=2.D0*1.5D0*DP*STRESS(NDI+1)/SY
      RETURN
      END

      SUBROUTINE PATH(NAME,U1,P1,U2,P2,N,NDI,NTENS,ANG)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (SY0=250.D0,HH=1000.D0,PI=3.14159265358979D0)
      CHARACTER*8 NAME
      DIMENSION U1(4),U2(4),PROPS(8),STATEV(12),STRESS(6),STRAIN(6)
      DIMENSION STRAINEE(6),FINDEX(2),FNORMAL(3,2),TIME(2),PREDEF(1)
      DIMENSION DPRED(1),COORDS(3),DROT(3,3),ORI(3,3),JMAC(1)
      DIMENSION JMATYP(1),LXFEM(3),EPL(6),DEPV(6),SV0(12)
      COMMON /REP/ RMAX
      DATA PROPS/1.3D0,1.6D0,0.5D0,1.2D0,1.0D0,0.5D0,-0.3333333333D0,
     1 2500.D0/
      DATA LXFEM/1,1,0/
      NSHR=NTENS-NDI
      STATEV=0.D0
      EPL=0.D0
      DROT=0.D0
      ORI=0.D0
      DO I=1,3
        DROT(I,I)=1.D0
      END DO
      CA=COS(ANG*PI/180.D0)
      SA=SIN(ANG*PI/180.D0)
      ORI(1,1)=CA
      ORI(2,1)=SA
      ORI(1,2)=-SA
      ORI(2,2)=CA
      ORI(3,3)=1.D0
      NST=N
      IF (P2 .GT. 0.D0) NST=2*N
      DO IS=1,NST
        IF (IS .LE. N) THEN
          PP=P1*DBLE(IS)/N
          CALL STATE(U1,SY0+HH*PP,PP,NDI,NTENS,STRESS,STRAINEE,DEPV)
          STRAIN(1:NTENS)=DEPV(1:NTENS)+STRAINEE(1:NTENS)
        ELSE
          PP=P1+P2*DBLE(IS-N)/N
          CALL STATE(U2,SY0+HH*PP,PP-P1,NDI,NTENS,STRESS,STRAINEE,DEPV)
          STRAIN(1:NTENS)=EPL(1:NTENS)+DEPV(1:NTENS)+STRAINEE(1:NTENS)
        END IF
        IF (IS .EQ. N) THEN
          CALL STATE(U1,SY0+HH*P1,P1,NDI,NTENS,STRESS,STRAINEE,EPL)
          CALL STATE(U1,SY0+HH*PP,PP,NDI,NTENS,STRESS,STRAINEE,DEPV)
        END IF
        SV0=STATEV
        DO IR=1,2
          STATEV=SV0
          CALL UDMGINI(FINDEX,2,FNORMAL,NDI,NSHR,NTENS,PROPS,8,STATEV,
     1     12,STRESS,STRAIN,STRAINEE,LXFEM,TIME,0.D0,0.D0,0.D0,PREDEF,
     2     DPRED,0,COORDS,1,1,1,1,1,IS,0,0,0.D0,0.D0,0.D0,0.D0,0.D0,
     3     0.D0,JMAC,JMATYP,0,0,1.D0,DROT,ORI)
          IF (IR .EQ. 1) F1=FINDEX(1)
        END DO
        RMAX=MAX(RMAX,ABS(F1-FINDEX(1)))
        IF (MOD(IS,N/5) .EQ. 0) THEN
          WRITE(*,'(A8,1X,F8.5,2(1X,F12.8),2F9.5,3F10.6)') NAME,PP,
     1     FINDEX(1),FINDEX(2),STATEV(NTENS+3),STATEV(NTENS+4),
     2     (FNORMAL(K,1),K=1,NDI)
        END IF
      END DO
      RETURN
      END
