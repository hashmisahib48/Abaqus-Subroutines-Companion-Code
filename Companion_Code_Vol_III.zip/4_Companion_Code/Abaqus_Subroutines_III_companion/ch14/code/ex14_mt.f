      DOUBLE PRECISION FUNCTION K14_EMT(EM,XNUM,EI,XNUI,C)
!     Mori-Tanaka Young's modulus, isotropic matrix, spherical
!     isotropic inclusions of volume fraction C (Eq. 14.7-3)
      INCLUDE 'ABA_PARAM.INC'
      XKM=EM/(3.D0*(1.D0-2.D0*XNUM))
      GM=EM/(2.D0*(1.D0+XNUM))
      XKI=EI/(3.D0*(1.D0-2.D0*XNUI))
      GI=EI/(2.D0*(1.D0+XNUI))
      F=GM*(9.D0*XKM+8.D0*GM)/(6.D0*(XKM+2.D0*GM))
      XK=XKM+C*(XKI-XKM)/(1.D0+(1.D0-C)*(XKI-XKM)/(XKM+4.D0*GM/3.D0))
      G=GM+C*(GI-GM)/(1.D0+(1.D0-C)*(GI-GM)/(GM+F))
      K14_EMT=9.D0*XK*G/(3.D0*XK+G)
      RETURN
      END
