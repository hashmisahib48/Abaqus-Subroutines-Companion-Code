!     Driver: K14_PRIN and K14_INV on random states (file prin_in.txt)
      PROGRAM DRVPRIN
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3),EN(3),V(6)
      OPEN(10,FILE='prin_in.txt')
      DO IT=1,5000
        READ(10,*,END=90) V
        CALL K14_FULL(3,3,V,1.D0,A)
        CALL K14_PRIN(3,A,EN,S1)
        CALL K14_INV(A,ETA,XI,THB,Q)
        WRITE(*,'(10E24.15)') S1,EN,ETA,XI,THB,Q
      END DO
   90 CONTINUE
      END
