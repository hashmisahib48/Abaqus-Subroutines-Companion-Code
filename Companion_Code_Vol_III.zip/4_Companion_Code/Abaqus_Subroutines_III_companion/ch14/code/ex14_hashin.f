      SUBROUTINE UDMGINI(FINDEX,NFINDEX,FNORMAL,NDI,NSHR,NTENS,PROPS,
     1 NPROPS,STATEV,NSTATV,STRESS,STRAIN,STRAINEE,LXFEM,TIME,DTIME,
     2 TEMP,DTEMP,PREDEF,DPRED,NFIELD,COORDS,NOEL,NPT,LAYER,KSPT,
     3 KSTEP,KINC,KDIRCYC,KCYCLELCF,TIMECYC,SSE,SPD,SCD,SVD,SMD,
     4 JMAC,JMATYP,MATLAYO,LACCFLA,CELENT,DROT,ORI)
!     Hashin (1980) indices and fracture-plane normals, 4 mechanisms:
!     1 fibre tension, 2 fibre compression, 3 matrix tension,
!     4 matrix compression. PROPS(1..7) = XT, XC, YT, YC, SL, ST (MPa),
!     ALPHA0 (degrees).  STRESS is in the local (material) axes.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION FINDEX(NFINDEX),FNORMAL(NDI,NFINDEX),PROPS(NPROPS),
     1 STATEV(NSTATV),STRESS(NTENS),STRAIN(NTENS),STRAINEE(NTENS),
     2 TIME(2),PREDEF(NFIELD),DPRED(NFIELD),COORDS(3),DROT(3,3),
     3 ORI(3,3),JMAC(*),JMATYP(*),LXFEM(3)
      DIMENSION S(3,3)
      PARAMETER (PI=3.14159265358979D0)
      IF (NFINDEX .LT. 4 .OR. NPROPS .LT. 7)
     1 CALL K14_ERR('UDMGINI: needs 4 mechanisms and 7 properties')
      XT=PROPS(1)
      XC=PROPS(2)
      YT=PROPS(3)
      YC=PROPS(4)
      SL=PROPS(5)
      ST=PROPS(6)
      CALL K14_FULL(NDI,NSHR,STRESS,1.D0,S)
      SM=S(2,2)+S(3,3)
      TL2=(S(1,2)**2+S(1,3)**2)/SL**2
      TT2=(S(2,3)**2-S(2,2)*S(3,3))/ST**2
      FT=0.D0
      FC=0.D0
      FMT=0.D0
      FMC=0.D0
      IF (S(1,1) .GE. 0.D0) THEN
        FT=(S(1,1)/XT)**2+TL2
      ELSE
        FC=(S(1,1)/XC)**2
      END IF
      IF (SM .GE. 0.D0) THEN
        FMT=SM**2/YT**2+TT2+TL2
      ELSE
        FMC=((YC/(2.D0*ST))**2-1.D0)*SM/YC+SM**2/(4.D0*ST**2)+TT2+TL2
      END IF
      FINDEX(1)=SQRT(MAX(FT,0.D0))
      FINDEX(2)=SQRT(MAX(FC,0.D0))
      FINDEX(3)=SQRT(MAX(FMT,0.D0))
      FINDEX(4)=SQRT(MAX(FMC,0.D0))
!     normals in global axes: columns of ORI are the local axes
      CA=COS(PROPS(7)*PI/180.D0)
      SA=SIN(PROPS(7)*PI/180.D0)
      IF (NSHR .LT. 3) SA=0.D0
      IF (NSHR .LT. 3) CA=1.D0
      DO K=1,NDI
        FNORMAL(K,1)=ORI(K,1)
        FNORMAL(K,2)=ORI(K,1)
        FNORMAL(K,3)=ORI(K,2)
        FNORMAL(K,4)=CA*ORI(K,2)+SA*ORI(K,3)
      END DO
      RETURN
      END
