"""Independent closed forms and post-processing for Chapter 15 (reads the driver output in this folder)."""
import numpy as np, json, re, os
from scipy.integrate import quad
from scipy.optimize import brentq
here=os.path.dirname(os.path.abspath(__file__)); R={}
def rd(f): return open(os.path.join(here,f)).read().splitlines()
# ---------- 1. friction coefficient, Eq. 15.4-1, independent evaluation
PR=dict(mus0=0.40,muk0=0.25,dc=0.05,dsp=-0.002,dkp=-0.001,dst=-2e-4,dkt=-1e-4,T0=20.)
def mu(v,p,T=20.,P=PR):
    ms=P['mus0']+P['dsp']*p+P['dst']*(T-P['T0']); mk=P['muk0']+P['dkp']*p+P['dkt']*(T-P['T0'])
    return mk+(ms-mk)*np.exp(-P['dc']*v)
tab=[l.split() for l in rd('out_coef.txt') if l.startswith('COEF_TAB')]
err=0; 
for t in tab:
    p,v,m,dv,dp,dt=map(float,t[1:7]); err=max(err,abs(m-mu(v,p)))
print('1. mu table: max |driver - python| =%.2e'%err)
print('   mu(p=5,v=0)=%.5f  mu(p=5,v=20)=%.5f  mu(p=5,v=60)=%.5f'%(mu(0,5),mu(20,5),mu(60,5)))
fd=[l for l in rd('out_coef.txt') if l.startswith('COEF_FDERR')][0].split()
print('   FD errors of FRIC_COEF derivatives (v,p,T):',fd[-3:])
R['coef_fd']=[float(x) for x in fd[-3:]]
# ---------- 2. cyclic history, constant mu
mu0,p,Kt=0.3,4.0,300.; tm=mu0*p; w=tm/Kt
TP=[0,0.05,-0.03,0.04,-0.01,0.0]
def play(g,gt):
    """closed form: elastic slope Kt, plateau +-tm (play operator written out piecewise)"""
    return None
# piecewise closed form
def cyc_closed(gs):
    out=[];tau=0.;gcur=0.
    for g in gs:
        pass
# analytic by branches: track state (last reversal point g_r, tau_r) -- loading branch tau = tau_r + Kt (g-g_r), clipped
gs_all=[];
d=np.loadtxt(os.path.join(here,'cyc.dat')); g,tau,sed,D,W=d.T
tc=np.zeros_like(g); gr=0.;tr=0.;
for k in range(len(g)):
    if k>0:
        dirn=np.sign(g[k]-g[k-1])
        if k>1 and dirn!=np.sign(g[k-1]-g[k-2]) and abs(g[k]-g[k-1])>1e-12: gr=g[k-1]; tr=tc[k-1]
    tc[k]=np.clip(tr+Kt*(g[k]-gr),-tm,tm)
print('2. cyclic: max |tau_driver - tau_closed| = %.2e MPa'%np.max(np.abs(tau-tc)))
# closed-form dissipation: slip length of each leg
slip=0.
legs=np.diff(TP)
first=True
Dc=0.
for L,dg in enumerate(legs):
    a=abs(dg)
    lost = w if L==0 else 2*w
    Dc+=tm*max(a-lost,0.)
print('   dissipated: driver %.6f, closed form %.6f N.mm/mm^2'%(D[-1],Dc))
print('   final elastic energy: driver %.6e, closed form %.6e'%(sed[-1],0.5*tm**2/Kt))
print('   work - (SED+D) = %.3e'%(W[-1]-sed[-1]-D[-1]))
R['cyc']=dict(D=D[-1],Dc=Dc,W=W[-1],SED=sed[-1],res=W[-1]-sed[-1]-D[-1],maxerr=float(np.max(np.abs(tau-tc))),tm=tm,w=w)
# ---------- 3. sliding block
m,N,v0=0.5,4905.,60.; pp=N/1000.
ms=mu(0,pp)*0+ (PR['mus0']+PR['dsp']*pp); mk=PR['muk0']+PR['dkp']*pp; dc=PR['dc']; dm=ms-mk
ts=(m/N)/(mk*dc)*np.log((mk*np.exp(dc*v0)+dm)/(mk+dm))
xs=quad(lambda v: v/((N/m)*(mk+dm*np.exp(-dc*v))),0,v0)[0]
# constant-mu comparison
print('3. block: mu_s=%.6f mu_k=%.6f  t_stop=%.7f s  x_stop=%.6f mm'%(ms,mk,ts,xs))
print('   constant mu=mu_k: t=%.6f s, x=%.5f mm; constant mu_s: t=%.6f'%(v0/(mk*N/m),v0**2/(2*mk*N/m),v0/(ms*N/m)))
R['block']=dict(ms=ms,mk=mk,ts=ts,xs=xs,tk=v0/(mk*N/m),tsmu=v0/(ms*N/m),KE0=0.5*m*v0**2)
ex=[l.split() for l in rd('out_vfric.txt') if l.startswith('V_STOP')]
R['expl']=[]
for e in ex:
    ir=int(e[1]); dt=float(e[2]); t=float(e[3]); x=float(e[4]); wk=float(e[5])
    print('   explicit routine %d dt=%.0e: t_stop=%.7f (%.3f%%)  x=%.6f (%.3f%%) work=%.4f'%(ir,dt,t,100*(t/ts-1),x,100*(x/xs-1),wk))
    R['expl'].append(dict(ir=ir,dt=dt,t=t,x=x,work=wk,et=100*(t/ts-1),ex=100*(x/xs-1),s1=float(e[6]),s2=float(e[7])))
im=[l.split() for l in rd('out_fric.txt') if l.startswith('D_STOP')]
kt=[l.split() for l in rd('out_fric.txt') if l.startswith('D_KT')]
R['impl']=[]
for a,b in zip(im,kt):
    dt=float(a[1]); t=float(a[2]); x=float(a[3]); it=int(a[4]); en=float(a[5]); dis=float(a[6]); K=float(b[1])
    print('   implicit FRIC dt=%.1e Kt=%g: t_stop=%.7f (%.3f%%) x=%.6f (%.3f%%) Newton its=%d  E=%.3f  diss=%.3f'%(dt,K,t,100*(t/ts-1),x,100*(x/xs-1),it,en,dis))
    R['impl'].append(dict(dt=dt,Kt=K,t=t,x=x,it=it,E=en,dis=dis,et=100*(t/ts-1),ex=100*(x/xs-1)))
# ---------- 4. stick-slip, closed form with belt speed
mm,k,A,p2,V=0.02,100.,100.,2.,10.; mus,muk=0.5,0.3; Nn=A*p2
om=np.sqrt(k/mm); u0=mus*Nn/k; xeq=muk*Nn/k; Aa=u0-xeq
f=lambda th: -Aa*om*np.sin(th)+V*np.cos(th)-V
th=2*np.pi-2*np.arctan(Aa*om/V)
assert abs(f(th))<1e-9
ts_=th/om; uend=xeq+Aa*np.cos(th)+V/om*np.sin(th)
tstick=(u0-uend)/V; Tper=ts_+tstick
relslip=V*ts_+(u0-uend); Dper=muk*Nn*relslip
umax=max(xeq+Aa*np.cos(t)+V/om*np.sin(t) for t in np.linspace(0,th,4001))
print('4. stick-slip closed form: omega=%.4f rad/s, slip duration %.5f s, stick %.5f s, period %.5f s, u_end=%.5f, u_max=%.5f, dissipation/cycle=%.3f N.mm'%(om,ts_,tstick,Tper,uend,umax,Dper))
Tlow=2*(mus-muk)*Nn/(k*V)+np.pi/om
print('   V->0 formula T=%.5f s'%Tlow)
d=np.loadtxt(os.path.join(here,'ss.dat')); t,u,F,vv,tau_,dist=d.T
# peaks of u (cycle maxima)
pk=[i for i in range(1,len(u)-1) if u[i]>=u[i-1] and u[i]>u[i+1] and u[i]>0.9]
pk=[i for j,i in enumerate(pk) if j==0 or t[i]-t[pk[j-1]]>0.05]
pt=t[pk]; per=np.diff(pt); 
print('   driver: peak times',np.round(pt[:8],4),' periods',np.round(per[:8],5))
cyc_diss=[dist[pk[j+1]]-dist[pk[j]] for j in range(len(pk)-1)]
umins=[min(u[pk[j]:pk[j+1]]) for j in range(len(pk)-1)]
print('   driver: mean period (cycles 2..) %.5f s, u_max %.4f, u_min %.4f (closed form %.4f), dissipation/cycle %.3f'%(np.mean(per[1:]),np.mean(u[pk[1:]]),np.mean(umins[1:]),uend,np.mean(cyc_diss[1:])))
R['ss']=dict(om=om,tslip=ts_,tstick=tstick,T=Tper,uend=uend,umax=umax,D=Dper,Tlow=Tlow,Tnum=float(np.mean(per[1:])),umax_num=float(np.mean(u[pk[1:]])),umin_num=float(np.mean(umins[1:])),D_num=float(np.mean(cyc_diss[1:])),ncyc=len(per))
def peaks(fn):
    d=np.loadtxt(os.path.join(here,fn)); t,u,F,vv,tau_,dist=d.T
    pk=[i for i in range(1,len(u)-1) if u[i]>=u[i-1] and u[i]>u[i+1] and u[i]>0.9]
    pk=[i for j,i in enumerate(pk) if j==0 or t[i]-t[pk[j-1]]>0.05]
    per=np.diff(t[pk]); dis=[dist[pk[j+1]]-dist[pk[j]] for j in range(len(pk)-1)]
    um=[min(u[pk[j]:pk[j+1]]) for j in range(len(pk)-1)]
    return dict(T=float(np.mean(per[1:])),umax=float(np.mean(u[pk[1:]])),umin=float(np.mean(um[1:])),D=float(np.mean(dis[1:])),n=len(per))
R['ss2']=peaks('ss2.dat'); print('   dt=2.5e-4 (half step):',R['ss2'])
def ssclosed(V):
    th=2*np.pi-2*np.arctan(Aa*om/V); ts_=th/om; uend=xeq+Aa*np.cos(th)+V/om*np.sin(th)
    return dict(V=V,T=ts_+(u0-uend)/V,tslip=ts_,uend=uend,D=muk*Nn*(V*ts_+u0-uend))
R['ssV']=[]
for V_,fn in ((5.,'ss_v5.dat'),(10.,'ss.dat'),(20.,'ss_v20.dat')):
    c=ssclosed(V_); n=peaks(fn); c.update(num=n); R['ssV'].append(c)
    print('   V=%g: closed T=%.5f u_end=%.4f D=%.2f | driver T=%.5f u_min=%.4f D=%.2f (%d cycles)'%(V_,c['T'],c['uend'],c['D'],n['T'],n['umin'],n['D'],n['n']))
its=[l.split() for l in rd('out_fric.txt') if l.startswith('E_ITER')][:3]
R['newton']=[dict(var=int(a[1]),tot=int(a[2]),mx=int(a[3]),fail=int(a[4])) for a in its]
print('   Newton:',R['newton'])
# ---------- 5. FD checks of FRIC derivatives
R['fd']=[]
for l in rd('out_fric.txt'):
    if l.startswith('C_ERR'):
        a=l.split(); R['fd'].append(dict(case=int(a[1]),G=float(a[2]),P=float(a[3]),T=float(a[4]),sg=float(a[5]),sp=float(a[6]),asym=float(a[7])))
    if l.startswith('B_ROT'): R['rot']=float(l.split()[1])
    if l.startswith('C_DDTDDG3'): R['G3']=[float(x) for x in l.split()[1:]]
    if l.startswith('C_DDTDDP3'): R['P3']=[float(x) for x in l.split()[1:]]
print('5. FD:',R['fd']); print('   rotation invariance max diff',R['rot'])
json.dump(R,open(os.path.join(here,'results.json'),'w'),indent=1)
