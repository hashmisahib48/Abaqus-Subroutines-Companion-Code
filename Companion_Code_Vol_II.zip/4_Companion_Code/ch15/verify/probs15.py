import numpy as np, json
from scipy.integrate import quad
out={}
# 15A.1
Ff,l,mu,p,Kt0=0.005,2.0,0.3,4.0,None
Kt=mu*p/(Ff*l); print('A1 Kt',Kt, 'elastic slip',Ff*l)
tau=0.0; tau+=Kt*0.004; print(' tau after .004',tau)
tr=tau+Kt*0.02; ds=(tr-mu*p)/Kt; print(' trial',tr,'ds',ds,'SFD',mu*p*ds)
# A2
PR=dict(mus0=0.40,muk0=0.25,dc=0.05,dsp=-0.002,dkp=-0.001)
def mu_(v,p):
    ms=.40-.002*p; mk=.25-.001*p; return mk+(ms-mk)*np.exp(-.05*v)
v,p=20.,10.; m0=mu_(v,p); h=1e-6
dv=(mu_(v+h,p)-mu_(v-h,p))/(2*h); dp=(mu_(v,p+h)-mu_(v,p-h))/(2*h)
print('A2',m0,dv,dp,'taylor',m0+dv*1+dp*0.5,'exact',mu_(21,10.5))
# A3
m,N,v0=0.5,4905.,60.
mk=0.25-0.001*9.81*0.5; 
for mu_c in (0.245095,0.39019):
    print('A3 const',mu_c,v0/(mu_c*N/m),v0**2/(2*mu_c*N/m))
# B1
mu_,p,Kt=0.3,4.,300.; dg=np.array([0.01,0.004]); tr=Kt*dg; trn=np.linalg.norm(tr); n=tr/trn
M=mu_*p*Kt/trn*(np.eye(2)-np.outer(n,n)); print('B1',trn,n,M,np.linalg.eigvalsh(M))
# B3
for dc in (1,4):
    print('B3 dtmin dc',dc, 2*dc*0.2/3000)
# roots of g for dt=1e-4, dc=1
Kt,p=3000.,2.
def g(x,dt,dc,tn): 
    return tn-Kt*x-p*(0.3+0.2*np.exp(-dc*x/dt))
for dt in (1e-4,5e-4):
    xs=np.linspace(0,0.01,2000001); gg=g(xs,dt,1.,1.05); r=np.sum(np.diff(np.sign(gg))!=0); print('roots dt',dt,r)
    gg=g(xs,dt,1.,1.2); print('  tn 1.2 roots',np.sum(np.diff(np.sign(gg))!=0))
# C2 viscous
mu0,c,v0=0.2,2.0,60.; N=4905.
print('C2 t_stop',m/c*np.log(1+c*v0/(mu0*N)), 'x',m/c*(v0-mu0*N/c*np.log(1+c*v0/(mu0*N))))
# discrete sim
dt=1e-5; v=v0; t=0; x=0
while True:
    fs=m*v/dt; fm=mu0*N+c*v; ft=min(fs,fm); vn=v-ft*dt/m
    if vn<=1e-12:
        fr=min(1,fs/fm); print(' sim', t+fr*dt, x+0.5*v*fr*dt); break
    x+=vn*dt; v=vn; t+=dt
# D1
print('D1 kcr example', 'a=0.01,b=0.015,sigma=5,Dc=0.01 mm ->', (0.015-0.01)*5/0.01)
