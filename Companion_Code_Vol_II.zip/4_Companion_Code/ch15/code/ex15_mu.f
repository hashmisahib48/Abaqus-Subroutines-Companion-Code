      SUBROUTINE K15_MU(PR, V, P, T, FMU, DMDV, DMDP, DMDT)
!     Friction coefficient of Eq. (15.4-1) and its partial
!     derivatives.  PR(1) MUS0, PR(2) MUK0 (-), PR(3) DC (s/mm),
!     PR(4) DMSDP, PR(5) DMKDP (1/MPa), PR(6) DMSDT, PR(7) DMKDT
!     (1/degC), PR(8) T0 (degC).  V slip rate (mm/s), P contact
!     pressure (MPa), T temperature (degC).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PR(8)
      PARAMETER (ZERO = 0.0D0)
      FMS = PR(1) + PR(4)*P + PR(6)*(T - PR(8))
      FMK = PR(2) + PR(5)*P + PR(7)*(T - PR(8))
      E = EXP(-PR(3)*V)
      FMU = FMK + (FMS - FMK)*E
      DMDV = -PR(3)*(FMS - FMK)*E
      DMDP = PR(5) + (PR(4) - PR(5))*E
      DMDT = PR(7) + (PR(6) - PR(7))*E
      IF (FMU .LT. ZERO) THEN
!        never return a negative coefficient
         FMU = ZERO
         DMDV = ZERO
         DMDP = ZERO
         DMDT = ZERO
      ENDIF
      RETURN
      END
