      SUBROUTINE FRIC(LM, TAU, DDTDDG, DDTDDP, DSLIP, SED, SFD,
     1 DDTDDT, PNEWDT, STATEV, DGAM, TAULM, PRESS, DPRESS, DDPDDH,
     2 SLIP, KSTEP, KINC, TIME, DTIME, NOEL, CINAME, SECNAME, MAINNAME,
     3 NPT, NODE, NPATCH, COORDS, RCOORD, DROT, TEMP, PREDEF, NFDIR,
     4 MCRD, NPRED, NSTATV, CHRLNGTH, PROPS, NPROPS)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CINAME, SECNAME, MAINNAME
      DIMENSION TAU(NFDIR), DDTDDG(NFDIR,NFDIR), DDTDDP(NFDIR),
     1 DSLIP(NFDIR), DDTDDT(NFDIR,2), STATEV(*), DGAM(NFDIR),
     2 TAULM(NFDIR), SLIP(NFDIR), TIME(2), COORDS(MCRD),
     3 RCOORD(MCRD), DROT(2,2), TEMP(2), PREDEF(2,*), PROPS(NPROPS)
      DIMENSION TR(2), AN(2)
!     PROPS(1:8) as in K15_MU;  PROPS(9) = FKT, interface stiffness
!     in the stick state (MPa/mm);  NFDIR = 1 or 2
      IF (PRESS .LE. 0.0D0) THEN
         LM = 2
         RETURN
      ENDIF
      LM = 0
      FKT = PROPS(9)
      DTM = MAX(DTIME, 1.0D-30)
      TAVG = 0.5D0*(TEMP(1) + TEMP(2))
!     trial state: all of the increment is elastic, Eq. 15.2-2
      TRN = 0.0D0
      DO I = 1, NFDIR
         TR(I) = TAU(I) + FKT*DGAM(I)
         TRN = TRN + TR(I)**2
      ENDDO
      TRN = SQRT(TRN)
      CALL K15_MU(PROPS, 0.0D0, PRESS, TAVG, FMU, DMDV, DMDP, DMDT)
      DLAM = 0.0D0
      DO I = 1, NFDIR
         DSLIP(I) = 0.0D0
         DDTDDP(I) = 0.0D0
         DDTDDT(I,1) = 0.0D0
         DDTDDT(I,2) = 0.0D0
         DO J = 1, NFDIR
            DDTDDG(I,J) = 0.0D0
         ENDDO
      ENDDO
      IF (TRN .LE. PRESS*FMU) THEN
!        elastic stick: the trial state is admissible
         DO I = 1, NFDIR
            TAU(I) = TR(I)
            DDTDDG(I,I) = FKT
         ENDDO
      ELSE
!        slip: scalar equation for the slip increment DLAM, with
!        the slip rate DLAM/DTIME in the coefficient, Eq. 15.2-4
         DLAM = (TRN - PRESS*FMU)/FKT
         DO IT = 1, 25
            CALL K15_MU(PROPS, DLAM/DTM, PRESS, TAVG, FMU, DMDV, DMDP,
     1                  DMDT)
            G = TRN - FKT*DLAM - PRESS*FMU
            DEN = MAX(FKT + PRESS*DMDV/DTM, 0.1D0*FKT)
            DLAM = MAX(DLAM + G/DEN, 0.0D0)
            IF (ABS(G) .LE. 1.0D-11*TRN) GOTO 10
         ENDDO
         PNEWDT = 0.5D0
   10    CALL K15_MU(PROPS, DLAM/DTM, PRESS, TAVG, FMU, DMDV, DMDP,
     1               DMDT)
         AA = PRESS*DMDV/DTM
         FAC = FKT/(FKT + AA)
         DO I = 1, NFDIR
            AN(I) = TR(I)/TRN
            TAU(I) = PRESS*FMU*AN(I)
            DSLIP(I) = DLAM*AN(I)
         ENDDO
!        consistent derivatives, Eq. 15.2-5
         DO I = 1, NFDIR
            DO J = 1, NFDIR
               DEL = 0.0D0
               IF (I .EQ. J) DEL = 1.0D0
               DDTDDG(I,J) = PRESS*FMU*FKT/TRN*(DEL - AN(I)*AN(J))
     1                       + AA*FAC*AN(I)*AN(J)
            ENDDO
            DDTDDP(I) = AN(I)*(FMU + PRESS*DMDP)*FAC
            DDTDDT(I,1) = 0.5D0*AN(I)*PRESS*DMDT*FAC
            DDTDDT(I,2) = DDTDDT(I,1)
         ENDDO
      ENDIF
      SED = 0.0D0
      DO I = 1, NFDIR
         SED = SED + 0.5D0*TAU(I)**2/FKT
      ENDDO
      SFD = PRESS*FMU*DLAM
      IF (NSTATV .GE. 2) THEN
         STATEV(1) = STATEV(1) + DLAM
         STATEV(2) = STATEV(2) + SFD
      ENDIF
      RETURN
      END
