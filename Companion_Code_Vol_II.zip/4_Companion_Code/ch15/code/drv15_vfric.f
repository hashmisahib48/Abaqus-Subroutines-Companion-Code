!     Driver for VFRIC, VFRICTION and VFRIC_COEF (Chapter 15):
!     a block of mass PM slides on a rigid plane and is brought to
!     rest by friction; explicit central-difference update with
!     kinematic contact.
      SUBROUTINE W_VFRIC(PR, DT, DS, FSTICK, FN, AR, STV, FT, KINC)
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PR(9), STV(3), FTAN(1,1), DSL(2,1), FPREV(2,1),
     1 FSTK(1), AREAS(1), FNOR(1), SHP(2,1), CS(2,1), CM(2,2),
     2 DCS(2,1), DCN(2,1), TS(1), PD(1,1), TM(1), PM(1,1), JSU(1),
     3 JMU(2), JCS(1), JCM(2,1), STA(3,1)
      CHARACTER*80 SI, SS, SM
      DSL(1,1) = DS
      DSL(2,1) = 0.0D0
      FPREV(1,1) = 0.0D0
      FPREV(2,1) = 0.0D0
      FSTK(1) = FSTICK
      AREAS(1) = AR
      FNOR(1) = FN
      JSU(1) = 1
      JCS(1) = 1
      DO K = 1, 3
         STA(K,1) = STV(K)
      ENDDO
      TS(1) = 20.0D0
      TM(1) = 20.0D0
      CALL VFRIC(FTAN, STA, 1, KINC, 1, 2, 1, 2, 1, 2, 3, 9, 1, 0, 1,
     1 JSU, JMU, JCS, JCM, 0.0D0, 0.0D0, DT, SI, SS, SM, 1, DSL, FSTK,
     2 FPREV, FNOR, 0.0D0, SHP, CS, CM, DCS, DCN, PR, AREAS, TS, PD,
     3 TM, PM)
      FT = FTAN(1,1)
      DO K = 1, 3
         STV(K) = STA(K,1)
      ENDDO
      RETURN
      END
!
      SUBROUTINE W_VFRICTION(PR, DT, DS, FSTICK, FN, AR, STV, FT, KINC)
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PR(9), STV(3), FTAN(1,1), ST(3,1,1), JFL(3), RD(4),
     1 JCSU(1,1), JCMU(2,1), DSL(2,1), FSTK(1), FPREV(2,1), FNOR(1),
     2 ARC(1), DCN(2,1), DCS(2,1), SHS(1,1), SHM(2,1), CS(2,1,1),
     3 CM(2,2,1), VS(2,1,1), VM(2,2,1), TS(1), TM(1), FS(1,1),
     4 FM(1,1)
      CHARACTER*80 SI, SS, SM
      DSL(1,1) = DS
      DSL(2,1) = 0.0D0
      FPREV(1,1) = 0.0D0
      FPREV(2,1) = 0.0D0
      FSTK(1) = FSTICK
      FNOR(1) = FN
      ARC(1) = AR
      JFL(1) = 1
      JFL(2) = KINC
      JFL(3) = 3
      RD(1) = 0.0D0
      RD(2) = 0.0D0
      RD(3) = DT
      RD(4) = 0.0D0
      DO K = 1, 3
         ST(K,1,1) = STV(K)
      ENDDO
      TS(1) = 20.0D0
      TM(1) = 20.0D0
      CALL VFRICTION(FTAN, ST, 1, 1, 1, 1, 1, 2, 1, 2, 3, 9, 1, 0,
     1 JFL, RD, SI, SS, SM, JCSU, JCMU, PR, DSL, FSTK, FPREV, FNOR,
     2 ARC, DCN, DCS, SHS, SHM, CS, CM, VS, VM, TS, TM, FS, FM)
      FT = FTAN(1,1)
      DO K = 1, 3
         STV(K) = ST(K,1,1)
      ENDDO
      RETURN
      END
!
      PROGRAM DRV15V
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PR(9), STV(3), FC(1,2), FD(1,20,2), SD(1,6), PRS(1),
     1 TA(1), FA(1,1), ID(6), RD(10), DTS(3)
      CHARACTER*80 SI, SS, SM
      DATA PR /0.40D0,0.25D0,0.05D0,-0.002D0,-0.001D0,-2.0D-4,
     1 -1.0D-4,20.0D0,0.0D0/
      DATA DTS /1.0D-3, 1.0D-4, 1.0D-5/
      PM = 0.5D0
      AR = 1000.0D0
      FN = 4905.0D0
      V0 = 60.0D0
      DO IR = 1, 3
         DO IDT = 1, 3
            DT = DTS(IDT)
            U = 0.0D0
            V = V0
            STV(1) = 0.0D0
            STV(2) = 0.0D0
            STV(3) = 0.0D0
            WORK = 0.0D0
            IF (IR .EQ. 1 .AND. IDT .EQ. 3) OPEN(UNIT=12,
     1      FILE='../verify/slide_expl.dat')
            DO N = 1, 2000000
               DS = V*DT
               FSTICK = PM*V/DT
               IF (IR .EQ. 1) THEN
                  CALL W_VFRIC(PR, DT, DS, FSTICK, FN, AR, STV, FT, N)
               ELSE IF (IR .EQ. 2) THEN
                  CALL W_VFRICTION(PR, DT, DS, FSTICK, FN, AR, STV, FT,
     1            N)
               ELSE
                  SD(1,1) = DS/DT
                  PRS(1) = FN/AR
                  TA(1) = 20.0D0
                  CALL VFRIC_COEF(FC, FD, 1, 9, 1, 0, ID, RD, SI, SS,
     1            SM, PR, SD, PRS, TA, FA)
                  FT = MIN(FSTICK, FC(1,1)*FN)
               ENDIF
               VN = V - FT*DT/PM
               WORK = WORK + FT*0.5D0*(V + VN)*DT
               IF (IR .EQ. 1 .AND. IDT .EQ. 3 .AND. MOD(N,20) .EQ. 0)
     1         WRITE(12,'(3E16.8)') (N - 1)*DT, V, U
               IF (VN .LE. 1.0D-12) THEN
                  FR = FSTICK/(FC_MAX(PR, V, FN, AR))
                  TS = (N - 1)*DT + MIN(1.0D0, FR)*DT
                  US = U + 0.5D0*V*MIN(1.0D0, FR)*DT
                  WRITE(6,'(A,I2,E10.3,5E20.12)') 'V_STOP ', IR,
     1            DT, TS, US, WORK, STV(1), STV(2)
                  GOTO 10
               ENDIF
               U = U + VN*DT
               V = VN
            ENDDO
   10       CONTINUE
            IF (IR .EQ. 1 .AND. IDT .EQ. 3) CLOSE(12)
         ENDDO
      ENDDO
      WRITE(6,'(A,E20.12)') 'V_KE0 ', 0.5D0*PM*V0**2
      END
!
      FUNCTION FC_MAX(PR, V, FN, AR)
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PR(9)
      CALL K15_MU(PR, V, FN/AR, 20.0D0, FMU, D1, D2, D3)
      FC_MAX = FMU*FN
      RETURN
      END
