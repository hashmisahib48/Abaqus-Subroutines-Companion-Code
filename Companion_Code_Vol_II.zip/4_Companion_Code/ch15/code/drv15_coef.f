!     Driver for FRIC_COEF (Chapter 15): the coefficient of Eq. 15.4-1
!     and its derivatives, called through the Abaqus interface.
      PROGRAM DRV15C
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PR(8), FC(1,2), FD(1,20,2), SD(1,6), PRS(1), TA(1),
     1 FA(1,1), ID(6), RD(10), FC1(1,2), FC2(1,2), PS(4), VT(4)
      CHARACTER*80 SI, SS, SM
      DATA PR /0.40D0,0.25D0,0.05D0,-0.002D0,-0.001D0,-2.0D-4,
     1 -1.0D-4,20.0D0/
      DATA PS /1.0D0, 5.0D0, 10.0D0, 20.0D0/
      DATA VT /0.0D0, 10.0D0, 20.0D0, 60.0D0/
      EMAXV = 0.0D0
      EMAXP = 0.0D0
      EMAXT = 0.0D0
      OPEN(UNIT=11, FILE='../verify/mu_curve.dat')
      DO IP = 1, 4
         DO IV = 0, 120
            VV = IV*0.5D0
            SD(1,1) = VV
            PRS(1) = PS(IP)
            TA(1) = 20.0D0
            CALL FRIC_COEF(FC, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM, PR,
     1      SD, PRS, TA, FA)
            HV = 1.0D-5
            SD(1,1) = VV + HV
            CALL FRIC_COEF(FC1, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM,
     1      PR, SD, PRS, TA, FA)
            SD(1,1) = VV
            CALL FRIC_COEF(FC, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM, PR,
     1      SD, PRS, TA, FA)
            SD(1,1) = VV - HV
            CALL FRIC_COEF(FC2, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM,
     1      PR, SD, PRS, TA, FA)
            SD(1,1) = VV
            CALL FRIC_COEF(FC, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM, PR,
     1      SD, PRS, TA, FA)
            DV = FD(1,1,1)
            EMAXV = MAX(EMAXV, ABS(DV - (FC1(1,1) - FC2(1,1))/(2*HV)))
            HP = 1.0D-5
            PRS(1) = PS(IP) + HP
            CALL FRIC_COEF(FC1, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM,
     1      PR, SD, PRS, TA, FA)
            PRS(1) = PS(IP) - HP
            CALL FRIC_COEF(FC2, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM,
     1      PR, SD, PRS, TA, FA)
            PRS(1) = PS(IP)
            CALL FRIC_COEF(FC, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM, PR,
     1      SD, PRS, TA, FA)
            EMAXP = MAX(EMAXP, ABS(FD(1,2,1) -
     1      (FC1(1,1) - FC2(1,1))/(2*HP)))
            HT = 1.0D-3
            TA(1) = 20.0D0 + HT
            CALL FRIC_COEF(FC1, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM,
     1      PR, SD, PRS, TA, FA)
            TA(1) = 20.0D0 - HT
            CALL FRIC_COEF(FC2, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM,
     1      PR, SD, PRS, TA, FA)
            TA(1) = 20.0D0
            CALL FRIC_COEF(FC, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM, PR,
     1      SD, PRS, TA, FA)
            EMAXT = MAX(EMAXT, ABS(FD(1,3,1) -
     1      (FC1(1,1) - FC2(1,1))/(2*HT)))
            WRITE(11,'(I2,5E16.8)') IP, VV, PS(IP), FC(1,1), FD(1,1,1),
     1      FD(1,2,1)
         ENDDO
      ENDDO
      CLOSE(11)
      WRITE(6,'(A,3E12.4)') 'COEF_FDERR (v,p,T) ', EMAXV, EMAXP, EMAXT
!     table of values for the book
      DO IP = 1, 4
         DO IV = 1, 4
            VV = VT(IV)
            SD(1,1) = VV
            PRS(1) = PS(IP)
            TA(1) = 20.0D0
            CALL FRIC_COEF(FC, FD, 1, 8, 1, 0, ID, RD, SI, SS, SM, PR,
     1      SD, PRS, TA, FA)
            WRITE(6,'(A,2F8.2,4E16.8)') 'COEF_TAB ', PS(IP), VV,
     1      FC(1,1), FD(1,1,1), FD(1,2,1), FD(1,3,1)
         ENDDO
      ENDDO
      END
