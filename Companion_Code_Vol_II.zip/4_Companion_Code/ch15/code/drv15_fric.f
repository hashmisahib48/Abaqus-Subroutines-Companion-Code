!     Driver for FRIC (Chapter 15): replays slip histories as Abaqus
!     would, one increment at a time, and checks derivatives.
      SUBROUTINE D_FRIC(NF, PR, TAUN, DG, P, DT, TV, TAUO, DTG, DTP,
     1 DTT, DSL, SED, SFD, ST, LM)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PR(9), TAUN(2), DG(2), TV(2), TAUO(2), DTG(2,2),
     1 DTP(2), DTT(2,2), DSL(2), ST(2)
      DIMENSION TAU(2), TAULM(2), SLIP(2), TIME(2), COORDS(2),
     1 RCOORD(2), DROT(2,2), PREDEF(2,1), DGAM(2), STV(2)
      CHARACTER*80 CINAME, SECNAME, MAINNAME
      DO I = 1, 2
         TAU(I) = TAUN(I)
         DGAM(I) = DG(I)
         STV(I) = ST(I)
         TAULM(I) = 0.0D0
         SLIP(I) = 0.0D0
         DO J = 1, 2
            DTG(I,J) = 0.0D0
            DTT(I,J) = 0.0D0
         ENDDO
      ENDDO
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      LM = 0
      PNEWDT = 1.0D0
      CALL FRIC(LM, TAU, DTG, DTP, DSL, SED, SFD, DTT, PNEWDT, STV,
     1 DGAM, TAULM, P, 0.0D0, 0.0D0, SLIP, 1, 1, TIME, DT, 0, CINAME,
     2 SECNAME, MAINNAME, 0, 0, 0, COORDS, RCOORD, DROT, TV, PREDEF, NF,
     3 2, 0, 2, 1.0D0, PR, 9)
      IF (NF .EQ. 1) THEN
!        FRIC stores DDTDDT(NFDIR,2) contiguously
         DTT(1,2) = DTT(2,1)
         DTT(2,1) = 0.0D0
      ENDIF
      DO I = 1, 2
         TAUO(I) = TAU(I)
         ST(I) = STV(I)
      ENDDO
      RETURN
      END
!
      PROGRAM DRV15F
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PRC(9), PRR(9), PRB(9)
      DATA PRC /0.3D0,0.3D0,0.0D0,0.0D0,0.0D0,0.0D0,0.0D0,20.0D0,
     1 300.0D0/
      DATA PRR /0.40D0,0.25D0,0.05D0,-0.002D0,-0.001D0,-2.0D-4,
     1 -1.0D-4,20.0D0,300.0D0/
      DATA PRB /0.5D0,0.3D0,1.0D0,0.0D0,0.0D0,0.0D0,0.0D0,20.0D0,
     1 3000.0D0/
      CALL CASEA(PRC)
      CALL CASEB(PRC)
      CALL CASEC(PRR)
      CALL CASED(PRR)
      CALL CASEE(PRB)
      END
!
!     ---- A: cyclic slip history, constant mu (Example 15.5-1)
      SUBROUTINE CASEA(PR)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PR(9), TAU(2), TO(2), DG(2), TV(2), DTG(2,2), DTP(2),
     1 DTT(2,2), DSL(2), ST(2), TP(6)
      DATA TP /0.0D0, 0.05D0, -0.03D0, 0.04D0, -0.01D0, 0.0D0/
      P = 4.0D0
      TV(1) = 20.0D0
      TV(2) = 20.0D0
      ST(1) = 0.0D0
      ST(2) = 0.0D0
      TAU(1) = 0.0D0
      TAU(2) = 0.0D0
      G = 0.0D0
      W = 0.0D0
      SE = 0.0D0
      D = 0.0D0
      NI = 100
      OPEN(UNIT=11, FILE='../verify/cyc.dat')
      WRITE(11,'(5E16.8)') G, TAU(1), 0.0D0, 0.0D0, 0.0D0
      DO L = 1, 5
         DGI = (TP(L+1) - TP(L))/NI
         DO IK = 1, NI
            DG(1) = DGI
            DG(2) = 0.0D0
            CALL D_FRIC(1, PR, TAU, DG, P, 1.0D0, TV, TO, DTG, DTP,
     1      DTT, DSL, SED, SFD, ST, LM)
            W = W + 0.5D0*(TAU(1) + TO(1))*DGI
            TAU(1) = TO(1)
            G = G + DGI
            D = D + SFD
            SE = SED
            WRITE(11,'(5E16.8)') G, TAU(1), SE, D, W
         ENDDO
      ENDDO
      CLOSE(11)
      WRITE(6,'(A,5E20.12)') 'A_END G TAU SED D W ', G, TAU(1), SE,
     1 D, W
      WRITE(6,'(A,2E20.12)') 'A_STATEV ', ST(1), ST(2)
      RETURN
      END
!
!     ---- B: invariance under rotation of the slip direction
      SUBROUTINE CASEB(PR)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PR(9), TA(2), TB(2), TO(2), DG(2), TV(2), DTG(2,2),
     1 DTP(2), DTT(2,2), DSL(2), ST(2), TP(6), SA(2), SB(2)
      DATA TP /0.0D0, 0.05D0, -0.03D0, 0.04D0, -0.01D0, 0.0D0/
      P = 4.0D0
      TV(1) = 20.0D0
      TV(2) = 20.0D0
      TH = 37.0D0*ATAN(1.0D0)/45.0D0
      CT = COS(TH)
      ST1 = SIN(TH)
      TA(1) = 0.0D0
      TA(2) = 0.0D0
      TB(1) = 0.0D0
      TB(2) = 0.0D0
      SA(1) = 0.0D0
      SA(2) = 0.0D0
      SB(1) = 0.0D0
      SB(2) = 0.0D0
      EMAX = 0.0D0
      DO L = 1, 5
         DGI = (TP(L+1) - TP(L))/100
         DO IK = 1, 100
            DG(1) = DGI
            DG(2) = 0.0D0
            CALL D_FRIC(1, PR, TA, DG, P, 1.0D0, TV, TO, DTG, DTP,
     1      DTT, DSL, SED, SFD, SA, LM)
            TA(1) = TO(1)
            DG(1) = CT*DGI
            DG(2) = ST1*DGI
            CALL D_FRIC(2, PR, TB, DG, P, 1.0D0, TV, TO, DTG, DTP,
     1      DTT, DSL, SED, SFD, SB, LM)
            TB(1) = TO(1)
            TB(2) = TO(2)
            E1 = ABS(TB(1) - CT*TA(1))
            E2 = ABS(TB(2) - ST1*TA(1))
            EMAX = MAX(EMAX, E1, E2)
         ENDDO
      ENDDO
      WRITE(6,'(A,E12.4)') 'B_ROT_MAXDIFF ', EMAX
      RETURN
      END
!
!     ---- C: finite-difference check of the derivatives
      SUBROUTINE CASEC(PR)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PR(9), TAU(2), DG(2), TV(2), TO(2), DTG(2,2), DTP(2),
     1 DTT(2,2), DSL(2), ST(2), T1(2), T2(2), DG1(2), TV1(2),
     2 FD(2,2), FDP(2), FDT(2,2)
      DIMENSION TAUS(2,3), DGS(2,3), TVS(2,3), PS(3), NFS(3)
      DATA TAUS /0.3D0,0.1D0, 1.5D0,0.0D0, 1.2D0,0.5D0/
      DATA DGS /1.0D-4,-2.0D-4, 0.02D0,0.0D0, 0.01D0,0.004D0/
      DATA TVS /20.0D0,20.0D0, 20.0D0,20.0D0, 60.0D0,35.0D0/
      DATA PS /4.905D0, 4.905D0, 4.905D0/
      DATA NFS /2, 1, 2/
      DT = 1.0D-3
      H = 1.0D-7
      DO IC = 1, 3
         NF = NFS(IC)
         ST(1) = 0.0D0
         ST(2) = 0.0D0
         DO I = 1, 2
            TAU(I) = TAUS(I,IC)
            DG(I) = DGS(I,IC)
            TV(I) = TVS(I,IC)
         ENDDO
         P = PS(IC)
         CALL D_FRIC(NF, PR, TAU, DG, P, DT, TV, TO, DTG, DTP, DTT,
     1   DSL, SED, SFD, ST, LM)
         DO J = 1, NF
            DO I = 1, 2
               DG1(I) = DG(I)
            ENDDO
            DG1(J) = DG(J) + H
            ST(1) = 0.0D0
            CALL D_FRIC(NF, PR, TAU, DG1, P, DT, TV, T1, DTG, DTP,
     1      DTT, DSL, SED, SFD, ST, LM)
            DG1(J) = DG(J) - H
            CALL D_FRIC(NF, PR, TAU, DG1, P, DT, TV, T2, DTG, DTP,
     1      DTT, DSL, SED, SFD, ST, LM)
            DO I = 1, NF
               FD(I,J) = (T1(I) - T2(I))/(2.0D0*H)
            ENDDO
         ENDDO
         HP = 1.0D-6
         CALL D_FRIC(NF, PR, TAU, DG, P+HP, DT, TV, T1, DTG, DTP,
     1   DTT, DSL, SED, SFD, ST, LM)
         CALL D_FRIC(NF, PR, TAU, DG, P-HP, DT, TV, T2, DTG, DTP,
     1   DTT, DSL, SED, SFD, ST, LM)
         DO I = 1, NF
            FDP(I) = (T1(I) - T2(I))/(2.0D0*HP)
         ENDDO
         DO K = 1, 2
            TV1(1) = TV(1)
            TV1(2) = TV(2)
            TV1(K) = TV(K) + 1.0D-3
            CALL D_FRIC(NF, PR, TAU, DG, P, DT, TV1, T1, DTG, DTP,
     1      DTT, DSL, SED, SFD, ST, LM)
            TV1(K) = TV(K) - 1.0D-3
            CALL D_FRIC(NF, PR, TAU, DG, P, DT, TV1, T2, DTG, DTP,
     1      DTT, DSL, SED, SFD, ST, LM)
            DO I = 1, NF
               FDT(I,K) = (T1(I) - T2(I))/2.0D-3
            ENDDO
         ENDDO
!        analytic derivatives at the base point (call again)
         ST(1) = 0.0D0
         CALL D_FRIC(NF, PR, TAU, DG, P, DT, TV, TO, DTG, DTP, DTT,
     1   DSL, SED, SFD, ST, LM)
         EG = 0.0D0
         SG = 0.0D0
         EP = 0.0D0
         SP = 0.0D0
         ET = 0.0D0
         ST2 = 0.0D0
         DO I = 1, NF
            EP = MAX(EP, ABS(DTP(I) - FDP(I)))
            SP = MAX(SP, ABS(FDP(I)))
            DO J = 1, NF
               EG = MAX(EG, ABS(DTG(I,J) - FD(I,J)))
               SG = MAX(SG, ABS(FD(I,J)))
            ENDDO
            DO K = 1, 2
               ET = MAX(ET, ABS(DTT(I,K) - FDT(I,K)))
               ST2 = MAX(ST2, ABS(FDT(I,K)))
            ENDDO
         ENDDO
         ASYM = 0.0D0
         IF (NF .EQ. 2) ASYM = ABS(DTG(1,2) - DTG(2,1))
         WRITE(6,'(A,I2,3E14.6)') 'C_CASE ', IC, TO(1), TO(2), SFD
         WRITE(6,'(A,I2,6E14.6)') 'C_ERR  ', IC, EG/SG, EP/MAX(SP,
     1   1.0D-30), ET/MAX(ST2,1.0D-30), SG, SP, ASYM
         IF (IC .EQ. 3) THEN
            WRITE(6,'(A,4E16.8)') 'C_DDTDDG3 ', DTG(1,1), DTG(1,2),
     1      DTG(2,1), DTG(2,2)
            WRITE(6,'(A,4E16.8)') 'C_FDG3    ', FD(1,1), FD(1,2),
     1      FD(2,1), FD(2,2)
            WRITE(6,'(A,2E16.8)') 'C_DDTDDP3 ', DTP(1), DTP(2)
         ENDIF
         IF (IC .EQ. 2) WRITE(6,'(A,2E16.8)') 'C_G2 ', DTG(1,1),
     1   FD(1,1)
      ENDDO
      RETURN
      END
!
!     ---- D: block sliding to a stop under FRIC, Newmark (Ex. 15.5-2)
      SUBROUTINE CASED(PR)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PR(9), TAU(2), TO(2), DG(2), TV(2), DTG(2,2), DTP(2),
     1 DTT(2,2), DSL(2), ST(2), STT(2), DTS(5), AKS(5)
      DATA DTS /4.0D-4, 1.0D-4, 2.5D-5, 1.0D-4, 1.0D-4/
      DATA AKS /3000.0D0, 3000.0D0, 3000.0D0, 300.0D0, 30.0D0/
      PM = 0.5D0
      AR = 1000.0D0
      FN = 4905.0D0
      P = FN/AR
      V0 = 60.0D0
      TV(1) = 20.0D0
      TV(2) = 20.0D0
      DO IDT = 1, 5
         DT = DTS(IDT)
         PR(9) = AKS(IDT)
         U = 0.0D0
         V = V0
         CALL K15_MU(PR, V0, P, 20.0D0, FMU, DM1, DM2, DM3)
         A = -FMU*FN/PM
         TAU(1) = 0.0D0
         TAU(2) = 0.0D0
         ST(1) = 0.0D0
         ST(2) = 0.0D0
         T = 0.0D0
         DIS = 0.0D0
         NIT = 0
         IF (IDT .EQ. 2) OPEN(UNIT=12, FILE='../verify/slide_impl.dat')
         DO IS = 1, 100000
            U1 = U + DT*V + 0.5D0*DT*DT*A
            DO IT = 1, 50
               DG(1) = U1 - U
               DG(2) = 0.0D0
               STT(1) = ST(1)
               STT(2) = ST(2)
               CALL D_FRIC(1, PR, TAU, DG, P, DT, TV, TO, DTG, DTP,
     1         DTT, DSL, SED, SFD, STT, LM)
               A1 = 4.0D0/DT**2*(U1 - U - DT*V) - A
               R = PM*A1 + AR*TO(1)
               NIT = NIT + 1
               IF (ABS(R) .LT. 1.0D-8*(PM*ABS(A1) + AR*ABS(TO(1)))) GOTO 10
               U1 = U1 - R/(4.0D0*PM/DT**2 + AR*DTG(1,1))
            ENDDO
            WRITE(6,*) 'D no convergence'
   10       V1 = V + 0.5D0*DT*(A + A1)
            DIS = DIS + AR*SFD
            EN = 0.5D0*PM*V1**2 + AR*SED + DIS
            IF (IDT .EQ. 2) WRITE(12,'(6E16.8)') T + DT, U1, V1, 
     1      TO(1), EN, DIS
            IF (V1 .LE. 0.0D0) THEN
               FR = V/(V - V1)
               TS = T + FR*DT
               US = U + FR*(U1 - U)
               WRITE(6,'(A,E10.3,2E20.12,I8,2E20.12)') 'D_STOP ', DT,
     1         TS, US, NIT, EN, DIS
               WRITE(6,'(A,E10.3)') 'D_KT ', PR(9)
               GOTO 20
            ENDIF
            TAU(1) = TO(1)
            ST(1) = STT(1)
            ST(2) = STT(2)
            U = U1
            V = V1
            A = A1
            T = T + DT
         ENDDO
   20    CONTINUE
         IF (IDT .EQ. 2) CLOSE(12)
      ENDDO
      WRITE(6,'(A,E20.12)') 'D_KE0 ', 0.5D0*PM*V0**2
      RETURN
      END
!
!     ---- E: stick-slip of a spring-restrained block on a belt
      SUBROUTINE CASEE(PR)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PR(9)
      COMMON /SSP/ DTSS, BVSS, NSTSS
      CHARACTER*40 FSS
      COMMON /SSC/ FSS
      DIMENSION PR2(9)
      DTSS = 5.0D-4
      BVSS = 10.0D0
      NSTSS = 3000
      NS = 0
      CALL SSRUN(PR, 1, 0, NS2)
      WRITE(6,*) 'E_LOGSTEP ', NS2
      CALL SSRUN(PR, 1, 1, NS)
      CALL SSRUN(PR, 2, NS2, NS)
      CALL SSRUN(PR, 3, NS2, NS)
      DO I = 1, 9
         PR2(I) = PR(I)
      ENDDO
      PR2(3) = 1.0D0
      DTSS = 2.5D-4
      NSTSS = 6000
      FSS = '../verify/ss2.dat'
      CALL SSRUN(PR2, 1, -1, NS)
      DTSS = 5.0D-4
      NSTSS = 3000
      BVSS = 5.0D0
      FSS = '../verify/ss_v5.dat'
      CALL SSRUN(PR2, 1, -1, NS)
      BVSS = 20.0D0
      FSS = '../verify/ss_v20.dat'
      CALL SSRUN(PR2, 1, -1, NS)
      RETURN
      END
!
      SUBROUTINE SSRUN(PR, IVAR, LOGSTEP, NSLOG)
      IMPLICIT REAL*8 (A-H,O-Z)
      COMMON /SSP/ DTSS, BVSS, NSTSS
      CHARACTER*40 FSS
      COMMON /SSC/ FSS
      DIMENSION PR(9), TAU(2), TO(2), DG(2), TV(2), DTG(2,2), DTP(2),
     1 DTT(2,2), DSL(2), ST(2), STT(2), ONS(40), DISC(40)
      LOGICAL SLIPPING
      ALPH = -0.05D0
      BETA = 0.25D0*(1.0D0 - ALPH)**2
      GAMM = 0.5D0 - ALPH
      PM = 0.02D0
      PK = 100.0D0
      AR = 100.0D0
      P = 2.0D0
      BV = BVSS
      DT = DTSS
      NSTEP = NSTSS
      TV(1) = 20.0D0
      TV(2) = 20.0D0
      U = 0.0D0
      V = BV
      A = 0.0D0
      TAU(1) = 0.0D0
      TAU(2) = 0.0D0
      ST(1) = 0.0D0
      ST(2) = 0.0D0
      SLIPPING = .FALSE.
      NON = 0
      NITT = 0
      NITM = 0
      NFAIL = 0
      NIMAX = 0
      ISMAX = 0
      DIST = 0.0D0
      UMIN = 1.0D9
      DISS = 0.0D0
      IF (IVAR .EQ. 1 .AND. LOGSTEP .GT. 0) OPEN(UNIT=13,
     1 FILE='../verify/ss.dat')
      IF (LOGSTEP .LT. 0) OPEN(UNIT=13, FILE=FSS)
      IF (LOGSTEP .GT. 0) OPEN(UNIT=14, FILE='../verify/res_hist.dat',
     1 ACCESS='APPEND')
      DO IS = 1, NSTEP
         T = (IS - 1)*DT
         U1 = U + DT*V + 0.5D0*DT*DT*A
         NI = 0
         DO IT = 1, 60
            DG(1) = U1 - U - BV*DT
            DG(2) = 0.0D0
            STT(1) = ST(1)
            STT(2) = ST(2)
            CALL D_FRIC(1, PR, TAU, DG, P, DT, TV, TO, DTG, DTP, DTT,
     1      DSL, SED, SFD, STT, LM)
            A1 = (U1 - U - DT*V - (0.5D0 - BETA)*DT*DT*A)/
     1           (BETA*DT*DT)
            R = PM*A1 + (1.0D0 + ALPH)*(PK*U1 + AR*TO(1))
     1          - ALPH*(PK*U + AR*TAU(1))
            IF (IS .EQ. LOGSTEP .AND. IVAR .LE. 3) WRITE(14,
     1      '(I2,I4,E16.8)') IVAR, NI, ABS(R)
            IF (ABS(R) .LT. 1.0D-7) GOTO 10
            NI = NI + 1
         FT = AR*DTG(1,1)
            IF (IVAR .EQ. 2) FT = AR*PR(9)
            IF (IVAR .EQ. 3) FT = 0.0D0
            U1 = U1 - R/(PM/(BETA*DT*DT) + (1.0D0 + ALPH)*(PK + FT))
         ENDDO
         NFAIL = NFAIL + 1
   10    NITT = NITT + NI
         NITM = MAX(NITM, NI)
         IF (NI .GT. NIMAX .AND. T .GT. 0.05D0) THEN
            NIMAX = NI
            ISMAX = IS
         ENDIF
         V1 = V + DT*((1.0D0 - GAMM)*A + GAMM*A1)
         IF (SFD .GT. 0.0D0) THEN
            IF (.NOT. SLIPPING .AND. NON .LT. 40) THEN
               NON = NON + 1
               ONS(NON) = T + DT
               IF (NON .GT. 1) DISC(NON-1) = DISS
               DISS = 0.0D0
            ENDIF
            SLIPPING = .TRUE.
            DISS = DISS + AR*SFD
         ENDIF
         DIST = DIST + AR*SFD
         IF (SFD .GT. 0.0D0) THEN
         ELSE
            SLIPPING = .FALSE.
         ENDIF
         IF (T .GT. 0.4D0) UMIN = MIN(UMIN, U1)
         TAU(1) = TO(1)
         ST(1) = STT(1)
         ST(2) = STT(2)
         IF (IVAR .EQ. 1 .AND. LOGSTEP .NE. 0) WRITE(13,'(6E16.8)')
     1   T + DT, U1, PK*U1, V1, TO(1), DIST
         U = U1
         V = V1
         A = A1
      ENDDO
      IF (LOGSTEP .GT. 0) CLOSE(14)
      IF (IVAR .EQ. 1 .AND. LOGSTEP .NE. 0) CLOSE(13)
      IF (LOGSTEP .EQ. 0) THEN
         NSLOG = NINT(ONS(1)/DT)
         RETURN
      ENDIF
      WRITE(6,'(A,I2,3I8)') 'E_ITER ', IVAR, NITT, NITM, NFAIL
      IF (IVAR .EQ. 1) THEN
         WRITE(6,'(A,I4)') 'E_NONSETS ', NON
         WRITE(6,'(A,12F10.5)') 'E_ONSETS ', (ONS(K), K=1,MIN(NON,12))
         WRITE(6,'(A,12F10.4)') 'E_DISS ', (DISC(K), K=1,MIN(NON-1,12))
         WRITE(6,'(A,E16.8)') 'E_UMIN ', UMIN
      ENDIF
      RETURN
      END
