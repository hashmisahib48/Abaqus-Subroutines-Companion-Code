#!/bin/sh
# Compile every listing of Chapter 15 and run the drivers (gfortran, no Abaqus involved).
cd /home/claude/vol2/ch15/code || exit 1
INC=-I/home/claude/vol2/lib/aba
FL="-ffixed-form -ffixed-line-length-none -std=legacy $INC"
for f in prob_15b2_bug ex15_mu ex15_fric_coef ex15_fric ex15_vfric ex15_vfriction ex15_vfric_coef; do gfortran -c $FL $f.f -o /tmp/$f.o || exit 1; done
rm -f ../verify/res_hist.dat
gfortran $FL drv15_coef.f ex15_mu.f ex15_fric_coef.f -o /tmp/d15c && /tmp/d15c > ../verify/out_coef.txt
gfortran $FL drv15_fric.f ex15_fric.f ex15_mu.f -o /tmp/d15f && /tmp/d15f > ../verify/out_fric.txt
gfortran $FL drv15_vfric.f ex15_vfric.f ex15_vfriction.f ex15_vfric_coef.f ex15_mu.f -o /tmp/d15v && /tmp/d15v > ../verify/out_vfric.txt
python3 ../verify/check15.py > ../verify/out_check.txt
echo done
