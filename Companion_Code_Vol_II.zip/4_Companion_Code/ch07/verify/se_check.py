import numpy as np, json
EA,EM,EL,SLS,SLE,SUS,SUE,SY0,HH=60000.,40000.,0.05,520.,600.,300.,200.,600.,4000.
EPSS,GL,GU=0.01,0.70,0.50
g=lambda G,x: G+(1-G)*np.exp(-x/EPSS)
pk=[0.09,0.10,0.11]
ep=[0.0]+[(p-EL-SY0/EM)/(1+HH/EM) for p in pk]
print('ep closed',ep)
ev={}
for l in open('out_se.txt'):
    t=l.split()
    if t[0]=='EVT': ev[(t[1],int(t[2]),t[3])]=[float(x) for x in t[4:]]
rows=[]
for tag,gl,gu in (('MOD',lambda x:g(GL,x),lambda x:g(GU,x)),('REF',lambda x:1,lambda x:1)):
    for c in (1,2,3):
        e0,e1=ep[c-1],ep[c]
        cf={'FS':(e0+gl(e0)*SLS/EA,gl(e0)*SLS),'FE':(e0+EL+gl(e0)*SLE/EM,gl(e0)*SLE),
            'RS':(e1+EL+gu(e1)*SUS/EM,gu(e1)*SUS),'RE':(e1+gu(e1)*SUE/EA,gu(e1)*SUE),'ZS':(e1,0.0)}
        for k,(se,ss) in cf.items():
            d=ev[(tag,c,k)]
            rows.append((tag,c,k,se,d[0],ss,d[1] if k!='ZS' else 0.0))
            print(tag,c,k,'closed eps %.6f stress %.3f | driver eps %.6f stress %.3f | d_eps %.1e'%(se,ss,d[0],(d[1] if k!='ZS' else 0.),d[0]-se))
json.dump(rows,open('se_rows.json','w'))
# work per cycle
for tag in ('MOD','REF'):
    print(tag,[ev[(tag,c,'ZS')][2] for c in (1,2,3)])
# g values
for x in (0,0.005,0.025/1.1,0.1):
    print('x=%.6f gL=%.6f gU=%.6f SsAS=%.4f SfAS=%.4f SsSA=%.4f SfSA=%.4f'%(x,g(GL,x),g(GU,x),g(GL,x)*520,g(GL,x)*600,g(GU,x)*300,g(GU,x)*200))
