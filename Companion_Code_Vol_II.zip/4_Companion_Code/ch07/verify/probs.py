import numpy as np, json, sys
sys.path.insert(0,'.')
E0=70000.;nu=0.33;er=0.005
exec(open('hyp_check.py').read().split('res={}')[0])   # reuse functions (D0, inv, eqs, Etan, integW)
out={}
# A.1
e=np.array([0.012,-0.004,-0.003,0.010,0,0])
I1,I2,epe=inv(e); q=eqs(e); out['A1']=dict(I1=I1,I2=I2,epe=epe,eq=q,E=E0/(1+q/er)**2, I2usual=-I2)
print('A1',out['A1'])
# A.2
g=lambda G,x: G+(1-G)*np.exp(-x/0.01)
x=0.008; gl=g(0.7,x); gu=g(0.5,x)
out['A2']=dict(gl=gl,gu=gu,v=[520*gl,600*gl,300*gu,200*gu]); print('A2',out['A2'])
# B.1 loop a=0.01,b=0.02
for a,b in ((0.01,0.02),):
    s,W=integW([[0]*6,[a,0,0,0,0,0],[a,0,0,b,0,0],[0,0,0,b,0,0],[0]*6],nsub=200)
    out['B1']=dict(W=W,s=s.tolist()); print('B1',W,s)
    s,W=integW([[0]*6,[a,0,0,0,0,0],[a,0,0,b,0,0],[0,0,0,b,0,0],[0]*6],nsub=100)
    print('B1 check',W)
# B.3 truss vs 3D
a=0.02; print('truss',E0*a/(1+a/er),'3D',E0*a/(1+0.886666666*a/er), 'ratio',(E0*a/(1+0.886666666*a/er))/(E0*a/(1+a/er)))
# C.1 table law: tangent E vs eq strain; uniaxial sigma at eps 0.01 (3D, eq=c eps)
tab=[(0,70000.),(0.002,60000.),(0.005,35000.),(0.01,12000.),(0.05,2000.)]
c=0.8866666666666666
def Et(q): return np.interp(q,[t[0] for t in tab],[t[1] for t in tab])
from scipy.integrate import quad
for eps in (0.004,0.01):
    val=quad(lambda s: Et(c*s),0,eps,points=[0.002/c,0.005/c,0.01/c],limit=200)[0]
    print('C1 eps',eps,'sigma',val, 'Et',Et(c*eps))
# C.2 table interpolation
tabs=np.array([[520,600,300,200,0],[390,450,175,115,0.02],[364,420,150,100,0.1]])
for x in (0.01,0.02/1.1,0.05):
    row=[np.interp(x,tabs[:,4],tabs[:,k]) for k in range(4)]
    ex=[520*g(.7,x),600*g(.7,x),300*g(.5,x),200*g(.5,x)]
    print('C2',x,np.round(row,3),np.round(ex,3))
