import numpy as np, re, json
E0=70000.;nu=0.33;er=0.005
lam=E0*nu/((1+nu)*(1-2*nu)); mu=E0/(2*(1+nu))
def D0(E=E0):
    l=E*nu/((1+nu)*(1-2*nu)); m=E/(2*(1+nu)); D=np.zeros((6,6))
    D[:3,:3]=l; 
    for i in range(3): D[i,i]=l+2*m; D[i+3,i+3]=m
    return D
def inv(e):
    I1=e[0]+e[1]+e[2]; epe=e[0]**2+e[1]**2+e[2]**2+0.5*(e[3]**2+e[4]**2+e[5]**2)
    return I1,0.5*(epe-I1*I1),epe
def eqs(e):
    I1,I2,_=inv(e); return np.sqrt(max(4/3*I2+4/9*I1*I1,0))
def Etan(e): return E0/(1+eqs(e)/er)**2
# independent integration: Gauss-Legendre in each of many sub-intervals
xg,wg=np.polynomial.legendre.leggauss(12)
def integ(P,nsub=400):
    P=np.array(P,float); sig=np.zeros(6); W=0.0
    for a,b in zip(P[:-1],P[1:]):
        de=b-a
        for k in range(nsub):
            t0,t1=k/nsub,(k+1)/nsub
            for x,w in zip(xg,wg):
                t=t0+(t1-t0)*(x+1)/2; ww=w*(t1-t0)/2
                e=a+t*de; inc=ww*(Etan(e)/E0)*(D0()@de); 
                W+=(sig+0)@0  # placeholder
                sig=sig+inc
    return sig
def integW(P,nsub=400):
    # work needs sigma at quadrature points: sigma(t)=sigma0+ int ; do nested: use fine trapezoid on Gauss points of stress
    P=np.array(P,float); sig=np.zeros(6); W=0.0
    for a,b in zip(P[:-1],P[1:]):
        de=b-a
        for k in range(nsub):
            t0,t1=k/nsub,(k+1)/nsub; s0=sig.copy(); ds=np.zeros(6)
            for x,w in zip(xg,wg):
                t=t0+(t1-t0)*(x+1)/2; ww=w*(t1-t0)/2
                ds+=ww*(Etan(a+t*de)/E0)*(D0()@de)
            # work over the cell: sigma(t) is smooth; use Simpson with midpoint stress via half integral
            sm=s0.copy()
            for x,w in zip(xg,wg):
                t=t0+(t1-t0)*(x+1)/4; ww=w*(t1-t0)/4
                sm+=ww*(Etan(a+t*de)/E0)*(D0()@de)
            W+=((s0+4*sm+(s0+ds))/6)@(de/nsub)
            sig=s0+ds
    return sig,W
res={}
# closed forms
c=np.sqrt(2/3*(1+2*nu**2-(1-2*nu)**2/3))
res['c']=c
res['uni']=E0*0.02/(1+c*0.02/er)
res['uniW']=0.5*0  # filled below
G0=E0/(2*(1+nu)); res['shear']=G0*0.03/(1+0.03/(np.sqrt(3)*er))
ehat=np.array([1.0,-0.2,0.3,0.5,-0.4,0.25])*0.02
res['pro']=(D0()@ehat/(1+eqs(ehat)/er)).tolist()
res['uni_tmp']=0.96*E0*0.02/(1+c*0.02/er*1)  # placeholder, see below
# temperature: E scaled by FT=1-4e-4*100=0.96 -> sigma=FT*E0 eps/(1+c eps/er)
res['uni_tmp']=0.96*E0*0.02/(1+c*0.02/er)
# uniaxial work: W=int sigma d eps with sigma=E0 e/(1+c e/er)
a=c/er; 
from math import log
res['uniW']=E0*(0.02/a-log(1+a*0.02)/a**2)
# path order
sA,_=integW([[0]*6,[0.02,0,0,0,0,0],[0.02,0,0,0.03,0,0]])
sB,_=integW([[0]*6,[0,0,0,0.03,0,0],[0.02,0,0,0.03,0,0]])
res['ORA']=sA.tolist(); res['ORB']=sB.tolist()
sL,W=integW([[0]*6,[0.02,0,0,0,0,0],[0.02,0,0,0.03,0,0],[0,0,0,0.03,0,0],[0]*6])
res['LOPs']=sL.tolist(); res['LOPW']=W
sL2,W2=integW([[0]*6,[0,0,0,0.03,0,0],[0.02,0,0,0.03,0,0],[0.02,0,0,0,0,0],[0]*6])
res['LOPrevs']=sL2.tolist(); res['LOPrevW']=W2
json.dump(res,open('hyp_ref.json','w'),indent=1)
# compare with driver
rows=[l.split() for l in open('out_hyp.txt')]
def val(tag,ir=None,n=None):
    for r in rows:
        if r[0]==tag and (ir is None or int(r[1])==ir) and (n is None or int(r[2])==n): return [float(x) for x in r[1:]]
print('c =',c)
print('uniaxial closed form %.6f'%res['uni'],' work %.6f'%res['uniW'])
for ir in (1,2,3):
    print('rule',ir,[('%d:%.4f'%(n,val('UNI',ir,n)[2])) for n in (1,2,5,10,20,50,100,1000)])
print('shear closed %.6f'%res['shear'])
for ir in (1,2,3):
    print('rule',ir,[('%d:%.4f'%(n,val('SHR',ir,n)[2])) for n in (1,2,5,10,20,50,100,1000)])
pr=[float(x) for x in [r for r in rows if r[0]=='PRO'][0][1:]]
print('proportional closed',np.round(res['pro'],4)); print('driver           ',np.round(pr,4)); print('maxdiff',np.max(np.abs(np.array(pr)-res['pro'])))
print('temp closed %.6f'%res['uni_tmp'],'driver',[r for r in rows if r[0]=='TMP'][0][1])
ora=[float(x) for x in [r for r in rows if r[0]=='ORA'][0][1:]]; orb=[float(x) for x in [r for r in rows if r[0]=='ORB'][0][1:]]
print('ORA indep',np.round(sA,4),'driver',np.round(ora,4)); print('ORB indep',np.round(sB,4),'driver',np.round(orb,4))
lop=[[float(x) for x in r[1:]] for r in rows if r[0]=='LOP'][-1]
print('LOP indep W %.6f'%W,np.round(sL,4)); print('LOP driver W %.6f'%lop[1],np.round(lop[2:],4))
print('reverse orientation W %.6f'%W2,np.round(sL2,4))
# invariants identity
inv_=[float(x) for x in [r for r in rows if r[0]=='INV'][0][1:]]
print('2 I2 + I1^2 =',2*inv_[1]+inv_[0]**2,' eps:eps =',inv_[3])
print('I2 usual sign',-inv_[1])
