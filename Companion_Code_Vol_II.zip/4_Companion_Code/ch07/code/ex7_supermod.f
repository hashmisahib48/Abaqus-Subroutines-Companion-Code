!     Plateau degradation of a superelastic alloy with the plastic
!     strain of the martensite (Abaqus 2024).  Standard:
!     USUPERELASHARDMOD;  Explicit: VUSUPERELASHARDMOD (ex7_vsupermod.f)
!     both call the kernel K7_SMOD below.
!
!     *SUPERELASTIC HARDENING MODIFICATIONS, USER, PROPERTIES=4
!     PROPS(1) EPSS  -    plastic-strain scale of the degradation
!     PROPS(2) GL    -    final factor of the loading plateau stresses
!     PROPS(3) GU    -    final factor of the unloading plateau stresses
!     PROPS(4) GE    -    final factor of the elastic moduli
!       g(x) = G + (1 - G) exp(-x/EPSS),   x = equivalent plastic strain
!
      SUBROUTINE K7_SMOD(EQP,PROPS,NPROPS,EAR,XNUAR,ESR,XNUSR,
     1 SSASR,SFASR,SSSAR,SFSAR,EA,XNUA,ES,XNUS,SSAS,SFAS,SSSA,SFSA)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(NPROPS)
      PARAMETER (ONE=1.D0, ZERO=0.D0)
      EPSS = PROPS(1)
      X = MAX(EQP,ZERO)
      EXPX = EXP(-X/EPSS)
      GL = PROPS(2) + (ONE-PROPS(2))*EXPX
      GU = PROPS(3) + (ONE-PROPS(3))*EXPX
      GE = PROPS(4) + (ONE-PROPS(4))*EXPX
      EA = GE*EAR                  ! MPa, austenite modulus
      XNUA = XNUAR                 ! -,   Poisson ratios unchanged
      ES = GE*ESR                  ! MPa, martensite modulus
      XNUS = XNUSR
      SSAS = GL*SSASR              ! MPa, start of A->M, loading
      SFAS = GL*SFASR              ! MPa, end of A->M, loading
      SSSA = GU*SSSAR              ! MPa, start of M->A, unloading
      SFSA = GU*SFSAR              ! MPa, end of M->A, unloading
      RETURN
      END
!
      SUBROUTINE USUPERELASHARDMOD(CMNAME,EQPLAS,
     1 NOEL,NPT,LAYER,KSPT,KINC,KSTEP,NSTATV,TEMP,DTEMP,REFT,
     2 TIME,DTIME,PROPS,NUMPROPS,NUMFIELDV,PREDEF,DPRED,
     3 EMODAREF,ENUAREF,EMODSREF,ENUSREF,SSASREF,SFASREF,SSSAREF,
     4 SFSAREF,CAS,CSA,EMODA,ENUA,EMODS,ENUS,SSAS,SFAS,SSSA,SFSA,
     5 STATEV)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION STATEV(NSTATV),TIME(*),
     1 PREDEF(NUMFIELDV),DPRED(NUMFIELDV),PROPS(NUMPROPS)
      CALL K7_SMOD(EQPLAS,PROPS,NUMPROPS,EMODAREF,ENUAREF,EMODSREF,
     1 ENUSREF,SSASREF,SFASREF,SSSAREF,SFSAREF,EMODA,ENUA,EMODS,
     2 ENUS,SSAS,SFAS,SSSA,SFSA)
      IF (NSTATV.GE.2) THEN
        STATEV(1) = SSAS           ! for output only
        STATEV(2) = SSSA
      ENDIF
      RETURN
      END
