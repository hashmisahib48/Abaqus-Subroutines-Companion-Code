!     Driver for UHYPEL (Chapter 7): the strain-driven update that
!     Abaqus performs, outside Abaqus.  Voigt order 11,22,33,12,13,23,
!     engineering shear strain.  Compile together with ex7_uhypel.f.
      SUBROUTINE K7_INV(EPS,EI1,EI2,EI3,EPE)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION EPS(6)
      EI1 = EPS(1)+EPS(2)+EPS(3)
      EPE = EPS(1)**2+EPS(2)**2+EPS(3)**2
     1    + 0.5D0*(EPS(4)**2+EPS(5)**2+EPS(6)**2)
      EI2 = 0.5D0*(EPE - EI1*EI1)
      A12 = 0.5D0*EPS(4)
      A13 = 0.5D0*EPS(5)
      A23 = 0.5D0*EPS(6)
      EI3 = EPS(1)*(EPS(2)*EPS(3)-A23*A23) - A12*(A12*EPS(3)-A23*A13)
     1    + A13*(A12*A23-EPS(2)*A13)
      RETURN
      END
!
      SUBROUTINE K7_MOD(EPS,TEMP,E,GNU)
!     modulus pair at the strain EPS, through UHYPEL
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION EPS(6),COORDS(3),PREDEF(1)
      CHARACTER*80 CMNAME
      CALL K7_INV(EPS,EI1,EI2,EI3,EPE)
      COORDS(1) = 0.D0
      COORDS(2) = 0.D0
      COORDS(3) = 0.D0
      PREDEF(1) = 0.D0
      CMNAME = 'HYPEL'
      CALL UHYPEL(E,GNU,EPS,3,3,EI1,EI2,EI3,COORDS,1,TEMP,PREDEF,
     1 CMNAME)
      RETURN
      END
!
      SUBROUTINE K7_DMAT(E,GNU,D)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION D(6,6)
      XLAM = E*GNU/((1.D0+GNU)*(1.D0-2.D0*GNU))
      XMU  = E/(2.D0*(1.D0+GNU))
      DO I = 1,6
        DO J = 1,6
          D(I,J) = 0.D0
        ENDDO
      ENDDO
      DO I = 1,3
        DO J = 1,3
          D(I,J) = XLAM
        ENDDO
        D(I,I) = XLAM + 2.D0*XMU
        D(I+3,I+3) = XMU
      ENDDO
      RETURN
      END
!
      SUBROUTINE K7_RUN(NSEG,PTS,NINC,IRULE,TEMP,SIG,W)
!     piecewise linear strain path PTS(:,0:NSEG), NINC steps per leg;
!     IRULE 1: moduli at the start, 2: at the mid-point, 3: at the
!     end of the increment.  W = sum of sigma.d(eps), trapezoidal.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PTS(6,0:NSEG),SIG(6),EPS(6),EPM(6),DE(6),D(6,6),S1(6)
      DO I = 1,6
        SIG(I) = 0.D0
        EPS(I) = PTS(I,0)
      ENDDO
      W = 0.D0
      DO ISEG = 1,NSEG
        DE = (PTS(:,ISEG)-PTS(:,ISEG-1))/NINC
        DO K = 1,NINC
          EPM = EPS + 0.5D0*(IRULE-1)*DE
          CALL K7_MOD(EPM,TEMP,E,GNU)
          CALL K7_DMAT(E,GNU,D)
          S1 = SIG + MATMUL(D,DE)
          W = W + 0.5D0*DOT_PRODUCT(SIG+S1,DE)
          SIG = S1
          EPS = EPS + DE
        ENDDO
      ENDDO
      RETURN
      END
!
      PROGRAM K7_HYPDRV
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PTS(6,0:4),SIG(6),EPS(6),NL(8)
      DATA NL /1,2,5,10,20,50,100,1000/
      XNU = 0.33D0
!     --- A: uniaxial stress, eps11 = 0.02, lateral strains -nu eps11
      DO IR = 1,3
        DO K = 1,8
          DO I = 1,6
            PTS(I,0) = 0.D0
            PTS(I,1) = 0.D0
          ENDDO
          PTS(1,1) = 0.02D0
          PTS(2,1) = -XNU*0.02D0
          PTS(3,1) = -XNU*0.02D0
          CALL K7_RUN(1,PTS,NL(K),IR,20.D0,SIG,W)
          WRITE(*,'(A,2I6,1P,3E22.14)') 'UNI',IR,NL(K),SIG(1),SIG(2),W
        ENDDO
      ENDDO
!     --- B: simple shear, gamma12 = 0.03
      DO IR = 1,3
        DO K = 1,8
          DO I = 1,6
            PTS(I,0) = 0.D0
            PTS(I,1) = 0.D0
          ENDDO
          PTS(4,1) = 0.03D0
          CALL K7_RUN(1,PTS,NL(K),IR,20.D0,SIG,W)
          WRITE(*,'(A,2I6,1P,2E22.14)') 'SHR',IR,NL(K),SIG(4),SIG(1)
        ENDDO
      ENDDO
!     --- C: proportional path, general strain state, mid-point rule
      DO I = 1,6
        PTS(I,0) = 0.D0
      ENDDO
      PTS(1,1) = 0.02D0*1.0D0
      PTS(2,1) = 0.02D0*(-0.2D0)
      PTS(3,1) = 0.02D0*0.3D0
      PTS(4,1) = 0.02D0*0.5D0
      PTS(5,1) = 0.02D0*(-0.4D0)
      PTS(6,1) = 0.02D0*0.25D0
      CALL K7_RUN(1,PTS,1000,2,20.D0,SIG,W)
      WRITE(*,'(A,1P,6E22.14)') 'PRO',SIG
      CALL K7_INV(PTS(1,1),EI1,EI2,EI3,EPE)
      WRITE(*,'(A,1P,4E22.14)') 'INV',EI1,EI2,EI3,EPE
!     --- T: temperature 120 C, uniaxial
      DO I = 1,6
        PTS(I,1) = 0.D0
      ENDDO
      PTS(1,1) = 0.02D0
      PTS(2,1) = -XNU*0.02D0
      PTS(3,1) = -XNU*0.02D0
      CALL K7_RUN(1,PTS,1000,2,120.D0,SIG,W)
      WRITE(*,'(A,1P,2E22.14)') 'TMP',SIG(1),SIG(2)
!     --- D: two orders of the same two strain components
      DO I = 1,6
        DO J = 0,4
          PTS(I,J) = 0.D0
        ENDDO
      ENDDO
      PTS(1,1) = 0.02D0
      PTS(1,2) = 0.02D0
      PTS(4,2) = 0.03D0
      CALL K7_RUN(2,PTS,4000,2,20.D0,SIG,W)
      WRITE(*,'(A,1P,6E22.14)') 'ORA',SIG
      PTS(1,1) = 0.D0
      PTS(4,1) = 0.03D0
      CALL K7_RUN(2,PTS,4000,2,20.D0,SIG,W)
      WRITE(*,'(A,1P,6E22.14)') 'ORB',SIG
!     --- E: closed rectangle in (eps11, gamma12)
      DO I = 1,6
        DO J = 0,4
          PTS(I,J) = 0.D0
        ENDDO
      ENDDO
      PTS(1,1) = 0.02D0
      PTS(1,2) = 0.02D0
      PTS(4,2) = 0.03D0
      PTS(4,3) = 0.03D0
      DO K = 1,3
        NI = 250*4**(K-1)
        CALL K7_RUN(4,PTS,NI,2,20.D0,SIG,W)
        WRITE(*,'(A,I6,1P,7E22.14)') 'LOP',NI,W,SIG
      ENDDO
      END
