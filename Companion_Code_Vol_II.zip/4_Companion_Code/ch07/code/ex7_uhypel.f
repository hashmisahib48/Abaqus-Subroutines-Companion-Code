!     Hypoelastic material with a hyperbolic tangent modulus
!     (Abaqus/Standard 2024, *HYPOELASTIC, USER).  UHYPEL has no PROPS
!     argument: the constants are fixed in PARAMETER statements.
!
!       E   = FT * E0 / (1 + EQ/ER)**2        tangent Young's modulus
!       GNU = XNU                              Poisson's ratio
!       EQ  = sqrt( 4/3 I2 + 4/9 I1**2 )       equivalent strain
!       FT  = 1 - BETA (TEMP - T0)             temperature factor
!
!     ---------- equivalent strain from the invariants ----------
      SUBROUTINE K7_EQ(EINV1,EINV2,SGN2,EQ)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (ZERO=0.D0, C43=4.D0/3.D0, C49=4.D0/9.D0)
!     SGN2 = +1 for I2 = (eps:eps - I1**2)/2 as printed in the
!     documentation; -1 for the usual I2 = (I1**2 - eps:eps)/2
      Q2 = C43*SGN2*EINV2 + C49*EINV1*EINV1
      EQ = SQRT(MAX(Q2,ZERO))
      RETURN
      END
!
!     ---------- the user subroutine ----------
      SUBROUTINE UHYPEL(E,GNU,STRAIN,NDI,NSHR,EINV1,EINV2,EINV3,
     1 COORDS,NOEL,TEMP,PREDEF,CMNAME)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION STRAIN(*),COORDS(3),PREDEF(*)
      PARAMETER (E0=70000.D0)      ! MPa, initial Young's modulus
      PARAMETER (XNU=0.33D0)       ! -,   Poisson's ratio
      PARAMETER (ER=0.005D0)       ! -,   reference strain of the law
      PARAMETER (BETA=4.D-4)       ! 1/C, softening with temperature
      PARAMETER (T0=20.D0)         ! C,   reference temperature
      PARAMETER (SGN2=1.D0)        ! sign convention of EINV2
      PARAMETER (ONE=1.D0)
      CALL K7_EQ(EINV1,EINV2,SGN2,EQ)
      FT = ONE - BETA*(TEMP - T0)
      E = FT*E0/(ONE + EQ/ER)**2
      GNU = XNU
      RETURN
      END
