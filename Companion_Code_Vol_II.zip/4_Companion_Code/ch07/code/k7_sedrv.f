!     Driver for USUPERELASHARDMOD / VUSUPERELASHARDMOD (Chapter 7).
!     Uniaxial reduction of the superelastic model of Auricchio and
!     Taylor with plastic martensite (NOT the Abaqus implementation),
!     strain driven; the user routine is called at the start of every
!     increment with the plastic strain of the converged state.
!     Compile with ex7_supermod.f and ex7_vsupermod.f.
      SUBROUTINE K7_CON(EQP,PROPS,CON)
!     CON: 1 EA, 2 EM, 3 SLS, 4 SLE, 5 SUS, 6 SUE
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PROPS(4),CON(6),STATEV(2),TIME(2),PREDEF(1),DPRED(1)
      CHARACTER*80 CMNAME
      CMNAME = 'NITI'
      TIME(1) = 0.D0
      TIME(2) = 0.D0
      PREDEF(1) = 0.D0
      DPRED(1) = 0.D0
      CALL USUPERELASHARDMOD(CMNAME,EQP,1,1,1,1,1,1,2,20.D0,0.D0,
     1 20.D0,TIME,1.D0,PROPS,4,1,PREDEF,DPRED,
     2 60000.D0,0.3D0,40000.D0,0.3D0,520.D0,600.D0,300.D0,200.D0,
     3 6.5D0,6.5D0,CON(1),ENUA,CON(2),ENUS,CON(3),CON(4),CON(5),
     4 CON(6),STATEV)
      RETURN
      END
!
      SUBROUTINE K7_UPD(EPS,XIN,EPN,PROPS,EL,SY0,HH,XI,EP,SIG)
!     one strain-driven increment of the uniaxial reduction
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PROPS(4),CON(6)
      RES(X,SL,SH) = (EA+X*(EM-EA))*(A-EL*X) - SL - (SH-SL)*X
      CALL K7_CON(EPN,PROPS,CON)
      EA = CON(1)
      EM = CON(2)
      A = EPS - EPN
      XI = XIN
      EP = EPN
      SF = RES(XIN,CON(3),CON(4))
      SR = RES(XIN,CON(6),CON(5))
      IF (SF.GT.0.D0 .AND. XIN.LT.1.D0) THEN
        S = 1.D0
        XH = 1.D0
        SL = CON(3)
        SH = CON(4)
      ELSEIF (SR.LT.0.D0 .AND. XIN.GT.0.D0) THEN
        S = -1.D0
        XH = 0.D0
        SL = CON(6)
        SH = CON(5)
      ELSE
        S = 0.D0
      ENDIF
      IF (S.NE.0.D0) THEN
        XL = XIN
        XI = XH
        IF (S*RES(XH,SL,SH).LT.0.D0) THEN
          DO IT = 1,100
            XI = 0.5D0*(XL+XH)
            IF (S*RES(XI,SL,SH).GT.0.D0) THEN
              XL = XI
            ELSE
              XH = XI
            ENDIF
          ENDDO
        ENDIF
      ENDIF
      SIG = (EA+XI*(EM-EA))*(A-EL*XI)
      IF (XI.GE.1.D0 .AND. SIG.GT.SY0+HH*EPN) THEN
        EP = EPN + (SIG-SY0-HH*EPN)/(EM+HH)
        SIG = EM*(A-EL-(EP-EPN))
      ENDIF
      RETURN
      END
!
      SUBROUTINE K7_CYC(TAG,PROPS)
      IMPLICIT REAL*8 (A-H,O-Z)
      CHARACTER*3 TAG
      DIMENSION PROPS(4),PK(3),CON(6)
      DATA PK /0.09D0,0.10D0,0.11D0/
      PARAMETER (EL=0.05D0, SY0=600.D0, HH=4000.D0, DE=1.D-5)
      EPS = 0.D0
      XI = 0.D0
      EP = 0.D0
      SIG = 0.D0
      IOUT = 0
      DO IC = 1,3
        W = 0.D0
        EPS0 = EPS
        NINC = NINT((PK(IC)-EPS)/DE)
        DEL = (PK(IC)-EPS)/NINC
        DO K = 1,NINC
          XIO = XI
          SO = SIG
          EPSN = EPS + DEL
          CALL K7_UPD(EPSN,XI,EP,PROPS,EL,SY0,HH,XI1,EP1,S1)
          W = W + 0.5D0*(SO+S1)*DEL
          IF (XIO.EQ.0.D0 .AND. XI1.GT.0.D0)
     1      WRITE(*,'(A,A,I2,A,2F12.6)') 'EVT ',TAG,IC,' FS ',EPSN,S1
          IF (XIO.LT.1.D0 .AND. XI1.GE.1.D0)
     1      WRITE(*,'(A,A,I2,A,2F12.6)') 'EVT ',TAG,IC,' FE ',EPSN,S1
          IF (EP.EQ.0.D0 .AND. EP1.GT.0.D0 .AND. IC.EQ.1)
     1      WRITE(*,'(A,A,I2,A,2F12.6)') 'EVT ',TAG,IC,' YL ',EPSN,S1
          EPS = EPSN
          XI = XI1
          EP = EP1
          SIG = S1
          IOUT = IOUT + 1
          IF (MOD(IOUT,25).EQ.0) WRITE(*,'(A,A,I2,F11.6,F11.4,F9.5,
     1      F11.7)') 'CUR ',TAG,IC,EPS,SIG,XI,EP
        ENDDO
        WRITE(*,'(A,A,I2,A,2F12.6,F12.8)') 'EVT ',TAG,IC,' PK ',EPS,
     1    SIG,EP
!       unloading to zero stress
        DO WHILE (SIG.GT.0.D0)
          XIO = XI
          SO = SIG
          EPSN = EPS - DE
          CALL K7_UPD(EPSN,XI,EP,PROPS,EL,SY0,HH,XI1,EP1,S1)
          IF (S1.LE.0.D0) THEN
            FR = SO/(SO-S1)
            EPSZ = EPS - FR*DE
            W = W - 0.5D0*SO*FR*DE
            EPS = EPSZ
            SIG = 0.D0
            XI = XI1
            EP = EP1
          ELSE
            W = W - 0.5D0*(SO+S1)*DE
            IF (XIO.EQ.1.D0 .AND. XI1.LT.1.D0)
     1        WRITE(*,'(A,A,I2,A,2F12.6)') 'EVT ',TAG,IC,' RS ',EPSN,S1
            IF (XIO.GT.0.D0 .AND. XI1.LE.0.D0)
     1        WRITE(*,'(A,A,I2,A,2F12.6)') 'EVT ',TAG,IC,' RE ',EPSN,S1
            EPS = EPSN
            XI = XI1
            EP = EP1
            SIG = S1
            IOUT = IOUT + 1
            IF (MOD(IOUT,25).EQ.0) WRITE(*,'(A,A,I2,F11.6,F11.4,F9.5,
     1        F11.7)') 'CUR ',TAG,IC,EPS,SIG,XI,EP
          ENDIF
        ENDDO
        WRITE(*,'(A,A,I2,A,F12.8,F12.8,F12.6)') 'EVT ',TAG,IC,' ZS ',
     1    EPS,EP,W
      ENDDO
      END
!
      PROGRAM K7_SEDRV
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION P1(4),P0(4),CON(6),CV(6)
      DIMENSION EQ(4),A1(4),A2(4),A3(4),A4(4),A5(4),A6(4),A7(4),A8(4)
      DIMENSION B1(4),B2(4),B3(4),B4(4),B5(4),B6(4),B7(4),B8(4)
      DIMENSION FLD(4,1),FLDN(4,1),SO(4,2),SN(4,2),TO(4),TN(4)
      DIMENSION CAS(4),CSA(4),RFT(4),JEL(4)
      CHARACTER*80 CMNAME
      DATA P1 /0.01D0,0.70D0,0.50D0,1.0D0/
      DATA P0 /0.01D0,1.00D0,1.00D0,1.0D0/
      CALL K7_CYC('MOD',P1)
      CALL K7_CYC('REF',P0)
!     Explicit routine on a block of four points
      EQ(1) = 0.D0
      EQ(2) = 0.005D0
      EQ(3) = 0.025D0/1.1D0
      EQ(4) = 0.1D0
      DO K = 1,4
        A1(K) = 60000.D0
        A2(K) = 0.3D0
        A3(K) = 40000.D0
        A4(K) = 0.3D0
        A5(K) = 520.D0
        A6(K) = 600.D0
        A7(K) = 300.D0
        A8(K) = 200.D0
        JEL(K) = K
        TO(K) = 20.D0
        TN(K) = 20.D0
        FLD(K,1) = 0.D0
        FLDN(K,1) = 0.D0
        SO(K,1) = 0.D0
        SO(K,2) = 0.D0
        CAS(K) = 6.5D0
        CSA(K) = 6.5D0
        RFT(K) = 20.D0
      ENDDO
      CMNAME = 'NITI'
      CALL VUSUPERELASHARDMOD(4,JEL,1,1,1,0.D0,0.D0,1.D0,CMNAME,2,1,
     1 4,P1,TO,TN,FLD,FLDN,SO,CAS,CSA,EQ,RFT,A1,A2,A3,A4,A5,A6,A7,A8,
     2 B1,B2,B3,B4,B5,B6,B7,B8,SN)
      DO K = 1,4
        CALL K7_CON(EQ(K),P1,CON)
        WRITE(*,'(A,I2,1P,E11.4,6E14.6)') 'BLK',K,EQ(K),B5(K),B6(K),
     1    B7(K),B8(K),SN(K,1),SN(K,2)
        WRITE(*,'(A,I2,1P,E11.4,6E14.6)') 'STD',K,EQ(K),CON(3),CON(4),
     1    CON(5),CON(6)
        WRITE(*,'(A,I2,1P,4E14.6)') 'BL2',K,B1(K),B2(K),B3(K),B4(K)
      ENDDO
      END
