"""Independent checks for Chapter 17: brute-force projections, closed forms and root finders in Python,
compared with the output of the Fortran drivers (code/drv17_*.f).  Writes results.json."""
import os, json, math
B=os.path.dirname(os.path.abspath(__file__)); import numpy as np
from scipy.optimize import minimize_scalar, fsolve, brentq, minimize
R={}
AMP,WL=1.5,10.0; WK=2*math.pi/WL
f=lambda x:AMP*np.sin(WK*x); fp=lambda x:AMP*WK*np.cos(WK*x); fpp=lambda x:-AMP*WK*WK*np.sin(WK*x)
def brute_sin(xa,ya):
    """global closest point by dense sampling (20001 points over +-D) and bounded polishing"""
    D=abs(ya-f(xa))+1e-9; xs=np.linspace(xa-D,xa+D,20001); d2=(xs-xa)**2+(f(xs)-ya)**2; j=int(np.argmin(d2))
    lo=xs[max(j-1,0)]; hi=xs[min(j+1,20000)]
    r=minimize_scalar(lambda x:(x-xa)**2+(f(x)-ya)**2,bounds=(lo,hi),method='bounded',options={'xatol':1e-13})
    x=r.x; w=math.sqrt(1+fp(x)**2); n=np.array([-fp(x)/w,1/w]); h=float((np.array([x,f(x)])-np.array([xa,ya]))@n)
    return x,h,w
# ---------------- sinusoid
rows=[l.split() for l in open(B+'/out_sin.txt') if l.startswith('S ')]
A=np.array([[float(v) for v in r[1:]] for r in rows])
ex=ey=eh=eo=ec=et=0.0; xb_all=[]
for xl,yl,H,px,py,tx,ty,dx,dy,t3,p3 in A:
    x,h,w=brute_sin(xl,yl); xb_all.append(x)
    eh=max(eh,abs(H-h)); ex=max(ex,abs(px-x)); ey=max(ey,abs(py-f(x)))
    et=max(et,abs(tx-1/w),abs(ty-fp(x)/w))
    n=np.array([-ty,tx]); eo=max(eo,abs((np.array([px-xl,py-yl])@np.array([tx,ty]))))     # A-P perpendicular to t
    c=-fpp(x)/w**3; ec=max(ec,abs(dx-c*tx),abs(dy-c*ty))
R['sin']=dict(n=len(A),dH=eh,dPx=ex,dPy=ey,dT=et,ortho=eo,dDNDS=ec,P3=float(abs(A[:,10]).max()),T23=float(abs(A[:,9]+1).max()))
Nl=[l.split() for l in open(B+'/out_sin.txt') if l.startswith('N ')][0]
R['sin']['naive_wrong']=int(Nl[1]); R['sin']['band06']=int(Nl[2]); R['sin']['naive_wrong_band06']=int(Nl[3])
Fl=[l.split() for l in open(B+'/out_sin.txt') if l.startswith('F ')][0]; R['sin']['fd_dnds']=float(Fl[1])
# naive Newton in python for several bands of |H| (true H from the routine)
def naive(xa,ya):
    x=xa
    for _ in range(50):
        g=(x-xa)+(f(x)-ya)*fp(x); gp=1+fp(x)**2+(f(x)-ya)*fpp(x)
        xn=x-g/gp
        if abs(xn-x)<1e-13: return xn
        x=xn
    return x
kmax=AMP*WK**2; R['sin']['kappa_max']=kmax; R['sin']['rho_min']=1/kmax
bands={}
for b in (0.5,1.0,1.5,2.0,3.0):
    sel=[(i,r) for i,r in enumerate(A) if abs(r[2])<=b]
    bad=sum(1 for i,r in sel if abs(naive(r[0],r[1])-xb_all[i])>1e-6)
    bands[str(b)]=[len(sel),bad]
R['sin']['naive_bands']=bands
# five worked points
pts=[(-1.0,0.2),(1.0,1.2),(2.5,1.0),(7.5,-1.4),(5.0,-0.6)]
tab=[]
for xa,ya in pts:
    x,h,w=brute_sin(xa,ya); tab.append(dict(xa=xa,ya=ya,H=h,xp=x,yp=float(f(x)),tx=1/w,ty=float(fp(x)/w),kappa=float(-fpp(x)/w**3)))
R['sin']['table']=tab
# ---------------- torus
RM,Rm=40.0,8.0
def tor(phi,psi): return np.array([(RM+Rm*np.cos(psi))*np.cos(phi),(RM+Rm*np.cos(psi))*np.sin(phi),Rm*np.sin(psi)])
rows=[l.split() for l in open(B+'/out_torus.txt') if l.startswith('T ')]
A=np.array([[float(v) for v in r[1:]] for r in rows])
ph=np.linspace(0,2*np.pi,361)[:-1]; ps=np.linspace(0,2*np.pi,181)[:-1]
PH,PS=np.meshgrid(ph,ps,indexing='ij'); S=np.stack([(RM+Rm*np.cos(PS))*np.cos(PH),(RM+Rm*np.cos(PS))*np.sin(PH),Rm*np.sin(PS)],-1)
eh=ep=ec1=ec2=eo=ek=0.0
for r in A[:600]:
    a=r[:3]; d2=((S-a)**2).sum(-1); i,j=np.unravel_index(np.argmin(d2),d2.shape)
    res=minimize(lambda q:((tor(q[0],q[1])-a)**2).sum(),[ph[i],ps[j]],method='BFGS',options={'gtol':1e-12})
    p=tor(*res.x); n=(p-np.array([ (RM*a[0]/math.hypot(a[0],a[1])),(RM*a[1]/math.hypot(a[0],a[1])),0]))/Rm
    h=float((p-a)@n); eh=max(eh,abs(r[3]-h)); ep=max(ep,np.abs(r[4:7]-p).max())
    t1=r[7:10]; t2=r[10:13]; nn=np.cross(t1,t2); eo=max(eo,np.abs(nn-n).max(),abs(t1@t2),abs(np.linalg.norm(t1)-1),abs(np.linalg.norm(t2)-1))
    cps=(math.hypot(a[0],a[1])-RM)/math.hypot(math.hypot(a[0],a[1])-RM,a[2])
    c2=cps/(RM+Rm*cps); ec1=max(ec1,np.abs(r[13:16]-t1/Rm).max()); ec2=max(ec2,np.abs(r[16:19]-c2*t2).max())
R['torus']=dict(n=len(A),dH=eh,dP=ep,frame=eo,dDNDS1=ec1,dDNDS2=ec2)
Fl=[l.split() for l in open(B+'/out_torus.txt') if l.startswith('F ')][0]; R['torus']['fd']=[float(Fl[1]),float(Fl[2])]
R['torus']['degenerate']=[l.split() for l in open(B+'/out_torus.txt') if l.startswith('D ')]
# ---------------- one-node model
SK,EPS,YD,NINC,XEND=2000.0,3000.0,0.4,40,10.0
def Rfun(a,xd):
    x,h,w=brute_sin(a[0],a[1]); n=np.array([-fp(x)/w,1/w]); r=np.array([SK*(xd-a[0]),SK*(YD-a[1])])
    if h>0: r=r+EPS*h*n
    return r
it={1:{},2:{},3:{}}; hist={}
for l in open(B+'/out_node.txt'):
    t=l.split()
    if t[0]=='P': it[int(t[1])][int(t[2])]=(int(t[3]),float(t[4]),float(t[5]),float(t[6]))
    if t[0]=='R': hist.setdefault((int(t[1]),int(t[2])),[]).append(float(t[4]))
    if t[0]=='T': R['node_fd']=float(t[1])
a=np.array([0.0,YD]); dev=0.0; pos={}
for inc in range(1,NINC+1):
    xd=XEND*inc/NINC; a=fsolve(lambda q:Rfun(q,xd),a,xtol=1e-12); pos[inc]=a.copy()
    for o in (1,2,3): dev=max(dev,abs(it[o][inc][1]-a[0]),abs(it[o][inc][2]-a[1]))
R['node']=dict(dev=dev,iters={o:[it[o][i][0] for i in range(1,NINC+1)] for o in (1,2,3)},H={i:it[1][i][3] for i in range(1,NINC+1)},
   X={i:it[1][i][1] for i in range(1,NINC+1)},Y={i:it[1][i][2] for i in range(1,NINC+1)},
   hist={str(k):v for k,v in hist.items() if k[1] in (8,10)})
R['node']['tot']={o:sum(R['node']['iters'][o]) for o in (1,2,3)}; R['node']['max']={o:max(R['node']['iters'][o]) for o in (1,2,3)}
R['node']['contact_incs']=sum(1 for i in range(1,NINC+1) if it[1][i][3]>0)
# ---------------- gap conductance
KS,SIG,M,HC,KG0,T0,NEXP,GM=45.0,1e-3,0.12,3000.0,0.0263,300.0,0.8,4e-4
def gk(d,p,ta,tb,ks=KS,kg0=KG0,nexp=NEXP,hc=HC):
    x=p/hc; xlo,xhi=1e-6,2e-2
    s=x**0.95 if x>=xlo else xlo**0.95*max(x,0)/xlo
    xc=min(max(x,xlo),xhi); y=1.184*SIG*(-math.log(3.132*xc))**0.547
    tm=max(0.5*(ta+tb)+273.15,1.0); kc=1.25*ks*M/SIG*s; kg=kg0*(tm/T0)**nexp/(max(d,0)+y+GM)
    return kc+kg,kc,kg
rows=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('G ')]
tabg=[]; e1=0
for r in rows:
    v=[float(x) for x in r[2:]]; d,p,ta,tb=v[:4]; ak=v[4:9]
    k,kc,kg=gk(d,p,ta,tb); e1=max(e1,abs(k-ak[0])/k)
    tabg.append(dict(d=d,p=p,ta=ta,tb=tb,AK=ak,kc=v[9],kg=v[10]))
R['gapcon']=dict(table=tabg,dk=e1)
Fl=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('FDG')][0]; R['gapcon']['fd']=[float(x) for x in Fl[1:]]
# independent finite differences in Python (complex-free): central, relative steps
def fd(d,p,ta,tb):
    out=[]
    h=1e-6*d if d>0 else None
    out.append(None if d<=0 else (gk(d+h,p,ta,tb)[0]-gk(d-h,p,ta,tb)[0])/(2*h))
    h=1e-6*p; out.append(None if p<=0 else (gk(d,p+h,ta,tb)[0]-gk(d,p-h,ta,tb)[0])/(2*h))
    h=1e-3; out.append((gk(d,p,ta+h,tb)[0]-gk(d,p,ta-h,tb)[0])/(2*h)); out.append((gk(d,p,ta,tb+h)[0]-gk(d,p,ta,tb-h)[0])/(2*h))
    return out
e=[0,0,0,0]
for t in tabg:
    ref=fd(t['d'],t['p'],t['ta'],t['tb'])
    for k in range(4):
        if ref[k] is not None and abs(t['AK'][k+1])>0: e[k]=max(e[k],abs(ref[k]-t['AK'][k+1])/abs(t['AK'][k+1]))
R['gapcon']['fd_py']=e
sw=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('SP ')]; R['gapcon']['sweep_p']=[[float(x) for x in r[1:]] for r in sw]
sw=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('SQ ')]; R['gapcon']['sweep_q']=[[float(x) for x in r[1:]] for r in sw]
sw=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('SD ')]; R['gapcon']['sweep_d']=[[float(x) for x in r[1:]] for r in sw]
# limiting values
x=1e-6; ylim=1.184*SIG*(-math.log(3.132*x))**0.547
R['gapcon']['Ymin']=ylim; R['gapcon']['gas_only']=KG0/(0.1+ylim+GM)
# plates + interface chain
TH,TC,CB1,CB2=150.0,20.0,45/2,160/3
def chain(p,nexp=NEXP):
    def h(q):
        ta=TH-q/CB1; tb=TC+q/CB2; return gk(0.0,p,ta,tb,nexp=nexp)[0]*(ta-tb)-q
    q=brentq(h,0.0,min(CB1,CB2)*(TH-TC),xtol=1e-14,rtol=1e-15); return TH-q/CB1,TC+q/CB2,q
rows=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('C ')]
ch=[]; e=0
for r in rows:
    iv,ip,n1=int(r[1]),int(r[2]),int(r[3]); p,ta,tb,q,k,n2=[float(x) for x in r[4:10]]
    ta2,tb2,q2=chain(p,NEXP if iv==1 else 0.0); e=max(e,abs(ta-ta2),abs(tb-tb2),abs(q-q2)/q2)
    ch.append(dict(iv=iv,p=p,thA=ta,thB=tb,q=q,k=k,nfull=n1,nfrozen=int(n2),ref=[ta2,tb2,q2]))
R['chain']=dict(rows=ch,dev=e)
# closed form for k independent of temperature (n = 0)
cf=[c for c in ch if c['iv']==2 and abs(c['p']-10)<1e-9][0]
k=cf['k']; q_cf=(TH-TC)/(1/CB1+1/k+1/CB2); R['chain']['closed']=dict(q=q_cf,q_drv=cf['q'],thA=TH-q_cf/CB1,thB=TC+q_cf/CB2)
R['chain']['hist']={}
for l in open(B+'/out_gap.txt'):
    if l.startswith('H '):
        t=l.split(); R['chain']['hist'].setdefault(t[1],[]).append([float(t[4]),float(t[5]),float(t[6])])
# ---------------- electrical
SIGS,ESIG,EM,EHC,AL,TH0=5.8e4,1e-3,0.12,1200.0,0.0039,20.0
def ge(p,ta,tb):
    x=p/EHC; xlo=1e-6; s=x**0.95 if x>=xlo else xlo**0.95*max(x,0)/xlo
    return 1.25*SIGS*EM/ESIG*s/(1+AL*(0.5*(ta+tb)-TH0))
rows=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('E ')]; te=[]; e=0
for r in rows:
    v=[float(x) for x in r[2:]]; p,ta,tb=v[:3]; p=0.0 if p==0 else 10**(-2+0.5*(int(r[1])-1)); s=v[3:8]; e=max(e,abs(s[0]-ge(p,ta,tb))/max(ge(p,ta,tb),1e-300)) if p>0 else e
    te.append(dict(p=p,ta=ta,tb=tb,S=s))
R['gapelectr']=dict(table=te,dev=e)
Fl=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('FDE')][0]; R['gapelectr']['fd']=[float(x) for x in Fl[1:]]
Wl=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('WF')][0]; R['gapelectr']['wf']=[float(x) for x in Wl[1:]]
Sl=[l.split() for l in open(B+'/out_gap.txt') if l.startswith('SC')][0]; R['gapelectr']['series']=[float(x) for x in Sl[1:]]
R["gapelectr"]["series_py"]=0.001/(2*2/SIGS+1/ge(10,20,20))
json.dump(R,open(B+'/results.json','w'),indent=1,default=float)
for k in ('sin','torus'): print(k,{a:b for a,b in R[k].items() if a not in('table','degenerate')})
print('node',R['node']['dev'],R['node']['tot'],R['node']['max'],R['node_fd'],R['node']['contact_incs'])
print('gapcon',R['gapcon']['dk'],R['gapcon']['fd'],R['gapcon']['fd_py'],R['gapcon']['Ymin'],R['gapcon']['gas_only'])
print('chain',R['chain']['dev'],R['chain']['closed'])
print('electr',R['gapelectr']['dev'],R['gapelectr']['fd'],R['gapelectr']['wf'],R['gapelectr']['series'],R['gapelectr']['series_py'])
