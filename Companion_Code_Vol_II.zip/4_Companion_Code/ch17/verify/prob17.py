"""Answers of the problems of Chapter 17 (computed)."""
import json, math, sys, os
B=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,B)
import numpy as np
from scipy.optimize import minimize
exec(open(B+'/check17.py').read().split('# ---------------- sinusoid')[0].split("R={}")[0])  # imports only
AMP,WL=1.5,10.0; WK=2*math.pi/WL
f=lambda x:AMP*np.sin(WK*x); fp=lambda x:AMP*WK*np.cos(WK*x); fpp=lambda x:-AMP*WK*WK*np.sin(WK*x)
from scipy.optimize import minimize_scalar
def sinpt(xa,ya):
    D=abs(ya-f(xa))+1e-9; xs=np.linspace(xa-D,xa+D,20001); d2=(xs-xa)**2+(f(xs)-ya)**2; j=int(np.argmin(d2))
    r=minimize_scalar(lambda x:(x-xa)**2+(f(x)-ya)**2,bounds=(xs[max(j-1,0)],xs[min(j+1,20000)]),method='bounded',options={'xatol':1e-14})
    x=r.x; w=math.sqrt(1+fp(x)**2); return dict(xp=x,yp=float(f(x)),H=float(((x-xa)*(-fp(x))+(f(x)-ya))/w),tx=1/w,ty=float(fp(x)/w),kappa=float(-fpp(x)/w**3),nx=float(-fp(x)/w),ny=1/w)
P={}
# 17A.1
a=sinpt(6.0,-1.0); P['A1']=a
# first Newton iterate from x_A
xa,ya=6.0,-1.0; g=(xa-xa)+(f(xa)-ya)*fp(xa); gp=1+fp(xa)**2+(f(xa)-ya)*fpp(xa); P['A1']['newton1']=xa-g/gp
# 17A.2 torus
RM,Rm=40.0,8.0
def torus(a):
    rho=math.hypot(a[0],a[1]); dr=rho-RM; dn=math.hypot(dr,a[2]); cps=dr/dn; sps=a[2]/dn; cph=a[0]/rho; sph=a[1]/rho
    n=np.array([cps*cph,cps*sph,sps]); t1=np.array([sps*cph,sps*sph,-cps]); t2=np.array([-sph,cph,0.0])
    p=np.array([(RM+Rm*cps)*cph,(RM+Rm*cps)*sph,Rm*sps]); return dict(H=Rm-dn,n=n.tolist(),t1=t1.tolist(),t2=t2.tolist(),P=p.tolist(),c1=1/Rm,c2=cps/(RM+Rm*cps),rho=rho,dn=dn)
P['A2']=torus(np.array([30.0,20.0,3.0]))
# 17A.3 gap conductance (hand check)
KS,SIG,M,HC,KG0,T0,NEXP,GM=45.0,1e-3,0.12,3000.0,0.0263,300.0,0.8,4e-4
def gk(d,p,ta,tb):
    x=p/HC; s=x**0.95; Z=-math.log(3.132*x); y=1.184*SIG*Z**0.547
    tm=0.5*(ta+tb)+273.15; kc=1.25*KS*M/SIG*s; kg=KG0*(tm/T0)**NEXP/(max(d,0)+y+GM)
    dydp=-1.184*SIG*0.547*Z**(-0.453)/x/HC
    gp=max(d,0)+y+GM
    return dict(kc=kc,kg=kg,k=kc+kg,Y=y,x=x,AK2=-kg/gp if d>0 else 0.0,AK3=1.25*KS*M/SIG*0.95*x**(-0.05)/HC-kg/gp*dydp,AK4=0.5*NEXP*kg/tm)
P['A3']=gk(0.0,5.0,20.0,20.0); P['A3']['q30']=P['A3']['k']*30.0
P['B3']=gk(0.004,2.0,20.0,20.0)
# 17B.1 stiffness factor
kap=AMP*WK*WK; h=0.5; P['B1']=dict(kappa=kap,h=h,fac=h*kap/(1-h*kap),eps=3000.0,krr=3000.0*h*kap/(1-h*kap))
# 17B.2 buggy routine at (2.0,0.8), ref point (0,0)
P['B2']=sinpt(2.0,0.8)
w=math.sqrt(1+fp(2.0)**2); P['B2']['bug_H']=float((0.8-f(2.0))/w); P['B2']['vertical']=float(f(2.0)-0.8)
# 17B.3 Wiedemann-Franz transfer
P['B3wf']=dict(h=3.0e4,T=400.0,sig=3.0e4/(2.44e-8*400.0))
# 17C.1 node model positions
R=json.load(open(B+'/results.json'))
P['C1']={str(i):[R['node']['X'][str(i)],R['node']['Y'][str(i)],R['node']['H'][str(i)]] for i in (8,10,20,30)}
# 17C.2 ellipse a=12, b=6, point (14,3)
ea,eb=12.0,6.0
def ell(p):
    th=np.linspace(0,2*np.pi,200001); d2=(ea*np.cos(th)-p[0])**2+(eb*np.sin(th)-p[1])**2; j=int(np.argmin(d2))
    r=minimize_scalar(lambda t:(ea*np.cos(t)-p[0])**2+(eb*np.sin(t)-p[1])**2,bounds=(th[j-1],th[j+1]),method='bounded',options={'xatol':1e-14})
    t=r.x; q=np.array([ea*np.cos(t),eb*np.sin(t)]); n=np.array([eb*np.cos(t),ea*np.sin(t)]); n/=np.linalg.norm(n)
    kap=ea*eb/((ea*np.sin(t))**2+(eb*np.cos(t))**2)**1.5
    return dict(theta=t,P=q.tolist(),n=n.tolist(),H=float((q-np.array(p))@n),kappa=float(kap))
P['C2']=ell([10.0,4.0]); P['C2b']=ell([4.0,3.0])
json.dump(P,open(B+'/prob.json','w'),indent=1,default=float)
for k,v in P.items(): print(k,v)
