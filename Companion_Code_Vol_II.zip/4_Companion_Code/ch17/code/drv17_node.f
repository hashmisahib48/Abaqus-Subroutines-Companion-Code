!     drv17_node.f   One secondary node on the sinusoidal rigid
!     surface, held by a spring and a penalty (Example 17.5-2).
!     R(A) = ks (D - A) + eps H n  for H > 0.  Newton iterations with
!     three tangents.  Writes ../verify/out_node.txt.
      PROGRAM DRV17N
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      CHARACTER*80 CN
      DIMENSION P(3), TGT(3,2), DNDS(3,2), X(3,3), TIME(2), U(6,2)
      DIMENSION A(2), A0(2), R(2), AK(2,2), DA(2), AT(2), RP(2), RM(2),
     1 AKX(2,2)
      DIMENSION APATH(2,3,60), NIT(3,60), HPATH(3,60)
      PARAMETER (SK = 2000.D0, EPS = 3000.D0)     ! N/mm
      PARAMETER (YD = 0.4D0, NINC = 40, XEND = 10.D0)
      TIME = 0.D0
      U = 0.D0
      CN = ' '
      OPEN (10, FILE='../verify/out_node.txt')
      DO 100 IOPT = 1, 3
         A(1) = 0.D0
         A(2) = YD
         DO 90 INC = 1, NINC
            XD = XEND*INC/NINC
            DO 10 IT = 0, 60
               CALL RESID(A, XD, YD, SK, EPS, IOPT, R, AK, H, ANX, ANY)
               RN = MAX(ABS(R(1)), ABS(R(2)))
               IF (IT .EQ. 0) RN0 = RN
               WRITE (10,'(A,3I4,4ES24.15)') 'R', IOPT, INC, IT, RN, H
               IF (RN .LE. 1.D-9*SK) GO TO 20
               DET = AK(1,1)*AK(2,2) - AK(1,2)*AK(2,1)
               DA(1) = -(AK(2,2)*R(1) - AK(1,2)*R(2))/DET
               DA(2) = -(-AK(2,1)*R(1) + AK(1,1)*R(2))/DET
               A(1) = A(1) + DA(1)
               A(2) = A(2) + DA(2)
   10       CONTINUE
   20       CONTINUE
            IF (IOPT .EQ. 1 .AND. INC .EQ. 8) AT = A
            WRITE (10,'(A,3I4,4ES24.15)') 'P', IOPT, INC, IT, A(1),
     1         A(2), H, XD
   90    CONTINUE
  100 CONTINUE
!     finite-difference check of the exact tangent in a state of the
!     path (increment 20, converged position stored in AT)
      XD = XEND*8/NINC
      CALL RESID(AT, XD, YD, SK, EPS, 1, R, AK, H, ANX, ANY)
      ERR = 0.D0
      DEL = 1.D-6
      DO 40 J = 1, 2
         A0 = AT
         A0(J) = AT(J) + DEL
         CALL RESID(A0, XD, YD, SK, EPS, 1, RP, AKX, H1, ANX, ANY)
         A0(J) = AT(J) - DEL
         CALL RESID(A0, XD, YD, SK, EPS, 1, RM, AKX, H1, ANX, ANY)
         DO 30 I = 1, 2
            FD = (RP(I) - RM(I))/(2.D0*DEL)
            ERR = MAX(ERR, ABS(FD - AK(I,J))/SK)
   30    CONTINUE
   40 CONTINUE
      WRITE (10,'(A,2ES24.15)') 'T', ERR, H
      CLOSE (10)
      END
!
      SUBROUTINE RESID(A, XD, YD, SK, EPS, IOPT, R, AK, H, ANX, ANY)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      CHARACTER*80 CN
      DIMENSION A(2), R(2), AK(2,2)
      DIMENSION P(3), TGT(3,2), DNDS(3,2), X(3,3), TIME(2), U(6,2)
      TIME = 0.D0
      U = 0.D0
      CN = ' '
      X = 0.D0
      X(1,1) = A(1)
      X(2,1) = A(2)
      CALL RSURFU(H, P, TGT, DNDS, X, TIME, U, CN, CN, CN, 0, 1, 0)
      TX = TGT(1,1)
      TY = TGT(2,1)
      ANX = -TY
      ANY = TX
      CAP = DNDS(1,1)*TX + DNDS(2,1)*TY
      IF (IOPT .EQ. 2) CAP = 0.D0
      IF (IOPT .EQ. 3) CAP = -CAP
      R(1) = SK*(XD - A(1))
      R(2) = SK*(YD - A(2))
      AK(1,1) = -SK
      AK(1,2) = 0.D0
      AK(2,1) = 0.D0
      AK(2,2) = -SK
      IF (H .GT. 0.D0) THEN
         R(1) = R(1) + EPS*H*ANX
         R(2) = R(2) + EPS*H*ANY
         FAC = H*CAP/(1.D0 - H*CAP)
         AK(1,1) = AK(1,1) + EPS*(-ANX*ANX + FAC*TX*TX)
         AK(1,2) = AK(1,2) + EPS*(-ANX*ANY + FAC*TX*TY)
         AK(2,1) = AK(2,1) + EPS*(-ANY*ANX + FAC*TY*TX)
         AK(2,2) = AK(2,2) + EPS*(-ANY*ANY + FAC*TY*TY)
      END IF
      RETURN
      END
