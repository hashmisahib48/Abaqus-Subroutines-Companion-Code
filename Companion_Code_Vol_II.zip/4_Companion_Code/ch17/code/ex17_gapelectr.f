      SUBROUTINE GAPELECTR(SIGMA,D,TEMP,PREDEF,TIME,CINAME,SECNAME,
     1 MAINNAME,COORDS,NODE,NPRED,KSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CINAME, SECNAME, MAINNAME
      DIMENSION SIGMA(5), D(2), TEMP(2), PREDEF(2,*), TIME(2),
     1 COORDS(*)
      DIMENSION PAR(6)
!
!     Electrical conductance of the contact spots, Eq. 17.8-1:
!     sigma_g = 1.25 sigma_s (m/sigma) (p/Hc)**0.95 / (1 + a (th-th0))
!     Copper on copper (current A, potential V, lengths mm).
      PARAMETER (ES = 5.8D4)           ! S/mm  conductivity of copper
      PARAMETER (ESIG = 1.D-3)         ! mm    combined rms roughness
      PARAMETER (ESLP = 0.12D0)        ! -     combined mean slope m
      PARAMETER (EHC = 1200.D0)        ! MPa   microhardness
      PARAMETER (EALP = 0.0039D0)      ! 1/K   resistivity coefficient
      PARAMETER (ETH0 = 20.D0)         ! deg C
!
      PAR(1) = ES
      PAR(2) = ESIG
      PAR(3) = ESLP
      PAR(4) = EHC
      PAR(5) = EALP
      PAR(6) = ETH0
      CALL K17_GAPE(D(2), TEMP(1), TEMP(2), PAR, SIGMA)
      RETURN
      END
