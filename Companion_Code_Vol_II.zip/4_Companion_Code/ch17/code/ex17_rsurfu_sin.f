      SUBROUTINE RSURFU(H,P,TGT,DNDS,X,TIME,U,CINAME,SECNAME,
     1 MAINNAME,NOEL,NODE,LCLOSE)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CINAME, SECNAME, MAINNAME
      DIMENSION P(3), TGT(3,2), DNDS(3,2), X(3,3), TIME(2), U(6,2)
!
!     Sinusoidal rigid surface y = AMP*SIN(2*PI*x/WLEN), body below,
!     plane or axisymmetric 2D model, rigid body translating only.
      PARAMETER (AMP = 1.5D0, WLEN = 10.D0)        ! mm
!
!     point A and the surface relative to the reference point
      XA = X(1,1) - X(1,2)
      YA = X(2,1) - X(2,2)
      CALL K17_SINE(XA, YA, AMP, WLEN, H, XP, YP, TX, TY, CURV)
!
      P(1) = X(1,2) + XP
      P(2) = X(2,2) + YP
      P(3) = 0.D0
      TGT(1,1) = TX
      TGT(2,1) = TY
      TGT(3,1) = 0.D0
      TGT(1,2) = 0.D0
      TGT(2,2) = 0.D0
      TGT(3,2) = -1.D0
      DNDS(1,1) = CURV*TX
      DNDS(2,1) = CURV*TY
      DNDS(3,1) = 0.D0
      DNDS(1,2) = 0.D0
      DNDS(2,2) = 0.D0
      DNDS(3,2) = 0.D0
      RETURN
      END
