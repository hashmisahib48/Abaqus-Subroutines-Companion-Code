      SUBROUTINE RSURFU(H,P,TGT,DNDS,X,TIME,U,CINAME,SECNAME,
     1 MAINNAME,NOEL,NODE,LCLOSE)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CINAME, SECNAME, MAINNAME
      DIMENSION P(3), TGT(3,2), DNDS(3,2), X(3,3), TIME(2), U(6,2)
      DIMENSION PL(3), T1(3), T2(3)
!
!     Solid torus about the z-axis through the reference point, 3D.
!     The body may translate and turn about its own axis only.
      PARAMETER (RMAJ = 40.D0, RMIN = 8.D0)        ! mm
!
      XA = X(1,1) - X(1,2)
      YA = X(2,1) - X(2,2)
      ZA = X(3,1) - X(3,2)
      CALL K17_TORUS(XA, YA, ZA, RMAJ, RMIN, H, PL, T1, T2, C1, C2)
!
      DO 10 K = 1, 3
         P(K) = X(K,2) + PL(K)
         TGT(K,1) = T1(K)
         TGT(K,2) = T2(K)
         DNDS(K,1) = C1*T1(K)
         DNDS(K,2) = C2*T2(K)
   10 CONTINUE
      RETURN
      END
