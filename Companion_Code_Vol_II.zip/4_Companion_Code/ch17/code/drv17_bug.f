!     drv17_bug.f   Runs the faulty routine of Problem 17B.2 (and prints
!     the same point for the correct one in verify/out_bug.txt).
      PROGRAM DRV17B
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      CHARACTER*80 CN
      DIMENSION P(3), TGT(3,2), DNDS(3,2), X(3,3), TIME(2), U(6,2)
      TIME = 0.D0
      U = 0.D0
      CN = ' '
      X = 0.D0
      X(1,1) = 2.D0
      X(2,1) = 0.8D0
      DNDS = 99.D0
      CALL RSURFU(H, P, TGT, DNDS, X, TIME, U, CN, CN, CN, 0, 1, 0)
      OPEN (10, FILE='../verify/out_bug.txt')
      WRITE (10,'(A,20ES16.8)') 'B', H, P(1), P(2), TGT(1,1), TGT(2,1),
     1   TGT(3,2), DNDS(1,1), DNDS(2,1), DNDS(3,1), DNDS(1,2)
      X(1,1) = 5.D0
      X(2,1) = -7.D0 + 0.8D0
      X(1,2) = 3.D0
      X(2,2) = -7.D0
      CALL RSURFU(H, P, TGT, DNDS, X, TIME, U, CN, CN, CN, 0, 1, 0)
      WRITE (10,'(A,20ES16.8)') 'M', H, P(1), P(2)
      CLOSE (10)
      END
