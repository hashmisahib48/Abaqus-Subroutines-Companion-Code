!     drv17_sin.f   Driver for the sinusoidal RSURFU (Section 17.4).
!     Calls the routine as Abaqus would: reference point away from the
!     origin, random points A.  Writes ../verify/out_sin.txt.
      PROGRAM DRV17S
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      CHARACTER*80 CN
      DIMENSION P(3), TGT(3,2), DNDS(3,2), X(3,3), TIME(2), U(6,2)
      DIMENSION PP(3), TG2(3,2), DN2(3,2), XX(3,3)
      INTEGER*8 ISEED
      COMMON /RNDC/ ISEED
      PARAMETER (AMP = 1.5D0, WLEN = 10.D0, RX = 3.D0, RY = -7.D0)
      PARAMETER (TWOPI = 6.283185307179586D0)
      F(XQ) = AMP*SIN(TWOPI*XQ/WLEN)
      FP(XQ) = AMP*TWOPI/WLEN*COS(TWOPI*XQ/WLEN)
      ISEED = 12345
      TIME = 0.D0
      U = 0.D0
      CN = ' '
      OPEN (10, FILE='../verify/out_sin.txt')
      NWRONG = 0
      NWB = 0
      NBAND = 0
      DO 10 I = 1, 3000
         XL = -12.D0 + 24.D0*RND()
         YL = -3.2D0 + 6.4D0*RND()
         X = 0.D0
         X(1,1) = RX + XL
         X(2,1) = RY + YL
         X(1,2) = RX
         X(2,2) = RY
         CALL RSURFU(H, P, TGT, DNDS, X, TIME, U, CN, CN, CN, 0, 1, 0)
         WRITE (10,'(A,12ES24.15)') 'S', XL, YL, H, P(1) - RX,
     1      P(2) - RY, TGT(1,1), TGT(2,1), DNDS(1,1), DNDS(2,1),
     2      TGT(3,2), P(3)
!        the naive routine: Newton from the vertical projection only
         CALL NAIVE(XL, YL, AMP, WLEN, XN, ICV)
         IF (ABS(XN - (P(1) - RX)) .GT. 1.D-6) NWRONG = NWRONG + 1
         IF (ABS(H) .LE. 0.6D0) THEN
            NBAND = NBAND + 1
            IF (ABS(XN - (P(1) - RX)) .GT. 1.D-6) NWB = NWB + 1
         END IF
   10 CONTINUE
      WRITE (10,'(A,3I8)') 'N', NWRONG, NBAND, NWB
!     finite-difference test of DNDS along the surface at depth H0
      H0 = 0.3D0
      DEL = 1.D-4
      ERRMAX = 0.D0
      DO 30 J = 0, 199
         XS = -12.D0 + 24.D0*(J + 0.5D0)/200.D0
         CALL ONORM(XS, AMP, WLEN, XX1, XX2)
         X = 0.D0
         X(1,2) = RX
         X(2,2) = RY
         X(1,1) = RX + XS - H0*XX1
         X(2,1) = RY + F(XS) - H0*XX2
         CALL RSURFU(H, P, TGT, DNDS, X, TIME, U, CN, CN, CN, 0, 1, 0)
         DO 20 K = 1, 2
            SGN = 3.D0 - 2.D0*K
            XQ = XS + SGN*DEL
            CALL ONORM(XQ, AMP, WLEN, Q1, Q2)
            XX = X
            XX(1,1) = RX + XQ - H0*Q1
            XX(2,1) = RY + F(XQ) - H0*Q2
            CALL RSURFU(H2, PP, TG2, DN2, XX, TIME, U, CN, CN, CN, 0,
     1         1, 0)
!           normal from the tangents: n = t1 x t2, t2 = (0,0,-1)
            IF (K .EQ. 1) THEN
               XNP = -TG2(2,1)
               YNP = TG2(1,1)
            ELSE
               XNM = -TG2(2,1)
               YNM = TG2(1,1)
            END IF
   20    CONTINUE
!        arc length between the two points (Simpson, 40 panels)
         DS = 0.D0
         NP = 40
         HH = 2.D0*DEL/NP
         DO 25 L = 0, NP
            XQ = XS - DEL + L*HH
            WQ = 1.D0
            IF (L .GT. 0 .AND. L .LT. NP) WQ = 2.D0 + 2.D0*MOD(L, 2)
            DS = DS + WQ*SQRT(1.D0 + FP(XQ)**2)
   25    CONTINUE
         DS = DS*HH/3.D0
         DNX = (XNP - XNM)/DS
         DNY = (YNP - YNM)/DS
         ERRMAX = MAX(ERRMAX, ABS(DNX - DNDS(1,1)), ABS(DNY - DNDS(2,1)))
   30 CONTINUE
      WRITE (10,'(A,ES24.15)') 'F', ERRMAX
!     translation invariance and sign: point on the surface and 0.2 mm
!     inside / outside along the normal
      CLOSE (10)
      END
!
      DOUBLE PRECISION FUNCTION RND()
      INTEGER*8 ISEED
      COMMON /RNDC/ ISEED
      ISEED = MOD(ISEED*16807_8, 2147483647_8)
      RND = DBLE(ISEED)/2147483647.D0
      END
!
      SUBROUTINE ONORM(XS, AMP, WLEN, NX, NY)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DOUBLE PRECISION NX, NY
      FPX = AMP*6.283185307179586D0/WLEN*COS(6.283185307179586D0*XS/
     1   WLEN)
      W = SQRT(1.D0 + FPX*FPX)
      NX = -FPX/W
      NY = 1.D0/W
      END
!
!     Naive projection: Newton on g(x) = 0 from the vertical foot point
      SUBROUTINE NAIVE(XA, YA, AMP, WLEN, X, ICV)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      WK = 6.283185307179586D0/WLEN
      X = XA
      ICV = 0
      DO 10 IT = 1, 50
         F = AMP*SIN(WK*X)
         FP = AMP*WK*COS(WK*X)
         FPP = -AMP*WK*WK*SIN(WK*X)
         G = (X - XA) + (F - YA)*FP
         GP = 1.D0 + FP*FP + (F - YA)*FPP
         IF (GP .EQ. 0.D0) RETURN
         XN = X - G/GP
         IF (ABS(XN - X) .LT. 1.D-13) THEN
            X = XN
            ICV = 1
            RETURN
         END IF
         X = XN
   10 CONTINUE
      END
