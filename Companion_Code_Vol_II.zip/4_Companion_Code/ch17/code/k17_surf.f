!     k17_surf.f   Closest-point projection on two analytical surfaces
!     (units: mm).  Double precision is declared here, so that the
!     helpers can be tested outside Abaqus without ABA_PARAM.INC.
      SUBROUTINE K17_SINE(XA, YA, AMP, WLEN, H, XP, YP, TX, TY, CURV)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (ZERO = 0.D0, ONE = 1.D0, HALF = 0.5D0)
      PARAMETER (TWOPI = 6.283185307179586D0, NSMAX = 4000)
!     Surface y = AMP*SIN(2*PI*x/WLEN), body below it, outward normal
!     n = (-f', 1)/w.  Point A = (XA,YA).  Out: H penetration (mm,
!     > 0 inside), foot point (XP,YP), unit tangent (TX,TY), and CURV
!     with dn/ds = CURV*t (> 0 at a crest, Eq. 17.4-2).
      WK = TWOPI/WLEN
      DV = ABS(YA - AMP*SIN(WK*XA))
!     the foot point lies within DV of XA: scan, then polish
      NS = MIN(MAX(INT(64.D0*DV/WLEN) + 4, 8), NSMAX)
      DX = 2.D0*DV/NS
      XS = XA - DV
      DBEST = 1.D300
      JB = 0
      DO 10 J = 0, NS
         X = XS + J*DX
         D2 = (X - XA)**2 + (AMP*SIN(WK*X) - YA)**2
         IF (D2 .LT. DBEST) THEN
            DBEST = D2
            JB = J
         END IF
   10 CONTINUE
      X = XS + JB*DX
      XLO = X - DX
      XHI = X + DX
      DO 20 IT = 1, 60
         F = AMP*SIN(WK*X)
         FP = AMP*WK*COS(WK*X)
         FPP = -AMP*WK*WK*SIN(WK*X)
         G = (X - XA) + (F - YA)*FP
         GP = ONE + FP*FP + (F - YA)*FPP
         IF (G .GT. ZERO) THEN
            XHI = X
         ELSE
            XLO = X
         END IF
         XN = HALF*(XLO + XHI)
         IF (GP .GT. ZERO) XN = X - G/GP
         IF (XN .LE. XLO .OR. XN .GE. XHI) XN = HALF*(XLO + XHI)
         IF (ABS(XN - X) .LE. 1.D-14*(ONE + ABS(X))) GO TO 30
         X = XN
   20 CONTINUE
   30 CONTINUE
      XP = X
      F = AMP*SIN(WK*XP)
      FP = AMP*WK*COS(WK*XP)
      FPP = -AMP*WK*WK*SIN(WK*XP)
      W = SQRT(ONE + FP*FP)
      YP = F
      TX = ONE/W
      TY = FP/W
      H = ((XP - XA)*(-FP) + (YP - YA))/W
      CURV = -FPP/W**3
      RETURN
      END
!
      SUBROUTINE K17_TORUS(XA, YA, ZA, RMAJ, RMIN, H, P, T1, T2, C1,
     1   C2)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (ZERO = 0.D0, ONE = 1.D0, TINY = 1.D-300)
      DIMENSION P(3), T1(3), T2(3)
!     Solid torus, axis z, centre circle of radius RMAJ, tube radius
!     RMIN; (XA,YA,ZA) relative to the centre.  Out: H = RMIN - |d|,
!     foot point P, tangents T1 (meridian) and T2 (circumferential)
!     with T1 x T2 = n, and the principal curvatures C1, C2 of Eq.
!     17.5-2 (dn/ds_i = C_i T_i).  At rho = 0 phi = 0 is chosen, and
!     on the centre circle n = e_z.
      RHO = SQRT(XA*XA + YA*YA)
      CPH = ONE
      SPH = ZERO
      IF (RHO .GT. TINY) THEN
         CPH = XA/RHO
         SPH = YA/RHO
      END IF
      DR = RHO - RMAJ
      DN = SQRT(DR*DR + ZA*ZA)
      CPS = ZERO
      SPS = ONE
      IF (DN .GT. TINY) THEN
         CPS = DR/DN
         SPS = ZA/DN
      END IF
      H = RMIN - DN
      RP = RMAJ + RMIN*CPS
      P(1) = RP*CPH
      P(2) = RP*SPH
      P(3) = RMIN*SPS
      T1(1) = SPS*CPH
      T1(2) = SPS*SPH
      T1(3) = -CPS
      T2(1) = -SPH
      T2(2) = CPH
      T2(3) = ZERO
      C1 = ONE/RMIN
      C2 = CPS/RP
      RETURN
      END
