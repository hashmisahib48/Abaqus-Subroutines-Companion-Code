!     k17_gap.f   Contact and gap conductance of rough surfaces
!     (units: N, mm, s, K; pressure MPa; gap conductance in
!     N/(s K mm) = 10**3 W/(m2 K); electrical in S/mm2).
      SUBROUTINE K17_SPOT(X, S, DSDX)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (ZERO = 0.D0, XLO = 1.D-6, EXPN = 0.95D0)
!     S = X**0.95 for X >= XLO, linear below (X = p/Hc, Eq. 17.7-2)
      IF (X .GE. XLO) THEN
         S = X**EXPN
         DSDX = EXPN*X**(EXPN - 1.D0)
      ELSE
         S = XLO**EXPN*MAX(X, ZERO)/XLO
         DSDX = XLO**EXPN/XLO
      END IF
      RETURN
      END
!
      SUBROUTINE K17_YGAP(X, Y, DYDX)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (XLO = 1.D-6, XHI = 2.D-2)
!     Y/sigma = 1.184*(-LN(3.132*X))**0.547, X clamped to [XLO,XHI]
      XC = MIN(MAX(X, XLO), XHI)
      Z = -LOG(3.132D0*XC)
      Y = 1.184D0*Z**0.547D0
      DYDX = 0.D0
      IF (X .GT. XLO .AND. X .LT. XHI)
     1   DYDX = -1.184D0*0.547D0*Z**(-0.453D0)/XC
      RETURN
      END
!
      SUBROUTINE K17_GAPK(DCL, PR, TA, TB, PAR, AK, AKC, AKG)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (ZERO = 0.D0, HALF = 0.5D0, TOFF = 273.15D0)
      DIMENSION PAR(8), AK(5)
!     Eqs. 17.7-1 to 17.7-4.  DCL clearance d (mm), PR pressure p
!     (MPa), TA, TB temperatures (deg C).  PAR: 1 ks (N/(s K)),
!     2 sigma (mm), 3 m (-), 4 Hc (MPa), 5 kg0 (N/(s K)), 6 T0 (K),
!     7 n (-), 8 M (mm).  Out: AK(1:5) as GAPCON; AKC, AKG the solid
!     and gas parts of AK(1).
      X = PR/PAR(4)
      CALL K17_SPOT(X, S, DSDX)
      CALL K17_YGAP(X, Y, DYDX)
      Y = Y*PAR(2)
      DYDP = DYDX*PAR(2)/PAR(4)
      A1 = 1.25D0*PAR(1)*PAR(3)/PAR(2)
      AKC = A1*S
      DKCDP = A1*DSDX/PAR(4)
      TM = MAX(HALF*(TA + TB) + TOFF, 1.D0)
      AKG0 = PAR(5)*(TM/PAR(6))**PAR(7)
      DE = MAX(DCL, ZERO)
      GP = DE + Y + PAR(8)
      AKG = AKG0/GP
      AK(1) = AKC + AKG
      AK(2) = ZERO
      IF (DCL .GT. ZERO) AK(2) = -AKG/GP
      AK(3) = DKCDP - AKG/GP*DYDP
      AK(4) = HALF*PAR(7)*AKG/TM
      AK(5) = AK(4)
      RETURN
      END
!
      SUBROUTINE K17_GAPE(PR, TA, TB, PAR, SIG)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (ZERO = 0.D0, HALF = 0.5D0)
      DIMENSION PAR(6), SIG(5)
!     Eqs. 17.8-1, 17.8-2.  PR pressure (MPa), TA, TB (deg C).
!     PAR: 1 sigma_s0 (S/mm), 2 sigma_r (mm), 3 m (-), 4 Hc (MPa),
!     5 alpha (1/K), 6 theta_0 (deg C).  Out: SIG(1:5) as GAPELECTR.
      X = PR/PAR(4)
      CALL K17_SPOT(X, S, DSDX)
      TM = HALF*(TA + TB)
      F = 1.D0/(1.D0 + PAR(5)*(TM - PAR(6)))
      A1 = 1.25D0*PAR(1)*PAR(3)/PAR(2)
      SIG(1) = A1*F*S
      SIG(2) = -HALF*PAR(5)*F*SIG(1)
      SIG(3) = SIG(2)
      SIG(4) = ZERO
      SIG(5) = A1*F*DSDX/PAR(4)
      RETURN
      END
!
