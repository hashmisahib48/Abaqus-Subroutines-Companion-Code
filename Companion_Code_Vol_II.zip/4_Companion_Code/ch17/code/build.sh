#!/bin/sh
# Compile every listing of Chapter 17 and run the drivers (gfortran, no Abaqus involved).
cd /home/claude/vol2/ch17/code || exit 1
INC=-I/home/claude/vol2/lib/aba
FS="-ffixed-form -std=legacy $INC"
FL="-ffixed-form -ffixed-line-length-none -std=legacy $INC"
for f in k17_surf k17_gap ex17_rsurfu_sin ex17_rsurfu_torus ex17_gapcon ex17_gapelectr prob_17b_bug; do gfortran -c $FS $f.f -o /tmp/$f.o || exit 1; done
gfortran $FL drv17_sin.f ex17_rsurfu_sin.f k17_surf.f -o /tmp/d17s && /tmp/d17s
gfortran $FL drv17_torus.f ex17_rsurfu_torus.f k17_surf.f -o /tmp/d17t && /tmp/d17t
gfortran $FL drv17_node.f ex17_rsurfu_sin.f k17_surf.f -o /tmp/d17n && /tmp/d17n
gfortran $FL drv17_gap.f ex17_gapcon.f ex17_gapelectr.f k17_gap.f -o /tmp/d17g && /tmp/d17g
gfortran $FL drv17_bug.f prob_17b_bug.f -o /tmp/d17b && /tmp/d17b
cd ../verify && python3 check17.py > out_check.txt 2>&1 && python3 prob17.py > out_prob.txt 2>&1
echo done
