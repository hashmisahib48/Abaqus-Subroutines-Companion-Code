      SUBROUTINE RSURFU(H,P,TGT,DNDS,X,TIME,U,CINAME,SECNAME,
     1 MAINNAME,NOEL,NODE,LCLOSE)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CINAME, SECNAME, MAINNAME
      DIMENSION P(3), TGT(3,2), DNDS(3,2), X(3,3), TIME(2), U(6,2)
!
!     Sinusoidal rigid surface y = AMP*SIN(2*PI*x/WLEN), body below.
!     It compiles.  How many faults are there?
      PARAMETER (AMP = 1.5D0, WLEN = 10.D0)
      PARAMETER (WK = 6.283185307179586D0/WLEN)
!
      XA = X(1,1)
      YA = X(2,1)
      F = AMP*SIN(WK*XA)
      FP = AMP*WK*COS(WK*XA)
      FPP = -AMP*WK*WK*SIN(WK*XA)
      W = SQRT(1.D0 + FP*FP)
      H = (YA - F)/W
      P(1) = XA
      P(2) = F
      P(3) = 0.D0
      TGT(1,1) = 1.D0/W
      TGT(2,1) = FP/W
      TGT(3,1) = 0.D0
      TGT(1,2) = 0.D0
      TGT(2,2) = 0.D0
      TGT(3,2) = 1.D0
      DNDS(1,1) = FPP/W**3*TGT(1,1)
      DNDS(2,1) = FPP/W**3*TGT(2,1)
      RETURN
      END
