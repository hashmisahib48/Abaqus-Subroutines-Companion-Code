      SUBROUTINE GAPCON(AK,D,FLOWM,TEMP,PREDEF,TIME,CINAME,SECNAME,
     1 MAINNAME,COORDS,NOEL,NODE,NPRED,KSTEP,KINC)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CINAME, SECNAME, MAINNAME
      DIMENSION AK(5), D(2), FLOWM(2), TEMP(2), PREDEF(2,*), TIME(2),
     1 COORDS(3)
      DIMENSION PAR(8)
!
!     Gap conductance k(d, p, theta) = k_c(p) + k_g/(d + Y(p) + M),
!     Eqs. 17.7-2 to 17.7-4.  Steel on steel, air in the gap.
      PARAMETER (SKS = 45.D0)          ! N/(s K)  = W/(m K), harmonic
      PARAMETER (SSIG = 1.D-3)         ! mm   combined rms roughness
      PARAMETER (SLP = 0.12D0)         ! -    combined mean slope m
      PARAMETER (SHC = 3000.D0)        ! MPa  microhardness
      PARAMETER (SKG0 = 0.0263D0)      ! N/(s K)  air at T0
      PARAMETER (ST0 = 300.D0)         ! K
      PARAMETER (SEXP = 0.8D0)         ! -    k_g ~ T**SEXP
      PARAMETER (SGM = 4.D-4)          ! mm   gas parameter M
!
      PAR(1) = SKS
      PAR(2) = SSIG
      PAR(3) = SLP
      PAR(4) = SHC
      PAR(5) = SKG0
      PAR(6) = ST0
      PAR(7) = SEXP
      PAR(8) = SGM
      CALL K17_GAPK(D(1), D(2), TEMP(1), TEMP(2), PAR, AK, AKC, AKG)
      RETURN
      END
