!     drv17_torus.f   Driver for the toroidal RSURFU (Section 17.5).
!     Writes ../verify/out_torus.txt.
      PROGRAM DRV17T
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      CHARACTER*80 CN
      DIMENSION P(3), TGT(3,2), DNDS(3,2), X(3,3), TIME(2), U(6,2)
      DIMENSION P2(3), TG2(3,2), DN2(3,2), XX(3,3), AN(3), ANP(3,4)
      INTEGER*8 ISEED
      COMMON /RNDC/ ISEED
      PARAMETER (RMAJ = 40.D0, RMIN = 8.D0)
      PARAMETER (RX = 5.D0, RY = -3.D0, RZ = 2.D0)
      ISEED = 777
      TIME = 0.D0
      U = 0.D0
      CN = ' '
      OPEN (10, FILE='../verify/out_torus.txt')
      I = 0
   10 CONTINUE
      XL = -56.D0 + 112.D0*RND()
      YL = -56.D0 + 112.D0*RND()
      ZL = -13.D0 + 26.D0*RND()
      RHO = SQRT(XL*XL + YL*YL)
      IF (SQRT((RHO - RMAJ)**2 + ZL*ZL) .GT. 12.D0) GO TO 10
      I = I + 1
      X = 0.D0
      X(1,1) = RX + XL
      X(2,1) = RY + YL
      X(3,1) = RZ + ZL
      X(1,2) = RX
      X(2,2) = RY
      X(3,2) = RZ
      CALL RSURFU(H, P, TGT, DNDS, X, TIME, U, CN, CN, CN, 0, 1, 0)
      WRITE (10,'(A,20ES24.15)') 'T', XL, YL, ZL, H, P(1) - RX,
     1   P(2) - RY, P(3) - RZ, (TGT(K,1), K = 1, 3), (TGT(K,2), K = 1,
     2   3), (DNDS(K,1), K = 1, 3), (DNDS(K,2), K = 1, 3)
      IF (I .LT. 3000) GO TO 10
!     finite-difference test of DNDS at depth H0 on the parametrisation
      H0 = 2.D0
      DEL = 1.D-5
      E1 = 0.D0
      E2 = 0.D0
      DO 40 J = 1, 200
         PHI = 6.283185307179586D0*RND()
         PSI = 6.283185307179586D0*RND()
         DO 30 K = 1, 4
            PH = PHI
            PS = PSI
            IF (K .EQ. 1) PS = PSI + DEL
            IF (K .EQ. 2) PS = PSI - DEL
            IF (K .EQ. 3) PH = PHI + DEL
            IF (K .EQ. 4) PH = PHI - DEL
            XX = X
            XX(1,2) = RX
            XX(2,2) = RY
            XX(3,2) = RZ
            RP = RMAJ + (RMIN - H0)*COS(PS)
            XX(1,1) = RX + RP*COS(PH)
            XX(2,1) = RY + RP*SIN(PH)
            XX(3,1) = RZ + (RMIN - H0)*SIN(PS)
            CALL RSURFU(H2, P2, TG2, DN2, XX, TIME, U, CN, CN, CN, 0, 1,
     1         0)
            ANP(1,K) = TG2(2,1)*TG2(3,2) - TG2(3,1)*TG2(2,2)
            ANP(2,K) = TG2(3,1)*TG2(1,2) - TG2(1,1)*TG2(3,2)
            ANP(3,K) = TG2(1,1)*TG2(2,2) - TG2(2,1)*TG2(1,2)
   30    CONTINUE
!        base point: tangents and DNDS at (PHI, PSI)
         RP = RMAJ + (RMIN - H0)*COS(PSI)
         XX(1,1) = RX + RP*COS(PHI)
         XX(2,1) = RY + RP*SIN(PHI)
         XX(3,1) = RZ + (RMIN - H0)*SIN(PSI)
         CALL RSURFU(H2, P2, TG2, DN2, XX, TIME, U, CN, CN, CN, 0, 1, 0)
         RPS = RMAJ + RMIN*COS(PSI)
         DO 35 K = 1, 3
!           s1 runs against psi (arc RMIN), s2 along phi (arc RPS)
            D1 = -(ANP(K,1) - ANP(K,2))/(2.D0*DEL)/RMIN
            D2 = (ANP(K,3) - ANP(K,4))/(2.D0*DEL)/RPS
            E1 = MAX(E1, ABS(D1 - DN2(K,1)))
            E2 = MAX(E2, ABS(D2 - DN2(K,2)))
   35    CONTINUE
   40 CONTINUE
      WRITE (10,'(A,2ES24.15)') 'F', E1, E2
!     degenerate points: on the axis, on the centre circle, at the
!     centre of the tube
      DO 50 K = 1, 3
         XL = 0.D0
         YL = 0.D0
         ZL = 1.D0
         IF (K .EQ. 2) THEN
            XL = RMAJ
            ZL = 0.D0
         ELSE IF (K .EQ. 3) THEN
            XL = RMAJ + RMIN
            ZL = 0.D0
         END IF
         X = 0.D0
         X(1,1) = RX + XL
         X(2,1) = RY + YL
         X(3,1) = RZ + ZL
         X(1,2) = RX
         X(2,2) = RY
         X(3,2) = RZ
         CALL RSURFU(H, P, TGT, DNDS, X, TIME, U, CN, CN, CN, 0, 1, 0)
         WRITE (10,'(A,I2,20ES16.8)') 'D', K, H, (P(M) - RX*0.D0, M = 1,
     1      3), (TGT(M,1), M = 1, 3), (DNDS(M,2), M = 1, 3)
   50 CONTINUE
      CLOSE (10)
      END
!
      DOUBLE PRECISION FUNCTION RND()
      INTEGER*8 ISEED
      COMMON /RNDC/ ISEED
      ISEED = MOD(ISEED*16807_8, 2147483647_8)
      RND = DBLE(ISEED)/2147483647.D0
      END
