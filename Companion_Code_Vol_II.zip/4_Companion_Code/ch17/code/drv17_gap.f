!     drv17_gap.f   Driver for GAPCON and GAPELECTR (Sections 17.6-17.8).
!     Writes ../verify/out_gap.txt.
      PROGRAM DRV17G
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      CHARACTER*80 CN
      DIMENSION AK(5), D(2), FM(2), TEMP(2), PRE(2,1), TIME(2), CO(3)
      DIMENSION SG(5), PAR(8), PARE(6), CASE(4,14), AKP(5), AKM(5)
      DIMENSION SGP(5), SGM(5), TS(2), R(2), AJ(2,2), DX(2), CNT(2)
      PARAMETER (SKS = 45.D0, SSIG = 1.D-3, SLP = 0.12D0, SHC = 3000.D0)
      PARAMETER (SKG0 = 0.0263D0, ST0 = 300.D0, SEXP = 0.8D0)
      PARAMETER (SGM0 = 4.D-4, ALORENZ = 2.44D-8)
      DATA CASE / 0.D0, 0.D0, 20.D0, 20.D0,
     1   0.1D0, 0.D0, 20.D0, 20.D0,
     2   0.01D0, 0.D0, 100.D0, 20.D0,
     3   0.D0, 0.01D0, 20.D0, 20.D0,
     4   0.D0, 0.1D0, 20.D0, 20.D0,
     5   0.D0, 1.D0, 20.D0, 20.D0,
     6   0.D0, 1.D0, 100.D0, 60.D0,
     7   0.D0, 10.D0, 20.D0, 20.D0,
     8   0.D0, 10.D0, 130.D0, 110.D0,
     9   0.D0, 50.D0, 20.D0, 20.D0,
     1   0.002D0, 1.D0, 20.D0, 20.D0,
     2   0.005D0, 10.D0, 80.D0, 60.D0,
     3   0.03D0, 0.5D0, 40.D0, 20.D0,
     4   -0.001D0, 5.D0, 20.D0, 20.D0 /
      CN = ' '
      TIME = 0.D0
      PRE = 0.D0
      FM = 0.D0
      CO = 0.D0
      PAR = (/ SKS, SSIG, SLP, SHC, SKG0, ST0, SEXP, SGM0 /)
      OPEN (10, FILE='../verify/out_gap.txt')
!     ---- A: the routine GAPCON at 14 states, with FD derivatives
      EMAX2 = 0.D0
      EMAX3 = 0.D0
      EMAX4 = 0.D0
      EMAX5 = 0.D0
      DO 20 IC = 1, 14
         D(1) = CASE(1,IC)
         D(2) = CASE(2,IC)
         TEMP(1) = CASE(3,IC)
         TEMP(2) = CASE(4,IC)
         CALL GAPCON(AK, D, FM, TEMP, PRE, TIME, CN, CN, CN, CO, 0, 1,
     1      0, 1, 1)
         CALL K17_GAPK(D(1), D(2), TEMP(1), TEMP(2), PAR, AKP, AKC,
     1      AKG)
         WRITE (10,'(A,I3,4ES14.6,7ES24.15)') 'G', IC, D(1), D(2),
     1      TEMP(1), TEMP(2), (AK(K), K = 1, 5), AKC, AKG
!        central differences of AK(1)
         IF (D(1) .GT. 0.D0) THEN
            DL = 1.D-6*D(1)
            CALL FDK(D(1)+DL, D(2), TEMP(1), TEMP(2), PAR, AKP)
            CALL FDK(D(1)-DL, D(2), TEMP(1), TEMP(2), PAR, AKM)
            EMAX2 = MAX(EMAX2, ABS((AKP(1)-AKM(1))/(2*DL)-AK(2))/
     1         ABS(AK(2)))
         END IF
         IF (D(2) .GT. 0.D0) THEN
            DL = 1.D-6*D(2)
            CALL FDK(D(1), D(2)+DL, TEMP(1), TEMP(2), PAR, AKP)
            CALL FDK(D(1), D(2)-DL, TEMP(1), TEMP(2), PAR, AKM)
            EMAX3 = MAX(EMAX3, ABS((AKP(1)-AKM(1))/(2*DL)-AK(3))/
     1         ABS(AK(3)))
         END IF
         DL = 1.D-3
         CALL FDK(D(1), D(2), TEMP(1)+DL, TEMP(2), PAR, AKP)
         CALL FDK(D(1), D(2), TEMP(1)-DL, TEMP(2), PAR, AKM)
         EMAX4 = MAX(EMAX4, ABS((AKP(1)-AKM(1))/(2*DL)-AK(4))/
     1      ABS(AK(4)))
         CALL FDK(D(1), D(2), TEMP(1), TEMP(2)+DL, PAR, AKP)
         CALL FDK(D(1), D(2), TEMP(1), TEMP(2)-DL, PAR, AKM)
         EMAX5 = MAX(EMAX5, ABS((AKP(1)-AKM(1))/(2*DL)-AK(5))/
     1      ABS(AK(5)))
   20 CONTINUE
      WRITE (10,'(A,4ES24.15)') 'FDG', EMAX2, EMAX3, EMAX4, EMAX5
!     ---- B: sweeps for the figure
      DO 30 J = 0, 60
         PR = 10.D0**(-3.D0 + 5.D0*J/60.D0)
         CALL K17_GAPK(0.D0, PR, 20.D0, 20.D0, PAR, AK, AKC, AKG)
         WRITE (10,'(A,4ES24.15)') 'SP', PR, AK(1), AKC, AKG
         CALL K17_GAPK(0.02D0, PR, 20.D0, 20.D0, PAR, AK, AKC, AKG)
         WRITE (10,'(A,4ES24.15)') 'SQ', PR, AK(1), AKC, AKG
   30 CONTINUE
      DO 40 J = 0, 60
         DD = 10.D0**(-4.D0 + 3.D0*J/60.D0)
         CALL K17_GAPK(DD, 0.D0, 20.D0, 20.D0, PAR, AK, AKC, AKG)
         WRITE (10,'(A,3ES24.15)') 'SD', DD, AK(1), AK(2)
   40 CONTINUE
!     ---- C: two plates and the interface; unknowns theta_A, theta_B
      TH = 150.D0
      TC = 20.D0
      CB1 = 45.D0/2.D0
      CB2 = 160.D0/3.D0
      DO 70 IV = 1, 2
         DO 60 IP = 0, 12
            PR = 10.D0**(-1.D0 + 2.7D0*IP/12.D0)
            IF (IP .EQ. 6) PR = 10.D0
            IF (IV .EQ. 1) THEN
               PAR(7) = SEXP
            ELSE
               PAR(7) = 0.D0
            END IF
            DO 55 IM = 1, 2
               TS(1) = 85.D0
               TS(2) = 85.D0
               DO 50 IT = 0, 60
                  CALL K17_GAPK(0.D0, PR, TS(1), TS(2), PAR, AK, AKC,
     1               AKG)
                  DT = TS(1) - TS(2)
                  Q = AK(1)*DT
                  R(1) = CB1*(TH - TS(1)) - Q
                  R(2) = Q - CB2*(TS(2) - TC)
                  RN = MAX(ABS(R(1)), ABS(R(2)))
                  IF (IP .EQ. 6 .AND. IV .EQ. 1) WRITE (10,
     1               '(A,3I4,3ES24.15)') 'H', IM, IT, IV, RN, TS(1),
     2               TS(2)
                  IF (RN .LE. 1.D-10*CB1*(TH - TC)) GO TO 51
                  QA = AK(1) + AK(4)*DT
                  QB = -AK(1) + AK(5)*DT
                  IF (IM .EQ. 2) THEN
                     QA = AK(1)
                     QB = -AK(1)
                  END IF
                  AJ(1,1) = -CB1 - QA
                  AJ(1,2) = -QB
                  AJ(2,1) = QA
                  AJ(2,2) = QB - CB2
                  DET = AJ(1,1)*AJ(2,2) - AJ(1,2)*AJ(2,1)
                  TS(1) = TS(1) - (AJ(2,2)*R(1) - AJ(1,2)*R(2))/DET
                  TS(2) = TS(2) - (-AJ(2,1)*R(1) + AJ(1,1)*R(2))/DET
   50          CONTINUE
   51          CNT(IM) = IT
   55       CONTINUE
            WRITE (10,'(A,2I3,I3,6ES24.15)') 'C', IV, IP, INT(CNT(1)),
     1         PR, TS(1), TS(2), Q, AK(1), CNT(2)
   60    CONTINUE
   70 CONTINUE
      PAR(7) = SEXP
!     ---- E: GAPELECTR at 8 states with FD derivatives
      DO 80 IC = 1, 8
         D(1) = 0.D0
         D(2) = 10.D0**(-2.D0 + 0.5D0*(IC - 1))
         TEMP(1) = 20.D0 + 10.D0*IC
         TEMP(2) = 20.D0 + 4.D0*IC
         IF (IC .EQ. 1) D(2) = 0.D0
         CALL GAPELECTR(SG, D, TEMP, PRE, TIME, CN, CN, CN, CO, 1, 1,
     1      1, 1)
         WRITE (10,'(A,I3,3ES14.6,5ES24.15)') 'E', IC, D(2), TEMP(1),
     1      TEMP(2), (SG(K), K = 1, 5)
   80 CONTINUE
      PARE = (/ 5.8D4, 1.D-3, 0.12D0, 1200.D0, 0.0039D0, 20.D0 /)
      EMAX2 = 0.D0
      EMAX3 = 0.D0
      EMAX5 = 0.D0
      DO 85 IC = 2, 8
         PR = 10.D0**(-2.D0 + 0.5D0*(IC - 1))
         TA = 20.D0 + 10.D0*IC
         TB = 20.D0 + 4.D0*IC
         CALL K17_GAPE(PR, TA, TB, PARE, SG)
         DL = 1.D-6*PR
         CALL K17_GAPE(PR+DL, TA, TB, PARE, SGP)
         CALL K17_GAPE(PR-DL, TA, TB, PARE, SGM)
         EMAX5 = MAX(EMAX5, ABS((SGP(1)-SGM(1))/(2*DL)-SG(5))/SG(5))
         CALL K17_GAPE(PR, TA+1.D-3, TB, PARE, SGP)
         CALL K17_GAPE(PR, TA-1.D-3, TB, PARE, SGM)
         EMAX2 = MAX(EMAX2, ABS((SGP(1)-SGM(1))/2.D-3-SG(2))/
     1      ABS(SG(2)))
         CALL K17_GAPE(PR, TA, TB+1.D-3, PARE, SGP)
         CALL K17_GAPE(PR, TA, TB-1.D-3, PARE, SGM)
         EMAX3 = MAX(EMAX3, ABS((SGP(1)-SGM(1))/2.D-3-SG(3))/
     1      ABS(SG(3)))
   85 CONTINUE
      WRITE (10,'(A,3ES24.15)') 'FDE', EMAX2, EMAX3, EMAX5
!     Wiedemann-Franz: thermal solid-spot conductance with the thermal
!     conductivity ks = L T sigma_s against the electrical one
      TK = 300.D0
      TTH = TK - 273.15D0
      PARE(5) = 0.D0
      PAR(1) = 1.D3*ALORENZ*TK*PARE(1)
      PAR(5) = 0.D0
      PAR(4) = 1200.D0
      PR = 10.D0
      CALL K17_GAPK(0.D0, PR, TTH, TTH, PAR, AK, AKC, AKG)
      CALL K17_GAPE(PR, TTH, TTH, PARE, SG)
      WRITE (10,'(A,4ES24.15)') 'WF', AKC, SG(1), AKC/SG(1),
     1   1.D3*ALORENZ*TK
!     series circuit: two copper plates (t = 2 mm) and the interface
      CALL K17_GAPE(10.D0, 20.D0, 20.D0, (/ 5.8D4, 1.D-3, 0.12D0,
     1   1200.D0, 0.0039D0, 20.D0 /), SG)
      WRITE (10,'(A,2ES24.15)') 'SC', SG(1), 0.001D0/(2.D0*2.D0/5.8D4 +
     1   1.D0/SG(1))
      CLOSE (10)
      END
!
      SUBROUTINE FDK(DD, PR, TA, TB, PAR, AK)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PAR(8), AK(5)
      CALL K17_GAPK(DD, PR, TA, TB, PAR, AK, AKC, AKG)
      RETURN
      END
