      SUBROUTINE K1_INV3(F, FI, DET)
!     Determinant and inverse of a 3 x 3 matrix by cofactors.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), FI(3,3)
      FI(1,1) = F(2,2)*F(3,3) - F(2,3)*F(3,2)
      FI(1,2) = F(1,3)*F(3,2) - F(1,2)*F(3,3)
      FI(1,3) = F(1,2)*F(2,3) - F(1,3)*F(2,2)
      FI(2,1) = F(2,3)*F(3,1) - F(2,1)*F(3,3)
      FI(2,2) = F(1,1)*F(3,3) - F(1,3)*F(3,1)
      FI(2,3) = F(1,3)*F(2,1) - F(1,1)*F(2,3)
      FI(3,1) = F(2,1)*F(3,2) - F(2,2)*F(3,1)
      FI(3,2) = F(1,2)*F(3,1) - F(1,1)*F(3,2)
      FI(3,3) = F(1,1)*F(2,2) - F(1,2)*F(2,1)
      DET = F(1,1)*FI(1,1) + F(1,2)*FI(2,1) + F(1,3)*FI(3,1)
      DO I = 1, 3
         DO J = 1, 3
            FI(I,J) = FI(I,J)/DET
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K1_KIN(F, AJ, BI1, BI2, CB)
!     Volume ratio, isochoric invariants and the isochoric right
!     Cauchy-Green tensor CB = J**(-2/3) F'F of the deformation
!     gradient F.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), FI(3,3), CB(3,3)
      CALL K1_INV3(F, FI, AJ)
      FAC = AJ**(-2.D0/3.D0)
      DO I = 1, 3
         DO J = 1, 3
            CB(I,J) = FAC*(F(1,I)*F(1,J) + F(2,I)*F(2,J)
     1                     + F(3,I)*F(3,J))
         ENDDO
      ENDDO
      BI1 = CB(1,1) + CB(2,2) + CB(3,3)
      T2 = 0.D0
      DO I = 1, 3
         DO J = 1, 3
            T2 = T2 + CB(I,J)*CB(J,I)
         ENDDO
      ENDDO
      BI2 = 0.5D0*(BI1*BI1 - T2)
      RETURN
      END
!
      SUBROUTINE K1_FIBRE(CB, A0, BI4, BI5)
!     Fibre pseudo-invariants for the reference direction A0
!     (unit).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION CB(3,3), A0(3), CA(3)
      DO I = 1, 3
         CA(I) = CB(I,1)*A0(1) + CB(I,2)*A0(2) + CB(I,3)*A0(3)
      ENDDO
      BI4 = A0(1)*CA(1) + A0(2)*CA(2) + A0(3)*CA(3)
      BI5 = CA(1)*CA(1) + CA(2)*CA(2) + CA(3)*CA(3)
      RETURN
      END
!
      SUBROUTINE K1_JACOBI(A, N, NP, D, V)
!     Eigenvalues D (ascending) and eigenvectors V (columns) of
!     the symmetric N x N matrix A(NP,NP) by cyclic Jacobi
!     rotations. A is destroyed.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(NP,NP), D(N), V(NP,N)
      DO I = 1, N
         DO J = 1, N
            V(I,J) = 0.D0
         ENDDO
         V(I,I) = 1.D0
      ENDDO
      DO ISWEEP = 1, 60
         OFF = 0.D0
         DIAG = 0.D0
         DO I = 1, N
            DIAG = DIAG + A(I,I)**2
            DO J = I+1, N
               OFF = OFF + A(I,J)**2
            ENDDO
         ENDDO
         IF (OFF .LE. 1.D-30*DIAG .OR. OFF .EQ. 0.D0) GOTO 50
         DO IP = 1, N-1
            DO IQ = IP+1, N
               IF (ABS(A(IP,IQ)) .GT. 1.D-300) THEN
                  TH = 0.5D0*(A(IQ,IQ) - A(IP,IP))/A(IP,IQ)
                  T = SIGN(1.D0, TH)/(ABS(TH) + SQRT(TH*TH + 1.D0))
                  CS = 1.D0/SQRT(T*T + 1.D0)
                  SN = T*CS
                  DO K = 1, N
                     AKP = A(K,IP)
                     AKQ = A(K,IQ)
                     A(K,IP) = CS*AKP - SN*AKQ
                     A(K,IQ) = SN*AKP + CS*AKQ
                  ENDDO
                  DO K = 1, N
                     APK = A(IP,K)
                     AQK = A(IQ,K)
                     A(IP,K) = CS*APK - SN*AQK
                     A(IQ,K) = SN*APK + CS*AQK
                  ENDDO
                  DO K = 1, N
                     VKP = V(K,IP)
                     VKQ = V(K,IQ)
                     V(K,IP) = CS*VKP - SN*VKQ
                     V(K,IQ) = SN*VKP + CS*VKQ
                  ENDDO
               ENDIF
            ENDDO
         ENDDO
      ENDDO
   50 CONTINUE
      DO I = 1, N
         D(I) = A(I,I)
      ENDDO
      DO I = 1, N-1
         K = I
         DO J = I+1, N
            IF (D(J) .LT. D(K)) K = J
         ENDDO
         IF (K .NE. I) THEN
            TMP = D(I)
            D(I) = D(K)
            D(K) = TMP
            DO J = 1, N
               TMP = V(J,I)
               V(J,I) = V(J,K)
               V(J,K) = TMP
            ENDDO
         ENDIF
      ENDDO
      RETURN
      END
!
      SUBROUTINE K1_PSTRETCH(F, DLAM, EV)
!     Principal stretches DLAM (descending) and the principal
!     directions EV (columns, reference configuration) of F.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), DLAM(3), EV(3,3), C(3,3), D(3), V(3,3)
      DO I = 1, 3
         DO J = 1, 3
            C(I,J) = F(1,I)*F(1,J) + F(2,I)*F(2,J) + F(3,I)*F(3,J)
         ENDDO
      ENDDO
      CALL K1_JACOBI(C, 3, 3, D, V)
      DO K = 1, 3
         DLAM(K) = SQRT(D(4-K))
         DO I = 1, 3
            EV(I,K) = V(I,4-K)
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K1_DINV(F, A0, G)
!     Gradients of J, I1bar, I2bar, I4bar and I5bar with respect
!     to F: G(I,J,K) = d(invariant K)/d F(I,J), K = 1..5.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), A0(3), G(3,3,5), FI(3,3), C(3,3), CB(3,3)
      DIMENSION FA(3), CA(3), FCA(3)
      CALL K1_INV3(F, FI, AJ)
      CALL K1_KIN(F, AJ, BI1, BI2, CB)
      CALL K1_FIBRE(CB, A0, BI4, BI5)
      FAC = AJ**(-2.D0/3.D0)
      DO I = 1, 3
         DO J = 1, 3
            C(I,J) = F(1,I)*F(1,J) + F(2,I)*F(2,J) + F(3,I)*F(3,J)
         ENDDO
      ENDDO
      CT = C(1,1) + C(2,2) + C(3,3)
      DO I = 1, 3
         FA(I) = F(I,1)*A0(1) + F(I,2)*A0(2) + F(I,3)*A0(3)
         CA(I) = C(I,1)*A0(1) + C(I,2)*A0(2) + C(I,3)*A0(3)
      ENDDO
      DO I = 1, 3
         FCA(I) = F(I,1)*CA(1) + F(I,2)*CA(2) + F(I,3)*CA(3)
      ENDDO
      ACA = A0(1)*CA(1) + A0(2)*CA(2) + A0(3)*CA(3)
      DO I = 1, 3
         DO J = 1, 3
            FIT = FI(J,I)
            FC = F(I,1)*C(1,J) + F(I,2)*C(2,J) + F(I,3)*C(3,J)
            G(I,J,1) = AJ*FIT
            G(I,J,2) = 2.D0*FAC*(F(I,J) - CT*FIT/3.D0)
            G(I,J,3) = 2.D0*FAC*FAC*(CT*F(I,J) - FC) - 4.D0*BI2*FIT/3.D0
            G(I,J,4) = 2.D0*FAC*(FA(I)*A0(J) - ACA*FIT/3.D0)
            G(I,J,5) = 2.D0*FAC*FAC*(FCA(I)*A0(J) + FA(I)*CA(J))
     1               - 4.D0*BI5*FIT/3.D0
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K1_STRESS(F, W1, W2, WJ, SIG)
!     Cauchy stress of an isotropic hyperelastic material from
!     the derivatives W1 = dU/dI1bar, W2 = dU/dI2bar, WJ =
!     dU/dJ, Eq. 1.4-1.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), SIG(3,3), CB(3,3), B(3,3), BB(3,3), S(3,3)
      CALL K1_KIN(F, AJ, BI1, BI2, CB)
      FAC = AJ**(-2.D0/3.D0)
      DO I = 1, 3
         DO J = 1, 3
            B(I,J) = FAC*(F(I,1)*F(J,1) + F(I,2)*F(J,2)
     1                    + F(I,3)*F(J,3))
         ENDDO
      ENDDO
      DO I = 1, 3
         DO J = 1, 3
            BB(I,J) = B(I,1)*B(1,J) + B(I,2)*B(2,J) + B(I,3)*B(3,J)
            S(I,J) = (W1 + BI1*W2)*B(I,J) - W2*BB(I,J)
         ENDDO
      ENDDO
      TR = (S(1,1) + S(2,2) + S(3,3))/3.D0
      DO I = 1, 3
         DO J = 1, 3
            SIG(I,J) = 2.D0*(S(I,J) - TR*DELTA(I,J))/AJ
         ENDDO
         SIG(I,I) = SIG(I,I) + WJ
      ENDDO
      RETURN
      END
!
      FUNCTION DELTA(I, J)
      INCLUDE 'ABA_PARAM.INC'
      DELTA = 0.D0
      IF (I .EQ. J) DELTA = 1.D0
      RETURN
      END
!
      SUBROUTINE K1_FDGRAD(FUN, X, N, H, G, ICENT)
!     Finite-difference gradient of the scalar function
!     FUN(X,N,F). ICENT = 1 central, otherwise forward.  The
!     step of component I is H*MAX(|X(I)|,1).
      INCLUDE 'ABA_PARAM.INC'
      EXTERNAL FUN
      DIMENSION X(N), G(N), XW(64)
      DO I = 1, N
         XW(I) = X(I)
      ENDDO
      CALL FUN(XW, N, F0)
      DO I = 1, N
         HI = H*MAX(ABS(X(I)), 1.D0)
         XW(I) = X(I) + HI
         CALL FUN(XW, N, FP)
         IF (ICENT .EQ. 1) THEN
            XW(I) = X(I) - HI
            CALL FUN(XW, N, FM)
            G(I) = (FP - FM)/(2.D0*HI)
         ELSE
            G(I) = (FP - F0)/HI
         ENDIF
         XW(I) = X(I)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K1_FDJAC(FUN, X, N, M, H, A)
!     Central-difference Jacobian A(M,N) of the vector function
!     FUN(X,N,Y,M).
      INCLUDE 'ABA_PARAM.INC'
      EXTERNAL FUN
      DIMENSION X(N), A(M,N), XW(64), YP(64), YM(64)
      DO I = 1, N
         XW(I) = X(I)
      ENDDO
      DO J = 1, N
         HJ = H*MAX(ABS(X(J)), 1.D0)
         XW(J) = X(J) + HJ
         CALL FUN(XW, N, YP, M)
         XW(J) = X(J) - HJ
         CALL FUN(XW, N, YM, M)
         DO I = 1, M
            A(I,J) = (YP(I) - YM(I))/(2.D0*HJ)
         ENDDO
         XW(J) = X(J)
      ENDDO
      RETURN
      END
