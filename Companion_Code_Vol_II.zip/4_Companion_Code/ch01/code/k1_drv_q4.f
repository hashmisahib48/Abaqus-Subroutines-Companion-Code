      PROGRAM K1_DRV_Q4
!     Example 1.7-1: stiffness, rigid-body modes, hourglass
!     modes and the constant-strain test of the 4-node element
!     tools.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), D(3,3), AK(8,8), A(8,8), EVL(8), V(8,8)
      DIMENSION B(3,8), U(8), XD(2,4)
      DATA X /0.D0,0.D0, 1.D0,0.D0, 1.D0,1.D0, 0.D0,1.D0/
      DATA XD /0.D0,0.D0, 2.D0,0.D0, 2.5D0,1.5D0, 0.3D0,1.2D0/
      CALL K1_DPS(210000.D0, 0.3D0, D)
      DO IX = 1, 2
         DO NG = 2, 1, -1
            IF (IX .EQ. 1) THEN
               CALL K1_KQ4(X, D, 1.D0, NG, AK)
            ELSE
               CALL K1_KQ4(XD, D, 1.D0, NG, AK)
            ENDIF
            DO I = 1, 8
               DO J = 1, 8
                  A(I,J) = AK(I,J)
               ENDDO
            ENDDO
            CALL K1_JACOBI(A, 8, 8, EVL, V)
            ASYM = 0.D0
            DO I = 1, 8
               DO J = 1, 8
                  ASYM = MAX(ASYM, ABS(AK(I,J) - AK(J,I)))
               ENDDO
            ENDDO
            WRITE(*,'(A,I2,A,I2,A,ES9.2)') 'shape ', IX, '  NG = ', NG,
     1        '  max asymmetry = ', ASYM
            WRITE(*,'(A,8ES11.3)') 'eigenvalues: ', EVL
            IF (IX .EQ. 1 .AND. NG .EQ. 2) THEN
               WRITE(*,'(A,F12.4,A,F12.4)') 'K(1,1) = ', AK(1,1),
     1           '   hand: ', 210000.D0/0.91D0*0.45D0
               WRITE(*,'(A,F12.4,A,F12.4)') 'K(1,2) = ', AK(1,2),
     1           '   hand: ', 210000.D0/(8.D0*0.7D0)
            ENDIF
         ENDDO
      ENDDO
!     constant-strain test on the distorted element: u = (e1*x +
!     g*y/2, e2*y + g*x/2) with e1 = 1e-3, e2 = -2e-3, g =
!     1.5e-3
      DO I = 1, 4
         U(2*I-1) = 1.D-3*XD(1,I) + 0.75D-3*XD(2,I)
         U(2*I) = -2.D-3*XD(2,I) + 0.75D-3*XD(1,I)
      ENDDO
      EMAX = 0.D0
      DO KG = 1, 4
         XI = 0.5773502691896258D0*(2*MOD(KG-1,2) - 1)
         ETA = 0.5773502691896258D0*(2*((KG-1)/2) - 1)
         CALL K1_Q4B(XD, XI, ETA, B, DETJ)
         E1 = 0.D0
         E2 = 0.D0
         E3 = 0.D0
         DO J = 1, 8
            E1 = E1 + B(1,J)*U(J)
            E2 = E2 + B(2,J)*U(J)
            E3 = E3 + B(3,J)*U(J)
         ENDDO
         EMAX = MAX(EMAX, ABS(E1-1.D-3), ABS(E2+2.D-3), ABS(E3-1.5D-3))
      ENDDO
      WRITE(*,'(A,ES10.2)') 'constant strain test, max strain error = ',
     1   EMAX
      END
