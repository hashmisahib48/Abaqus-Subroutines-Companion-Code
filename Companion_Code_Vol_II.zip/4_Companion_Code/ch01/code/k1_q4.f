      SUBROUTINE K1_DPS(E, ANU, D)
!     Plane-stress elasticity matrix, engineering shear strain.
!     E in MPa, ANU dimensionless.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(3,3)
      DO I = 1, 3
         DO J = 1, 3
            D(I,J) = 0.D0
         ENDDO
      ENDDO
      FAC = E/(1.D0 - ANU*ANU)
      D(1,1) = FAC
      D(2,2) = FAC
      D(1,2) = FAC*ANU
      D(2,1) = FAC*ANU
      D(3,3) = 0.5D0*FAC*(1.D0 - ANU)
      RETURN
      END
!
      SUBROUTINE K1_Q4B(X, XI, ETA, B, DETJ)
!     Strain-displacement matrix B(3,8) and Jacobian determinant
!     of the 4-node quadrilateral at (XI,ETA); nodes counter-
!     clockwise, X in mm.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), B(3,8), XS(4), ES(4), DNXI(4), DNET(4)
      DATA XS /-1.D0, 1.D0, 1.D0, -1.D0/
      DATA ES /-1.D0, -1.D0, 1.D0, 1.D0/
      AJ11 = 0.D0
      AJ12 = 0.D0
      AJ21 = 0.D0
      AJ22 = 0.D0
      DO I = 1, 4
         DNXI(I) = 0.25D0*XS(I)*(1.D0 + ES(I)*ETA)
         DNET(I) = 0.25D0*ES(I)*(1.D0 + XS(I)*XI)
         AJ11 = AJ11 + DNXI(I)*X(1,I)
         AJ12 = AJ12 + DNXI(I)*X(2,I)
         AJ21 = AJ21 + DNET(I)*X(1,I)
         AJ22 = AJ22 + DNET(I)*X(2,I)
      ENDDO
      DETJ = AJ11*AJ22 - AJ12*AJ21
      DO I = 1, 4
         DNX = ( AJ22*DNXI(I) - AJ12*DNET(I))/DETJ
         DNY = (-AJ21*DNXI(I) + AJ11*DNET(I))/DETJ
         B(1,2*I-1) = DNX
         B(1,2*I)   = 0.D0
         B(2,2*I-1) = 0.D0
         B(2,2*I)   = DNY
         B(3,2*I-1) = DNY
         B(3,2*I)   = DNX
      ENDDO
      RETURN
      END
!
      SUBROUTINE K1_KQ4(X, D, T, NG, AK)
!     Stiffness matrix AK(8,8) of the 4-node plane element,
!     thickness T, NG = 2 (2 x 2 Gauss points) or NG = 1 (one
!     point, no hourglass control).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), D(3,3), AK(8,8), B(3,8), DB(3,8)
      PARAMETER (G2 = 0.5773502691896258D0)
      DO I = 1, 8
         DO J = 1, 8
            AK(I,J) = 0.D0
         ENDDO
      ENDDO
      DO IG = 1, NG*NG
         IF (NG .EQ. 1) THEN
            XI = 0.D0
            ETA = 0.D0
            W = 4.D0
         ELSE
            XI = G2*(2*MOD(IG-1,2) - 1)
            ETA = G2*(2*((IG-1)/2) - 1)
            W = 1.D0
         ENDIF
         CALL K1_Q4B(X, XI, ETA, B, DETJ)
         DO I = 1, 3
            DO J = 1, 8
               DB(I,J) = D(I,1)*B(1,J) + D(I,2)*B(2,J) + D(I,3)*B(3,J)
            ENDDO
         ENDDO
         DO I = 1, 8
            DO J = 1, 8
               AK(I,J) = AK(I,J) + W*T*DETJ*(B(1,I)*DB(1,J)
     1                 + B(2,I)*DB(2,J) + B(3,I)*DB(3,J))
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
