      SUBROUTINE K1_MRD(IBUG, PR, BI1, BI2, AJ, W, DW, D2W)
!     Energy of a compressible Mooney-Rivlin material and its
!     first and second derivatives with respect to (I1bar,
!     I2bar, J). PR = C10 (MPa), C01 (MPa), D1 (1/MPa).  IBUG
!     selects a planted fault for the demonstration: 0 none, 1
!     dU/dJ without the factor 2, 2 d2U/dJ2 without the factor
!     2.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PR(3), DW(3), D2W(3,3)
      W = PR(1)*(BI1 - 3.D0) + PR(2)*(BI2 - 3.D0) + (AJ - 1.D0)**2/PR(3)
      DW(1) = PR(1)
      DW(2) = PR(2)
      DW(3) = 2.D0*(AJ - 1.D0)/PR(3)
      IF (IBUG .EQ. 1) DW(3) = (AJ - 1.D0)/PR(3)
      DO I = 1, 3
         DO J = 1, 3
            D2W(I,J) = 0.D0
         ENDDO
      ENDDO
      D2W(3,3) = 2.D0/PR(3)
      IF (IBUG .EQ. 2) D2W(3,3) = 1.D0/PR(3)
      RETURN
      END
!
      SUBROUTINE K1_WI(X, N, W)
!     U as a function of the three arguments (I1bar, I2bar, J).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(N), DW(3), D2W(3,3)
      COMMON /K1PAR/ PR(3), IBUG
      CALL K1_MRD(IBUG, PR, X(1), X(2), X(3), W, DW, D2W)
      RETURN
      END
!
      SUBROUTINE K1_DWI(X, N, Y, M)
!     The three first derivatives as a vector function of the
!     arguments.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(N), Y(M), D2W(3,3)
      COMMON /K1PAR/ PR(3), IBUG
      CALL K1_MRD(IBUG, PR, X(1), X(2), X(3), W, Y, D2W)
      RETURN
      END
!
      SUBROUTINE K1_WF(X, N, W)
!     U as a function of the nine components of F (column-
!     major).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(N), F(3,3), CB(3,3), DW(3), D2W(3,3)
      COMMON /K1PAR/ PR(3), IBUG
      DO J = 1, 3
         DO I = 1, 3
            F(I,J) = X(3*(J-1) + I)
         ENDDO
      ENDDO
      CALL K1_KIN(F, AJ, BI1, BI2, CB)
      CALL K1_MRD(0, PR, BI1, BI2, AJ, W, DW, D2W)
      RETURN
      END
!
      PROGRAM K1_DRV_FD
!     Example 1.6-1: finite-difference tests of the energy
!     derivatives and of the stress derived from them.
      INCLUDE 'ABA_PARAM.INC'
      EXTERNAL K1_WI, K1_DWI, K1_WF
      DIMENSION F(3,3), X(9), P(9), SIG(3,3), SIGFD(3,3), FI(3,3)
      DIMENSION XI(3), GFD(3), HFD(3,3), DW(3), D2W(3,3), CB(3,3)
      DIMENSION PAN(9), PFD(9), DLAM(3), EV(3,3), D(3)
      DIMENSION V(3,3), SE(3), F0(3,3)
      COMMON /K1PAR/ PR(3), IBUG
      DATA F0 /1.30D0, 0.10D0, 0.00D0, 0.25D0, 0.80D0, -0.05D0,
     1         0.00D0, 0.15D0, 0.95D0/
      DO I = 1, 3
         DO J = 1, 3
            F(I,J) = F0(I,J)
         ENDDO
      ENDDO
      PR(1) = 0.5D0
      PR(2) = 0.1D0
      PR(3) = 0.02D0
      CALL K1_KIN(F, AJ, BI1, BI2, CB)
      XI(1) = BI1
      XI(2) = BI2
      XI(3) = AJ
!     --- A: derivatives of U with respect to the invariants
      DO IBUG = 0, 2
         CALL K1_MRD(IBUG, PR, BI1, BI2, AJ, W, DW, D2W)
         CALL K1_FDGRAD(K1_WI, XI, 3, 1.D-6, GFD, 1)
         CALL K1_FDJAC(K1_DWI, XI, 3, 3, 1.D-6, HFD)
         E1 = 0.D0
         E2 = 0.D0
         DO I = 1, 3
            E1 = MAX(E1, ABS(DW(I) - GFD(I)))
            DO J = 1, 3
               E2 = MAX(E2, ABS(D2W(I,J) - HFD(I,J)))
            ENDDO
         ENDDO
         WRITE(*,'(A,I2,A,ES10.3,A,ES10.3)') 'IBUG=', IBUG,
     1    '  max|dU - FD| = ', E1, '   max|d2U - FD| = ', E2
      ENDDO
!     --- B: stress from the derivatives against the derivative
!     of U(F)
      IBUG = 0
      CALL K1_MRD(0, PR, BI1, BI2, AJ, W, DW, D2W)
      CALL K1_STRESS(F, DW(1), DW(2), DW(3), SIG)
      DO J = 1, 3
         DO I = 1, 3
            X(3*(J-1)+I) = F(I,J)
         ENDDO
      ENDDO
      CALL K1_FDGRAD(K1_WF, X, 9, 1.D-6, P, 1)
      CALL K1_INV3(F, FI, AJ)
      EMAX = 0.D0
      SMAX = 0.D0
      DO I = 1, 3
         DO J = 1, 3
            SIGFD(I,J) = 0.D0
            DO K = 1, 3
               SIGFD(I,J) = SIGFD(I,J) + P(3*(K-1)+I)*F(J,K)/AJ
            ENDDO
            EMAX = MAX(EMAX, ABS(SIGFD(I,J) - SIG(I,J)))
            SMAX = MAX(SMAX, ABS(SIG(I,J)))
         ENDDO
      ENDDO
      WRITE(*,'(A,2ES12.3)') 'B: max|sig - sigFD|, max|sig| = ',
     1   EMAX, SMAX
      WRITE(*,'(A,9F10.5)') 'sig = ', ((SIG(I,J),J=1,3),I=1,3)
      WRITE(*,'(A,ES12.3)') 'asymmetry max|s12-s21|... = ',
     1   MAX(ABS(SIG(1,2)-SIG(2,1)), ABS(SIG(1,3)-SIG(3,1)),
     2       ABS(SIG(2,3)-SIG(3,2)))
!     bug 1 in the stress
      CALL K1_MRD(1, PR, BI1, BI2, AJ, W, DW, D2W)
      CALL K1_STRESS(F, DW(1), DW(2), DW(3), SIG)
      EMAX = 0.D0
      DO I = 1, 3
         DO J = 1, 3
            EMAX = MAX(EMAX, ABS(SIGFD(I,J) - SIG(I,J)))
         ENDDO
      ENDDO
      WRITE(*,'(A,ES12.3)') 'B: IBUG=1  max|sig - sigFD| = ', EMAX
!     --- C: step-size sweep of the first-derivative check
      CALL K1_MRD(0, PR, BI1, BI2, AJ, W, DW, D2W)
      CALL K1_STRESS(F, DW(1), DW(2), DW(3), SIG)
      DO I = 1, 3
         DO J = 1, 3
            PAN(3*(J-1)+I) = 0.D0
            DO K = 1, 3
               PAN(3*(J-1)+I) = PAN(3*(J-1)+I) + AJ*SIG(I,K)*FI(J,K)
            ENDDO
         ENDDO
      ENDDO
      PMAX = 0.D0
      DO I = 1, 9
         PMAX = MAX(PMAX, ABS(PAN(I)))
      ENDDO
      OPEN(10, FILE='fd_sweep.dat')
      DO K = 1, 12
         H = 10.D0**(-K)
         CALL K1_FDGRAD(K1_WF, X, 9, H, PFD, 0)
         CALL K1_FDGRAD(K1_WF, X, 9, H, P, 1)
         EF = 0.D0
         EC = 0.D0
         DO I = 1, 9
            EF = MAX(EF, ABS(PFD(I) - PAN(I)))
            EC = MAX(EC, ABS(P(I) - PAN(I)))
         ENDDO
         WRITE(10,'(ES10.2,2ES14.5)') H, EF/PMAX, EC/PMAX
         WRITE(*,'(A,ES9.1,2ES12.3)') 'h, forward, central: ', H,
     1      EF/PMAX, EC/PMAX
      ENDDO
      CLOSE(10)
!     --- D: uniaxial stress, lambda = 2, nearly incompressible
!     limit
      DO ID = 1, 2
         IF (ID .EQ. 1) PR(3) = 1.D-6
         IF (ID .EQ. 2) PR(3) = 0.02D0
         XLAM = 2.D0
         XLO = 0.3D0
         XHI = 1.2D0
         DO IT = 1, 200
            XMU = 0.5D0*(XLO + XHI)
            DO I = 1, 3
               DO J = 1, 3
                  F(I,J) = 0.D0
               ENDDO
            ENDDO
            F(1,1) = XLAM
            F(2,2) = XMU
            F(3,3) = XMU
            CALL K1_KIN(F, AJ, BI1, BI2, CB)
            CALL K1_MRD(0, PR, BI1, BI2, AJ, W, DW, D2W)
            CALL K1_STRESS(F, DW(1), DW(2), DW(3), SIG)
            IF (SIG(2,2) .GT. 0.D0) THEN
               XHI = XMU
            ELSE
               XLO = XMU
            ENDIF
         ENDDO
         WRITE(*,'(A,ES9.2,A,F10.6,A,F10.6,A,F10.6)') 'D1=', PR(3),
     1    '  mu=', XMU, '  J=', AJ, '  P11=', AJ*SIG(1,1)/XLAM
      ENDDO
      WRITE(*,'(A,F10.6)') 'closed form P11 (incompressible) = ',
     1   2.D0*(2.D0 - 0.25D0)*(PR(1) + PR(2)/2.D0)
!     --- E: principal Cauchy stresses, invariant form and
!     stretch form
      PR(1) = 0.5D0
      PR(2) = 0.D0
      PR(3) = 0.02D0
      DO I = 1, 3
         DO J = 1, 3
            F(I,J) = F0(I,J)
         ENDDO
      ENDDO
      CALL K1_KIN(F, AJ, BI1, BI2, CB)
      CALL K1_MRD(0, PR, BI1, BI2, AJ, W, DW, D2W)
      CALL K1_STRESS(F, DW(1), DW(2), DW(3), SIG)
      CALL K1_JACOBI(SIG, 3, 3, SE, V)
      CALL K1_PSTRETCH(F, DLAM, EV)
      SUMW = 0.D0
      DO K = 1, 3
         DLAM(K) = DLAM(K)*AJ**(-1.D0/3.D0)
         SUMW = SUMW + DLAM(K)*2.D0*PR(1)*DLAM(K)
      ENDDO
      DO K = 1, 3
         D(K) = (DLAM(K)*2.D0*PR(1)*DLAM(K) - SUMW/3.D0)/AJ + DW(3)
      ENDDO
      WRITE(*,'(A,3F12.6)') 'eig(sigma) ascending = ', SE
      WRITE(*,'(A,3F12.6)') 'Eq. 1.4-2 (lam desc.) = ', D(3), D(2), D(1)
      END
