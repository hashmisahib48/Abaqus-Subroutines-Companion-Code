      PROGRAM PROB_1B3_TEST
!     Runs the faulty routine of Problem 1B.3 on three test
!     states.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), A0(3), CB(3,3)
      DATA A0 /1.D0, 0.D0, 0.D0/
      DO IT = 1, 3
         DO I = 1, 3
            DO J = 1, 3
               F(I,J) = 0.D0
            ENDDO
         ENDDO
         IF (IT .EQ. 1) THEN
            F(1,1) = 1.D0
            F(2,2) = 1.D0
            F(3,3) = 1.D0
         ELSEIF (IT .EQ. 2) THEN
            F(1,1) = 1.1D0
            F(2,2) = 1.1D0
            F(3,3) = 1.1D0
         ELSE
            F(1,1) = 2.D0
            F(2,2) = 1.D0/SQRT(2.D0)
            F(3,3) = 1.D0/SQRT(2.D0)
         ENDIF
         CALL K1_KINBUG(F, AJ, B1, B2, B4, A0)
         CALL K1_KIN(F, AJ, C1, C2, CB)
         CALL K1_FIBRE(CB, A0, C4, C5)
         WRITE(*,'(I2,A,4F10.5,A,4F10.5)') IT, '  bug: ', AJ, B1, B2,
     1      B4, '   correct: ', AJ, C1, C2, C4
      ENDDO
      END
