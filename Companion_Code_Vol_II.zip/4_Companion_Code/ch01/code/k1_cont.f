      SUBROUTINE K1_PROJ2D(XS, XA, XB, S, H, AN, AT)
!     Closest-point projection of the secondary point XS onto
!     the straight main segment A-B (2-D, coordinates in mm).  S
!     in [0,1] is the position of the projection on the segment
!     (unclamped), H the gap (positive open, negative =
!     penetration), AN the unit normal that points out of the
!     main body (the body lies to the left of A->B) and AT the
!     unit tangent.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XS(2), XA(2), XB(2), AN(2), AT(2)
      DX = XB(1) - XA(1)
      DY = XB(2) - XA(2)
      AL = SQRT(DX*DX + DY*DY)
      AT(1) = DX/AL
      AT(2) = DY/AL
      AN(1) = AT(2)
      AN(2) = -AT(1)
      S = ((XS(1) - XA(1))*DX + (XS(2) - XA(2))*DY)/(AL*AL)
      H = (XS(1) - XA(1))*AN(1) + (XS(2) - XA(2))*AN(2)
      RETURN
      END
!
      SUBROUTINE K1_SLIP(S0, S1, XA1, XB1, DSLIP)
!     Tangential slip increment of a secondary point relative to
!     the main segment: the change of the projection position S
!     measured on the main material, times the segment length at
!     the end of the increment (mm).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XA1(2), XB1(2)
      AL1 = SQRT((XB1(1) - XA1(1))**2 + (XB1(2) - XA1(2))**2)
      DSLIP = (S1 - S0)*AL1
      RETURN
      END
