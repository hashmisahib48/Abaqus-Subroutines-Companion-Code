      PROGRAM K1_DRV_KIN
!     Example 1.3-1: invariants, principal stretches, their
!     gradients and their behaviour under rotations (Abaqus is
!     not involved).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), FR(3,3), CB(3,3), A0(3), DLAM(3), EV(3,3)
      DIMENSION G(3,3,5), GFD(3,3,5), Q(3,3), FP(3,3), FM(3,3), FI(3,3)
      DIMENSION CBP(3,3), CBM(3,3), A0R(3), X(2)
      DATA F /1.30D0, 0.10D0, 0.00D0, 0.25D0, 0.80D0, -0.05D0,
     1        0.00D0, 0.15D0, 0.95D0/
      PI = 4.D0*ATAN(1.D0)
      A0(1) = COS(PI/6.D0)
      A0(2) = SIN(PI/6.D0)
      A0(3) = 0.D0
      CALL K1_KIN(F, AJ, BI1, BI2, CB)
      CALL K1_FIBRE(CB, A0, BI4, BI5)
      CALL K1_PSTRETCH(F, DLAM, EV)
      WRITE(*,'(A,F12.8)') 'J    = ', AJ
      WRITE(*,'(A,F12.8)') 'I1b  = ', BI1
      WRITE(*,'(A,F12.8)') 'I2b  = ', BI2
      WRITE(*,'(A,F12.8)') 'I4b  = ', BI4
      WRITE(*,'(A,F12.8)') 'I5b  = ', BI5
      WRITE(*,'(A,3F12.8)') 'lam  = ', DLAM
      WRITE(*,'(A,3F12.8)') 'lamb = ', (DLAM(K)*AJ**(-1.D0/3.D0), K=1,3)
      WRITE(*,'(A,F12.8)') 'sum lam^2 / J^(2/3) - I1b = ',
     1   (DLAM(1)**2+DLAM(2)**2+DLAM(3)**2)*AJ**(-2.D0/3.D0) - BI1
      WRITE(*,'(A,F12.8)') 'fibre stretch sqrt(a.C.a) = ',
     1   SQRT(BI4*AJ**(2.D0/3.D0))
!     gradients: analytic against central differences, step 1e-6
      CALL K1_DINV(F, A0, G)
      H = 1.D-6
      DO I = 1, 3
         DO J = 1, 3
            DO K = 1, 3
               DO L = 1, 3
                  FP(K,L) = F(K,L)
                  FM(K,L) = F(K,L)
               ENDDO
            ENDDO
            FP(I,J) = F(I,J) + H
            FM(I,J) = F(I,J) - H
            CALL K1_KIN(FP, AJP, B1P, B2P, CBP)
            CALL K1_KIN(FM, AJM, B1M, B2M, CBM)
            CALL K1_FIBRE(CBP, A0, B4P, B5P)
            CALL K1_FIBRE(CBM, A0, B4M, B5M)
            GFD(I,J,1) = (AJP - AJM)/(2.D0*H)
            GFD(I,J,2) = (B1P - B1M)/(2.D0*H)
            GFD(I,J,3) = (B2P - B2M)/(2.D0*H)
            GFD(I,J,4) = (B4P - B4M)/(2.D0*H)
            GFD(I,J,5) = (B5P - B5M)/(2.D0*H)
         ENDDO
      ENDDO
      DO K = 1, 5
         DMAX = 0.D0
         GMAX = 0.D0
         DO I = 1, 3
            DO J = 1, 3
               DMAX = MAX(DMAX, ABS(G(I,J,K) - GFD(I,J,K)))
               GMAX = MAX(GMAX, ABS(G(I,J,K)))
            ENDDO
         ENDDO
         WRITE(*,'(A,I2,2ES12.3)') 'gradient K, max|diff|, max|G| = ',
     1      K, DMAX, GMAX
      ENDDO
!     rotation of the current configuration: F -> Q F (Q about
!     z, 40 deg)
      TH = 40.D0*PI/180.D0
      Q(1,1) = COS(TH)
      Q(1,2) = -SIN(TH)
      Q(2,1) = SIN(TH)
      Q(2,2) = COS(TH)
      Q(3,3) = 1.D0
      Q(1,3) = 0.D0
      Q(2,3) = 0.D0
      Q(3,1) = 0.D0
      Q(3,2) = 0.D0
      DO I = 1, 3
         DO J = 1, 3
            FR(I,J) = Q(I,1)*F(1,J) + Q(I,2)*F(2,J) + Q(I,3)*F(3,J)
         ENDDO
      ENDDO
      CALL K1_KIN(FR, AJR, R1, R2, CBP)
      CALL K1_FIBRE(CBP, A0, R4, R5)
      CALL K1_PSTRETCH(FR, DLAM, EV)
      WRITE(*,'(A,5ES12.3)') 'QF: change of J,I1,I2,I4,I5 = ',
     1   AJR-AJ, R1-BI1, R2-BI2, R4-BI4, R5-BI5
!     rotation of the reference configuration: F -> F Q, fibre
!     fixed
      DO I = 1, 3
         DO J = 1, 3
            FR(I,J) = F(I,1)*Q(1,J) + F(I,2)*Q(2,J) + F(I,3)*Q(3,J)
         ENDDO
      ENDDO
      CALL K1_KIN(FR, AJR, R1, R2, CBP)
      CALL K1_FIBRE(CBP, A0, R4, R5)
      WRITE(*,'(A,5ES12.3)') 'FQ: change of J,I1,I2,I4,I5 = ',
     1   AJR-AJ, R1-BI1, R2-BI2, R4-BI4, R5-BI5
!     ... and with the fibre rotated with the reference
!     configuration
      DO I = 1, 3
         A0R(I) = Q(1,I)*A0(1) + Q(2,I)*A0(2) + Q(3,I)*A0(3)
      ENDDO
      CALL K1_FIBRE(CBP, A0R, R4, R5)
      WRITE(*,'(A,2ES12.3)') 'FQ, fibre rotated: change of I4,I5 = ',
     1   R4-BI4, R5-BI5
!     hand-check states: uniaxial and equibiaxial,
!     incompressible, lam=2
      DO IM = 1, 3
         DO I = 1, 3
            DO J = 1, 3
               FR(I,J) = 0.D0
            ENDDO
         ENDDO
         IF (IM .EQ. 1) THEN
            FR(1,1) = 2.D0
            FR(2,2) = 1.D0/SQRT(2.D0)
            FR(3,3) = 1.D0/SQRT(2.D0)
         ELSEIF (IM .EQ. 2) THEN
            FR(1,1) = 2.D0
            FR(2,2) = 2.D0
            FR(3,3) = 0.25D0
         ELSE
            FR(1,1) = 2.D0
            FR(2,2) = 1.D0
            FR(3,3) = 0.5D0
         ENDIF
         A0R(1) = 1.D0
         A0R(2) = 0.D0
         A0R(3) = 0.D0
         CALL K1_KIN(FR, AJR, R1, R2, CBP)
         CALL K1_FIBRE(CBP, A0R, R4, R5)
         WRITE(*,'(A,I2,5F11.6)') 'mode J I1 I2 I4 I5: ', IM,
     1      AJR, R1, R2, R4, R5
      ENDDO
      END
