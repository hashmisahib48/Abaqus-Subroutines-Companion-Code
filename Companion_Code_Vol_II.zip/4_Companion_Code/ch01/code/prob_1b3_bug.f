      SUBROUTINE K1_KINBUG(F, AJ, BI1, BI2, BI4, A0)
!     Meant to return J, I1bar, I2bar and the fibre invariant
!     I4bar of F.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), A0(3), C(3,3), CB(3,3)
      AJ = F(1,1)*(F(2,2)*F(3,3) - F(2,3)*F(3,2))
     1   - F(1,2)*(F(2,1)*F(3,3) - F(2,3)*F(3,1))
     2   + F(1,3)*(F(2,1)*F(3,2) - F(2,2)*F(3,1))
      DO I = 1, 3
         DO J = 1, 3
            C(I,J) = F(I,1)*F(J,1) + F(I,2)*F(J,2) + F(I,3)*F(J,3)
            CB(I,J) = AJ**(-1.D0/3.D0)*C(I,J)
         ENDDO
      ENDDO
      BI1 = CB(1,1) + CB(2,2) + CB(3,3)
      BI2 = 0.5D0*(BI1*BI1 - (CB(1,1) + CB(2,2) + CB(3,3)))
      BI4 = 0.D0
      DO I = 1, 3
         DO J = 1, 3
            BI4 = BI4 + A0(I)*C(I,J)*A0(J)
         ENDDO
      ENDDO
      RETURN
      END
