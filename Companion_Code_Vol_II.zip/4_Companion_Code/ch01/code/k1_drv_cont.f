      PROGRAM K1_DRV_CONT
!     Closest-point projection and slip of a secondary point on
!     a main segment that translates (Section 1.8 and Problem
!     1A.3).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XS0(2), XS1(2), XA0(2), XB0(2), XA1(2), XB1(2)
      DIMENSION AN(2), AT(2)
      DATA XA0 /0.D0, 0.D0/, XB0 /1.D0, 0.2D0/
      DATA XA1 /0.1D0, 0.D0/, XB1 /1.1D0, 0.2D0/
      DATA XS0 /0.3D0, 0.1D0/, XS1 /0.55D0, 0.1D0/
      CALL K1_PROJ2D(XS0, XA0, XB0, S0, H0, AN, AT)
      WRITE(*,'(A,2F10.6,A,2F10.6)') 'n = ', AN, '  t = ', AT
      WRITE(*,'(A,F10.6,A,F10.6)') 's0 = ', S0, '   h0 = ', H0
      CALL K1_PROJ2D(XS1, XA1, XB1, S1, H1, AN, AT)
      WRITE(*,'(A,F10.6,A,F10.6)') 's1 = ', S1, '   h1 = ', H1
      CALL K1_SLIP(S0, S1, XA1, XB1, DS)
      WRITE(*,'(A,F10.6)') 'slip increment = ', DS
      END
