#!/bin/sh
# Compile every listing of Chapter 1 and run the drivers (gfortran 13, no Abaqus involved).
cd /home/claude/vol2/ch01/code || exit 1
INC=-I/home/claude/vol2/lib/aba
for f in k1_tools k1_q4 k1_cont prob_1b3_bug; do gfortran -c -ffixed-form -std=legacy $INC $f.f -o /tmp/$f.o || exit 1; done
gfortran -ffixed-form -std=legacy $INC k1_drv_kin.f k1_tools.f -o /tmp/k1kin && /tmp/k1kin > ../verify/out_kin.txt
gfortran -ffixed-form -std=legacy $INC k1_drv_fd.f k1_tools.f -o /tmp/k1fd && /tmp/k1fd > ../verify/out_fd.txt
gfortran -ffixed-form -std=legacy $INC k1_drv_q4.f k1_q4.f k1_tools.f -o /tmp/k1q4 && /tmp/k1q4 > ../verify/out_q4.txt
gfortran -ffixed-form -std=legacy $INC k1_drv_cont.f k1_cont.f -o /tmp/k1c && /tmp/k1c > ../verify/out_cont.txt
gfortran -ffixed-form -std=legacy $INC prob_1b3_test.f prob_1b3_bug.f k1_tools.f -o /tmp/p1b3 && /tmp/p1b3 > ../verify/out_p1b3.txt
python3 ../verify/check.py > ../verify/out_check.txt
echo done
