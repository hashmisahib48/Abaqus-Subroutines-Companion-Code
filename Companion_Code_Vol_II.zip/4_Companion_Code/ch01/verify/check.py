"""Independent numpy/scipy computations for Chapter 1 (cross-check of the Fortran drivers
and source of the numbers quoted in examples and problems)."""
import numpy as np
np.set_printoptions(precision=8, suppress=False, linewidth=140)
def kin(F,a=None):
    J=np.linalg.det(F); C=F.T@F; Cb=J**(-2/3)*C
    I1=np.trace(Cb); I2=.5*(I1**2-np.trace(Cb@Cb))
    out=dict(J=J,I1=I1,I2=I2,lam=np.sqrt(np.linalg.eigvalsh(C))[::-1])
    if a is not None: out['I4']=a@Cb@a; out['I5']=(Cb@a)@(Cb@a)
    return out
F=np.array([[1.30,0.25,0.00],[0.10,0.80,0.15],[0.00,-0.05,0.95]])
a=np.array([np.cos(np.pi/6),np.sin(np.pi/6),0])
print('Ex1.3-1',kin(F,a), 'fibre stretch', np.sqrt(a@F.T@F@a))
# problems
g=0.5; Fs=np.array([[1,g,0],[0,1,0],[0,0,1.]])
for a_ in ([1,0,0],[0,1,0],[1/np.sqrt(2),1/np.sqrt(2),0]):
    print('shear',kin(Fs,np.array(a_)))
# 1A.2
lam=1.5; C10=0.5; print('1A.2 sigma',2*C10*(lam**2-1/lam),'P',2*C10*(lam**2-1/lam)/lam)
# right rotation
th=np.radians(40); Q=np.array([[np.cos(th),-np.sin(th),0],[np.sin(th),np.cos(th),0],[0,0,1]])
k0=kin(F,a); k1=kin(F@Q,a); k2=kin(F@Q,Q.T@a); k3=kin(Q@F,a)
print('FQ dI4,dI5',k1['I4']-k0['I4'],k1['I5']-k0['I5'],'rot fibre',k2['I4']-k0['I4'],'QF',k3['I4']-k0['I4'])
# FD step optimum for exp(x) at 1
eps=np.finfo(float).eps
hs=10.0**-np.arange(1,17,0.25)
fw=[abs((np.exp(1+h)-np.exp(1))/h-np.e)/np.e for h in hs]
ce=[abs((np.exp(1+h)-np.exp(1-h))/(2*h)-np.e)/np.e for h in hs]
print('exp: forward min',min(fw),hs[int(np.argmin(fw))],' central min',min(ce),hs[int(np.argmin(ce))])
print('theory h_fwd',np.sqrt(2*eps),'h_cen',(3*eps)**(1/3))
# Q4
def q4(X,D,ng):
    K=np.zeros((8,8)); xs=np.array([-1,1,1,-1.]); es=np.array([-1,-1,1,1.])
    pts=[(0,0,4.)] if ng==1 else [(sx/np.sqrt(3),sy/np.sqrt(3),1.) for sy in (-1,1) for sx in (-1,1)]
    for xi,eta,w in pts:
        dxi=.25*xs*(1+es*eta); det_=.25*es*(1+xs*xi)
        Jm=np.array([[dxi@X[:,0],dxi@X[:,1]],[det_@X[:,0],det_@X[:,1]]])
        dN=np.linalg.solve(Jm,np.vstack([dxi,det_]))
        B=np.zeros((3,8)); B[0,0::2]=dN[0]; B[1,1::2]=dN[1]; B[2,0::2]=dN[1]; B[2,1::2]=dN[0]
        K+=w*np.linalg.det(Jm)*B.T@D@B
    return K
E,nu=210000.,0.3; D=E/(1-nu**2)*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
X=np.array([[0,0],[1,0],[1,1],[0,1.]]); XD=np.array([[0,0],[2,0],[2.5,1.5],[0.3,1.2]])
for nm,XX in (('square',X),('distorted',XD)):
    for ng in (2,1): print(nm,ng,np.linalg.eigvalsh(q4(XX,D,ng)))
K=q4(X,D,2); print('K11',K[0,0],E/(1-nu**2)*(0.5-nu/6),'K12',K[0,1],E/(8*(1-nu)))
# plane strain
Dpe=E/((1+nu)*(1-2*nu))*np.array([[1-nu,nu,0],[nu,1-nu,0],[0,0,(1-2*nu)/2]])
Kp=q4(X,Dpe,2); print('plane strain K11,K12',Kp[0,0],Kp[0,1],np.linalg.eigvalsh(Kp))
# Gent vs Yeoh
mu,Jm=0.7,30.
def gent(lam,mode):
    if mode=='u': I1=lam**2+2/lam; return mu*(lam-lam**-2)/(1-(I1-3)/Jm)
    if mode=='b': I1=2*lam**2+lam**-4; return mu*(lam-lam**-5)/(1-(I1-3)/Jm)
    if mode=='p': I1=lam**2+1+lam**-2; return mu*(lam-lam**-3)/(1-(I1-3)/Jm)
print('Gent P(3)',gent(3,'u'),'P(5)',gent(5,'u'),'lock stretch',np.sqrt(Jm+3))
def yeoh_rows(lam,mode):
    if mode=='u': I1=lam**2+2/lam; f=2*(lam-lam**-2)
    if mode=='b': I1=2*lam**2+lam**-4; f=2*(lam-lam**-5)
    if mode=='p': I1=lam**2+1+lam**-2; f=2*(lam-lam**-3)
    x=I1-3
    return f*np.array([1,2*x,3*x**2])
def fit(lmax):
    # lam grid per mode: biaxial and planar limited to same I1 range as uniaxial lmax
    A=[];b=[]
    I1max=lmax**2+2/lmax
    for mode in 'ubp':
        for lam in np.linspace(1.02,lmax,60):
            I1={'u':lam**2+2/lam,'b':2*lam**2+lam**-4,'p':lam**2+1+lam**-2}[mode]
            if I1>I1max+1e-9: continue
            g=gent(lam,mode); A.append(yeoh_rows(lam,mode)/g); b.append(1.0)
    c=np.linalg.lstsq(np.array(A),np.array(b),rcond=None)[0]; return c
def yeoh(c,lam,mode): return yeoh_rows(lam,mode)@c
for lmax in (3.,5.):
    c=fit(lmax); print('fit to',lmax,c)
    for lam in (1.5,2,3,4,5):
        print(lam,'Gent u %.4f Yeoh u %.4f err %.2f%%'%(gent(lam,'u'),yeoh(c,lam,'u'),100*(yeoh(c,lam,'u')/gent(lam,'u')-1)))
    lam=np.linspace(1.02,5.5,500); e=[abs(yeoh(c,l,'u')/gent(l,'u')-1) for l in lam]
    print(' max rel err uniax up to 3:',max(e[:np.searchsorted(lam,3.0)]),'up to 5:',max(e[:np.searchsorted(lam,5.0)]))
