"""Post-processing of the Fortran driver output of Chapter 11 (run from ch11/).
Independent checks done here: ODE solution of the plane-strain uniaxial-stress problem,
generalised eigenproblem of the bar, HHT recurrence of the modal oscillator."""
import numpy as np, json, re
from scipy.integrate import solve_ivp
from scipy.linalg import eigh
R={}
# ---------------- truss
T={}
for l in open('verify/truss_out.txt'):
    p=l.split()
    if p[0] in ('fd_err_rel','fd_kmax','fd_eg','fd_err_nogeo_rel','rot_force_igeom1','rot_force_igeom0','pmax_closed','wsnap_closed','l0','k0_closed','dc_maxerr','dc_iters_total'):
        T[p[0]]=float(p[1])
lc={}; cur=None
for l in open('verify/truss_out.txt'):
    p=l.split()
    if p[0]=='lc_begin': cur=(int(p[1]),int(p[2])); lc[cur]=[]
    elif p[0]=='lc': lc[cur].append(float(p[2]))
    elif p[0]=='lc_end': T['lc_end_%s_%s'%(p[1],p[2])]=(int(p[3]),float(p[4]))
T['lc']={'%d_%d'%k:v for k,v in lc.items()}
dc=np.array([[float(x) for x in l.split()[1:5]] for l in open('verify/truss_out.txt') if l.startswith('dc ')])
T['dc']=dc.tolist()
R['truss']=T
# ---------------- quad
Q={}
for l in open('verify/quad_out.txt'):
    p=l.split(); Q[p[0]]=[float(x) for x in p[1:]]
uni=np.loadtxt('verify/quad_uni.txt')   # eps, eps, s11, s22, s33, peeq, s12, its
E,nu,sy,H=210000.,0.3,250.,1000.
G=E/2/(1+nu); K=E/3/(1-2*nu)
C=np.zeros((3,3)); C[:]=K-2*G/3; C+=2*G*np.eye(3)
def ode(eps_end,n=200):
    e0=sy*(1-nu**2)/(E*np.sqrt(1-nu+nu**2))
    s0=E/(1-nu**2)*e0
    sg0=np.array([s0,0,nu*s0])
    def rhs(e,y):
        s=y[:3]; p=y[3]
        dev=s-s.mean(); q=np.sqrt(1.5*dev@dev); nn=1.5*dev/q
        Cn=C@nn
        Cep=C-np.outer(Cn,Cn)/(nn@C@nn+H)
        # dsigma22=0 with deps33=0, deps11=1:
        de22=-Cep[1,0]/Cep[1,1]
        de=np.array([1,de22,0.])
        ds=Cep@de
        # dp = (nn.C.de)/(nn.C.nn+H)
        dp=(nn@C@de)/(nn@C@nn+H)
        return np.r_[ds,dp]
    sol=solve_ivp(rhs,[e0,eps_end],np.r_[sg0,0],rtol=1e-12,atol=1e-14,dense_output=True)
    return e0,sol
e0,sol=ode(0.01)
err=[];errs=[]
for r in uni:
    e=r[0]
    if e<=e0: ref=np.array([E/(1-nu**2)*e,0,nu*E/(1-nu**2)*e,0])
    else: ref=sol.sol(e)
    errs.append([e,r[2]-ref[0],r[4]-ref[2],r[5]-ref[3]])
    err.append([abs(r[2]-ref[0])/ref[0],abs(r[4]-ref[2])/ref[2],abs(r[5]-ref[3])/max(ref[3],1e-9) if e>e0 else 0])
Q['e0']=e0; Q['ode_end']=list(sol.sol(0.01)); Q['uni_end']=[uni[-1,2],uni[-1,3],uni[-1,4],uni[-1,5]]
Q['err_max_s11']=max(x[0] for x in err); Q['err_max_s33']=max(x[1] for x in err)
Q['err_peeq_end']=abs(uni[-1,5]-sol.sol(0.01)[3])/sol.sol(0.01)[3]
Q['uni_iters']=uni[:,7].astype(int).tolist(); Q['uni']=uni.tolist()
Q['ode_curve']=[[e]+list(sol.sol(e)) for e in np.linspace(e0,0.01,60)]
# yield onset closed form
Q['s11_y_closed']=sy/np.sqrt(1-nu+nu**2)
res={}
for l in open('verify/quad_neck_res.txt'):
    p=l.split(); res.setdefault(int(p[1]),[]).append(float(p[3]))
Q['res']={str(k):v for k,v in res.items()}
Q['en']={}
for l in open('verify/quad_out.txt'):
    if l.startswith('B_en '):
        p=l.split(); n=int(p[1]); W,Ee,Ep=map(float,p[2:5]); Q['en'][n]=[W,Ee,Ep,abs(W-Ee-Ep)/(Ee+Ep)]
Q['An']={}
for l in open('verify/quad_out.txt'):
    if l.startswith('A_n '):
        p=l.split(); n=int(p[1]); a,b_,c_=map(float,p[2:5]); ref=sol.sol(0.01)
        Q['An'][n]=[a,b_,c_,abs(a-ref[0])/ref[0],abs(b_-ref[2])/ref[2],abs(c_-ref[3])/ref[3]]
R['quad']=Q
# ---------------- bar eigenvalues
L,A,Em,rho=1000.,100.,210000.,7.85e-9
c=np.sqrt(Em/rho); B={}
B['c']=c; B['om_exact']=[(2*n-1)*np.pi*c/(2*L) for n in (1,2,3)]
for im,name in ((0,'lumped'),(1,'consistent')):
    B[name]={}
    for N in (2,4,8,16):
        d=open('verify/km_%d_%02d.txt'%(im,N)).read().split('\n')
        n=int(d[0]); rows=[[float(x) for x in l.split()] for l in d[1:1+2*n] if l.strip()]
        K_=np.array(rows[:n]); M_=np.array(rows[n:])
        w=np.sqrt(eigh(K_,M_,eigvals_only=True))
        B[name][N]=w[:3].tolist()+[w[-1]]
        B[name]['sym%d'%N]=float(np.abs(K_-K_.T).max()+np.abs(M_-M_.T).max())
        B[name]['mtot%d'%N]=None
B['mass_total']=rho*A*L
# lumped total mass check and rank of M
for im,name in ((0,'lumped'),(1,'consistent')):
    N=8; d=open('verify/km_%d_%02d.txt'%(im,N)).read().split('\n'); n=int(d[0]); rows=[[float(x) for x in l.split()] for l in d[1:1+2*n] if l.strip()]
    M_=np.array(rows[n:]); B[name]['rowsum_total']=float(M_.sum()+ (rho*A*L/N)/2*0)  # reduced (node 1 removed)
dyn=[l.split() for l in open('verify/dyn_summary.txt')]
B['omega1_driver']={('%s_%s'%(p[1],p[2])):float(p[3]) for p in dyn}
# ---------------- dynamics: HHT recurrence of the modal oscillator
def recur(om,alpha,dt,n,q0=1.0):
    beta=(1-alpha)**2/4; gam=.5-alpha
    q=q0; v=0.; a=-om**2*q  # M a + K q =0 initially
    out=[(q,v)]
    # unknown a1: a1 + om^2((1+alpha) u1 - alpha u0)=0 ; u1=u0+dt v0+dt^2((.5-beta)a0+beta a1)
    for k in range(n):
        u_pred=q+dt*v+dt**2*(.5-beta)*a
        a1=-om**2*((1+alpha)*u_pred-alpha*q)/(1+(1+alpha)*om**2*beta*dt**2)
        u1=u_pred+beta*dt**2*a1
        v1=v+dt*((1-gam)*a+gam*a1)
        q,v,a=u1,v1,a1; out.append((q,v))
    return np.array(out)
D={}
for im in (0,1):
    for ia in (0,1):
        al=-0.05*ia
        d=np.loadtxt('verify/dyn_%d%d.txt'%(im,ia))
        om=B['omega1_driver']['%d_8'%im]
        T0=2*np.pi/om; dt=T0/40
        rc=recur(om,al,dt,800)
        dq=np.abs(d[:,2]-rc[:,0]).max()
        amp=np.sqrt(d[:,2]**2+(d[:,3]/om)**2)
        # zero crossings of q for period
        q=d[:,2]; t=d[:,1]; zc=[]
        for k in range(len(q)-1):
            if q[k]>0>=q[k+1] or q[k]<0<=q[k+1]:
                zc.append(t[k]+(t[k+1]-t[k])*q[k]/(q[k]-q[k+1]))
        per=2*(zc[-1]-zc[0])/(len(zc)-1)
        # spectral radius of HHT amplification for this om*dt
        beta=(1-al)**2/4; gam=.5-al
        # build one-step map on (u,v,a) from recurrence
        def step(s):
            q0,v0,a0=s
            up=q0+dt*v0+dt**2*(.5-beta)*a0
            a1=-om**2*((1+al)*up-al*q0)/(1+(1+al)*om**2*beta*dt**2)
            u1=up+beta*dt**2*a1; v1=v0+dt*((1-gam)*a0+gam*a1)
            return np.array([u1,v1,a1])
        Mx=np.column_stack([step(e) for e in np.eye(3)])
        rho_s=max(abs(np.linalg.eigvals(Mx)))
        D['%d%d'%(im,ia)]=dict(dq=float(dq),amp800=float(amp[-1]),rho=float(rho_s),rho800=float(rho_s**800),
            period=float(per),T0=float(T0),eperr=float((d[:,4].max()-d[:,4].min())/d[0,4]),e_end=float(d[-1,4]/d[0,4]),dt=float(dt),om=float(om),
            nonz=int(len(zc)))
B['dyn']=D
R['bar']=B
json.dump(R,open('verify/results.json','w'),indent=1,default=float)
print(json.dumps({k:R[k] for k in ('bar',)},indent=0,default=float)[:3000])
print('quad err',Q['err_max_s11'],Q['err_max_s33'],Q['err_peeq_end'],Q['uni_end'],Q['ode_end'])
print(Q['en'])
