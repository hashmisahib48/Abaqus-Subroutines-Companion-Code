      SUBROUTINE K11_VISVAL(SIG, PEEQ, VAL)
!     Quantities mapped onto the overlay mesh
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION SIG(4), VAL(5)
      P  = (SIG(1) + SIG(2) + SIG(3))/3.0D0
      S2 = (SIG(1)-P)**2 + (SIG(2)-P)**2 + (SIG(3)-P)**2
     1     + 2.0D0*SIG(4)**2
      VAL(1) = PEEQ                       ! UVAR1  PEEQ
      VAL(2) = SQRT(1.5D0*S2)             ! UVAR2  Mises (MPa)
      VAL(3) = SIG(1)                     ! UVAR3  S11 (MPa)
      VAL(4) = SIG(2)                     ! UVAR4  S22 (MPa)
      VAL(5) = SIG(4)                     ! UVAR5  S12 (MPa)
      RETURN
      END
!
      SUBROUTINE K11_PUT(JELEM, IP, VAL)
!     Called by the UEL: store the values of integration point IP
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXEL = 5000)
      DIMENSION VAL(5)
      COMMON /K11VIS/ VIS(5,4,NMAXEL)
      IF (JELEM .LT. 1 .OR. JELEM .GT. NMAXEL) RETURN
      DO K = 1, 5
         VIS(K,IP,JELEM) = VAL(K)
      ENDDO
      RETURN
      END
!
      SUBROUTINE UVARM(UVAR,DIRECT,T,TIME,DTIME,CMNAME,ORNAME,
     1 NUVARM,NOEL,NPT,LAYER,KSPT,KSTEP,KINC,NDI,NSHR,COORD,
     2 JMAC,JMATYP,MATLAYO,LACCFLA)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME,ORNAME
      DIMENSION UVAR(NUVARM),DIRECT(3,3),T(3,3),TIME(2)
      DIMENSION JMAC(*),JMATYP(*),COORD(*)
      PARAMETER (KOFF = 1000, NMAXEL = 5000)
      COMMON /K11VIS/ VIS(5,4,NMAXEL)
!
!     Overlay element number = UEL number + KOFF; the overlay CPE4
!     elements have the Gauss-point order of the UEL
      IEL = NOEL - KOFF
      DO K = 1, NUVARM
         UVAR(K) = 0.0D0
      ENDDO
      IF (IEL .LT. 1 .OR. IEL .GT. NMAXEL) RETURN
      IF (NPT .LT. 1 .OR. NPT .GT. 4 .OR. NUVARM .GT. 5) RETURN
      DO K = 1, NUVARM
         UVAR(K) = VIS(K,NPT,IEL)
      ENDDO
      RETURN
      END
