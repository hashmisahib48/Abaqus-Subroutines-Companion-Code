      SUBROUTINE K11_J2(PROPS, EPS, SV0, SV1, D, WE, DISS, DPMAX, IERR)
!     Plane-strain J2 plasticity at one integration point,
!     linear hardening, backward-Euler radial return.
!     PROPS: 1 E, 2 NU (-), 3 SY0, 4 H (MPa)
!     EPS(4): total strain (11, 22, 33, gamma12)
!     SV(9): 1-4 stress, 5-8 plastic strain, 9 PEEQ
!     SV0 start of increment, SV1 end of increment
!     D(4,4): consistent tangent; WE elastic energy density;
!     DISS: plastic dissipation density of the increment (N/mm^2)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*), EPS(4), SV0(9), SV1(9), D(4,4)
      DIMENSION STR(4), S(4), EN(4)
      G  = PROPS(1)/(2.0D0*(1.0D0 + PROPS(2)))
      BK = PROPS(1)/(3.0D0*(1.0D0 - 2.0D0*PROPS(2)))
      D = 0.0D0
      DO J = 1, 3
         DO I = 1, 3
            D(I,J) = BK - 2.0D0*G/3.0D0
         ENDDO
         D(J,J) = D(J,J) + 2.0D0*G
      ENDDO
      D(4,4) = G
      DO I = 1, 4
         STR(I) = 0.0D0
         DO J = 1, 4
            STR(I) = STR(I) + D(I,J)*(EPS(J) - SV0(4+J))
         ENDDO
      ENDDO
      P = (STR(1) + STR(2) + STR(3))/3.0D0
      S(1) = STR(1) - P
      S(2) = STR(2) - P
      S(3) = STR(3) - P
      S(4) = STR(4)
      SN2 = S(1)**2 + S(2)**2 + S(3)**2 + 2.0D0*S(4)**2
      Q   = SQRT(1.5D0*SN2)
      SYN = PROPS(3) + PROPS(4)*SV0(9)
      DP  = 0.0D0
      IERR = 0
      SV1(5) = SV0(5)
      SV1(6) = SV0(6)
      SV1(7) = SV0(7)
      SV1(8) = SV0(8)
      IF (Q - SYN .GT. 1.0D-10*PROPS(3)) THEN
         DP  = (Q - SYN)/(3.0D0*G + PROPS(4))
         TH  = 1.0D0 - 3.0D0*G*DP/Q
         THB = 3.0D0*G/(3.0D0*G + PROPS(4)) - (1.0D0 - TH)
         DO I = 1, 4
            EN(I) = S(I)/SQRT(SN2)
         ENDDO
         DO I = 1, 3
            STR(I)   = P + TH*S(I)
            SV1(4+I) = SV0(4+I) + 1.5D0*DP*S(I)/Q
         ENDDO
         STR(4)   = TH*S(4)
         SV1(8)   = SV0(8) + 3.0D0*DP*S(4)/Q
         DO J = 1, 3
            DO I = 1, 3
               D(I,J) = BK - 2.0D0*G*(TH/3.0D0+THB*EN(I)*EN(J))
            ENDDO
            D(J,J) = D(J,J) + 2.0D0*G*TH
            D(J,4) = -2.0D0*G*THB*EN(J)*EN(4)
            D(4,J) = D(J,4)
         ENDDO
         D(4,4) = G*TH - 2.0D0*G*THB*EN(4)**2
         IF (DP .GT. DPMAX) IERR = 1
      ENDIF
      DO I = 1, 4
         SV1(I) = STR(I)
      ENDDO
      SV1(9) = SV0(9) + DP
      DISS = (SYN + PROPS(4)*DP)*DP
      WE = 0.0D0
      DO I = 1, 4
         WE = WE + 0.5D0*STR(I)*(EPS(I) - SV1(4+I))
      ENDDO
      RETURN
      END
