!     Test harness for the truss mass matrices and the dynamic branch of
!     the UEL (Chapter 11, Sections 11.7).  A fixed-free bar of NEL
!     elements along x; LFLAGS(1) = 41 (frequency) with LFLAGS(3) = 2, 4;
!     LFLAGS(1) = 11 (direct integration) with LFLAGS(3) = 6 and 1.
      PROGRAM DRVDYN
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMX = 40)
      DIMENSION AKR(NMX,NMX), AMR(NMX,NMX), PHI(NMX)
      CHARACTER*40 FN
      COMMON /BAR/ BL, BA, BE, BRHO
      BL = 1000.0D0
      BA = 100.0D0
      BE = 210000.0D0
      BRHO = 7.85D-9
      OPEN(10, FILE='verify/dyn_summary.txt')
      DO IM = 0, 1
         DO NEL = 2, 16, 2
            IF (NEL .EQ. 6 .OR. NEL .EQ. 10 .OR. NEL .EQ. 12 .OR.
     1          NEL .EQ. 14) GO TO 5
            CALL ASMKM(NEL, IM, AKR, AMR, NMX)
            WRITE(FN,'(A,I1,A,I2.2,A)') 'verify/km_', IM, '_', NEL,
     1            '.txt'
            OPEN(11, FILE=FN)
            WRITE(11,*) NEL
            DO I = 1, NEL
               WRITE(11,'(40ES24.15)') (AKR(I,J), J=1,NEL)
            ENDDO
            DO I = 1, NEL
               WRITE(11,'(40ES24.15)') (AMR(I,J), J=1,NEL)
            ENDDO
            CLOSE(11)
            CALL INVIT(NEL, AKR, AMR, NMX, PHI, OM)
            WRITE(10,'(A,2I3,1P,E20.12)') 'omega1 ', IM, NEL, OM
    5       CONTINUE
         ENDDO
      ENDDO
      CLOSE(10)
      NEL = 8
      DO IM = 0, 1
         CALL ASMKM(NEL, IM, AKR, AMR, NMX)
         CALL INVIT(NEL, AKR, AMR, NMX, PHI, OM)
         DO IA = 0, 1
            ALPHA = -0.05D0*IA
            CALL DYNRUN(NEL, IM, IA, ALPHA, PHI, OM)
         ENDDO
      ENDDO
      END
!
      SUBROUTINE ELPROP(IM, PROPS)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(4)
      COMMON /BAR/ BL, BA, BE, BRHO
      PROPS(1) = BA
      PROPS(2) = BE
      PROPS(3) = BRHO
      PROPS(4) = IM
      RETURN
      END
!
      SUBROUTINE ASMKM(NEL, IM, AKR, AMR, NMX)
!     Assemble reduced stiffness and mass (axial DOFs of nodes 2..NEL+1)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION AKR(NMX,NMX), AMR(NMX,NMX), PROPS(4), X(2,2), U(4)
      DIMENSION DU(4), V(4), A(4), SV(7), LF(10), PAR(3), RHS(4)
      DIMENSION AK(4,4), AM(4,4), EN(8)
      COMMON /BAR/ BL, BA, BE, BRHO
      CALL ELPROP(IM, PROPS)
      AKR = 0.0D0
      AMR = 0.0D0
      U = 0.0D0
      DU = 0.0D0
      V = 0.0D0
      A = 0.0D0
      SV = 0.0D0
      PAR = 0.0D0
      HL = BL/NEL
      DO IE = 1, NEL
         X(1,1) = (IE-1)*HL
         X(2,1) = 0.0D0
         X(1,2) = IE*HL
         X(2,2) = 0.0D0
         LF = 0
         LF(1) = 41
         LF(3) = 2
         CALL K11_CALLUEL(1,4,2,PROPS,4,X,U,DU,V,A,SV,7,LF,1.0D0,PAR,
     1                    IE,RHS,AK,EN,PNEW)
         LF(3) = 4
         CALL K11_CALLUEL(1,4,2,PROPS,4,X,U,DU,V,A,SV,7,LF,1.0D0,PAR,
     1                    IE,RHS,AM,EN,PNEW)
!        element DOF 1 -> node IE, DOF 3 -> node IE+1; reduced index
!        of the axial DOF of node k is k-1 (node 1 fixed)
         DO KA = 1, 2
            IA = IE + KA - 2
            IF (IA .GE. 1) THEN
               DO KB = 1, 2
                  IB = IE + KB - 2
                  IF (IB .GE. 1) THEN
                     AKR(IA,IB) = AKR(IA,IB) + AK(2*KA-1,2*KB-1)
                     AMR(IA,IB) = AMR(IA,IB) + AM(2*KA-1,2*KB-1)
                  ENDIF
               ENDDO
            ENDIF
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE INVIT(N, AKR, AMR, NMX, PHI, OM)
!     Lowest eigenpair of K phi = w^2 M phi by inverse iteration;
!     phi is scaled to unit value at the free end
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION AKR(NMX,NMX), AMR(NMX,NMX), PHI(NMX), W(NMX,NMX)
      DIMENSION B(NMX)
      DO I = 1, N
         PHI(I) = 1.0D0
      ENDDO
      DO IT = 1, 200
         DO I = 1, N
            B(I) = 0.0D0
            DO J = 1, N
               B(I) = B(I) + AMR(I,J)*PHI(J)
            ENDDO
         ENDDO
         DO J = 1, N
            DO I = 1, N
               W(I,J) = AKR(I,J)
            ENDDO
         ENDDO
         CALL K11_SOLVE(W, B, N, NMX, IERR)
         DO I = 1, N
            PHI(I) = B(I)/B(N)
         ENDDO
      ENDDO
      SK = 0.0D0
      SM = 0.0D0
      DO I = 1, N
         DO J = 1, N
            SK = SK + PHI(I)*AKR(I,J)*PHI(J)
            SM = SM + PHI(I)*AMR(I,J)*PHI(J)
         ENDDO
      ENDDO
      OM = SQRT(SK/SM)
      RETURN
      END
!
      SUBROUTINE DYNRUN(NEL, IM, IA, ALPHA, PHI, OM)
!     Free vibration in the first discrete mode, HHT/Newmark integration
!     driven the way Abaqus drives a direct-integration step
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMX = 40, NS = 800)
      DIMENSION PHI(NMX), PROPS(4), X(2,2), UE(4), DUE(4), VE(4), AE(4)
      DIMENSION SVN(7,NMX), SVT(7,NMX), LF(10), PAR(3), RHS(4)
      DIMENSION AK(4,4), AM(4,4), EN(8)
      DIMENSION UN(NMX), VN(NMX), AN(NMX), UC(NMX), VC(NMX), AC(NMX)
      DIMENSION RT(NMX), AT(NMX,NMX), AMF(NMX,NMX), AKF(NMX,NMX)
      DIMENSION WK(NMX,NMX), B(NMX), DUV(NMX), ZERO4(4)
      CHARACTER*40 FN
      COMMON /BAR/ BL, BA, BE, BRHO
      CALL ELPROP(IM, PROPS)
      NF = NEL
      HL = BL/NEL
      T0 = 2.0D0*3.14159265358979324D0/OM
      DT = T0/40.0D0
      BETA  = (1.0D0 - ALPHA)**2/4.0D0
      GAMMA = 0.5D0 - ALPHA
      PAR(1) = ALPHA
      PAR(2) = BETA
      PAR(3) = GAMMA
      CALL ASMKM(NEL, IM, AKF, AMF, NMX)
      DO I = 1, NF
         UN(I) = PHI(I)
         VN(I) = 0.0D0
      ENDDO
      SVN = 0.0D0
!     static pass (LFLAGS(1)=1) stores the internal force in SVARS
      DO IE = 1, NEL
         CALL ELDOF(IE, UN, X, UE, HL)
         LF = 0
         LF(1) = 1
         LF(3) = 1
         DUE = 0.0D0
         VE = 0.0D0
         AE = 0.0D0
         CALL K11_CALLUEL(1,4,2,PROPS,4,X,UE,DUE,VE,AE,SVN(1,IE),7,LF,
     1                    1.0D0,PAR,IE,RHS,AK,EN,PNEW)
      ENDDO
!     initial acceleration: LFLAGS(3)=6 gives M and -FINT
      RT = 0.0D0
      DO IE = 1, NEL
         CALL ELDOF(IE, UN, X, UE, HL)
         LF = 0
         LF(1) = 11
         LF(2) = 0
         LF(3) = 6
         SVT(:,IE) = SVN(:,IE)
         CALL K11_CALLUEL(1,4,2,PROPS,4,X,UE,DUE,VE,AE,SVT(1,IE),7,LF,
     1                    DT,PAR,IE,RHS,AK,EN,PNEW)
         CALL SCAT(IE, RHS, RT)
      ENDDO
      DO J = 1, NF
         DO I = 1, NF
            WK(I,J) = AMF(I,J)
         ENDDO
         B(J) = RT(J)
      ENDDO
      CALL K11_SOLVE(WK, B, NF, NMX, IERR)
      DO I = 1, NF
         AN(I) = B(I)
      ENDDO
      WRITE(FN,'(A,I1,I1,A)') 'verify/dyn_', IM, IA, '.txt'
      OPEN(12, FILE=FN)
      DO KS = 0, NS
         SQ = 0.0D0
         SQD = 0.0D0
         SM = 0.0D0
         EK = 0.0D0
         EE = 0.0D0
         DO I = 1, NF
            DO J = 1, NF
               SQ  = SQ  + PHI(I)*AMF(I,J)*UN(J)
               SQD = SQD + PHI(I)*AMF(I,J)*VN(J)
               SM  = SM  + PHI(I)*AMF(I,J)*PHI(J)
               EK  = EK  + 0.5D0*VN(I)*AMF(I,J)*VN(J)
               EE  = EE  + 0.5D0*UN(I)*AKF(I,J)*UN(J)
            ENDDO
         ENDDO
         WRITE(12,'(I5,1P,4E24.15)') KS, KS*DT, SQ/SM, SQD/SM, EK+EE
         IF (KS .EQ. NS) GO TO 90
!        --- one increment: Newton iteration on the end-of-increment U
         UC(1:NF) = UN(1:NF)
         DO IT = 1, 10
            DO I = 1, NF
               AC(I) = (UC(I)-UN(I))/(BETA*DT**2) - VN(I)/(BETA*DT)
     1                 - (0.5D0/BETA - 1.0D0)*AN(I)
               VC(I) = VN(I) + DT*((1.0D0-GAMMA)*AN(I) + GAMMA*AC(I))
            ENDDO
            RT = 0.0D0
            AT = 0.0D0
            DO IE = 1, NEL
               CALL ELDOF(IE, UC, X, UE, HL)
               CALL ELDOF(IE, VC, X, VE, HL)
               CALL ELDOF(IE, AC, X, AE, HL)
               LF = 0
               LF(1) = 11
               LF(2) = 0
               LF(3) = 1
               SVT(:,IE) = SVN(:,IE)
               CALL K11_CALLUEL(1,4,2,PROPS,4,X,UE,DUE,VE,AE,SVT(1,IE),
     1                          7,LF,DT,PAR,IE,RHS,AK,EN,PNEW)
               CALL SCAT(IE, RHS, RT)
               CALL SCATM(IE, AK, AT, NMX)
            ENDDO
            RN = 0.0D0
            DO I = 1, NF
               RN = MAX(RN, ABS(RT(I)))
            ENDDO
            IF (RN .LT. 1.0D-8) GO TO 50
            DO J = 1, NF
               DO I = 1, NF
                  WK(I,J) = AT(I,J)
               ENDDO
               B(J) = RT(J)
            ENDDO
            CALL K11_SOLVE(WK, B, NF, NMX, IERR)
            DO I = 1, NF
               UC(I) = UC(I) + B(I)
            ENDDO
         ENDDO
   50    CONTINUE
         UN(1:NF) = UC(1:NF)
         VN(1:NF) = VC(1:NF)
         AN(1:NF) = AC(1:NF)
         SVN(:,1:NEL) = SVT(:,1:NEL)
      ENDDO
   90 CLOSE(12)
      RETURN
      END
!
      SUBROUTINE ELDOF(IE, UR, X, UE, HL)
!     Element DOFs (u1,v1,u2,v2) and coordinates from reduced vector
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION UR(*), X(2,2), UE(4)
      X(1,1) = (IE-1)*HL
      X(2,1) = 0.0D0
      X(1,2) = IE*HL
      X(2,2) = 0.0D0
      UE = 0.0D0
      IF (IE .GE. 2) UE(1) = UR(IE-1)
      UE(3) = UR(IE)
      RETURN
      END
!
      SUBROUTINE SCAT(IE, RHS, RT)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION RHS(4), RT(*)
      IF (IE .GE. 2) RT(IE-1) = RT(IE-1) + RHS(1)
      RT(IE) = RT(IE) + RHS(3)
      RETURN
      END
!
      SUBROUTINE SCATM(IE, AK, AT, NMX)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION AK(4,4), AT(NMX,NMX)
      IF (IE .GE. 2) AT(IE-1,IE-1) = AT(IE-1,IE-1) + AK(1,1)
      IF (IE .GE. 2) AT(IE-1,IE) = AT(IE-1,IE) + AK(1,3)
      IF (IE .GE. 2) AT(IE,IE-1) = AT(IE,IE-1) + AK(3,1)
      AT(IE,IE) = AT(IE,IE) + AK(3,3)
      RETURN
      END
