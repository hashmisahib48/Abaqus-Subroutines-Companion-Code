      SUBROUTINE K11_UEL1(RHS,AMATRX,SVARS,ENERGY,NDOFEL,NRHS,NSVARS,
     1 PROPS,NPROPS,COORDS,MCRD,NNODE,U,DU,V,A,JTYPE,TIME,DTIME,
     2 KSTEP,KINC,JELEM,PARAMS,NDLOAD,JDLTYP,ADLMAG,PREDEF,NPREDF,
     3 LFLAGS,MLVARX,DDLMAG,MDLOAD,PNEWDT,JPROPS,NJPROP,PERIOD)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION RHS(MLVARX,*),AMATRX(NDOFEL,NDOFEL),PROPS(*),
     1 SVARS(*),ENERGY(8),COORDS(MCRD,NNODE),U(NDOFEL),
     2 DU(MLVARX,*),V(NDOFEL),A(NDOFEL),TIME(2),PARAMS(*),
     3 JDLTYP(MDLOAD,*),ADLMAG(MDLOAD,*),DDLMAG(MDLOAD,*),
     4 PREDEF(2,NPREDF,NNODE),LFLAGS(*),JPROPS(*)
      DIMENSION FINT(4), AKT(4,4), AM(4,4), X0(2,2)
!
!     Truss U1.  PROPS: 1 A (mm^2)  2 E (MPa)  3 RHO (tonne/mm^3)
!                       4 mass type (0 lumped, 1 consistent)
!     SVARS: 1 S (MPa)  2 Green strain  3 axial force (N)
!            4-7 internal force at the end of the increment (N)
      IF (NDOFEL .NE. 4 .OR. NSVARS .LT. 7 .OR. MLVARX .LT. 4) THEN
         WRITE(7,*) 'U1: needs NDOFEL=4, NSVARS>=7'
         CALL XIT
      ENDIF
      DO J = 1, 2
         X0(1,J) = COORDS(1,J)
         X0(2,J) = COORDS(2,J)
      ENDDO
      CALL K11_TRUSS(X0, U, PROPS(1), PROPS(2), LFLAGS(2), FINT, AKT,
     1               S, EG, STRCH, XL0)
      CALL K11_MASS(PROPS(1), PROPS(3), XL0, NINT(PROPS(4)), AM)
!     element nearly collapsed: ask Abaqus for a smaller increment
      IF (STRCH .LT. 0.5D0) PNEWDT = 0.25D0
!
      LPROC = LFLAGS(1)
      LTASK = LFLAGS(3)
      ALPHA = 0.0D0
      DADU  = 0.0D0
      IF (LPROC .EQ. 11 .OR. LPROC .EQ. 12) THEN
         ALPHA = PARAMS(1)
         DADU  = 1.0D0/(PARAMS(2)*DTIME**2)
      ENDIF
      AMATRX = 0.0D0
      ENERGY = 0.0D0
      DO K2 = 2, NRHS                 ! Riks: no load
         DO K1 = 1, NDOFEL
            RHS(K1,K2) = 0.0D0
         ENDDO
      ENDDO
!
      IF (LTASK .EQ. 1 .OR. LTASK .EQ. 5) THEN
!        residual and Jacobian: RHS = -(f_int) - inertia
         DO K1 = 1, NDOFEL
            RHS(K1,1) = -(1.0D0 + ALPHA)*FINT(K1) + ALPHA*SVARS(3+K1)
            DO K2 = 1, NDOFEL
               IF (DADU .GT. 0.0D0) RHS(K1,1) = RHS(K1,1) -
     1                                          AM(K1,K2)*A(K2)
               AMATRX(K1,K2) = (1.0D0 + ALPHA)*AKT(K1,K2)
     1                         + DADU*AM(K1,K2)
            ENDDO
         ENDDO
         IF (LTASK .EQ. 1) THEN
            SVARS(1) = S
            SVARS(2) = EG
            SVARS(3) = PROPS(1)*S*STRCH
            DO K1 = 1, NDOFEL
               SVARS(3+K1) = FINT(K1)
            ENDDO
            ENERGY(2) = 0.5D0*PROPS(2)*EG**2*PROPS(1)*XL0
            IF (DADU .GT. 0.0D0) THEN
               DO K1 = 1, NDOFEL
                  DO K2 = 1, NDOFEL
                     ENERGY(1) = ENERGY(1) + 0.5D0*V(K1)*AM(K1,K2)*V(K2)
                  ENDDO
               ENDDO
            ENDIF
         ENDIF
      ELSE IF (LTASK .EQ. 2) THEN
         AMATRX = AKT                           ! stiffness only
      ELSE IF (LTASK .EQ. 4) THEN
         AMATRX = AM                            ! mass only
      ELSE IF (LTASK .EQ. 6) THEN
!        mass and residual for the initial acceleration
         AMATRX = AM
         DO K1 = 1, NDOFEL
            RHS(K1,1) = -FINT(K1)
         ENDDO
      ENDIF
!     LTASK = 3 (damping) and 100 (perturbation): none
      RETURN
      END
