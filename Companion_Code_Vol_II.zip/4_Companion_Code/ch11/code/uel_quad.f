      SUBROUTINE K11_UEL2(RHS,AMATRX,SVARS,ENERGY,NDOFEL,NRHS,NSVARS,
     1 PROPS,NPROPS,COORDS,MCRD,NNODE,U,DU,V,A,JTYPE,TIME,DTIME,
     2 KSTEP,KINC,JELEM,PARAMS,NDLOAD,JDLTYP,ADLMAG,PREDEF,NPREDF,
     3 LFLAGS,MLVARX,DDLMAG,MDLOAD,PNEWDT,JPROPS,NJPROP,PERIOD)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION RHS(MLVARX,*),AMATRX(NDOFEL,NDOFEL),PROPS(*),
     1 SVARS(*),ENERGY(8),COORDS(MCRD,NNODE),U(NDOFEL),
     2 DU(MLVARX,*),V(NDOFEL),A(NDOFEL),TIME(2),PARAMS(*),
     3 JDLTYP(MDLOAD,*),ADLMAG(MDLOAD,*),DDLMAG(MDLOAD,*),
     4 PREDEF(2,NPREDF,NNODE),LFLAGS(*),JPROPS(*)
      DIMENSION X(2,4), DNX(2,4), EPS(4), SV1(9), D(4,4), VAL(5)
      DIMENSION GP(2,4), SIG(4)
!
!     Quadrilateral U2, plane strain J2, 2 x 2 Gauss points
!     PROPS: 1 E  2 NU  3 SY0  4 H  5 thickness
!     SVARS: (IP-1)*9+1..9 as SV of K11_J2; 37 dissipation
      PARAMETER (DPMAX = 2.0D-2)           ! max PEEQ step
      DATA GP /-0.5773502691896258D0, -0.5773502691896258D0,
     1          0.5773502691896258D0, -0.5773502691896258D0,
     2          0.5773502691896258D0,  0.5773502691896258D0,
     3         -0.5773502691896258D0,  0.5773502691896258D0/
      IF (NDOFEL .NE. 8 .OR. NSVARS .LT. 37) THEN
         WRITE(7,*) 'U2: needs NDOFEL=8, NSVARS>=37'
         CALL XIT
      ENDIF
      AMATRX = 0.0D0
      ENERGY = 0.0D0
      DO K2 = 1, NRHS
         DO K1 = 1, NDOFEL
            RHS(K1,K2) = 0.0D0
         ENDDO
      ENDDO
!     mass is not defined for this element (LFLAGS(3) = 3, 4, 6)
      IF (LFLAGS(3).NE.1 .AND. LFLAGS(3).NE.2 .AND. LFLAGS(3).NE.5)
     1   RETURN
      DO K = 1, 4
         X(1,K) = COORDS(1,K)
         X(2,K) = COORDS(2,K)
      ENDDO
      DISSEL = 0.0D0
      DO IP = 1, 4
         IB = (IP-1)*9
         CALL K11_SHAPE(GP(1,IP), GP(2,IP), X, DNX, DETJ)
         W = DETJ*PROPS(5)                 ! Gauss weights are 1
         EPS = 0.0D0
         DO K = 1, 4
            EPS(1) = EPS(1) + DNX(1,K)*U(2*K-1)
            EPS(2) = EPS(2) + DNX(2,K)*U(2*K)
            EPS(4) = EPS(4) + DNX(2,K)*U(2*K-1) + DNX(1,K)*U(2*K)
         ENDDO
         CALL K11_J2(PROPS, EPS, SVARS(IB+1), SV1, D, WE, DISS, DPMAX,
     1               IERR)
         IF (IERR .NE. 0) PNEWDT = 0.5D0
         DO K = 1, 4
            RHS(2*K-1,1) = RHS(2*K-1,1)
     1         - W*(DNX(1,K)*SV1(1) + DNX(2,K)*SV1(4))
            RHS(2*K,1)   = RHS(2*K,1)
     1         - W*(DNX(2,K)*SV1(2) + DNX(1,K)*SV1(4))
         ENDDO
         DO KB = 1, 4
            DO KA = 1, 4
               AMATRX(2*KA-1,2*KB-1) = AMATRX(2*KA-1,2*KB-1) + W*(
     1            DNX(1,KA)*(D(1,1)*DNX(1,KB) + D(1,4)*DNX(2,KB))
     2          + DNX(2,KA)*(D(4,1)*DNX(1,KB) + D(4,4)*DNX(2,KB)))
               AMATRX(2*KA-1,2*KB) = AMATRX(2*KA-1,2*KB) + W*(
     1            DNX(1,KA)*(D(1,2)*DNX(2,KB) + D(1,4)*DNX(1,KB))
     2          + DNX(2,KA)*(D(4,2)*DNX(2,KB) + D(4,4)*DNX(1,KB)))
               AMATRX(2*KA,2*KB-1) = AMATRX(2*KA,2*KB-1) + W*(
     1            DNX(2,KA)*(D(2,1)*DNX(1,KB) + D(2,4)*DNX(2,KB))
     2          + DNX(1,KA)*(D(4,1)*DNX(1,KB) + D(4,4)*DNX(2,KB)))
               AMATRX(2*KA,2*KB) = AMATRX(2*KA,2*KB) + W*(
     1            DNX(2,KA)*(D(2,2)*DNX(2,KB) + D(2,4)*DNX(1,KB))
     2          + DNX(1,KA)*(D(4,2)*DNX(2,KB) + D(4,4)*DNX(1,KB)))
            ENDDO
         ENDDO
         ENERGY(2) = ENERGY(2) + W*WE
         DISSEL    = DISSEL + W*DISS
         IF (LFLAGS(3) .EQ. 1) THEN
            DO K = 1, 9
               SVARS(IB+K) = SV1(K)
            ENDDO
            SIG(1) = SV1(1)
            SIG(2) = SV1(2)
            SIG(3) = SV1(3)
            SIG(4) = SV1(4)
            CALL K11_VISVAL(SIG, SV1(9), VAL)
            CALL K11_PUT(JELEM, IP, VAL)
         ENDIF
      ENDDO
      ENERGY(4) = SVARS(37) + DISSEL
      IF (LFLAGS(3) .EQ. 1) SVARS(37) = ENERGY(4)
      RETURN
      END
