      SUBROUTINE K11_FDCHK(JT, NDOF, NNOD, PROPS, NPR, X, U, SV, NSV,
     1                     LF, H, ETA)
!     Finite-difference check of AMATRX against RHS for one element.
!     SVARS passed in are restored before every
!     call, so only the dependence on U is differentiated.
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAX = 24)
      DIMENSION PROPS(NPR), X(2,NNOD), U(NDOF), SV(NSV), LF(10)
      DIMENSION UP(NMAX), SV1(200), RP(NMAX), RM(NMAX), R0(NMAX)
      DIMENSION AK(NDOF,NDOF), AKX(NDOF,NDOF), AFD(NDOF,NDOF)
      DIMENSION DU(NMAX), V(NMAX), A(NMAX), PAR(3), EN(8)
      DU = 0.0D0
      V = 0.0D0
      A = 0.0D0
      PAR = 0.0D0
      SV1(1:NSV) = SV(1:NSV)
      CALL K11_CALLUEL(JT,NDOF,NNOD,PROPS,NPR,X,U,DU,V,A,SV1,NSV,LF,
     1                 1.0D0,PAR,1,R0,AK,EN,PNEW)
      DO J = 1, NDOF
         UP(1:NDOF) = U(1:NDOF)
         UP(J) = U(J) + H
         SV1(1:NSV) = SV(1:NSV)
         CALL K11_CALLUEL(JT,NDOF,NNOD,PROPS,NPR,X,UP,DU,V,A,SV1,NSV,
     1                    LF,1.0D0,PAR,1,RP,AKX,EN,PNEW)
         UP(J) = U(J) - H
         SV1(1:NSV) = SV(1:NSV)
         CALL K11_CALLUEL(JT,NDOF,NNOD,PROPS,NPR,X,UP,DU,V,A,SV1,NSV,
     1                    LF,1.0D0,PAR,1,RM,AKX,EN,PNEW)
         DO I = 1, NDOF
            AFD(I,J) = -(RP(I) - RM(I))/(2.0D0*H)
         ENDDO
      ENDDO
      ERR = 0.0D0
      REF = 0.0D0
      DO J = 1, NDOF
         DO I = 1, NDOF
            ERR = MAX(ERR, ABS(AK(I,J) - AFD(I,J)))
            REF = MAX(REF, ABS(AFD(I,J)))
         ENDDO
      ENDDO
      ETA = ERR/REF
      RETURN
      END
