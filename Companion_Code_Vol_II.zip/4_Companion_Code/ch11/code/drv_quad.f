!     Test harness for the plane-strain J2 quadrilateral U2 and the
!     overlay output (Chapter 11, Sections 11.5, 11.6, 11.8).
!     The harness drives the UEL the way Abaqus does: SVARS passed in are
!     the values at the start of the increment at every iteration, and
!     are committed only when the increment has converged.
      PROGRAM DRVQUAD
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      COMMON /STAT/ NCUT, NITTOT, WEXT, EEL, EPD, LOGU
      DIMENSION RES(0:30)
      PR(1) = 210000.0D0
      PR(2) = 0.3D0
      PR(3) = 250.0D0
      PR(4) = 1000.0D0
      PR(5) = 1.0D0
      OPEN(10, FILE='verify/quad_out.txt')
      OPEN(11, FILE='verify/quad_uni.txt')
!
!     ---- A. one element, strain-driven, plane strain, sigma_yy = 0
      CALL MESH1()
      EPS0 = 250.0D0*(1.0D0 - 0.09D0)/(210000.0D0*SQRT(0.79D0))
      CALL RUNLOAD(1, EPS0)
      WRITE(10,'(A,1P,3E16.8)') 'A0_first_yield ', EPS0, SVC(1,1),
     1      SVC(9,1)
      CALL MESH1()
      CALL RUNLOAD(1, 1.0001D0*EPS0)
      WRITE(10,'(A,1P,3E16.8)') 'A0_above ', 1.0001D0*EPS0, SVC(1,1),
     1      SVC(9,1)
      CALL MESH1()
      LOGU = 11
      CALL RUNLOAD(40, 0.01D0)
      WRITE(10,'(A,I4,I6)') 'A_cut_iters ', NCUT, NITTOT
      LOGU = 0
      DO NI = 0, 4
         NINC = 10*2**NI
         CALL MESH1()
         CALL RUNLOAD(NINC, 0.01D0)
         WRITE(10,'(A,I5,1P,3E16.8)') 'A_n ', NINC, SVC(1,1), SVC(3,1),
     1         SVC(9,1)
         WRITE(10,'(A,I5,1P,3E16.8)') 'A_en ', NINC, WEXT, EEL, EPD
      ENDDO
!     ---- A2. one increment of 5 % strain: cutbacks from PNEWDT
      CALL MESH1()
      CALL RUNLOAD(1, 0.05D0)
      WRITE(10,'(A,I4,I6)') 'A2_cut_iters ', NCUT, NITTOT
      WRITE(10,'(A,1P,E14.6)') 'A2_peeq ', SVC(9,1)
!
!     ---- B. necked strip: Newton history, FD check, energies
      CALL MESHNECK(8, 4)
      LOGU = 12
      OPEN(12, FILE='verify/quad_neck_res.txt')
      CALL RUNLOAD(10, 0.055D0)
      CLOSE(12)
      LOGU = 0
      WRITE(10,'(A,I4,I6)') 'B_cut_iters ', NCUT, NITTOT
      WRITE(10,'(A,1P,3E16.8)') 'B_energy ', WEXT, EEL, EPD
      CALL DUMPNECK()
      CALL FDCHECK(5)
      DO NI = 1, 5
         NINC = 5*2**(NI-1)
         CALL MESHNECK(8, 4)
         CALL RUNLOAD(NINC, 0.055D0)
         WRITE(10,'(A,I4,1P,3E16.8)') 'B_en ', NINC, WEXT, EEL, EPD
      ENDDO
!
!     ---- C. patch test with a distorted 2 x 2 patch
      CALL MESHPATCH()
      CALL RUNLOAD(10, 1.0D0)
      CALL PATCHCHK()
      CLOSE(10)
      CLOSE(11)
      END
!
      SUBROUTINE MESH1()
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      NN = 4
      NE = 1
      XN(1,1) = 0.0D0
      XN(2,1) = 0.0D0
      XN(1,2) = 1.0D0
      XN(2,2) = 0.0D0
      XN(1,3) = 1.0D0
      XN(2,3) = 1.0D0
      XN(1,4) = 0.0D0
      XN(2,4) = 1.0D0
      IEL(1,1) = 1
      IEL(2,1) = 2
      IEL(3,1) = 3
      IEL(4,1) = 4
!     prescribed: u1, u4 = 0; v1, v2 = 0; u2, u3 = final value 1 (x
!     strain level, scaled by RUNLOAD)
      NPD = 6
      IPD(1) = 1
      VPD(1) = 0.0D0
      IPD(2) = 7
      VPD(2) = 0.0D0
      IPD(3) = 2
      VPD(3) = 0.0D0
      IPD(4) = 4
      VPD(4) = 0.0D0
      IPD(5) = 3
      VPD(5) = 1.0D0
      IPD(6) = 5
      VPD(6) = 1.0D0
      CALL CLEARST()
      RETURN
      END
!
      SUBROUTINE CLEARST()
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      SVC = 0.0D0
      UC = 0.0D0
      RETURN
      END
!
      SUBROUTINE MESHNECK(NX, NY)
!     Strip 0 <= x <= 40 mm, 0 <= y <= h(x), h = 4 + (x-20)^2/400 mm
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      NN = (NX+1)*(NY+1)
      NE = NX*NY
      DO I = 0, NX
         X = 40.0D0*I/NX
         HH = 4.0D0 + (X-20.0D0)**2/400.0D0
         DO J = 0, NY
            K = I*(NY+1) + J + 1
            XN(1,K) = X
            XN(2,K) = HH*J/NY
         ENDDO
      ENDDO
      K = 0
      DO I = 0, NX-1
         DO J = 0, NY-1
            K = K + 1
            IEL(1,K) = I*(NY+1) + J + 1
            IEL(2,K) = (I+1)*(NY+1) + J + 1
            IEL(3,K) = (I+1)*(NY+1) + J + 2
            IEL(4,K) = I*(NY+1) + J + 2
         ENDDO
      ENDDO
      NPD = 0
      DO J = 0, NY
         NPD = NPD + 1
         IPD(NPD) = 2*(J+1) - 1
         VPD(NPD) = 0.0D0
         NPD = NPD + 1
         IPD(NPD) = 2*(NX*(NY+1) + J + 1) - 1
         VPD(NPD) = 1.0D0
      ENDDO
      DO I = 1, NX
         NPD = NPD + 1
         IPD(NPD) = 2*(I*(NY+1) + 1)
         VPD(NPD) = 0.0D0
      ENDDO
      CALL CLEARST()
      RETURN
      END
!
      SUBROUTINE MESHPATCH()
!     3 x 3 nodes on 0..10 mm, interior node displaced; all boundary
!     nodes carry the uniform strain field (4e-3, -1e-3, 2e-3)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      NN = 9
      NE = 4
      DO I = 0, 2
         DO J = 0, 2
            K = I*3 + J + 1
            XN(1,K) = 5.0D0*I
            XN(2,K) = 5.0D0*J
         ENDDO
      ENDDO
      XN(1,5) = 6.3D0
      XN(2,5) = 3.4D0
      K = 0
      DO I = 0, 1
         DO J = 0, 1
            K = K + 1
            IEL(1,K) = I*3 + J + 1
            IEL(2,K) = (I+1)*3 + J + 1
            IEL(3,K) = (I+1)*3 + J + 2
            IEL(4,K) = I*3 + J + 2
         ENDDO
      ENDDO
      NPD = 0
      DO K = 1, 9
         IF (K .NE. 5) THEN
            X = XN(1,K)
            Y = XN(2,K)
            NPD = NPD + 1
            IPD(NPD) = 2*K - 1
            VPD(NPD) = 4.0D-3*X + 1.0D-3*Y
            NPD = NPD + 1
            IPD(NPD) = 2*K
            VPD(NPD) = -1.0D-3*Y + 1.0D-3*X
         ENDIF
      ENDDO
      CALL CLEARST()
      RETURN
      END
!
      SUBROUTINE ASSEMB(UT, SVIN, SVOUT, FG, AKG, EEL1, EPD1, PNMIN,
     1                  NDM)
!     Assemble RHS (FG = -f_int) and AMATRX of all elements at UT
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDMC = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDMC),
     1  VPD(NDMC), SVC(37,NEM), UC(NDMC), PR(5)
      DIMENSION UT(NDM), SVIN(37,NEM), SVOUT(37,NEM), FG(NDM),
     1  AKG(NDM,NDM)
      DIMENSION X(2,4), UE(8), DUE(8), VE(8), AE(8), RHS(8), AK(8,8),
     1  EN(8), PAR(3), LF(10), IDOF(8)
      FG = 0.0D0
      AKG = 0.0D0
      EEL1 = 0.0D0
      EPD1 = 0.0D0
      PNMIN = 1.0D36
      PAR = 0.0D0
      DUE = 0.0D0
      VE = 0.0D0
      AE = 0.0D0
      LF = 0
      LF(1) = 1
      LF(3) = 1
      DO IE = 1, NE
         DO K = 1, 4
            X(1,K) = XN(1,IEL(K,IE))
            X(2,K) = XN(2,IEL(K,IE))
            IDOF(2*K-1) = 2*IEL(K,IE) - 1
            IDOF(2*K)   = 2*IEL(K,IE)
         ENDDO
         DO I = 1, 8
            UE(I) = UT(IDOF(I))
         ENDDO
         SVOUT(:,IE) = SVIN(:,IE)
         CALL K11_CALLUEL(2,8,4,PR,5,X,UE,DUE,VE,AE,SVOUT(1,IE),37,LF,
     1                    1.0D0,PAR,IE,RHS,AK,EN,PNEW)
         PNMIN = MIN(PNMIN, PNEW)
         EEL1 = EEL1 + EN(2)
         EPD1 = EPD1 + EN(4)
         DO I = 1, 8
            FG(IDOF(I)) = FG(IDOF(I)) + RHS(I)
            DO J = 1, 8
               AKG(IDOF(I),IDOF(J)) = AKG(IDOF(I),IDOF(J)) + AK(I,J)
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE RUNLOAD(NINC, SCALE)
!     Incremental-iterative solution with automatic cutback (PNEWDT)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      COMMON /STAT/ NCUT, NITTOT, WEXT, EEL, EPD, LOGU
      DIMENSION UT(NDM), FG(NDM), AKG(NDM,NDM), SVT(37,NEM)
      DIMENSION AKR(NDM,NDM), B(NDM), IFREE(NDM), ISPD(NDM), RO(NDM)
      NDOF = 2*NN
      DO I = 1, NDOF
         ISPD(I) = 0
      ENDDO
      DO K = 1, NPD
         ISPD(IPD(K)) = K
      ENDDO
      NF = 0
      DO I = 1, NDOF
         IF (ISPD(I) .EQ. 0) THEN
            NF = NF + 1
            IFREE(NF) = I
         ENDIF
      ENDDO
      NCUT = 0
      NITTOT = 0
      WEXT = 0.0D0
      EEL = 0.0D0
      EPD = 0.0D0
      RO = 0.0D0
      XLAM = 0.0D0
      DLAM = 1.0D0/NINC
      KINC = 0
  100 CONTINUE
      IF (XLAM .GE. 1.0D0 - 1.0D-12) GO TO 900
      DL = MIN(DLAM, 1.0D0 - XLAM)
      XNEW = XLAM + DL
      UT = UC
      DO K = 1, NPD
         UT(IPD(K)) = XNEW*SCALE*VPD(K)
      ENDDO
      IFAIL = 0
!     first iteration, as in Abaqus: linear solution for the increment
!     of the prescribed DOFs from the tangent at the start of the increment
      CALL ASSEMB(UC, SVC, SVT, FG, AKG, E1, E2, PNMIN, NDM)
      DO J = 1, NF
         DO I = 1, NF
            AKR(I,J) = AKG(IFREE(I),IFREE(J))
         ENDDO
         B(J) = FG(IFREE(J))
         DO K = 1, NPD
            B(J) = B(J) - AKG(IFREE(J),IPD(K))*(UT(IPD(K))-UC(IPD(K)))
         ENDDO
      ENDDO
      CALL K11_SOLVE(AKR, B, NF, NDM, IERR)
      DO K = 1, NF
         UT(IFREE(K)) = UT(IFREE(K)) + B(K)
      ENDDO
      DO IT = 0, 25
         CALL ASSEMB(UT, SVC, SVT, FG, AKG, E1, E2, PNMIN, NDM)
         IF (PNMIN .LT. 1.0D0) THEN
            IFAIL = 1
            GO TO 200
         ENDIF
         RMAX = 0.0D0
         FS = 0.0D0
         DO I = 1, NDOF
            FS = MAX(FS, ABS(FG(I)))
         ENDDO
         DO K = 1, NF
            RMAX = MAX(RMAX, ABS(FG(IFREE(K))))
         ENDDO
         IF (LOGU .EQ. 12) WRITE(12,'(A,2I4,1P,2E14.6)') 'res ',
     1      KINC+1, IT, RMAX, FS
         IF (RMAX .LE. 1.0D-9*FS .OR. RMAX .LE. 1.0D-11) GO TO 300
         IF (IT .EQ. 25) THEN
            IFAIL = 1
            GO TO 200
         ENDIF
         DO J = 1, NF
            DO I = 1, NF
               AKR(I,J) = AKG(IFREE(I),IFREE(J))
            ENDDO
            B(J) = FG(IFREE(J))
         ENDDO
         CALL K11_SOLVE(AKR, B, NF, NDM, IERR)
         DO K = 1, NF
            UT(IFREE(K)) = UT(IFREE(K)) + B(K)
         ENDDO
         NITTOT = NITTOT + 1
      ENDDO
  200 CONTINUE
!     cutback: the increment is abandoned and retried smaller
      NCUT = NCUT + 1
      DLAM = 0.5D0*DL
      IF (NCUT .GT. 40) STOP 'too many cutbacks'
      GO TO 100
  300 CONTINUE
!     converged: commit state, update work and energies
      KINC = KINC + 1
      DWE = 0.0D0
      DO K = 1, NPD
         ID = IPD(K)
         DWE = DWE + 0.5D0*(RO(ID) - FG(ID))*(UT(ID) - UC(ID))
         RO(ID) = -FG(ID)
      ENDDO
      WEXT = WEXT + DWE
      EEL = E1
      EPD = E2
      SVC = SVT
      UC = UT
      XLAM = XNEW
      IF (LOGU .EQ. 11) THEN
         S11 = SVC(1,1)
         WRITE(11,'(F10.6,1P,6E16.8,I4)') XNEW*SCALE, UT(3)*0.0D0 +
     1      XNEW*SCALE, S11, SVC(2,1), SVC(3,1), SVC(9,1), SVC(4,1), IT
      ENDIF
      GO TO 100
  900 CONTINUE
      RETURN
      END
!
      SUBROUTINE FDCHECK(IE)
!     Compare AMATRX with -dRHS/dU for element IE at a plastic state
!     (start-of-increment SVARS fixed during the perturbations)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      DIMENSION X(2,4), UE(8), UP(8), DUE(8), VE(8), AE(8), RHS(8),
     1  AK(8,8), AFD(8,8), AKX(8,8), RP(8), RM(8), EN(8), PAR(3), LF(10), SV(37)
      PAR = 0.0D0
      DUE = 0.0D0
      VE = 0.0D0
      AE = 0.0D0
      LF = 0
      LF(1) = 1
      LF(3) = 1
      DO K = 1, 4
         X(1,K) = XN(1,IEL(K,IE))
         X(2,K) = XN(2,IEL(K,IE))
         UE(2*K-1) = 1.08D0*UC(2*IEL(K,IE)-1)
         UE(2*K)   = 1.08D0*UC(2*IEL(K,IE))
      ENDDO
      SV = SVC(:,IE)
      CALL K11_CALLUEL(2,8,4,PR,5,X,UE,DUE,VE,AE,SV,37,LF,1.0D0,PAR,IE,
     1                 RHS,AK,EN,PNEW)
      NPL = 0
      DO IP = 1, 4
         IF (SV((IP-1)*9+9) .GT. SVC((IP-1)*9+9,IE)) NPL = NPL + 1
      ENDDO
      H = 1.0D-6
      DO J = 1, 8
         UP = UE
         UP(J) = UE(J) + H
         SV = SVC(:,IE)
         CALL K11_CALLUEL(2,8,4,PR,5,X,UP,DUE,VE,AE,SV,37,LF,1.0D0,PAR,
     1                    IE,RP,AKX,EN,PNEW)
         UP(J) = UE(J) - H
         SV = SVC(:,IE)
         CALL K11_CALLUEL(2,8,4,PR,5,X,UP,DUE,VE,AE,SV,37,LF,1.0D0,PAR,
     1                    IE,RM,AKX,EN,PNEW)
         DO I = 1, 8
            AFD(I,J) = -(RP(I) - RM(I))/(2.0D0*H)
         ENDDO
      ENDDO
      ERR = 0.0D0
      REF = 0.0D0
      DO J = 1, 8
         DO I = 1, 8
            ERR = MAX(ERR, ABS(AK(I,J) - AFD(I,J)))
            REF = MAX(REF, ABS(AFD(I,J)))
         ENDDO
      ENDDO
      WRITE(10,'(A,I3,1P,E14.6)') 'fd_plastic_points ', NPL, 0.0D0
      WRITE(10,'(A,1P,E14.6)') 'fd_err_rel ', ERR/REF
      RETURN
      END
!
      SUBROUTINE DUMPNECK()
!     Write mesh, deformed node positions and the UVARM values
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      DIMENSION UVAR(5), DIR(3,3), T(3,3), TIME(2), JMAC(1), JMATYP(1),
     1  COORD(3), X(2,4), DNX(2,4), GP(2,4)
      CHARACTER*80 CM, OR
      DATA GP /-0.5773502691896258D0, -0.5773502691896258D0,
     1          0.5773502691896258D0, -0.5773502691896258D0,
     2          0.5773502691896258D0,  0.5773502691896258D0,
     3         -0.5773502691896258D0,  0.5773502691896258D0/
      OPEN(13, FILE='verify/neck_nodes.txt')
      DO K = 1, NN
         WRITE(13,'(I4,1P,4E16.8)') K, XN(1,K), XN(2,K), UC(2*K-1),
     1         UC(2*K)
      ENDDO
      CLOSE(13)
      OPEN(13, FILE='verify/neck_elems.txt')
      DO IE = 1, NE
         WRITE(13,'(5I5)') IE, (IEL(K,IE), K=1,4)
      ENDDO
      CLOSE(13)
      OPEN(13, FILE='verify/neck_gp.txt')
      DMAX = 0.0D0
      DO IE = 1, NE
         DO K = 1, 4
            X(1,K) = XN(1,IEL(K,IE))
            X(2,K) = XN(2,IEL(K,IE))
         ENDDO
         DO IP = 1, 4
            XI = GP(1,IP)
            ET = GP(2,IP)
            XG = 0.0D0
            YG = 0.0D0
            DO K = 1, 4
               SH = 0.25D0*(1.0D0 + XI*SGN(K,1))*(1.0D0 + ET*SGN(K,2))
               XG = XG + SH*(XN(1,IEL(K,IE)) + UC(2*IEL(K,IE)-1))
               YG = YG + SH*(XN(2,IEL(K,IE)) + UC(2*IEL(K,IE)))
            ENDDO
            CALL UVARM(UVAR,DIR,T,TIME,0.0D0,CM,OR,5,1000+IE,IP,1,1,1,1,
     1                 3,1,COORD,JMAC,JMATYP,1,1)
            IB = (IP-1)*9
            SXX = SVC(IB+1,IE)
            SYY = SVC(IB+2,IE)
            SZZ = SVC(IB+3,IE)
            SXY = SVC(IB+4,IE)
            P = (SXX+SYY+SZZ)/3.0D0
            QV = SQRT(1.5D0*((SXX-P)**2+(SYY-P)**2+(SZZ-P)**2
     1                 + 2.0D0*SXY**2))
            DMAX = MAX(DMAX, ABS(UVAR(1)-SVC(IB+9,IE)),
     1                 ABS(UVAR(2)-QV), ABS(UVAR(3)-SXX),
     2                 ABS(UVAR(4)-SYY), ABS(UVAR(5)-SXY))
            WRITE(13,'(2I4,1P,7E16.8)') IE, IP, XG, YG, UVAR(1),
     1            UVAR(2), UVAR(3), UVAR(4), UVAR(5)
         ENDDO
      ENDDO
      CLOSE(13)
      WRITE(10,'(A,1P,E14.6)') 'uvarm_maxdiff ', DMAX
      UVAR = -1.0D0
      CALL UVARM(UVAR,DIR,T,TIME,0.0D0,CM,OR,5,1,1,1,1,1,1,3,1,COORD,
     1           JMAC,JMATYP,1,1)
      WRITE(10,'(A,1P,E14.6)') 'uvarm_outside ', ABS(UVAR(1))
      RETURN
      END
!
      FUNCTION SGN(K, IC)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XS(4), YS(4)
      DATA XS /-1.0D0, 1.0D0, 1.0D0, -1.0D0/
      DATA YS /-1.0D0, -1.0D0, 1.0D0, 1.0D0/
      IF (IC .EQ. 1) THEN
         SGN = XS(K)
      ELSE
         SGN = YS(K)
      ENDIF
      RETURN
      END
!
      SUBROUTINE PATCHCHK()
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NNM = 60, NEM = 40, NDM = 120)
      COMMON /MESH/ XN(2,NNM), IEL(4,NEM), NN, NE, NPD, IPD(NDM),
     1  VPD(NDM), SVC(37,NEM), UC(NDM), PR(5)
      SMAX = -1.0D30
      SMIN = 1.0D30
      PMAX = -1.0D30
      PMIN = 1.0D30
      DO IE = 1, NE
         DO IP = 1, 4
            IB = (IP-1)*9
            SMAX = MAX(SMAX, SVC(IB+1,IE))
            SMIN = MIN(SMIN, SVC(IB+1,IE))
            PMAX = MAX(PMAX, SVC(IB+9,IE))
            PMIN = MIN(PMIN, SVC(IB+9,IE))
         ENDDO
      ENDDO
      UX = 4.0D-3*XN(1,5) + 1.0D-3*XN(2,5)
      UY = -1.0D-3*XN(2,5) + 1.0D-3*XN(1,5)
      WRITE(10,'(A,1P,E14.6)') 'patch_s11 ', SMAX
      WRITE(10,'(A,1P,E14.6)') 'patch_s11_spread ', SMAX - SMIN
      WRITE(10,'(A,1P,E14.6)') 'patch_peeq ', PMAX
      WRITE(10,'(A,1P,E14.6)') 'patch_peeq_spread ', PMAX - PMIN
      WRITE(10,'(A,1P,2E14.6)') 'patch_unode_err ',
     1   ABS(UC(9) - UX), ABS(UC(10) - UY)
      RETURN
      END
