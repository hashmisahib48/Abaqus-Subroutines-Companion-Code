      SUBROUTINE K11_TRUSS(X0, U, AREA, EM, IGEOM, FINT, AKT, S, EG,
     1                     STRCH, XL0)
!     Total-Lagrangian two-node plane truss (St. Venant-Kirchhoff)
!     X0(2,2) reference coordinates; U(4) total displacements
!     IGEOM = 1 large displacement, 0 small displacement (linear)
!     FINT(4) internal force (N); AKT(4,4) tangent dFINT/dU (N/mm)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X0(2,2), U(4), FINT(4), AKT(4,4), D0(2), D(2)
      D0(1) = X0(1,2) - X0(1,1)
      D0(2) = X0(2,2) - X0(2,1)
      XL02  = D0(1)**2 + D0(2)**2
      XL0   = SQRT(XL02)
      D(1)  = D0(1) + U(3) - U(1)
      D(2)  = D0(2) + U(4) - U(2)
      STRCH = SQRT(D(1)**2 + D(2)**2)/XL0
      IF (IGEOM .EQ. 1) THEN
         EG = 0.5D0*((D(1)**2 + D(2)**2)/XL02 - 1.0D0)
      ELSE
         D(1) = D0(1)
         D(2) = D0(2)
         EG = (D0(1)*(U(3)-U(1)) + D0(2)*(U(4)-U(2)))/XL02
      ENDIF
      S  = EM*EG                          ! 2nd P-K stress (MPa)
      CC = AREA*S/XL0                     ! geometric stiffness
      CM = AREA*EM/(XL0*XL02)             ! material stiffness
      FINT(1) = -CC*D(1)
      FINT(2) = -CC*D(2)
      FINT(3) =  CC*D(1)
      FINT(4) =  CC*D(2)
      DO J = 1, 2
         DO I = 1, 2
            BLK = CM*D(I)*D(J)
            IF (I .EQ. J .AND. IGEOM .EQ. 1) BLK = BLK + CC
            AKT(I,J)     =  BLK
            AKT(I+2,J+2) =  BLK
            AKT(I,J+2)   = -BLK
            AKT(I+2,J)   = -BLK
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K11_MASS(AREA, RHO, XL0, IMASS, AM)
!     Element mass matrix, DOF order (u1,v1,u2,v2)
!     IMASS = 0 lumped, 1 consistent
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION AM(4,4)
      AM = 0.0D0
      C = RHO*AREA*XL0
      IF (IMASS .EQ. 1) THEN
         DO I = 1, 2
            AM(I,I)     = C/3.0D0
            AM(I+2,I+2) = C/3.0D0
            AM(I,I+2)   = C/6.0D0
            AM(I+2,I)   = C/6.0D0
         ENDDO
      ELSE
         DO I = 1, 4
            AM(I,I) = 0.5D0*C
         ENDDO
      ENDIF
      RETURN
      END
