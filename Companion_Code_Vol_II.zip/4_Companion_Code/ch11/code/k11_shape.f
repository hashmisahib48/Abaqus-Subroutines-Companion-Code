      SUBROUTINE K11_SHAPE(XI, ETA, X, DNX, DETJ)
!     Bilinear quadrilateral: derivatives dN/dx, dN/dy at (XI,ETA),
!     Jacobian determinant. Nodes counter-clockwise from (-1,-1).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), DNX(2,4), DNL(2,4), AJ(2,2), XN(4), YN(4)
      DATA XN /-1.0D0, 1.0D0, 1.0D0, -1.0D0/
      DATA YN /-1.0D0, -1.0D0, 1.0D0, 1.0D0/
      DO K = 1, 4
         DNL(1,K) = 0.25D0*XN(K)*(1.0D0 + YN(K)*ETA)
         DNL(2,K) = 0.25D0*YN(K)*(1.0D0 + XN(K)*XI)
      ENDDO
      DO J = 1, 2
         DO I = 1, 2
            AJ(I,J) = 0.0D0
            DO K = 1, 4
               AJ(I,J) = AJ(I,J) + DNL(I,K)*X(J,K)
            ENDDO
         ENDDO
      ENDDO
      DETJ = AJ(1,1)*AJ(2,2) - AJ(1,2)*AJ(2,1)
      DO K = 1, 4
         DNX(1,K) = ( AJ(2,2)*DNL(1,K) - AJ(1,2)*DNL(2,K))/DETJ
         DNX(2,K) = (-AJ(2,1)*DNL(1,K) + AJ(1,1)*DNL(2,K))/DETJ
      ENDDO
      RETURN
      END
