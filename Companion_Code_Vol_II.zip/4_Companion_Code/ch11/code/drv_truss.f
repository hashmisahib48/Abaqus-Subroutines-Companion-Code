!     Test harness for the truss U1 (Chapter 11, Section 11.3)
!     1  finite-difference check of AMATRX against RHS
!     2  rigid-body rotation
!     3  von Mises truss: Newton iteration, closed-form comparison
      PROGRAM DRVTRUSS
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(4), X(2,2), U(4), DU(4), V(4), A(4), SV(7)
      DIMENSION RHS(4), AM(4,4), EN(8), PAR(3), LF(10), AK(4,4)
      DIMENSION RP(4), RM(4), UP(4), AFD(4,4), AFD2(4,4), SV0(7), AMM(4,4), UG(6)
      COMMON /PRM/ AREA, EMOD, HGT, HSP
      OPEN(10, FILE='verify/truss_out.txt')
      AREA = 100.0D0
      EMOD = 210000.0D0
      PROPS(1) = AREA
      PROPS(2) = EMOD
      PROPS(3) = 7.85D-9
      PROPS(4) = 0.0D0
      PAR = 0.0D0
      V = 0.0D0
      A = 0.0D0
      DU = 0.0D0
      LF = 0
      LF(1) = 1
      LF(2) = 1
      LF(3) = 1
!
!     ---- 1. finite-difference check of the tangent
      X(1,1) = 0.0D0
      X(2,1) = 0.0D0
      X(1,2) = 600.0D0
      X(2,2) = 400.0D0
      U(1) = 3.0D0
      U(2) = -2.0D0
      U(3) = 20.0D0
      U(4) = -15.0D0
      SV = 0.0D0
      CALL K11_CALLUEL(1,4,2,PROPS,4,X,U,DU,V,A,SV,7,LF,1.0D0,PAR,1,
     1                 RHS,AK,EN,PNEW)
      H = 1.0D-4
      DO J = 1, 4
         UP = U
         UP(J) = U(J) + H
         SV0 = SV
         CALL K11_CALLUEL(1,4,2,PROPS,4,X,UP,DU,V,A,SV0,7,LF,1.0D0,PAR,
     1                    1,RP,AM,EN,PNEW)
         UP(J) = U(J) - H
         SV0 = SV
         CALL K11_CALLUEL(1,4,2,PROPS,4,X,UP,DU,V,A,SV0,7,LF,1.0D0,PAR,
     1                    1,RM,AM,EN,PNEW)
         DO I = 1, 4
            AFD(I,J) = -(RP(I) - RM(I))/(2.0D0*H)
         ENDDO
      ENDDO
      ERR = 0.0D0
      REF = 0.0D0
      DO J = 1, 4
         DO I = 1, 4
            ERR = MAX(ERR, ABS(AK(I,J) - AFD(I,J)))
            REF = MAX(REF, ABS(AFD(I,J)))
         ENDDO
      ENDDO
      WRITE(10,'(A,1P,E14.6)') 'fd_err_rel ', ERR/REF
      WRITE(10,'(A,1P,E14.6)') 'fd_kmax ', REF
      WRITE(10,'(A,1P,E14.6)') 'fd_eg ', SV(2)
!     step-size sweep of the central difference
      DO KH = -10, 2
         H = 10.0D0**KH
         DO J = 1, 4
            UP = U
            UP(J) = U(J) + H
            SV0 = SV
            CALL K11_CALLUEL(1,4,2,PROPS,4,X,UP,DU,V,A,SV0,7,LF,1.0D0,
     1                       PAR,1,RP,AM,EN,PNEW)
            UP(J) = U(J) - H
            SV0 = SV
            CALL K11_CALLUEL(1,4,2,PROPS,4,X,UP,DU,V,A,SV0,7,LF,1.0D0,
     1                       PAR,1,RM,AM,EN,PNEW)
            DO I = 1, 4
               AFD2(I,J) = -(RP(I) - RM(I))/(2.0D0*H)
            ENDDO
         ENDDO
         ERRH = 0.0D0
         DO J = 1, 4
            DO I = 1, 4
               ERRH = MAX(ERRH, ABS(AK(I,J) - AFD2(I,J)))
            ENDDO
         ENDDO
         WRITE(10,'(A,I4,1P,E14.6)') 'fd_h ', KH, ERRH/REF
      ENDDO
!     tangent without the geometric (initial-stress) term
      CALL K11_TRUSS(X, U, AREA, EMOD, 1, RHS, AMM, S, EG, STRCH, XL0)
      CC = AREA*S/XL0
      DO I = 1, 2
         AMM(I,I)     = AMM(I,I) - CC
         AMM(I+2,I+2) = AMM(I+2,I+2) - CC
         AMM(I,I+2)   = AMM(I,I+2) + CC
         AMM(I+2,I)   = AMM(I+2,I) + CC
      ENDDO
      ERR2 = 0.0D0
      DO J = 1, 4
         DO I = 1, 4
            ERR2 = MAX(ERR2, ABS(AMM(I,J) - AFD(I,J)))
         ENDDO
      ENDDO
      WRITE(10,'(A,1P,E14.6)') 'fd_err_nogeo_rel ', ERR2/REF
!
!     ---- 2. rigid rotation of the element by 30 degrees
      TH = 30.0D0*ATAN(1.0D0)/45.0D0
      U(1) = 0.0D0
      U(2) = 0.0D0
      U(3) = (COS(TH) - 1.0D0)*X(1,2) - SIN(TH)*X(2,2)
      U(4) = SIN(TH)*X(1,2) + (COS(TH) - 1.0D0)*X(2,2)
      DO IG = 1, 0, -1
         LF(2) = IG
         SV = 0.0D0
         CALL K11_CALLUEL(1,4,2,PROPS,4,X,U,DU,V,A,SV,7,LF,1.0D0,PAR,
     1                    1,RHS,AK,EN,PNEW)
         FN = SQRT(RHS(1)**2 + RHS(2)**2 + RHS(3)**2 + RHS(4)**2)
         WRITE(10,'(A,I1,1P,E14.6)') 'rot_force_igeom', IG, FN
      ENDDO
      LF(2) = 1
!
!     ---- 3. von Mises truss
      HSP = 1000.0D0
      HGT = 100.0D0
      XL0 = SQRT(HSP**2 + HGT**2)
      PMAX = 2.0D0*AREA*EMOD*HGT**3/(3.0D0*SQRT(3.0D0)*XL0**3)
      WSNAP = HGT*(1.0D0 - 1.0D0/SQRT(3.0D0))
      WRITE(10,'(A,1P,E14.6)') 'pmax_closed ', PMAX
      WRITE(10,'(A,1P,E14.6)') 'wsnap_closed ', WSNAP
      WRITE(10,'(A,1P,E14.6)') 'l0 ', XL0
      WRITE(10,'(A,1P,E14.6)') 'k0_closed ', 2.0D0*AREA*EMOD*HGT**2/
     1                         XL0**3
!     3a displacement control: apex moved down in steps of 2 mm
      UG = 0.0D0
      EMAXERR = 0.0D0
      NITT = 0
      DO KS = 0, 60
         W = 2.0D0*KS
         UG(4) = -W
         DO IT = 1, 30
            CALL K11_VM(UG, 0.0D0, 1, R3, R4, AK3, AK34, AK43, AK44, P)
            IF (ABS(R3) .LT. 1.0D-9) GO TO 10
            UG(3) = UG(3) + R3/AK3
         ENDDO
   10    CONTINUE
         NITT = NITT + IT
         PC = AREA*EMOD*(HGT-W)*(HGT**2-(HGT-W)**2)/XL0**3
         EMAXERR = MAX(EMAXERR, ABS(P-PC))
         WRITE(10,'(A,F8.2,2F16.6,I4,1P,E12.3)') 'dc ', W, P, PC, IT,
     1         UG(3)
      ENDDO
      WRITE(10,'(A,1P,E14.6)') 'dc_maxerr ', EMAXERR
      WRITE(10,'(A,I6)') 'dc_iters_total ', NITT
!     3b load control, three tangents; one increment to a given load
      DO IFR = 1, 2
         FR = 0.5D0
         IF (IFR .EQ. 2) FR = 0.9D0
         DO ITG = 1, 3
            UG = 0.0D0
            WRITE(10,'(A,I2,I2)') 'lc_begin ', IFR, ITG
            DO IT = 0, 40
               CALL K11_VM(UG, FR*PMAX, ITG, R3, R4, AK3, AK34, AK43,
     1                     AK44, P)
               RN = SQRT(R3**2 + R4**2)
               WRITE(10,'(A,I3,1P,E14.6)') 'lc ', IT, RN
               IF (RN .LT. 1.0D-8 .OR. IT .EQ. 40) THEN
                  WRITE(10,'(A,I2,I2,I4,F12.5)') 'lc_end ', IFR, ITG,
     1                  IT, -UG(4)
                  GO TO 20
               ENDIF
               DET = AK3*AK44 - AK34*AK43
               UG(3) = UG(3) + ( AK44*R3 - AK34*R4)/DET
               UG(4) = UG(4) + (-AK43*R3 + AK3*R4)/DET
            ENDDO
   20       CONTINUE
         ENDDO
      ENDDO
      CLOSE(10)
      END
!
      SUBROUTINE K11_VM(UG, PEXT, ITG, R3, R4, AK3, AK34, AK43, AK44,
     1                  P)
!     Residual (external minus internal force) of the apex DOFs (3,4)
!     of the von Mises truss for the downward load PEXT.  Tangent type
!     ITG: 1 consistent, 2 material part only, 3 initial stiffness.
!     P returns the downward force that holds the apex in equilibrium.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION UG(6), X(2,2), U(4), DU(4), V(4), A(4), SV(7), PAR(3)
      DIMENSION RHS(4), AK(4,4), EN(8), PROPS(4), LF(10), AK0(4,4)
      COMMON /PRM/ AREA, EMOD, HGT, HSP
      PROPS(1) = AREA
      PROPS(2) = EMOD
      PROPS(3) = 7.85D-9
      PROPS(4) = 0.0D0
      PAR = 0.0D0
      DU = 0.0D0
      V = 0.0D0
      A = 0.0D0
      LF = 0
      LF(1) = 1
      LF(2) = 1
      LF(3) = 1
      F3 = 0.0D0
      F4 = 0.0D0
      AK3 = 0.0D0
      AK34 = 0.0D0
      AK43 = 0.0D0
      AK44 = 0.0D0
      DO IE = 1, 2
         IF (IE .EQ. 1) THEN
            X(1,1) = -HSP
            X(2,1) = 0.0D0
            X(1,2) = 0.0D0
            X(2,2) = HGT
            U = (/ 0.0D0, 0.0D0, UG(3), UG(4) /)
            I3 = 3
            I4 = 4
         ELSE
            X(1,1) = 0.0D0
            X(2,1) = HGT
            X(1,2) = HSP
            X(2,2) = 0.0D0
            U = (/ UG(3), UG(4), 0.0D0, 0.0D0 /)
            I3 = 1
            I4 = 2
         ENDIF
         SV = 0.0D0
         CALL K11_CALLUEL(1,4,2,PROPS,4,X,U,DU,V,A,SV,7,LF,1.0D0,PAR,
     1                    IE,RHS,AK,EN,PNEW)
         F3 = F3 - RHS(I3)
         F4 = F4 - RHS(I4)
         IF (ITG .EQ. 2) THEN
            CALL K11_TRUSS(X, U, AREA, EMOD, 1, RHS, AK, S, EG, STRCH,
     1                     XL0)
            CC = AREA*S/XL0
            DO I = 1, 2
               AK(I,I)     = AK(I,I) - CC
               AK(I+2,I+2) = AK(I+2,I+2) - CC
               AK(I,I+2)   = AK(I,I+2) + CC
               AK(I+2,I)   = AK(I+2,I) + CC
            ENDDO
         ELSE IF (ITG .EQ. 3) THEN
            U = 0.0D0
            SV = 0.0D0
            CALL K11_CALLUEL(1,4,2,PROPS,4,X,U,DU,V,A,SV,7,LF,1.0D0,
     1                       PAR,IE,RHS,AK,EN,PNEW)
         ENDIF
         AK3  = AK3  + AK(I3,I3)
         AK34 = AK34 + AK(I3,I4)
         AK43 = AK43 + AK(I4,I3)
         AK44 = AK44 + AK(I4,I4)
      ENDDO
      R3 = -F3
      R4 = -PEXT - F4
      P  = -F4
      RETURN
      END
