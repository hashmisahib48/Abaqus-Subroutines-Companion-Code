      SUBROUTINE K11_SOLVE(A, B, N, NMAX, IERR)
!     Test-harness utility (not part of the element): solves A x = B
!     by Gaussian elimination with partial pivoting; x overwrites B.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(NMAX,NMAX), B(NMAX)
      IERR = 0
      DO K = 1, N
         IP = K
         DO I = K+1, N
            IF (ABS(A(I,K)) .GT. ABS(A(IP,K))) IP = I
         ENDDO
         IF (ABS(A(IP,K)) .LT. 1.0D-300) THEN
            IERR = K
            RETURN
         ENDIF
         IF (IP .NE. K) THEN
            DO J = 1, N
               T = A(K,J)
               A(K,J) = A(IP,J)
               A(IP,J) = T
            ENDDO
            T = B(K)
            B(K) = B(IP)
            B(IP) = T
         ENDIF
         DO I = K+1, N
            F = A(I,K)/A(K,K)
            IF (F .NE. 0.0D0) THEN
               DO J = K, N
                  A(I,J) = A(I,J) - F*A(K,J)
               ENDDO
               B(I) = B(I) - F*B(K)
            ENDIF
         ENDDO
      ENDDO
      DO K = N, 1, -1
         S = B(K)
         DO J = K+1, N
            S = S - A(K,J)*B(J)
         ENDDO
         B(K) = S/A(K,K)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K11_CALLUEL(JT,NDOF,NNOD,PROPS,NPR,X,U,DU,V,A,SV,NSV,
     1 LF,DT,PARAMS,JEL,RHS,AMAT,EN,PNEW)
!     Calls UEL the way Abaqus does, with dummy load/field arguments
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(NPR),X(2,NNOD),U(NDOF),DU(NDOF),V(NDOF),A(NDOF),
     1 SV(NSV),LF(10),PARAMS(3),RHS(NDOF),AMAT(NDOF,NDOF),EN(8)
      DIMENSION TIME(2),JDLTYP(1,1),ADLMAG(1,1),DDLMAG(1,1),
     1 PREDEF(2,1,NNOD),JPR(1)
      TIME(1) = 0.0D0
      TIME(2) = 0.0D0
      JPR(1) = 0
      PNEW = 1.0D36
      DO I = 1, NDOF
         RHS(I) = 0.0D0
      ENDDO
      CALL UEL(RHS,AMAT,SV,EN,NDOF,1,NSV,PROPS,NPR,X,2,NNOD,U,DU,V,A,
     1 JT,TIME,DT,1,1,JEL,PARAMS,0,JDLTYP,ADLMAG,PREDEF,0,LF,NDOF,
     2 DDLMAG,1,PNEW,JPR,0,1.0D0)
      RETURN
      END
