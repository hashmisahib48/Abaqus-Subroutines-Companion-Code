import json, numpy as np, subprocess, tempfile, os
from h18lib import *
import t_mat as M, t_el as E, t_con as C, run18
L=Lib(build()); out={}
# A1
G,K=1.2,100.; out['A1']=dict(E=9*K*G/(3*K+G),nu=(3*K-2*G)/(2*(3*K+G)))
# A2
Et=10000.; nu=0.25; _,Kk,_,_=L.uel(E.SQ,[2000,nu,5,0],np.zeros(8),2); out['A2']=dict(eig=np.linalg.eigvalsh(Kk).tolist(),f=[Et/(1-nu),Et/(1+nu),Et*(3-nu)/(6*(1-nu**2))])
# A3
P=C.Pt(L); P.step(-0.02,[0,0]); a=(P.p,P.dd[0,0]); P=C.Pt(L); P.step(0.01,[0,0]); p=P.p; P.step(0.01,[0.05,0]); out['A3']=dict(p1=a[0],k1=a[1],p2=p,lim=0.3*p,gs=0.3*p/50,tau=P.tau[0],sfd=P.sfd)
# B2 covariance of the tangent
_,K0,_,_=L.uel(E.SQ,E.PT,np.zeros(8),2); th=0.7; u=E.rot_u(E.SQ,th,(0,0)); _,Kr,_,_=L.uel(E.SQ,E.PT,u,2)
R=np.array([[np.cos(th),-np.sin(th)],[np.sin(th),np.cos(th)]]); Q=np.kron(np.eye(4),R)
out['B2']=dict(err=float(np.max(np.abs(Kr-Q@K0@Q.T))/np.max(np.abs(K0))),ratio=float(np.max(np.abs(Kr-K0))/np.max(np.abs(K0))))
# B3 bug listing
src=open('../code/ex18_uinter.f').read()
bugs=[('FLIM = AMU*P','FLIM = AMU*STATEV(4)'),('GE(K)  = TAU(K)/AKT','GE(K)  = GE(K)'),('DIS = DIS + TAU(K)*(DRDISP(K+1) - DGE)','DIS = DIS + TAU(K)*DRDISP(K+1)'),('DDSDDR(K+1,L+1) = -FLIM*AKT*TT(K)*TT(L)/TN**3','DDSDDR(K+1,L+1) = FLIM*AKT*TT(K)*TT(L)/TN**3')]
for o,n in bugs: assert src.count(o)==1; src=src.replace(o,n)
open('../code/prob_18b3_bug.f','w').write(src)
d=tempfile.mkdtemp(); fs=[]
for f in ('ex18_uhyper.f','ex18_uel.f','ex18_calls.f'): fs.append(CODE+'/'+f)
fs.append('../code/prob_18b3_bug.f')
so=d+'/b.so'; subprocess.check_call(['gfortran','-shared','-fPIC','-ffixed-form','-std=legacy','-I'+INC,*fs,INC+'/stubs.f','-o',so],stderr=subprocess.DEVNULL)
Lb=Lib(so); R=C.run_all(Lb); out['B3']={k:[float(v[0]),bool(v[1])] for k,v in R.items()}
# C1 Gent from Chapter 2
d=tempfile.mkdtemp(); so=d+'/g.so'
subprocess.check_call(['gfortran','-shared','-fPIC','-ffixed-form','-std=legacy','-I'+INC,'/home/claude/vol2/ch02/code/ex2_uhyper_gent.f',CODE+'/ex18_calls.f',CODE+'/ex18_uel.f',CODE+'/ex18_uinter.f',INC+'/stubs.f','-o',so],stderr=subprocess.DEVNULL)
Lg=Lib(so); pr=[1.0,30.0,0.3,0.02]
xs,m=M.drucker_map(Lg,pr,1.1,31); dmin=float(np.nanmin(m)); emin=1e9
for mode in ('uni','bi'):
    for lam in np.linspace(0.45,3.0,14): emin=min(emin,M.ellip(Lg,M.path_F(mode,lam),pr)[0])
out['C1']=dict(drucker=dmin,ellip=float(emin),stab=M.m7_stab(Lg,pr)); 
# also M1-style FD of derivatives with the gent routine
out['C1']['fd']=M.m4_fd(Lg,pr)[0]
# C2 nonlinear patch, total Lagrangian
th=np.radians(25); Rm=np.array([[np.cos(th),-np.sin(th)],[np.sin(th),np.cos(th)]]); F0=Rm@np.array([[1.08,0.04],[-0.02,0.95]])
X=E.PATCH_X; ue=((F0-np.eye(2))@X.T).T.ravel(); u=np.zeros(16); u[:8]=ue[:8]; free=np.arange(8,16); res=[]
for it in range(12):
    Rg=np.zeros(16); Kg=np.zeros((16,16))
    for el in E.PATCH_E:
        dofs=np.array([[2*n,2*n+1] for n in el]).ravel(); r,Ke,_,_=L.uel(X[list(el)],E.PT,u[dofs],1); Rg[dofs]+=r; Kg[np.ix_(dofs,dofs)]+=Ke
    res.append(float(np.max(np.abs(Rg[free])))); 
    if res[-1]<1e-12: break
    u[free]+=np.linalg.solve(Kg[np.ix_(free,free)],Rg[free])
out['C2']=dict(res=res,err=float(np.max(np.abs(u-ue))/np.max(np.abs(ue))))
json.dump(out,open('out/probs.json','w'),indent=1,default=float)
print(json.dumps(out,default=float)[:3000])
