"""Numbers quoted in the chapter (everything computed by the routines of ch18/code)."""
import json, numpy as np
from h18lib import build, Lib
import t_mat as M, t_el as E, t_con as C, run18
L=Lib(build()); out={}
# ---------------- material -----------------
def A9(F,pr): return M.tangent(L,F,pr).reshape(9,9)
def mins(mode,lam,pr):
    F=M.path_F(mode,lam); q,_=M.ellip(L,F,pr); a=np.linalg.eigvalsh(0.5*(A9(F,pr)+A9(F,pr).T))[0]
    h=np.linalg.eigvalsh(M.hess(L,np.log(np.diag(F)),pr))[0]; return h,q,a
def root(f,a,b,n=60):
    fa=f(a)
    for _ in range(n):
        m=0.5*(a+b); fm=f(m)
        if (fm>0)==(fa>0): a,fa=m,fm
        else: b=m
    return 0.5*(a+b)
mat={}
w=np.linalg.eigvalsh(0.5*(A9(np.eye(3),M.PR)+A9(np.eye(3),M.PR).T)); mat['A_ref']=w.tolist()
for name,pr in (('pos',M.PR),('neg',[0.5,-0.1,0.02])):
    d={}
    for mode in ('uni','bi'):
        lam=np.linspace(0.4,3.4,121); H=[];Q=[];A=[]
        for l in lam:
            h,q,a=mins(mode,l,pr); H.append(h);Q.append(q);A.append(a)
        d[mode]={'lam':lam.tolist(),'drucker':H,'ellip':Q,'A':A}
        for key,arr in (('drucker',H),('ellip',Q)):
            arr=np.array(arr); th=[]
            for k in range(len(lam)-1):
                if (arr[k]>0)!=(arr[k+1]>0):
                    f=(lambda l,idx=0: mins(mode,l,pr)[0 if key=='drucker' else 1])
                    th.append(root(f,lam[k],lam[k+1],40))
            d[mode][key+'_loss']=th
    xs,m=M.drucker_map(L,pr,1.2,61); d['frac_unstable']=float(np.sum(m<0)/np.sum(~np.isnan(m))); d['dmin']=float(np.nanmin(m))
    mat[name]=d
out['mat']=mat
# ---------------- element -----------------
el={}
_,K,_,_=L.uel(E.SQ,E.PL,np.zeros(8),2); el['sq_eig']=np.linalg.eigvalsh(K).tolist()
_,K,_,_=L.uel(E.DQ,E.PL,np.zeros(8),2); el['dq_eig']=np.linalg.eigvalsh(K).tolist(); el['dq_ref_eig']=np.linalg.eigvalsh(E.ref_k(E.DQ)).tolist()
el['spec_err']=E.e2_spectrum(L)[0]; el['patch']=E.e3_patch(L)[1]
el['rot']=[float(x) for x in E.e5_rotation(L)[:2]]+[E.e5_rotation(L)[2].tolist()]
el['fd_stressed']=E.e4_fd(L); el['fd_unstressed']=E.e4_fd_unstressed(L)
el['energy']=E.e6_energy(L); el['rigid']=E.e1_rigid(L)
el['conv']=[(int(n),float(a),float(b)) for n,a,b in E.e7_convergence(L,ns=(4,8,16,32))]
el['conv_reg']=[(int(n),float(a),float(b)) for n,a,b in E.e7_convergence(L,ns=(4,8,16,32),pert=0.0)]
fl={f[0]:f for f in run18.FAULTS['el']}
def fl_lib(c): return Lib(build(fl[c][2],c))
Lf=fl_lib('E6'); el['E6_fd_stressed']=E.e4_fd(Lf); el['E6_fd_unstressed']=E.e4_fd_unstressed(Lf)
Lf=fl_lib('E3'); el['E3_conv_reg']=E.conv_rates(E.e7_convergence(Lf,ns=(16,32),pert=0.0)); el['E3_conv_dist']=E.conv_rates(E.e7_convergence(Lf,ns=(16,32)))
_,Kf,_,_=Lf.uel(E.SQ,E.PL,np.zeros(8),2); el['E3_sq_dev']=float(np.max(np.abs(Kf-E.ref_k(E.SQ)))/np.max(np.abs(E.ref_k(E.SQ))))
_,Kf,_,_=Lf.uel(E.DQ,E.PL,np.zeros(8),2); el['E3_dq_dev']=float(np.max(np.abs(Kf-E.ref_k(E.DQ)))/np.max(np.abs(E.ref_k(E.DQ)))); el['E3_dq_eig']=np.linalg.eigvalsh(Kf).tolist()
Lf=fl_lib('E2'); _,Kf,_,_=Lf.uel(E.SQ,E.PL,np.zeros(8),2); el['E2_sq_eig']=np.linalg.eigvalsh(Kf).tolist()
Lf=fl_lib('E1'); el['E1_patch']=E.e3_patch(Lf)[1]; _,Kf,_,_=Lf.uel(E.SQ,E.PL,np.zeros(8),2); el['E1_sq_eig']=np.linalg.eigvalsh(Kf).tolist()
Lf=fl_lib('E7'); r=E.e5_rotation(Lf); el['E7_rot']=float(r[0]); el['E7_fd']=E.e4_fd(Lf); el['E7_en']=E.e6_energy(Lf)
Lf=fl_lib('E4'); el['E4_fd']=E.e4_fd(Lf)
out['el']=el
# ---------------- contact -----------------
co={}
co['p']={d:C.pw(d) for d in (0.0,0.02)}; 
P=C.Pt(L); P.step(0.02,[0,0]); p=P.p; lim=C.MU*p
co['lim']=lim; co['gamma_slip']=lim/C.KT
loop=[]; Q=C.Pt(L); Q.step(0.02,[0,0]); 
path=[0.0]+[0.06]+[-0.06]*0
# loop: forward to s=0.06, back to -0.06, forward to 0.06 (many increments)
g=0.0; seq=np.concatenate([np.linspace(0,0.06,61),np.linspace(0.06,-0.06,121)[1:],np.linspace(-0.06,0.06,121)[1:]])
tau=[];dis=[]
for k in range(1,len(seq)): Q.step(0.02,[seq[k]-seq[k-1],0]); tau.append(float(Q.tau[0])); dis.append(Q.sfd)
co['loop']={'g':seq[1:].tolist(),'tau':tau,'sfd':dis}
co['bal']=[(n,C.c5_balance(L,n)[0]) for n in (250,500,1000,2000,4000,8000)]
co['inc']=C.c7_increments(L)[1].tolist(); co['inc_ref']=lim
cf={f[0]:f for f in run18.FAULTS['con']}
Lf=Lib(build(cf['K2'][2],'K2')); co['K2_inc']=C.c7_increments(Lf)[1].tolist()
Lf=Lib(build(cf['K6'][2],'K6')); co['K6_iso']=C.c6_isotropy(Lf)
Lf=Lib(build(cf['K1'][2],'K1')); co['K1_fd']=C.c3_fd(Lf)
Lf=Lib(build(cf['K4'][2],'K4')); co['K4_bal']=C.c5_balance(Lf,2000)[0]
Lf=Lib(build(cf['K3'][2],'K3')); co['K3_rev']=C.c2_reversal(Lf)
co['fd']=C.c3_fd(L); co['rev']=C.c2_reversal(L); co['iso']=C.c6_isotropy(L); co['nrg']=C.c4_normal_energy(L)
# histories for the hysteresis figure (variable pressure, 2-D slip path)
t,d,g=C.hist2d(2000); P=C.Pt(L); P.step(d[0],[0,0]); tt=[];pp=[]
for k in range(1,len(d)): P.step(d[k],g[k]-g[k-1]); tt.append(P.tau.tolist()); pp.append(P.p)
co['h2d']={'g':g[1:].tolist(),'tau':tt,'p':pp,'sfd':P.sfd,'sed':P.sed}
out['con']=co
json.dump(out,open('out/data.json','w'),default=float)
print('ok')
