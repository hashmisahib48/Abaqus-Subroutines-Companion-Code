"""Chapter 18 test harness: compiles the Fortran routines (clean or with one injected fault)
into a shared library and calls UHYPER, UEL and UINTER through ctypes, with the
argument lists of Abaqus (via the thin K18_CALL* wrappers of ex18_calls.f)."""
import ctypes as ct, numpy as np, subprocess, os, tempfile, shutil
CODE='/home/claude/vol2/ch18/code'; INC='/home/claude/vol2/lib/aba'
FILES=['ex18_uhyper.f','ex18_uel.f','ex18_uinter.f','ex18_calls.f']
def build(fault=None, tag='clean'):
    """fault = (file, old, new) or None -> path of the shared library"""
    d=tempfile.mkdtemp(prefix='k18_'); srcs=[]
    for f in FILES:
        s=open(os.path.join(CODE,f)).read()
        if fault and fault[0]==f:
            assert s.count(fault[1])==1,(fault[1],s.count(fault[1]))
            s=s.replace(fault[1],fault[2])
        p=os.path.join(d,f); open(p,'w').write(s); srcs.append(p)
    so=os.path.join(d,'lib_%s.so'%tag)
    subprocess.check_call(['gfortran','-shared','-fPIC','-ffixed-form','-std=legacy','-I'+INC,*srcs,INC+'/stubs.f','-o',so],stderr=subprocess.DEVNULL)
    return so
def _d(x): return ct.byref(ct.c_double(x))
def _i(n): return ct.byref(ct.c_int(n))
def _a(a): return a.ctypes.data_as(ct.c_void_p)
class Lib:
    def __init__(self,so): self.l=ct.CDLL(so)
    def hyper(self,bi1,bi2,aj,incmp,props):
        pr=np.ascontiguousarray(props,dtype=float); U=np.zeros(2); u1=np.zeros(3); u2=np.zeros(6); u3=np.zeros(6)
        self.l.k18_callh_(_d(bi1),_d(bi2),_d(aj),_i(incmp),_i(len(pr)),_a(pr),_a(U),_a(u1),_a(u2),_a(u3))
        return U,u1,u2,u3
    def uel(self,coords,props,u,lf3=1):
        co=np.ascontiguousarray(coords,dtype=float).reshape(4,2); pr=np.ascontiguousarray(props,dtype=float)
        uu=np.ascontiguousarray(u,dtype=float); rhs=np.zeros((8,1),order='F'); am=np.zeros((8,8),order='F')
        sv=np.zeros(12); en=np.zeros(8)
        self.l.k18_calle_(_i(1),_a(co),_a(pr),_a(uu),_i(lf3),_a(rhs),_a(am),_a(sv),_a(en))
        return rhs[:,0].copy(),am.copy(),sv,en[1]
    def uinter(self,rdisp,drdisp,statev,props):
        rd=np.ascontiguousarray(rdisp,dtype=float); dr=np.ascontiguousarray(drdisp,dtype=float)
        sv=np.ascontiguousarray(statev,dtype=float).copy(); pr=np.ascontiguousarray(props,dtype=float)
        st=np.zeros(3); dd=np.zeros((3,3),order='F'); sed=ct.c_double(0); sfd=ct.c_double(0)
        self.l.k18_callu_(_a(rd),_a(dr),_a(sv),_a(pr),_a(st),_a(dd),ct.byref(sed),ct.byref(sfd))
        return st,dd.copy(),sv,sed.value,sfd.value
