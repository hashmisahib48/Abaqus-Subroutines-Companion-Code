"""Verification matrix of the user interaction (softened normal law + regularised Coulomb friction)."""
import numpy as np
from h18lib import Lib
KN,CC,KT,MU=100.0,0.05,50.0,0.3          # MPa/mm, mm, MPa/mm, -
PR=np.array([KN,CC,KT,MU])
def pw(d): return KN*(d+CC)**2/(2*CC) if -CC<d<0 else (KN*(d+CC/2) if d>=0 else 0.0)
def Wn(d): return KN*(d+CC)**3/(6*CC) if -CC<d<0 else (KN*(d*d/2+CC*d/2+CC*CC/6) if d>=0 else 0.0)
class Pt:
    """one contact point: calls UINTER increment by increment like Abaqus"""
    def __init__(s,L,pr=PR): s.L=L; s.pr=pr; s.sv=np.zeros(4); s.d=0.0; s.g=np.zeros(2); s.tau=np.zeros(2); s.p=0.0; s.sed=0.0; s.sfd=0.0
    def step(s,d,dg):
        dg=np.asarray(dg,float); s.g=s.g+dg
        st,dd,s.sv,s.sed,s.sfd=s.L.uinter([d,s.g[0],s.g[1]],[d-s.d,dg[0],dg[1]],s.sv,s.pr)
        s.d=d; s.p=st[0]; s.tau=st[1:].copy(); s.dd=dd; return st
def c1_points(L):
    e=0; P=Pt(L)
    for d in (-0.08,-0.05,-0.03,-0.025,0.0,0.02):
        P=Pt(L); st=P.step(d,[0,0]); e=max(e,abs(st[0]-pw(d))/KN/CC, abs(P.sed-Wn(d))/(KN*CC*CC))
    # stick, then slip, at constant overclosure d=0.01
    P=Pt(L); P.step(0.01,[0,0]); p=pw(0.01); st=P.step(0.01,[0.004,0]); e=max(e,abs(st[1]-KT*0.004)/(KT*0.004))
    st=P.step(0.01,[0.05,0.0]); e=max(e,abs(st[1]-MU*p)/(MU*p),abs(st[2]))
    st=P.step(0.01,[0.0,0.03]); ang=np.arctan2(st[2],st[1]); e=max(e,abs(np.hypot(st[1],st[2])-MU*p)/(MU*p))
    # open and far points
    P=Pt(L); st=P.step(-0.2,[0.01,0.0]); e=max(e,np.max(np.abs(st)))
    st,dd,sv,sed,sfd=L.uinter([-1e36,0,0],[0,0,0],np.zeros(4),PR); e=max(e,np.max(np.abs(st)),np.max(np.abs(dd)),abs(sed))
    return e
def c2_reversal(L):
    """slide s, then reverse by d: tau = mu p - kt d until -mu p at d = 2 mu p/kt; dissipation closed form"""
    P=Pt(L); P.step(0.02,[0,0]); p=pw(0.02); lim=MU*p; s=0.05; P.step(0.02,[s,0]); e=0; sfd0=P.sfd
    e=max(e,abs(P.sfd-lim*(s-lim/KT))/(lim*s))
    for d in (0.1*lim/KT,lim/KT,2*lim/KT,3*lim/KT,0.06):
        Q=Pt(L); Q.step(0.02,[0,0]); Q.step(0.02,[s,0]); st=Q.step(0.02,[-d,0])
        ref=max(lim-KT*d,-lim); e=max(e,abs(st[1]-ref)/lim)
        dref=lim*(s-lim/KT)+lim*max(0,d-2*lim/KT); e=max(e,abs(Q.sfd-dref)/(lim*s))
    return e
def c3_fd(L,h=1e-7):
    cases=[(-0.03,[0.002,0.001],[0,0],[0.001,-0.0005]),   # onset range, stick
           (0.01,[0.001,0.0004],[0,0],[0.0006,0.0002]),   # stick
           (0.01,[0.0,0.0],[0.0,0.0],[0.03,0.02]),        # slip, direction 33 deg
           (0.03,[0.01,0.0],[0.0,0.0],[-0.02,0.07]),      # slip, turning
           (0.002,[0.0,0.0],[0,0],[0.1,-0.04])]
    e=0
    for d,g0,_,dg in cases:
        P=Pt(L); P.step(d,[0,0]); P.step(d,g0)   # set state
        sv0=P.sv.copy(); d0=P.d; g0a=P.g.copy()
        def S(dd_,dgg):
            return L.uinter([dd_,0,0],[dd_-d0,dgg[0],dgg[1]],sv0,PR)[0]
        dgv=np.array(dg); base=L.uinter([d0,0,0],[0,dgv[0],dgv[1]],sv0,PR); A=base[1]
        Afd=np.zeros((3,3))
        for k in range(3):
            if k==0: Afd[:,0]=(S(d0+h,dgv)-S(d0-h,dgv))/(2*h)
            else:
                dp=dgv.copy(); dm=dgv.copy(); dp[k-1]+=h; dm[k-1]-=h; Afd[:,k]=(S(d0,dp)-S(d0,dm))/(2*h)
        e=max(e,np.max(np.abs(A-Afd))/np.max(np.abs(A)))
    return e
def c4_normal_energy(L):
    n=4000; ds=np.concatenate([np.linspace(-0.08,0.04,n//2+1),np.linspace(0.04,-0.08,n//2+1)[1:]])
    P=Pt(L); ps=[]
    for d in ds: P.step(d,[0,0]); ps.append(P.p)
    ps=np.array(ps); half=n//2; pl=ps[:half+1]; h=ds[1]-ds[0]
    simp=h/3*(pl[0]+pl[-1]+4*pl[1:-1:2].sum()+2*pl[2:-1:2].sum())     # integral of p along the loading branch
    P2=Pt(L); P2.step(0.04,[0,0]); e1=abs(P2.sed-simp)/Wn(0.04)          # SED equals the work of the pressure
    e3=abs(P.sed)/Wn(0.04)                                                # closed loop in the gap: nothing left
    return max(e1,e3)
def hist2d(n):
    t=np.linspace(0,1,n+1)
    d=0.02+0.012*np.sin(2*np.pi*t)
    g=np.c_[0.05*np.sin(4*np.pi*t),0.04*(np.sin(6*np.pi*t+0.3)-np.sin(0.3))]
    return t,d,g
def c5_balance(L,n=2000):
    """work of the interface = change of stored energy + frictional dissipation (trapezoidal work)"""
    t,d,g=hist2d(n); P=Pt(L); P.step(d[0],[0,0]); p0=P.p; t0=P.tau.copy(); W=0.0; dis=[P.sfd]
    for k in range(1,n+1):
        P.step(d[k],g[k]-g[k-1]); W+=0.5*(p0+P.p)*(d[k]-d[k-1])+0.5*(t0+P.tau)@(g[k]-g[k-1]); p0=P.p; t0=P.tau.copy(); dis.append(P.sfd)
    res=W-(P.sed-Wn(d[0]))-P.sfd
    return abs(res)/abs(W), np.min(np.diff(dis)), W
def rotc(a): return np.array([[np.cos(a),-np.sin(a)],[np.sin(a),np.cos(a)]])
def corner_hist(R=np.eye(2),sgn=1.0):
    legs=[(0.02,[0.03,0.0]),(0.02,[0.0,0.04]),(0.025,[-0.05,-0.01]),(0.015,[0.02,-0.03]),(0.02,[0.01,0.04])]
    P=Pt(Lcur); P.step(0.02,[0,0]); out=[]
    for dd,dg in legs:
        st=P.step(dd,sgn*(R@np.array(dg))); out.append(st[1:].copy())
    return np.array(out),P
Lcur=None
def c6_isotropy(L):
    global Lcur; Lcur=L; base,_=corner_hist(); e=0
    for a in (0.3,0.65,1.3,2.5):
        R=rotc(a); rot,_=corner_hist(R)
        e=max(e,np.max(np.abs(rot-base@R.T))/np.max(np.abs(base)))
    neg,_=corner_hist(np.eye(2),-1.0); e=max(e,np.max(np.abs(neg+base))/np.max(np.abs(base)))
    return e
def c7_increments(L):
    res=[]
    for N in (1,10,100,1000):
        P=Pt(L); P.step(0.0,[0,0]); ang=np.radians(20); tot=0.06*np.array([np.cos(ang),np.sin(ang)])
        for k in range(1,N+1): P.step(0.02*k/N,tot/N)
        res.append(P.tau.copy())
    res=np.array(res); ref=MU*pw(0.02)
    return float(np.max(np.abs(res-res[-1]))/ref), res
def run_all(L):
    R={}
    e=c1_points(L); R['C1']=(e,e<1e-11)
    e=c2_reversal(L); R['C2']=(e,e<1e-11)
    e=c3_fd(L); R['C3']=(e,e<1e-6)
    e=c4_normal_energy(L); R['C4']=(e,e<1e-8)
    e,mono,W=c5_balance(L); R['C5']=(e,e<5e-4 and mono>-1e-14)
    e=c6_isotropy(L); R['C6']=(e,e<1e-11)
    e,_=c7_increments(L); R['C7']=(e,e<1e-11)
    return R
if __name__=='__main__':
    from h18lib import build
    L=Lib(build())
    for k,v in run_all(L).items(): print(k,v)
    print(c5_balance(L,500)[:2],c5_balance(L,1000)[:2],c5_balance(L,4000)[:2])
