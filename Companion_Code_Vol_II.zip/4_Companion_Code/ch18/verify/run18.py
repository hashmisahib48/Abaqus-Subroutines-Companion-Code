"""Runs the clean routines and every injected fault through the three verification matrices."""
import json, sys, numpy as np
from h18lib import build, Lib
import t_mat, t_el, t_con
H='ex18_uhyper.f'; U='ex18_uel.f'; C='ex18_uinter.f'
FAULTS={
 'mat':[('U1','C01 derivative doubled',(H,'UI1(2) = C01','UI1(2) = 2.0D0*C01')),
        ('U2','UI1(3) lacks the factor 2',(H,'UI1(3) = 2.0D0*(AJ - 1.0D0)/D1','UI1(3) = (AJ - 1.0D0)/D1')),
        ('U3','UI2(3) lacks the factor 2',(H,'UI2(3) = 2.0D0/D1','UI2(3) = 1.0D0/D1')),
        ('U4','energy datum: C01 term without -3',(H,'C01*(BI2 - 3.0D0)\n','C01*BI2\n')),
        ('U5','C10 and C01 interchanged',(H,'C10 = PROPS(1)\n      C01 = PROPS(2)','C10 = PROPS(2)\n      C01 = PROPS(1)')),
        ('U6','U(2) includes the volumetric term',(H,'U(1)   = U(1) + (AJ - 1.0D0)**2/D1','U(1)   = U(1) + (AJ - 1.0D0)**2/D1\n         U(2)   = U(1)')),
        ('U7','data fault: C01 = -0.1 MPa (code correct)',None)],
 'el':[('E1','shear modulus: D33 without 1/2',(U,'D(3,3) = 0.5D0*FAC*(1.D0 - ANU)','D(3,3) = FAC*(1.D0 - ANU)')),
       ('E2','one-point integration',(U,'      NGP = 4\n      SGP = 1.D0\n      WG = 1.D0','      NGP = 1\n      SGP = 0.D0\n      WG = 4.D0')),
       ('E3','transposed Jacobian in dN/dx',(U,'DNX(1,I) = ( A22*DXI(I) - A12*DET(I))/DETJ\n            DNX(2,I) = (-A21*DXI(I) + A11*DET(I))/DETJ','DNX(1,I) = ( A22*DXI(I) - A21*DET(I))/DETJ\n            DNX(2,I) = (-A12*DXI(I) + A11*DET(I))/DETJ')),
       ('E4','RHS = +internal force',(U,'RHS(K1,1) = -FI(K1)','RHS(K1,1) = FI(K1)')),
       ('E5','thickness missing in AMATRX only',(U,'AK(I,J) = AK(I,J) + WT*BL(M,I)*D(M,L)*BL(L,J)','AK(I,J) = AK(I,J) + DETJ*BL(M,I)*D(M,L)*BL(L,J)')),
       ('E6','geometric stiffness omitted',(U,'GEO = QN','GEO = 0.D0')),
       ('E7','linearised strain in the nonlinear element',(U,'QS = QN','QS = 0.D0')),
       ('E8','ENERGY(2) twice the strain energy',(U,'ENER = ENER + 0.5D0*WT*EV(I)*S(I)','ENER = ENER + 1.0D0*WT*EV(I)*S(I)'))],
 'con':[('K1','no mu dp/dd term in the tangent',(C,'DDSDDR(K+1,1) = AMU*DPDD*TT(K)/TN','DDSDDR(K+1,1) = 0.D0')),
        ('K2','friction limit from the pressure of the last increment',(C,'FLIM = AMU*P','FLIM = AMU*STATEV(4)')),
        ('K3','elastic slip not limited in slip',(C,'GE(K)  = TAU(K)/AKT','GE(K)  = GE(K)')),
        ('K4','dissipation counts the elastic slip',(C,'DIS = DIS + TAU(K)*(DRDISP(K+1) - DGE)','DIS = DIS + TAU(K)*DRDISP(K+1)')),
        ('K5','normal energy: linear term missing',(C,'W = AKN*(DEL*DEL/2.D0 + 0.5D0*C*DEL + C*C/6.D0)','W = AKN*(DEL*DEL/2.D0 + C*C/6.D0)')),
        ('K6','tangential magnitude from component 1 only',(C,'TN = SQRT(TT(1)**2 + TT(2)**2)','TN = ABS(TT(1)) + 1.D-30')),
        ('K7','wrong slope in the onset range',(C,'DPDD = AKN*(DEL + C)/C','DPDD = AKN*(DEL + C)/(2.D0*C)'))]}
MODS={'mat':t_mat,'el':t_el,'con':t_con}
def run(fam,fault):
    code,desc,spec=fault
    if spec is None:
        L=Lib(build()); return MODS[fam].run_all(L,[0.5,-0.1,0.02])
    L=Lib(build(spec,code))
    try: return MODS[fam].run_all(L)
    except Exception as ex: 
        print('   exception in',code,type(ex).__name__,str(ex)[:60]); return {'ERR':(float('nan'),False)}
def main():
    out={}; L=Lib(build())
    for fam,mod in MODS.items():
        R=mod.run_all(L); out[fam]={'clean':{k:[float(v[0]),bool(v[1])] for k,v in R.items()},'faults':{}}
        print(fam,'clean',{k:bool(v[1]) for k,v in R.items()})
        tests=list(R.keys())
        for f in FAULTS[fam]:
            Rf=run(fam,f); 
            for t in tests: Rf.setdefault(t,(float('nan'),False))
            out[fam]['faults'][f[0]]={'desc':f[1],'res':{k:[float(Rf[k][0]),bool(Rf[k][1])] for k in tests}}
            print(' ',f[0],f[1][:40].ljust(40),''.join('.' if Rf[t][1] else 'X' for t in tests))
    json.dump(out,open('out/matrix.json','w'),indent=1)
if __name__=='__main__': main()
