"""Verification matrix of the UHYPER routine (Mooney-Rivlin, C10=0.5, C01=0.1, D1=0.02)."""
import numpy as np
from h18lib import Lib
C10,C01,D1=0.5,0.1,0.02
PR=[C10,C01,D1]
def kin(F):
    C=F.T@F; J=np.linalg.det(F); t=np.trace(C); I2=0.5*(t*t-np.trace(C@C))
    return J**(-2/3)*t, J**(-4/3)*I2, J, C, t, I2
def Pfun(L,F,pr=PR,incmp=0):
    I1b,I2b,J,C,t,I2=kin(F); U,u1,u2,u3=L.hyper(I1b,I2b,J,incmp,pr)
    Fit=np.linalg.inv(F).T
    dI1=J**(-2/3)*(2*F-(2/3)*t*Fit); dI2=J**(-4/3)*(2*t*F-2*F@C-(4/3)*I2*Fit); dJ=J*Fit
    return u1[0]*dI1+u1[1]*dI2+u1[2]*dJ, U[0]
def Wref(F,pr=PR):
    I1b,I2b,J,*_=kin(F); return pr[0]*(I1b-3)+pr[1]*(I2b-3)+(J-1)**2/pr[2]
def Pref(F,pr=PR,h=1e-6):
    P=np.zeros((3,3))
    for i in range(3):
        for j in range(3):
            Fp=F.copy(); Fm=F.copy(); Fp[i,j]+=h; Fm[i,j]-=h; P[i,j]=(Wref(Fp,pr)-Wref(Fm,pr))/(2*h)
    return P
def relerr(a,b,scale=None):
    s=scale if scale is not None else max(np.max(np.abs(b)),1e-300); return float(np.max(np.abs(np.asarray(a)-np.asarray(b)))/s)
def m1_closed(L,pr=PR):
    c10,c01=pr[0],pr[1]; e=0
    for lam in (1.5,2.0,3.0,4.0):
        for mode in ('uni','bi','pl'):
            F={'uni':np.diag([lam,lam**-.5,lam**-.5]),'bi':np.diag([lam,lam,lam**-2]),'pl':np.diag([lam,1,1/lam])}[mode]
            P,_=Pfun(L,F,pr,1)
            # Lagrange pressure from the free (zero) stress component
            k={'uni':1,'bi':2,'pl':2}[mode]; p=P[k,k]*F[k,k]
            P11=P[0,0]-p/F[0,0]
            ref={'uni':2*(lam-lam**-2)*(c10+c01/lam),'bi':2*(lam-lam**-5)*(c10+lam**2*c01),'pl':2*(lam-lam**-3)*(c10+c01)}[mode]
            e=max(e,abs(P11-ref)/abs(ref))
    return e
def m2_reference(L,pr=PR):
    F=np.eye(3); P,U=Pfun(L,F,pr); e=max(abs(U),np.max(np.abs(P)))
    g=1e-4; Fs=np.eye(3); Fs[0,1]=g; Ps,_=Pfun(L,Fs,pr); G=Ps[0,1]/g
    eG=abs(G-2*(pr[0]+pr[1]))/(2*(pr[0]+pr[1]))
    K=L.hyper(3,3,1.0,0,pr)[2][2]; eK=abs(K-2/pr[2])/(2/pr[2])
    return max(e,eG,eK),(e,eG,eK)
def m3_hydro(L,pr=PR):
    e=0
    for J in (0.8,1.3):
        lam=J**(1/3); F=lam*np.eye(3); P,U=Pfun(L,F,pr)
        sig=P@F.T/J; ref=2*(J-1)/pr[2]
        e=max(e,abs(sig[0,0]-ref)/abs(ref),abs(sig[0,1]),abs(L.hyper(3,3,J,0,pr)[0][1]),abs(U-(J-1)**2/pr[2])/((J-1)**2/pr[2]))
    return e
IDX2=[(0,0),(1,1),(2,2),(0,1),(0,2),(1,2)]
def m4_fd(L,pr=PR):
    st=[(3.0,3.0,1.0),(3.8,4.4,0.9),(5.5,7.7,1.15),(32.9,41.0,1.1),(4.1,3.6,0.62)]; e1=e2=0
    for x in st:
        x=np.array(x); U,u1,u2,_=L.hyper(*x,0,pr)
        fd1=np.zeros(3); fd2=np.zeros((3,3))
        for a in range(3):
            h=1e-5*max(1,abs(x[a])); xp=x.copy(); xm=x.copy(); xp[a]+=h; xm[a]-=h
            Up,u1p,*_=L.hyper(*xp,0,pr); Um,u1m,*_=L.hyper(*xm,0,pr)
            fd1[a]=(Up[0]-Um[0])/(2*h); fd2[:,a]=(u1p-u1m)/(2*h)
        e1=max(e1,relerr(u1,fd1,max(1,np.max(np.abs(fd1)))))
        S=np.zeros((3,3))
        for k,(a,b) in enumerate(IDX2): S[a,b]=S[b,a]=u2[k]
        e2=max(e2,relerr(S,fd2,max(1,np.max(np.abs(fd2)))))   # also catches asymmetry of fd2 vs S
    return max(e1,e2),(e1,e2)
FS=[np.array([[1.3,.2,0],[.1,.9,.05],[0,0,1.1]]),np.array([[1,1.5,0],[0,1,0],[0,0,1.]]),
    np.array([[2.0,0,0],[0,.8,.1],[0,.2,.7]]),np.array([[.9,-.3,.1],[.4,1.2,0],[.05,0,1.05]])]
def m5_stress(L,pr=PR):
    e=0
    for F in FS:
        P,_=Pfun(L,F,pr); e=max(e,relerr(P,Pref(F,pr)))
    return e
def m6_work(L,pr=PR):
    e=0; Fs=[np.eye(3)]+FS[:3]+[np.eye(3)]
    xg,wg=np.polynomial.legendre.leggauss(12); xg=(xg+1)/2; wg=wg/2
    for A,B in zip(Fs[:-1],Fs[1:]):
        W=sum(w*np.sum(Pfun(L,A+s*(B-A),pr)[0]*(B-A)) for s,w in zip(xg,wg))
        dU=Pfun(L,B,pr)[1]-Pfun(L,A,pr)[1]; e=max(e,abs(W-dU)/max(abs(dU),1.0))
    return e
def hess(L,e,pr=PR):
    """Hessian of U in the logarithmic stretches e_i (compressible), from UI1 and UI2."""
    e=np.asarray(e,float); s=e.sum(); a=np.exp(2*e-2*s/3); I1=a.sum(); J=np.exp(s)
    g1=2*a-2/3*I1; H1=np.zeros((3,3)); 
    for i in range(3):
        c=2*(np.arange(3)==i)-2/3; H1+=a[i]*np.outer(c,c)
    I2=0; g2=np.zeros(3); H2=np.zeros((3,3))
    for i in range(3):
        for j in range(i+1,3):
            b=np.exp(2*e[i]+2*e[j]-4*s/3); c=2*(np.arange(3)==i)+2*(np.arange(3)==j)-4/3
            I2+=b; g2+=b*c; H2+=b*np.outer(c,c)
    U,u1,u2,_=L.hyper(I1,I2,J,0,pr); S=np.zeros((3,3))
    for k,(p,q) in enumerate(IDX2): S[p,q]=S[q,p]=u2[k]
    G=np.array([g1,g2,J*np.ones(3)]); 
    return u1[0]*H1+u1[1]*H2+u1[2]*J*np.ones((3,3))+G.T@S@G
def drucker_map(L,pr=PR,emax=1.1,n=45):
    """smallest eigenvalue of the Hessian (MPa) on the hexagon |e_i|<=emax of the deviatoric plane at J=1"""
    xs=np.linspace(-emax,emax,n); m=np.full((n,n),np.nan)
    for i,e1 in enumerate(xs):
        for j,e2 in enumerate(xs):
            e3=-e1-e2
            if abs(e3)<=emax: m[j,i]=np.linalg.eigvalsh(hess(L,[e1,e2,e3],pr))[0]
    return xs,m
def tangent(L,F,pr=PR,h=1e-6):
    A=np.zeros((3,3,3,3))
    for k in range(3):
        for l in range(3):
            Fp=F.copy(); Fm=F.copy(); Fp[k,l]+=h; Fm[k,l]-=h
            A[:,:,k,l]=(Pfun(L,Fp,pr)[0]-Pfun(L,Fm,pr)[0])/(2*h)
    return A
def fib(n=120):
    k=np.arange(n)+.5; z=1-2*k/n; ph=np.pi*(1+5**.5)*k; r=np.sqrt(1-z*z)
    return np.c_[r*np.cos(ph),r*np.sin(ph),z]
NN=fib()
def ellip(L,F,pr=PR):
    A=tangent(L,F,pr); m=1e300
    for N in NN:
        Q=np.einsum('iJkL,J,L->ik',A,N,N); m=min(m,np.linalg.eigvalsh(0.5*(Q+Q.T))[0])
    return m, np.linalg.eigvalsh(0.5*(A.reshape(9,9)+A.reshape(9,9).T))[0] if False else None
def path_F(mode,lam):
    return {'uni':np.diag([lam,lam**-.5,lam**-.5]),'bi':np.diag([lam,lam,lam**-2]),'pl':np.diag([lam,1,1/lam])}[mode]
def m7_stab(L,pr=PR):
    xs,m=drucker_map(L,pr,1.1,31); dmin=np.nanmin(m)
    G0=2*(pr[0]+pr[1]); emin=1e300
    for mode in ('uni','bi'):
        for lam in np.linspace(0.45,3.0,14):
            q,_=ellip(L,path_F(mode,lam),pr); emin=min(emin,q)
    return dmin,emin
def run_all(L,pr=PR):
    """returns {test: (error or margin, passed)}"""
    R={}
    e=m1_closed(L,pr); R['M1']=(e,e<1e-11)
    e,_=m2_reference(L,pr); R['M2']=(e,e<1e-6)
    e=m3_hydro(L,pr); R['M3']=(e,e<1e-11)
    e,_=m4_fd(L,pr); R['M4']=(e,e<1e-6)
    e=m5_stress(L,pr); R['M5']=(e,e<1e-6)
    e=m6_work(L,pr); R['M6']=(e,e<1e-9)
    d,q=m7_stab(L,pr); R['M7']=(min(d,q),d>0 and q>0)
    return R
if __name__=='__main__':
    from h18lib import build
    L=Lib(build()); R=run_all(L); 
    for k,v in R.items(): print(k,v)
    print(m2_reference(L)[1],m4_fd(L)[1])
    print(m7_stab(L)); print(m7_stab(L,[0.5,-0.1,0.02]))
