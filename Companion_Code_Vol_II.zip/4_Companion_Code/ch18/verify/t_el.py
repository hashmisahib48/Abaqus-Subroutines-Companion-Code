"""Verification matrix of the four-node plane-stress UEL (E=1000 MPa, nu=0.3, t=2 mm)."""
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spl, sympy as sy
from h18lib import Lib
E,NU,T=1000.0,0.3,2.0
PL=[E,NU,T,0.0]; PT=[E,NU,T,1.0]
SQ=np.array([[0,0],[1,0],[1,1],[0,1.]])
DQ=np.array([[0,0],[1.2,0.15],[1.4,1.1],[0.1,0.8]])
def ref_k(X,E=E,nu=NU,t=T):
    """independent plane-stress Q4 stiffness (separate code, tensor-index form)"""
    g=1/np.sqrt(3); pts=[(-g,-g),(g,-g),(g,g),(-g,g)]
    c=E/(1-nu**2); D=c*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]]); K=np.zeros((8,8))
    for xi,et in pts:
        dN=0.25*np.array([[-(1-et),(1-et),(1+et),-(1+et)],[-(1-xi),-(1+xi),(1+xi),(1-xi)]])
        Jm=dN@X; dNx=np.linalg.solve(Jm,dN)
        B=np.zeros((3,8)); B[0,0::2]=dNx[0]; B[1,1::2]=dNx[1]; B[2,0::2]=dNx[1]; B[2,1::2]=dNx[0]
        K+=B.T@D@B*np.linalg.det(Jm)*t
    return K
def rigid(X,th=1.0):
    return None
def e1_rigid(L,X=DQ,props=PL):
    r,K,_,_=L.uel(X,props,np.zeros(8)); xc=X.mean(0); m=0
    for k in range(3):
        u=np.zeros(8)
        if k<2: u[k::2]=1.0
        else:
            u[0::2]=-(X[:,1]-xc[1]); u[1::2]=(X[:,0]-xc[0])
        m=max(m,np.max(np.abs(K@u))/(np.max(np.abs(K))*np.max(np.abs(u))))
    return m
def e2_spectrum(L,props=PL):
    e=0; nz=[]
    for X in (SQ,DQ):
        _,K,_,_=L.uel(X,props,np.zeros(8)); w=np.linalg.eigvalsh(0.5*(K+K.T)); wr=np.linalg.eigvalsh(ref_k(X))
        e=max(e,np.max(np.abs(w-wr))/wr[-1]+np.max(np.abs(K-K.T))/wr[-1]); nz.append(int(np.sum(np.abs(w)<1e-9*w[-1])))
    return e,nz
PATCH_X=np.array([[0,0],[.24,0],[.24,.12],[0,.12],[.04,.02],[.18,.03],[.16,.08],[.08,.08]])
PATCH_E=[(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)]
def e3_patch(L,props=PL):
    ex=lambda x,y: np.array([1e-3*(x+.5*y), 1e-3*(-.2*x+2*y)])
    nd=8; u=np.zeros(2*nd)
    for n in range(4): u[2*n:2*n+2]=ex(*PATCH_X[n])
    # Newton iteration as Abaqus does it: R = sum RHS, K du = R, interior dof free
    free=np.arange(8,16)
    for it in range(3):
        R=np.zeros(2*nd); Kg=np.zeros((2*nd,2*nd))
        for el in PATCH_E:
            dofs=np.array([[2*n,2*n+1] for n in el]).ravel()
            r,K,_,_=L.uel(PATCH_X[list(el)],props,u[dofs],1); R[dofs]+=r; Kg[np.ix_(dofs,dofs)]+=K
        if it>0 and np.max(np.abs(R[free]))<1e-9: break
        du=np.linalg.solve(Kg[np.ix_(free,free)],R[free]); u[free]+=du
    ue=np.array([ex(*PATCH_X[n]) for n in range(8)]).ravel(); eu=np.max(np.abs(u-ue))/np.max(np.abs(ue))
    D=E/(1-NU**2)*np.array([[1,NU,0],[NU,1,0],[0,0,(1-NU)/2]]); sref=D@np.array([1e-3,2e-3,1e-3*(.5-.2)])
    es=0
    for el in PATCH_E:
        dofs=np.array([[2*n,2*n+1] for n in el]).ravel(); _,_,sv,_=L.uel(PATCH_X[list(el)],props,u[dofs],1)
        es=max(es,np.max(np.abs(sv.reshape(4,3)-sref))/np.max(np.abs(sref)))
    return max(eu,es),(eu,es)
def state_tl():
    th=np.radians(25); R=np.array([[np.cos(th),-np.sin(th)],[np.sin(th),np.cos(th)]])
    F0=R@np.array([[1.12,0.08],[-0.05,0.93]]); X=DQ
    return ((F0-np.eye(2))@X.T).T.ravel()     # nodal displacements, node by node
def e4_fd(L,props=PT,h=1e-6):
    u=state_tl(); _,K,_,_=L.uel(DQ,props,u,2); n=8; Kfd=np.zeros((n,n))
    for j in range(n):
        up=u.copy(); um=u.copy(); up[j]+=h; um[j]-=h
        Kfd[:,j]=-(L.uel(DQ,props,up,5)[0]-L.uel(DQ,props,um,5)[0])/(2*h)
    return np.max(np.abs(K-Kfd))/np.max(np.abs(K))
def e4_fd_unstressed(L,props=PT,h=1e-6):
    u=np.zeros(8); _,K,_,_=L.uel(DQ,props,u,2); Kfd=np.zeros((8,8))
    for j in range(8):
        up=u.copy(); um=u.copy(); up[j]+=h; um[j]-=h
        Kfd[:,j]=-(L.uel(DQ,props,up,5)[0]-L.uel(DQ,props,um,5)[0])/(2*h)
    return np.max(np.abs(K-Kfd))/np.max(np.abs(K))
def rot_u(X,th,tr=(0.3,-0.2)):
    R=np.array([[np.cos(th),-np.sin(th)],[np.sin(th),np.cos(th)]]); xc=X.mean(0)
    return ((R-np.eye(2))@(X-xc).T).T.ravel()+np.tile(tr,4)
def e5_rotation(L):
    # total Lagrangian: internal force of a rigid motion must vanish at any angle
    _,K,_,_=L.uel(DQ,PT,np.zeros(8),2); Kmax=np.max(np.abs(K)); et=0
    for th in (0.3,0.9,1.5,3.0):
        u=rot_u(DQ,th); r=L.uel(DQ,PT,u,5)[0]; et=max(et,np.max(np.abs(r))/(Kmax*np.max(np.abs(u))))
    # linear element: the force scales with theta**2 (no first-order error)
    ths=np.array([1e-1,1e-2,1e-3]); f=[np.max(np.abs(L.uel(DQ,PL,rot_u(DQ,t,(0,0)),5)[0])) for t in ths]
    f=np.maximum(f,1e-300); slope=np.polyfit(np.log(ths),np.log(f),1)[0]
    return et,slope,f
def e6_energy(L):
    e=0
    for props in (PL,PT):
        u=state_tl() if props[3]==1 else 1e-2*np.array([.3,-.1,.5,.2,-.4,.1,.2,.6])
        en=L.uel(DQ,props,u,1)[3]
        xg,wg=np.polynomial.legendre.leggauss(10); xg=(xg+1)/2; wg=wg/2
        W=sum(w*np.dot(-L.uel(DQ,props,s*u,5)[0],u) for s,w in zip(xg,wg)); e=max(e,abs(en-W)/abs(W))
    return e
_ex=None
def exact():
    global _ex
    if _ex: return _ex
    x,y=sy.symbols('x y'); pi=sy.pi
    ux=sy.Rational(1,100)*sy.sin(pi*x)*sy.sin(pi*y); uy=sy.Rational(1,25)*x*(1-x)*y*(1-y)
    c=E/(1-NU**2); ex_=sy.diff(ux,x); ey_=sy.diff(uy,y); g=sy.diff(ux,y)+sy.diff(uy,x)
    sx=c*(ex_+NU*ey_); sy_=c*(NU*ex_+ey_); tau=c*(1-NU)/2*g
    bx=-(sy.diff(sx,x)+sy.diff(tau,y)); by=-(sy.diff(tau,x)+sy.diff(sy_,y))
    f=lambda e: sy.lambdify((x,y),e,'numpy')
    _ex=dict(u=(f(ux),f(uy)),b=(f(bx),f(by)),eps=(f(ex_),f(ey_),f(g)))
    return _ex
def e7_convergence(L,props=PL,ns=(4,8,16),pert=0.25):
    ex=exact(); out=[]; g=1/np.sqrt(3); gp=[(-g,-g),(g,-g),(g,g),(-g,g)]
    q=np.polynomial.legendre.leggauss(4); qp=[(a,b,wa*wb) for a,wa in zip(*q) for b,wb in zip(*q)]
    c=E/(1-NU**2); D=c*np.array([[1,NU,0],[NU,1,0],[0,0,(1-NU)/2]])
    for n in ns:
        h=1.0/n; xs=np.linspace(0,1,n+1); nid=lambda i,j: j*(n+1)+i
        Xn=np.array([[xs[i],xs[j]] for j in range(n+1) for i in range(n+1)]); N=len(Xn)
        rng=np.random.RandomState(7)
        for k in range(N):
            if 1e-12<Xn[k,0]<1-1e-12 and 1e-12<Xn[k,1]<1-1e-12: Xn[k]+=pert*h*(2*rng.rand(2)-1)
        rows=[];cols=[];vals=[]; F=np.zeros(2*N); els=[]
        for j in range(n):
            for i in range(n):
                nd=[nid(i,j),nid(i+1,j),nid(i+1,j+1),nid(i,j+1)]; els.append(nd)
                _,K,_,_=L.uel(Xn[nd],props,np.zeros(8),2); dofs=np.array([[2*k,2*k+1] for k in nd]).ravel()
                for a in range(8):
                    for b in range(8): rows.append(dofs[a]); cols.append(dofs[b]); vals.append(K[a,b])
                for xi,et,w in qp:
                    Nn=0.25*np.array([(1-xi)*(1-et),(1+xi)*(1-et),(1+xi)*(1+et),(1-xi)*(1+et)])
                    xp=Nn@Xn[nd]; bx=ex['b'][0](*xp); by=ex['b'][1](*xp)
                    for k in range(4):
                        F[2*nd[k]]+=Nn[k]*bx*w*(h/2)**2*T; F[2*nd[k]+1]+=Nn[k]*by*w*(h/2)**2*T
        Kg=sp.csr_matrix((vals,(rows,cols)),shape=(2*N,2*N))
        onb=[k for k in range(N) if min(Xn[k])<1e-12 or max(Xn[k])>1-1e-12]
        fixed=np.array([[2*k,2*k+1] for k in onb]).ravel(); free=np.setdiff1d(np.arange(2*N),fixed)
        u=np.zeros(2*N)
        try:
            u[free]=spl.spsolve(Kg[free][:,free].tocsc(),F[free])
        except Exception: return None
        if not np.all(np.isfinite(u)): return None
        e0=e1=0
        for nd in els:
            ue=u[np.array([[2*k,2*k+1] for k in nd]).ravel()]
            for xi,et,w in qp:
                Nn=0.25*np.array([(1-xi)*(1-et),(1+xi)*(1-et),(1+xi)*(1+et),(1-xi)*(1+et)])
                dN=0.25*np.array([[-(1-et),(1-et),(1+et),-(1+et)],[-(1-xi),-(1+xi),(1+xi),(1-xi)]])
                Jm=dN@Xn[nd]; dNx=np.linalg.solve(Jm,dN); xp=Nn@Xn[nd]; dj=np.linalg.det(Jm)
                uh=np.array([Nn@ue[0::2],Nn@ue[1::2]]); uex=np.array([ex['u'][0](*xp),ex['u'][1](*xp)])
                e0+=w*dj*np.sum((uh-uex)**2)
                eh=np.array([dNx[0]@ue[0::2],dNx[1]@ue[1::2],dNx[1]@ue[0::2]+dNx[0]@ue[1::2]])
                ee=np.array([ex['eps'][0](*xp),ex['eps'][1](*xp),ex['eps'][2](*xp)]); d=eh-ee; e1+=w*dj*(d@D@d)
        out.append((n,np.sqrt(e0),np.sqrt(e1)))
    return out
def conv_rates(out):
    if out is None: return None
    r0=np.log(out[-2][1]/out[-1][1])/np.log(2); r1=np.log(out[-2][2]/out[-1][2])/np.log(2); return r0,r1
def run_all(L):
    R={}
    e=e1_rigid(L); R['E1']=(e,e<1e-11)
    e,nz=e2_spectrum(L); R['E2']=(e,e<1e-9 and nz==[3,3])
    e,_=e3_patch(L); R['E3']=(e,e<1e-9)
    e=e4_fd(L); R['E4']=(e,e<1e-6)
    et,sl,_=e5_rotation(L); R['E5']=(et,et<1e-10 and sl>1.95)
    e=e6_energy(L); R['E6']=(e,e<1e-9)
    c=e7_convergence(L,ns=(8,16,32)); r=conv_rates(c); R['E7']=(r[0] if r else float('nan'), bool(r) and r[0]>1.9 and r[1]>0.9)
    return R
if __name__=='__main__':
    from h18lib import build
    L=Lib(build())
    for k,v in run_all(L).items(): print(k,v)
    print(e2_spectrum(L), e3_patch(L)[1], e4_fd_unstressed(L), e5_rotation(L)[1:], conv_rates(e7_convergence(L,ns=(4,8,16,32))), e7_convergence(L))
