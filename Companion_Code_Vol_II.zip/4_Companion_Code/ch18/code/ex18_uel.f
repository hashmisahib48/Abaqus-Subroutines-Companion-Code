      SUBROUTINE K18_DPS(E, ANU, D)
!     Plane-stress elasticity matrix, engineering shear strain.
!     E (MPa), ANU (-).  D(3,3) in MPa.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(3,3)
      FAC = E/(1.D0 - ANU*ANU)
      DO I = 1, 3
         DO J = 1, 3
            D(I,J) = 0.D0
         ENDDO
      ENDDO
      D(1,1) = FAC
      D(2,2) = FAC
      D(1,2) = FAC*ANU
      D(2,1) = FAC*ANU
      D(3,3) = 0.5D0*FAC*(1.D0 - ANU)
      RETURN
      END
!
      SUBROUTINE K18_Q4(X, PROPS, U, FINT, AK, SV, ENER, ISTAT)
!     Four-node plane-stress quadrilateral, 2 x 2 Gauss points, total
!     Lagrangian when PROPS(4) = 1 (Green strain, St. Venant-Kirchhoff
!     membrane law), linear when PROPS(4) = 0.  X(2,4) in mm,
!     PROPS = E (MPa), NU (-), T (mm), NLGEOM (0 or 1).
!     FINT(8) in N, AK(8,8) in N/mm, SV = 2nd Piola-Kirchhoff stress
!     (S11, S22, S12 in MPa) at the four Gauss points, ENER in N mm.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), PROPS(*), U(8), FINT(8), AK(8,8), SV(12),
     1 D(3,3), BL(3,8), XG(4), EG(4), DXI(4), DET(4), DNX(2,4),
     2 H(2,2), F(2,2), EV(3), S(3), XS(4), ES(4)
      DATA XG /-0.5773502691896258D0, 0.5773502691896258D0,
     1          0.5773502691896258D0, -0.5773502691896258D0/
      DATA EG /-0.5773502691896258D0, -0.5773502691896258D0,
     1          0.5773502691896258D0, 0.5773502691896258D0/
      DATA XS /-1.D0, 1.D0, 1.D0, -1.D0/
      DATA ES /-1.D0, -1.D0, 1.D0, 1.D0/
      ISTAT = 0
      E = PROPS(1)
      ANU = PROPS(2)
      T = PROPS(3)
      QN = PROPS(4)
      IF (E.LE.0.D0 .OR. T.LE.0.D0 .OR. ABS(ANU).GE.1.D0) ISTAT = 1
      IF (ISTAT .NE. 0) RETURN
      CALL K18_DPS(E, ANU, D)
      NGP = 4
      SGP = 1.D0
      WG = 1.D0
      DO I = 1, 8
         FINT(I) = 0.D0
         DO J = 1, 8
            AK(I,J) = 0.D0
         ENDDO
      ENDDO
      ENER = 0.D0
      DO IG = 1, NGP
         XI = SGP*XG(IG)
         ET = SGP*EG(IG)
         A11 = 0.D0
         A12 = 0.D0
         A21 = 0.D0
         A22 = 0.D0
         DO I = 1, 4
            DXI(I) = 0.25D0*XS(I)*(1.D0 + ES(I)*ET)
            DET(I) = 0.25D0*ES(I)*(1.D0 + XS(I)*XI)
            A11 = A11 + DXI(I)*X(1,I)
            A12 = A12 + DXI(I)*X(2,I)
            A21 = A21 + DET(I)*X(1,I)
            A22 = A22 + DET(I)*X(2,I)
         ENDDO
         DETJ = A11*A22 - A12*A21
         IF (DETJ .LE. 0.D0) THEN
            ISTAT = 2
            RETURN
         ENDIF
         WT = T*DETJ*WG
         DO I = 1, 4
            DNX(1,I) = ( A22*DXI(I) - A12*DET(I))/DETJ
            DNX(2,I) = (-A21*DXI(I) + A11*DET(I))/DETJ
         ENDDO
!        displacement gradient H(i,j) = du_i/dX_j and deformation F
         DO I = 1, 2
            DO J = 1, 2
               H(I,J) = 0.D0
               DO K = 1, 4
                  H(I,J) = H(I,J) + U(2*K-2+I)*DNX(J,K)
               ENDDO
               F(I,J) = QN*H(I,J)
            ENDDO
            F(I,I) = F(I,I) + 1.D0
         ENDDO
!        Green strain (engineering shear), linear when QN = 0
         QS = QN
         EV(1) = H(1,1) + 0.5D0*QS*(H(1,1)**2 + H(2,1)**2)
         EV(2) = H(2,2) + 0.5D0*QS*(H(1,2)**2 + H(2,2)**2)
         EV(3) = H(1,2) + H(2,1) + QS*(H(1,1)*H(1,2) + H(2,1)*H(2,2))
         DO I = 1, 3
            S(I) = D(I,1)*EV(1) + D(I,2)*EV(2) + D(I,3)*EV(3)
            SV(3*IG-3+I) = S(I)
            ENER = ENER + 0.5D0*WT*EV(I)*S(I)
         ENDDO
!        BL(3,8) = dE/du with the current F
         DO K = 1, 4
            DO I = 1, 2
               J = 2*K - 2 + I
               BL(1,J) = F(I,1)*DNX(1,K)
               BL(2,J) = F(I,2)*DNX(2,K)
               BL(3,J) = F(I,1)*DNX(2,K) + F(I,2)*DNX(1,K)
            ENDDO
         ENDDO
         DO J = 1, 8
            FINT(J) = FINT(J) + WT*(BL(1,J)*S(1) + BL(2,J)*S(2)
     1                            + BL(3,J)*S(3))
         ENDDO
         DO I = 1, 8
            DO J = 1, 8
               DO M = 1, 3
                  DO L = 1, 3
                     AK(I,J) = AK(I,J) + WT*BL(M,I)*D(M,L)*BL(L,J)
                  ENDDO
               ENDDO
            ENDDO
         ENDDO
!        geometric stiffness  dN_a/dX_j S_jl dN_b/dX_l  delta_ik
         GEO = QN
         DO KA = 1, 4
            DO KB = 1, 4
               G = DNX(1,KA)*(S(1)*DNX(1,KB) + S(3)*DNX(2,KB))
     1           + DNX(2,KA)*(S(3)*DNX(1,KB) + S(2)*DNX(2,KB))
               DO I = 1, 2
                  AK(2*KA-2+I,2*KB-2+I) = AK(2*KA-2+I,2*KB-2+I)
     1                                  + GEO*WT*G
               ENDDO
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE UEL(RHS,AMATRX,SVARS,ENERGY,NDOFEL,NRHS,NSVARS,
     1 PROPS,NPROPS,COORDS,MCRD,NNODE,U,DU,V,A,JTYPE,TIME,DTIME,
     2 KSTEP,KINC,JELEM,PARAMS,NDLOAD,JDLTYP,ADLMAG,PREDEF,NPREDF,
     3 LFLAGS,MLVARX,DDLMAG,MDLOAD,PNEWDT,JPROPS,NJPROP,PERIOD)
!     U1: four-node plane-stress quadrilateral, linear or total
!     Lagrangian (PROPS(4)), static analysis only.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION RHS(MLVARX,*),AMATRX(NDOFEL,NDOFEL),PROPS(*),
     1 SVARS(*),ENERGY(8),COORDS(MCRD,NNODE),U(NDOFEL),
     2 DU(MLVARX,*),V(NDOFEL),A(NDOFEL),TIME(2),PARAMS(*),
     3 JDLTYP(MDLOAD,*),ADLMAG(MDLOAD,*),DDLMAG(MDLOAD,*),
     4 PREDEF(2,NPREDF,NNODE),LFLAGS(*),JPROPS(*)
      DIMENSION AK(8,8), FI(8), SV(12), INTV(2), REALV(1)
      CHARACTER*8 CHARV(1)
!
      LF3 = LFLAGS(3)
      DO KRHS = 1, NRHS
         DO K1 = 1, NDOFEL
            RHS(K1,KRHS) = 0.D0
         ENDDO
      ENDDO
      DO K1 = 1, NDOFEL
         DO K2 = 1, NDOFEL
            AMATRX(K1,K2) = 0.D0
         ENDDO
      ENDDO
      IF (LF3.NE.1 .AND. LF3.NE.2 .AND. LF3.NE.5) RETURN
      CALL K18_Q4(COORDS, PROPS, U, FI, AK, SV, ENER, ISTAT)
      IF (ISTAT .NE. 0 .OR. NSVARS .LT. 12) THEN
         INTV(1) = JELEM
         INTV(2) = ISTAT
         CALL STDB_ABQERR(-3, 'UEL: element %I rejected (status '//
     1      '%I).', INTV, REALV, CHARV)
      ENDIF
!     Abaqus wants RHS = external - internal force
      IF (LF3.EQ.1 .OR. LF3.EQ.5) THEN
         DO K1 = 1, NDOFEL
            RHS(K1,1) = -FI(K1)
         ENDDO
      ENDIF
      IF (LF3.EQ.1 .OR. LF3.EQ.2) THEN
         DO K1 = 1, NDOFEL
            DO K2 = 1, NDOFEL
               AMATRX(K1,K2) = AK(K1,K2)
            ENDDO
         ENDDO
      ENDIF
      DO K1 = 1, 12
         SVARS(K1) = SV(K1)
      ENDDO
      ENERGY(2) = ENER
      RETURN
      END
