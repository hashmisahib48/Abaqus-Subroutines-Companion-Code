#!/bin/sh
# Compile every Fortran file of Chapter 18 and build the shared test library.
cd /home/claude/vol2/ch18/code || exit 1
INC=-I/home/claude/vol2/lib/aba
for f in ex18_uhyper ex18_uel ex18_uinter ex18_calls; do
  gfortran -c -ffixed-form -std=legacy $INC $f.f -o /tmp/$f.o || exit 1
done
gfortran -shared -fPIC -ffixed-form -std=legacy $INC ex18_uhyper.f ex18_uel.f ex18_uinter.f ex18_calls.f /home/claude/vol2/lib/aba/stubs.f -o /tmp/lib18_clean.so && echo "compiled 4 files; library built"
