      SUBROUTINE K18_NORM(DEL, AKN, C, P, DPDD, W)
!     Softened normal law: p = 0 for DEL <= -C, quadratic onset on
!     -C < DEL < 0, linear (slope AKN) for DEL >= 0.  DEL = overclosure
!     (mm), AKN (MPa/mm), C (mm).  P (MPa), DPDD (MPa/mm), W (N/mm).
      INCLUDE 'ABA_PARAM.INC'
      IF (DEL .LE. -C) THEN
         P = 0.D0
         DPDD = 0.D0
         W = 0.D0
      ELSE IF (DEL .LT. 0.D0) THEN
         P = AKN*(DEL + C)**2/(2.D0*C)
         DPDD = AKN*(DEL + C)/C
         W = AKN*(DEL + C)**3/(6.D0*C)
      ELSE
         P = AKN*(DEL + 0.5D0*C)
         DPDD = AKN
         W = AKN*(DEL*DEL/2.D0 + 0.5D0*C*DEL + C*C/6.D0)
      ENDIF
      RETURN
      END
!
      SUBROUTINE UINTER(STRESS,DDSDDR,DVISCOUS,DSTRUCTURAL,FLUX,
     1 DDFDDT,DDSDDT,DDFDDR,STATEV,SED,SFD,SPD,SVD,SCD,PNEWDT,
     2 RDISP,DRDISP,TEMP,DTEMP,PREDEF,DPRED,TIME,DTIME,FREQR,
     3 CINAME,SECNAME,MAINNAME,PROPS,COORDS,ALOCALDIR,DROT,AREA,
     4 CHRLNGTH,NODE,NDIR,NSTATV,NPRED,NPROPS,MCRD,KSTEP,KINC,KIT,
     5 LINPER,LOPENCLOSE,LSTATE,LSDI,LPRINT)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CINAME, SECNAME, MAINNAME
      DIMENSION STRESS(NDIR), DDSDDR(NDIR,NDIR), FLUX(2), DDFDDT(2,2),
     1 DDSDDT(NDIR,2), DDFDDR(2,NDIR), STATEV(NSTATV), RDISP(NDIR),
     2 DRDISP(NDIR), TEMP(2), DTEMP(2), PREDEF(2,NPRED),
     3 DPRED(2,NPRED), TIME(2), PROPS(NPROPS), COORDS(MCRD),
     4 ALOCALDIR(3,3), DROT(2,2), DVISCOUS(NDIR,NDIR),
     5 DSTRUCTURAL(NDIR,NDIR)
!     Softened normal contact with regularised Coulomb friction.
!     PROPS: AKN (MPa/mm), C (mm), AKT (MPa/mm), AMU (-).
!     STATEV: 1,2 elastic slip (mm); 3 dissipation (N mm/mm**2);
!     4 pressure (MPa).  Tangential slip is accumulated from DRDISP.
      PARAMETER (RFAR = 1.D30)
      DIMENSION GE(2), TT(2), TAU(2)
      STRESS = 0.D0
      DDSDDR = 0.D0
      FLUX = 0.D0
      SED = 0.D0
      SFD = STATEV(3)
      IF (RDISP(1) .LT. -RFAR) RETURN
      AKN = PROPS(1)
      C   = PROPS(2)
      AKT = PROPS(3)
      AMU = PROPS(4)
      CALL K18_NORM(RDISP(1), AKN, C, P, DPDD, W)
      STRESS(1) = P
      DDSDDR(1,1) = DPDD
!     elastic predictor for the tangential stress
      DO K = 1, 2
         GE(K) = STATEV(K) + DRDISP(K+1)
         TT(K) = AKT*GE(K)
      ENDDO
      TN = SQRT(TT(1)**2 + TT(2)**2)
      FLIM = AMU*P
      IF (TN .LE. FLIM) THEN
!        stick
         DO K = 1, 2
            TAU(K) = TT(K)
            DDSDDR(K+1,K+1) = AKT
         ENDDO
      ELSE
!        slip: return to the friction limit, along the trial direction
         DO K = 1, 2
            TAU(K) = FLIM*TT(K)/TN
            GE(K)  = TAU(K)/AKT
         ENDDO
         DO K = 1, 2
            DO L = 1, 2
               DDSDDR(K+1,L+1) = -FLIM*AKT*TT(K)*TT(L)/TN**3
            ENDDO
            DDSDDR(K+1,K+1) = DDSDDR(K+1,K+1) + FLIM*AKT/TN
            DDSDDR(K+1,1) = AMU*DPDD*TT(K)/TN
         ENDDO
      ENDIF
!     dissipation: tau(n+1) . (slip increment - elastic slip increment)
      DIS = 0.D0
      DO K = 1, 2
         DGE = GE(K) - STATEV(K)
         DIS = DIS + TAU(K)*(DRDISP(K+1) - DGE)
      ENDDO
      DO K = 1, 2
         STRESS(K+1) = TAU(K)
         STATEV(K) = GE(K)
      ENDDO
      SFD = STATEV(3) + DIS
      STATEV(3) = SFD
      STATEV(4) = P
      SED = W + 0.5D0*AKT*(GE(1)**2 + GE(2)**2)
      RETURN
      END
