      SUBROUTINE K13_SPDP(
     1  NBLOCK, RHS, AMASS, DTIMESTABLE, SVARS, NSVARS, ENERGY,
     2  NNODE, NDOFEL, PROPS, NPROPS, JPROPS, NJPROPS, COORDS,
     3  MCRD, U, DU, V, A, JTYPE, JELEM, TIME, PERIOD, DTIMECUR,
     4  DTIMEPREV, KSTEP, KINC, LFLAGS, DMASSSCALEFACTOR, PREDEF,
     5  NPREDEF, JDLTYP, ADLMAG)
!
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (JMASSCALC = 1, JINTFORCEANDDTSTABLE = 2,
     1  JEXTERNFORCE = 3)
      PARAMETER (IPROCEDURE = 1, INLGEOM = 2, IOPCODE = 3,
     1  NFLAGS = 3)
      PARAMETER (NELENERGY = 12, NPRED = 2, NTIME = 2)
      PARAMETER (IELIE = 3, IELDD = 5)
      DIMENSION RHS(NBLOCK,NDOFEL), AMASS(NBLOCK,NDOFEL,NDOFEL),
     1  DTIMESTABLE(NBLOCK), SVARS(NBLOCK,NSVARS),
     2  ENERGY(NBLOCK,NELENERGY), PROPS(NPROPS), JPROPS(NJPROPS),
     3  JELEM(NBLOCK), TIME(NTIME), LFLAGS(NFLAGS),
     4  COORDS(NBLOCK,NNODE,MCRD), U(NBLOCK,NDOFEL),
     5  DU(NBLOCK,NDOFEL), V(NBLOCK,NDOFEL), A(NBLOCK,NDOFEL),
     6  DMASSSCALEFACTOR(NBLOCK), ADLMAG(NBLOCK),
     7  PREDEF(NBLOCK,NNODE,NPREDEF,NPRED)
!
!     Spring and dashpot in parallel along the line of the nodes
!     (direction from the original coordinates).  Properties:
!     PROPS(1) = K (N/mm), PROPS(2) = C (N s/mm), PROPS(3) = M
!     (tonne, lumped at each node).  SVARS(1) = elongation.
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0, TWO = 2.0D0,
     1  FSTAB = 0.99D0)
      DIMENSION E0(3)
      AK = PROPS(1)
      AC = PROPS(2)
      AM = PROPS(3)
      DO K = 1, NBLOCK
         AL0 = ZERO
         DO ID = 1, MCRD
            E0(ID) = COORDS(K,2,ID) - COORDS(K,1,ID)
            AL0 = AL0 + E0(ID)*E0(ID)
         ENDDO
         AL0 = SQRT(AL0)
         DO ID = 1, MCRD
            E0(ID) = E0(ID)/AL0
         ENDDO
         IF (LFLAGS(IOPCODE) .EQ. JMASSCALC) THEN
            DO I = 1, NDOFEL
               DO J = 1, NDOFEL
                  AMASS(K,I,J) = ZERO
               ENDDO
               AMASS(K,I,I) = AM
            ENDDO
         ELSE IF (LFLAGS(IOPCODE) .EQ. JINTFORCEANDDTSTABLE) THEN
            DELTA = ZERO
            DDOT  = ZERO
            DINC  = ZERO
            DO ID = 1, MCRD
               DELTA = DELTA + E0(ID)*(U(K,MCRD+ID)-U(K,ID))
               DDOT  = DDOT + E0(ID)*(V(K,MCRD+ID)-V(K,ID))
               DINC  = DINC + E0(ID)*(DU(K,MCRD+ID)-DU(K,ID))
            ENDDO
            FDASH = AC*DDOT
            FTOT  = AK*DELTA + FDASH
            DO ID = 1, MCRD
               RHS(K,ID)      = -FTOT*E0(ID)
               RHS(K,MCRD+ID) =  FTOT*E0(ID)
            ENDDO
            ENERGY(K,IELIE) = HALF*AK*DELTA*DELTA
            ENERGY(K,IELDD) = ENERGY(K,IELDD) + FDASH*DINC
            SVARS(K,1) = DELTA
!           stable increment of the relative mode, Eq. 13.6-3
            OMEGA2 = TWO*AK/AM
            GAMMA  = AC/AM
            DTIMESTABLE(K) = FSTAB*TWO/(GAMMA +
     1         SQRT(OMEGA2 + GAMMA*GAMMA))
         ELSE
            DO I = 1, NDOFEL
               RHS(K,I) = ZERO
            ENDDO
         ENDIF
      ENDDO
      RETURN
      END
