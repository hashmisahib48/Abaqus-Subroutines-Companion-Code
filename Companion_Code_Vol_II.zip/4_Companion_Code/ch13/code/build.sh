#!/bin/sh
# Compile every listing of Chapter 13 and run the driver (gfortran; Abaqus is not involved).
cd /home/claude/vol2/ch13/code || exit 1
INC=-I/home/claude/vol2/lib/aba
FL="-ffixed-form -ffixed-line-length-none -std=legacy"
for f in ex13_vuel ex13_truss ex13_spdp prob_13b3_bug; do gfortran -c $FL $INC $f.f -o /tmp/$f.o || exit 1; done
gfortran $FL -ffree-line-length-none $INC drv13_main.f drv13.f ex13_vuel.f ex13_truss.f ex13_spdp.f -o /tmp/drv13 || exit 1
/tmp/drv13 && echo driver done
python3 ../verify/check13.py
