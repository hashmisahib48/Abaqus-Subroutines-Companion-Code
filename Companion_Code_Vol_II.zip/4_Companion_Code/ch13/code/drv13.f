!     Explicit driver for VUEL (Chapter 13): central-difference
!     integration of an assembled set of 2-node user elements.
!     N, mm, tonne, s, MPa.
      SUBROUTINE D13_SIM(JT, NE, NN, MCRD, ICON, X0, IFIX, ADDM, U0, V0,
     1  PROPS, NPROPS, NSV, NLG, DTABS, DTFAC, NSTEP, IOUT, IW1, IW2,
     2  IUNIT, DTMIN, UMAX, EBAL, XMSUM, OFFD)
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NEN = 12)
      COMMON /D13C/ EBAL2
      DIMENSION ICON(2,NE), X0(MCRD,NN), IFIX(MCRD*NN), ADDM(MCRD*NN),
     1  U0(MCRD*NN), V0(MCRD*NN), PROPS(NPROPS)
      DIMENSION RHS(NE,2*MCRD), AMASS(NE,2*MCRD,2*MCRD), DTS(NE),
     1  SVARS(NE,NSV), ENERGY(NE,NEN), COORDS(NE,2,MCRD),
     2  U(NE,2*MCRD), DU(NE,2*MCRD), V(NE,2*MCRD), A(NE,2*MCRD),
     3  DMSF(NE), PREDEF(NE,2,1,2), ADLMAG(NE), JELEM(NE), JPROPS(1),
     4  LFLAGS(3), TIME(2)
      DIMENSION UG(MCRD*NN), VG(MCRD*NN), AG(MCRD*NN), FI(MCRD*NN),
     1  XM(MCRD*NN), UOLD(MCRD*NN), VOLD(MCRD*NN)
      ND = MCRD*NN
      NDOFEL = 2*MCRD
      SVARS = 0.D0
      ENERGY = 0.D0
      A = 0.D0
      DU = 0.D0
      V = 0.D0
      U = 0.D0
      DMSF = 1.D0
      PREDEF = 0.D0
      ADLMAG = 0.D0
      JPROPS = 0
      DO K = 1, NE
         JELEM(K) = K
         DO IN = 1, 2
            DO ID = 1, MCRD
               COORDS(K,IN,ID) = X0(ID,ICON(IN,K))
            ENDDO
         ENDDO
      ENDDO
      LFLAGS(1) = 17
      LFLAGS(2) = NLG
      TIME(1) = 0.D0
      TIME(2) = 0.D0
!     --- mass operation, assembly of the diagonal, check of the form
      LFLAGS(3) = 1
      CALL VUEL(NE, RHS, AMASS, DTS, SVARS, NSV, ENERGY, 2, NDOFEL,
     1  PROPS, NPROPS, JPROPS, 0, COORDS, MCRD, U, DU, V, A, JT, JELEM,
     2  TIME, 1.D0, 0.D0, 0.D0, 1, 1, LFLAGS, DMSF, PREDEF, 0, 0, ADLMAG)
      XM = ADDM
      OFFD = 0.D0
      DO K = 1, NE
         DO I = 1, NDOFEL
            DO J = 1, NDOFEL
               IF (I .NE. J) OFFD = MAX(OFFD, ABS(AMASS(K,I,J)))
            ENDDO
            IG = (ICON((I-1)/MCRD+1,K)-1)*MCRD + MOD(I-1,MCRD) + 1
            XM(IG) = XM(IG) + AMASS(K,I,I)
         ENDDO
      ENDDO
      XMSUM = 0.D0
      DO I = 1, ND, MCRD
         XMSUM = XMSUM + XM(I)
      ENDDO
!     --- initial acceleration
!     quasi-static ramp from zero to U0 (so that the internal energy
!     starts from the correct value), then the initial force
      UG = 0.D0
      VG = 0.D0
      AG = 0.D0
      UOLD = 0.D0
      DO IR = 1, 400
         UOLD = UG
         UG = U0*DBLE(IR)/400.D0
         CALL FORCES
      ENDDO
      UG = U0
      VG = V0
      UOLD = U0
      CALL FORCES
      DTMIN = MINVAL(DTS)
      DT = DTABS
      IF (DT .LE. 0.D0) DT = DTFAC*DTMIN
      DO I = 1, ND
         AG(I) = 0.D0
         IF (IFIX(I) .EQ. 0) AG(I) = -FI(I)/XM(I)
      ENDDO
      UMAX = MAXVAL(ABS(UG))
      UREF = MAX(UMAX, 1.D-30)
      E0 = 0.D0
      E02 = 0.D0
      EBAL = 0.D0
      EBAL2 = 0.D0
      CALL OUT(0, 0.5D0*SUM(XM*VG*VG), 0.5D0*SUM(XM*VG*VG), E0, E02)
      DO I = 1, ND
         VG(I) = VG(I) + 0.5D0*DT*AG(I)
         UG(I) = UG(I) + DT*VG(I)
      ENDDO
      DO N = 1, NSTEP
         TIME(1) = N*DT
         TIME(2) = N*DT
         CALL FORCES
         DO I = 1, ND
            AG(I) = 0.D0
            IF (IFIX(I) .EQ. 0) AG(I) = -FI(I)/XM(I)
            VOLD(I) = VG(I)
            VG(I) = VG(I) + DT*AG(I)
            UOLD(I) = UG(I)
         ENDDO
         EKIN = 0.D0
         EKIN2 = 0.D0
         DO I = 1, ND
            EKIN = EKIN + 0.5D0*XM(I)*VOLD(I)*VG(I)
            EKIN2 = EKIN2 + 0.125D0*XM(I)*(VOLD(I)+VG(I))**2
         ENDDO
         CALL OUT(N, EKIN, EKIN2, E0, E02)
         DO I = 1, ND
            UG(I) = UG(I) + DT*VG(I)
         ENDDO
         UMAX = MAX(UMAX, MAXVAL(ABS(UG)))
         IF (UMAX .GT. 3.D0*UREF*1.D3 .OR. UMAX .NE. UMAX) GOTO 900
      ENDDO
  900 CONTINUE
      RETURN
      CONTAINS
      SUBROUTINE FORCES
!        gather, call VUEL (internal force operation), scatter
         DO K = 1, NE
            DO IN = 1, 2
               DO ID = 1, MCRD
                  II = (IN-1)*MCRD + ID
                  IG = (ICON(IN,K)-1)*MCRD + ID
                  DU(K,II) = UG(IG) - UOLD(IG)
                  U(K,II) = UG(IG)
                  V(K,II) = VG(IG)
                  A(K,II) = AG(IG)
               ENDDO
            ENDDO
         ENDDO
         LFLAGS(3) = 2
         CALL VUEL(NE, RHS, AMASS, DTS, SVARS, NSV, ENERGY, 2,
     1     NDOFEL, PROPS, NPROPS, JPROPS, 0, COORDS, MCRD, U, DU,
     2     V, A, JT, JELEM, TIME, 1.D0, DT, DT, 1, 1, LFLAGS, DMSF,
     3     PREDEF, 0, 0, ADLMAG)
         FI = 0.D0
         DO K = 1, NE
            DO IN = 1, 2
               DO ID = 1, MCRD
                  II = (IN-1)*MCRD + ID
                  IG = (ICON(IN,K)-1)*MCRD + ID
                  FI(IG) = FI(IG) + RHS(K,II)
               ENDDO
            ENDDO
         ENDDO
      END SUBROUTINE FORCES
      SUBROUTINE OUT(N, EKIN, EKIN2, E0, E02)
         EIN = SUM(ENERGY(:,3))
         EDS = SUM(ENERGY(:,5))
         ETOT = EKIN + EIN + EDS
         ETOT2 = EKIN2 + EIN + EDS
         IF (N .EQ. 0) E02 = ETOT2
         IF (N .EQ. 1) E0 = ETOT
         IF (N .GE. 1 .AND. E0 .NE. 0.D0) EBAL = MAX(EBAL,
     1      ABS(ETOT-E0)/ABS(E0))
         IF (E02 .NE. 0.D0) EBAL2 = MAX(EBAL2,ABS(ETOT2-E02)/ABS(E02))
         IF (IUNIT .GT. 0 .AND. MOD(N,IOUT) .EQ. 0) THEN
            UA = 0.D0
            UB = 0.D0
            IF (IW1 .GT. 0) UA = UG(IW1)
            IF (IW2 .GT. 0) UB = UG(IW2)
            WRITE(IUNIT,'(6(1PE23.15,1X))') N*DT, UA, UB,
     1        EKIN, EIN, EDS
         ENDIF
      END SUBROUTINE OUT
      END
