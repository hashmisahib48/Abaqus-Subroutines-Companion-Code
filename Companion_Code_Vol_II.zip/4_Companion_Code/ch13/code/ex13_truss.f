      SUBROUTINE K13_TRUSS(
     1  NBLOCK, RHS, AMASS, DTIMESTABLE, SVARS, NSVARS, ENERGY,
     2  NNODE, NDOFEL, PROPS, NPROPS, JPROPS, NJPROPS, COORDS,
     3  MCRD, U, DU, V, A, JTYPE, JELEM, TIME, PERIOD, DTIMECUR,
     4  DTIMEPREV, KSTEP, KINC, LFLAGS, DMASSSCALEFACTOR, PREDEF,
     5  NPREDEF, JDLTYP, ADLMAG)
!
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (JMASSCALC = 1, JINTFORCEANDDTSTABLE = 2,
     1  JEXTERNFORCE = 3)
      PARAMETER (IPROCEDURE = 1, INLGEOM = 2, IOPCODE = 3,
     1  NFLAGS = 3)
      PARAMETER (NELENERGY = 12, NPRED = 2, NTIME = 2)
      PARAMETER (IELIE = 3)
      DIMENSION RHS(NBLOCK,NDOFEL), AMASS(NBLOCK,NDOFEL,NDOFEL),
     1  DTIMESTABLE(NBLOCK), SVARS(NBLOCK,NSVARS),
     2  ENERGY(NBLOCK,NELENERGY), PROPS(NPROPS), JPROPS(NJPROPS),
     3  JELEM(NBLOCK), TIME(NTIME), LFLAGS(NFLAGS),
     4  COORDS(NBLOCK,NNODE,MCRD), U(NBLOCK,NDOFEL),
     5  DU(NBLOCK,NDOFEL), V(NBLOCK,NDOFEL), A(NBLOCK,NDOFEL),
     6  DMASSSCALEFACTOR(NBLOCK), ADLMAG(NBLOCK),
     7  PREDEF(NBLOCK,NNODE,NPREDEF,NPRED)
!
!     Two-node truss, 2-D or 3-D (NDOFEL = 2*MCRD).  Properties:
!     PROPS(1) = A0 (mm^2), PROPS(2) = E (MPa), PROPS(3) = RHO
!     (t/mm^3).  SVARS(1) = length, SVARS(2) = force, previous call
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0, FSTAB = 0.99D0)
      DIMENSION XD(3)
      AREA0 = PROPS(1)
      EMOD  = PROPS(2)
      RHO   = PROPS(3)
      WAVE  = SQRT(EMOD/RHO)
      DO K = 1, NBLOCK
         AL0 = ZERO
         DO ID = 1, MCRD
            XD(ID) = COORDS(K,2,ID) - COORDS(K,1,ID)
            AL0 = AL0 + XD(ID)*XD(ID)
         ENDDO
         AL0 = SQRT(AL0)
         IF (LFLAGS(IOPCODE) .EQ. JMASSCALC) THEN
!           lumped mass: half of the bar mass at each end
            AM0 = HALF*AREA0*RHO*AL0
            DO I = 1, NDOFEL
               DO J = 1, NDOFEL
                  AMASS(K,I,J) = ZERO
               ENDDO
               AMASS(K,I,I) = AM0
            ENDDO
         ELSE IF (LFLAGS(IOPCODE) .EQ. JINTFORCEANDDTSTABLE) THEN
            AL = ZERO
            DO ID = 1, MCRD
               XD(ID) = XD(ID) + U(K,MCRD+ID) - U(K,ID)
               AL = AL + XD(ID)*XD(ID)
            ENDDO
            AL = SQRT(AL)
!           logarithmic strain, force on the original area
            FAX = EMOD*AREA0*LOG(AL/AL0)
            DO ID = 1, MCRD
               RHS(K,ID)      = -FAX*XD(ID)/AL
               RHS(K,MCRD+ID) =  FAX*XD(ID)/AL
            ENDDO
!           internal energy, trapezoidal rule (first call: 0)
            ALOLD = SVARS(K,1)
            FOLD  = SVARS(K,2)
            IF (ALOLD .LE. ZERO) THEN
               ALOLD = AL0
               FOLD  = ZERO
            ENDIF
            ENERGY(K,IELIE) = ENERGY(K,IELIE)
     1         + HALF*(FAX + FOLD)*(AL - ALOLD)
            SVARS(K,1) = AL
            SVARS(K,2) = FAX
            DTIMESTABLE(K) = FSTAB*SQRT(AL*AL0)/WAVE
         ELSE
!           external force operation: no distributed load on a truss
            DO I = 1, NDOFEL
               RHS(K,I) = ZERO
            ENDDO
         ENDIF
      ENDDO
      RETURN
      END
