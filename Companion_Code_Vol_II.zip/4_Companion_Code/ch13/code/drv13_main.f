!     Main program of the Chapter 13 driver: scenarios of Examples
!     13.5-1, 13.6-1, 13.4-1, 13.7-1 and the element checks.
      PROGRAM DRV13M
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (PI = 3.14159265358979D0)
      COMMON /D13C/ EBAL2
      DIMENSION ICON(2,64), X0(200), IFIX(200), ADDM(200), U0(200),
     1  V0(200), PROPS(8)
      CHARACTER*40 FN
      OPEN(20, FILE='../verify/summary.txt')
      EMOD = 210000.D0
      RHO  = 7.85D-9
      WAVE = SQRT(EMOD/RHO)
      WRITE(20,'(A,1PE22.14)') 'wave_speed ', WAVE
!     ---------------- S1: truss with a tip mass ---------------------
      AL = 100.D0
      AREA = 10.D0
      TIPM = 1.D-4
      PROPS(1) = AREA
      PROPS(2) = EMOD
      PROPS(3) = RHO
      ICON(1,1) = 1
      ICON(2,1) = 2
      X0 = 0.D0
      X0(4) = AL
      IFIX = 0
      ADDM = 0.D0
      U0 = 0.D0
      V0 = 0.D0
      DO I = 1, 3
         IFIX(I) = 1
      ENDDO
      IFIX(5) = 1
      IFIX(6) = 1
      ADDM(4) = TIPM
      U0(4) = 1.D-3
      CALL D13_SIM(1001, 1, 2, 3, ICON, X0, IFIX, ADDM, U0, V0, PROPS,
     1  3, 2, 0, 0.D0, 1.D0, 0, 1, 0, 4, 0, DTM, UMX, EB, XMS, OFD)
      WRITE(20,'(A,1PE22.14)') 's1_dtstable ', DTM
      WRITE(20,'(A,1PE22.14)') 's1_masssum ', XMS
      WRITE(20,'(A,1PE22.14)') 's1_offdiag ', OFD
      TEND = 2.4D-3
      DO IC = 1, 6
         FAC = 0.25D0
         IF (IC .EQ. 2) FAC = 1.D0
         IF (IC .EQ. 3) FAC = 2.D0
         IF (IC .EQ. 4) FAC = 4.D0
         IF (IC .EQ. 5) FAC = 7.D0
         IF (IC .EQ. 6) FAC = 8.D0
         NST = INT(TEND/(FAC*DTM))
         WRITE(FN,'(A,I1,A)') '../verify/s1_', IC, '.txt'
         OPEN(21, FILE=FN)
         CALL D13_SIM(1001, 1, 2, 3, ICON, X0, IFIX, ADDM, U0, V0,
     1     PROPS, 3, 2, 0, 0.D0, FAC, NST, MAX(1,INT(0.25D0/FAC)), 0, 4,
     2     21, DTM, UMX, EB, XMS, OFD)
         CLOSE(21)
         WRITE(20,'(A,I1,A,F8.2,I8,3(1X,1PE12.4))') 's1_run',
     1     IC, ' ', FAC, NST, UMX, EB, EBAL2
      ENDDO
      FLO = 0.5D0
      FHI = 40.D0
      DO IT = 1, 40
         FM = 0.5D0*(FLO+FHI)
         CALL D13_SIM(1001, 1, 2, 3, ICON, X0, IFIX, ADDM, U0, V0,
     1     PROPS, 3, 2, 0, 0.D0, FM, 60000, 1, 0, 4, 0, DTM, UMX, EB,
     2     XMS, OFD)
         IF (UMX .GT. 3.D-3) THEN
            FHI = FM
         ELSE
            FLO = FM
         ENDIF
      ENDDO
      WRITE(20,'(A,1PE22.14)') 's1_crit ', FLO
!     ---------------- S2: spring and dashpot, free-free --------------
      PROPS(1) = 1000.D0
      PROPS(3) = 0.01D0
      OMEG = SQRT(2.D0*PROPS(1)/PROPS(3))
      WRITE(20,'(A,1PE22.14)') 's2_omega ', OMEG
      C30 = COS(PI/6.D0)
      S30 = SIN(PI/6.D0)
      X0 = 0.D0
      X0(3) = 10.D0*C30
      X0(4) = 10.D0*S30
      IFIX = 0
      ADDM = 0.D0
      V0 = 0.D0
      U0 = 0.D0
      U0(1) = -0.5D0*C30
      U0(2) = -0.5D0*S30
      U0(3) =  0.5D0*C30
      U0(4) =  0.5D0*S30
      NRUN = 0
      DO IX = 1, 5
         XI = 0.D0
         IF (IX .EQ. 2) XI = 0.1D0
         IF (IX .EQ. 3) XI = 0.5D0
         IF (IX .EQ. 4) XI = 1.D0
         IF (IX .EQ. 5) XI = 3.D0
         PROPS(2) = XI*PROPS(3)*OMEG
!        critical factor by bisection
         CALL D13_SIM(1002, 1, 2, 2, ICON, X0, IFIX, ADDM, U0, V0,
     1     PROPS, 3, 1, 0, 0.D0, 1.D0, 0, 1, 0, 3, 0, DTM, UMX, EB,
     2     XMS, OFD)
         WRITE(20,'(A,I1,1X,F6.3,1X,1PE22.14)') 's2_dtstable', IX, XI,
     1     DTM
         FLO = 0.5D0
         FHI = 3.D0
         DO IT = 1, 40
            FM = 0.5D0*(FLO+FHI)
            CALL D13_SIM(1002, 1, 2, 2, ICON, X0, IFIX, ADDM, U0, V0,
     1        PROPS, 3, 1, 0, 0.D0, FM, 60000, 1, 0, 3, 0, DTM, UMX, EB,
     2        XMS, OFD)
            IF (UMX .GT. 3.D0) THEN
               FHI = FM
            ELSE
               FLO = FM
            ENDIF
         ENDDO
         WRITE(20,'(A,I1,1X,F6.3,1X,1PE22.14)') 's2_crit', IX, XI, FLO
      ENDDO
!     detailed runs: damping ratio 0.1, five increments
      PROPS(2) = 0.1D0*PROPS(3)*OMEG
      DO IC = 1, 5
         DTA = 1.D-3/2.D0**(IC-1)
         NST = INT(0.05D0/DTA)
         WRITE(FN,'(A,I1,A)') '../verify/s2_', IC, '.txt'
         OPEN(21, FILE=FN)
         CALL D13_SIM(1002, 1, 2, 2, ICON, X0, IFIX, ADDM, U0, V0,
     1     PROPS, 3, 1, 0, DTA, 1.D0, NST, 1, 1, 3, 21, DTM, UMX, EB,
     2     XMS, OFD)
         CLOSE(21)
         WRITE(20,'(A,I1,1X,1PE14.6,I8,1X,1PE12.4)') 's2_run', IC, DTA,
     1     NST, EB
      ENDDO
      DO IX = 3, 5, 2
         XI = 0.5D0
         IF (IX .EQ. 5) XI = 1.5D0
         PROPS(2) = XI*PROPS(3)*OMEG
         DTA = 2.5D-4
         WRITE(FN,'(A,I1,A)') '../verify/s2x_', IX, '.txt'
         OPEN(21, FILE=FN)
         CALL D13_SIM(1002, 1, 2, 2, ICON, X0, IFIX, ADDM, U0, V0,
     1     PROPS, 3, 1, 0, DTA, 1.D0, 200, 1, 1, 3, 21, DTM, UMX, EB,
     2     XMS, OFD)
         CLOSE(21)
         WRITE(20,'(A,I1,1X,F6.3,1X,1PE12.4)') 's2x', IX, XI, EB
      ENDDO
!     ---------------- S3: bar of 20 elements, released ---------------
      NE = 20
      AL = 1000.D0
      AREA = 10.D0
      H = AL/NE
      PROPS(1) = AREA
      PROPS(2) = EMOD
      PROPS(3) = RHO
      X0 = 0.D0
      IFIX = 0
      ADDM = 0.D0
      V0 = 0.D0
      EPS0 = 1.D-3
      DO J = 1, NE
         ICON(1,J) = J
         ICON(2,J) = J + 1
      ENDDO
      DO J = 1, NE + 1
         X0(J) = (J-1)*H
         U0(J) = EPS0*X0(J)
      ENDDO
      IFIX(1) = 1
      CALL D13_SIM(1001, NE, NE+1, 1, ICON, X0, IFIX, ADDM, U0, V0,
     1  PROPS, 3, 2, 0, 0.D0, 1.D0, 0, 1, 0, NE+1, 0, DTM, UMX, EB,
     2  XMS, OFD)
      WRITE(20,'(A,1PE22.14)') 's3_dtstable ', DTM
      WRITE(20,'(A,1PE22.14)') 's3_masssum ', XMS
      TP = 4.D0*AL/WAVE
      NST = INT(3.D0*TP/DTM)
      OPEN(21, FILE='../verify/s3.txt')
      CALL D13_SIM(1001, NE, NE+1, 1, ICON, X0, IFIX, ADDM, U0, V0,
     1  PROPS, 3, 2, 0, 0.D0, 1.D0, NST, 1, 0, NE+1, 21, DTM, UMX, EB,
     2  XMS, OFD)
      CLOSE(21)
      WRITE(20,'(A,I8,2(1X,1PE12.4))') 's3_run ', NST, EB, EBAL2
      FLO = 0.5D0
      FHI = 3.D0
      DO IT = 1, 40
         FM = 0.5D0*(FLO+FHI)
         CALL D13_SIM(1001, NE, NE+1, 1, ICON, X0, IFIX, ADDM, U0, V0,
     1     PROPS, 3, 2, 0, 0.D0, FM, 60000, 1, 0, NE+1, 0, DTM, UMX, EB,
     2     XMS, OFD)
         IF (UMX .GT. 3.D0*EPS0*AL) THEN
            FHI = FM
         ELSE
            FLO = FM
         ENDIF
      ENDDO
      WRITE(20,'(A,1PE22.14)') 's3_crit ', FLO
      DO IC = 1, 6
         FM = 0.9D0
         IF (IC .EQ. 2) FM = 1.D0
         IF (IC .EQ. 3) FM = 1.01D0
         IF (IC .EQ. 4) FM = 1.02D0
         IF (IC .EQ. 5) FM = 1.05D0
         IF (IC .EQ. 6) FM = 1.2D0
         CALL D13_SIM(1001, NE, NE+1, 1, ICON, X0, IFIX, ADDM, U0, V0,
     1     PROPS, 3, 2, 0, 0.D0, FM, 600, 1, 0, NE+1, 0, DTM, UMX, EB,
     2     XMS, OFD)
         WRITE(20,'(A,I1,1X,F6.3,1X,1PE12.4,1X,1PE12.4)') 's3_f', IC,
     1     FM, UMX, EB
      ENDDO
!     ---------------- S4: transverse motion, large strain ------------
      AL = 100.D0
      AREA = 1.D0
      TIPM = 1.D-3
      PROPS(1) = AREA
      X0 = 0.D0
      X0(3) = AL
      IFIX = 0
      ADDM = 0.D0
      V0 = 0.D0
      U0 = 0.D0
      ICON(1,1) = 1
      ICON(2,1) = 2
      IFIX(1) = 1
      IFIX(2) = 1
      IFIX(3) = 1
      ADDM(4) = TIPM
      U0(4) = 50.D0
      CALL D13_SIM(1001, 1, 2, 2, ICON, X0, IFIX, ADDM, U0, V0, PROPS,
     1  3, 2, 1, 0.D0, 1.D0, 0, 1, 0, 4, 0, DTM, UMX, EB, XMS, OFD)
      WRITE(20,'(A,1PE22.14)') 's4_dtstable ', DTM
      NST = INT(3.0D-2/DTM)
      OPEN(21, FILE='../verify/s4.txt')
      CALL D13_SIM(1001, 1, 2, 2, ICON, X0, IFIX, ADDM, U0, V0, PROPS,
     1  3, 2, 1, 0.D0, 1.D0, NST, 5, 0, 4, 21, DTM, UMX, EB, XMS, OFD)
      CLOSE(21)
      WRITE(20,'(A,I8,2(1X,1PE12.4))') 's4_run ', NST, EB, EBAL2
      CALL D13_CHK
      CLOSE(20)
      END
!
      SUBROUTINE D13_CHK
!     rigid motion, equilibrium and block independence of the truss
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NB = 5, MC = 3, ND = 6)
      DIMENSION RHS(NB,ND), AMASS(NB,ND,ND), DTS(NB), SVARS(NB,2),
     1  ENERGY(NB,12), COORDS(NB,2,MC), U(NB,ND), DU(NB,ND), V(NB,ND),
     2  A(NB,ND), DMSF(NB), PREDEF(NB,2,1,2), ADLMAG(NB), JELEM(NB),
     3  JPROPS(1), LFLAGS(3), TIME(2), PROPS(3), R(3,3), RHS1(1,ND),
     4  AM1(1,ND,ND), DTS1(1), SV1(1,2), EN1(1,12), CO1(1,2,MC),
     5  U1(1,ND), DU1(1,ND), V1(1,ND), A1(1,ND), DM1(1), PR1(1,2,1,2),
     6  AD1(1), JE1(1), CUR(3,2)
      PROPS(1) = 12.D0
      PROPS(2) = 210000.D0
      PROPS(3) = 7.85D-9
      ISEED = 12345
      SVARS = 0.D0
      ENERGY = 0.D0
      DU = 0.D0
      V = 0.D0
      A = 0.D0
      DMSF = 1.D0
      PREDEF = 0.D0
      ADLMAG = 0.D0
      JPROPS = 0
      LFLAGS(1) = 17
      LFLAGS(2) = 1
      LFLAGS(3) = 2
      TIME = 0.D0
      DO K = 1, NB
         JELEM(K) = K
         DO IN = 1, 2
            DO ID = 1, MC
               ISEED = MOD(1103515245*ISEED + 12345, 2147483647)
               COORDS(K,IN,ID) = 100.D0*DBLE(ISEED)/2147483647.D0
            ENDDO
         ENDDO
      ENDDO
!     rotation about the axis (1,2,2)/3 by 0.7 rad, plus translation
      TH = 0.7D0
      AX = 1.D0/3.D0
      AY = 2.D0/3.D0
      AZ = 2.D0/3.D0
      CT = COS(TH)
      ST = SIN(TH)
      R(1,1) = CT + AX*AX*(1.D0-CT)
      R(1,2) = AX*AY*(1.D0-CT) - AZ*ST
      R(1,3) = AX*AZ*(1.D0-CT) + AY*ST
      R(2,1) = AY*AX*(1.D0-CT) + AZ*ST
      R(2,2) = CT + AY*AY*(1.D0-CT)
      R(2,3) = AY*AZ*(1.D0-CT) - AX*ST
      R(3,1) = AZ*AX*(1.D0-CT) - AY*ST
      R(3,2) = AZ*AY*(1.D0-CT) + AX*ST
      R(3,3) = CT + AZ*AZ*(1.D0-CT)
      DO K = 1, NB
         DO IN = 1, 2
            DO ID = 1, MC
               UR = -COORDS(K,IN,ID) + 5.D0*ID
               DO JD = 1, MC
                  UR = UR + R(ID,JD)*COORDS(K,IN,JD)
               ENDDO
               U(K,(IN-1)*MC+ID) = UR
            ENDDO
         ENDDO
      ENDDO
      CALL VUEL(NB, RHS, AMASS, DTS, SVARS, 2, ENERGY, 2, ND, PROPS, 3,
     1  JPROPS, 0, COORDS, MC, U, DU, V, A, 1001, JELEM, TIME, 1.D0,
     2  1.D0, 1.D0, 1, 1, LFLAGS, DMSF, PREDEF, 0, 0, ADLMAG)
      RMAX = 0.D0
      DO K = 1, NB
         DO I = 1, ND
            RMAX = MAX(RMAX, ABS(RHS(K,I)))
         ENDDO
      ENDDO
      EMAX = MAXVAL(ABS(ENERGY(:,3)))
      WRITE(20,'(A,1PE14.6)') 'chk_rigid_rhsmax ', RMAX
      WRITE(20,'(A,1PE14.6)') 'chk_rigid_energy ', EMAX
!     stretch field: force and moment balance, block independence
      SVARS = 0.D0
      ENERGY = 0.D0
      DO K = 1, NB
         DO IN = 1, 2
            DO ID = 1, MC
               ISEED = MOD(1103515245*ISEED + 12345, 2147483647)
               U(K,(IN-1)*MC+ID) = 5.D0*(DBLE(ISEED)/2147483647.D0-.5D0)
            ENDDO
         ENDDO
      ENDDO
      CALL VUEL(NB, RHS, AMASS, DTS, SVARS, 2, ENERGY, 2, ND, PROPS, 3,
     1  JPROPS, 0, COORDS, MC, U, DU, V, A, 1001, JELEM, TIME, 1.D0,
     2  1.D0, 1.D0, 1, 1, LFLAGS, DMSF, PREDEF, 0, 0, ADLMAG)
      FMAX = 0.D0
      TMAX = 0.D0
      SCAL = 0.D0
      DO K = 1, NB
         DO ID = 1, MC
            FS = RHS(K,ID) + RHS(K,MC+ID)
            FMAX = MAX(FMAX, ABS(FS))
            SCAL = MAX(SCAL, ABS(RHS(K,ID)))
            DO IN = 1, 2
               CUR(ID,IN) = COORDS(K,IN,ID) + U(K,(IN-1)*MC+ID)
            ENDDO
         ENDDO
         TM1 = CUR(2,1)*RHS(K,3) - CUR(3,1)*RHS(K,2)
     1       + CUR(2,2)*RHS(K,6) - CUR(3,2)*RHS(K,5)
         TM2 = CUR(3,1)*RHS(K,1) - CUR(1,1)*RHS(K,3)
     1       + CUR(3,2)*RHS(K,4) - CUR(1,2)*RHS(K,6)
         TM3 = CUR(1,1)*RHS(K,2) - CUR(2,1)*RHS(K,1)
     1       + CUR(1,2)*RHS(K,5) - CUR(2,2)*RHS(K,4)
         TMAX = MAX(TMAX, ABS(TM1), ABS(TM2), ABS(TM3))
      ENDDO
      WRITE(20,'(A,1PE14.6)') 'chk_equil_force ', FMAX
      WRITE(20,'(A,1PE14.6)') 'chk_equil_moment ', TMAX
      WRITE(20,'(A,1PE14.6)') 'chk_equil_scale ', SCAL
!     block independence: element 3 alone
      K = 3
      DO I = 1, ND
         U1(1,I) = U(K,I)
         DU1(1,I) = 0.D0
         V1(1,I) = 0.D0
         A1(1,I) = 0.D0
      ENDDO
      DO IN = 1, 2
         DO ID = 1, MC
            CO1(1,IN,ID) = COORDS(K,IN,ID)
         ENDDO
      ENDDO
      SV1 = 0.D0
      EN1 = 0.D0
      DM1 = 1.D0
      PR1 = 0.D0
      AD1 = 0.D0
      JE1(1) = 3
      CALL VUEL(1, RHS1, AM1, DTS1, SV1, 2, EN1, 2, ND, PROPS, 3,
     1  JPROPS, 0, CO1, MC, U1, DU1, V1, A1, 1001, JE1, TIME, 1.D0,
     2  1.D0, 1.D0, 1, 1, LFLAGS, DM1, PR1, 0, 0, AD1)
      BD = 0.D0
      DO I = 1, ND
         BD = MAX(BD, ABS(RHS1(1,I)-RHS(3,I)))
      ENDDO
      BD = MAX(BD, ABS(DTS1(1)-DTS(3)))
      WRITE(20,'(A,1PE14.6)') 'chk_block_diff ', BD
      END
