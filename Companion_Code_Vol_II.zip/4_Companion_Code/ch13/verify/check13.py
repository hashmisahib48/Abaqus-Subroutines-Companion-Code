"""Chapter 13: compare the outputs of the gfortran driver (code/drv13*.f) with closed forms
and independent integrations; write results.json."""
import numpy as np, json, re
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar, brentq
import scipy.linalg as sl
V='/home/claude/vol2/ch13/verify/'
S={}
for ln in open(V+'summary.txt'):
    p=ln.split()
    if not p: continue
    S[p[0]]=[float(x) if re.match(r'^-?[\d.]+([EeDd][+-]?\d+)?$',x) else x for x in p[1:]]
R={}
E,RHO=210000.,7.85e-9; c=np.sqrt(E/RHO); R['wave']=c
# ---------------- S1: truss with tip mass ----------------
L,A,M,u0=100.,10.,1e-4,1e-3; k=E*A/L; mb=RHO*A*L
w=np.sqrt(k/(M+mb/2)); T=2*np.pi/w
# continuum bar with tip mass: beta tan beta = mb/M
bc=brentq(lambda b:b*np.tan(b)-mb/M,1e-6,np.pi/2-1e-9); wc=bc*c/L
R['s1']=dict(k=k,mb=mb,w=w,T=T,wc=wc,w_over_wc=w/wc,dtstab=S['s1_dtstable'][0],masssum=S['s1_masssum'][0],
  offdiag=S['s1_offdiag'][0],crit=S['s1_crit'][0],w_dt_limit=2/w, crit_exact=2/w/S['s1_dtstable'][0],runs=[])
for ic in range(1,6):
    d=np.loadtxt(V+f's1_{ic}.txt'); t=d[:,0]; u=d[:,2]
    fac=S[f's1_run{ic}'][0]; dt=fac*S['s1_dtstable'][0]
    wh=2/dt*np.arcsin(w*dt/2)
    err_h=np.max(np.abs(u-u0*np.cos(wh*t)))/u0
    err_c=np.max(np.abs(u-u0*np.cos(w*t)))/u0
    f=lambda ww:np.sum((u-u0*np.cos(ww*t))**2)
    r=minimize_scalar(f,bounds=(wh*0.97,wh*1.03),method='bounded',options=dict(xatol=1e-10*wh))
    R['s1']['runs'].append(dict(fac=fac,dt=dt,wdt=w*dt,wh_formula=wh,w_fit=r.x,T_ratio_formula=w/wh,T_ratio_fit=w/r.x,
       rel_period_err=w/wh-1,approx=(w*dt)**2/24,err_vs_disc=err_h,err_vs_cont=err_c,ebal=S[f's1_run{ic}'][3],steps=int(S[f's1_run{ic}'][1]),ebal_naive=S[f's1_run{ic}'][4]))
# ---------------- S2: spring-dashpot ----------------
m,kk=0.01,1000.; om=np.sqrt(2*kk/m); d0=1.0
R['s2']=dict(omega=om,crit=[],runs=[],x=[])
for ix in range(1,6):
    xi=[0,.1,.5,1,3][ix-1]; dts=S[f's2_dtstable{ix}'][1]
    g=xi*om
    dtf=2/(g+np.sqrt(om**2+g**2))
    R['s2']['crit'].append(dict(xi=xi,dtstable=dts,dtformula=dtf,dtstab_over_formula=dts/(0.99*dtf),crit=S[f's2_crit{ix}'][1],crit_dt=S[f's2_crit{ix}'][1]*dts))
def delta_exact(t,xi):
    if xi<1:
        wd=om*np.sqrt(1-xi**2); return d0*np.exp(-xi*om*t)*(np.cos(wd*t)+xi*om/wd*np.sin(wd*t))
    if xi==1: return d0*np.exp(-om*t)*(1+om*t)
    s=om*np.sqrt(xi**2-1); return d0*np.exp(-xi*om*t)*(np.cosh(s*t)+xi*om/s*np.sinh(s*t))
C30=np.cos(np.pi/6)
for ic in range(1,6):
    d=np.loadtxt(V+f's2_{ic}.txt'); t=d[:,0]; dl=(d[:,2]-d[:,1])/C30; dt=S[f's2_run{ic}'][0]
    ex=delta_exact(t,0.1)
    R['s2']['runs'].append(dict(dt=dt,omdt=om*dt,err=float(np.max(np.abs(dl-ex))/d0),ebal=S[f's2_run{ic}'][2],
        mom=float(np.max(np.abs(d[:,1]+d[:,2]))),dissipated=float(d[-1,5]),ie_end=float(d[-1,4])))
for ix,xi in ((3,.5),(5,1.5)):
    d=np.loadtxt(V+f's2x_{ix}.txt'); t=d[:,0]; dl=(d[:,2]-d[:,1])/C30
    R['s2']['x'].append(dict(xi=xi,err=float(np.max(np.abs(dl-delta_exact(t,xi)))/d0),ebal=S[f's2x{ix}'][1]))
t_end=0.05; xi_=0.1; wd_=om*np.sqrt(1-xi_**2)
dd_=-d0*om**2/wd_*np.exp(-xi_*om*t_end)*np.sin(wd_*t_end); E0_=0.5*kk*d0**2
Eend=0.5*kk*delta_exact(t_end,xi_)**2+0.5*(m/2)*dd_**2
R['s2']['diss_exact']=E0_-Eend; R['s2']['E0']=E0_
e=[r['err'] for r in R['s2']['runs']]; R['s2']['order']=[float(np.log2(e[i]/e[i+1])) for i in range(4)]
# order of convergence for the undamped part separately: damping error = first order
# ---------------- S3: bar of 20 elements ----------------
N=20; Lb=1000.; h=Lb/N; Ab=10.; eps0=1e-3; kb=E*Ab/h; mn=RHO*Ab*h
Kmat=np.zeros((N,N)); Mv=np.full(N,mn); Mv[-1]=mn/2
for j in range(N):
    Kmat[j,j]+=kb
    if j>0: Kmat[j-1,j-1]+=kb; Kmat[j,j-1]-=kb; Kmat[j-1,j]-=kb
ev=sl.eigh(Kmat,np.diag(Mv),eigvals_only=True); wm=np.sqrt(ev)
dtc=2/wm[-1]; dts3=S['s3_dtstable'][0]
d=np.loadtxt(V+'s3.txt'); t=d[:,0]; ut=d[:,2]
def tri(t): # tip displacement / (eps0 L): fixed-free bar released from uniform strain
    ph=np.mod(t*c/Lb,4.0)
    return np.where(ph<2,1-ph,ph-3)
err=np.abs(ut-eps0*Lb*tri(t))/(eps0*Lb)
R['s3']=dict(N=N,h=h,dtstab=dts3,dt_h_over_c=h/c,w1=float(wm[0]),w1_cont=np.pi*c/(2*Lb),wmax=float(wm[-1]),dt_crit_exact=float(dtc),
  crit_ratio_exact=float(dtc/dts3),crit_ratio_bisect=S['s3_crit'][0],steps=int(S['s3_run'][0]),ebal=S['s3_run'][1],ebal_naive=S['s3_run'][2],
  err_max=float(err.max()),err_rms=float(np.sqrt(np.mean(err**2))),ie0=0.5*E*Ab*Lb*eps0**2,
  f=[dict(fac=S[f's3_f{i}'][0],umax=S[f's3_f{i}'][1],ebal=S[f's3_f{i}'][2]) for i in range(1,7)],
  T_cont=4*Lb/c,T_disc=2*np.pi/wm[0], masssum=S['s3_masssum'][0], mass_exact=RHO*Ab*Lb)
# ---------------- S4: nonlinear transverse truss ----------------
L0,A4,M4=100.,1.,1e-3; mbar=RHO*A4*L0; Me=M4+mbar/2; y0=50.
def F(Lc): return E*A4*np.log(Lc/L0)
def rhs(t,z):
    y,v=z; Lc=np.hypot(L0,y); return [v,-F(Lc)*y/Lc/Me]
sol=solve_ivp(rhs,[0,0.03],[y0,0],method='DOP853',rtol=1e-12,atol=1e-12,dense_output=True)
d=np.loadtxt(V+'s4.txt'); t=d[:,0]; y=d[:,2]
yr=sol.sol(t)[0]
W=lambda Lc:E*A4*(Lc*np.log(Lc/L0)-Lc+L0)
Lc=np.hypot(L0,y); Wex=W(Lc)
# period: ODE reference by event
ev_=lambda t,z:z[0]
ev_.direction=-1
sol2=solve_ivp(rhs,[0,0.2],[y0,0],method='DOP853',rtol=1e-12,atol=1e-12,events=ev_)
Tref=4*sol2.t_events[0][0] if len(sol2.t_events[0]) else None
# numerical quarter period by interpolation of the first zero crossing
i0=np.where((y[:-1]>0)&(y[1:]<=0))[0][0]; tz=t[i0]+(0-y[i0])*(t[i0+1]-t[i0])/(y[i0+1]-y[i0])
# linearised-in-strain comparison: tangent stiffness at y=0
R['s4']=dict(L0=L0,A=A4,M=M4,Me=Me,y0=y0,dtstab=S['s4_dtstable'][0],steps=int(S['s4_run'][0]),ebal=S['s4_run'][1],
  err_max=float(np.max(np.abs(y-yr))/y0),Lmax=float(np.hypot(L0,y0)),strain_max=float(np.log(np.hypot(L0,y0)/L0)),
  T_ref=float(Tref),T_num_q=float(4*tz),W_err=float(np.max(np.abs(d[:,4]-Wex))/W(np.hypot(L0,y0))),Wmax=float(W(np.hypot(L0,y0))),
  tend=float(t[-1]),Fmax=float(F(np.hypot(L0,y0))))
# ---------------- element checks ----------------
R['chk']={k_[4:]:S[k_][0] for k_ in S if k_.startswith('chk_')}
json.dump(R,open(V+'results.json','w'),indent=1,default=float)
np.savez(V+'ref.npz',t4=t,y4=y,yr4=yr,W4=Wex,IE4=d[:,4],KE4=d[:,3])
print(json.dumps(R,indent=1,default=float))
