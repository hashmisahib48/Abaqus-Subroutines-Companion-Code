"""Numbers quoted in the Problems of Chapter 13 (closed forms and independent integrations)."""
import numpy as np, json
from scipy.integrate import solve_ivp
A={}
# A1
L,Ar,E,rho=250.,20.,70000.,2.7e-9
c=np.sqrt(E/rho); A['A1']=dict(m_node=0.5*rho*Ar*L,c=c,dt=L/c,dts=0.99*L/c,nsteps=int(np.ceil(1e-3/(0.99*L/c))),dt_exact_steps=1e-3/(0.99*L/c))
# A2
k,m,cd=500.,0.02,2.0
om=np.sqrt(2*k/m); g=cd/m; xi=cd/(m*om)
A['A2']=dict(omega=om,xi=xi,ccrit=m*om,gamma=g,dt=2/(g+np.sqrt(om**2+g**2)),dts=0.99*2/(g+np.sqrt(om**2+g**2)),dt0=2/om)
# A3
L0,Ar,E=100.,10.,210000.
def F(Lc): return E*Ar*np.log(Lc/L0)
W=lambda Lc:E*Ar*(Lc*np.log(Lc/L0)-Lc+L0)
A['A3']=dict(Fp=F(105.),Fp_lin=E*Ar*5/L0,Fm=F(95.),Fm_lin=-E*Ar*5/L0,Wp=W(105.),Wm=W(95.),Wp_lin=0.5*E*Ar*25/L0,Wtrap=0.5*F(105.)*5.)
# B1
om=np.sqrt(2*1000/0.01)
A['B1']=dict(omega=om,xi05=2*(np.sqrt(1.25)-.5)/om,a_over=2*(np.sqrt(1.25)-.5),xi0=2/om,xi3=2*(np.sqrt(10)-3)/om,det05=None)
# B2
E,rho,Ar,L=210000.,7.85e-9,10.,100.
k=E*Ar/L; m=rho*Ar*L
A['B2']=dict(k=k,m=m,wl=np.sqrt(4*k/m),wc=np.sqrt(12*k/m),dtl=2/np.sqrt(4*k/m),dtc=2/np.sqrt(12*k/m),L_over_c=L/np.sqrt(E/rho))
# C1: spring with cubic hardening, damping
k0,beta,mr,xi0=1000.,0.5,0.005,0.2
w0=np.sqrt(k0/mr); cdd=2*xi0*mr*w0
def f(t,z): d,v=z; return [v,-(k0*(d+beta*d**3)+cdd*v)/mr]
ev=lambda t,z:z[0]; ev.direction=-1
s=solve_ivp(f,[0,0.1],[1.,0.],method='DOP853',rtol=1e-12,atol=1e-14,events=ev,dense_output=True)
t1=s.t_events[0][0]
ev2=lambda t,z:z[1]; ev2.direction=1
s2=solve_ivp(f,[0,0.1],[1.,0.],method='DOP853',rtol=1e-12,atol=1e-14,events=ev2)
tm=s2.t_events[0][0]; dm=s.sol(tm)[0]
A['C1']=dict(w0=w0,c=cdd,t_zero=t1,t_min=tm,d_min=dm,Wd=None)
# energy dissipated by t_min: initial energy minus potential at min
Wp=lambda d:k0*(d**2/2+beta*d**4/4)
A['C1']['Ediss_to_min']=Wp(1.)-Wp(dm)
# C2: step load on tip, truss of Example 13.5-1
E,A_,L=210000.,10.,100.; kk=E*A_/L; P=100.
A['C2']=dict(k=kk,ust=P/kk,upeak=2*P/kk,T=2*np.pi*np.sqrt((1e-4+7.85e-9*10*100/2)/kk))
wt=2*(k0*(1+3*beta*1.0**2))/0.01; gam=cdd/0.01
A['C1']['dt_tangent']=2/(gam+np.sqrt(wt+gam**2)); A['C1']['W0']=Wp(1.); A['C1']['gam']=gam; A['C1']['kt']=k0*(1+3*beta)
A['C2']['ust_half']=(P/2)/kk; A['C2']['upeak_half']=2*(P/2)/kk
json.dump(A,open('answers.json','w'),indent=1,default=float)
print(json.dumps(A,indent=1,default=float))
