!     Driver for Chapter 12: emulates what Abaqus does around a user
!     element (Newton iteration, SVARS at the start of every iteration,
!     commit when converged) and runs the verification tests.
      PROGRAM K12DRV
      INCLUDE 'ABA_PARAM.INC'
      OPEN(20, FILE='../out/results.txt')
      OPEN(7, FILE='../out/abq7.txt')
      CALL T1POINT
      CALL T2ONE
      CALL T3ELEM
      CALL T4CYL
      CLOSE(20)
      END
!
      SUBROUTINE ELCALL(IE, UE, DUE, RHSE, AE, LF3, PNEWDT)
!     one call of the user element, with the arguments Abaqus supplies
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      COMMON /STAT/ SVC(NSV,NMAXE), SVN(NSV,NMAXE)
      COMMON /CFG/ THK, ITWIN, NTS, IBB
      DIMENSION UE(8), DUE(8), RHSE(8), AE(8,8)
      DIMENSION XC(2,4), SV(NSV), ENERGY(8), PROPS(1), V(8), A(8),
     1 TIME(2), PARAMS(1), JDLTYP(1,1), ADLMAG(1,1), DDLMAG(1,1),
     2 PREDEF(2,1,4), LFLAGS(5), JPROPS(2), DUU(8,1), RHS1(8,1)
      DO I = 1, 4
         XC(1,I) = X(1,ICON(I,IE))
         XC(2,I) = X(2,ICON(I,IE))
      ENDDO
      IF (ITWIN .EQ. 1) THEN
         NSVARS = 13*4
      ELSE
         NSVARS = NTS*4
      ENDIF
      SV(1:NSVARS) = SVC(1:NSVARS,IE)
      PROPS(1) = THK
      JPROPS(1) = NTS
      JPROPS(2) = IBB
      LFLAGS = 0
      LFLAGS(1) = 1
      LFLAGS(3) = LF3
      DUU(:,1) = DUE
      V = 0.0D0
      A = 0.0D0
      TIME = 0.0D0
      PNEWDT = 1.0D0
      ENERGY = 0.0D0
      RHS1 = 0.0D0
      IF (ITWIN .EQ. 1) THEN
         CALL UEL(RHS1, AE, SV, ENERGY, 8, 1, NSVARS, PROPS, 1, XC, 2,
     1    4, UE, DUU, V, A, 1, TIME, 1.0D0, 1, 1, IE, PARAMS, 0,
     2    JDLTYP, ADLMAG, PREDEF, 0, LFLAGS, 8, DDLMAG, 1, PNEWDT,
     3    JPROPS, 2, 0.0D0)
      ELSE
         CALL UELMAT(RHS1, AE, SV, ENERGY, 8, 1, NSVARS, PROPS, 1, XC,
     1    2, 4, UE, DUU, V, A, 1, TIME, 1.0D0, 1, 1, IE, PARAMS, 0,
     2    JDLTYP, ADLMAG, PREDEF, 0, LFLAGS, 8, DDLMAG, 1, PNEWDT,
     3    JPROPS, 2, 0.0D0, IE)
      ENDIF
      RHSE = RHS1(:,1)
      SVN(1:NSVARS,IE) = SV(1:NSVARS)
      RETURN
      END
!
      SUBROUTINE ASSEMB(U, US, FINT, XK, N)
!     global internal force FINT and tangent XK at the displacements U
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      DIMENSION U(N), US(N), FINT(N), XK(N,N)
      DIMENSION UE(8), DUE(8), RHSE(8), AE(8,8), IDOF(8)
      FINT = 0.0D0
      XK = 0.0D0
      DO IE = 1, NE
         DO I = 1, 4
            IDOF(2*I-1) = 2*ICON(I,IE) - 1
            IDOF(2*I) = 2*ICON(I,IE)
         ENDDO
         UE = U(IDOF)
         DUE = U(IDOF) - US(IDOF)
         CALL ELCALL(IE, UE, DUE, RHSE, AE, 1, PNEWDT)
         DO I = 1, 8
            FINT(IDOF(I)) = FINT(IDOF(I)) - RHSE(I)
            DO J = 1, 8
               XK(IDOF(I),IDOF(J)) = XK(IDOF(I),IDOF(J)) + AE(I,J)
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE SOLVE(A, B, N, LDA)
!     Gaussian elimination with partial pivoting, solution in B
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(LDA,*), B(*)
      DO K = 1, N
         IP = K
         DO I = K+1, N
            IF (ABS(A(I,K)) .GT. ABS(A(IP,K))) IP = I
         ENDDO
         IF (IP .NE. K) THEN
            DO J = 1, N
               T = A(K,J)
               A(K,J) = A(IP,J)
               A(IP,J) = T
            ENDDO
            T = B(K)
            B(K) = B(IP)
            B(IP) = T
         ENDIF
         DO I = K+1, N
            F = A(I,K)/A(K,K)
            IF (F .NE. 0.0D0) THEN
               A(I,K+1:N) = A(I,K+1:N) - F*A(K,K+1:N)
               B(I) = B(I) - F*B(K)
            ENDIF
         ENDDO
      ENDDO
      DO K = N, 1, -1
         B(K) = (B(K) - DOT_PRODUCT(A(K,K+1:N), B(K+1:N)))/A(K,K)
      ENDDO
      RETURN
      END
!
      SUBROUTINE INCSTEP(U, FEXT, UPT, IFIX, N, FSC, TOL, RES, NIT)
!     one load increment: Newton iteration from the converged state
!     U on entry: converged displacements; on exit: new ones.
!     RES(0:NIT): residual norm / FSC at each iteration (NIT < 0: fail)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64)
      COMMON /STAT/ SVC(NSV,NMAXE), SVN(NSV,NMAXE)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      DIMENSION U(N), FEXT(N), UPT(N), IFIX(N), RES(0:60)
      DIMENSION US(N), FINT(N), XK(N,N), R(N), KF(N), XR(N,N)
      US = U
      DO I = 1, N
         IF (IFIX(I) .EQ. 1) U(I) = UPT(I)
      ENDDO
      NF = 0
      DO I = 1, N
         IF (IFIX(I) .EQ. 0) THEN
            NF = NF + 1
            KF(NF) = I
         ENDIF
      ENDDO
      NIT = -1
      DO IT = 0, 60
         CALL ASSEMB(U, US, FINT, XK, N)
         R = FEXT - FINT
         RN = 0.0D0
         DO I = 1, NF
            RN = RN + R(KF(I))**2
         ENDDO
         RES(IT) = SQRT(RN)/FSC
         IF (RES(IT) .LT. TOL) THEN
            NIT = IT
            SVC(:,1:NE) = SVN(:,1:NE)
            CALL K12_COMMIT
            RETURN
         ENDIF
         DO J = 1, NF
            DO I = 1, NF
               XR(I,J) = XK(KF(I),KF(J))
            ENDDO
         ENDDO
         DO I = 1, NF
            R(I) = R(KF(I))
         ENDDO
         CALL SOLVE(XR, R, NF, N)
         DO I = 1, NF
            U(KF(I)) = U(KF(I)) + R(I)
         ENDDO
      ENDDO
      U = US
      RETURN
      END
!
      SUBROUTINE UMATPT(NT, SIGN, SV, DE, SIG, D)
!     the Volume I UMAT at one point (3D classes, NT = 4 or 6)
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K12CFG/ PR(6), NTENS
      DIMENSION SIGN(NT), SV(NT+1), DE(NT), SIG(NT), D(NT,NT)
      DIMENSION PROPS(8), STRAN(6), TIME(2), PREDEF(1), DPRED(1),
     1 COORDS(3), DROT(3,3), DFGRD0(3,3), DFGRD1(3,3), DDSDDT(6),
     2 DRPLDE(6), JSTEP(4)
      CHARACTER*80 CMNAME
      PROPS(1:6) = PR
      PROPS(7) = 0.0D0
      PROPS(8) = 0.0D0
      SIG = SIGN
      SSE = 0.0D0
      SPD = 0.0D0
      SCD = 0.0D0
      RPL = 0.0D0
      DRPLDT = 0.0D0
      PNEWDT = 1.0D0
      CALL UMAT(SIG, SV, D, SSE, SPD, SCD, RPL, DDSDDT, DRPLDE,
     1 DRPLDT, STRAN, DE, TIME, 0.0D0, 0.0D0, 0.0D0, PREDEF, DPRED,
     2 CMNAME, 3, NT-3, NT, NT+1, PROPS, 8, COORDS, DROT, PNEWDT,
     3 0.0D0, DFGRD0, DFGRD1, 1, 1, 1, 1, JSTEP, 1)
      RETURN
      END
!
      SUBROUTINE T1POINT
      INCLUDE 'ABA_PARAM.INC'
      DOUBLE PRECISION K12_PEEQ
      DIMENSION STRESS(3), DD(3,3), DSTRAN(3), STRAN(3), DFG(3,3),
     1 PRE(1), DPR(1), CO(3)
      DO IV = 1, 2
         DO NT = 4, 6, 2
            CALL T1RUN(IV, NT)
         ENDDO
      ENDDO
!     plane stress, equibiaxial strain to 0.01 in ten steps
      CALL K12_SETMAT(210000.D0, 0.3D0, 250.D0, 1000.D0, 0.D0, 0.D0,
     1                3)
      DFG = 0.0D0
      DO K = 1, 10
         DSTRAN(1) = 1.0D-3
         DSTRAN(2) = 1.0D-3
         DSTRAN(3) = 0.0D0
         CALL MATERIAL_LIB_MECH(1, STRESS, DD, STRAN, DSTRAN, 1, 1.D0,
     1        1.D0, DFG, PRE, DPR, 0, 1.D0, CO)
         CALL K12_COMMIT
      ENDDO
      WRITE(20,'(A,1P,4E16.8)') 'T1PS', STRESS(1), STRESS(2), STRESS(3),
     1      K12_PEEQ(1,1)
      DSTRAN(1) = 1.0D-4
      DSTRAN(2) = 1.0D-4
      DSTRAN(3) = 0.0D0
      CALL MATERIAL_LIB_MECH(1, STRESS, DD, STRAN, DSTRAN, 1, 1.D0,
     1     1.D0, DFG, PRE, DPR, 0, 1.D0, CO)
      WRITE(20,'(A,1P,4E16.8)') 'T1D', DD(1,1), DD(1,2), DD(2,2),
     1      DD(3,3)
      RETURN
      END
!
      SUBROUTINE T1RUN(IV, NT)
!     stub library against the Volume I UMAT, strain-driven path
      INCLUDE 'ABA_PARAM.INC'
      DOUBLE PRECISION K12_PEEQ
      DIMENSION DE(NT), SG(NT), SV(NT+1), SIG(NT), D(NT,NT),
     1 STRESS(NT), DD(NT,NT), STRAN(NT), DSTRAN(NT), DFG(3,3),
     2 PRE(1), DPR(1), CO(3), DEP(NT), FD(NT,NT), SIGP(NT), SIGM(NT),
     3 DDX(NT,NT)
      IF (IV .EQ. 1) CALL K12_SETMAT(210000.D0, 0.3D0, 250.D0,
     1                1000.D0, 0.D0, 0.D0, NT)
      IF (IV .EQ. 2) CALL K12_SETMAT(210000.D0, 0.3D0, 250.D0,
     1                1000.D0, 150.D0, 30.D0, NT)
      SG = 0.0D0
      SV = 0.0D0
      STRAN = 0.0D0
      DFG = 0.0D0
      CO = 0.0D0
      DMAXS = 0.0D0
      DMAXD = 0.0D0
      DMAXT = 0.0D0
      DO K = 1, 40
         DE = 0.0D0
         DO I = 1, 3
            DE(I) = 1.5D-3*SIN(0.37D0*K + 0.9D0*I)
         ENDDO
         DO I = 4, NT
            DE(I) = 2.5D-3*COS(0.23D0*K + 0.7D0*I)
         ENDDO
         IF (NT .EQ. 4) DE(3) = 0.0D0
         CALL UMATPT(NT, SG, SV, DE, SIG, D)
         DSTRAN = DE
!        tangent by central differences of the stub (history fixed)
         DO J = 1, NT
            DEP = DSTRAN
            DEP(J) = DEP(J) + 1.0D-7
            CALL MATERIAL_LIB_MECH(1, SIGP, DDX, STRAN, DEP, 1, 1.D0,
     1           1.D0, DFG, PRE, DPR, 0, 1.D0, CO)
            DEP(J) = DEP(J) - 2.0D-7
            CALL MATERIAL_LIB_MECH(1, SIGM, DDX, STRAN, DEP, 1, 1.D0,
     1           1.D0, DFG, PRE, DPR, 0, 1.D0, CO)
            FD(:,J) = (SIGP - SIGM)/2.0D-7
         ENDDO
         CALL MATERIAL_LIB_MECH(1, STRESS, DD, STRAN, DSTRAN, 1,
     1        1.D0, 1.D0, DFG, PRE, DPR, 0, 1.D0, CO)
         DMAXS = MAX(DMAXS, MAXVAL(ABS(STRESS - SIG)))
         DMAXD = MAX(DMAXD, MAXVAL(ABS(DD - D))/MAXVAL(ABS(D)))
         DMAXT = MAX(DMAXT, MAXVAL(ABS(DD - FD))/MAXVAL(ABS(DD)))
         SG = SIG
         CALL K12_COMMIT
         DPE = ABS(K12_PEEQ(1,1) - SV(1))
      ENDDO
      WRITE(20,'(A,2I3,1P,5E13.5)') 'T1', IV, NT, DMAXS, DMAXD, DPE,
     1      DMAXT, SV(1)
      RETURN
      END
!
      SUBROUTINE SETUP1(X1, X2, X3, X4)
!     mesh of one quadrilateral element (nodes counter-clockwise)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      COMMON /STAT/ SVC(NSV,NMAXE), SVN(NSV,NMAXE)
      DIMENSION X1(2), X2(2), X3(2), X4(2)
      NN = 4
      NE = 1
      X(:,1) = X1
      X(:,2) = X2
      X(:,3) = X3
      X(:,4) = X4
      ICON(:,1) = (/1, 2, 3, 4/)
      SVC = 0.0D0
      SVN = 0.0D0
      RETURN
      END
!
      SUBROUTINE T2ONE
!     one plane stress element: uniaxial stress and equibiaxial strain
      INCLUDE 'ABA_PARAM.INC'
      DOUBLE PRECISION K12_PEEQ
      COMMON /CFG/ THK, ITWIN, NTS, IBB
      DIMENSION U(8), FEXT(8), UPT(8), IFIX(8), RES(0:60), FINT(8),
     1 XK(8,8), US(8)
      ITWIN = 0
      NTS = 3
      IBB = 0
      THK = 2.0D0
      DO IC = 1, 2
         CALL K12_SETMAT(210000.D0, 0.3D0, 250.D0, 1000.D0, 0.D0,
     1                   0.D0, 3)
         CALL SETUP1((/0.D0,0.D0/), (/10.D0,0.D0/), (/10.D0,5.D0/),
     1               (/0.D0,5.D0/))
         U = 0.0D0
         FEXT = 0.0D0
         IFIX = 0
         IFIX(1) = 1
         IFIX(2) = 1
         IFIX(4) = 1
         IFIX(7) = 1
         IFIX(3) = 1
         IFIX(5) = 1
         IF (IC .EQ. 2) THEN
            IFIX(6) = 1
            IFIX(8) = 1
         ENDIF
         NST = 5
         IF (IC .EQ. 2) NST = 4
         DO K = 1, NST
            EPS = 0.01D0*K
            IF (IC .EQ. 2) EPS = 0.0025D0*K
            UPT = 0.0D0
            UPT(3) = 10.0D0*EPS
            UPT(5) = 10.0D0*EPS
            UPT(6) = 5.0D0*EPS
            UPT(8) = 5.0D0*EPS
            CALL INCSTEP(U, FEXT, UPT, IFIX, 8, 2500.D0, 1.0D-10, RES,
     1                   NIT)
            US = U
            CALL ASSEMB(U, US, FINT, XK, 8)
            SX = (FINT(3) + FINT(5))/10.0D0
            SY = (FINT(6) + FINT(8))/20.0D0
            WRITE(20,'(A,2I3,1P,7E16.8)') 'T2', IC, NIT, EPS, SX,
     1         SY, K12_PEEQ(1,1), U(6)/5.0D0, RES(0), RES(1)
            WRITE(20,'(A,2I3,1P,8E11.3)') 'T2R', IC, K, (RES(J), J=0,
     1         MIN(NIT,7))
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE FIELD(IK, XN, YN, EPS, DU)
!     nodal displacement increments of three smooth test fields
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XN(4), YN(4), DU(8)
      DO I = 1, 4
         X = XN(I)
         Y = YN(I)
         IF (IK .EQ. 1) THEN
            DU(2*I-1) = EPS*(0.6D0*X + 0.2D0*Y + 0.1D0*X*Y)
            DU(2*I) = EPS*(-0.3D0*X + 0.5D0*Y - 0.1D0*X*X)
         ELSEIF (IK .EQ. 2) THEN
            DU(2*I-1) = EPS*(-0.5D0*X + 0.4D0*Y)
            DU(2*I) = EPS*(0.3D0*X + 0.6D0*Y + 0.1D0*X*Y)
         ELSE
            DU(2*I-1) = EPS*(0.2D0*X - 0.3D0*Y + 0.05D0*Y*Y)
            DU(2*I) = EPS*(0.4D0*X + 0.1D0*Y)
         ENDIF
      ENDDO
      RETURN
      END
!
      SUBROUTINE RUNSEQ(ITW, IBBR, RHS3, AE3, ERRFD, AEV, AEP)
!     two plastic increments, then RHS and AMATRX of a third one
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      COMMON /STAT/ SVC(NSV,NMAXE), SVN(NSV,NMAXE)
      COMMON /CFG/ THK, ITWIN, NTS, IBB
      DIMENSION RHS3(8), AE3(8,8), AEV(8,8), AEP(8,8)
      DIMENSION XN(4), YN(4), DU1(8), DU2(8), DU3(8), UE(8), RHSE(8),
     1 AE(8,8), RP(8), RM(8), AFD(8,8), UT(8), DT(8), Z(8)
      ITWIN = ITW
      IBB = IBBR
      NTS = 4
      THK = 1.5D0
      CALL K12_SETMAT(210000.D0, 0.3D0, 250.D0, 1000.D0, 150.D0,
     1                30.D0, 4)
      CALL SETUP1((/0.D0,0.D0/), (/2.2D0,0.1D0/), (/2.0D0,1.6D0/),
     1            (/-0.1D0,1.4D0/))
      XN = X(1,1:4)
      YN = X(2,1:4)
      Z = 0.0D0
!     elastic tangent of the virgin element
      CALL ELCALL(1, Z, Z, RHSE, AEV, 1, PNEWDT)
      CALL FIELD(1, XN, YN, 3.0D-3, DU1)
      CALL FIELD(2, XN, YN, 2.0D-3, DU2)
      CALL FIELD(3, XN, YN, 1.0D-3, DU3)
      UE = 0.0D0
      CALL ELCALL(1, DU1, DU1, RHSE, AE, 1, PNEWDT)
      SVC = SVN
      CALL K12_COMMIT
      UE = DU1
      CALL ELCALL(1, UE + DU2, DU2, RHSE, AE, 1, PNEWDT)
      SVC = SVN
      CALL K12_COMMIT
      UE = UE + DU2
!     third increment: residual, tangent, finite differences
      CALL ELCALL(1, UE + DU3, DU3, RHS3, AE3, 1, PNEWDT)
      AEP = AE3
      H = 1.0D-7
      DO J = 1, 8
         UT = UE + DU3
         DT = DU3
         UT(J) = UT(J) + H
         DT(J) = DT(J) + H
         CALL ELCALL(1, UT, DT, RP, AE, 1, PNEWDT)
         UT(J) = UT(J) - 2.0D0*H
         DT(J) = DT(J) - 2.0D0*H
         CALL ELCALL(1, UT, DT, RM, AE, 1, PNEWDT)
         AFD(:,J) = -(RP - RM)/(2.0D0*H)
      ENDDO
      ERRFD = MAXVAL(ABS(AFD - AE3))/MAXVAL(ABS(AE3))
      RETURN
      END
!
      SUBROUTINE T3ELEM
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      COMMON /CFG/ THK, ITWIN, NTS, IBB
      DIMENSION RA(8), AA(8,8), RB(8), AB(8,8), AEV(8,8), AEP(8,8),
     1 AEV2(8,8), AEP2(8,8), Z(8), UR(8), RHSE(8), AE(8,8)
      DO IBBR = 0, 1
         CALL RUNSEQ(0, IBBR, RA, AA, ERRA, AEV, AEP)
         CALL RUNSEQ(1, IBBR, RB, AB, ERRB, AEV2, AEP2)
         WRITE(20,'(A,I2,1P,6E13.4)') 'T3', IBBR, ERRA, ERRB,
     1     MAXVAL(ABS(RA - RB))/MAXVAL(ABS(RA)),
     2     MAXVAL(ABS(AA - AB))/MAXVAL(ABS(AA)),
     3     MAXVAL(ABS(AEV - AEV2))/MAXVAL(ABS(AEV)),
     4     MAXVAL(ABS(AA - TRANSPOSE(AA)))/MAXVAL(ABS(AA))
         DO I = 1, 8
            WRITE(20,'(A,2I2,1P,8E16.8)') 'KV', IBBR, I, AEV(I,:)
         ENDDO
         DO I = 1, 8
            WRITE(20,'(A,2I2,1P,8E16.8)') 'KP', IBBR, I, AEP(I,:)
         ENDDO
!        rigid-body motion: translation and rotation of 1e-3 rad
         ITWIN = 0
         IBB = IBBR
         CALL K12_SETMAT(210000.D0, 0.3D0, 250.D0, 1000.D0, 150.D0,
     1                   30.D0, 4)
         DO I = 1, 4
            UR(2*I-1) = 2.0D-3 - 1.0D-3*X(2,I)
            UR(2*I) = -1.0D-3 + 1.0D-3*X(1,I)
         ENDDO
         CALL ELCALL(1, UR, UR, RHSE, AE, 1, PNEWDT)
         WRITE(20,'(A,I2,1P,2E13.4)') 'T3RB', IBBR,
     1     MAXVAL(ABS(RHSE)), MAXVAL(ABS(MATMUL(AEV, UR)))
      ENDDO
      RETURN
      END
!
      SUBROUTINE BUILDCYL(NR, NTH, F1, IFIX, N)
!     quarter of a thick-walled cylinder, a = 50 mm, b = 100 mm;
!     F1: nodal forces for unit internal pressure (plane strain, t = 1)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      COMMON /STAT/ SVC(NSV,NMAXE), SVN(NSV,NMAXE)
      DIMENSION F1(*), IFIX(*)
      PI = 4.0D0*ATAN(1.0D0)
      NN = (NR+1)*(NTH+1)
      NE = NR*NTH
      N = 2*NN
      DO J = 0, NTH
         DO I = 0, NR
            R = 50.0D0 + 50.0D0*I/NR
            T = 0.5D0*PI*J/NTH
            X(1,J*(NR+1)+I+1) = R*COS(T)
            X(2,J*(NR+1)+I+1) = R*SIN(T)
         ENDDO
      ENDDO
      IE = 0
      DO J = 0, NTH-1
         DO I = 0, NR-1
            IE = IE + 1
            ICON(1,IE) = J*(NR+1) + I + 1
            ICON(2,IE) = J*(NR+1) + I + 2
            ICON(3,IE) = (J+1)*(NR+1) + I + 2
            ICON(4,IE) = (J+1)*(NR+1) + I + 1
         ENDDO
      ENDDO
      IFIX(1:N) = 0
      F1(1:N) = 0.0D0
      DO I = 0, NR
         IFIX(2*(I+1)) = 1
         IFIX(2*(NTH*(NR+1)+I+1)-1) = 1
      ENDDO
      DO J = 0, NTH-1
         N1 = J*(NR+1) + 1
         N2 = (J+1)*(NR+1) + 1
         TX = X(1,N2) - X(1,N1)
         TY = X(2,N2) - X(2,N1)
         XL = SQRT(TX*TX + TY*TY)
         XNX = TY/XL
         XNY = -TX/XL
         IF (XNX*X(1,N1) + XNY*X(2,N1) .LT. 0.0D0) THEN
            XNX = -XNX
            XNY = -XNY
         ENDIF
         F1(2*N1-1) = F1(2*N1-1) + 0.5D0*XL*XNX
         F1(2*N1) = F1(2*N1) + 0.5D0*XL*XNY
         F1(2*N2-1) = F1(2*N2-1) + 0.5D0*XL*XNX
         F1(2*N2) = F1(2*N2) + 0.5D0*XL*XNY
      ENDDO
      SVC = 0.0D0
      SVN = 0.0D0
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION GPPEEQ(IE, K)
      INCLUDE 'ABA_PARAM.INC'
      DOUBLE PRECISION K12_PEEQ
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64)
      COMMON /STAT/ SVC(NSV,NMAXE), SVN(NSV,NMAXE)
      COMMON /CFG/ THK, ITWIN, NTS, IBB
      IF (ITWIN .EQ. 1) THEN
         GPPEEQ = SVC((K-1)*13 + 9, IE)
      ELSE
         GPPEEQ = K12_PEEQ(IE, K)
      ENDIF
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION GPMISES(IE, K)
!     von Mises stress at point K of element IE (committed state)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64, MAXH = 512,
     1 MAXP = 8)
      COMMON /STAT/ SVC(NSV,NMAXE), SVN(NSV,NMAXE)
      COMMON /CFG/ THK, ITWIN, NTS, IBB
      COMMON /K12CFG/ PR(6), NTENS
      COMMON /K12ST/ SIGC(6,MAXP,MAXH), EPC(6,MAXP,MAXH),
     1 PEEQC(MAXP,MAXH), SIGT(6,MAXP,MAXH), EPT(6,MAXP,MAXH),
     2 PEEQT(MAXP,MAXH)
      DIMENSION S(4)
      IF (ITWIN .EQ. 1) THEN
         S = SVC((K-1)*13+5:(K-1)*13+8, IE)
      ELSE
         S = SIGC(1:4,K,IE)
      ENDIF
      P = (S(1) + S(2) + S(3))/3.0D0
      GPMISES = SQRT(1.5D0*((S(1)-P)**2 + (S(2)-P)**2 + (S(3)-P)**2 +
     1          2.0D0*S(4)**2))
      RETURN
      END
!
      SUBROUTINE T4CYL
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300, NSV = 64)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      COMMON /STAT/ SVC(NSV,NMAXE), SVN(NSV,NMAXE)
      COMMON /CFG/ THK, ITWIN, NTS, IBB
      PARAMETER (NMAXD = 800)
      DIMENSION F1(NMAXD), IFIX(NMAXD), U(NMAXD), UPT(NMAXD),
     1 FEXT(NMAXD), RES(0:60), PL(6), PLX(15), SH(4), UKEEP(NMAXD,2),
     2 XL(8), GX(2)
      DATA PL /10.D0, 60.D0, 100.D0, 125.D0, 150.D0, 175.D0/
      DATA PLX /10.D0, 60.D0, 100.D0, 110.D0, 120.D0, 130.D0, 140.D0,
     1 150.D0, 160.D0, 170.D0, 175.D0, 180.D0, 185.D0, 190.D0, 195.D0/
      DO ICASE = 1, 9
         IF (ICASE .EQ. 1) THEN
            NR = 16; NTH = 8; IBB = 1; ITWIN = 0
         ELSEIF (ICASE .EQ. 2) THEN
            NR = 16; NTH = 8; IBB = 1; ITWIN = 1
         ELSEIF (ICASE .EQ. 3) THEN
            NR = 16; NTH = 8; IBB = 0; ITWIN = 0
         ELSEIF (ICASE .EQ. 4) THEN
            NR = 8; NTH = 4; IBB = 1; ITWIN = 0
         ELSEIF (ICASE .EQ. 5) THEN
            NR = 4; NTH = 2; IBB = 1; ITWIN = 0
         ELSEIF (ICASE .EQ. 6) THEN
            NR = 16; NTH = 8; IBB = 0; ITWIN = 1
         ELSEIF (ICASE .EQ. 7) THEN
            NR = 8; NTH = 4; IBB = 0; ITWIN = 0
         ELSEIF (ICASE .EQ. 8) THEN
            NR = 4; NTH = 2; IBB = 0; ITWIN = 0
         ELSE
            NR = 16; NTH = 8; IBB = 1; ITWIN = 0
         ENDIF
         NS = 6
         IF (ICASE .EQ. 9) NS = 15
         NTS = 4
         THK = 1.0D0
         CALL K12_SETMAT(210000.D0, 0.3D0, 250.D0, 1000.D0, 0.D0,
     1                   0.D0, 4)
         CALL BUILDCYL(NR, NTH, F1, IFIX, N)
         U(1:N) = 0.0D0
         UPT(1:N) = 0.0D0
         DO ISTEP = 1, NS
            P = PL(ISTEP)
            IF (ICASE .EQ. 9) P = PLX(ISTEP)
            FEXT(1:N) = P*F1(1:N)
            FSC = SQRT(SUM(FEXT(1:N)**2))
            CALL INCSTEP(U, FEXT, UPT, IFIX, N, FSC, 1.0D-8, RES, NIT)
            WRITE(20,'(A,I2,F8.1,I4,1P,12E11.3)') 'CI', ICASE, P, NIT,
     1         (RES(K), K=0, MIN(NIT,11))
            IF (ISTEP .EQ. 1) THEN
!              first-yield pressure from the elastic solution at 10 MPa
               QM = 0.0D0
               DO IE = 1, NE
                  DO K = 1, 4
                     QM = MAX(QM, GPMISES(IE, K))
                  ENDDO
               ENDDO
               WRITE(20,'(A,I2,1P,2E16.8)') 'PY', ICASE, QM,
     1            250.0D0*10.0D0/QM
            ENDIF
            IF (ABS(P - 150.0D0) .LT. 1.0D-9) THEN
!              plastic radius: largest radius of a plastic Gauss point
               C = 0.0D0
               NPL = 0
               DO IE = 1, NE
                  DO K = 1, 4
                     IF (GPPEEQ(IE, K) .GT. 1.0D-10) THEN
                        NPL = NPL + 1
                        CALL GPXY(IE, K, GX)
                        C = MAX(C, SQRT(GX(1)**2 + GX(2)**2))
                     ENDIF
                  ENDDO
               ENDDO
               PM = 0.0D0
               DO IE = 1, NE
                  DO K = 1, 4
                     PM = MAX(PM, GPPEEQ(IE, K))
                  ENDDO
               ENDDO
               WRITE(20,'(A,I2,1P,4E16.8,I6)') 'C150', ICASE, C, U(1),
     1            PM, 0.0D0, NPL
               UKEEP(1:N,1) = U(1:N)
               IF (ICASE .EQ. 1) THEN
                  OPEN(21, FILE='../out/cyl_state.txt')
                  WRITE(21,*) NR, NTH
                  DO IE = 1, NE
                     DO K = 1, 4
                        CALL GPXY(IE, K, GX)
                        WRITE(21,'(2F12.5,1P,E14.6)') GX(1), GX(2),
     1                     GPPEEQ(IE, K)
                     ENDDO
                  ENDDO
                  CLOSE(21)
               ENDIF
            ENDIF
            IF (ICASE .EQ. 9) THEN
               C = 0.0D0
               DO IE = 1, NE
                  DO K = 1, 4
                     IF (GPPEEQ(IE, K) .GT. 1.0D-10) THEN
                        CALL GPXY(IE, K, GX)
                        C = MAX(C, SQRT(GX(1)**2 + GX(2)**2))
                     ENDIF
                  ENDDO
               ENDDO
               WRITE(20,'(A,F8.1,I4,1P,2E16.8)') 'CP', P, NIT, C, U(1)
            ENDIF
         ENDDO
         IF (ICASE .EQ. 1) UKEEP(1:N,2) = U(1:N)
         IF (ICASE .EQ. 1) USAVE1 = MAXVAL(ABS(U(1:N)))
         IF (ICASE .EQ. 1) THEN
            OPEN(22, FILE='../out/u_case1.txt')
            WRITE(22,'(1P,E22.14)') U(1:N)
            CLOSE(22)
         ENDIF
         IF (ICASE .EQ. 2 .OR. ICASE .EQ. 6) THEN
            OPEN(23, FILE='../out/u_case1.txt')
            DO I = 1, N
               READ(23,*) UU
               UKEEP(I,1) = UU
            ENDDO
            CLOSE(23)
            IF (ICASE .EQ. 6) THEN
               OPEN(23, FILE='../out/u_case3.txt')
               DO I = 1, N
                  READ(23,*) UKEEP(I,1)
               ENDDO
               CLOSE(23)
            ENDIF
            WRITE(20,'(A,I2,1P,2E16.8)') 'UD', ICASE,
     1         MAXVAL(ABS(U(1:N) - UKEEP(1:N,1))), MAXVAL(ABS(U(1:N)))
         ENDIF
         IF (ICASE .EQ. 3) THEN
            OPEN(22, FILE='../out/u_case3.txt')
            WRITE(22,'(1P,E22.14)') U(1:N)
            CLOSE(22)
         ENDIF
      ENDDO
      RETURN
      END
!
      SUBROUTINE GPXY(IE, K, GX)
!     global coordinates of Gauss point K of element IE
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (NMAXN = 400, NMAXE = 300)
      COMMON /MESH/ X(2,NMAXN), ICON(4,NMAXE), NN, NE
      DIMENSION GX(2), SH(4), DN(2,4), IGX(4), IGY(4)
      DATA IGX /1, 2, 2, 1/
      DATA IGY /1, 1, 2, 2/
      G = 1.0D0/SQRT(3.0D0)
      XI = G*(2*IGX(K) - 3)
      ET = G*(2*IGY(K) - 3)
      CALL K12_SHP(XI, ET, SH, DN)
      GX = 0.0D0
      DO I = 1, 4
         GX = GX + SH(I)*X(:,ICON(I,IE))
      ENDDO
      RETURN
      END
