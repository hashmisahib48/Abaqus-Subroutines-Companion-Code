      SUBROUTINE K12_QUAD4(NTENS, IBBAR, THK, X, U, DU, SVARS,
     1 NSVARS, RHS, AMATRX, PNEWDT, NPREDF, PREDEF, MATERIALLIB)
!     element residual RHS = -(internal force) and tangent AMATRX
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), U(8), DU(8), SVARS(NSVARS), RHS(8),
     1 AMATRX(8,8), PREDEF(2,NPREDF,4)
      DIMENSION B(NTENS,8,4), DNX(2,4,4), SH(4,4), DV(4), BV(8),
     1 DN(2,4), STRESS(NTENS), DDSDDE(NTENS,NTENS), STRAN(NTENS),
     2 DSTRAN(NTENS), DFGRD(3,3), PREDL(4), DPREDL(4), XIP(3),
     3 FINT(8), GP(2), IGX(4), IGY(4)
      DATA IGX /1, 2, 2, 1/
      DATA IGY /1, 1, 2, 2/
      NSVINT = NTENS
      GP(1) = -1.0D0/SQRT(3.0D0)
      GP(2) = -GP(1)
      IF (NSVARS .LT. 4*NSVINT) THEN
         WRITE(7,*) 'K12_QUAD4: VARIABLES must be at least 4*NTENS'
         CALL XIT
      ENDIF
!     pass 1: geometry, B matrices, element mean of the dilatation
      B = 0.0D0
      BV = 0.0D0
      AREA = 0.0D0
      DO K = 1, 4
         CALL K12_SHP(GP(IGX(K)), GP(IGY(K)), SH(1,K), DN)
         XJ11 = 0.0D0
         XJ12 = 0.0D0
         XJ21 = 0.0D0
         XJ22 = 0.0D0
         DO IA = 1, 4
            XJ11 = XJ11 + DN(1,IA)*X(1,IA)
            XJ12 = XJ12 + DN(1,IA)*X(2,IA)
            XJ21 = XJ21 + DN(2,IA)*X(1,IA)
            XJ22 = XJ22 + DN(2,IA)*X(2,IA)
         ENDDO
         DET = XJ11*XJ22 - XJ12*XJ21
         IF (DET .LE. 0.0D0) THEN
            PNEWDT = 0.25D0
            WRITE(7,*) 'K12_QUAD4: non-positive Jacobian'
            RETURN
         ENDIF
         DV(K) = DET*THK
         AREA = AREA + DET
         DO IA = 1, 4
            DNX(1,IA,K) = ( XJ22*DN(1,IA) - XJ12*DN(2,IA))/DET
            DNX(2,IA,K) = (-XJ21*DN(1,IA) + XJ11*DN(2,IA))/DET
            B(1,2*IA-1,K) = DNX(1,IA,K)
            B(2,2*IA,K) = DNX(2,IA,K)
            B(NTENS,2*IA-1,K) = 0.5D0*DNX(2,IA,K)
            B(NTENS,2*IA,K) = 0.5D0*DNX(1,IA,K)
            BV(2*IA-1) = BV(2*IA-1) + DV(K)*DNX(1,IA,K)
            BV(2*IA) = BV(2*IA) + DV(K)*DNX(2,IA,K)
         ENDDO
      ENDDO
      BV = BV/SUM(DV)
      IF (IBBAR .EQ. 1 .AND. NTENS .EQ. 4) THEN
         DO K = 1, 4
            DO IA = 1, 4
               DXB = 0.5D0*(BV(2*IA-1) - DNX(1,IA,K))
               DYB = 0.5D0*(BV(2*IA) - DNX(2,IA,K))
               B(1,2*IA-1,K) = B(1,2*IA-1,K) + DXB
               B(1,2*IA,K) = B(1,2*IA,K) + DYB
               B(2,2*IA-1,K) = B(2,2*IA-1,K) + DXB
               B(2,2*IA,K) = B(2,2*IA,K) + DYB
            ENDDO
         ENDDO
      ENDIF
      CELENT = SQRT(AREA)
!     pass 2: material call at each integration point
      FINT = 0.0D0
      DO K = 1, 4
         ISV = (K-1)*NSVINT
         DSTRAN = MATMUL(B(:,:,K), U)
         DO I = 1, NTENS
            STRAN(I) = SVARS(ISV+I)
         ENDDO
         DFGRD = 0.0D0
         DFGRD(1,1) = 1.0D0
         DFGRD(2,2) = 1.0D0
         DFGRD(3,3) = 1.0D0
         XIP = 0.0D0
         DO IA = 1, 4
            DO I = 1, 2
               XIP(I) = XIP(I) + SH(IA,K)*X(I,IA)
               DO J = 1, 2
                  DFGRD(I,J) = DFGRD(I,J) + DNX(J,IA,K)*U(2*IA-2+I)
               ENDDO
            ENDDO
         ENDDO
         PREDL = 0.0D0
         DPREDL = 0.0D0
         DO IP = 1, MIN(NPREDF, 4)
            DO IA = 1, 4
               PREDL(IP) = PREDL(IP) + SH(IA,K)*(PREDEF(1,IP,IA) -
     1                     PREDEF(2,IP,IA))
               DPREDL(IP) = DPREDL(IP) + SH(IA,K)*PREDEF(2,IP,IA)
            ENDDO
         ENDDO
         STRESS = 0.0D0
         DDSDDE = 0.0D0
         DVDV0 = 1.0D0
         CALL MATERIAL_LIB_MECH(MATERIALLIB, STRESS, DDSDDE, DSTRAN,
     1        STRAN, 1, DVDV0, DV(K), DFGRD, PREDL, DPREDL, NPREDF,
     2        CELENT, XIP)
         DO I = 1, NTENS
            SVARS(ISV+I) = STRAN(I) + DSTRAN(I)
         ENDDO
         FINT = FINT + MATMUL(TRANSPOSE(B(:,:,K)), STRESS)*DV(K)/THK
         AMATRX = AMATRX + MATMUL(TRANSPOSE(B(:,:,K)),
     1            MATMUL(DDSDDE, B(:,:,K)))*DV(K)
      ENDDO
      RHS = -FINT
      RETURN
      END
