      SUBROUTINE MATERIAL_LIB_MECH(MATERIALLIB,STRESS,DDSDDE,STRAN,
     1 DSTRAN,NPT,DVDV0,DVMAT,DFGRD,PREDEF,DPREDEF,NPREDF,CELENT,
     2 COORDS)
!
!     TEST STUB, NOT THE ABAQUS LIBRARY.  Same call sequence as the
!     documented utility routine; the material is J2 plasticity with
!     the yield stress SY0 + H*EP + Q*(1 - EXP(-B*EP)).
!     The stub keeps the history that the Abaqus library keeps
!     internally: committed (start of increment) and trial values for
!     each integration point NPT of the element MATERIALLIB (here an
!     element handle).  K12_COMMIT plays the role of Abaqus accepting
!     the converged increment.
!
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXH = 512, MAXP = 8)
      COMMON /K12CFG/ PR(6), NTENS
      COMMON /K12ST/ SIGC(6,MAXP,MAXH), EPC(6,MAXP,MAXH),
     1 PEEQC(MAXP,MAXH), SIGT(6,MAXP,MAXH), EPT(6,MAXP,MAXH),
     2 PEEQT(MAXP,MAXH)
      DIMENSION STRESS(*), DDSDDE(NTENS,*), STRAN(*), DSTRAN(*),
     1 DFGRD(3,3), PREDEF(*), DPREDEF(*), COORDS(3)
      DIMENSION DE(6), SIG(6), EP(6), D6(6,6), IX(6)
!
      KH = MATERIALLIB
      IF (KH .LT. 1 .OR. KH .GT. MAXH .OR. NPT .LT. 1 .OR.
     1    NPT .GT. MAXP) THEN
         WRITE(7,*) 'MATERIAL_LIB_MECH stub: bad handle or point'
         CALL XIT
      ENDIF
!     position of the NTENS components in the six-component vector
      DO I = 1, NTENS
         IX(I) = I
      ENDDO
      IF (NTENS .EQ. 3) IX(3) = 4
      DE = 0.0D0
      DO I = 1, NTENS
         DE(IX(I)) = DSTRAN(I)
      ENDDO
!     plane stress: iterate on the thickness strain until SIG(3) = 0
      DE33 = 0.0D0
      DO IT = 1, 25
         IF (NTENS .EQ. 3) DE(3) = DE33
         CALL K12_J2(PR, SIGC(1,NPT,KH), EPC(1,NPT,KH),
     1               PEEQC(NPT,KH), DE, SIG, EP, PEEQ, D6, IERR)
         IF (NTENS .NE. 3) EXIT
         IF (ABS(SIG(3)) .LE. 1.0D-10*PR(3)) EXIT
         DE33 = DE33 - SIG(3)/D6(3,3)
      ENDDO
      SIGT(:,NPT,KH) = SIG
      EPT(:,NPT,KH) = EP
      PEEQT(NPT,KH) = PEEQ
      DO I = 1, NTENS
         STRESS(I) = SIG(IX(I))
         DO J = 1, NTENS
            DDSDDE(I,J) = D6(IX(I),IX(J))
            IF (NTENS .EQ. 3) DDSDDE(I,J) = DDSDDE(I,J) -
     1         D6(IX(I),3)*D6(3,IX(J))/D6(3,3)
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K12_SETMAT(E, XNU, SY0, H, Q, B, NT)
!     test control: constants (MPa) and number of stress components;
!     clears the history of all elements
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXH = 512, MAXP = 8)
      COMMON /K12CFG/ PR(6), NTENS
      COMMON /K12ST/ SIGC(6,MAXP,MAXH), EPC(6,MAXP,MAXH),
     1 PEEQC(MAXP,MAXH), SIGT(6,MAXP,MAXH), EPT(6,MAXP,MAXH),
     2 PEEQT(MAXP,MAXH)
      PR(1) = E
      PR(2) = XNU
      PR(3) = SY0
      PR(4) = H
      PR(5) = Q
      PR(6) = B
      NTENS = NT
      SIGC = 0.0D0
      EPC = 0.0D0
      PEEQC = 0.0D0
      SIGT = 0.0D0
      EPT = 0.0D0
      PEEQT = 0.0D0
      RETURN
      END
!
      SUBROUTINE K12_COMMIT
!     the increment has converged: trial values become the history
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXH = 512, MAXP = 8)
      COMMON /K12CFG/ PR(6), NTENS
      COMMON /K12ST/ SIGC(6,MAXP,MAXH), EPC(6,MAXP,MAXH),
     1 PEEQC(MAXP,MAXH), SIGT(6,MAXP,MAXH), EPT(6,MAXP,MAXH),
     2 PEEQT(MAXP,MAXH)
      SIGC = SIGT
      EPC = EPT
      PEEQC = PEEQT
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION K12_PEEQ(KH, NPT)
!     committed equivalent plastic strain (a test accessor)
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXH = 512, MAXP = 8)
      COMMON /K12CFG/ PR(6), NTENS
      COMMON /K12ST/ SIGC(6,MAXP,MAXH), EPC(6,MAXP,MAXH),
     1 PEEQC(MAXP,MAXH), SIGT(6,MAXP,MAXH), EPT(6,MAXP,MAXH),
     2 PEEQT(MAXP,MAXH)
      K12_PEEQ = PEEQC(NPT, KH)
      RETURN
      END
!
      SUBROUTINE K12_SY(PR, EP, SY, HP)
!     yield stress SY and slope HP = dSY/dEP (MPa) at PEEQ = EP
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PR(6)
      EX = EXP(-PR(6)*EP)
      SY = PR(3) + PR(4)*EP + PR(5)*(1.0D0 - EX)
      HP = PR(4) + PR(5)*PR(6)*EX
      RETURN
      END
!
      SUBROUTINE K12_J2(PR, SIGN, EPN, PEEQN, DE, SIG, EP, PEEQ, D,
     1                  IERR)
!     J2 return mapping for the six-component vector (11, 22, 33,
!     12, 13, 23; engineering shear strain) and its consistent tangent
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PR(6), SIGN(6), EPN(6), DE(6), SIG(6), EP(6), D(6,6),
     1 S(6), XN(6)
      G = PR(1)/(2.0D0*(1.0D0 + PR(2)))
      XK = PR(1)/(3.0D0*(1.0D0 - 2.0D0*PR(2)))
      D = 0.0D0
      DO J = 1, 3
         DO I = 1, 3
            D(I,J) = XK - 2.0D0*G/3.0D0
         ENDDO
         D(J,J) = D(J,J) + 2.0D0*G
         D(J+3,J+3) = G
      ENDDO
      SIG = SIGN + MATMUL(D, DE)
      EP = EPN
      PEEQ = PEEQN
      IERR = 0
      P = (SIG(1) + SIG(2) + SIG(3))/3.0D0
      S(1:3) = SIG(1:3) - P
      S(4:6) = SIG(4:6)
      SN2 = S(1)**2 + S(2)**2 + S(3)**2 + 2.0D0*(S(4)**2 + S(5)**2 +
     1      S(6)**2)
      Q = SQRT(1.5D0*SN2)
      CALL K12_SY(PR, PEEQN, SY, HP)
      IF (Q - SY .LE. 1.0D-10*PR(3)) RETURN
!     plastic: Newton iteration for DP,  Q - 3*G*DP = SY(PEEQN + DP)
      DP = (Q - SY)/(3.0D0*G + HP)
      DO IT = 1, 50
         CALL K12_SY(PR, PEEQN + DP, SYN, HPN)
         RES = Q - 3.0D0*G*DP - SYN
         IF (ABS(RES) .LE. 1.0D-12*PR(3)) EXIT
         DP = DP + RES/(3.0D0*G + HPN)
      ENDDO
      IF (IT .GT. 50) IERR = 1
      THETA = 1.0D0 - 3.0D0*G*DP/Q
      THBAR = 3.0D0*G/(3.0D0*G + HPN) - (1.0D0 - THETA)
      DO I = 1, 6
         XN(I) = S(I)/SQRT(SN2)
         IF (I .LE. 3) THEN
            SIG(I) = P + THETA*S(I)
            EP(I) = EPN(I) + 1.5D0*DP*S(I)/Q
         ELSE
            SIG(I) = THETA*S(I)
            EP(I) = EPN(I) + 3.0D0*DP*S(I)/Q
         ENDIF
      ENDDO
      PEEQ = PEEQN + DP
!     consistent tangent
      D = 0.0D0
      DO J = 1, 3
         DO I = 1, 3
            D(I,J) = XK - 2.0D0*THETA*G/3.0D0
         ENDDO
         D(J,J) = D(J,J) + 2.0D0*THETA*G
         D(J+3,J+3) = THETA*G
      ENDDO
      DO J = 1, 6
         DO I = 1, 6
            D(I,J) = D(I,J) - 2.0D0*G*THBAR*XN(I)*XN(J)
         ENDDO
      ENDDO
      RETURN
      END
