      SUBROUTINE UEL(RHS,AMATRX,SVARS,ENERGY,NDOFEL,NRHS,NSVARS,
     1 PROPS,NPROPS,COORDS,MCRD,NNODE,U,DU,V,A,JTYPE,TIME,DTIME,
     2 KSTEP,KINC,JELEM,PARAMS,NDLOAD,JDLTYP,ADLMAG,PREDEF,NPREDF,
     3 LFLAGS,MLVARX,DDLMAG,MDLOAD,PNEWDT,JPROPS,NJPROP,PERIOD)
!
      INCLUDE 'ABA_PARAM.INC'
!
      DIMENSION RHS(MLVARX,*),AMATRX(NDOFEL,NDOFEL),PROPS(*),
     1 SVARS(NSVARS),ENERGY(8),COORDS(MCRD,NNODE),U(NDOFEL),
     2 DU(MLVARX,*),V(NDOFEL),A(NDOFEL),TIME(2),PARAMS(*),
     3 JDLTYP(MDLOAD,*),ADLMAG(MDLOAD,*),DDLMAG(MDLOAD,*),
     4 PREDEF(2,NPREDF,NNODE),LFLAGS(*),JPROPS(*)
!
!     U1: 4-node plane element, 2 x 2 Gauss points, Abaqus material
!     PROPS(1)  thickness (mm), used for plane strain and plane stress
!     JPROPS(1) NTENS: 4 plane strain (TENSOR=PSTRAIN), 3 plane stress
!     JPROPS(2) 1 mean-dilatation (B-bar) strain, 0 standard
!     SVARS: total strain at the start of the increment, NTENS per point
!
      IF (NNODE .NE. 4 .OR. NDOFEL .NE. 8 .OR. MCRD .NE. 2 .OR.
     1    NJPROP .LT. 2 .OR. NPROPS .LT. 1) THEN
         WRITE(7,*) 'UEL U1: needs 4 nodes, 2 DOF, 1 prop, 2 jprops'
         CALL XIT
      ENDIF
!     mass matrix request (LFLAGS(3)=4): static element, identity
      IF (LFLAGS(3) .EQ. 4) THEN
         AMATRX = 0.0D0
         DO I = 1, NDOFEL
            AMATRX(I,I) = 1.0D0
         ENDDO
         RETURN
      ENDIF
      IF (LFLAGS(3) .EQ. 3 .OR. LFLAGS(3) .EQ. 100) THEN
         AMATRX = 0.0D0
         RETURN
      ENDIF
      IF (LFLAGS(1) .NE. 1 .OR. LFLAGS(2) .NE. 0 .OR. NDLOAD .GT. 0)
     1   THEN
         WRITE(7,*) 'UEL U1: static, small displacement, no DLOAD'
         CALL XIT
      ENDIF
      NTENS = JPROPS(1)
      CALL K12_QUAD4D(NTENS, JPROPS(2), PROPS(1), COORDS, U, DU(1,1),
     1               SVARS, NSVARS, RHS(1,1), AMATRX, PNEWDT, NPREDF,
     2               PREDEF)
      RETURN
      END
!
      SUBROUTINE K12_QUAD4D(NTENS, IBBAR, THK, X, U, DU, SVARS,
     1 NSVARS, RHS, AMATRX, PNEWDT, NPREDF, PREDEF)
!     element residual RHS = -(internal force) and tangent AMATRX
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), U(8), DU(8), SVARS(NSVARS), RHS(8),
     1 AMATRX(8,8), PREDEF(2,NPREDF,4)
      DIMENSION B(NTENS,8,4), DNX(2,4,4), SH(4,4), DV(4), BV(8),
     1 DN(2,4), STRESS(NTENS), DDSDDE(NTENS,NTENS), STRAN(NTENS),
     2 DSTRAN(NTENS), DFGRD(3,3), PREDL(4), DPREDL(4), XIP(3),
     3 FINT(8), GP(2), IGX(4), IGY(4)
      DATA IGX /1, 2, 2, 1/
      DATA IGY /1, 1, 2, 2/
      NSVINT = 3*NTENS + 1
      GP(1) = -1.0D0/SQRT(3.0D0)
      GP(2) = -GP(1)
      IF (NSVARS .LT. 4*NSVINT) THEN
         WRITE(7,*) 'K12_QUAD4: VARIABLES must be at least 4*NTENS'
         CALL XIT
      ENDIF
!     pass 1: geometry, B matrices, element mean of the dilatation
      B = 0.0D0
      BV = 0.0D0
      AREA = 0.0D0
      DO K = 1, 4
         CALL K12_SHP(GP(IGX(K)), GP(IGY(K)), SH(1,K), DN)
         XJ11 = 0.0D0
         XJ12 = 0.0D0
         XJ21 = 0.0D0
         XJ22 = 0.0D0
         DO IA = 1, 4
            XJ11 = XJ11 + DN(1,IA)*X(1,IA)
            XJ12 = XJ12 + DN(1,IA)*X(2,IA)
            XJ21 = XJ21 + DN(2,IA)*X(1,IA)
            XJ22 = XJ22 + DN(2,IA)*X(2,IA)
         ENDDO
         DET = XJ11*XJ22 - XJ12*XJ21
         IF (DET .LE. 0.0D0) THEN
            PNEWDT = 0.25D0
            WRITE(7,*) 'K12_QUAD4: non-positive Jacobian'
            RETURN
         ENDIF
         DV(K) = DET*THK
         AREA = AREA + DET
         DO IA = 1, 4
            DNX(1,IA,K) = ( XJ22*DN(1,IA) - XJ12*DN(2,IA))/DET
            DNX(2,IA,K) = (-XJ21*DN(1,IA) + XJ11*DN(2,IA))/DET
            B(1,2*IA-1,K) = DNX(1,IA,K)
            B(2,2*IA,K) = DNX(2,IA,K)
            B(NTENS,2*IA-1,K) = DNX(2,IA,K)
            B(NTENS,2*IA,K) = DNX(1,IA,K)
            BV(2*IA-1) = BV(2*IA-1) + DV(K)*DNX(1,IA,K)
            BV(2*IA) = BV(2*IA) + DV(K)*DNX(2,IA,K)
         ENDDO
      ENDDO
      BV = BV/SUM(DV)
      IF (IBBAR .EQ. 1 .AND. NTENS .EQ. 4) THEN
         DO K = 1, 4
            DO IA = 1, 4
               DXB = 0.5D0*(BV(2*IA-1) - DNX(1,IA,K))
               DYB = 0.5D0*(BV(2*IA) - DNX(2,IA,K))
               B(1,2*IA-1,K) = B(1,2*IA-1,K) + DXB
               B(1,2*IA,K) = B(1,2*IA,K) + DYB
               B(2,2*IA-1,K) = B(2,2*IA-1,K) + DXB
               B(2,2*IA,K) = B(2,2*IA,K) + DYB
            ENDDO
         ENDDO
      ENDIF
      CELENT = SQRT(AREA)
!     pass 2: material call at each integration point
      FINT = 0.0D0
      AMATRX = 0.0D0
      DO K = 1, 4
         ISV = (K-1)*NSVINT
         DSTRAN = MATMUL(B(:,:,K), DU)
         DO I = 1, NTENS
            STRAN(I) = SVARS(ISV+I)
         ENDDO
         DFGRD = 0.0D0
         DFGRD(1,1) = 1.0D0
         DFGRD(2,2) = 1.0D0
         DFGRD(3,3) = 1.0D0
         XIP = 0.0D0
         DO IA = 1, 4
            DO I = 1, 2
               XIP(I) = XIP(I) + SH(IA,K)*X(I,IA)
               DO J = 1, 2
                  DFGRD(I,J) = DFGRD(I,J) + DNX(J,IA,K)*U(2*IA-2+I)
               ENDDO
            ENDDO
         ENDDO
         PREDL = 0.0D0
         DPREDL = 0.0D0
         DO IP = 1, MIN(NPREDF, 4)
            DO IA = 1, 4
               PREDL(IP) = PREDL(IP) + SH(IA,K)*(PREDEF(1,IP,IA) -
     1                     PREDEF(2,IP,IA))
               DPREDL(IP) = DPREDL(IP) + SH(IA,K)*PREDEF(2,IP,IA)
            ENDDO
         ENDDO
         STRESS = 0.0D0
         DDSDDE = 0.0D0
         DVDV0 = 1.0D0
         CALL K12_DIRECT(NTENS, STRESS, DDSDDE, DSTRAN,
     1        SVARS(ISV+NTENS+1))
         DO I = 1, NTENS
            SVARS(ISV+I) = STRAN(I) + DSTRAN(I)
         ENDDO
         FINT = FINT + MATMUL(TRANSPOSE(B(:,:,K)), STRESS)*DV(K)
         AMATRX = AMATRX + MATMUL(TRANSPOSE(B(:,:,K)),
     1            MATMUL(DDSDDE, B(:,:,K)))*DV(K)
      ENDDO
      RHS = -FINT
      RETURN
      END
!
      SUBROUTINE K12_DIRECT(NTENS, STRESS, DDSDDE, DSTRAN, SV)
!     J2 law coded directly: the Volume I UMAT, with its state in SVARS
!     SV: stress at the start (NTENS), PEEQ, plastic strain (NTENS)
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K12CFG/ PR(6), NT
      DIMENSION STRESS(NTENS), DDSDDE(NTENS,NTENS), DSTRAN(NTENS),
     1 SV(2*NTENS+1), PROPS(8), STRAN(6), TIME(2), PREDEF(1),
     2 DPRED(1), COORDS(3), DROT(3,3), DFGRD0(3,3), DFGRD1(3,3),
     3 DDSDDT(6), DRPLDE(6), JSTEP(4)
      CHARACTER*80 CMNAME
      IF (NTENS .NE. 4) THEN
         WRITE(7,*) 'K12_DIRECT: plane strain only'
         CALL XIT
      ENDIF
      PROPS(1) = PR(1)
      PROPS(2) = PR(2)
      PROPS(3) = PR(3)
      PROPS(4) = PR(4)
      PROPS(5) = PR(5)
      PROPS(6) = PR(6)
      PROPS(7) = 0.0D0
      PROPS(8) = 0.0D0
      STRESS = SV(1:NTENS)
      SSE = 0.0D0
      SPD = 0.0D0
      SCD = 0.0D0
      RPL = 0.0D0
      DRPLDT = 0.0D0
      PNEWDT = 1.0D0
      CALL UMAT(STRESS, SV(NTENS+1), DDSDDE, SSE, SPD, SCD, RPL,
     1 DDSDDT, DRPLDE, DRPLDT, STRAN, DSTRAN, TIME, 0.0D0, 0.0D0,
     2 0.0D0, PREDEF, DPRED, CMNAME, 3, 1, NTENS, NTENS+1, PROPS, 8,
     3 COORDS, DROT, PNEWDT, 0.0D0, DFGRD0, DFGRD1, 1, 1, 1, 1,
     4 JSTEP, 1)
      SV(1:NTENS) = STRESS
      RETURN
      END
