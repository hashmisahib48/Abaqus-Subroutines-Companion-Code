#!/bin/sh
# build and run the Chapter 12 drivers (gfortran 13, stubs from lib/aba)
cd "$(dirname "$0")/../code" || exit 1
python3 ../verify/mktwin.py
gfortran -O1 -w -ffixed-form -std=legacy -ffpe-summary=none -I/home/claude/vol2/lib/aba \
  ex12_drv.f ex12_uelmat.f ex12_uel_direct.f ex12_matlib.f vol1_umat_j2.f /home/claude/vol2/lib/aba/stubs.f -o ../out/ex12_drv || exit 1
cd ../code && ../out/ex12_drv
