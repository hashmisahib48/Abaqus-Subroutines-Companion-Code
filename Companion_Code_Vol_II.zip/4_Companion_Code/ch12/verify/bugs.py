"""Inject one fault at a time into ex12_uelmat.f, run the Chapter 12 driver and record what it reports."""
import os,subprocess,re,shutil,sys
base=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'); code=os.path.join(base,'code')
src=open(os.path.join(code,'ex12_uelmat.f')).read()
F={
 1:("         DSTRAN = MATMUL(B(:,:,K), DU)","         DSTRAN = MATMUL(B(:,:,K), U)"),
 2:("            B(NTENS,2*IA-1,K) = DNX(2,IA,K)\n            B(NTENS,2*IA,K) = DNX(1,IA,K)","            B(NTENS,2*IA-1,K) = 0.5D0*DNX(2,IA,K)\n            B(NTENS,2*IA,K) = 0.5D0*DNX(1,IA,K)"),
 3:("      RHS = -FINT","      RHS = FINT"),
 4:("      FINT = 0.0D0\n      AMATRX = 0.0D0\n","      FINT = 0.0D0\n"),
 5:("     1        DSTRAN, K, DVDV0,","     1        DSTRAN, 1, DVDV0,"),
 6:("CALL MATERIAL_LIB_MECH(MATERIALLIB, STRESS, DDSDDE, STRAN,\n     1        DSTRAN,","CALL MATERIAL_LIB_MECH(MATERIALLIB, STRESS, DDSDDE, DSTRAN,\n     1        STRAN,"),
 7:("         FINT = FINT + MATMUL(TRANSPOSE(B(:,:,K)), STRESS)*DV(K)","         FINT = FINT + MATMUL(TRANSPOSE(B(:,:,K)), STRESS)*DV(K)/THK"),
}
os.makedirs(os.path.join(base,'out','bug'),exist_ok=True)
for k,(a,b) in F.items():
    if k not in map(int,sys.argv[1:] or F): continue
    if a not in src: print('fault',k,'pattern not found'); continue
    d=os.path.join(base,'out','bug',str(k)); os.makedirs(d,exist_ok=True)
    open(os.path.join(d,'ex12_uelmat.f'),'w').write(src.replace(a,b))
    r=subprocess.run(['gfortran','-w','-O1','-ffixed-form','-std=legacy','-I/home/claude/vol2/lib/aba',os.path.join(code,'ex12_drv.f'),os.path.join(d,'ex12_uelmat.f'),os.path.join(code,'ex12_uel_direct.f'),os.path.join(code,'ex12_matlib.f'),os.path.join(code,'vol1_umat_j2.f'),'/home/claude/vol2/lib/aba/stubs.f','-o',os.path.join(d,'drv')],capture_output=True,text=True)
    if r.returncode: print(k,r.stderr[:500]); continue
    os.makedirs(os.path.join(d,'code'),exist_ok=True); os.makedirs(os.path.join(d,'out'),exist_ok=True)
    try: subprocess.run([os.path.join(d,'drv')],cwd=os.path.join(d,'code'),capture_output=True,text=True,timeout=300)
    except Exception as e: print(k,'run',e)
    res=open(os.path.join(d,'out','results.txt')).read().splitlines() if os.path.exists(os.path.join(d,'out','results.txt')) else []
    print('--- fault',k)
    for l in res:
        if l.startswith(('T2 ','T3 ','T3RB')) or (l.startswith('CI 1') and ' 150.0' in l) or l.startswith('C150 1') or l.startswith('UD'): print(l[:170])
