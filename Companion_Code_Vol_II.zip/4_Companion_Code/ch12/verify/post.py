"""Post-process out/results.txt: closed forms, eigenvalues, problem answers -> out/post.json"""
import numpy as np, json, os, re
from scipy.optimize import brentq
B=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'); O=os.path.join(B,'out')
L=open(os.path.join(O,'results.txt')).read().splitlines()
R={}
E,NU,SY0,H=210000.,0.3,250.,1000.; G=E/2.6; K=E/(3*(1-2*NU)); Et=E*H/(E+H); eY=SY0/E
def f(x): return [float(t) for t in x.split()]
R['T1']=[f(l[2:]) for l in L if l.startswith('T1 ')]
R['T1PS']=f([l for l in L if l.startswith('T1PS')][0][4:])
R['T1D']=f([l for l in L if l.startswith('T1D')][0][3:])
R['T2']=[f(l[2:]) for l in L if l.startswith('T2 ')]
R['T2R']=[f(l[3:]) for l in L if l.startswith('T2R')]
R['T3']=[f(l[2:]) for l in L if l.startswith('T3 ')]
R['T3RB']=[f(l[4:]) for l in L if l.startswith('T3RB')]
R['CI']=[f(l[2:]) for l in L if l.startswith('CI ')]
R['PY']=[f(l[2:]) for l in L if l.startswith('PY')]
R['C150']=[f(l[4:]) for l in L if l.startswith('C150')]
R['CP']=[f(l[2:]) for l in L if l.startswith('CP')]
R['UD']=[f(l[2:]) for l in L if l.startswith('UD')]
# eigenvalues of element matrices
def mat(tag,ib):
    rows=[f(l[2:])[2:] for l in L if l.startswith(tag+' %d '%ib)]
    return np.array(rows)
EIG={}
for ib in (0,1):
    EIG['KV%d'%ib]=np.linalg.eigvalsh(0.5*(mat('KV',ib)+mat('KV',ib).T)).tolist()
    EIG['KP%d'%ib]=np.linalg.eigvalsh(0.5*(mat('KP',ib)+mat('KP',ib).T)).tolist()
R['EIG']=EIG
# closed forms
a,b=50.,100.
R['py_closed']=float(SY0/np.sqrt(0.5*((1.6667-(-1))**2+(-1-0.2)**2+(0.2-1.6667)**2)) ) if False else None
th=(b*b+a*a)/(b*b-a*a); sz=NU*(th-1.0)
q=np.sqrt(0.5*((th+1)**2+(-1-sz)**2+(sz-th)**2)); R['py_closed']=SY0/q
pc=lambda c: 2*SY0/np.sqrt(3)*(np.log(c/a)+0.5*(1-c*c/(b*b)))
R['c150_closed']=brentq(lambda c:pc(c)-150,a,b)
R['plim']=pc(b)
R['pc_curve']=[[float(c),float(pc(c))] for c in np.linspace(a,b,41)]
# uniaxial closed forms
def uni(eps): s=SY0+Et*(eps-eY); return s,(s-SY0)/H
R['uni']={str(e):uni(e) for e in (0.01,0.02,0.05)}
R['lat5']=-(NU*uni(0.05)[0]/E+0.5*uni(0.05)[1])+0*0  # elastic lateral + plastic lateral (-ep/2)
R['lat5']=-NU*uni(0.05)[0]/E-0.5*uni(0.05)[1]
# A1
xs=np.array([[0,0],[4,0],[4,2],[0,2.]])
u=lambda x,y:(0.002*x+0.001*y); v=lambda x,y:(0.0005*x-0.0005*y)
DU=[(u(*p),v(*p)) for p in xs]
D=np.zeros((4,4)); lam=K-2*G/3
for i in range(3):
    for j in range(3): D[i,j]=lam
    D[i,i]+=2*G
D[3,3]=G
de=np.array([0.002,-0.0005,0,0.0015]); ds=D@de
p=ds[:3].mean(); dev=np.r_[ds[:3]-p,ds[3:]]; qq=np.sqrt(1.5*(dev[:3]@dev[:3]+2*dev[3]**2))
R['A1']=dict(DU=DU,ds=ds.tolist(),q=float(qq))
# B2 trapezoid work
def sig(e): return E*e if e<=eY else SY0+Et*(e-eY)
Wex=0.5*SY0*eY+0.5*(SY0+sig(0.02))*(0.02-eY)
tr={}
for n in (1,2,4,10,20,100):
    es=np.linspace(0,0.02,n+1); s=[sig(e) for e in es]
    tr[n]=float(sum(0.5*(s[i]+s[i+1])*(es[i+1]-es[i]) for i in range(n)))
R['B2']=dict(exact=Wex,trap=tr,sse=sig(0.02)**2/(2*E))
# A3
s2,p2=uni(0.02); R['A3']=dict(sigma=s2,peeq=p2,F=s2*10.0,Fy=SY0*10.0,ey=eY)
json.dump(R,open(os.path.join(O,'post.json'),'w'),indent=1,default=float)
print(json.dumps({k:R[k] for k in ('T1','T1PS','T1D','T3','T3RB','PY','C150','UD','A1','B2','A3','py_closed','c150_closed','plim','uni','lat5')},indent=0,default=float))
for k,v in EIG.items(): print(k,np.round(v,3))
