"""Generate the 'direct' twin of ex12_uelmat.f: the same element with the J2 law called directly
(Volume I UMAT, state in SVARS) instead of MATERIAL_LIB_MECH (state in the library)."""
import re,os
d=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','code')
s=open(os.path.join(d,'ex12_uelmat.f')).read()
s=s.replace("SUBROUTINE UELMAT(","SUBROUTINE UEL(")
s=s.replace("PERIOD,\n     4 MATERIALLIB)","PERIOD)")
s=s.replace("PREDEF, MATERIALLIB)","PREDEF)")
s=s.replace("SUBROUTINE K12_QUAD4(","SUBROUTINE K12_QUAD4D(").replace("CALL K12_QUAD4(","CALL K12_QUAD4D(")
s=s.replace("      NSVINT = NTENS\n","      NSVINT = 3*NTENS + 1\n")
i=s.index("         CALL MATERIAL_LIB_MECH("); j=s.index("         DO I = 1, NTENS\n            SVARS(ISV+I)")
s=s[:i]+"         CALL K12_DIRECT(NTENS, STRESS, DDSDDE, DSTRAN,\n     1        SVARS(ISV+NTENS+1))\n"+s[j:]
s=s.replace("'UELMAT U1","'UEL U1")
a=s.index("      SUBROUTINE K12_SHP("); b=s.index("      SUBROUTINE K12_QUAD4D(")
s=s[:a]+s[b:]
open(os.path.join(d,'ex12_uel_direct.f'),'w').write(s+"""!
      SUBROUTINE K12_DIRECT(NTENS, STRESS, DDSDDE, DSTRAN, SV)
!     J2 law coded directly: the Volume I UMAT, with its state in SVARS
!     SV: stress at the start (NTENS), PEEQ, plastic strain (NTENS)
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K12CFG/ PR(6), NT
      DIMENSION STRESS(NTENS), DDSDDE(NTENS,NTENS), DSTRAN(NTENS),
     1 SV(2*NTENS+1), PROPS(8), STRAN(6), TIME(2), PREDEF(1),
     2 DPRED(1), COORDS(3), DROT(3,3), DFGRD0(3,3), DFGRD1(3,3),
     3 DDSDDT(6), DRPLDE(6), JSTEP(4)
      CHARACTER*80 CMNAME
      IF (NTENS .NE. 4) THEN
         WRITE(7,*) 'K12_DIRECT: plane strain only'
         CALL XIT
      ENDIF
      PROPS(1) = PR(1)
      PROPS(2) = PR(2)
      PROPS(3) = PR(3)
      PROPS(4) = PR(4)
      PROPS(5) = PR(5)
      PROPS(6) = PR(6)
      PROPS(7) = 0.0D0
      PROPS(8) = 0.0D0
      STRESS = SV(1:NTENS)
      SSE = 0.0D0
      SPD = 0.0D0
      SCD = 0.0D0
      RPL = 0.0D0
      DRPLDT = 0.0D0
      PNEWDT = 1.0D0
      CALL UMAT(STRESS, SV(NTENS+1), DDSDDE, SSE, SPD, SCD, RPL,
     1 DDSDDT, DRPLDE, DRPLDT, STRAN, DSTRAN, TIME, 0.0D0, 0.0D0,
     2 0.0D0, PREDEF, DPRED, CMNAME, 3, 1, NTENS, NTENS+1, PROPS, 8,
     3 COORDS, DROT, PNEWDT, 0.0D0, DFGRD0, DFGRD1, 1, 1, 1, 1,
     4 JSTEP, 1)
      SV(1:NTENS) = STRESS
      RETURN
      END
""")
