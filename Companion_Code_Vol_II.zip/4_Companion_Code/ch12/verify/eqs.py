import sys; sys.path.insert(0,'/home/claude/vol2/lib')
from mkeq import mkeq
import os; os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
E={
 'e1231':[r'$\boldsymbol{\sigma}_{n+1}=\boldsymbol{\sigma}\left(\boldsymbol{\sigma}_{n},\ \mathrm{history}_{n},\ \Delta\boldsymbol{\varepsilon}\right),\qquad D_{ij}=\frac{\partial\,\sigma_{i,\,n+1}}{\partial\,\Delta\varepsilon_{j}}$'],
 'e1241':[r'$\Delta\varepsilon_{33}\ \leftarrow\ \Delta\varepsilon_{33}-\frac{\sigma_{33}}{D_{33}}\quad\mathrm{until}\quad\sigma_{33}=0,$',
          r'$D^{*}_{ij}=D_{ij}-\frac{D_{i3}\,D_{3j}}{D_{33}},\qquad i,j\in\{1,\,2,\,4\}$'],
 'e1251':[r'$N_a=\frac{1}{4}\,(1+\xi_a\xi)(1+\eta_a\eta),\qquad \mathbf{x}=\sum_a N_a\,\mathbf{x}_a,\qquad J_{ij}=\frac{\partial\,x_j}{\partial\,\xi_i}$',
          r'$\frac{\partial N_a}{\partial x_j}=\sum_{i}\left(\mathbf{J}^{-1}\right)_{ji}\frac{\partial N_a}{\partial \xi_i},\qquad dV=t\,\det\mathbf{J}\ d\xi_1\,d\xi_2$'],
 'e1252':[r'$\Delta\varepsilon_{11}=\sum_a N_{a,x}\,\Delta u_a,\qquad \Delta\varepsilon_{22}=\sum_a N_{a,y}\,\Delta v_a,\qquad \Delta\varepsilon_{33}=0$',
          r'$\Delta\gamma_{12}=\sum_a\left(N_{a,y}\,\Delta u_a+N_{a,x}\,\Delta v_a\right)$'],
 'e1253':[r'$\bar{\mathbf{B}}_a=\mathbf{B}_a+\frac{1}{2}\,\mathbf{m}\,\left(\bar{\mathbf{b}}_a-\mathbf{b}_a\right)^{T},\qquad \mathbf{m}=(1,\,1,\,0,\,0)^{T}$',
          r'$\mathbf{b}_a=(N_{a,x},\ N_{a,y})^{T},\qquad \bar{\mathbf{b}}_a=\frac{1}{V}\int_{V}\mathbf{b}_a\ dV$'],
 'e1254':[r'$\mathbf{f}=\sum_{k=1}^{4}t\,\det\mathbf{J}_k\ \bar{\mathbf{B}}_k^{T}\,\boldsymbol{\sigma}_k,\qquad \mathbf{K}=\sum_{k=1}^{4}t\,\det\mathbf{J}_k\ \bar{\mathbf{B}}_k^{T}\,\mathbf{D}_k\,\bar{\mathbf{B}}_k$',
          r'$\mathrm{RHS}=-\,\mathbf{f},\qquad \mathrm{AMATRX}=\mathbf{K}$'],
 'e1261':[r'$A^{\mathrm{fd}}_{ij}=-\,\frac{R_i(\mathbf{U}+h\,\mathbf{e}_j)-R_i(\mathbf{U}-h\,\mathbf{e}_j)}{2h},\qquad \epsilon_{\mathrm{fd}}=\frac{\max_{ij}\left|A^{\mathrm{fd}}_{ij}-A_{ij}\right|}{\max_{ij}\left|A_{ij}\right|}$'],
 'e1271':[r'$p=\frac{2\,\sigma_{y}}{\sqrt{3}}\left[\ln\frac{c}{a}+\frac{1}{2}\left(1-\frac{c^{2}}{b^{2}}\right)\right]$',
          r'$p_{y}=\frac{\sigma_{y0}}{q_1},\qquad \vartheta=\frac{b^2+a^2}{b^2-a^2}$',
          r'$q_1=\sqrt{\frac{1}{2}\left[(\vartheta+1)^2+\left(1+\nu(\vartheta-1)\right)^2+\left(\vartheta-\nu(\vartheta-1)\right)^2\right]}$'],
}
mkeq(E,'.')
