import sys, json, os; sys.path.insert(0,'/home/claude/vol2/lib')
from figstyle import *
import matplotlib.pyplot as plt, numpy as np
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
R=json.load(open('out/post.json'))
def tx(ax,x,y,s,fs=7.8,**k):
    k.setdefault('fontsize',fs); ax.text(x,y,s,**k)
E_,NU,SY0,H=210000.,0.3,250.,1000.; Et=E_*H/(E_+H); eY=SY0/E_

# 12A.1 element with displacement increments
fig,ax=new(3.4,1.9)
P=np.array([[0,0],[4,0],[4,2],[0,2.]]); DU=np.array(R['A1']['DU'])
ax.add_patch(Polygon(P,fc=LB,ec=BLUE,lw=1.2))
sc=70
Q=P+sc*DU; ax.add_patch(Polygon(Q,fc='none',ec=RED,lw=1.0,ls='--'))
for a,(x,y) in enumerate(P):
    ax.plot(x,y,'o',color=NAVY,ms=3.6); 
    off=[(-0.3,-0.3),(0.3,-0.3),(0.3,0.3),(-0.3,0.3)][a]; tx(ax,x+off[0],y+off[1],str(a+1),color=NAVY,ha='center',va='center',weight='bold',fontsize=8)
    arr(ax,(x,y),tuple(Q[a]),c=RED,lw=0.8,ms=5)
g=1/np.sqrt(3)
for xi in (-g,g):
    for et in (-g,g): ax.plot(2+2*xi,1+et,'s',color=GREEN,ms=3.2)
tx(ax,2,-0.62,'4 mm',color=GREY,ha='center',fontsize=7.6); tx(ax,-0.45,1,'2 mm',color=GREY,ha='right',va='center',fontsize=7.6)
tx(ax,2,1.0,'plane strain, $t$ = 1 mm\nGauss points (green)',color=GREY,ha='center',va='center',fontsize=7.4)
tx(ax,4.75,1,'increments $\\Delta\\mathbf{U}$\nof Problem 12A.1\n(red, ×70)',color=RED,ha='left',va='center',fontsize=7.4)
ax.set_xlim(-1.4,6.7); ax.set_ylim(-1,2.8); save(fig,'p_12A1.png')

# 12A.2 three elements
fig,axs=plt.subplots(1,3,figsize=(4.6,1.8),dpi=240)
for a in axs: a.set_aspect('equal'); a.axis('off')
a=axs[0]
v=np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1.]])
pr=lambda p:(p[0]+0.45*p[2],p[1]+0.35*p[2])
ed=[(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]
for i,j in ed: a.plot(*zip(pr(v[i]),pr(v[j])),color=BLUE,lw=1.0)
for k,p in enumerate(v): a.plot(*pr(p),'o',color=NAVY,ms=2.8)
gg=0.5/np.sqrt(3)
for x in (0.5-gg,0.5+gg):
    for y in (0.5-gg,0.5+gg):
        for z in (0.5-gg,0.5+gg): a.plot(*pr((x,y,z)),'s',color=RED,ms=2.0)
tx(a,0.8,-0.38,'(a) 8-node brick',color=GREY,ha='center',fontsize=7.4); a.set_xlim(-0.2,1.7); a.set_ylim(-0.5,1.5)
a=axs[1]
a.add_patch(Rectangle((0,0),1,1,fc=LB,ec=BLUE,lw=1.0))
for p in [(0,0),(1,0),(1,1),(0,1)]: a.plot(*p,'o',color=NAVY,ms=3)
for x in (0.5-gg,0.5+gg):
    for y in (0.5-gg,0.5+gg): a.plot(x,y,'s',color=RED,ms=2.8)
tx(a,0.5,-0.2,'(b) 4-node, plane stress',color=GREY,ha='center',fontsize=7.4); a.set_xlim(-0.2,1.2); a.set_ylim(-0.3,1.2)
a=axs[2]
a.add_patch(Rectangle((0,0),1,1,fc=LB,ec=BLUE,lw=1.0))
for p in [(0,0),(1,0),(1,1),(0,1),(0.5,0),(1,0.5),(0.5,1),(0,0.5)]: a.plot(*p,'o',color=NAVY,ms=3)
g3=np.sqrt(0.6)/2
for x in (0.5-g3,0.5,0.5+g3):
    for y in (0.5-g3,0.5,0.5+g3): a.plot(x,y,'s',color=RED,ms=2.8)
tx(a,0.5,-0.2,'(c) 8-node, plane stress',color=GREY,ha='center',fontsize=7.4); a.set_xlim(-0.2,1.2); a.set_ylim(-0.3,1.2)
fig.subplots_adjust(wspace=0.05,left=0.01,right=0.99); save(fig,'p_12A2.png')

# 12A.3 single element, boundary conditions
fig,ax=new(3.4,1.8)
ax.add_patch(Rectangle((0,0),10,5,fc=LB,ec=BLUE,lw=1.2))
hatch_v(ax,0,0,5,step=0.9,d=0.5)
for x in (0,10): pass
ax.plot([0,10],[0,0],color=NAVY,lw=1)
for x in np.arange(0,10.1,1.4): ax.plot([x,x-0.5],[0,-0.5],color=NAVY,lw=0.7)
arr(ax,(10.2,1.2),(12.2,1.2),c=RED,lw=1.2); arr(ax,(10.2,3.8),(12.2,3.8),c=RED,lw=1.2)
tx(ax,12.5,2.5,'$u_1$ = $\\varepsilon\\,L$\nprescribed',color=RED,ha='left',va='center',fontsize=7.6)
tx(ax,5,2.5,'plane stress\n$t$ = 2 mm',color=GREY,ha='center',va='center',fontsize=7.6)
tx(ax,5,5.6,'10 mm',color=GREY,ha='center',fontsize=7.4); tx(ax,-1.6,2.5,'5 mm',color=GREY,ha='center',va='center',fontsize=7.4,rotation=90)
tx(ax,5,-1.5,'top edge free: uniaxial stress',color=GREY,ha='center',fontsize=7.4)
for k,(x,y) in enumerate([(0,0),(10,0),(10,5),(0,5)]): ax.plot(x,y,'o',color=NAVY,ms=3.2)
ax.set_xlim(-2.6,17.5); ax.set_ylim(-2.2,6.8); save(fig,'p_12A3.png')

# 12B1 matrix partition
fig,ax=new(3.2,1.8)
ax.set_xlim(-1.3,5.3); ax.set_ylim(-1.0,4.6)
labs=['1','2','3','4']
for i in range(4):
    for j in range(4):
        fc='#FFFFFF'
        if i==2 or j==2: fc='#FBE6E3'
        if i==2 and j==2: fc='#F5B7B1'
        ax.add_patch(Rectangle((j,3-i),1,1,fc=fc,ec=GREY,lw=0.7))
        tx(ax,j+0.5,3-i+0.5,'$D_{%s%s}$'%(labs[i],labs[j]),ha='center',va='center',fontsize=7.8,color=NAVY)
for i,l in enumerate(['11','22','33','12']):
    tx(ax,-0.12,3-i+0.5,l,ha='right',va='center',fontsize=7.4,color=GREY); tx(ax,i+0.5,4.2,l,ha='center',va='bottom',fontsize=7.4,color=GREY)
tx(ax,4.2,2.5,'row, column 3:\n$\\sigma_{33}$, $\\Delta\\varepsilon_{33}$\neliminated',ha='left',va='center',fontsize=7.4,color=RED)
tx(ax,2,-0.5,'$\\mathbf{D}$ (4 × 4) from the library',ha='center',fontsize=7.6,color=GREY)
ax.set_xlim(-1.0,6.2); save(fig,'p_12B1.png')

# 12B2 trapezoid
fig,ax=plt.subplots(figsize=(3.1,1.9),dpi=240)
e=np.linspace(0,0.02,400); s=np.where(e<=eY,E_*e,SY0+Et*(e-eY)); ax.plot(e*100,s,color=BLUE,lw=1.2)
def sg(x): return E_*x if x<=eY else SY0+Et*(x-eY)
ax.fill([0,1,1],[0,0,sg(0.01)],color=PINK,alpha=0.9); ax.fill([1,2,2,1],[0,0,sg(0.02),sg(0.01)],color='#FDF0E0',alpha=0.9)
ax.plot([0,1,2],[0,sg(0.01),sg(0.02)],color=RED,lw=1.0,marker='o',ms=3.2)
ax.set_xlabel('$\\varepsilon_{11}$  (%)',fontsize=8); ax.set_ylabel('$\\sigma_{11}$  (MPa)',fontsize=8); ax.tick_params(labelsize=7)
ax.set_xlim(0,2.1); ax.set_ylim(0,300); tx(ax,1.0,60,'two increments,\ntrapezoid rule',ha='center',fontsize=7.4,color=RED)
tx(ax,1.5,215,'exact curve',color=BLUE,fontsize=7.4,ha='center')
fig.subplots_adjust(bottom=0.2,left=0.2); save(fig,'p_12B2.png')

# 12C1 cylinder with BCs
fig,ax=new(3.3,2.0)
ar=np.linspace(0,np.pi/2,60)
ax.fill(np.r_[50*np.cos(ar),100*np.cos(ar[::-1])],np.r_[50*np.sin(ar),100*np.sin(ar[::-1])],color=LB)
ax.plot(50*np.cos(ar),50*np.sin(ar),color=NAVY,lw=1.0); ax.plot(100*np.cos(ar),100*np.sin(ar),color=NAVY,lw=1.0)
ax.plot([50,100],[0,0],color=NAVY,lw=1.0); ax.plot([0,0],[50,100],color=NAVY,lw=1.0)
for r in np.linspace(52,98,8): ax.plot([r,r-3],[0,-4],color=NAVY,lw=0.6); ax.plot([0,-4],[r,r-3],color=NAVY,lw=0.6)
for t in np.radians(np.linspace(8,82,6)): arr(ax,(40*np.cos(t),40*np.sin(t)),(49*np.cos(t),49*np.sin(t)),c=RED,lw=0.9,ms=5)
tx(ax,28,20,'$p$',color=RED,fontsize=9,ha='center'); tx(ax,75,-14,'symmetry: $v$ = 0',color=GREY,fontsize=7.4,ha='center',va='top'); tx(ax,-6,76,'symmetry:\n$u$ = 0',color=GREY,fontsize=7.4,ha='right',va='center')
tx(ax,86,70,'plane strain\n$a$ = 50, $b$ = 100 mm',color=NAVY,fontsize=7.4,ha='center',va='center')
ax.set_xlim(-48,125); ax.set_ylim(-22,106); save(fig,'p_12C1.png')

# 12C2 brick numbering
fig,ax=new(3.0,1.8)
v=np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1.]])
pr=lambda p:(p[0]+0.5*p[2],p[1]+0.4*p[2])
for i,j in ed: ax.plot(*zip(pr(v[i]),pr(v[j])),color=BLUE,lw=1.1)
for k,p in enumerate(v):
    q=pr(p); ax.plot(*q,'o',color=NAVY,ms=3.2); tx(ax,q[0]+(-0.08 if k in (0,3,7) else 0.08),q[1]+(0.1 if p[1]==1 else -0.1),str(k+1),color=NAVY,ha='right' if k in (0,3,7) else 'left',va='center',fontsize=7.8,weight='bold')
arr(ax,pr((1.0,0.5,0.5)),(1.95,0.7),c=RED,lw=1.1); tx(ax,2.0,0.7,'$u_1$ prescribed\non nodes 2, 3, 6, 7',color=RED,ha='left',va='center',fontsize=7.4)
tx(ax,0.8,-0.45,'symmetry planes through nodes 1, 4, 5, 8 ($u_1$ = 0),\n1, 2, 5, 6 ($u_2$ = 0), 1, 2, 3, 4 ($u_3$ = 0)',color=GREY,ha='center',va='top',fontsize=6.8)
ax.set_xlim(-0.6,3.6); ax.set_ylim(-1.2,1.6); save(fig,'p_12C2.png')

# 12D1 plan
fig,ax=plt.subplots(figsize=(3.4,1.9),dpi=240); ax.set_xlim(0,100); ax.set_ylim(0,56); ax.axis('off')
def bx(x,y,w,h,t,fc=LB,ec=BLUE,fs=7.4):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=1.5',fc=fc,ec=ec,lw=0.9)); ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,color=NAVY,linespacing=1.25)
bx(1,38,44,16,'strain measure and\nstress measure of\nthe library (LFLAGS(2)=1)',LGREY,GREY)
bx(55,38,44,16,'element kinematics:\nF from U, B-matrix\nat the current geometry')
bx(1,13,44,16,'tangent: material part\nand geometric part,\nFD check')
bx(55,13,44,16,'tests: rigid rotation,\nlarge-strain uniaxial,\npatch test',PINK,RED)
arr(ax,(45.6,46),(54.4,46),c=GREY,lw=1.0); arr(ax,(77,37.4),(77,29.6),c=GREY,lw=1.0); arr(ax,(54.4,21),(45.6,21),c=GREY,lw=1.0)
tx(ax,50,4,'UNVERIFIED in the documentation: decide first',color=RED,fontsize=7.4,ha='center')
save(fig,'p_12D1.png')
print('pfigs ok')
