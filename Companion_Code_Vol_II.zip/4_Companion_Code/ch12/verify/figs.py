import sys, json, os; sys.path.insert(0,'/home/claude/vol2/lib')
from figstyle import *
import matplotlib.pyplot as plt, numpy as np
B=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'); os.chdir(B)
R=json.load(open('out/post.json'))
FS=7.8
def tx(ax,x,y,s,fs=FS,**k):
    k.setdefault('fontsize',fs); ax.text(x,y,s,**k)
E,NU,SY0,H=210000.,0.3,250.,1000.; Et=E*H/(E+H); eY=SY0/E

# ---------- Fig 12.2-1 : data flow ----------
fig,ax=plt.subplots(figsize=(4.9,2.35),dpi=240); ax.set_xlim(0,100); ax.set_ylim(0,50); ax.axis('off')
def bx(x,y,w,h,t,fc,ec,fs=7.4,tc=NAVY,b=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=1.5',fc=fc,ec=ec,lw=1.0))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,color=tc,weight='bold' if b else 'normal',linespacing=1.3)
bx(0,30,20,15,'Abaqus/Standard\n(Newton loop,\nassembly)',LGREY,GREY,fs=7.2)
bx(38,30,22,15,'UELMAT\nyour element',LB,BLUE,b=True,fs=7.6)
bx(76,30,24,15,'MATERIAL_\nLIB_MECH',PINK,RED,b=True,fs=7.6)
bx(38,2,22,14,'state of the\nintegration points\nin SVARS (strain)',LB,BLUE,fs=7.0)
bx(76,2,24,14,'material history,\nkept inside\nthe library',PINK,RED,fs=7.0)
arr(ax,(20.6,40),(37.4,40),c=GREY,lw=1.1); arr(ax,(37.4,35),(20.6,35),c=GREY,lw=1.1)
arr(ax,(60.6,40),(75.4,40),c=BLUE,lw=1.1); arr(ax,(75.4,35),(60.6,35),c=RED,lw=1.1)
arr(ax,(46,29.4),(46,16.6),c=BLUE,lw=1.0); arr(ax,(52,16.6),(52,29.4),c=BLUE,lw=1.0)
arr(ax,(84,29.4),(84,16.6),c=RED,lw=1.0); arr(ax,(92,16.6),(92,29.4),c=RED,lw=1.0)
tx(ax,10,46.5,'U, DU, SVARS,\nLFLAGS, PROPS',fontsize=6.6,color=GREY,ha='center',va='bottom')
tx(ax,10,28.5,'RHS, AMATRX,\nSVARS, PNEWDT',fontsize=6.6,color=GREY,ha='center',va='top')
tx(ax,68,41.0,'STRAN, DSTRAN,\nDFGRD, NPT',fontsize=6.6,color=BLUE,ha='center',va='bottom')
tx(ax,68,33.5,'STRESS,\nDDSDDE',fontsize=6.6,color=RED,ha='center',va='top')
tx(ax,0,12,'blue: written by you\nred: supplied by Abaqus',fontsize=6.8,color=GREY,ha='left',va='center')
save(fig,'fig_flow.png')

# ---------- Fig 12.5-1 : element, Gauss points, SVARS ----------
fig=plt.figure(figsize=(4.9,2.1),dpi=240)
a1=fig.add_axes([0.0,0.02,0.33,0.96]); a1.set_aspect('equal'); a1.axis('off')
a2=fig.add_axes([0.37,0.22,0.63,0.62]); a2.axis('off'); a2.set_xlim(0,41); a2.set_ylim(0,12)
P=np.array([[0,0],[4,0.25],[4.3,3.2],[0.2,3.0]])
a1.add_patch(Polygon(P,fc=LB,ec=BLUE,lw=1.2))
g=1/np.sqrt(3)
def shp(xi,et): return 0.25*np.array([(1-xi)*(1-et),(1+xi)*(1-et),(1+xi)*(1+et),(1-xi)*(1+et)])
gp=[(-g,-g),(g,-g),(g,g),(-g,g)]
for k,(xi,et) in enumerate(gp):
    p=shp(xi,et)@P; a1.plot(*p,'s',color=RED,ms=4.2); tx(a1,p[0]+0.13,p[1]+0.08,str(k+1),color=RED,fontsize=7.6,ha='left',va='bottom')
for a,(x,y) in enumerate(P):
    dx=[-0.25,0.25,0.25,-0.25][a]; dy=[-0.25,-0.25,0.25,0.25][a]
    a1.plot(x,y,'o',color=NAVY,ms=4); tx(a1,x+dx,y+dy,str(a+1),color=NAVY,fontsize=8,ha='center',va='center',weight='bold')
a1.set_xlim(-0.6,4.9); a1.set_ylim(-1.2,3.8)
tx(a1,2.1,-0.7,'(a) nodes (navy),\nintegration points (red)',color=GREY,fontsize=7.0,ha='center',va='top')
cols=[BLUE,TEAL,GREEN,PUR]
for k in range(4):
    x0=k*10.3
    for j,lab in enumerate(['ε11','ε22','ε33','γ12']):
        a2.add_patch(Rectangle((x0+j*2.45,5),2.45,3,fc=LB if k%2==0 else '#E2F3F4',ec=cols[k],lw=0.8))
        tx(a2,x0+j*2.45+1.22,6.5,lab,fontsize=5.9,ha='center',va='center',color=NAVY)
    tx(a2,x0+4.9,9.0,'point %d'%(k+1),fontsize=7.2,ha='center',color=cols[k])
    tx(a2,x0+4.9,3.9,'%d–%d'%(4*k+1,4*k+4),fontsize=6.8,ha='center',color=GREY)
tx(a2,20.5,2.0,'SVARS index; NTENS = 4, NSVARS ≥ 16',fontsize=7.0,color=NAVY,ha='center')
tx(a2,20.5,0.0,'(b) total strain at the start of the increment',color=GREY,fontsize=7.0,ha='center',va='top')
save(fig,'fig_elem.png')

# ---------- Fig 12.4-1 : state handling ----------
fig,ax=plt.subplots(figsize=(4.9,1.9),dpi=240); ax.set_xlim(0,100); ax.set_ylim(-1,45); ax.axis('off')
def bx2(x,y,w,h,t,fc,ec,fs=7.4):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=1.5',fc=fc,ec=ec,lw=1.0)); ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,color=NAVY,linespacing=1.25)
bx2(1,14,17,12,'committed\nstate $S_n$',LB,BLUE)
for k,y in enumerate([30,14,0]):
    bx2(44,y,20,9,'trial state\n(call %d)'%(k+1),PINK,RED,fs=7.0)
    arr(ax,(18.6,[24,20,16][k]),(43.4,y+4.5),c=BLUE,lw=1.0)
    tx(ax,[26,31,26][k],[32.3,22.3,6.3][k],'DSTRAN$_%d$'%(k+1),fontsize=6.8,color=BLUE,ha='center',va='center')
bx2(80,14,19,12,'committed\n$S_{n+1}$',LB,BLUE)
arr(ax,(64.6,3),(79.4,15),c=GREEN,lw=1.2)
tx(ax,76,3.2,'converged:\naccepted',fontsize=6.8,color=GREEN,ha='center',va='center')
tx(ax,50,43.5,'every call restarts from $S_n$; earlier trial states are discarded',fontsize=7.0,color=GREY,ha='center',va='center')
save(fig,'fig_state.png')

# ---------- Fig 12.6-1 : single element ----------
def cap(ax,t,y=-0.36): ax.text(0.5,y,t,transform=ax.transAxes,ha='center',va='top',fontsize=7.2,color=GREY)
T2=R['T2']; T2R=R['T2R']
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.2),dpi=240)
e=np.linspace(0,0.05,300); s_=np.where(e<=eY,E*e,SY0+Et*(e-eY)); a1.plot(e*100,s_,color=BLUE,lw=1.2,label='closed form')
uni=[t for t in T2 if t[0]==1]; a1.plot([t[2]*100 for t in uni],[t[3] for t in uni],'o',mfc='white',mec=RED,ms=4.5,mew=1.0,label='element')
a1.set_xlabel('$\\varepsilon_{11}$  (%)',fontsize=8); a1.set_ylabel('$\\sigma_{11}$  (MPa)',fontsize=8); a1.tick_params(labelsize=7)
a1.set_xlim(0,5.3); a1.set_ylim(0,330); a1.legend(fontsize=6.8,loc='lower right',handlelength=1.4,labelspacing=0.25)
cap(a1,'(a) uniaxial stress, plane-stress element')
cols=[BLUE,OR,RED]
for t,c in zip([T2R[0],T2R[2],T2R[4]],cols):
    r=t[2:]; a2.semilogy(range(len(r)),r,'o-',color=c,ms=3.4,lw=0.9,label='step %d'%int(t[1]))
a2.set_xlabel('iteration',fontsize=8); a2.set_ylabel('residual / $F_0$',fontsize=8); a2.tick_params(labelsize=7); a2.set_ylim(1e-15,3); a2.set_xlim(-0.2,4.4)
a2.legend(fontsize=6.6,loc='upper right',handlelength=1.2,labelspacing=0.2)
cap(a2,'(b) Newton iteration, three of five steps')
fig.subplots_adjust(wspace=0.42,bottom=0.30); save(fig,'fig_check.png')

# ---------- Fig 12.7-1 : cylinder ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.45),dpi=240,gridspec_kw={'width_ratios':[1,1.05]})
a1.set_aspect('equal'); a1.axis('off')
NR,NTH=16,8
rr=np.linspace(50,100,NR+1); th=np.linspace(0,np.pi/2,NTH+1)
for t in th: a1.plot(rr*np.cos(t),rr*np.sin(t),color='#9AA5B5',lw=0.35)
for r_ in rr: a1.plot(r_*np.cos(th),r_*np.sin(th),color='#9AA5B5',lw=0.35)
ar=np.linspace(0,np.pi/2,60)
a1.plot(50*np.cos(ar),50*np.sin(ar),color=NAVY,lw=0.9); a1.plot(100*np.cos(ar),100*np.sin(ar),color=NAVY,lw=0.9)
d=np.loadtxt('out/cyl_state.txt',skiprows=1); pl=d[:,2]>1e-10
a1.plot(d[pl,0],d[pl,1],'.',color=RED,ms=2.0); a1.plot(d[~pl,0],d[~pl,1],'.',color=BLUE,ms=1.4)
c=R['C150'][0][1]; a1.plot(c*np.cos(ar),c*np.sin(ar),color=OR,lw=0.9,ls='--')
tx(a1,52,-9,'$p$ = 150 MPa; red: plastic Gauss points,\ndashed: $c$ = %.2f mm'%c,fontsize=6.8,color=GREY,ha='center',va='top')
tx(a1,34,6,'$a$',fontsize=8,color=NAVY,ha='center'); tx(a1,104,4,'$b$',fontsize=8,color=NAVY,ha='left')
a1.set_xlim(-8,112); a1.set_ylim(-40,106); tx(a1,52,-40,'(a) 16 × 8 elements',color=GREY,fontsize=7.2,ha='center',va='top')
cp=np.array(R['pc_curve']); a2.plot(cp[:,1],cp[:,0],color=BLUE,lw=1.2,label='closed form')
cc=[t for t in R['CP'] if t[2]>0]; a2.plot([t[0] for t in cc],[t[2] for t in cc],'o',mfc='white',mec=RED,ms=3.8,mew=0.9,label='element')
a2.axvline(R['py_closed'],color=GREY,lw=0.6,ls=':'); tx(a2,R['py_closed']+2,98,'$p_y$',color=GREY,fontsize=7.4,va='top')
a2.set_xlabel('pressure $p$  (MPa)',fontsize=8); a2.set_ylabel('plastic radius $c$  (mm)',fontsize=8); a2.tick_params(labelsize=7)
a2.set_xlim(100,205); a2.set_ylim(48,102); a2.legend(fontsize=6.8,loc='lower right',handlelength=1.4,labelspacing=0.25)
cap(a2,'(b) growth of the plastic zone',-0.34)
fig.subplots_adjust(wspace=0.32,bottom=0.22); save(fig,'fig_cyl.png')

# ---------- Fig 12.7-2 : convergence and locking ----------
CI=R['CI']
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.2),dpi=240)
for t,c in zip([t for t in CI if t[0]==1 and t[1] in (125.,150.,175.)],[TEAL,OR,RED]):
    n=int(t[2]); r=t[3:3+n+1]; a1.semilogy(range(len(r)),r,'o-',color=c,ms=3.4,lw=0.9,label='%d MPa'%int(t[1]))
a1.set_xlabel('iteration',fontsize=8); a1.set_ylabel('residual / $\\|F\\|$',fontsize=8); a1.tick_params(labelsize=7); a1.set_ylim(1e-15,3)
a1.legend(fontsize=6.6,loc='upper right',handlelength=1.2,labelspacing=0.2); cap(a1,'(a) pressure steps, 16 × 8 mesh')
ua={}
for t in R['C150']: ua[int(t[0])]=t[2]
nr=[4,8,16]; bb=[ua[5],ua[4],ua[1]]; pp=[ua[8],ua[7],ua[3]]
a2.plot(nr,[x*1000 for x in bb],'o-',color=BLUE,ms=4,lw=1.0,label='mean dilatation'); a2.plot(nr,[x*1000 for x in pp],'s-',color=RED,ms=3.8,lw=1.0,label='standard')
a2.set_xscale('log',base=2); a2.set_xticks(nr); a2.set_xticklabels(['4×2','8×4','16×8']); a2.minorticks_off(); a2.tick_params(labelsize=7)
a2.set_ylabel('$u_a$ at 150 MPa  (µm)',fontsize=8); a2.set_xlabel('mesh',fontsize=8); a2.legend(fontsize=6.6,loc='lower right',handlelength=1.2,labelspacing=0.2)
cap(a2,'(b) inner radial displacement')
fig.subplots_adjust(wspace=0.42,bottom=0.30); save(fig,'fig_conv.png')
print('figs ok')
