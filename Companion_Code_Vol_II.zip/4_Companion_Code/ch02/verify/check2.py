import io,contextlib
with contextlib.redirect_stdout(io.StringIO()):
    from check import *
# --- compressible hydrostatic and shear closed forms
h,sh=hom('mr_0'); 
def hyd(d):
    return np.array([[float(x) for x in l.split()[1:]] for l in open(f'out/{d}/out_hom.txt') if l.startswith('HYD')])
hm=hyd('mr_0'); J=hm[:,0]**3; print('MR hydrostatic max rel err',np.max(np.abs(hm[:,1]-2*(J-1)/0.02)/np.maximum(1e-12,np.abs(2*(J-1)/0.02)))[()] if True else 0)
mu,lam=0.6,2.9
hc=hyd('cnh_0'); J=hc[:,0]**3; cf=mu*(J**(-1/3)-1/J)+lam*np.log(J)/J
mask=np.abs(cf)>1e-9
print('CNH hydrostatic rel err',np.max(np.abs(hc[mask,1]-cf[mask])/np.abs(cf[mask])), 'abs at lam=1',np.abs(hc[~mask,1]).max())
_,shc=hom('cnh_0'); g=shc[1:,0]
print('CNH shear s12, N1 rel err',np.max(np.abs(shc[1:,1]-mu*g)/(mu*g)),np.max(np.abs(shc[1:,2]-mu*g*g)/(mu*g*g)),'N2',np.abs(shc[:,3]).max())
# --- effect of D1 on the equibiaxial / uniaxial nominal stress at lambda=3 (independent)
for D1 in (0.02,0.002,0.0002,0.00002):
    p=dict(C10=0.5,C01=0.1,D1=D1); out=[]
    for m in (1,2,3):
        x,P=indep(Wmr,p,m,3.0); out.append((P,x**(1 if m!=2 else 1)*0+ 3.0*(x if m!=1 else x*x)))
    print('D1',D1,['P=%.5f J=%.5f'%o for o in out])
