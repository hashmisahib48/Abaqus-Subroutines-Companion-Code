"""Compares the driver output (out/*) with closed forms and with an independent
numerical differentiation of the energy as a function of F (no UHYPER derivatives used)."""
import numpy as np, json
from scipy.optimize import brentq
R={}
def hom(d):
    rows=[l.split() for l in open(f'out/{d}/out_hom.txt')]
    h={1:[],2:[],3:[]}; sh=[]
    for r in rows:
        if r[0]=='HYD': continue
        if r[0]=='SHEAR': sh.append([float(x) for x in r[1:]])
        else: h[int(r[0])].append([float(x) for x in r[1:]])
    return {k:np.array(v) for k,v in h.items()}, np.array(sh)
# ---------- closed forms, incompressible ----------
def W12_mr(I1,I2,p): return p['C10'],p['C01']
def W12_gent(I1,I2,p):
    x=(I1-3)/p['Jm']; return 0.5*p['mu']/(1-x), p['C2']/I2
def inv(mode,l):
    if mode==1: return l*l+2/l, 2*l+1/l**2
    if mode==2: return 2*l*l+l**-4, l**4+2*l**-2
    return l*l+1+l**-2, l*l+1+l**-2
def Pcf(mode,l,W12,p):
    I1,I2=inv(mode,l); W1,W2=W12(I1,I2,p)
    if mode==1: return 2*(l-l**-2)*(W1+W2/l)
    if mode==2: return 2*(l-l**-5)*(W1+W2*l*l)
    return 2*(l-l**-3)*(W1+W2)
MR=dict(C10=0.5,C01=0.1,D1=0.02); GT=dict(mu=1.0,Jm=30.0,C2=0.3,D1=0.02)
def check_inc(name,W12,p,lim=None):
    h,sh=hom(name); worst=0
    for m in (1,2,3):
        for l,xl,P in h[m]:
            if l==1.0: continue
            I1,_=inv(m,l)
            if lim and (I1-3)/p['Jm']>=0.99: continue
            c=Pcf(m,l,W12,p); worst=max(worst,abs(P-c)/abs(c))
    ws=0
    for g,s12,n1,n2 in sh:
        if g==0: continue
        W1,W2=W12(3+g*g,3+g*g,p)
        for v,c in ((s12,2*(W1+W2)*g),(n1,2*(W1+W2)*g*g),(n2,-2*W2*g*g)):
            ws=max(ws,abs(v-c)/max(abs(c),1e-12))
    return worst,ws
R['mr_inc']=check_inc('mr_1',W12_mr,MR); R['gent_inc']=check_inc('gent_1',W12_gent,GT,lim=True)
print('closed forms, relative differences (stretch tests, shear):',R['mr_inc'],R['gent_inc'])
# ---------- independent PK1 by differencing W(F) ----------
def Wmr(F,p):
    J=np.linalg.det(F); B=F@F.T; I1=np.trace(B)*J**(-2/3); I2=0.5*(np.trace(B)**2-np.trace(B@B))*J**(-4/3)
    return p['C10']*(I1-3)+p['C01']*(I2-3)+(J-1)**2/p['D1']
def Wcnh(F,p):
    J=np.linalg.det(F); B=F@F.T; I1=np.trace(B)*J**(-2/3)
    return 0.5*p['mu']*(J**(2/3)*I1-3-2*np.log(J))+0.5*p['lam']*np.log(J)**2
def PK1(W,F,p,h=1e-6):
    P=np.zeros((3,3))
    for i in range(3):
        for j in range(3):
            d=np.zeros((3,3)); d[i,j]=h; P[i,j]=(W(F+d,p)-W(F-d,p))/(2*h)
    return P
def Fm(mode,l,x):
    return np.diag([l, x if mode==1 else (l if mode==2 else 1.0), x])
def indep(W,p,mode,l):
    f=lambda x: PK1(W,Fm(mode,l,x),p)[2,2]
    x=brentq(f,0.002,2.0,xtol=1e-15); return x,PK1(W,Fm(mode,l,x),p)[0,0]
def check_comp(name,W,p):
    h,_=hom(name); worst=0; wl=0
    for m in (1,2,3):
        for l,xl,P in h[m]:
            if l==1.0: continue
            x,Pi=indep(W,p,m,l); worst=max(worst,abs(P-Pi)/abs(Pi)); wl=max(wl,abs(xl-x)/x)
    return worst,wl
R['mr_comp']=check_comp('mr_0',Wmr,MR)
CN=dict(mu=0.6,lam=2.9); R['cnh_comp']=check_comp('cnh_0',Wcnh,CN)
print('compressible vs independent PK1 (P, lateral stretch):',R['mr_comp'],R['cnh_comp'])
# compressible shear
h,sh=hom('mr_0'); print('compressible MR shear s12(g=2):',sh[-1])
# ---------- values quoted ----------
tab={}
for lam in (2.0,3.0):
    for m,nm in ((1,'UT'),(2,'EB'),(3,'PS')):
        P1=Pcf(m,lam,W12_mr,MR); h1,_=hom('mr_1'); h0,_=hom('mr_0')
        i=[k for k,r in enumerate(h1[m]) if r[0]==lam][0]
        tab[f'mr_{nm}_{lam}']=(P1,h1[m][i][2],h0[m][i][2],h0[m][i][1])
        hg1,_=hom('gent_1'); hg0,_=hom('gent_0')
        tab[f'gent_{nm}_{lam}']=(Pcf(m,lam,W12_gent,GT),hg1[m][i][2],hg0[m][i][2])
for k,v in tab.items(): print(k,['%.5f'%x for x in v])
R['tab']=tab
# limiting stretches of the Gent model
from scipy.optimize import brentq as bq
lim={}
lim['UT']=bq(lambda l:l*l+2/l-33,1.5,10); lim['EB']=bq(lambda l:2*l*l+l**-4-33,1.5,10); lim['PS']=bq(lambda l:l*l+1+l**-2-33,1.5,10)
print('Gent limiting stretches',lim); R['lim']=lim
# ---------- FD tests ----------
for d in ['mr_1','mr_0','gent_1','gent_0','cnh_0','cnh_bug_0']:
    print(d,'FD:',[l.split()[2:] for l in open(f'out/{d}/out_fd.txt') if l.startswith('STATE')][0:4])
    print(d,'path:',max(max(abs(a-b)/abs(a) for a,b in ((float(r[1]),float(r[2])),(float(r[3]),float(r[4])))) for r in (l.split() for l in open(f'out/{d}/out_tan.txt'))))
    print(d,'hess:',[l.split()[2:] for l in open(f'out/{d}/out_hess.txt')])
# ---------- Drucker ----------
def load(d):
    a=np.loadtxt(f'{d}/out_dr.txt'); e=a[:,:3]; A=np.zeros((len(a),3,3))
    A[:,0,0]=a[:,3];A[:,1,1]=a[:,4];A[:,2,2]=a[:,5];A[:,0,1]=A[:,1,0]=a[:,6];A[:,0,2]=A[:,2,0]=a[:,7];A[:,1,2]=A[:,2,1]=a[:,8]
    return e,A
Ub=np.array([[1,-1,0],[1,1,-2]]).T/np.array([np.sqrt(2),np.sqrt(6)])
def mineig(d):
    e,A=load(d); S=np.einsum('ia,nij,jb->nab',Ub,A,Ub); return e,np.linalg.eigvalsh(S)[:,0]
for d in ['out/mr_1','expl/mr-0.1','out/gent_1']:
    e,m=mineig(d); hexm=np.abs(e).max(1)<=1.2+1e-9
    print(d,'min eig in hexagon',m[hexm].min(),'unstable fraction',(m[hexm]<0).mean())
# equibiaxial stability limit of MR with C01<0
C10,C01=0.5,-0.1
f=lambda l:2*(l-l**-5)*(C10+C01*l*l)
lc=brentq(lambda l:(f(l+1e-6)-f(l-1e-6)),1.2,3); print('EB max load stretch MR(0.5,-0.1):',lc, 'sqrt(5)=',5**0.5)
json.dump({k:(v if not isinstance(v,tuple) else list(v)) for k,v in R.items()},open('results.json','w'),default=float)
