      SUBROUTINE UHYPER(BI1,BI2,AJ,U,UI1,UI2,UI3,TEMP,NOEL,
     1 CMNAME,INCMPFLAG,NUMSTATEV,STATEV,NUMFIELDV,FIELDV,
     2 FIELDVINC,NUMPROPS,PROPS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION U(2),UI1(3),UI2(6),UI3(6),STATEV(*),FIELDV(*),
     1 FIELDVINC(*),PROPS(*)
!
!     Compressible neo-Hookean material of Bonet and Wood, Eq. (2.8-1):
!        U = (MU/2) (J**(2/3) I1bar - 3 - 2 ln J) + (XLAM/2) (ln J)**2
!     PROPS(1) = MU (MPa)   PROPS(2) = XLAM (MPa)   TYPE=COMPRESSIBLE
!     U(2) is not defined: the energy is not split into a deviatoric
!     and a volumetric part, so *MULLINS EFFECT cannot be combined.
!
      IF (NUMPROPS .LT. 2 .OR. INCMPFLAG .NE. 0) THEN
         WRITE(7,*) 'UHYPER: two properties, TYPE=COMPRESSIBLE'
         CALL XIT
      ENDIF
      XMU  = PROPS(1)
      XLAM = PROPS(2)
      DO K = 1, 6
         UI2(K) = 0.0D0
         UI3(K) = 0.0D0
      ENDDO
      U(2) = 0.0D0
      XLJ  = LOG(AJ)
      A23  = AJ**(2.0D0/3.0D0)
      AM13 = AJ**(-1.0D0/3.0D0)
      AM43 = AM13/AJ
      AM73 = AM43/AJ
!
      U(1)   = 0.5D0*XMU*(A23*BI1 - 3.0D0 - 2.0D0*XLJ)
     1       + 0.5D0*XLAM*XLJ**2
      UI1(1) = 0.5D0*XMU*A23
      UI1(2) = 0.0D0
      UI1(3) = 0.5D0*XMU*(2.0D0*AM13*BI1/3.0D0 - 2.0D0/AJ)
     1       + XLAM*XLJ/AJ
      UI2(3) = 0.5D0*XMU*(-2.0D0*AM43*BI1/9.0D0 + 2.0D0/AJ**2)
     1       + XLAM*(1.0D0 - XLJ)/AJ**2
      UI2(5) = XMU*AM13
      UI3(4) = -XMU*AM43/9.0D0
      UI3(6) = 0.5D0*XMU*(4.0D0*AM73*BI1/27.0D0 - 4.0D0/AJ**3)
     1       + XLAM*(2.0D0*XLJ - 3.0D0)/AJ**3
      RETURN
      END
