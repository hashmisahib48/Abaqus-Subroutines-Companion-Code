#!/bin/sh
# builds and runs the driver with the three UHYPER routines
A=/home/claude/vol2/lib/aba
mkdir -p ../verify/out
for m in mr gent cnh cnh_bug; do
  gfortran -ffixed-form -std=legacy -I$A -o ../verify/out/drv_$m ex2_drv.f ex2_uhyper_$m.f $A/stubs.f || exit 1
done
cd ../verify/out
run() { # model inc props...
  mkdir -p $1_$2; ( cd $1_$2; printf "%s\n%s\n" "$3" "$4" | ../drv_$1 ); }
run mr 1 "2 1" "0.5 0.1"
run mr 0 "3 0" "0.5 0.1 0.02"
run gent 1 "3 1" "1.0 30.0 0.3"
run gent 0 "4 0" "1.0 30.0 0.3 0.02"
run cnh 0 "2 0" "0.6 2.9"
run cnh_bug 0 "2 0" "0.6 2.9"
mkdir -p mr_neg; ( cd mr_neg; printf "2 1\n0.5 -0.1\n" | ../drv_mr )
