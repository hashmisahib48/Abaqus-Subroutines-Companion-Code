      SUBROUTINE UHYPER(BI1,BI2,AJ,U,UI1,UI2,UI3,TEMP,NOEL,
     1 CMNAME,INCMPFLAG,NUMSTATEV,STATEV,NUMFIELDV,FIELDV,
     2 FIELDVINC,NUMPROPS,PROPS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION U(2),UI1(3),UI2(6),UI3(6),STATEV(*),FIELDV(*),
     1 FIELDVINC(*),PROPS(*)
!
!     Gent model with a logarithmic I2 term, Eq. (2.6-1):
!        U = -(MU JM/2) ln(1 - (I1bar-3)/JM) + C2 ln(I2bar/3)
!            + (J - 1)**2 / D1
!     PROPS(1) = MU (MPa)   PROPS(2) = JM (-)   PROPS(3) = C2 (MPa)
!     PROPS(4) = D1 (1/MPa), needed only if INCMPFLAG = 0
!     Beyond X0 = 0.99 of the limiting I1bar the logarithm is replaced
!     by its second-order Taylor polynomial (UHYPER has no PNEWDT).
!
      PARAMETER (X0 = 0.99D0)
!
      IF (NUMPROPS .LT. 3 .OR. (INCMPFLAG .EQ. 0 .AND.
     1    NUMPROPS .LT. 4)) THEN
         WRITE(7,*) 'UHYPER: too few properties'
         CALL XIT
      ENDIF
      XMU = PROPS(1)
      XJM = PROPS(2)
      C2  = PROPS(3)
      DO K = 1, 6
         UI2(K) = 0.0D0
         UI3(K) = 0.0D0
      ENDDO
      UI1(3) = 0.0D0
!
      X = (BI1 - 3.0D0)/XJM
      IF (X .LT. X0) THEN
         F  = -LOG(1.0D0 - X)
         F1 = 1.0D0/(1.0D0 - X)
         F2 = F1*F1
      ELSE
         D  = 1.0D0 - X0
         DX = X - X0
         F  = -LOG(D) + DX/D + 0.5D0*(DX/D)**2
         F1 = (1.0D0 + DX/D)/D
         F2 = 1.0D0/D**2
      ENDIF
      G = 0.5D0*XMU*XJM
      U(2)   = G*F + C2*LOG(BI2/3.0D0)
      U(1)   = U(2)
      UI1(1) = 0.5D0*XMU*F1
      UI1(2) = C2/BI2
      UI2(1) = 0.5D0*XMU*F2/XJM
      UI2(2) = -C2/BI2**2
!
      IF (INCMPFLAG .EQ. 0) THEN
         D1     = PROPS(4)
         U(1)   = U(1) + (AJ - 1.0D0)**2/D1
         UI1(3) = 2.0D0*(AJ - 1.0D0)/D1
         UI2(3) = 2.0D0/D1
      ENDIF
      RETURN
      END
