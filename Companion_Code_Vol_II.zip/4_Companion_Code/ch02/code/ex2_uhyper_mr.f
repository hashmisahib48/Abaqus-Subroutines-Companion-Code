      SUBROUTINE UHYPER(BI1,BI2,AJ,U,UI1,UI2,UI3,TEMP,NOEL,
     1 CMNAME,INCMPFLAG,NUMSTATEV,STATEV,NUMFIELDV,FIELDV,
     2 FIELDVINC,NUMPROPS,PROPS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION U(2),UI1(3),UI2(6),UI3(6),STATEV(*),FIELDV(*),
     1 FIELDVINC(*),PROPS(*)
!
!     Mooney-Rivlin, Eq. (2.4-1):
!        U = C10 (I1bar - 3) + C01 (I2bar - 3) + (J - 1)**2 / D1
!     PROPS(1) = C10 (MPa)   PROPS(2) = C01 (MPa)
!     PROPS(3) = D1 (1/MPa), needed only if INCMPFLAG = 0
!
      IF (NUMPROPS .LT. 2 .OR. (INCMPFLAG .EQ. 0 .AND.
     1    NUMPROPS .LT. 3)) THEN
         WRITE(7,*) 'UHYPER: too few properties'
         CALL XIT
      ENDIF
      C10 = PROPS(1)
      C01 = PROPS(2)
      D1  = 1.0D0
      DO K = 1, 6
         UI2(K) = 0.0D0
         UI3(K) = 0.0D0
      ENDDO
      UI1(3) = 0.0D0
!
!     deviatoric part and its first derivatives
      U(2)   = C10*(BI1 - 3.0D0) + C01*(BI2 - 3.0D0)
      U(1)   = U(2)
      UI1(1) = C10
      UI1(2) = C01
!
!     volumetric part, only for TYPE=COMPRESSIBLE
      IF (INCMPFLAG .EQ. 0) THEN
         D1 = PROPS(3)
         IF (D1 .LE. 0.0D0) THEN
            WRITE(7,*) 'UHYPER: D1 must be positive'
            CALL XIT
         ENDIF
         U(1)   = U(1) + (AJ - 1.0D0)**2/D1
         UI1(3) = 2.0D0*(AJ - 1.0D0)/D1
         UI2(3) = 2.0D0/D1
      ENDIF
      RETURN
      END
