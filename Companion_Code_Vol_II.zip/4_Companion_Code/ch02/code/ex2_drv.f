      PROGRAM K2DRV
!
!     Driver for UHYPER (Chapter 2).  Calls UHYPER as Abaqus would and
!     performs the tests of Sections 2.4 to 2.7.  Reads from unit 5:
!        NP, INCMPFLAG   then   PROPS(1..NP)
!     and writes the result files out_*.txt in the current directory.
!
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION U(2),UI1(3),UI2(6),UI3(6),F(3,3),SIG(3,3),E(3)
      DIMENSION A(3,3),A2(3,3),XL(3),S3(3)
      COMMON /K2P/ PROPS(20), NP, INC
      READ(5,*) NP, INC
      READ(5,*) (PROPS(I), I = 1, NP)
!
!     ---- 1. finite-difference test of the derivative arrays --------
      OPEN(10, FILE='out_fd.txt')
      DO IST = 1, 5
         IF (IST .EQ. 1) THEN
            B1 = 3.5D0
            B2 = 3.4D0
            AJ = 1.0D0
         ELSEIF (IST .EQ. 2) THEN
            B1 = 4.2D0
            B2 = 5.0D0
            AJ = 0.9D0
         ELSEIF (IST .EQ. 3) THEN
            B1 = 6.0D0
            B2 = 9.5D0
            AJ = 1.3D0
         ELSEIF (IST .EQ. 4) THEN
            B1 = 3.1D0
            B2 = 3.2D0
            AJ = 0.8D0
         ELSE
            B1 = 32.9D0
            B2 = 40.0D0
            AJ = 1.1D0
         ENDIF
         IF (INC .EQ. 1) AJ = 1.0D0
         CALL K2_FDCHK(B1, B2, AJ, 1.0D-5, E1, E2, E3)
         WRITE(10,'(A,I2,3(1X,ES12.4))') 'STATE', IST, E1, E2, E3
      ENDDO
!     step scan at state 2 (Fig. 2.5-1)
      IF (INC .EQ. 1) THEN
         AJ = 1.0D0
      ELSE
         AJ = 0.9D0
      ENDIF
      DO K = 1, 9
         H = 10.0D0**(-K)
         CALL K2_FDCHK(4.2D0, 5.0D0, AJ, H, E1, E2, E3)
         WRITE(10,'(A,1X,ES9.2,3(1X,ES12.4))') 'SCAN', H, E1, E2, E3
      ENDDO
      CLOSE(10)
!
!     ---- 2. homogeneous deformations -------------------------------
      OPEN(11, FILE='out_hom.txt')
      DO IM = 1, 3
         DO K = 0, 20
            XLAMB = 1.0D0 + 0.25D0*K
            IF (K .EQ. 0) XLAMB = 1.0D0
            CALL K2_HOM(IM, XLAMB, P1, XLAT)
            WRITE(11,'(I2,3(1X,ES22.14))') IM, XLAMB, XLAT, P1
         ENDDO
      ENDDO
      DO K = 0, 10
         G = 0.2D0*K
         DO I = 1, 3
            DO J = 1, 3
               F(I,J) = 0.0D0
            ENDDO
            F(I,I) = 1.0D0
         ENDDO
         F(1,2) = G
         CALL K2_CAUCHY(F, SIG)
         WRITE(11,'(A,4(1X,ES22.14))') 'SHEAR', G, SIG(1,2),
     1      SIG(1,1)-SIG(2,2), SIG(2,2)-SIG(3,3)
      ENDDO
      DO K = 0, 10
         XLAMB = 0.5D0 + 0.1D0*K
         DO I = 1, 3
            XL(I) = XLAMB
         ENDDO
         CALL K2_SIGD(XL, S3)
         WRITE(11,'(A,2(1X,ES22.14))') 'HYD', XLAMB, S3(1)
      ENDDO
      CLOSE(11)
!
!     ---- 3. second derivatives along a path ------------------------
      OPEN(12, FILE='out_tan.txt')
      Q = 0.5D0
      IF (INC .EQ. 0) Q = 0.3D0
      DO K = 1, 6
         XLAMB = 1.0D0 + 0.4D0*K
         CALL K2_PATH(XLAMB, Q, W1C, W1F, W2C, W2F)
         WRITE(12,'(F6.2,4(1X,ES22.14))') XLAMB, W1C, W1F, W2C, W2F
      ENDDO
      CLOSE(12)
!
!     ---- 4. Hessian in the logarithmic stretches (Drucker) ---------
      OPEN(13, FILE='out_dr.txt')
      N = 60
      DO I = 0, N
         DO J = 0, N
            E(1) = -1.2D0 + 2.4D0*I/N
            E(2) = -1.2D0 + 2.4D0*J/N
            E(3) = -E(1) - E(2)
            CALL K2_HESS(E, A)
            WRITE(13,'(3(1X,F8.4),6(1X,ES14.6))') E(1), E(2), E(3),
     1         A(1,1), A(2,2), A(3,3), A(1,2), A(1,3), A(2,3)
         ENDDO
      ENDDO
      CLOSE(13)
      IF (INC .EQ. 0) THEN
         OPEN(14, FILE='out_drv.txt')
         DO I = -12, 12
            E(1) = 0.0D0
            E(2) = 0.0D0
            E(3) = 0.0D0
            S = 0.1D0*I
            E(1) = S/3.0D0
            E(2) = S/3.0D0
            E(3) = S/3.0D0
            CALL K2_HESS(E, A)
            WRITE(14,'(F8.4,1X,ES14.6)') S, A(1,1)+A(2,2)+A(3,3)
     1         + 2.0D0*(A(1,2)+A(1,3)+A(2,3))
         ENDDO
         CLOSE(14)
      ENDIF
!     chain rule against differences of the stresses
      OPEN(15, FILE='out_hess.txt')
      DO IST = 1, 3
         E(1) = 0.3D0*IST
         E(2) = -0.1D0*IST
         E(3) = 0.2D0 - 0.05D0*IST
         IF (INC .EQ. 1) E(3) = -E(1) - E(2)
         CALL K2_HESS(E, A)
         CALL K2_HESSFD(E, A2)
         D = 0.0D0
         X = 0.0D0
         DO I = 1, 3
            DO J = 1, 3
               D = MAX(D, ABS(A(I,J) - A2(I,J)))
               X = MAX(X, ABS(A(I,J)))
            ENDDO
         ENDDO
         WRITE(15,'(A,I2,2(1X,ES12.4))') 'HESS', IST, D, D/X
      ENDDO
      CLOSE(15)
      END
!
!-----------------------------------------------------------------------
      SUBROUTINE K2_EVAL(BI1, BI2, AJ, U, UI1, UI2, UI3)
!     calls UHYPER with dummy values for the arguments it does not use
      IMPLICIT REAL*8 (A-H,O-Z)
      CHARACTER*80 CMNAME
      DIMENSION U(2),UI1(3),UI2(6),UI3(6),STATEV(1),FIELDV(1),
     1 FIELDVINC(1)
      COMMON /K2P/ PROPS(20), NP, INC
      CMNAME = 'DRIVER'
      CALL UHYPER(BI1,BI2,AJ,U,UI1,UI2,UI3,20.0D0,1,CMNAME,INC,0,
     1 STATEV,0,FIELDV,FIELDVINC,NP,PROPS)
      RETURN
      END
!
!-----------------------------------------------------------------------
      SUBROUTINE K2_INVAR(F, BI1, BI2, AJ)
!     invariants of Eq. (2.2-1) from the deformation gradient
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION F(3,3), B(3,3)
      DO I = 1, 3
         DO J = 1, 3
            B(I,J) = F(I,1)*F(J,1) + F(I,2)*F(J,2) + F(I,3)*F(J,3)
         ENDDO
      ENDDO
      AJ = F(1,1)*(F(2,2)*F(3,3) - F(2,3)*F(3,2))
     1   - F(1,2)*(F(2,1)*F(3,3) - F(2,3)*F(3,1))
     2   + F(1,3)*(F(2,1)*F(3,2) - F(2,2)*F(3,1))
      T1 = B(1,1) + B(2,2) + B(3,3)
      T2 = 0.0D0
      DO I = 1, 3
         DO J = 1, 3
            T2 = T2 + B(I,J)*B(J,I)
         ENDDO
      ENDDO
      BI1 = AJ**(-2.0D0/3.0D0)*T1
      BI2 = AJ**(-4.0D0/3.0D0)*0.5D0*(T1*T1 - T2)
      RETURN
      END
!
!-----------------------------------------------------------------------
      SUBROUTINE K2_CAUCHY(F, SIG)
!     Cauchy stress from the first derivatives, Eq. (2.2-3).  For an
!     incompressible material the hydrostatic part is not determined.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION F(3,3), SIG(3,3), B(3,3), BB(3,3), BB2(3,3), T(3,3)
      DIMENSION U(2),UI1(3),UI2(6),UI3(6)
      COMMON /K2P/ PROPS(20), NP, INC
      CALL K2_INVAR(F, BI1, BI2, AJ)
      CALL K2_EVAL(BI1, BI2, AJ, U, UI1, UI2, UI3)
      C = AJ**(-2.0D0/3.0D0)
      DO I = 1, 3
         DO J = 1, 3
            B(I,J) = F(I,1)*F(J,1) + F(I,2)*F(J,2) + F(I,3)*F(J,3)
            BB(I,J) = C*B(I,J)
         ENDDO
      ENDDO
      DO I = 1, 3
         DO J = 1, 3
            BB2(I,J) = BB(I,1)*BB(1,J) + BB(I,2)*BB(2,J)
     1               + BB(I,3)*BB(3,J)
         ENDDO
      ENDDO
      TR = 0.0D0
      DO I = 1, 3
         DO J = 1, 3
            T(I,J) = (UI1(1) + BI1*UI1(2))*BB(I,J) - UI1(2)*BB2(I,J)
         ENDDO
         TR = TR + T(I,I)
      ENDDO
      DO I = 1, 3
         DO J = 1, 3
            SIG(I,J) = 2.0D0/AJ*T(I,J)
         ENDDO
         SIG(I,I) = SIG(I,I) - 2.0D0/AJ*TR/3.0D0
         IF (INC .EQ. 0) SIG(I,I) = SIG(I,I) + UI1(3)
      ENDDO
      RETURN
      END
!
!-----------------------------------------------------------------------
      SUBROUTINE K2_SIGD(XL, S)
!     principal Cauchy stresses for F = diag(XL)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION XL(3), S(3), F(3,3), SIG(3,3)
      DO I = 1, 3
         DO J = 1, 3
            F(I,J) = 0.0D0
         ENDDO
         F(I,I) = XL(I)
      ENDDO
      CALL K2_CAUCHY(F, SIG)
      DO I = 1, 3
         S(I) = SIG(I,I)
      ENDDO
      RETURN
      END
!
!-----------------------------------------------------------------------
      SUBROUTINE K2_HOM(MODE, XLAMB, P1, XLAT)
!     MODE 1 uniaxial, 2 equibiaxial, 3 planar tension.  Returns the
!     nominal stress P1 = J sigma_1 / lambda_1 and the free stretch.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION XL(3), S(3)
      COMMON /K2P/ PROPS(20), NP, INC
      XL(1) = XLAMB
      IF (INC .EQ. 1) THEN
         IF (MODE .EQ. 1) XLAT = XLAMB**(-0.5D0)
         IF (MODE .EQ. 2) XLAT = XLAMB**(-2.0D0)
         IF (MODE .EQ. 3) XLAT = 1.0D0/XLAMB
      ELSE
!        bisection on the lateral stretch so that the free stress is 0
         XLO = 0.002D0
         XHI = 2.0D0
         DO IT = 1, 200
            XLAT = 0.5D0*(XLO + XHI)
            CALL K2_SETL(MODE, XLAMB, XLAT, XL)
            CALL K2_SIGD(XL, S)
            IF (S(3) .GT. 0.0D0) THEN
               XHI = XLAT
            ELSE
               XLO = XLAT
            ENDIF
         ENDDO
      ENDIF
      CALL K2_SETL(MODE, XLAMB, XLAT, XL)
      CALL K2_SIGD(XL, S)
      AJ = XL(1)*XL(2)*XL(3)
      IF (INC .EQ. 1) THEN
         P1 = (S(1) - S(3))/XLAMB
      ELSE
         P1 = AJ*S(1)/XLAMB
      ENDIF
      RETURN
      END
!
      SUBROUTINE K2_SETL(MODE, XLAMB, XLAT, XL)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION XL(3)
      XL(1) = XLAMB
      IF (MODE .EQ. 1) THEN
         XL(2) = XLAT
      ELSEIF (MODE .EQ. 2) THEN
         XL(2) = XLAMB
      ELSE
         XL(2) = 1.0D0
      ENDIF
      XL(3) = XLAT
      RETURN
      END
!
!-----------------------------------------------------------------------
      SUBROUTINE K2_FDCHK(B1, B2, AJ, H, E1, E2, E3)
!     largest relative errors of UI1, UI2 and UI3 against central
!     differences of U(1), UI1 and UI2 (Eqs. 2.5-1 to 2.5-3)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION U(2),UI1(3),UI2(6),UI3(6),X(3)
      DIMENSION UP1(3),UM1(3),UP2(6),UM2(6),D1(3),D2(6,3),D3(6)
      DIMENSION UI1P(3,3),UI1M(3,3),UI2P(6,3),UI2M(6,3),UU(2)
      COMMON /K2P/ PROPS(20), NP, INC
      X(1) = B1
      X(2) = B2
      X(3) = AJ
      NV = 3
      IF (INC .EQ. 1) NV = 2
      CALL K2_EVAL(B1, B2, AJ, U, UI1, UI2, UI3)
      DO K = 1, NV
         HK = H*MAX(1.0D0, ABS(X(K)))
         CALL K2_EV2(X, K, HK, UU, UP1, UP2, DUM)
         CALL K2_EV2(X, K, -HK, UU, UM1, UM2, DUM)
         D1(K) = 0.0D0
         DO L = 1, 3
            UI1P(L,K) = UP1(L)
            UI1M(L,K) = UM1(L)
         ENDDO
         DO L = 1, 6
            UI2P(L,K) = UP2(L)
            UI2M(L,K) = UM2(L)
         ENDDO
      ENDDO
!     first derivatives from U(1)
      E1 = 0.0D0
      DO K = 1, NV
         HK = H*MAX(1.0D0, ABS(X(K)))
         CALL K2_EV2(X, K, HK, UU, UP1, UP2, DUM)
         UPLUS = UU(1)
         CALL K2_EV2(X, K, -HK, UU, UM1, UM2, DUM)
         D = (UPLUS - UU(1))/(2.0D0*HK)
         E1 = MAX(E1, ABS(D - UI1(K))/MAX(1.0D0, ABS(UI1(K))))
      ENDDO
!     second derivatives from UI1 (UI2 index: 11,22,JJ,12,1J,2J)
      E2 = 0.0D0
      DO K = 1, NV
         HK = H*MAX(1.0D0, ABS(X(K)))
         DO L = 1, NV
            DD = (UI1P(L,K) - UI1M(L,K))/(2.0D0*HK)
            CALL K2_IDX2(K, L, M)
            E2 = MAX(E2, ABS(DD - UI2(M))/MAX(1.0D0, ABS(UI2(M))))
         ENDDO
      ENDDO
!     third derivatives from UI2: d/dJ of UI2 (UI3 index: 11J, 12J,
!     22J, 1JJ, 2JJ, JJJ)
      E3 = 0.0D0
      IF (INC .EQ. 0) THEN
         HK = H*MAX(1.0D0, ABS(X(3)))
         DO M = 1, 6
            D3(M) = (UI2P(M,3) - UI2M(M,3))/(2.0D0*HK)
         ENDDO
         E3 = MAX(E3, ABS(D3(1) - UI3(1))/MAX(1.0D0,ABS(UI3(1))))
         E3 = MAX(E3, ABS(D3(4) - UI3(2))/MAX(1.0D0,ABS(UI3(2))))
         E3 = MAX(E3, ABS(D3(2) - UI3(3))/MAX(1.0D0,ABS(UI3(3))))
         E3 = MAX(E3, ABS(D3(5) - UI3(4))/MAX(1.0D0,ABS(UI3(4))))
         E3 = MAX(E3, ABS(D3(6) - UI3(5))/MAX(1.0D0,ABS(UI3(5))))
         E3 = MAX(E3, ABS(D3(3) - UI3(6))/MAX(1.0D0,ABS(UI3(6))))
      ENDIF
      RETURN
      END
!
      SUBROUTINE K2_EV2(X, K, HK, UU, UI1, UI2, DUM)
!     UHYPER evaluated at X with component K displaced by HK
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION X(3), Y(3), UU(2), UI1(3), UI2(6), UI3(6)
      DO L = 1, 3
         Y(L) = X(L)
      ENDDO
      Y(K) = Y(K) + HK
      CALL K2_EVAL(Y(1), Y(2), Y(3), UU, UI1, UI2, UI3)
      DUM = 0.0D0
      RETURN
      END
!
      SUBROUTINE K2_IDX2(K, L, M)
!     position in UI2 of the derivative with respect to variables K, L
      IF (K .EQ. L) THEN
         M = K
      ELSEIF (K + L .EQ. 3) THEN
         M = 4
      ELSEIF (K + L .EQ. 4) THEN
         M = 5
      ELSE
         M = 6
      ENDIF
      RETURN
      END
!
!-----------------------------------------------------------------------
      SUBROUTINE K2_PATH(XLAMB, Q, W1C, W1F, W2C, W2F)
!     first and second derivative of U along F = diag(l, l**-Q, l**-Q),
!     by the chain rule from UI1 and UI2 (suffix C) and by five-point
!     differences of U itself (suffix F)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION U(2),UI1(3),UI2(6),UI3(6),V(3),V1(3),V2(3),AM(3,3)
      DIMENSION W(-2:2), AV(3,-2:2)
      H = 1.0D-3
      DO K = -2, 2
         CALL K2_PINV(XLAMB + K*H, Q, AV(1,K), AV(2,K), AV(3,K))
         CALL K2_EVAL(AV(1,K), AV(2,K), AV(3,K), U, UI1, UI2, UI3)
         W(K) = U(1)
      ENDDO
      DO L = 1, 3
         V1(L) = (AV(L,-2) - 8.0D0*AV(L,-1) + 8.0D0*AV(L,1)
     1          - AV(L,2))/(12.0D0*H)
         V2(L) = (-AV(L,-2) + 16.0D0*AV(L,-1) - 30.0D0*AV(L,0)
     1          + 16.0D0*AV(L,1) - AV(L,2))/(12.0D0*H*H)
      ENDDO
      CALL K2_EVAL(AV(1,0), AV(2,0), AV(3,0), U, UI1, UI2, UI3)
      AM(1,1) = UI2(1)
      AM(2,2) = UI2(2)
      AM(3,3) = UI2(3)
      AM(1,2) = UI2(4)
      AM(2,1) = UI2(4)
      AM(1,3) = UI2(5)
      AM(3,1) = UI2(5)
      AM(2,3) = UI2(6)
      AM(3,2) = UI2(6)
      W1C = 0.0D0
      W2C = 0.0D0
      DO L = 1, 3
         W1C = W1C + UI1(L)*V1(L)
         W2C = W2C + UI1(L)*V2(L)
         DO M = 1, 3
            W2C = W2C + AM(L,M)*V1(L)*V1(M)
         ENDDO
      ENDDO
      W1F = (W(-2) - 8.0D0*W(-1) + 8.0D0*W(1) - W(2))/(12.0D0*H)
      W2F = (-W(-2) + 16.0D0*W(-1) - 30.0D0*W(0) + 16.0D0*W(1)
     1     - W(2))/(12.0D0*H*H)
      RETURN
      END
!
      SUBROUTINE K2_PINV(XLAMB, Q, BI1, BI2, AJ)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION F(3,3)
      DO I = 1, 3
         DO J = 1, 3
            F(I,J) = 0.0D0
         ENDDO
      ENDDO
      F(1,1) = XLAMB
      F(2,2) = XLAMB**(-Q)
      F(3,3) = XLAMB**(-Q)
      CALL K2_INVAR(F, BI1, BI2, AJ)
      RETURN
      END
!
!-----------------------------------------------------------------------
      SUBROUTINE K2_HESS(E, A)
!     A(i,j) = d2U/de_i de_j in the logarithmic principal stretches
!     e_i, Eq. (2.7-2), from UI1 and UI2 by the chain rule
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION E(3), A(3,3), Z(3), G(3,3), H(3,3,3), AM(3,3)
      DIMENSION U(2),UI1(3),UI2(6),UI3(6)
      S = E(1) + E(2) + E(3)
      AJ = EXP(S)
      D4 = 0.0D0
      BI1 = 0.0D0
      DO I = 1, 3
         Z(I) = EXP(2.0D0*E(I) - 2.0D0*S/3.0D0)
         D4 = D4 + Z(I)**2
         BI1 = BI1 + Z(I)
      ENDDO
      BI2 = Z(1)*Z(2) + Z(1)*Z(3) + Z(2)*Z(3)
      CALL K2_EVAL(BI1, BI2, AJ, U, UI1, UI2, UI3)
      DO I = 1, 3
         G(1,I) = 2.0D0*Z(I) - 2.0D0*BI1/3.0D0
         G(2,I) = BI1*G(1,I) - 2.0D0*Z(I)**2 + 2.0D0*D4/3.0D0
         G(3,I) = AJ
         DO J = 1, 3
            DEL = 0.0D0
            IF (I .EQ. J) DEL = 1.0D0
            H(1,I,J) = 4.0D0*Z(I)*DEL - 4.0D0*(Z(I) + Z(J))/3.0D0
     1               + 4.0D0*BI1/9.0D0
            H(3,I,J) = AJ
         ENDDO
      ENDDO
      DO I = 1, 3
         DO J = 1, 3
            DEL = 0.0D0
            IF (I .EQ. J) DEL = 1.0D0
            H(2,I,J) = G(1,I)*G(1,J) + BI1*H(1,I,J)
     1        - 8.0D0*Z(I)**2*DEL + 8.0D0*(Z(I)**2 + Z(J)**2)/3.0D0
     2        - 8.0D0*D4/9.0D0
         ENDDO
      ENDDO
      AM(1,1) = UI2(1)
      AM(2,2) = UI2(2)
      AM(3,3) = UI2(3)
      AM(1,2) = UI2(4)
      AM(2,1) = UI2(4)
      AM(1,3) = UI2(5)
      AM(3,1) = UI2(5)
      AM(2,3) = UI2(6)
      AM(3,2) = UI2(6)
      DO I = 1, 3
         DO J = 1, 3
            A(I,J) = 0.0D0
            DO K = 1, 3
               A(I,J) = A(I,J) + UI1(K)*H(K,I,J)
               DO L = 1, 3
                  A(I,J) = A(I,J) + AM(K,L)*G(K,I)*G(L,J)
               ENDDO
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K2_TAU(E, TAU)
!     Kirchhoff principal stresses tau_i = dU/de_i from UI1 only
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION E(3), TAU(3), Z(3), U(2), UI1(3), UI2(6), UI3(6)
      S = E(1) + E(2) + E(3)
      AJ = EXP(S)
      D4 = 0.0D0
      BI1 = 0.0D0
      DO I = 1, 3
         Z(I) = EXP(2.0D0*E(I) - 2.0D0*S/3.0D0)
         D4 = D4 + Z(I)**2
         BI1 = BI1 + Z(I)
      ENDDO
      BI2 = Z(1)*Z(2) + Z(1)*Z(3) + Z(2)*Z(3)
      CALL K2_EVAL(BI1, BI2, AJ, U, UI1, UI2, UI3)
      DO I = 1, 3
         G1 = 2.0D0*Z(I) - 2.0D0*BI1/3.0D0
         G2 = BI1*G1 - 2.0D0*Z(I)**2 + 2.0D0*D4/3.0D0
         TAU(I) = UI1(1)*G1 + UI1(2)*G2 + UI1(3)*AJ
      ENDDO
      RETURN
      END
!
      SUBROUTINE K2_HESSFD(E, A)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION E(3), A(3,3), EP(3), TP(3), TM(3)
      H = 1.0D-6
      DO J = 1, 3
         DO I = 1, 3
            EP(I) = E(I)
         ENDDO
         EP(J) = E(J) + H
         CALL K2_TAU(EP, TP)
         EP(J) = E(J) - H
         CALL K2_TAU(EP, TM)
         DO I = 1, 3
            A(I,J) = (TP(I) - TM(I))/(2.0D0*H)
         ENDDO
      ENDDO
      RETURN
      END
