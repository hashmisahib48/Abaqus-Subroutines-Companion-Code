import sys, json; sys.path.insert(0,'/home/claude/vol2/lib')
from figstyle import *
import matplotlib.pyplot as plt, numpy as np, os
from matplotlib.patches import FancyBboxPatch
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from ref import *
OUTD='..'; R=json.load(open('../out/results.json')); NU=json.load(open('../out/nums.json'))
FS=7.8
def tx(ax,x,y,s,fs=FS,**k):
    k.setdefault('fontsize',fs); ax.text(x,y,s,**k)
def sv(fig,n): fig.savefig(f'{OUTD}/{n}',dpi=240,bbox_inches='tight',pad_inches=0.04,facecolor='white'); plt.close(fig)
def style(a,fs=8):
    a.tick_params(labelsize=7.4); a.xaxis.label.set_size(fs); a.yaxis.label.set_size(fs)
def cap(ax,t,y=-0.30): ax.text(0.5,y,t,transform=ax.transAxes,ha='center',va='top',fontsize=7.6,color=GREY)
CT={80:BLUE,100:GREEN,120:OR,140:RED}
# ---------- Fig 8.2-1 ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.6,2.0),dpi=240)
al=np.linspace(0,1,400)
for T,c in CT.items():
    a1.plot(al,[rate(a,T)*1e4 for a in al],color=c,lw=1.2)
    Tf,ts=Tcycle([(0,T),(14400,T)]); A=solve(Tf,ts); t=np.linspace(0,14400,300)
    a2.plot(t/3600,[A(x) for x in t],color=c,lw=1.2); tx(a2,4.05,A(14400*4/4 if False else 3600*4)+{80:-0.03,100:-0.02,120:-0.03,140:0.0}[T],f'{T}',color=c,ha='left',fontsize=7.2,va='center')
a1.set_xlabel('degree of cure α'); a1.set_ylabel('rate  α̇  (10$^{-4}$ s$^{-1}$)'); style(a1)
a1.plot([NU['peak120'][0]],[NU['peak120'][1]*1e4],'o',color=OR,ms=3.5)
tx(a1,0.03,2.65,'peak, 120 °C',color=OR,ha='left',fontsize=7.4,va='bottom')
tx(a1,0.05,5.55,'140 °C',color=RED,ha='left',fontsize=7.2); a1.set_ylim(0,6.2)
a2.set_xlabel('time  (h)'); a2.set_ylabel('degree of cure α'); style(a2); a2.set_ylim(0,1.0); a2.set_xlim(0,4)
cap(a1,'(a) rate against α'); cap(a2,'(b) isothermal cure')
fig.subplots_adjust(wspace=0.38); sv(fig,'fig_rate.png')
# ---------- Fig 8.3-1: division of work ----------
fig,ax=plt.subplots(figsize=(4.6,2.15),dpi=240); ax.set_xlim(-1,101); ax.set_ylim(-1,47); ax.axis('off')
def bx(x,y,w,h,t,fc,ec,tc=NAVY,fs=7.6,b=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.25,rounding_size=1.2',fc=fc,ec=ec,lw=0.9))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,color=tc,weight='bold' if b else 'normal',linespacing=1.3)
bx(0,28,30,15,'Abaqus\nDOC, TEMP, DTIME,\nSTATEVOLD, PROPS',LB,BLUE,fs=7.4)
bx(36,28,28,15,'UCURE\nK8_RATE',PINK,RED,tc=RED,b=True,fs=8)
bx(70,28,30,15,'Abaqus\nupdate of the degree\nof cure, Newton',LB,BLUE,fs=7.4)
arr(ax,(30.6,35.5),(35.4,35.5),c=BLUE); arr(ax,(64.6,35.5),(69.4,35.5),c=RED)
tx(ax,50,24.6,'DOCRATEARRAY(1) = α̇',fontsize=7.2,color=RED,ha='center'); tx(ax,50,21.4,'(2) = ∂α̇/∂α,   (3) = ∂α̇/∂T',fontsize=7.2,color=RED,ha='center')
bx(0,0,30,12,'heat generation\nρ H$_r$ α̇',LGREY,GREY,fs=7.4)
bx(36,0,28,12,'cure shrinkage\nε$^{cs}$ = −γ Δα',LGREY,GREY,fs=7.4)
bx(70,0,30,12,'properties through\na field variable (α)',LGREY,GREY,fs=7.4)
ax.plot([85,85],[27.6,18],color=GREY,lw=0.8); ax.plot([15,85],[18,18],color=GREY,lw=0.8)
for x in (15,50,85): arr(ax,(x,18),(x,12.9),c=GREY,lw=0.8)
sv(fig,'fig_flow.png')
# ---------- Fig 8.5-1: FD step ----------
d=np.loadtxt('../out/fd_grid.dat')
fig,ax=plt.subplots(figsize=(2.85,1.75),dpi=240)
ax.loglog(d[:,0],d[:,1],'-o',color=BLUE,ms=3,lw=1,label='∂α̇/∂α'); ax.loglog(d[:,0],d[:,2],'-s',color=OR,ms=3,lw=1,label='∂α̇/∂T')
ax.set_xlabel('step  h  (α, or °C)'); ax.set_ylabel('relative error ε'); style(ax); hh=np.array([1e-4,1e-1]); ax.loglog(hh,0.3*hh**2,color=GREY,lw=0.8,ls='--'); tx(ax,2e-3,1e-6,'∝ h$^2$',color=GREY,ha='left',fontsize=7.4)
ax.legend(fontsize=7.6,loc='upper center'); sv(fig,'fig_fd.png')
# ---------- Fig 8.6-1: isothermal ----------
Tf,ts=Tcycle([(0,120),(7200,120)]); A=solve(Tf,ts)
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.6,2.0),dpi=240)
import subprocess
def drv(inp): 
    return subprocess.run('cd ../code && ../out/k8drv',input=inp,shell=True,capture_output=True,text=True).stdout
def mkin(imode=1,itang=0,theta=1.0,dt=100.,tend=7200.,props=(1.0e5,8000.,5.0e3,6000.,1.2,1.8,-273.15),corners=((0,120.),(7200,120.)),t0=80.,dtad=120.,f='x.dat'):
    s=f"{imode} {itang} {theta} {dt} {tend}\n"+' '.join(repr(float(p)) for p in props)+f"\n{len(corners)}\n"
    s+=''.join(f"{t} {T}\n" for t,T in corners)+f"{t0} {dtad}\n../out/{f}\n"; return s
t=np.linspace(0,7200,200); a1.plot(t/3600,[A(x) for x in t],color=NAVY,lw=1.2,label='ODE')
for th,mk,c,l in ((1.0,'o',RED,'ϑ = 1'),(0.5,'s',BLUE,'ϑ = ½')):
    drv(mkin(theta=th,dt=450.,f='tmp.dat')); dd=np.loadtxt('../out/tmp.dat'); a1.plot(dd[:,0]/3600,dd[:,2],mk,color=c,ms=3.2,mfc='none',mew=0.8,label=l)
a1.set_xlabel('time (h)'); a1.set_ylabel('degree of cure α'); style(a1); a1.legend(fontsize=7.0,loc='lower right',bbox_to_anchor=(1.0,0.02)); a1.set_ylim(0,1.0); a1.set_xlim(0,2.05)
dts=[900,450,225,100,50,25,10]
for th,mk,c,l in ((1.0,'o',RED,'ϑ = 1'),(0.5,'s',BLUE,'ϑ = ½')):
    e=[R['iso'][f'{th}_{x}']['err_end'] for x in dts]; a2.loglog(dts,e,'-'+mk,color=c,ms=3,lw=1,label=l)
x=np.array([10,900.]); a2.loglog(x,8e-5*x/10,color=GREY,lw=0.7,ls='--'); a2.loglog(x,4e-8*(x/10)**2,color=GREY,lw=0.7,ls='--')
tx(a2,12,2e-5,'slope 1',color=GREY,ha='left',fontsize=7.2); tx(a2,150,3e-7,'slope 2',color=GREY,ha='left',fontsize=7.2)
a2.set_xlabel('Δt (s)'); a2.set_ylabel('error of α at 7200 s'); style(a2)
cap(a1,'(a) α(t) at 120 °C'); cap(a2,'(b) error at the end')
a2.set_ylim(1e-8,5e-2); fig.subplots_adjust(wspace=0.42); sv(fig,'fig_iso.png')
# ---------- Fig 8.6-2: ramp ----------
cor=((0,25.),(1900,120.),(5500,120.),(6700,180.),(10300,180.))
Tr,trr=Tcycle(list(cor)); Ar=solve(Tr,trr)
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.6,2.0),dpi=240)
t=np.linspace(0,10300,500); a1.plot(t/3600,[Tr(x) for x in t],color=GREY,lw=1,ls='--'); a1.set_ylim(0,200); a1.set_xlabel('time (h)'); a1.set_ylabel('temperature (°C)',color=GREY)
a1b=a1.twinx(); a1b.spines['right'].set_visible(True); a1b.plot(t/3600,[Ar(x) for x in t],color=NAVY,lw=1.2,label='ODE')
drv(mkin(theta=1.0,dt=200.,tend=10300.,corners=cor,f='tmp.dat')) if False else None
drv(mkin(theta=1.0,dt=100.,tend=10300.,corners=cor,f='tmp.dat')); dd=np.loadtxt('../out/tmp.dat'); a1b.plot(dd[::3,0]/3600,dd[::3,2],'o',color=RED,ms=2.8,mfc='none',mew=0.7,label='ϑ = 1, Δt = 100 s')
a1b.set_ylabel('degree of cure α'); a1b.set_ylim(0,1.05); style(a1); a1b.tick_params(labelsize=7.4); a1b.yaxis.label.set_size(8); pass
dts=[100,50,25,10]
for th,mk,c,l in ((1.0,'o',RED,'ϑ = 1'),(0.5,'s',BLUE,'ϑ = ½')):
    e=[R['ramp'][f'{th}_{x}']['err_max'] for x in dts]; a2.loglog(dts,e,'-'+mk,color=c,ms=3,lw=1,label=l)
x=np.array([10,100.]); a2.loglog(x,6e-4*x/10,color=GREY,lw=0.7,ls='--'); a2.loglog(x,2e-6*(x/10)**2,color=GREY,lw=0.7,ls='--')
a2.set_xlabel('Δt (s)'); a2.set_ylabel('largest error of α'); style(a2); a2.legend(fontsize=7.4,loc='lower right')
cap(a1,'(a) cycle (dashed) and α'); cap(a2,'(b) largest error'); tx(a1b,1.45,0.50,'α',color=NAVY,fontsize=8,ha='left'); tx(a1,0.2,138,'T',color=GREY,fontsize=8,ha='left')
a2.set_ylim(2e-6,5e-2); fig.subplots_adjust(wspace=0.85); sv(fig,'fig_ramp.png')
# ---------- Fig 8.7-1: adiabatic ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.6,2.05),dpi=240)
f=lambda t,y:[rate(y[0],80+120*y[0])]
from scipy.integrate import solve_ivp
s=solve_ivp(f,(0,14400),[0.],method='DOP853',rtol=1e-12,atol=1e-15,dense_output=True); t=np.linspace(0,14400,400); a=s.sol(t)[0]
a1.plot(t/3600,80+120*a,color=RED,lw=1.2); a1.set_ylim(60,220); a1.set_xlabel('time (h)'); a1.set_ylabel('temperature (°C)',color=RED)
a1b=a1.twinx(); a1b.spines['right'].set_visible(True); a1b.plot(t/3600,a,color=NAVY,lw=1.2); a1b.set_ylim(0,1.05); a1b.set_ylabel('degree of cure α'); a1b.tick_params(labelsize=7.4); a1b.yaxis.label.set_size(8)
d0=np.load('../out/ad_0_100.npy'); a1b.plot(d0[::4,0]/3600,d0[::4,2],'o',color=OR,ms=2.8,mfc='none',mew=0.7); tx(a1,0.1,205,'T',color=RED); tx(a1,3.45,142,'α',color=NAVY,ha='left')
style(a1); cap(a1,'(a) adiabatic cure (line: ODE)')
cl={0:(BLUE,'o','full'),1:(OR,'s','without ∂α̇/∂T'),2:(RED,'^','without both')}
res={k:np.load(f'../out/ad_res_{k}.npy') for k in (0,1,2)}
step=int(res[1][np.argmax(res[1][:,1]),0])
for k,(c,mk,l) in cl.items():
    r=res[k]; r=r[r[:,0]==step]; a2.semilogy(r[:,1],r[:,2],'-'+mk,color=c,ms=2.6,lw=0.9,label=l)
a2.set_xlabel('iteration'); a2.set_ylabel('residual |g|'); style(a2); a2.legend(fontsize=7.2,loc='upper right'); a2.set_ylim(1e-14,3)
cap(a2,'(b) one increment, three Jacobians')
fig.subplots_adjust(wspace=0.95); sv(fig,'fig_ad.png'); print('step',step)
for k in (0,1,2):
    r=res[k]; r=r[r[:,0]==step]; print(k,len(r))
