"""Independent reference solutions for Chapter 8 (Kamal-Sourour cure kinetics)."""
import numpy as np
from scipy.integrate import solve_ivp
# material of the chapter (s, K, degC)
A1,E1R,A2,E2R,M,N,T0K = 1.0e5, 8000.0, 5.0e3, 6000.0, 1.2, 1.8, -273.15
P=dict(A1=A1,E1R=E1R,A2=A2,E2R=E2R,m=M,n=N,abs0=T0K)
def rate(a,T,p=P):
    th=T-p['abs0']; a=min(max(a,0.0),1.0)
    k1=p['A1']*np.exp(-p['E1R']/th); k2=p['A2']*np.exp(-p['E2R']/th)
    return (k1+k2*a**p['m'])*(1-a)**p['n']
def Tcycle(segs):
    """segs: list of (t,T) corner points -> function T(t) and breakpoints"""
    ts=np.array([s[0] for s in segs]); Ts=np.array([s[1] for s in segs])
    return (lambda t: float(np.interp(t,ts,Ts))), ts
def solve(Tf,ts,a0=0.0,p=P,method='DOP853',rtol=1e-12,atol=1e-15,tev=None):
    out_t=[];out_a=[];a=a0;t0=ts[0]
    for k in range(len(ts)-1):
        s=solve_ivp(lambda t,y:[rate(y[0],Tf(t),p)],(ts[k],ts[k+1]),[a],method=method,rtol=rtol,atol=atol,dense_output=True)
        a=s.y[0,-1]
        out_t.append(s);
    def A(t):
        for k,s in enumerate(out_t):
            if t<=ts[k+1]+1e-9: return float(s.sol(min(max(t,ts[k]),ts[k+1]))[0])
        return float(a)
    return A
if __name__=='__main__':
    for T in (100,120,140):
        Tf,ts=Tcycle([(0,T),(10800,T)]); A=solve(Tf,ts)
        print(T,[round(A(t),4) for t in (600,1800,3600,7200,10800)])
