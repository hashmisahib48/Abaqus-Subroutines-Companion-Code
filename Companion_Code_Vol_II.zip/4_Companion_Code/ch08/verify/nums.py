import numpy as np, json
from scipy.optimize import minimize_scalar
from scipy.integrate import solve_ivp
from ref import *
def k12(T,p=P): th=T-p['abs0']; return p['A1']*np.exp(-p['E1R']/th), p['A2']*np.exp(-p['E2R']/th)
def derivs(a,T,p=P):
    th=T-p['abs0']; k1,k2=k12(T,p); B=1-a
    f=(k1+k2*a**p['m'])*B**p['n']
    fa=k2*p['m']*a**(p['m']-1)*B**p['n']-p['n']*(k1+k2*a**p['m'])*B**(p['n']-1)
    ft=(k1*p['E1R']+k2*a**p['m']*p['E2R'])*B**p['n']/th**2
    return k1,k2,f,fa,ft
N={}
# A1
N['A1']=derivs(0.3,100.0)
# peak at 120 C
r=minimize_scalar(lambda a:-rate(a,120.0),bounds=(0.01,0.99),method='bounded',options={'xatol':1e-12}); N['peak120']=(r.x,-r.fun)
# iso peak in time (ODE)
Tf,ts=Tcycle([(0,120),(7200,120)]); 
s=solve_ivp(lambda t,y:[rate(y[0],120.)],(0,7200),[0.],method='DOP853',rtol=1e-12,atol=1e-15,dense_output=True)
tt=np.linspace(0,7200,72001); aa=s.sol(tt)[0]; rr=np.array([rate(a,120.) for a in aa]); N['iso_peak_t']=(tt[rr.argmax()],rr.max())
# ramp peak
Tr,trr=Tcycle([(0,25),(1900,120),(5500,120),(6700,180),(10300,180)]); Ar=solve(Tr,trr); tt=np.linspace(0,10300,103001)
rr=np.array([rate(Ar(t),Tr(t)) for t in tt[::10]]); N['ramp_peak']=(tt[::10][rr.argmax()],rr.max())
# adiabatic
f=lambda t,y:[rate(y[0],80+120*y[0])]
s=solve_ivp(f,(0,14400),[0.],method='DOP853',rtol=1e-12,atol=1e-15,dense_output=True)
tt=np.linspace(0,14400,144001); aa=s.sol(tt)[0]; rr=np.array([rate(a,80+120*a) for a in aa]); N['ad_peak']=(tt[rr.argmax()],rr.max(),aa[rr.argmax()])
N['ad_T_end']=80+120*aa[-1]; N['ad_a_end']=aa[-1]
rho=1.25e-9; H=1.8e11; c=1.5e9
N['rhoH']=rho*H; N['qmax']=rho*H*rr.max(); N['dTad']=H/c
# A2
H2=3.0e5*1e6; c2=1.8e3*1e6; N['A2']=(H2,c2,H2/c2,60+0.95*H2/c2)
# A3 closed form
k1,k2=k12(120.0); tcl=lambda a:np.log((k1+k2*a)/(k1*(1-a)))/(k1+k2); N['A3']=(k1,k2,tcl(0.5),tcl(0.9),tcl(0.99))
N['A3_alpha']=[k1*(np.exp((k1+k2)*t)-1)/(k2+k1*np.exp((k1+k2)*t)) for t in (3600,7200)]
# shrinkage
g=0.02; E0=10.; Ei=3000.; 
for aend in (Ar(10300),):
    N['shr']=(aend,-g*aend,g*(E0*aend+(Ei-E0)*aend**2/2))
# B1
N['B1_alpha_star_120']=r.x
# B2 critical dt
def crit(T,m,fl,p=P):
    k1,k2=k12(T,p); fa0=k2*m*fl**(m-1)-p['n']*k1; return 1/fa0, fa0
N['B2']=(crit(120.,0.7,1e-8),crit(120.,0.7,1e-3))
# C2 diffusion control
def rate_d(a,T,C=40.,ac=0.85):
    th=T+273.15; k1,k2=k12(T); d=1/(1+np.exp(C*(a-ac))); return (k1+k2*a**P['m'])*(1-a)**P['n']*d
s=solve_ivp(lambda t,y:[rate_d(y[0],120.)],(0,36000),[0.],method='DOP853',rtol=1e-12,atol=1e-15,dense_output=True)
N['C2']=[float(s.sol(t)[0]) for t in (3600,7200,14400,36000)]
json.dump(N,open('../out/nums.json','w'),indent=1,default=float); print(json.dumps(N,indent=1,default=float))
