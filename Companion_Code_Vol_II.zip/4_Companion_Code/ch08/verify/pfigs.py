import sys, json; sys.path.insert(0,'/home/claude/vol2/lib')
from figstyle import *
import matplotlib.pyplot as plt, numpy as np, os
from matplotlib.patches import Rectangle
from scipy.integrate import solve_ivp
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from ref import *
from nums import derivs, k12
def tx(ax,x,y,s,fs=7.5,**k): k.setdefault('fontsize',fs); ax.text(x,y,s,**k)
def sv(fig,n): fig.savefig('../'+n,dpi=240,bbox_inches='tight',pad_inches=0.04,facecolor='white'); plt.close(fig)
def sty(a): a.tick_params(labelsize=7.5); a.xaxis.label.set_size(7.5); a.yaxis.label.set_size(7.5)
al=np.linspace(0,1,300)
# A1
fig,ax=plt.subplots(figsize=(2.4,1.4),dpi=240); T=100.; f=[rate(a,T)*1e4 for a in al]; ax.plot(al,f,color=BLUE,lw=1.2)
k1,k2,f0,fa,ft=derivs(0.3,T); ax.plot(0.3,f0*1e4,'o',color=RED,ms=4); xx=np.array([0.1,0.5]); ax.plot(xx,(f0+fa*(xx-0.3))*1e4,color=OR,lw=1,ls='--')
tx(ax,0.45,1.25,'α = 0.3, T = 100 °C',color=RED,ha='left'); tx(ax,0.05,0.12,'dashed: slope ∂α̇/∂α',color=OR,ha='left'); ax.set_ylim(0,1.5)
ax.set_xlabel('α'); ax.set_ylabel('α̇  (10$^{-4}$ s$^{-1}$)'); sty(ax); sv(fig,'p_8A1.png')
# A2
fig,(a1,a2)=plt.subplots(1,2,figsize=(3.0,1.25),dpi=240,gridspec_kw={'width_ratios':[0.8,1.2]})
a1.axis('off'); a1.add_patch(Rectangle((0.1,0.2),0.8,0.6,fc=LB,ec=BLUE,lw=1.2)); a1.add_patch(Rectangle((0.02,0.12),0.96,0.76,fc='none',ec=GREY,lw=0.8,ls='--'))
tx(a1,0.5,0.5,'ρ, c, H$_r$',ha='center',va='center',color=NAVY); tx(a1,0.5,0.02,'insulated',ha='center',color=GREY,fontsize=7.5); a1.set_xlim(0,1); a1.set_ylim(0,1)
a2.plot([0,1],[60,60+166.7],color=RED,lw=1.2); a2.set_xlabel('α'); a2.set_ylabel('T (°C)'); sty(a2); tx(a2,0.05,200,'slope H$_r$/c',color=RED,ha='left'); a2.plot(0.95,218.3,'o',color=NAVY,ms=3.5); tx(a2,0.9,232,'α = 0.95',ha='right',color=NAVY,fontsize=7.5); a2.set_ylim(40,250)
fig.subplots_adjust(wspace=0.45); sv(fig,'p_8A2.png')
# A3
k1,k2=k12(120.); t=np.linspace(0,10800,300); aa=k1*(np.exp((k1+k2)*t)-1)/(k2+k1*np.exp((k1+k2)*t))
fig,ax=plt.subplots(figsize=(2.4,1.35),dpi=240); ax.plot(t/3600,aa,color=BLUE,lw=1.2)
for a in (0.5,0.9): tt=np.log((k1+k2*a)/(k1*(1-a)))/(k1+k2); ax.plot([tt/3600],[a],'o',color=RED,ms=3.5); ax.plot([0,tt/3600],[a,a],color=GRID,lw=0.7); tx(ax,tt/3600+0.08,a-0.12,f't$_{{{int(a*100)}}}$ = ?',color=RED,ha='left')
ax.set_xlabel('time (h)'); ax.set_ylabel('α'); sty(ax); ax.set_ylim(0,1.05); tx(ax,1.6,0.35,'m = n = 1, 120 °C',color=GREY,ha='left'); sv(fig,'p_8A3.png')
# B1
fig,ax=plt.subplots(figsize=(2.4,1.35),dpi=240)
for T,c in ((80,BLUE),(120,OR),(160,RED)):
    f=np.array([rate(a,T) for a in al]); ax.plot(al,f/f.max(),color=c,lw=1.1,label=f'{T} °C'); ax.plot(al[f.argmax()],1,'o',color=c,ms=3)
ax.set_xlabel('α'); ax.set_ylabel('α̇ / α̇$_{max}$'); ax.legend(fontsize=7.0,loc='lower center',ncol=3,bbox_to_anchor=(0.5,-0.02),columnspacing=0.8,handlelength=1.0); sty(ax); ax.set_ylim(0,1.1); tx(ax,0.5,1.04,'∂α̇/∂α = 0 ?',color=GREY,ha='left',fontsize=7.5); sv(fig,'p_8B1.png')
# B2
p=dict(P); p['m']=0.7
def fl(a,fl_):
    th=393.15; k1,k2=k12(120.,p); a=max(a,0); return (k1+k2*a**0.7)*(1-a)**1.8
fig,ax=plt.subplots(figsize=(2.4,1.4),dpi=240); a=np.linspace(0,0.004,200); dt=10.; ax.plot(a*1e2,[(x-dt*fl(x,0))*1e3 for x in a],color=BLUE,lw=1.2)
k1,k2=k12(120.,p); sl=dt*(k2*0.7*1e-8**(-0.3)-1.8*k1); g0=-dt*fl(0,0)
ax.plot([0],[g0*1e3],'o',color=RED,ms=3.5); aa=np.array([0,0.0012]); ax.plot(aa*1e2,(g0+(1-sl)*aa)*1e3,color=OR,ls='--',lw=1)
ax.axhline(0,color=GRID,lw=0.7); ax.set_xlabel('α  (10$^{-2}$)'); ax.set_ylabel('g  (10$^{-3}$)'); sty(ax); tx(ax,0.14,-2.3,'Newton line, slope < 0',color=OR,ha='left',fontsize=7.5); tx(ax,0.02,1.9,'g(α), m = 0.7, Δt = 10 s',color=BLUE,ha='left',fontsize=7.5); sv(fig,'p_8B2.png')
# C1
fig,ax=new(3.0,1.05)
ax.add_patch(Rectangle((0,0),2,2,fc=LB,ec=BLUE,lw=1)); tx(ax,1,1,'1 element\nUCURE',ha='center',va='center',color=NAVY)
arr(ax,(-1.1,1),(-0.05,1),c=RED); tx(ax,-1.15,1.0,'T = 120 °C\n(all nodes)',ha='right',va='center',color=RED,fontsize=7.5)
tx(ax,2.4,1.5,'hold 7200 s',color=GREY,ha='left',va='center'); tx(ax,2.4,0.5,'output: degree of cure',color=NAVY,ha='left',va='center')
ax.set_xlim(-3.7,6.6); ax.set_ylim(-0.1,2.1); sv(fig,'p_8C1.png')
# C2
def rate_d(a,T,C=40.,ac=0.85): return rate(a,T)/(1+np.exp(C*(a-ac)))
fig,ax=plt.subplots(figsize=(2.4,1.35),dpi=240); ax.plot(al,[rate(a,120)*1e4 for a in al],color=BLUE,lw=1.1,label='f'); ax.plot(al,[rate_d(a,120)*1e4 for a in al],color=RED,lw=1.1,label='f$_D$, C = 40, α$_c$ = 0.85')
ax.set_xlabel('α'); ax.set_ylabel('α̇ (10$^{-4}$ s$^{-1}$)'); ax.legend(fontsize=7.5,loc='upper right'); sty(ax); ax.set_ylim(0,3.5); sv(fig,'p_8C2.png')
# D1: DSC
fig,ax=plt.subplots(figsize=(2.6,1.4),dpi=240); Tp={}
for b,c in ((2,BLUE),(5,GREEN),(10,OR)):
    bs=b/60.; te=250.; Tf,ts=Tcycle([(0,25),((te-25)/bs,te)]); s=solve_ivp(lambda t,y:[rate(y[0],25+bs*t)],(0,(te-25)/bs),[0.],method='DOP853',rtol=1e-11,atol=1e-14,dense_output=True)
    TT=np.linspace(25,te,800); r=np.array([rate(float(s.sol((x-25)/bs)[0]),x)*60 for x in TT]); ax.plot(TT,r*1e3,color=c,lw=1.1,label=f'{b} K/min'); Tp[b]=TT[r.argmax()]
ax.set_xlabel('T (°C)'); ax.set_ylabel('α̇ (10$^{-3}$ min$^{-1}$)'); ax.legend(fontsize=7.5); sty(ax); sv(fig,'p_8D1.png')
bs=np.array([2,5,10.]); Tk=np.array([Tp[b] for b in (2,5,10)])+273.15
sl=np.polyfit(1/Tk,np.log(bs/Tk**2),1)[0]; print('Tp',Tp,'Kissinger -E/R',sl)
json.dump(dict(Tp=Tp,kiss=sl),open('../out/dsc.json','w'))
