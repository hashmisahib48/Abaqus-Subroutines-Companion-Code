"""Chapter 8 verification runs: calls the compiled driver, compares with independent references."""
import subprocess, json, numpy as np, os, re, shutil
from ref import *
os.chdir(os.path.dirname(os.path.abspath(__file__))); CODE='../code'; OUT='../out'
I='/home/claude/vol2/lib/aba'
def build(src='ex8_ucure.f',exe='k8drv'):
    subprocess.run(f'cd {CODE} && gfortran -ffixed-form -std=legacy -I{I} k8_drv.f {src} {I}/stubs.f -o ../out/{exe}',shell=True,check=True)
def run(inp,exe='k8drv'):
    r=subprocess.run(f'cd {CODE} && ../out/{exe}',input=inp,shell=True,capture_output=True,text=True); return r.stdout
def mkin(imode=1,itang=0,theta=1.0,dt=100.,tend=7200.,props=(1.0e5,8000.,5.0e3,6000.,1.2,1.8,-273.15),corners=((0,120.),(7200,120.)),t0=80.,dtad=120.,f='x.dat'):
    s=f"{imode} {itang} {theta} {dt} {tend}\n"+' '.join(repr(float(p)) for p in props)+f"\n{len(corners)}\n"
    s+=''.join(f"{t} {T}\n" for t,T in corners)+f"{t0} {dtad}\n../out/{f}\n"; return s
def load(f): return np.loadtxt(f'{OUT}/{f}')
R={}
build()
# ---- isothermal 120 degC, 7200 s: accuracy against DOP853, theta = 1 and 1/2
Tf,ts=Tcycle([(0,120),(7200,120)]); A=solve(Tf,ts); A_r=solve(Tf,ts,method='Radau',rtol=1e-12,atol=1e-14)
R['ref_agree_iso']=max(abs(A(t)-A_r(t)) for t in np.linspace(0,7200,300)); R['iso_ref_7200']=A(7200)
R['iso']={}
for th in (1.0,0.5):
  for dt in (900,450,225,100,50,25,10):
    out=run(mkin(theta=th,dt=float(dt),f='iso.dat')); d=load('iso.dat')
    err=np.array([abs(a-A(t)) for t,a in zip(d[:,0],d[:,2])])
    R['iso'][f'{th}_{dt}']=dict(a=d[-1,2],err_end=err[-1],err_max=err.max(),nit=int(d[:,4].sum()),itmax=int(d[:,4].max()),out=out.strip())
# ---- closed form m=n=1
def closed(t,k1,k2): E=np.exp((k1+k2)*t); return k1*(E-1)/(k2+k1*E)
th=120+273.15; k1=1.0e5*np.exp(-8000/th); k2=5.0e3*np.exp(-6000/th)
pr=dict(P); pr['m']=1.0; pr['n']=1.0; A11=solve(Tf,ts,p=pr)
R['cf']=dict(k1=k1,k2=k2,closed_7200=closed(7200,k1,k2),ode_7200=A11(7200),diff=abs(closed(7200,k1,k2)-A11(7200)))
R['cf']['drv']={}
for dt in (900,225,50,10):
    run(mkin(dt=float(dt),props=(1.0e5,8000.,5.0e3,6000.,1.0,1.0,-273.15),f='iso11.dat')); d=load('iso11.dat')
    e=max(abs(a-closed(t,k1,k2)) for t,a in zip(d[:,0],d[:,2])); R['cf']['drv'][dt]=dict(a=d[-1,2],err_max=e)
# ---- ramp cycle
cor=((0,25.),(1900,120.),(5500,120.),(6700,180.),(10300,180.))
Tr,tr=Tcycle(list(cor)); Ar=solve(Tr,tr); Ar2=solve(Tr,tr,method='Radau',rtol=1e-12,atol=1e-14)
R['ref_agree_ramp']=max(abs(Ar(t)-Ar2(t)) for t in np.linspace(0,10300,400))
R['ramp_ref']={t:Ar(t) for t in (1900,3000,5500,6700,8000,10300)}
R['ramp']={}
for th in (1.0,0.5):
  for dt in (100,50,25,10):
    out=run(mkin(theta=th,dt=float(dt),tend=10300.,corners=cor,f='ramp.dat')); d=load('ramp.dat')
    err=np.array([abs(a-Ar(t)) for t,a in zip(d[:,0],d[:,2])])
    R['ramp'][f'{th}_{dt}']=dict(a=d[-1,2],err_end=err[-1],err_max=err.max(),nit=int(d[:,4].sum()),itmax=int(d[:,4].max()),out=out.strip())
# ---- adiabatic: iteration counts with three derivative sets
from scipy.integrate import solve_ivp
f=lambda t,y:[rate(y[0],80+120*y[0])]
ev=lambda t,y:y[0]-0.5
s=solve_ivp(f,(0,14400),[0.],method='DOP853',rtol=1e-12,atol=1e-15,events=ev,dense_output=True)
Aad=lambda t: float(s.sol(t)[0]); R['ad_ref']=dict(t50=float(s.t_events[0][0]),a14400=Aad(14400),a7200=Aad(7200),a9000=Aad(9000))
s2=solve_ivp(f,(0,14400),[0.],method='Radau',rtol=1e-12,atol=1e-14,dense_output=True)
R['ad_ref']['agree']=max(abs(Aad(t)-float(s2.sol(t)[0])) for t in np.linspace(0,14400,300))
R['ad']={}
for dt in (400,200,100,50):
  for it in (0,1,2):
    out=run(mkin(imode=2,itang=it,dt=float(dt),tend=14400.,f='ad.dat')); d=load('ad.dat')
    err=np.array([abs(a-Aad(t)) for t,a in zip(d[:,0],d[:,2])])
    res=np.loadtxt(f'{OUT}/ad.dat.res'); 
    R['ad'][f'{it}_{dt}']=dict(a=d[-1,2],err_end=err[-1],err_max=err.max(),nit=int(d[:,4].sum()),itmax=int(d[:,4].max()),out=out.strip(),T=d[-1,1])
    if dt==100: np.save(f'{OUT}/ad_res_{it}.npy',res); np.save(f'{OUT}/ad_{it}_{dt}.npy',d)
# ---- m=0.7: floor 1e-8 versus 1e-3
src=open(f'{CODE}/ex8_ucure.f').read()
for fl in ('1.0D-8','1.0D-3'):
    open(f'{CODE}/_tmp.f','w').write(src.replace('AFLOOR = 1.0D-3',f'AFLOOR = {fl}')); build('_tmp.f','k8tmp')
    pm=dict(P); pm['m']=0.7; Am=solve(Tf,ts,p=pm)
    R['m07_'+fl]={}
    for dt in (100,50,10):
        out=run(mkin(dt=float(dt),props=(1.0e5,8000.,5.0e3,6000.,0.7,1.8,-273.15),f='m07.dat'),'k8tmp'); d=load('m07.dat')
        R['m07_'+fl][dt]=dict(a=d[-1,2],itmax=int(d[:,4].max()),ref=Am(7200))
os.remove(f'{CODE}/_tmp.f')
# ---- fd
out=subprocess.run(f'cd {CODE} && gfortran -ffixed-form -std=legacy -I{I} k8_fd.f ex8_ucure.f {I}/stubs.f -o ../out/k8fd && ../out/k8fd',shell=True,capture_output=True,text=True).stdout
R['fd']=out.strip().split('\n')[-1]
json.dump(R,open(f'{OUT}/results.json','w'),indent=1,default=float)
print(json.dumps(R,indent=1,default=float))
