      PROGRAM K8DRV
!     Driver for UCURE (outside Abaqus).  A stand-in for the implicit
!     integration of the degree of cure: theta-method with Newton's
!     method, calling UCURE as Abaqus would.  The scheme actually used
!     by Abaqus is not documented; this one only tests the routine.
!     IMODE 1: temperature prescribed as piecewise linear in time
!     IMODE 2: adiabatic, T = T0 + DTAD*DOC
!     ITANG 0: full derivative, 1: DRDA only, 2: none (fixed point)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(7), TC(20), TT(20), DRA(3), SO(2), SN(2),
     1 COORDS(3), TIME(3), PREDEF(1), DPRED(1)
      CHARACTER*80 CMNAME, CFILE
      READ(5,*) IMODE, ITANG, THETA, DT, TEND
      READ(5,*) (PROPS(K), K = 1, 7)
      READ(5,*) NC
      DO K = 1, NC
         READ(5,*) TC(K), TT(K)
      ENDDO
      READ(5,*) T0AD, DTAD
      READ(5,'(A)') CFILE
      OPEN(10, FILE=CFILE)
      OPEN(11, FILE=TRIM(CFILE)//'.res')
      NSTEP = NINT(TEND/DT)
      DOCN = 0.0D0
      SO = 0.0D0
      TNOW = TT(1)
      IF (IMODE .EQ. 2) TNOW = T0AD
      CMNAME = 'CURE'
      CALL K8_EVAL(DOCN, TNOW, 0.0D0, DT, PROPS, SO, SN, DRA, TIME)
      FOLD = DRA(1)
      NITOT = 0
      NMAX = 0
      WRITE(10,'(5ES24.15)') 0.0D0, TNOW, DOCN, FOLD, 0.0D0
      DO N = 1, NSTEP
         TIMEN = N*DT
         TEXT = TNOW
         IF (IMODE .EQ. 1) CALL K8_TEMP(TC, TT, NC, TIMEN, TEXT)
         A = DOCN
         DO IT = 1, 200
            TE = TEXT
            DTDA = 0.0D0
            IF (IMODE .EQ. 2) THEN
               TE = T0AD + DTAD*A
               DTDA = DTAD
            ENDIF
            CALL K8_EVAL(A, TE, TIMEN, DT, PROPS, SO, SN, DRA, TIME)
            G = A - DOCN - DT*(THETA*DRA(1) + (1.0D0 - THETA)*FOLD)
            WRITE(11,'(2I7,ES16.6)') N, IT, ABS(G)
            IF (ABS(G) .LT. 1.0D-13) GOTO 10
            GP = 1.0D0
            IF (ITANG .EQ. 0) GP = 1.0D0 - THETA*DT*(DRA(2)
     1                              + DRA(3)*DTDA)
            IF (ITANG .EQ. 1) GP = 1.0D0 - THETA*DT*DRA(2)
            A = A - G/GP
         ENDDO
   10    CONTINUE
         NIT = IT
         IF (IT .GT. 200) NIT = 200
         NITOT = NITOT + NIT
         NMAX = MAX(NMAX, NIT)
         DOCN = A
         TNOW = TE
         SO = SN
         FOLD = DRA(1)
         WRITE(10,'(5ES24.15)') TIMEN, TNOW, DOCN, FOLD, DBLE(NIT)
      ENDDO
      CLOSE(10)
      CLOSE(11)
      WRITE(*,'(A,ES22.14,A,ES22.14)') 'final DOC', DOCN, '  T', TNOW
      WRITE(*,'(A,I8,A,I5,A,2ES14.6)') 'iterations total', NITOT,
     1 '  max per step', NMAX, '  peak rate, time', SO(1), SO(2)
      END
!
      SUBROUTINE K8_EVAL(A, TEMP, TIMEN, DT, PROPS, SO, SN, DRA,
     1                   TIME)
!     one call of UCURE with the arguments set as Abaqus would set them
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*), SO(*), SN(*), DRA(*), TIME(*), COORDS(3),
     1 PREDEF(1), DPRED(1), IA(1), RA(1)
      CHARACTER*80 CMNAME, CA(1)
      TIME(1) = TIMEN
      TIME(2) = TIMEN
      TIME(3) = 0.0D0
      COORDS = 0.0D0
      CMNAME = 'CURE'
      CALL UCURE(A, DRA, 1, 1, 0, 0, 1, 1, 1, CMNAME, 2, SO, SN,
     1 COORDS, TIME, DT, PNEWDT, TEMP, 0.0D0, 0, PREDEF, DPRED, 7,
     2 PROPS, 0, IA, 0, RA, 0, CA)
      END
!
      SUBROUTINE K8_TEMP(TC, TT, NC, T, TEXT)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION TC(*), TT(*)
      TEXT = TT(NC)
      DO K = 1, NC - 1
         IF (T .LE. TC(K+1) + 1.0D-9) THEN
            TEXT = TT(K) + (TT(K+1) - TT(K))*(T - TC(K))
     1           /(TC(K+1) - TC(K))
            RETURN
         ENDIF
      ENDDO
      END
