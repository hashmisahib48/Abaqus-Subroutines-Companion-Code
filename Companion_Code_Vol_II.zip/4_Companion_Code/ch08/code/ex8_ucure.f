      SUBROUTINE UCURE(DOC, DOCRATEARRAY, NOEL, NPT, LAYER, KSPT,
     1 KSTEP, KINC, JPROC, CMNAME, NSTATV, STATEVOLD, STATEV,
     2 COORDS, TIME, DTIME, PNEWDT, TEMP, DTEMP, NFIELD, PREDEF,
     3 DPRED, NPROPS, PROPS, NIARRAY, I_ARRAY, NRARRAY, R_ARRAY,
     4 NCARRAY, C_ARRAY)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME, C_ARRAY(*)
      DIMENSION DOCRATEARRAY(*), STATEVOLD(*), STATEV(*), COORDS(*),
     1 TIME(*), PREDEF(*), DPRED(*), PROPS(*), I_ARRAY(*), R_ARRAY(*)
!
!     Kamal-Sourour cure kinetics: rate = (K1 + K2*DOC**M)*(1-DOC)**N
!     PROPS: 1 A1 (1/s)  2 E1/R (K)  3 A2 (1/s)  4 E2/R (K)
!            5 M (-)     6 N (-), N >= 1    7 absolute zero (deg C)
!     TEMP in deg C (as in the model), time in s
!     STATEV: 1 largest cure rate so far (1/s), 2 its time (s)
!
      CALL K8_RATE(PROPS, NPROPS, DOC, TEMP, RATE, DRDA, DRDT, IERR)
      IF (IERR .NE. 0) THEN
         WRITE(7,*) 'UCURE: bad properties, IERR =', IERR
         CALL XIT
      ENDIF
      DOCRATEARRAY(1) = RATE
      DOCRATEARRAY(2) = DRDA
      DOCRATEARRAY(3) = DRDT
!
!     state: rebuilt from STATEVOLD at every call, never accumulated
      IF (NSTATV .GE. 2) THEN
         STATEV(1) = STATEVOLD(1)
         STATEV(2) = STATEVOLD(2)
         IF (RATE .GT. STATEVOLD(1)) THEN
            STATEV(1) = RATE
            STATEV(2) = TIME(2)
         ENDIF
      ENDIF
      RETURN
      END
!
      SUBROUTINE K8_RATE(PROPS, NPROPS, DOC, TEMP, RATE, DRDA, DRDT,
     1                   IERR)
!     Rate of cure and its two derivatives (Eqs. 8.2-2, 8.2-3)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*)
      PARAMETER (AFLOOR = 1.0D-3)   ! bounds DOC**(M-1) for M < 1
      PARAMETER (THMIN = 1.0D0)     ! K; below this: no cure
!
      IERR = 0
      RATE = 0.0D0
      DRDA = 0.0D0
      DRDT = 0.0D0
      IF (NPROPS .LT. 7) IERR = 1
      IF (IERR .NE. 0) RETURN
      A1  = PROPS(1)
      E1R = PROPS(2)
      A2  = PROPS(3)
      E2R = PROPS(4)
      XM  = PROPS(5)
      XN  = PROPS(6)
      IF (A1 .LT. 0.0D0 .OR. A2 .LT. 0.0D0 .OR. XM .LT. 0.0D0 .OR.
     1    XN .LT. 1.0D0) IERR = 2
      IF (IERR .NE. 0) RETURN
      TH = TEMP - PROPS(7)
      IF (TH .LT. THMIN) RETURN
!
      A  = MIN(MAX(DOC, 0.0D0), 1.0D0)
      B  = 1.0D0 - A
      AF = A
      IF (XM .LT. 1.0D0) AF = MAX(A, AFLOOR)
      XK1 = A1*EXP(-E1R/TH)
      XK2 = A2*EXP(-E2R/TH)
      AM  = A**XM
      BN  = B**XN
      RATE = (XK1 + XK2*AM)*BN
      DRDA = XK2*XM*AF**(XM - 1.0D0)*BN
     1     - XN*(XK1 + XK2*AM)*B**(XN - 1.0D0)
      DRDT = (XK1*E1R + XK2*AM*E2R)*BN/TH**2
      RETURN
      END
