      PROGRAM K8FD
!     Finite-difference check of the derivatives returned by K8_RATE.
!     Central differences: step HA in DOC (absolute), HT in TEMP.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(7)
      DATA PROPS /1.0D5, 8000.0D0, 5.0D3, 6000.0D0, 1.2D0, 1.8D0,
     1 -273.15D0/
      OPEN(10, FILE='../out/fd_grid.dat')
      EMAXA = 0.0D0
      EMAXT = 0.0D0
      DO IT = 0, 14
         TEMP = 60.0D0 + 10.0D0*IT
         DO IA = 1, 49
            A = 0.02D0*IA
            CALL K8_RATE(PROPS, 7, A, TEMP, R0, DRA, DRT, IE)
            HA = 1.0D-6
            HT = 1.0D-4
            CALL K8_RATE(PROPS, 7, A+HA, TEMP, RP, X1, X2, IE)
            CALL K8_RATE(PROPS, 7, A-HA, TEMP, RM, X1, X2, IE)
            FDA = (RP - RM)/(2.0D0*HA)
            CALL K8_RATE(PROPS, 7, A, TEMP+HT, RP, X1, X2, IE)
            CALL K8_RATE(PROPS, 7, A, TEMP-HT, RM, X1, X2, IE)
            FDT = (RP - RM)/(2.0D0*HT)
            EA = ABS(FDA - DRA)/MAX(ABS(DRA), 1.0D-12)
            ET = ABS(FDT - DRT)/MAX(ABS(DRT), 1.0D-12)
            EMAXA = MAX(EMAXA, EA)
            EMAXT = MAX(EMAXT, ET)
            IF (IA .EQ. 25 .OR. IA .EQ. 5 .OR. IA .EQ. 45)
     1         WRITE(*,'(F7.1,F6.2,3ES14.6,2ES12.3)') TEMP, A, R0,
     2            DRA, DRT, EA, ET
         ENDDO
      ENDDO
      WRITE(*,'(A,2ES12.3)') 'max relative error (DOC, TEMP):',
     1  EMAXA, EMAXT
!     error against step size at TEMP = 120, DOC = 0.4
      A = 0.4D0
      TEMP = 120.0D0
      CALL K8_RATE(PROPS, 7, A, TEMP, R0, DRA, DRT, IE)
      DO K = 1, 14
         H = 10.0D0**(-K)
         CALL K8_RATE(PROPS, 7, A+H, TEMP, RP, X1, X2, IE)
         CALL K8_RATE(PROPS, 7, A-H, TEMP, RM, X1, X2, IE)
         EA = ABS((RP - RM)/(2.0D0*H) - DRA)/ABS(DRA)
         CALL K8_RATE(PROPS, 7, A, TEMP+H, RP, X1, X2, IE)
         CALL K8_RATE(PROPS, 7, A, TEMP-H, RM, X1, X2, IE)
         ET = ABS((RP - RM)/(2.0D0*H) - DRT)/ABS(DRT)
         WRITE(10,'(3ES16.6)') H, EA, ET
      ENDDO
      CLOSE(10)
      END
