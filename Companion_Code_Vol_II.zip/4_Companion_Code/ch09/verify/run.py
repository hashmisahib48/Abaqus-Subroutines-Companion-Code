"""Chapter 9 verification: compile every file, run the drivers, compare with independent references.
usage: python3 run.py   (writes ../out/nums.json and data files)"""
import subprocess, json, os, glob, numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.optimize import brentq
HERE=os.path.dirname(os.path.abspath(__file__)); CODE=HERE+'/../code'; OUT=HERE+'/../out'
INC='/home/claude/vol2/lib/aba'; FL='-ffixed-form -ffixed-line-length-none -std=legacy -I'+INC
def sh(c,inp=None): return subprocess.run(c,shell=True,capture_output=True,text=True,input=inp)
R={}
# ---------- 1. compile every file (listing files with the 72-column check)
nok=0; files=sorted(glob.glob(CODE+'/*.f')); R['compiled']=[]
for f in files:
    r=sh(f'gfortran -c {FL} {f} -o /dev/null'); ok=(r.returncode==0)
    over=[i+1 for i,l in enumerate(open(f).read().split('\n')) if len(l)>72 and os.path.basename(f).startswith('ex9')]
    print(('OK   ' if ok else 'FAIL ')+os.path.basename(f),'>72:',over); nok+=ok; R['compiled'].append(os.path.basename(f))
    if not ok: print(r.stderr[:800])
R['nfiles']=len(files)
def build(drv,rt,exe): 
    r=sh(f'cd {CODE} && gfortran {FL} {drv} {rt} {INC}/stubs.f -o {OUT}/{exe}'); assert r.returncode==0,r.stderr
build('k9_eos_drv.f','ex9_vueos.f','k9eos'); build('k9_visc_drv.f','ex9_vuviscosity.f','k9visc')
build('k9_thix_drv.f','ex9_vuvisc_thix.f','k9thix'); build('k9_fab_drv.f','ex9_vfabric.f','k9fab')
def run(exe,inp): return np.array([[float(x) for x in l.split()] for l in sh(f'{OUT}/{exe}',inp).stdout.strip().split('\n') if l.strip()])
def runraw(exe,inp): return sh(f'{OUT}/{exe}',inp).stdout
# ======================= VUEOS =======================
rho0,c0,s,g0=8.93e-9,3.94e6,1.489,1.99
head=f'{c0} {s} {g0} {rho0}\n'
def pH(eta): return rho0*c0**2*eta/(1-s*eta)**2
def pMG(rho,E): eta=1-rho0/rho; return pH(eta)*(1-0.5*g0*eta)+g0*rho0*E
# --- E1 derivatives against finite differences (one block of 3N points)
x=np.linspace(0.90,1.50,13); rho=x*rho0; Em=np.linspace(0,6e11,13)
h=1e-5
pts=[(r,e) for r,e in zip(rho,Em)]+[(r*(1+h),e) for r,e in zip(rho,Em)]+[(r*(1-h),e) for r,e in zip(rho,Em)]+[(r,e*(1+h)+1e3) for r,e in zip(rho,Em)]+[(r,e*(1-h)-1e3) for r,e in zip(rho,Em)]
inp=head+'1\n%d\n'%len(pts)+''.join(f'{float(a)!r} {float(b)!r}\n' for a,b in pts); d=run('k9eos',inp); n=len(x)
p0,dr,de=d[:n,2],d[:n,3],d[:n,4]
fd_r=(d[n:2*n,2]-d[2*n:3*n,2])/(2*h*rho); fd_e=(d[3*n:4*n,2]-d[4*n:5*n,2])/(d[3*n:4*n,1]-d[4*n:5*n,1])
R['eos_fd']=dict(max_rel_rho=float(np.max(np.abs(dr-fd_r)/np.abs(dr))),max_rel_E=float(np.max(np.abs(de-fd_e)/np.abs(de))),h=h,n=n)
# analytic comparison with the documented example (s=0)
inp='3.94e6 0.0 1.99 8.93e-9\n1\n%d\n'%n+''.join(f'{float(a)!r} {float(b)!r}\n' for a,b in zip(rho,Em)); d0=run('k9eos',inp)
eta=1-rho0/rho; doc_p=rho0*c0**2*eta*(1-0.5*g0*eta)+g0*rho0*Em; doc_dr=c0**2*(rho0/rho)**2*(1-g0*eta)
R['eos_doc']=dict(max_p=float(np.max(np.abs(d0[:,2]-doc_p)/np.abs(doc_p).clip(1))),max_dr=float(np.max(np.abs(d0[:,3]-doc_dr)/np.abs(doc_dr))))
# --- E2 Hugoniot, one energy-coupled step from rest
xs=np.array([1.05,1.10,1.15,1.20,1.25,1.30,1.35,1.40]); rn=xs*rho0
inp=head+'2\n%d 1\n'%len(xs)+''.join(f'{rho0!r} 0 0 {float(r)!r}\n' for r in rn); d=run('k9eos',inp)
eta=1-1/xs; ph=pH(eta); up=c0*eta/(1-s*eta); Us=c0+s*up; Eh=0.5*up**2
cs=np.sqrt(d[:,3]+d[:,2]/d[:,0]**2*d[:,4])
R['hug']=dict(x=xs.tolist(),p_drv=d[:,2].tolist(),p_ref=ph.tolist(),E_drv=d[:,1].tolist(),E_ref=Eh.tolist(),
  err_p=float(np.max(np.abs(d[:,2]-ph)/ph)),err_E=float(np.max(np.abs(d[:,1]-Eh)/Eh)),nit=d[:,5].astype(int).tolist(),
  up=up.tolist(),Us=Us.tolist(),cs=cs.tolist(),lax=bool(np.all(Us-up<cs) and np.all(Us>c0)),p_up_Us=float(np.max(np.abs(d[:,2]-rho0*Us*up)/ph)))
# reference sound speed at the rest state
d=run('k9eos',head+'1\n1\n%r 0\n'%rho0); R['c_rest']=float(np.sqrt(d[0,3])); R['c0']=c0
# --- E3 Newton iteration counts with a scaled DPDEM
inp0=lambda sc: head+'2\n1 %r\n%r 0 0 %r\n'%(float(sc),rho0,1.25*rho0)
R['nit_sc']={}
for sc in (1.0,0.5,0.0,-1.0): d=run('k9eos',inp0(sc)); R['nit_sc'][str(sc)]=dict(nit=int(d[0,5]),p=float(d[0,2]))
# --- E4 compress / release paths
xmax=1.25
def path(N,M):
    up_=[rho0*(1+(xmax-1)*k/N) for k in range(1,N+1)]; dn=[rho0*xmax-(xmax-1)*rho0*k/M for k in range(1,M+1)]
    return up_+dn
def runpath(N,M,sc=1.0):
    pa=path(N,M); inp=head+'3\n%d %r\n%r\n'%(len(pa),sc,rho0)+''.join(f'{float(r)!r}\n' for r in pa); return run('k9eos',inp)
def Wref(xmax,N=None):
    # isentropic release from the Hugoniot state of xmax: dE/drho = p/rho^2, accurate ODE solution
    eta=1-1/xmax; E0=0.5*(c0*eta/(1-s*eta))**2
    f=lambda r,E: pMG(r,E[0])/r**2
    sol=solve_ivp(f,[xmax*rho0,rho0],[E0],method='DOP853',rtol=1e-13,atol=1e-3); return float(sol.y[0,-1]),E0
Eres_ref,EH=Wref(xmax)
R['rel']=dict(Eres_ref=Eres_ref,EH=EH,frac=Eres_ref/EH,pH=float(pH(1-1/xmax)))
R['rel']['table']=[]
for N in (1,2,4,8,16,32,64):
    d=runpath(N,N); R['rel']['table'].append(dict(N=N,Eres=float(d[-1,1]),pres=float(d[-1,2]),pmax=float(d[N,2]),Emax=float(d[N,1])))
R['rel']['rel_M']=[]
for M in (1,2,4,8,16,32,64,256):
    d=runpath(1,M); R['rel']['rel_M'].append(dict(M=M,Eres=float(d[-1,1]),err=float(abs(d[-1,1]-Eres_ref)/EH)))
dN=runpath(1,64); dK=runpath(64,64); np.savetxt(OUT+'/path_1_64.dat',dN); np.savetxt(OUT+'/path_64_64.dat',dK)
# isentropic reference curve p(rho) from the reference state (compression)
fr=lambda r,E: pMG(r,E[0])/r**2
rr=np.linspace(rho0,xmax*rho0,200); sol=solve_ivp(fr,[rho0,xmax*rho0],[0.0],t_eval=rr,method='DOP853',rtol=1e-12,atol=1e-3)
np.savetxt(OUT+'/isentrope.dat',np.c_[rr/rho0,[pMG(r,e) for r,e in zip(rr,sol.y[0])],sol.y[0]])
R['isent']=dict(p=float(pMG(xmax*rho0,sol.y[0,-1])),E=float(sol.y[0,-1]))
# time step: wave speed of the stiffest state
R['eos_misc']=dict(K0=rho0*c0**2,cH_14=float(cs[-1]))

# ======================= VUVISCOSITY =======================
P=dict(model=1,eta0=1e-3,etainf=1e-6,lam=0.1,n=0.4,a=2.0,ear=6000.,tref=20.,tzero=273.15)
def pv(model=1,**k): 
    q=dict(P); q.update(k); q['model']=model; return ' '.join(repr(float(q[x])) for x in ('model','eta0','etainf','lam','n','a','ear','tref','tzero'))+'\n'
def cross(g,T=20.,**k):
    q=dict(P); q.update(k); at=np.exp(q['ear']*(1/(T+q['tzero'])-1/(q['tref']+q['tzero']))); x=at*q['lam']*g
    return at*(q['etainf']+(q['eta0']-q['etainf'])/(1+x**(1-q['n'])))
def cy(g,T=20.,**k):
    q=dict(P); q.update(k); at=np.exp(q['ear']*(1/(T+q['tzero'])-1/(q['tref']+q['tzero']))); x=at*q['lam']*g
    return at*(q['etainf']+(q['eta0']-q['etainf'])*(1+x**q['a'])**((q['n']-1)/q['a']))
def evalv(model,gs,Ts,**k):
    inp=pv(model,**k)+'1\n%d\n'%len(gs)+''.join(f'{float(g)!r} {float(T)!r}\n' for g,T in zip(gs,Ts)); return run('k9visc',inp)
g=np.logspace(-3,3,61)
dC=evalv(1,g,[20]*len(g)); dY=evalv(2,g,[20]*len(g))
np.savetxt(OUT+'/visc_cross.dat',np.c_[g,dC[:,2],dY[:,2]])
# documented example (Cross with eta_inf = 0): eta0/(1+(lam*g)**(1-n))
dD=evalv(1,g,[20]*len(g),etainf=0.0); docv=1e-3/(1+(0.1*g)**(1-0.4))
R['visc_doc']=float(np.max(np.abs(dD[:,2]-docv)/docv))
R['visc_ref']=float(np.max(np.abs(dC[:,2]-cross(g))/cross(g)))+0.0
R['visc_ref_cy']=float(np.max(np.abs(dY[:,2]-cy(g))/cy(g)))
# property tests: value at lam*g = 1, low-shear limit, slope at high shear, n = 1 Newtonian
d1=evalv(1,[10.],[20.]); d2=evalv(2,[10.],[20.])
R['visc_x1']=dict(cross=float(d1[0,2]),cross_ref=1e-6+(1e-3-1e-6)/2,cy=float(d2[0,2]),cy_ref=1e-6+(1e-3-1e-6)*2**((0.4-1)/2.))
gl=np.array([1e-6,1e-5]); dl=evalv(1,gl,[20,20]); R['visc_low']=dict(g=gl.tolist(),eta=dl[:,2].tolist(),rel=(1-dl[:,2]/1e-3).tolist())
gh=np.array([1e5,1e6]); dh=evalv(1,gh,[20,20],etainf=0.0); dhy=evalv(2,gh,[20,20],etainf=0.0)
R['visc_slope']=dict(cross=float(np.log(dh[1,2]/dh[0,2])/np.log(10)),cy=float(np.log(dhy[1,2]/dhy[0,2])/np.log(10)),expect=-0.6)
dn=evalv(1,[0.01,1,100,1e4],[20]*4,n=1.0); R['visc_n1']=dn[:,2].tolist()
# temperature: collapse onto the master curve
Ts=[20.,40.,60.,80.]; gg=np.logspace(-2,3,31); sets={}
dev=0.
for T in Ts:
    d=evalv(1,gg,[T]*len(gg)); at=np.exp(6000*(1/(T+273.15)-1/293.15)); sets[T]=d[:,2]
    master=cross(at*gg)  # eta_ref(a_T g)
    dev=max(dev,float(np.max(np.abs(d[:,2]/at-master)/master)))
    if T==80.: R['aT80']=float(at)
R['visc_collapse']=dev; R['aT']={str(T):float(np.exp(6000*(1/(T+273.15)-1/293.15))) for T in Ts}
np.savetxt(OUT+'/visc_T.dat',np.c_[gg]+0); np.savetxt(OUT+'/visc_T.dat',np.c_[gg,*[sets[T] for T in Ts]])
# slit flow: Picard solution with the routine against the Rabinowitsch-Mooney integral
def rm(G,h=1.0,**k):
    tw=G*h
    def gdot(tau): return brentq(lambda gd: gd*cross(gd,**k)-tau,0,1e18,xtol=1e-14,rtol=1e-14)
    I=quad(lambda t: t*gdot(t),0,tw,epsabs=0,epsrel=1e-12,limit=200)[0]
    return h*I/tw**2, gdot(tw)
def slit(G,NY=200,h=1.0,model=1,T=20.,**k):
    inp=pv(model,**k)+'2\n%r %r %d %r\n'%(h,G,NY,T); out=runraw('k9visc',inp).strip().split('\n')
    a=[float(x) for x in out[0].split()]; prof=np.array([[float(x) for x in l.split()] for l in out[1:]]); return dict(um=a[0],gw=a[1],u0=a[2],nit=int(a[3])),prof
R['slit']=[]
for G in (0.0005,0.005,0.02,0.2,2.0,20.0):
    r,prof=slit(G); um,gw=rm(G); K=1e-3*0.1**(0.4-1); n=0.4; upl=n/(2*n+1)*1.0*(G*1.0/K)**(1/n); unw=G*1.0**2/(3*1e-3)
    R['slit'].append(dict(G=G,tauw=G,um=r['um'],um_ref=um,err=abs(r['um']-um)/um,gw=r['gw'],gw_ref=gw,nit=r['nit'],ratio_newton=r['um']/unw,ratio_pl=r['um']/upl))
r,prof=slit(0.02); np.savetxt(OUT+'/slit_prof.dat',prof)
R['slit_conv']=[]
for NY in (25,50,100,200,400,800):
    r,_=slit(0.02,NY=NY); um,gw=rm(0.02); R['slit_conv'].append(dict(NY=NY,um=r['um'],err=abs(r['um']-um)/um,nit=r['nit']))
# Newtonian limit n = 1 (Cross shape = 1/2): u = G h^2/(3 eta), eta = 5e-4
r,_=slit(0.02,n=1.0,etainf=0.0); R['slit_newt']=dict(um=r['um'],ref=0.02/(3*0.5e-3),err=abs(r['um']-0.02/(3*0.5e-3))/(0.02/(3*0.5e-3)))
# thixotropy
tb,ck=10.,0.02; gr=[1.,5.,25.]
inp='1e-3 1e-5 %r %r\n3\n%s\n%d\n'%(tb,ck,' '.join(map(str,gr)),60+60)+'\n'.join(['1.0 1.0']*60+['1.0 0.0']*60)+'\n'
d=run('k9thix',inp); t=d[:,0]; zeq=np.array([ck*x/(1/tb+ck*x) for x in gr]); tau=np.array([1/(1/tb+ck*x) for x in gr])
ze=np.array([zeq[k]*(1-np.exp(-np.minimum(t,60)/tau[k])) for k in range(3)]).T
# recovery after t = 60 (rate zero): zeta = zeta60 * exp(-(t-60)/tb)
z60=zeq*(1-np.exp(-60/tau)); rec=np.array([z60[k]*np.exp(-(t-60)/tb) for k in range(3)]).T
ref=np.where((t<=60)[:,None],ze,rec); R['thix']=dict(err=float(np.max(np.abs(d[:,2:5]-ref))),zeq=zeq.tolist(),tau=tau.tolist(),z60=z60.tolist(),eta_end=d[59,5:8].tolist())
np.savetxt(OUT+'/thix.dat',np.c_[d[:,0],d[:,2:5],d[:,5:8]])
# coarse steps: one 60 s step must give the same state
inp='1e-3 1e-5 %r %r\n3\n%s\n1\n60.0 1.0\n'%(tb,ck,' '.join(map(str,gr))); d1=run('k9thix',inp)
R['thix']['coarse']=float(np.max(np.abs(d1[0,2:5]-ze[59])))
# viscous stable increment estimate
R['visc_dt']=dict(eta=1e-3,rho=1.0e-9,Lc=1.0,dt=1.0e-9*1.0**2/(2*1e-3))
# power-law limit with eta_inf = 0
R['slit_pl']=[]
for G in (0.02,0.2,2.0,20.0,200.0):
    r,_=slit(G,etainf=0.0); um,gw=rm(G,etainf=0.0); K=1e-3*0.1**(0.4-1); n=0.4; upl=n/(2*n+1)*(G/K)**(1/n)
    R['slit_pl'].append(dict(G=G,gw=r['gw'],um=r['um'],err=abs(r['um']-um)/um,ratio_pl=r['um']/upl,nit=r['nit']))
# ======================= VFABRIC =======================
EA,EB,EK,BE,GA,GL,GLK,KA,ER=1500.,6000.,0.03,0.01,2.,200.,np.radians(50.),5.,0.25; DENS=1.14e-9
PF=(EA,EB,EK,BE,GA,GL,GLK,KA,ER)
fh=' '.join(repr(float(p)) for p in PF)+'\n%r\n'%DENS
def bil(x,A,B,xk,be):
    if x<0: return be*A*x, 0.5*be*A*x*x
    if x<=xk: return A*x,0.5*A*x*x
    return A*xk+B*(x-xk), 0.5*A*xk*xk+A*xk*(x-xk)+0.5*B*(x-xk)**2
def fref(e1,e2,gam,kappa=KA):
    s1,w1=bil(e1,EA,EB,EK,BE); s2,w2=bil(e2,EA,EB,EK,BE); g,ws=bil(abs(gam),GA,GL,GLK,1.0); g=np.sign(gam)*g
    eb=0.5*(max(e1,0)+max(e2,0)); tau=g*(1+kappa*eb)
    s1+= 0.5*kappa*ws*(e1>0); s2+=0.5*kappa*ws*(e2>0)
    return s1,s2,tau,w1+w2+ws*(1+kappa*eb)
def fev(pts,lop=1,tt=1.0):
    inp=fh+'1\n%d %r %d\n'%(lop,tt,len(pts))+''.join('%r %r %r\n'%tuple(float(v) for v in p) for p in pts); return run('k9fab',inp)
# F1: yarn sweep in warp, incl. compression and rupture
e=np.r_[np.linspace(-0.03,0.24,28),0.2501,0.26]; d=fev([(x,0,0) for x in e])
ref=np.array([[fref(x,0,0)[0],fref(x,0,0)[1],0] for x in e]); ref[e>ER]=0
R['fab_yarn']=dict(err=float(np.max(np.abs(d[:,:3]-ref))),flags=d[-2:,3].tolist(),s_at=[float(fev([(x,0,0)])[0,0]) for x in (0.02,0.03,0.05,0.10)])
np.savetxt(OUT+'/fab_yarn.dat',np.c_[e,d[:,0]])
# F2: shear sweep, unstrained and with biaxial pretension 0.02
gm=np.linspace(-1.4,1.4,57); d0=fev([(0,0,x) for x in gm]); d2=fev([(0.02,0.02,x) for x in gm])
r0=np.array([fref(0,0,x)[:3] for x in gm]); r2=np.array([fref(0.02,0.02,x)[:3] for x in gm])
R['fab_shear']=dict(err0=float(np.max(np.abs(d0[:,:3]-r0))),err2=float(np.max(np.abs(d2[:,:3]-r2))),
  tau_lock=float(fref(0,0,GLK)[2]),tau_1=float(fref(0,0,1.0)[2]),tau_1_pre=float(fref(0.02,0.02,1.0)[2]),s1_1_pre=float(fref(0.02,0.02,1.0)[0]),ws_1=float(bil(1.0,GA,GL,GLK,1.0)[1]),
  tau_drv_lock=float(fev([(0,0,GLK)])[0,2]),tau_drv_1=float(fev([(0,0,1.0)])[0,2]),tau_drv_1_pre=float(fev([(0.02,0.02,1.0)])[0,2]),s1_drv_1_pre=float(fev([(0.02,0.02,1.0)])[0,0]))
np.savetxt(OUT+'/fab_shear.dat',np.c_[gm,d0[:,2],d2[:,2],d2[:,0]])
# F3: paths and energy
rng=np.random.default_rng(9); NB=7; NS=800
def legs(wp,per):
    out=[]
    for a,b in zip(wp[:-1],wp[1:]):
        for k in range(per): out.append((np.array(b)-np.array(a))/per)
    return np.array(out)
P1=legs([(0,0,0),(0.04,0.04,0),(0.04,0.04,1.0),(0,0,1.0),(0,0,0)],200)
paths=[P1]
for k in range(5):
    wp=[(0,0,0)]+[(rng.uniform(-0.02,0.1),rng.uniform(-0.02,0.1),rng.uniform(-1.3,1.3)) for _ in range(9)]+[(0.03,0.02,1.0)]
    paths.append(legs(wp,80))
paths.append(legs([(0,0,0),(0.26,0,0),(0.02,0,0)],400))
inp=fh+'2\n%d %d\n'%(NB,NS)+''.join('%r %r %r\n'%tuple(float(v) for v in paths[k][i]) for i in range(NS) for k in range(NB))
if os.path.exists(OUT+'/hist.dat'): os.remove(OUT+'/hist.dat')
r=subprocess.run(f'cd {OUT} && rm -f fort.7 && ./k9fab',shell=True,capture_output=True,text=True,input=inp)
d=np.array([[float(x) for x in l.split()] for l in r.stdout.strip().split('\n')]); hist=np.loadtxt(OUT+'/fort.7'); os.rename(OUT+'/fort.7',OUT+'/hist.dat')
fin=[]; 
for k in range(1,6):
    ex=fref(d[k,0],d[k,1],d[k,2]); fin.append(dict(final=d[k,:3].tolist(),dstress=float(np.max(np.abs(d[k,3:6]-np.array(ex[:3])))),W=float(d[k,6]),Wref=float(ex[3]),relW=float(abs(d[k,6]-ex[3])/ex[3])))
R['fab_path']=dict(random=fin,loop_W=float(d[0,6]),loop_stress=d[0,3:6].tolist(),rupt_stress=d[6,3:6].tolist(),rupt_flag=float(d[6,7]),rupt_eps=float(d[6,0]))
# non-conservative alternative: yarn stress without the coupling term, same loop
def naive_loop(kappa=KA):
    W=0.0; stp=[]; Wn=0.0
    for p in P1:
        pass
    e1=e2=g=0.0; Wn=0.0; Wc=0.0
    def st(e1,e2,g,naive):
        s1,s2,tau,_=fref(e1,e2,g,kappa)
        if naive:
            s1=bil(e1,EA,EB,EK,BE)[0]; s2=bil(e2,EA,EB,EK,BE)[0]
        return np.array([s1,s2,tau])
    for p in P1:
        a=st(e1,e2,g,True); b=st(e1+p[0],e2+p[1],g+p[2],True)
        Wn+=0.5*((a[0]+b[0])*p[0]+(a[1]+b[1])*p[1]+(a[2]+b[2])*p[2]); e1+=p[0]; e2+=p[1]; g+=p[2]
    return Wn
R['fab_path']['loop_W_naive']=float(naive_loop()); R['fab_path']['loop_W_naive_ref']=float(KA*0.04*bil(1.0,GA,GL,GLK,1.0)[1])
# loop with kappa=0 for the plot of hysteresis-free behaviour is not needed
# F4: tangent symmetry by central differences through the routine
pts=[]
for _ in range(40):
    e1=rng.choice([rng.uniform(0.004,0.028),rng.uniform(0.032,0.1)]); e2=rng.choice([rng.uniform(0.004,0.028),rng.uniform(0.032,0.1)]); g=rng.choice([rng.uniform(0.1,0.85),rng.uniform(0.9,1.3)])*rng.choice([-1,1]); pts.append((e1,e2,g))
h=1e-6; base=np.array(pts)
def evp(dx):
    return fev(base+np.array(dx))
dg_p=evp((0,0,h)); dg_m=evp((0,0,-h)); d1_p=evp((h,0,0)); d1_m=evp((-h,0,0)); d2_p=evp((0,h,0)); d2_m=evp((0,-h,0))
ds1_dg=(dg_p[:,0]-dg_m[:,0])/(2*h); dt_de1=(d1_p[:,2]-d1_m[:,2])/(2*h)
ds2_dg=(dg_p[:,1]-dg_m[:,1])/(2*h); dt_de2=(d2_p[:,2]-d2_m[:,2])/(2*h)
R['fab_sym']=dict(n=len(pts),max_rel_1=float(np.max(np.abs(ds1_dg-dt_de1)/np.abs(dt_de1))),max_rel_2=float(np.max(np.abs(ds2_dg-dt_de2)/np.abs(dt_de2))),
  example=dict(gam=pts[0][2],ds1_dg=float(ds1_dg[0]),dt_de1=float(dt_de1[0])))
# F5: lOp
inc=fev([(1e-6,2e-6,3e-6)],lop=-1,tt=0.0); R['fab_lop']=dict(m1=inc[0,:3].tolist(),m1_ref=[6000*1e-6,6000*2e-6,200*(1+5*0.25)*3e-6],zero=fev([(0.01,0.01,0.3)],lop=0)[0,:3].tolist())
# F6: bias extension, ideal pin-jointed net, yarns at 45 degrees
lam=np.linspace(1.0,1.40,81); th=np.arccos(lam/np.sqrt(2)*1.0); gam=np.pi/2-2*th
dd=fev([(0,0,x) for x in gam]); np.savetxt(OUT+'/fab_bias.dat',np.c_[lam,np.degrees(gam),dd[:,2]])
R['bias']=dict(lock={str(a):float(np.cos(np.radians(45-a/2))/np.cos(np.radians(45))) for a in (40,45,50,55,60)},
  gam_at_14=float(np.degrees(np.pi/2-2*np.arccos(1.4/np.sqrt(2)))),lam_max=float(np.sqrt(2)))
c=[np.sqrt(EB/DENS),np.sqrt(GL*(1+KA*ER)/DENS)]; R['fab_dt']=dict(c_yarn=float(c[0]),c_shear=float(c[1]),c_a=float(np.sqrt(EA/DENS)),dt_1mm=float(1.0/c[0]),dt_1mm_a=float(1.0/np.sqrt(EA/DENS)))
json.dump(R,open(OUT+'/nums.json','w'),indent=1)
