import sys, json; sys.path.insert(0,'/home/claude/vol2/lib')
from figstyle import *
import matplotlib.pyplot as plt, numpy as np, os
from matplotlib.patches import Polygon, Rectangle, Arc
os.chdir(os.path.dirname(os.path.abspath(__file__))); OUTD='..'; OUT='../out'; R=json.load(open(OUT+'/nums.json'))
def sv(fig,n): fig.savefig(f'{OUTD}/{n}',dpi=240,bbox_inches='tight',pad_inches=0.04,facecolor='white'); plt.close(fig)
def tx(ax,x,y,s,**k):
    k.setdefault("fontsize",7.8); ax.text(x,y,s,**k)
def sty(a): a.tick_params(labelsize=7.4); a.xaxis.label.set_size(8); a.yaxis.label.set_size(8)
# A1
r0,c0,s,g0=2.70e-9,5.35e6,1.34,2.0
fig,ax=plt.subplots(figsize=(2.9,1.9),dpi=240); x=np.linspace(1,1.4,100); e=1-1/x
ax.plot(x,r0*c0**2*e/(1-s*e)**2/1e3,color=RED,lw=1.3); ax.plot(x,r0*c0**2*e/(1-s*e)**2*(1-0.5*g0*e)/1e3,color=GREEN,lw=1.1,ls=':')
ax.plot([1.2],[21.3526],'o',color=OR,ms=4); tx(ax,1.205,12,'ρ/ρ$_0$ = 1.2',color=OR,ha='left'); tx(ax,1.02,50,'Hugoniot (E$_m$ from the jump conditions)',color=RED,ha='left',fontsize=7.4); tx(ax,1.4,20,'cold curve',color=GREEN,ha='right')
ax.set_xlabel('ρ/ρ$_0$'); ax.set_ylabel('pressure  (GPa)'); sty(ax); ax.set_ylim(0,60); sv(fig,'p_9A1.png')
# A2
fig,ax=plt.subplots(figsize=(2.9,1.9),dpi=240); g=np.logspace(-2,3,200); ax.loglog(g,1e-3/(1+(0.1*g)**0.6),color=BLUE,lw=1.3)
for gg in (1,10,100): ax.loglog([gg],[1e-3/(1+(0.1*gg)**0.6)],'o',color=OR,ms=3.8)
ax.axhline(1e-4,color=GREY,lw=0.6,ls=':'); tx(ax,0.012,1.15e-4,'η$_0$/10',color=GREY,ha='left'); ax.plot([389.4],[1e-4],'s',color=RED,ms=3.8)
ax.set_xlabel('shear rate  (s$^{-1}$)'); ax.set_ylabel('η  (MPa·s)'); sty(ax); ax.set_ylim(3e-5,1.6e-3); sv(fig,'p_9A2.png')
# A3
fig,ax=plt.subplots(figsize=(2.6,2.3),dpi=240); ax.set_aspect('equal'); ax.axis('off'); ax.set_xlim(-0.3,5.2); ax.set_ylim(-0.7,6.6)
rect=Rectangle((0,0),3.6,5.4,fc=LB,ec=BLUE,lw=1); ax.add_patch(rect)
for k in range(-6,8):
    l1,=ax.plot([k*0.9,k*0.9+5.4],[0,5.4],color=NAVY,lw=0.5); l2,=ax.plot([k*0.9+5.4,k*0.9],[0,5.4],color=RED,lw=0.5); l1.set_clip_path(rect); l2.set_clip_path(rect)
arr(ax,(1.8,5.5),(1.8,6.4),c=RED,lw=1.4); arr(ax,(1.8,-0.1),(1.8,-0.65),c=RED,lw=1.4); tx(ax,2.0,6.2,'F, stretch λ',color=RED,ha='left')
for (x,y,t) in ((1.8,2.7,'C'),(0.45,0.35,'A'),(3.15,0.35,'A'),(0.45,5.0,'A'),(3.15,5.0,'A')):
    tx(ax,x,y,t,color=NAVY,ha='center',va='center',fontsize=9,weight='bold',bbox=dict(fc='white',ec='none',pad=0.8))
tx(ax,3.75,2.7,'yarns\n±45°',color=NAVY,ha='left',va='center',fontsize=7.6)
sv(fig,'p_9A3.png')
# B1
fig,ax=plt.subplots(figsize=(3.2,1.7),dpi=240); ax.axis('off'); ax.set_xlim(0,10); ax.set_ylim(0,5)
ax.add_patch(Rectangle((0.2,1),4.2,2.2,fc=PINK,ec=RED)); ax.add_patch(Rectangle((4.4,1),5.4,2.2,fc=LB,ec=BLUE)); ax.plot([4.4,4.4],[0.7,3.5],color=NAVY,lw=2)
arr(ax,(2.2,2.1),(3.5,2.1),c=RED,lw=1.3); tx(ax,2.2,1.5,'u$_p$',color=RED,ha='center'); tx(ax,2.3,2.7,'ρ, p, E$_m$',color=RED,ha='center',fontsize=7.4); tx(ax,7.1,2.7,'ρ$_0$, p = 0, E$_m$ = 0',color=BLUE,ha='center',fontsize=7.4); tx(ax,7.1,1.5,'at rest',color=BLUE,ha='center')
arr(ax,(4.4,3.9),(5.8,3.9),c=NAVY,lw=1.3); tx(ax,5.0,4.3,'U$_s$',color=NAVY,ha='left'); arr(ax,(3.6,3.9),(0.6,3.9),c=GREY,lw=1.0); tx(ax,2.0,4.3,'c$_s$ (relative to the material)',color=GREY,ha='center',fontsize=7.2)
sv(fig,'p_9B1.png')
# B3
fig,ax=plt.subplots(figsize=(3.0,1.7),dpi=240); ax.axis('off'); ax.set_xlim(0,10); ax.set_ylim(-0.3,5.4)
ax.plot([0.3,9.7],[0,0],color=NAVY,lw=2); ax.plot([0.3,9.7],[5,5],color=NAVY,lw=2); ax.plot([0.3,9.7],[2.5,2.5],color=GREY,lw=0.6,ls=':')
yy=np.linspace(0,5,80); ax.plot(0.6+4.0*(1-np.abs((yy-2.5)/2.5)**2.5),yy,color=RED,lw=1.2)
arr(ax,(5.2,1.4),(7.2,1.4),c=BLUE,lw=1.4); tx(ax,5.2,0.7,'G = −dp/dx',color=BLUE,ha='left'); ax.annotate('',xy=(9.0,0),xytext=(9.0,5),arrowprops=dict(arrowstyle='<->',color=GREY,lw=0.8)); tx(ax,8.9,2.4,'2H',color=GREY,ha='right')
tx(ax,6.8,3.7,'Cross fluid, τ = G y',color=NAVY,ha='center',fontsize=7.4)
sv(fig,'p_9B3.png')
# C1
fig,ax=plt.subplots(figsize=(2.9,1.9),dpi=240); g=np.linspace(0,8,300)
for m,c in ((1,GREEN),(5,BLUE),(50,RED)): ax.plot(g,1e-3*g+0.005*(1-np.exp(-m*g)),color=c,lw=1.2)
ax.plot(g,1e-3*g+0.005,color=GREY,lw=0.8,ls='--'); tx(ax,8,0.0132,'Bingham',color=GREY,ha='right',va='bottom'); tx(ax,3.2,0.0045,'m = 1 s',color=GREEN,ha='left',fontsize=7.4); tx(ax,1.2,0.0075,'5',color=BLUE,ha='left',fontsize=7.4); tx(ax,0.45,0.0112,'50',color=RED,ha='left',fontsize=7.4)
ax.set_xlabel('γ̇  (s$^{-1}$)'); ax.set_ylabel('τ  (MPa)'); sty(ax); ax.set_ylim(0,0.014); ax.set_xlim(0,8); sv(fig,'p_9C1.png')
# C2
fig,ax=plt.subplots(figsize=(2.6,1.9),dpi=240); ax.set_xlim(-0.01,0.055); ax.set_ylim(-0.1,1.2)
ax.plot([0,0.04,0.04,0,0],[0,0,1,1,0],color=BLUE,lw=1.2); 
for p,q in (((0,0),(0.02,0)),((0.04,0),(0.04,0.5)),((0.04,1),(0.02,1)),((0,1),(0,0.5))): arr(ax,p,q,c=RED,lw=1.2)
ax.set_xlabel('ē'); ax.set_ylabel('γ  (rad)'); sty(ax); tx(ax,0.02,0.5,'loop 1',color=GREY,ha='center'); tx(ax,0.021,-0.07,'1',color=RED,ha='center',fontsize=7.2); tx(ax,0.046,0.5,'2',color=RED,ha='center',fontsize=7.2); tx(ax,0.021,1.05,'3',color=RED,ha='center',fontsize=7.2); tx(ax,-0.006,0.5,'4',color=RED,ha='center',fontsize=7.2)
sv(fig,'p_9C2.png')
# D1
rho0,c0,s,g0=8.93e-9,3.94e6,1.489,1.99
fig,ax=plt.subplots(figsize=(3.0,1.9),dpi=240); iso=np.loadtxt(OUT+'/isentrope.dat'); x=np.linspace(1,1.25,100); e=1-1/x; ph=rho0*c0**2*e/(1-s*e)**2/1e3
ax.plot(1/x,ph,color=RED,lw=1.3); ax.plot(1/iso[:,0],iso[:,1]/1e3,color=BLUE,lw=1.3,ls='--')
ax.plot([1,1/1.25],[0,56.2279],color=GREY,lw=0.8,ls=':'); 
ax.set_xlabel('specific volume  v/v$_0$'); ax.set_ylabel('pressure  (GPa)'); sty(ax); tx(ax,0.95,48,'Hugoniot',color=RED,ha='right'); tx(ax,0.9,12,'isentrope',color=BLUE,ha='left'); tx(ax,0.88,30,'Rayleigh\nline',color=GREY,ha='right',fontsize=7.2); ax.invert_xaxis(); ax.set_ylim(0,62)
sv(fig,'p_9D1.png'); print('ok')
