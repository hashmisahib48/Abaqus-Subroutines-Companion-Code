import sys, json; sys.path.insert(0,'/home/claude/vol2/lib')
from figstyle import *
import matplotlib.pyplot as plt, numpy as np, os
from matplotlib.patches import FancyBboxPatch, Polygon, Arc, Rectangle
os.chdir(os.path.dirname(os.path.abspath(__file__)))
OUTD='..'; OUT='../out'; R=json.load(open(OUT+'/nums.json'))
FS=7.8
def tx(ax,x,y,s,fs=FS,**k): k.setdefault('fontsize',fs); ax.text(x,y,s,**k)
def sv(fig,n): fig.savefig(f'{OUTD}/{n}',dpi=240,bbox_inches='tight',pad_inches=0.04,facecolor='white'); plt.close(fig)
def style(a,fs=8): a.tick_params(labelsize=7.4); a.xaxis.label.set_size(fs); a.yaxis.label.set_size(fs)
def cap(ax,t,y=-0.30): ax.text(0.5,y,t,transform=ax.transAxes,ha='center',va='top',fontsize=7.6,color=GREY)
rho0,c0,s,g0=8.93e-9,3.94e6,1.489,1.99
def pH(eta,r0=rho0,c=c0,ss=s): return r0*c**2*eta/(1-ss*eta)**2
def bx(ax,x,y,w,h,t,fc,ec,tc=NAVY,fs=7.6,b=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.25,rounding_size=1.2',fc=fc,ec=ec,lw=0.9))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,color=tc,weight='bold' if b else 'normal',linespacing=1.3)
# ---------- Fig 9.2-1 flow ----------
fig,ax=plt.subplots(figsize=(4.7,2.5),dpi=240); ax.set_xlim(-2,148); ax.set_ylim(-1,66); ax.axis('off')
rows=[(46,'VUEOS','*EOS, TYPE=USER','ρ, ρ$_0$, E$_m$, dkk','p, ∂p/∂ρ, ∂p/∂E$_m$'),
      (23,'VUVISCOSITY','*VISCOSITY, DEFINITION=USER','shrRate, T, fields, state','viscosity, state'),
      (0,'VFABRIC','*FABRIC, USER','ε, Δε, σ$_{old}$, lOp, state','σ$_{new}$ (3), state, energy')]
for y,n,k,i_,o_ in rows:
    bx(ax,0,y,38,17,i_,LB,BLUE,fs=6.2); bx(ax,45,y,56,17,'',PINK,RED,tc=RED,fs=7.2); ax.text(73,y+11.3,n,ha='center',va='center',fontsize=7.8,color=RED,weight='bold'); ax.text(73,y+5.2,k,ha='center',va='center',fontsize=6.0,color=RED); bx(ax,108,y,37,17,o_,LB,BLUE,fs=6.2)
    arr(ax,(38.8,y+8.5),(44.2,y+8.5),c=BLUE); arr(ax,(101.8,y+8.5),(107.2,y+8.5),c=RED)
tx(ax,19,66.5,'Abaqus passes (blocks)',color=BLUE,ha='center',fontsize=7.8,weight='bold'); tx(ax,73,66.5,'your routine',color=RED,ha='center',fontsize=7.8,weight='bold'); tx(ax,126,66.5,"Abaqus takes",color=BLUE,ha='center',fontsize=7.8,weight='bold')
sv(fig,'fig_flow.png')
# ---------- Fig 9.4-1: Hugoniot and Lax ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.7,2.15),dpi=240)
xs=np.linspace(1.0,1.45,100); eta=1-1/xs; ph=pH(eta)/1e3
iso=np.loadtxt(OUT+'/isentrope.dat')
a1.plot(xs,ph,color=RED,lw=1.3); a1.plot(iso[:,0],iso[:,1]/1e3,color=BLUE,lw=1.2,ls='--')
cold=pH(eta)*(1-0.5*g0*eta)/1e3; a1.plot(xs,cold,color=GREEN,lw=1.0,ls=':')
h=R['hug']; a1.plot(h['x'],np.array(h['p_drv'])/1e3,'o',color=OR,ms=3.2,mfc='none',mew=0.9)
a1.set_xlabel('compression  ρ/ρ$_0$'); a1.set_ylabel('pressure  (GPa)'); style(a1); a1.set_xlim(1,1.45); a1.set_ylim(0,150)
tx(a1,1.30,128,'Hugoniot',color=RED,ha='right'); tx(a1,1.43,45,'isentrope',color=BLUE,ha='right'); tx(a1,1.43,10,'cold curve (E$_m$ = 0)',color=GREEN,ha='right')
up=np.array(h['up'])/1e6; Us=np.array(h['Us'])/1e6; cs=np.array(h['cs'])/1e6
a2.plot(up,Us,color=RED,lw=1.2); a2.plot(up,Us-up,color=GREY,lw=1.0,ls='--'); a2.plot(up,cs,'o-',color=OR,ms=3,lw=0.9,mfc='none')
a2.set_xlabel('particle velocity  u$_p$  (mm/ms)'); a2.set_ylabel('speed  (mm/ms = km/s)'); style(a2)
tx(a2,1.15,4.25,'U$_s$',color=RED,ha='left'); tx(a2,1.0,3.95,'U$_s$ − u$_p$',color=GREY,ha='left'); tx(a2,0.3,6.95,'c  (from the routine)',color=OR,ha='left'); a2.set_ylim(3.6,7.4)
cap(a1,'(a) pressure',-0.28); cap(a2,'(b) speeds on the Hugoniot',-0.28); fig.subplots_adjust(wspace=0.42); sv(fig,'fig_hug.png')
# ---------- Fig 9.4-2: release ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.7,2.15),dpi=240)
d1=np.loadtxt(OUT+'/path_1_64.dat'); d2=np.loadtxt(OUT+'/path_64_64.dat')
a1.plot(d2[:65,0]/rho0,d2[:65,2]/1e3,color=BLUE,lw=1.2,ls='--'); a1.plot(d1[:2,0]/rho0,d1[:2,2]/1e3,color=RED,lw=1.0,marker='o',ms=2.5); a1.plot(d1[1:,0]/rho0,d1[1:,2]/1e3,color=RED,lw=1.2)
a1.set_xlabel('ρ/ρ$_0$'); a1.set_ylabel('pressure  (GPa)'); style(a1); a1.set_xlim(1,1.27); a1.set_ylim(-3,60)
tx(a1,1.012,40,'shock, then\nrelease',color=RED,ha='left'); tx(a1,1.255,17,'64 steps\nup and down',color=BLUE,ha='right')
Ns=[1,2,4,8,16,32,64]; pm=np.array([t['pmax'] for t in R['rel']['table']]); pi=R['isent']['p']
a2.loglog(Ns,np.abs(pm-pi)/pi,'-o',color=BLUE,ms=3,lw=1,label='compression: p at ρ/ρ$_0$ = 1.25')
Ms=[t['M'] for t in R['rel']['rel_M']][1:-1]; er=[t['err'] for t in R['rel']['rel_M']][1:-1]
a2.loglog(Ms,er,'-s',color=RED,ms=3,lw=1,label='release: residual energy')
hh=np.array([2,64]); a2.loglog(hh,0.08*hh**-2.,color=GREY,lw=0.8,ls='--'); tx(a2,9,2e-5,'∝ N$^{-2}$',color=GREY,ha='left')
a2.set_xlabel('number of steps N or M'); a2.set_ylabel('relative error'); style(a2); a2.set_ylim(1e-6,3e-1)
a2.legend(fontsize=6.8,loc='upper right',handlelength=1.4,borderaxespad=0.1)
cap(a1,'(a) one cycle',-0.28); cap(a2,'(b) convergence',-0.28); fig.subplots_adjust(wspace=0.42); sv(fig,'fig_rel.png')
# ---------- Fig 9.6-1: flow curves ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.7,2.15),dpi=240)
d=np.loadtxt(OUT+'/visc_cross.dat'); g=d[:,0]
a1.loglog(g,d[:,1],color=BLUE,lw=1.3); a1.loglog(g,d[:,2],color=RED,lw=1.3,ls='--')
a1.axhline(1e-3,color=GREY,lw=0.6,ls=':'); a1.axhline(1e-6,color=GREY,lw=0.6,ls=':'); a1.axvline(10,color=GREY,lw=0.6,ls=':')
gg=np.array([100.,1000.]); e100=np.interp(100,g,d[:,1]); a1.loglog(gg,0.55*e100*(gg/100)**-0.6,color=GREY,lw=0.9)
tx(a1,2e-3,1.45e-3,'η$_0$',color=GREY,ha='left'); tx(a1,2e-3,1.5e-6,'η$_\\infty$',color=GREY,ha='left'); tx(a1,11,1.2e-6,'λγ̇ = 1',color=GREY,ha='left')
tx(a1,3e-3,2.2e-4,'Cross',color=BLUE,ha='left'); tx(a1,3e-3,1.1e-4,'Carreau–Yasuda',color=RED,ha='left'); tx(a1,60,3.0e-5,'asymptote,\nslope n − 1',color=GREY,ha='right',va='top')
a1.set_xlabel('shear rate  γ̇  (s$^{-1}$)'); a1.set_ylabel('viscosity  η  (MPa·s)'); style(a1); a1.set_ylim(5e-7,4e-3)
Ts=[20,40,60,80]; cols=[BLUE,GREEN,OR,RED]; dd=np.loadtxt(OUT+'/visc_T.dat'); gg=dd[:,0]
for k,(T,c) in enumerate(zip(Ts,cols)):
    at=R['aT'][str(float(T))]; a2.loglog(at*gg,dd[:,1+k]/at,'o',color=c,ms=2.6,mfc='none',mew=0.8,label=f'{T} °C')
a2.loglog(g,d[:,1],color=GREY,lw=0.8)
a2.set_xlabel('reduced rate  a$_T$ γ̇  (s$^{-1}$)'); a2.set_ylabel('η / a$_T$  (MPa·s)'); style(a2); a2.legend(fontsize=6.8,loc='lower left',handletextpad=0.2,borderaxespad=0.1,markerscale=1.2)
cap(a1,'(a) 20 °C, Eqs. 9.5-2 and 9.5-3',-0.30); cap(a2,'(b) the shift collapses the curves',-0.30); fig.subplots_adjust(wspace=0.5); sv(fig,'fig_visc.png')
# ---------- Fig 9.6-2: slit ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.7,2.15),dpi=240)
pr=np.loadtxt(OUT+'/slit_prof.dat'); y=pr[:,0]; u=pr[:,1]; um=R['slit'][2]['um']
a1.plot(y,u/um,color=RED,lw=1.3); a1.plot(y,1.5*(1-y**2),color=GREY,lw=1.0,ls='--')
n=0.4; a1.plot(y,(2*n+1)/(n+1)*(1-y**((n+1)/n)),color=BLUE,lw=1.0,ls=':')
a1.set_xlabel('y / H'); a1.set_ylabel('u / ū'); style(a1); a1.set_xlim(0,1); a1.set_ylim(0,1.9)
tx(a1,0.04,0.62,'Newtonian',color=GREY,ha='left',va='top'); tx(a1,0.04,0.46,'power law, n = 0.4',color=BLUE,ha='left',va='top'); tx(a1,0.04,0.30,'routine, G = 0.02',color=RED,ha='left',va='top')
cv=R['slit_conv']; a2.loglog([c['NY'] for c in cv],[c['err'] for c in cv],'-o',color=BLUE,ms=3,lw=1)
hh=np.array([25,800]); a2.loglog(hh,0.25*hh**-2.,color=GREY,lw=0.8,ls='--'); tx(a2,60,1.2e-5,'∝ N$^{-2}$',color=GREY,ha='left')
a2.set_xticks([25,100,400]); a2.set_xticklabels(['25','100','400']); a2.minorticks_off()
a2.set_xlabel('cells  N'); a2.set_ylabel('error of ū'); style(a2)
cap(a1,'(a) velocity profile',-0.28); cap(a2,'(b) convergence',-0.28); fig.subplots_adjust(wspace=0.4); sv(fig,'fig_slit.png')
# ---------- Fig 9.9-1 thixotropy ----------
fig,ax=plt.subplots(figsize=(3.3,2.0),dpi=240); d=np.loadtxt(OUT+'/thix.dat'); t=d[:,0]
tb,ck=10.,0.02; cols=[BLUE,OR,RED]; gr=[1,5,25]
tt=np.linspace(0,120,500)
for k,(gk,c) in enumerate(zip(gr,cols)):
    zeq=ck*gk/(1/tb+ck*gk); tau=1/(1/tb+ck*gk); z=np.where(tt<=60,zeq*(1-np.exp(-tt/tau)),zeq*(1-np.exp(-60/tau))*np.exp(-(tt-60)/tb))
    ax.plot(tt,z,color=c,lw=1.1); ax.plot(t[::6],d[::6,1+k],'o',color=c,ms=2.4,mfc='none',mew=0.8); tx(ax,48,zeq+0.025,f'γ̇ = {gk} s$^{{-1}}$',color=c,ha='right',va='bottom',fontsize=7.2)
ax.axvline(60,color=GREY,lw=0.6,ls=':'); tx(ax,61,0.93,'rest',color=GREY,ha='left',fontsize=7.4)
ax.set_xlabel('time  (s)'); ax.set_ylabel('breakdown  ζ'); style(ax); ax.set_xlim(0,120); ax.set_ylim(0,1)
sv(fig,'fig_thix.png')
# ---------- Fig 9.7-1 kinematics ----------
fig,ax=plt.subplots(figsize=(4.6,1.9),dpi=240); ax.set_aspect('equal'); ax.axis('off'); ax.set_xlim(-0.5,9.6); ax.set_ylim(-0.9,3.2)
sq=Polygon([(0,0),(2.2,0),(2.2,2.2),(0,2.2)],fc=LB,ec=BLUE,lw=1); ax.add_patch(sq)
arr(ax,(0,0),(2.2,0),c=NAVY,lw=1.2); arr(ax,(0,0),(0,2.2),c=NAVY,lw=1.2)
tx(ax,1.1,-0.42,'a$_1$ (warp)',ha='center',color=NAVY); tx(ax,-0.12,1.1,'a$_2$\n(weft)',ha='right',va='center',color=NAVY)
tx(ax,1.1,2.5,'reference: 90°',ha='center',color=GREY)
arr(ax,(2.6,1.1),(4.0,1.1),c=GREY,lw=1.2); tx(ax,3.3,1.38,'Δε, γ',ha='center',color=GREY)
x0=4.8; a1v=np.array([2.45,0.0]); gam=0.5; l2=2.3; a2v=l2*np.array([np.sin(gam),np.cos(gam)])
P=[(x0,0),(x0+a1v[0],0),(x0+a1v[0]+a2v[0],a2v[1]),(x0+a2v[0],a2v[1])]
ax.add_patch(Polygon(P,fc=PINK,ec=RED,lw=1)); arr(ax,(x0,0),(x0+a1v[0],0),c=RED,lw=1.2); arr(ax,(x0,0),(x0+a2v[0],a2v[1]),c=RED,lw=1.2)
ax.add_patch(Arc((x0,0),1.3,1.3,theta1=np.degrees(np.pi/2-gam),theta2=90,color=OR,lw=1.2)); ax.add_patch(Arc((x0,0),1.9,1.9,theta1=0,theta2=np.degrees(np.pi/2-gam),color=GREY,lw=0.8))
tx(ax,x0+0.35,1.02,'γ',color=OR,fontsize=9,ha='center'); tx(ax,x0+1.15,0.25,'π/2 − γ',color=GREY,ha='left',fontsize=7.4)
tx(ax,x0+a1v[0]/2,-0.42,'ε$_1$ = |a$_1$| − 1',ha='center',color=RED); tx(ax,x0+a2v[0]+0.2,a2v[1]+0.12,'ε$_2$ = |a$_2$| − 1',ha='left',color=RED)
tx(ax,x0+1.9,2.7,'deformed: yarns no longer orthogonal',ha='center',color=GREY)
sv(fig,'fig_kin.png')
# ---------- Fig 9.8-1: laws ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.7,2.15),dpi=240)
d=np.loadtxt(OUT+'/fab_yarn.dat'); m=d[:,0]<=0.2501
a1.plot(d[m,0],d[m,1],color=BLUE,lw=1.3); a1.plot(d[m,0],d[m,1],'o',color=BLUE,ms=2.2)
a1.axvline(0.03,color=GREY,lw=0.6,ls=':'); a1.axvline(0.25,color=RED,lw=0.8,ls='--'); a1.axhline(0,color=GREY,lw=0.5)
a1.set_xlabel('yarn strain  ε'); a1.set_ylabel('yarn stress  σ  (MPa)'); style(a1); a1.set_xlim(-0.04,0.28); a1.set_ylim(-50,1700)
tx(a1,0.034,1500,'knee ε$_k$',color=GREY,ha='left'); tx(a1,0.246,250,'rupture ε$_r$:\npoint deleted',color=RED,ha='right'); tx(a1,0.005,1000,'slope E$_B$ above the knee',color=BLUE,ha='left'); tx(a1,0.075,60,'slope E$_A$',color=BLUE,ha='left')
d0=np.loadtxt(OUT+'/fab_shear.dat'); m=d0[:,0]>=0
a2.plot(d0[m,0],d0[m,1],color=BLUE,lw=1.3); a2.plot(d0[m,0],d0[m,2],color=RED,lw=1.3)
gl=np.radians(50); a2.axvline(gl,color=GREY,lw=0.6,ls=':'); tx(a2,gl-0.03,40,'γ$_L$',color=GREY,ha='right')
a2.set_xlabel('shear angle  γ  (rad)'); a2.set_ylabel('shear stress  τ  (MPa)'); style(a2); a2.set_xlim(0,1.3); a2.set_ylim(0,90)
tx(a2,0.05,70,'ē = 0 (blue)',color=BLUE,ha='left'); tx(a2,0.05,58,'ē = 0.02 (red)',color=RED,ha='left'); tx(a2,0.86,12,'locked',color=GREY,ha='right')
cap(a1,'(a) warp or weft yarn',-0.28); cap(a2,'(b) trellis shear with locking',-0.28); fig.subplots_adjust(wspace=0.42); sv(fig,'fig_fab.png')
# ---------- Fig 9.8-2: loop and bias ----------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.7,2.15),dpi=240)
h=np.loadtxt(OUT+'/hist.dat'); n=len(h)
GA,GL,GLK,KA,EA,EB,EK,BE=2.,200.,np.radians(50),5.,1500.,6000.,0.03,0.01
def bil(x,A,B,xk):
    return (A*x,0.5*A*x*x) if x<=xk else (A*xk+B*(x-xk),0.5*A*xk*xk+A*xk*(x-xk)+0.5*B*(x-xk)**2)
def stn(e,g):
    y=bil(e,EA,EB,EK)[0]; gg_,ws=bil(abs(g),GA,GL,GLK); return np.array([y,y,np.sign(g)*gg_*(1+KA*e)])
Wn=[0.0]; e=g=0.0
pts=[(0,0,0),(0.04,0.04,0),(0.04,0.04,1.0),(0,0,1.0),(0,0,0)]; path=[]
for a,b_ in zip(pts[:-1],pts[1:]):
    for k in range(200): path.append((np.array(b_)-np.array(a))/200)
for dlt in path:
    a=stn(e,g); b2=stn(e+dlt[0],g+dlt[2]); Wn.append(Wn[-1]+0.5*((a[0]+b2[0])*dlt[0]*2+(a[2]+b2[2])*dlt[2])); e+=dlt[0]; g+=dlt[2]
a1.plot(range(n+1),[0]+list(h[:,6]),color=BLUE,lw=1.3); a1.plot(range(n+1),Wn,color=RED,lw=1.3)
for k in (200,400,600): a1.axvline(k,color=GREY,lw=0.5,ls=':')
a1.set_xlabel('increment number'); a1.set_ylabel('work  W  (N·mm/mm³)'); style(a1); a1.set_xlim(0,800); a1.set_ylim(-0.3,max(Wn)*1.12)
tx(a1,15,4.2,'red: without the coupling\nterm in σ$_1$, σ$_2$',color=RED,ha='left',va='bottom',fontsize=7.2); tx(a1,15,3.4,'blue: routine (Eq. 9.7-5)',color=BLUE,ha='left',va='bottom',fontsize=7.2)
for k,t in zip((100,300,500,700),('ε','γ','ε','γ')): tx(a1,k,max(Wn)*1.04,t,color=GREY,ha='center',fontsize=7.2)
b=np.loadtxt(OUT+'/fab_bias.dat'); a2.plot(b[:,0],b[:,1],color=BLUE,lw=1.3)
lk=R['bias']['lock']['50']; a2.plot([lk],[50],'o',color=RED,ms=3.5); a2.plot([1,lk],[50,50],color=GREY,lw=0.6,ls=':'); a2.plot([lk,lk],[0,50],color=GREY,lw=0.6,ls=':')
tx(a2,1.02,52,'γ$_L$ = 50°',color=GREY,ha='left',fontsize=7.2); tx(a2,lk+0.01,8,f'λ = {lk:.4f}',color=RED,ha='left',fontsize=7.4)
a2.set_xlabel('stretch  λ  (45° yarns)'); a2.set_ylabel('shear angle  γ  (degrees)'); style(a2); a2.set_xlim(1,1.41); a2.set_ylim(0,80)
cap(a1,'(a) work along the loop of Example 9.8-1',-0.28); cap(a2,'(b) bias extension',-0.28); fig.subplots_adjust(wspace=0.42); sv(fig,'fig_loop.png')
print('ok')
