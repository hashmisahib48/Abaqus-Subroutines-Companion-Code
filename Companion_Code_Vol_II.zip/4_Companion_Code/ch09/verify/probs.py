"""Numbers for the problems of Chapter 9 (appended to out/nums.json)."""
import json, os, subprocess, numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
HERE=os.path.dirname(os.path.abspath(__file__)); CODE=HERE+'/../code'; OUT=HERE+'/../out'
INC='/home/claude/vol2/lib/aba'; FL='-ffixed-form -ffixed-line-length-none -std=legacy -I'+INC
def sh(c,inp=None): return subprocess.run(c,shell=True,capture_output=True,text=True,input=inp)
def build(drv,rt,exe):
    r=sh(f'cd {CODE} && gfortran {FL} {drv} {rt} {INC}/stubs.f -o {OUT}/{exe}'); assert r.returncode==0,r.stderr
def run(exe,inp): return np.array([[float(x) for x in l.split()] for l in sh(f'{OUT}/{exe}',inp).stdout.strip().split('\n') if l.strip()])
R=json.load(open(OUT+'/nums.json')); Q={}
# ---- 9A.1 aluminium-like constants, Hugoniot at rho/rho0 = 1.2
rho0,c0,s,g0=2.70e-9,5.35e6,1.34,2.0; x=1.2; eta=1-1/x
pH=rho0*c0**2*eta/(1-s*eta)**2; up=c0*eta/(1-s*eta); Us=c0+s*up; EH=0.5*up**2
head=f'{c0} {s} {g0} {rho0}\n'
d=run('k9eos',head+'2\n1 1\n%r 0 0 %r\n'%(rho0,x*rho0)); dc=run('k9eos',head+'1\n1\n%r 0\n'%(x*rho0))
Q['a1']=dict(pH=pH,up=up,Us=Us,EH=EH,p_drv=float(d[0,2]),E_drv=float(d[0,1]),p_cold=float(dc[0,2]),pH_GPa=pH/1e3,
  dpdr=float(d[0,3]),dpde=float(d[0,4]),c_s=float(np.sqrt(d[0,3]+d[0,2]/d[0,0]**2*d[0,4])))
# ---- 9A.2 Cross fluid with eta_inf = 0, lambda = 0.1 s, n = 0.4, eta0 = 1e-3
def cross0(g,eta0=1e-3,lam=0.1,n=0.4): return eta0/(1+(lam*g)**(1-n))
build('k9_visc_drv.f','ex9_vuviscosity.f','k9visc')
inp='1 1e-3 0 0.1 0.4 2 6000 20 273.15\n1\n4\n1 20\n10 20\n100 20\n1000 20\n'; d=run('k9visc',inp)
g90=9**(1/0.6)/0.1
Q['a2']=dict(eta=d[:,2].tolist(),g_tenth=g90,eta_check=float(cross0(g90)/1e-3))
# ---- 9A.3 bias extension, lock angle 55 degrees; shear angle at stretch 1.30
lock=np.cos(np.radians(45-55/2))/np.cos(np.radians(45)); gam130=np.degrees(np.pi/2-2*np.arccos(1.30/np.sqrt(2)))
Q['a3']=dict(lock=float(lock),gam130=float(gam130),eps_lock=float(lock-1))
# ---- 9B.1 sound speed at the Hugoniot state of the chapter (copper-like), x=1.25
i=R['hug']['x'].index(1.25); Q['b1']=dict(up=R['hug']['up'][i],Us=R['hug']['Us'][i],cs=R['hug']['cs'][i],Us_minus_up=R['hug']['Us'][i]-R['hug']['up'][i],c0=3.94e6)
# ---- 9B.2 buggy routine
build('k9_eos_drv.f','prob_9b2_bug.f','k9eos_bug')
head=f'3.94e6 1.489 1.99 8.93e-9\n'
good=run('k9eos',head+'1\n3\n%r 0\n%r 0\n%r 6e11\n'%(1.2*8.93e-9,1.2*8.93e-9,1.2*8.93e-9)); bad=run('k9eos_bug',head+'1\n3\n%r 0\n%r 0\n%r 6e11\n'%(1.2*8.93e-9,1.2*8.93e-9,1.2*8.93e-9))
Q['b2']=dict(good_p=good[:,2].tolist(),bad_p=bad[:,2].tolist(),good_dr=good[:,3].tolist(),bad_dr=bad[:,3].tolist(),good_de=good[:,4].tolist(),bad_de=bad[:,4].tolist())
# ---- 9B.3 power-law ratios (from chapter run)
Q['b3']=[(r['G'],r['ratio_pl'],r['gw']) for r in R['slit_pl'][:4]]
# ---- 9C.1 Papanastasiou in a slit against Buckingham-Reiner
build('k9_visc_drv.f','prob_9c1_papanastasiou.f','k9visc_pap')
ep,ty=1e-3,0.005; G=0.02; h=1.0; tw=G*h; phi=ty/tw; ub=tw*h/(3*ep)*(1-1.5*phi+0.5*phi**3)
Q['c1']=dict(phi=phi,y0=phi*h,ubr=ub,tw=tw,runs=[])
for m in (10.,100.,1000.,1e4):
    out=sh(f'{OUT}/k9visc_pap',f'{ep} {ty} {m} 0 0 0 0 0 0\n2\n{h} {G} 400 20\n').stdout.strip().split('\n'); a=[float(v) for v in out[0].split()]
    # reference: Rabinowitsch-Mooney with the regularised law
    eta=lambda g: ep+ty*(-np.expm1(-m*g))/g if g>1e-12 else ep+ty*m
    gd=lambda t: brentq(lambda g: g*eta(g)-t,0,1e6,xtol=1e-14,rtol=1e-14)
    I=quad(lambda t: t*gd(t),0,tw,epsabs=0,epsrel=1e-11,limit=200)[0]; um=h*I/tw**2
    Q['c1']['runs'].append(dict(m=m,um=a[0],ref=um,err=abs(a[0]-um)/um,u0=a[2],nit=int(a[3])))
# ---- 9C.2 loop work with kappa = 10
import re
src=open(HERE+'/run.py').read()
Q['c2']={}
def fabrun(kappa):
    P=[1500.,6000.,0.03,0.01,2.,200.,np.radians(50.),kappa,0.25]
    fh=' '.join(repr(float(p)) for p in P)+'\n1.14e-9\n'
    def legs(wp,per):
        o=[]
        for a,b in zip(wp[:-1],wp[1:]):
            for k in range(per): o.append((np.array(b)-np.array(a))/per)
        return np.array(o)
    P1=legs([(0,0,0),(0.04,0.04,0),(0.04,0.04,1.0),(0,0,1.0),(0,0,0)],200)
    inp=fh+'2\n1 800\n'+''.join('%r %r %r\n'%tuple(float(v) for v in P1[i]) for i in range(800))
    r=subprocess.run(f'cd {OUT} && rm -f fort.7 && ./k9fab',shell=True,capture_output=True,text=True,input=inp); return [float(v) for v in r.stdout.split()]
for kap in (5.,10.):
    o=fabrun(kap); Q['c2'][str(kap)]=dict(W=o[6])
def bil(x,A,B,xk):
    return 0.5*A*x*x if x<=xk else 0.5*A*xk*xk+A*xk*(x-xk)+0.5*B*(x-xk)**2
ws1=bil(1.0,2.,200.,np.radians(50.)); Q['c2']['ws1']=ws1; Q['c2']['naive_10']=10*0.04*ws1; Q['c2']['naive_5']=5*0.04*ws1
# ---- 9D.1 entropy: Hugoniot vs isentrope energy at x=1.25 (chapter constants)
Eh=R['rel']['EH']; Ei=R['isent']['E']; Q['d1']=dict(EH=Eh,Ei=Ei,diff=Eh-Ei,frac=(Eh-Ei)/Eh,waste_frac=R['rel']['frac'],ph=R['rel']['pH'],pi=R['isent']['p'])
R['probs']=Q; json.dump(R,open(OUT+'/nums.json','w'),indent=1)
print(json.dumps(Q,indent=0)[:4000])
