      SUBROUTINE VFABRIC(
     1  NBLOCK, NDIM, NPT, LAYER, KSPT, KSTEP, KINC, NSTATEV,
     2  NFIELDV, NPROPS, LOP, JELEM, STEPTIME, TOTALTIME, DT, CMNAME,
     3  COORDMP, CHARLENGTH, PROPS, DENSITY, BRAIDANGLE, FABRICSTRAIN,
     4  FABRICSTRAININC, TEMPOLD, FIELDOLD, FABRICSTRESSOLD, STATEOLD,
     5  TEMPNEW, FIELDNEW, ENERINTERN, FABRICSTRESSNEW, STATENEW,
     6  ENERINELAS)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION JELEM(NBLOCK), COORDMP(NBLOCK,NDIM),
     1  CHARLENGTH(NBLOCK), PROPS(NPROPS), DENSITY(NBLOCK),
     2  BRAIDANGLE(NBLOCK), FABRICSTRAIN(NBLOCK,4),
     3  FABRICSTRAININC(NBLOCK,4), TEMPOLD(NBLOCK),
     4  FIELDOLD(NBLOCK,NFIELDV), FABRICSTRESSOLD(NBLOCK,3),
     5  STATEOLD(NBLOCK,NSTATEV), TEMPNEW(NBLOCK),
     6  FIELDNEW(NBLOCK,NFIELDV), ENERINTERN(NBLOCK),
     7  FABRICSTRESSNEW(NBLOCK,3), STATENEW(NBLOCK,NSTATEV),
     8  ENERINELAS(NBLOCK)
      CHARACTER*80 CMNAME
!
!     Bilinear yarns and bilinear trellis shear with locking
!     PROPS: 1 EA (MPa)  2 EB (MPa)  3 EPSK (-)  4 BETA (-)
!            5 GA (MPa)  6 GL (MPa)  7 GAMLOCK (rad)  8 KAPPA (-)
!            9 EPSR (-)
!     STRAIN: 1 warp, 2 weft, 3 thick., 4 TENSOR shear (gamma/2)
!     STRESS: 1 warp, 2 weft, 3 shear.  STATE: 1 flag (1 active, 0
!     deleted; *DEPVAR, DELETE=1), 2 shear angle (rad)
!     W = wy(E1) + wy(E2) + ws(GAM)*(1 + KAPPA*EBAR), Eq. 9.7-4
      PARAMETER (ZERO = 0.0D0, HALF = 0.5D0, ONE = 1.0D0, TWO = 2.0D0)
      EMAX = MAX(PROPS(1), PROPS(2))
      GMAX = MAX(PROPS(5), PROPS(6))*(ONE + PROPS(8)*PROPS(9))
      DO 100 K = 1, NBLOCK
         FLAG = STATEOLD(K,1)
         IF (TOTALTIME .EQ. ZERO) FLAG = ONE
         E1  = FABRICSTRAIN(K,1)
         E2  = FABRICSTRAIN(K,2)
         GAM = TWO*FABRICSTRAIN(K,4)
         IF (LOP .LE. -1) THEN
!           datacheck: elastic, stiffest branch
            S1  = EMAX*FABRICSTRAININC(K,1)
            S2  = EMAX*FABRICSTRAININC(K,2)
            TAU = GMAX*TWO*FABRICSTRAININC(K,4)
         ELSE IF (LOP .EQ. 0) THEN
            S1 = ZERO
            S2 = ZERO
            TAU = ZERO
         ELSE
            IF (MAX(E1,E2) .GT. PROPS(9)) FLAG = ZERO
            CALL K9_BILIN(E1, PROPS(1), PROPS(2), PROPS(3), PROPS(4),
     1                    S1, WY)
            CALL K9_BILIN(E2, PROPS(1), PROPS(2), PROPS(3), PROPS(4),
     1                    S2, WY)
            CALL K9_BILIN(ABS(GAM), PROPS(5), PROPS(6), PROPS(7), ONE,
     1                    TAU, WS)
            EBAR = HALF*(MAX(E1,ZERO) + MAX(E2,ZERO))
            TAU  = SIGN(TAU, GAM)*(ONE + PROPS(8)*EBAR)
            IF (E1 .GT. ZERO) S1 = S1 + HALF*PROPS(8)*WS
            IF (E2 .GT. ZERO) S2 = S2 + HALF*PROPS(8)*WS
            IF (FLAG .EQ. ZERO) THEN
               S1 = ZERO
               S2 = ZERO
               TAU = ZERO
            ENDIF
         ENDIF
         FABRICSTRESSNEW(K,1) = S1
         FABRICSTRESSNEW(K,2) = S2
         FABRICSTRESSNEW(K,3) = TAU
         STATENEW(K,1)  = FLAG
         STATENEW(K,2)  = GAM
         ENERINELAS(K)  = ZERO
  100 CONTINUE
      RETURN
      END
!
      SUBROUTINE K9_BILIN(X, A, B, XK, BETA, Y, W)
!     Bilinear law: slope A to XK, B beyond, BETA*A for X < 0.
!     Y = f(X) and W = integral of f from 0 to X
      INCLUDE 'VABA_PARAM.INC'
      IF (X .LT. 0.0D0) THEN
         Y = BETA*A*X
         W = 0.5D0*Y*X
      ELSE IF (X .LE. XK) THEN
         Y = A*X
         W = 0.5D0*Y*X
      ELSE
         Y = A*XK + B*(X - XK)
         W = 0.5D0*A*XK*XK + A*XK*(X - XK) + 0.5D0*B*(X - XK)**2
      ENDIF
      RETURN
      END
