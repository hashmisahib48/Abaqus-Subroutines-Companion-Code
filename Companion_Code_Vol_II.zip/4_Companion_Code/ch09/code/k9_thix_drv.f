      PROGRAM K9THXD
!     Driver for the thixotropic VUVISCOSITY (ex9_vuvisc_thix.f).
!     A block of NB points with different shear rates follows one
!     history of NT steps; each step has its own DT and a factor that
!     multiplies the shear rates.  Writes time, factor, ZETA(1..NB).
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NM = 64)
      DIMENSION PROPS(4), GR0(NM), GR(NM), TT(NM), ETA(NM)
      DIMENSION JEL(NM), FO(NM,1), FN(NM,1), SO(NM,1), SN(NM,1)
      CHARACTER*80 CMNAME
      CMNAME = 'THIX'
      READ(5,*) PROPS
      READ(5,*) NB
      READ(5,*) (GR0(K), K = 1, NB)
      READ(5,*) NT
      TIME = 0.0D0
      DO K = 1, NB
         JEL(K) = K
         SO(K,1) = 0.0D0
         TT(K) = 20.0D0
      ENDDO
      DO N = 1, NT
         READ(5,*) DT, FAC
         DO K = 1, NB
            GR(K) = FAC*GR0(K)
         ENDDO
         CALL VUVISCOSITY(NB, JEL, 1, 1, 1, TIME, TIME, DT, CMNAME, 1,
     1     0, 4, PROPS, TT, TT, FO, FN, SO, GR, ETA, SN)
         TIME = TIME + DT
         DO K = 1, NB
            SO(K,1) = SN(K,1)
         ENDDO
         WRITE(6,'(40ES20.12)') TIME, FAC, (SN(K,1), K = 1, NB),
     1                          (ETA(K), K = 1, NB)
      ENDDO
      END
