      SUBROUTINE VUVISCOSITY(
     1  NBLOCK, JELEM, KINTPT, KLAYER, KSECPT,
     2  STEPTIME, TOTALTIME, DT, CMNAME, NSTATEV, NFIELDV, NPROPS,
     3  PROPS, TEMPOLD, TEMPNEW, FIELDOLD, FIELDNEW, STATEOLD,
     4  SHRRATE, VISCOSITY, STATENEW)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION JELEM(NBLOCK), PROPS(NPROPS), TEMPOLD(NBLOCK),
     1  TEMPNEW(NBLOCK), FIELDOLD(NBLOCK,NFIELDV),
     2  FIELDNEW(NBLOCK,NFIELDV), STATEOLD(NBLOCK,NSTATEV),
     3  SHRRATE(NBLOCK), VISCOSITY(NBLOCK), STATENEW(NBLOCK,NSTATEV)
      CHARACTER*80 CMNAME
!
!     Shear-thinning viscosity, Arrhenius time-temperature shift
!     PROPS: 1 MODEL (1 Cross, 2 Carreau-Yasuda)   2 ETA0 (MPa*s)
!            3 ETAINF (MPa*s)   4 LAMBDA (s)   5 N (-), N < 1
!            6 A (-) (Carreau-Yasuda)   7 EA/R (K)
!            8 TREF (model units)  9 TZERO (K): 273.15 for deg C,
!            0 for K
      PARAMETER (ZERO = 0.0D0, ONE = 1.0D0)
      IMODEL = NINT(PROPS(1))
      ETA0   = PROPS(2)
      ETAINF = PROPS(3)
      XLAM   = PROPS(4)
      XN     = PROPS(5)
      XA     = PROPS(6)
      EAR    = PROPS(7)
      TRF    = PROPS(8) + PROPS(9)
      DO 100 K = 1, NBLOCK
         TABS = TEMPNEW(K) + PROPS(9)
         AT   = EXP(EAR*(ONE/TABS - ONE/TRF))       ! a_T
         X    = AT*XLAM*MAX(SHRRATE(K), ZERO)
         IF (IMODEL .EQ. 1) THEN
            SHAPE = ONE/(ONE + X**(ONE - XN))        ! Cross
         ELSE
            SHAPE = (ONE + X**XA)**((XN - ONE)/XA)   ! C-Y
         ENDIF
         VISCOSITY(K) = AT*(ETAINF + (ETA0 - ETAINF)*SHAPE)
  100 CONTINUE
      RETURN
      END
