      PROGRAM K9FABD
!     Driver for VFABRIC (outside Abaqus).  Reads from unit 5.
!     MODE 1: one increment from the unstrained state for a block of
!             points: lines E1 E2 GAMMA; LOP and TOTALTIME are given.
!     MODE 2: NB parallel paths of NS increments: for every step a line
!             per path with DE1 DE2 DGAMMA.  Reports the final state,
!             the work done (trapezoid rule) and the history of path 1.
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PROPS(9)
      READ(5,*) PROPS
      READ(5,*) DENS
      READ(5,*) MODE
      IF (MODE .EQ. 1) THEN
         READ(5,*) LOP, TTIME, N
      ELSE
         READ(5,*) N, NS
      ENDIF
      CALL K9_RUN(N, MODE, LOP, TTIME, NS, PROPS, DENS)
      END
!
      SUBROUTINE K9_RUN(N, MODE, LOP, TTIME, NS, PROPS, DENS)
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION PROPS(9), EPS(N,4), DEP(N,4), SIG(N,3), SIGN(N,3)
      DIMENSION ST(N,2), STN(N,2), W(N), E0(N), EI(N)
      DIMENSION JEL(N), CO(N,2), CL(N), DEN(N), BA(N), TO(N)
      DIMENSION FO(N,1), TN(N), FN(N,1)
      CHARACTER*80 CMNAME
      CMNAME = 'FABRIC'
      DO K = 1, N
         JEL(K) = K
         DEN(K) = DENS
         BA(K)  = 1.5707963267948966D0
         CL(K)  = 1.0D0
      ENDDO
      IF (MODE .EQ. 1) THEN
         DO K = 1, N
            READ(5,*) E1, E2, GAM
            DEP(K,1) = E1
            DEP(K,2) = E2
            DEP(K,3) = 0.0D0
            DEP(K,4) = 0.5D0*GAM
            EPS(K,:) = DEP(K,:)
            SIG(K,:) = 0.0D0
            ST(K,1) = 1.0D0
            ST(K,2) = 0.0D0
         ENDDO
         CALL VFABRIC(N, 2, 1, 1, 1, 1, 1, 2, 0, 9, LOP, JEL, TTIME,
     1     TTIME, 1.0D-6, CMNAME, CO, CL, PROPS, DEN, BA, EPS, DEP,
     2     TO, FO, SIG, ST, TN, FN, E0, SIGN, STN, EI)
         DO K = 1, N
            WRITE(6,'(5ES24.15)') SIGN(K,1), SIGN(K,2), SIGN(K,3),
     1                            STN(K,1), STN(K,2)
         ENDDO
      ELSE
         DO K = 1, N
            EPS(K,:) = 0.0D0
            SIG(K,:) = 0.0D0
            ST(K,1) = 1.0D0
            ST(K,2) = 0.0D0
            W(K) = 0.0D0
         ENDDO
         DO IS = 1, NS
            DO K = 1, N
               READ(5,*) D1, D2, DG
               DEP(K,1) = D1
               DEP(K,2) = D2
               DEP(K,3) = 0.0D0
               DEP(K,4) = 0.5D0*DG
               EPS(K,:) = EPS(K,:) + DEP(K,:)
            ENDDO
            CALL VFABRIC(N, 2, 1, 1, 1, 1, IS, 2, 0, 9, 1, JEL,
     1        1.0D0*IS, 1.0D0*IS, 1.0D-6, CMNAME, CO, CL, PROPS, DEN,
     2        BA, EPS, DEP, TO, FO, SIG, ST, TN, FN, E0, SIGN, STN,
     3        EI)
            DO K = 1, N
               W(K) = W(K) + 0.5D0*((SIG(K,1) + SIGN(K,1))*DEP(K,1)
     1           + (SIG(K,2) + SIGN(K,2))*DEP(K,2)
     2           + (SIG(K,3) + SIGN(K,3))*2.0D0*DEP(K,4))
               SIG(K,:) = SIGN(K,:)
               ST(K,:)  = STN(K,:)
            ENDDO
            WRITE(7,'(8ES20.12)') EPS(1,1), EPS(1,2), 2.0D0*EPS(1,4),
     1         SIG(1,1), SIG(1,2), SIG(1,3), W(1), ST(1,1)
         ENDDO
         DO K = 1, N
            WRITE(6,'(8ES24.15)') EPS(K,1), EPS(K,2), 2.0D0*EPS(K,4),
     1        SIG(K,1), SIG(K,2), SIG(K,3), W(K), ST(K,1)
         ENDDO
      ENDIF
      RETURN
      END
