      PROGRAM K9VISD
!     Driver for VUVISCOSITY (outside Abaqus).  Reads from unit 5.
!     MODE 1: evaluate a block (SHRRATE, TEMP) -> VISCOSITY
!     MODE 2: steady plane Poiseuille flow between plates 2H apart,
!             pressure gradient G = -dp/dx, by Picard iteration on the
!             viscosity of N cell faces (one block per iteration)
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NM = 4000)
      DIMENSION PROPS(9), GR(NM), TT(NM), ETA(NM)
      READ(5,*) PROPS
      READ(5,*) MODE
      IF (MODE .EQ. 1) THEN
         READ(5,*) N
         DO K = 1, N
            READ(5,*) GR(K), TT(K)
         ENDDO
         CALL K9_VCALL(N, PROPS, GR, TT, ETA)
         DO K = 1, N
            WRITE(6,'(3ES24.15)') GR(K), TT(K), ETA(K)
         ENDDO
      ELSE
         READ(5,*) H, G, NY, TEMP
         CALL K9_SLIT(PROPS, H, G, NY, TEMP)
      ENDIF
      END
!
      SUBROUTINE K9_VCALL(N, PROPS, GR, TT, ETA)
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NM = 4000)
      DIMENSION PROPS(9), GR(N), TT(N), ETA(N)
      DIMENSION JEL(NM), FO(NM,1), FN(NM,1), SO(NM,1), SN(NM,1)
      CHARACTER*80 CMNAME
      CMNAME = 'VISC'
      DO K = 1, N
         JEL(K) = K
      ENDDO
      CALL VUVISCOSITY(N, JEL, 1, 1, 1, 0.0D0, 0.0D0, 1.0D-6, CMNAME,
     1  0, 0, 9, PROPS, TT, TT, FO, FN, SO, GR, ETA, SN)
      RETURN
      END
!
      SUBROUTINE K9_SLIT(PROPS, H, G, NY, TEMP)
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NM = 4000)
      DIMENSION PROPS(9), U(0:NM), GR(NM), TT(NM), ETA(NM), ETAO(NM)
      DIMENSION A(0:NM), B(0:NM), C(0:NM), R(0:NM)
      DY = H/NY
      DO K = 1, NY
         TT(K) = TEMP
         GR(K) = 0.0D0
      ENDDO
      CALL K9_VCALL(NY, PROPS, GR, TT, ETAO)
      NIT = 0
      DO ITER = 1, 3000
         DO J = 0, NY - 1
            IF (J .EQ. 0) THEN
               A(J) = 0.0D0
               B(J) = -ETAO(1)/DY
               C(J) = ETAO(1)/DY
               R(J) = -0.5D0*G*DY
            ELSE
               A(J) = ETAO(J)/DY
               B(J) = -(ETAO(J) + ETAO(J+1))/DY
               C(J) = ETAO(J+1)/DY
               R(J) = -G*DY
            ENDIF
         ENDDO
!        Thomas algorithm for u(0..NY-1), u(NY) = 0
         DO J = 1, NY - 1
            W = A(J)/B(J-1)
            B(J) = B(J) - W*C(J-1)
            R(J) = R(J) - W*R(J-1)
         ENDDO
         U(NY) = 0.0D0
         U(NY-1) = R(NY-1)/B(NY-1)
         DO J = NY - 2, 0, -1
            U(J) = (R(J) - C(J)*U(J+1))/B(J)
         ENDDO
         DO K = 1, NY
            GR(K) = ABS(U(K-1) - U(K))/DY
         ENDDO
         CALL K9_VCALL(NY, PROPS, GR, TT, ETA)
         DMAX = 0.0D0
         DO K = 1, NY
            DMAX = MAX(DMAX, ABS(ETA(K) - ETAO(K))/ETA(K))
            ETAO(K) = 0.5D0*(ETAO(K) + ETA(K))
         ENDDO
         NIT = ITER
         IF (DMAX .LT. 1.0D-10) GOTO 50
      ENDDO
   50 CONTINUE
      UM = 0.0D0
      DO J = 0, NY - 1
         UM = UM + U(J)
      ENDDO
      UM = (UM - 0.5D0*U(0))*DY/H
      WRITE(6,'(3ES24.15,I6)') UM, GR(NY), U(0), NIT
      DO J = 0, NY
         WRITE(6,'(2ES24.15)') J*DY, U(J)
      ENDDO
      RETURN
      END
