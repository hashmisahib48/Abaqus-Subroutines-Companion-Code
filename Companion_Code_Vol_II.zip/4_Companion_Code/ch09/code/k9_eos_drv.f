      PROGRAM K9EOSD
!     Driver for VUEOS (outside Abaqus).  Reads commands from unit 5.
!     MODE 1: evaluate a block (RHO, EM) -> P, DPDRHO, DPDEM
!     MODE 2: one energy-coupled step for a block of points; Newton on
!             the energy equation  E - E0 + (P0+P)/2*(1/RHO - 1/RHO0)=0
!             using DPDEM scaled by SC (SC=1 is the routine's value)
!     MODE 3: one history (list of densities), block of one point
!     The Newton loop is a stand-in for the update done by Abaqus,
!     whose algorithm is not documented; it tests the routine only.
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NM = 2000)
      DIMENSION PROPS(3), RHO(NM), EM(NM), P(NM), DR(NM), DE(NM)
      DIMENSION RO(NM), EO(NM), PO(NM), RN(NM), NIT(NM)
      READ(5,*) PROPS, RHO0
      READ(5,*) MODE
      IF (MODE .EQ. 1) THEN
         READ(5,*) N
         DO K = 1, N
            READ(5,*) RHO(K), EM(K)
         ENDDO
         CALL K9_CALL(N, PROPS, RHO0, RHO, EM, P, DR, DE)
         DO K = 1, N
            WRITE(6,'(5ES24.15)') RHO(K), EM(K), P(K), DR(K), DE(K)
         ENDDO
      ELSE IF (MODE .EQ. 2) THEN
         READ(5,*) N, SC
         DO K = 1, N
            READ(5,*) RO(K), EO(K), PO(K), RN(K)
         ENDDO
         CALL K9_ESTEP(N, PROPS, RHO0, RO, EO, PO, RN, SC, EM, P, DR,
     1                 DE, NIT)
         DO K = 1, N
            WRITE(6,'(5ES24.15,I4)') RN(K), EM(K), P(K), DR(K), DE(K),
     1                               NIT(K)
         ENDDO
      ELSE
         READ(5,*) N, SC
         READ(5,*) RHO(1)
         EM(1) = 0.0D0
         P(1)  = 0.0D0
         CALL K9_CALL(1, PROPS, RHO0, RHO, EM, P, DR, DE)
         EO(1) = 0.0D0
         WRITE(6,'(4ES24.15)') RHO(1), EO(1), P(1), 0.0D0
         DO K = 1, N
            READ(5,*) RN(1)
            RO(1) = RHO(1)
            PO(1) = P(1)
            CALL K9_ESTEP(1, PROPS, RHO0, RO, EO, PO, RN, SC, EM, P,
     1                    DR, DE, NIT)
            RHO(1) = RN(1)
            EO(1)  = EM(1)
            WRITE(6,'(4ES24.15)') RHO(1), EO(1), P(1), DR(1)
         ENDDO
      ENDIF
      END
!
      SUBROUTINE K9_CALL(N, PROPS, RHO0, RHO, EM, P, DR, DE)
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NM = 2000)
      DIMENSION PROPS(3), RHO(N), EM(N), P(N), DR(N), DE(N)
      DIMENSION JEL(NM), TO(NM), TN(NM), FO(NM,1), FN(NM,1)
      DIMENSION SO(NM,1), SN(NM,1), CL(NM), CO(NM,3), DM(NM)
      DIMENSION R0(NM), DK(NM)
      CHARACTER*80 CMNAME
      CMNAME = 'EOS'
      DO K = 1, N
         JEL(K) = K
         R0(K)  = RHO0
         DM(K)  = RHO(K)
         DK(K)  = 0.0D0
      ENDDO
      CALL VUEOS(N, JEL, 1, 1, 1, 0.0D0, 0.0D0, 1.0D-6, CMNAME, 0, 0,
     1  3, PROPS, TO, TN, FO, FN, SO, CL, CO, DM, R0, RHO, DK, EM, P,
     2  DR, DE, SN)
      RETURN
      END
!
      SUBROUTINE K9_ESTEP(N, PROPS, RHO0, RO, EO, PO, RN, SC, EN, PN,
     1                    DR, DE, NIT)
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (NM = 2000)
      DIMENSION PROPS(3), RO(N), EO(N), PO(N), RN(N), EN(N), PN(N)
      DIMENSION DR(N), DE(N), NIT(N), G(NM)
      LOGICAL DONE(NM)
      DO K = 1, N
         EN(K) = EO(K)
         DONE(K) = .FALSE.
         NIT(K) = 0
      ENDDO
      DO ITER = 1, 60
         CALL K9_CALL(N, PROPS, RHO0, RN, EN, PN, DR, DE)
         NOPEN = 0
         DO K = 1, N
            IF (.NOT. DONE(K)) THEN
               DV = 1.0D0/RN(K) - 1.0D0/RO(K)
               G(K) = EN(K) - EO(K) + 0.5D0*(PO(K) + PN(K))*DV
               TOL = 1.0D-11*(ABS(EN(K)) + ABS(EO(K)) + 1.0D8)
               IF (ABS(G(K)) .LE. TOL) THEN
                  DONE(K) = .TRUE.
                  NIT(K) = ITER
               ELSE
                  GP = 1.0D0 + 0.5D0*SC*DE(K)*DV
                  EN(K) = EN(K) - G(K)/GP
                  NOPEN = NOPEN + 1
               ENDIF
            ENDIF
         ENDDO
         IF (NOPEN .EQ. 0) RETURN
      ENDDO
      DO K = 1, N
         IF (.NOT. DONE(K)) NIT(K) = -1
      ENDDO
      RETURN
      END
