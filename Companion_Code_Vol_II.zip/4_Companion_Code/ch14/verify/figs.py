import sys, json, os
sys.path.insert(0,'/home/claude/vol2/lib'); sys.path.insert(0,os.path.dirname(__file__))
from figstyle import *
import numpy as np
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
R=json.load(open('out/results.json'))
FS=7.8
def tx(ax,x,y,s,fs=FS,**k):
    k.setdefault('fontsize',fs); ax.text(x,y,s,**k)
E1,E2,G12,NU12=140000.,10000.,5000.,0.3
nu21=NU12*E2/E1; d=1-NU12*nu21; Q11,Q22,Q12,Q66=E1/d,E2/d,NU12*E2/d,G12
def qb11(th):
    t=np.radians(th); U1=(3*Q11+3*Q22+2*Q12+4*Q66)/8; U2=(Q11-Q22)/2; U3=(Q11+Q22-2*Q12-4*Q66)/8
    return U1+U2*np.cos(2*t)+U3*np.cos(4*t)
PLYCOL={0:'#CFE0F7',90:'#F7D9D4',45:'#D8EFE0',-45:'#EBDDF3',30:'#D8EFE0',-30:'#EBDDF3'}

def stack(ax,angles,thick,x0=0,w=1.0,show_ang=True,zlab=True,fs=FS):
    h=sum(thick); z=-h/2
    for a,t in zip(angles,thick):
        ax.add_patch(Rectangle((x0,z),w,t,fc=PLYCOL.get(a,'#EEE'),ec=NAVY,lw=0.8))
        if show_ang: ax.text(x0+w/2,z+t/2,f'{a:g}°'.replace('-','−'),ha='center',va='center',fontsize=fs,color=NAVY)
        z+=t
    return h

# ---------------- Fig 14.2-1: laminate, strain and stress profiles ----------------
ang=[0,45,-45,90,90,-45,45,0]; tp=0.125; th=[tp]*8; h=1.0
fig,axs=plt.subplots(1,3,figsize=(4.9,2.4),dpi=240,gridspec_kw={'width_ratios':[1,1,1.1]})
a=axs[0]; a.set_xlim(-0.6,1.25); a.set_ylim(-0.62,0.66); a.axis('off')
stack(a,ang,th,x0=0,w=1.0)
a.annotate('',xy=(-0.18,0.5),xytext=(-0.18,-0.5),arrowprops=dict(arrowstyle='<->',color=GREY,lw=0.7))
tx(a,-0.25,0,'$h$ = 1 mm',rotation=90,ha='right',va='center',color=GREY)
arr(a,(-0.05,-0.56),(-0.05,0.0),c='white',lw=0)
tx(a,0.5,0.6,'(a) plies, $z_k$',color=GREY,ha='center')
for k in range(9):
    pass
tx(a,1.04,0.5,'$z$=0.5',ha='left',va='center',color=GREY,fontsize=7.5); tx(a,1.04,-0.5,'$-$0.5',ha='left',va='center',color=GREY,fontsize=7.5)
tx(a,1.04,0,'0',ha='left',va='center',color=GREY,fontsize=7.5)
a=axs[1]; a.set_xlim(-1.3,1.3); a.set_ylim(-0.62,0.66)
for s in ('left','top','right'): a.spines[s].set_visible(False)
a.spines['bottom'].set_visible(False); a.set_yticks([]); a.set_xticks([])
a.axvline(0,color=GREY,lw=0.6); a.axhline(0,color=GREY,lw=0.4,ls=':')
e0,kap=0.3,0.8
zz=np.array([-0.5,0.5]); a.plot(e0+kap*zz,zz,color=BLUE,lw=1.4)
a.fill_betweenx(zz,0,e0+kap*zz,color=LB,alpha=0.8)
tx(a,0.5,0.6,'(b) $\\varepsilon(z)$',color=GREY,ha='center')
a.annotate('',xy=(e0,0.0),xytext=(0,0),arrowprops=dict(arrowstyle='->',color=RED,lw=0.9)); tx(a,e0/2,-0.05,'$\\varepsilon^0$',color=RED,ha='center',va='top',fontsize=8)
tx(a,0.15,0.42,'slope $\\kappa$',color=BLUE,ha='left',va='center',fontsize=7.8)
a=axs[2]; a.set_xlim(-1.3,1.3); a.set_ylim(-0.62,0.66)
for s in ('left','top','right','bottom'): a.spines[s].set_visible(False)
a.set_yticks([]); a.set_xticks([]); a.axvline(0,color=GREY,lw=0.6); a.axhline(0,color=GREY,lw=0.4,ls=':')
z0=-0.5
for ag,t in zip(ang,th):
    za=np.array([z0,z0+t]); sg=np.array([qb11(ag)*(e0*0+kap*z) for z in za])/qb11(0)
    a.fill_betweenx(za,0,sg,color=PINK,alpha=0.9,lw=0); a.plot(sg,za,color=RED,lw=1.0)
    a.plot([sg[1],sg[1]],[z0+t,z0+t],color=RED,lw=0)
    z0+=t
tx(a,0.0,0.6,'(c) $\\sigma_{11}(z)$',color=GREY,ha='center')
tx(a,1.28,-0.35,'jumps at the\ninterfaces\n($\\kappa_{11}$ only)',color=RED,ha='right',va='center',fontsize=7.5)
fig.subplots_adjust(wspace=0.12,left=0.02,right=0.99,top=0.96,bottom=0.04)
save(fig,'fig_stack.png')

# ---------------- Fig 14.4-1: flow of UGENS ----------------
fig,ax=new(4.9,3.4)
ax.set_xlim(0,10); ax.set_ylim(0,7); ax.set_aspect('auto')
box(ax,0.1,5.6,3.0,1.2,'Abaqus\n(element, Newton loop)',fc=LGREY,ec=GREY,fs=8)
tx(ax,3.5,6.55,'STRAN, DSTRAN, PROPS, STATEV',color=BLUE,ha='left',va='center',fontsize=7.6)
tx(ax,3.5,5.85,'FORCE(6), DDNDDE, SSE, STATEV',color=RED,ha='left',va='center',fontsize=7.6)
arr(ax,(3.1,6.45),(3.4,6.45),c=BLUE,lw=1.0); arr(ax,(3.4,5.95),(3.1,5.95),c=RED,lw=1.0)
box(ax,0.1,4.2,3.6,0.9,'UGENS:\ne = STRAN + DSTRAN',fc=LB,ec=BLUE,fs=7.8)
arr(ax,(1.9,5.6),(1.9,5.12),c=BLUE,lw=1.0)
box(ax,0.1,2.7,3.6,1.1,'K14_SEC: loop over plies k\nand Gauss points i (z$_i$, w$_i$)',fc=LB,ec=BLUE,fs=8)
arr(ax,(1.9,4.2),(1.9,3.82),c=BLUE,lw=1.0)
box(ax,4.6,2.0,5.2,3.0,'',fc=LB,ec=BLUE)
for k,t in enumerate(['K14_LAM at the point:','e$_{xy}$ = $\\varepsilon^0$ + z $\\kappa$','rotate to the ply axes: e$_{12}$ = T e$_{xy}$','solve $\\tau$ from $\\gamma_{12}$ (Newton)','$\\sigma_{12}$, tangent Q$_t$, w, failure index','rotate back: $\\sigma_{xy}$ = T$^T\\sigma_{12}$, $\\bar{Q}$ = T$^T$Q$_t$T']):
    tx(ax,4.75,4.65-k*0.5,t,color=NAVY,ha='left',va='center',fontsize=7.8,weight='bold' if k==0 else 'normal')
arr(ax,(3.7,3.3),(4.6,3.3),c=BLUE,lw=1.0); arr(ax,(4.6,2.75),(3.7,2.75),c=RED,lw=1.0)
box(ax,0.1,0.8,9.7,1.1,'N, M, C$_t$, W accumulate with the weights w$_i$;\nFI = largest ply index  →  FORCE, DDNDDE, SSE, STATEV',fc=PINK,ec=RED,fs=7.8)
arr(ax,(1.9,2.7),(1.9,1.92),c=RED,lw=1.0); tx(ax,0.1,0.25,'blue: data flowing in;  red: results written by the routine',color=GREY,ha='left',fontsize=7.5)
save(fig,'fig_flow.png')

# ---------------- Fig 14.5-1: ABD patterns ----------------
fig,axs=plt.subplots(1,3,figsize=(4.9,1.95),dpi=240)
names=[('QI','[0/45/−45/90]$_s$'),('CP','[0/90]'),('AP','[30/−30]')]
for a,(k,ti) in zip(axs,names):
    M=np.array(R['abd'][k]['ref']); mx=np.abs(M).max()
    L=np.where(np.abs(M)<1e-6*mx,np.nan,np.sign(M)*np.log10(np.maximum(np.abs(M),1)))
    a.imshow(np.where(np.isnan(L),0,np.sign(L)*(np.abs(L))),cmap='RdBu_r',vmin=-5,vmax=5,alpha=1) if False else None
    cm=plt.get_cmap('RdBu_r').copy(); cm.set_bad('white')
    a.imshow(L,cmap=cm,vmin=-5.2,vmax=5.2)
    for i in range(7): a.axhline(i-0.5,color='white',lw=0.5); a.axvline(i-0.5,color='white',lw=0.5)
    a.axhline(2.5,color=NAVY,lw=0.9); a.axvline(2.5,color=NAVY,lw=0.9)
    a.set_xticks([]); a.set_yticks([]); 
    for s in a.spines.values(): s.set_visible(True); s.set_color(NAVY); s.set_linewidth(0.8)
    a.set_title(ti,fontsize=8,color=NAVY,pad=3)
    for (x,y,t) in ((1,1,'A'),(4,1,'B'),(1,4,'B'),(4,4,'D')):
        a.text(x,y,t,ha='center',va='center',fontsize=9,color='#444',alpha=0.5,weight='bold')
fig.subplots_adjust(wspace=0.08,left=0.01,right=0.99,top=0.88,bottom=0.12)
fig.text(0.5,0.015,'colour: sign × log$_{10}$|entry|;  white: zero (|entry| < 10$^{-6}$ of the largest)',ha='center',fontsize=7.5,color=GREY)
save(fig,'fig_abd.png')

# ---------------- Fig 14.5-2: nonlinear response and FD error ----------------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.3),dpi=240)
c=R['curve']; g=np.array(c['g'])
gg=g[1:]; a1.plot(gg*1e3,np.array(c['N12lin'])[1:]/gg/1e3,color=GREY,lw=1.0,ls='--'); a1.plot(gg*1e3,np.array(c['N12'])[1:]/gg/1e3,color=BLUE,lw=1.4); a1.set_ylim(19.4,20.8)
a1.set_xlabel('$\\gamma^0_{12}$ ($10^{-3}$)',fontsize=8.5); a1.set_ylabel('$N_{12}/\\gamma^0_{12}$ ($10^3$ N/mm)',fontsize=8.5); a1.tick_params(labelsize=7.8)
tx(a1,19.5,20.65,'linear: $A_{66}$',color=GREY,ha='right',va='top',fontsize=7.8); tx(a1,19.5,19.55,'nonlinear shear',color=BLUE,ha='right',va='bottom',fontsize=7.8)
tx(a1,-0.1,1.02,'(a)',transform=a1.transAxes,color=GREY,fontsize=8); 
hh=np.array([x[0] for x in R['nl']['fd']]); ee=np.array([x[1] for x in R['nl']['fd']])
a2.loglog(hh,ee,'o-',color=RED,ms=3,lw=1.0)
a2.set_xlabel('relative step $h$',fontsize=8.5); a2.set_ylabel('max error of $\\mathbf{C}_{fd}$ / max |$\\mathbf{C}$|',fontsize=8.5); a2.tick_params(labelsize=7.8)
tx(a2,3e-3,3e-6,'truncation\n$\\propto h^2$',color=GREY,ha='left',fontsize=7.8); tx(a2,3e-8,6e-10,'round-off\n$\\propto 1/h$',color=GREY,ha='left',fontsize=7.8)
a2.invert_xaxis(); tx(a2,-0.2,1.02,'(b)',transform=a2.transAxes,color=GREY,fontsize=8)
fig.subplots_adjust(wspace=0.55,left=0.11,right=0.99,top=0.93,bottom=0.2)
save(fig,'fig_nl.png')

# ---------------- Fig 14.6-1: VUGENS arrays and packed storage ----------------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.5),dpi=240,gridspec_kw={'width_ratios':[1.15,1]})
a1.set_xlim(0,10); a1.set_ylim(0,10); a1.axis('off')
rows=[('strainInc',['11','22','33','12$^t$'],BLUE),('curvInc',['11','22','12$^t$'],BLUE),('forceNew',['N11','N22','N12'],RED),('xmomNew',['M11','M22','M12'],RED)]
y=9.0
for nm,cols,col in rows:
    tx(a1,0.0,y-0.9,nm,color=col,fontsize=7.8,ha='left',va='center',weight='bold')
    x=3.3
    for c_ in cols:
        for kk in range(2):
            a1.add_patch(Rectangle((x,y-kk*0.55-0.9),1.45,0.5,fc=LB if col==BLUE else PINK,ec=col,lw=0.6))
        tx(a1,x+0.72,y-0.05,c_,fontsize=7.5,ha='center',va='center',color=NAVY)
        x+=1.5
    y-=2.2
a1.text(0,0.0,'one row per point of the block;  $^t$ tensor component',fontsize=7.5,color=GREY)
a2.set_xlim(0.5,6.5); a2.set_ylim(7.1,0.0); a2.set_aspect('equal'); a2.axis('off')
L=0
for j in range(1,7):
    for i in range(1,j+1):
        L+=1
        a2.add_patch(Rectangle((j-0.5,i-0.5),1,1,fc=LB if (i<=3)==(j<=3) else '#FDF0E0',ec=BLUE,lw=0.5))
        tx(a2,j,i,str(L),fontsize=7.5,ha='center',va='center',color=NAVY)
    for i in range(j+1,7): a2.add_patch(Rectangle((j-0.5,i-0.5),1,1,fc='white',ec=GRID,lw=0.4))
for k,l in enumerate(['N11','N22','N12','M11','M22','M12']):
    tx(a2,0.1,k+1,l,fontsize=7.2,ha='right',va='center',color=GREY); tx(a2,k+1,0.25,l,fontsize=7.2,ha='center',va='bottom',color=GREY)
tx(a2,3.5,6.75,'ddndde(k, 1…21): packed upper triangle',fontsize=7.6,ha='center',va='top',color=NAVY)
fig.subplots_adjust(wspace=0.08,left=0.0,right=1.0,top=0.97,bottom=0.1)
save(fig,'fig_block.png')

# ---------------- Fig 14.7-1: design response ----------------
fig,(a1,a2)=plt.subplots(1,2,figsize=(4.9,2.4),dpi=240,gridspec_kw={'width_ratios':[1.15,1]})
al=0.15
s1,s2=np.meshgrid(np.linspace(-150,150,300),np.linspace(-150,150,300))
q=np.sqrt(s1**2-s1*s2+s2**2); phi=q+al*(s1+s2)
cs=a1.contour(s1,s2,phi,levels=[50,100,150],colors=[BLUE],linewidths=1.0)
a1.contour(s1,s2,q,levels=[50,100,150],colors=[GREY],linewidths=0.8,linestyles='--')
a1.clabel(cs,fmt='%d',fontsize=7)
for (p1,p2) in [(60,-40),(90,60),(-60,-70)]:
    qq=np.sqrt(p1**2-p1*p2+p2**2); g1=(2*p1-p2)/(2*qq)+al; g2=(2*p2-p1)/(2*qq)+al
    arr(a1,(p1,p2),(p1+60*g1,p2+60*g2),c=RED,lw=1.0,ms=6); a1.plot(p1,p2,'o',color=RED,ms=2.5)
a1.set_aspect('equal'); a1.set_xlabel('$S_{11}$ (MPa)',fontsize=8.5); a1.set_ylabel('$S_{22}$ (MPa)',fontsize=8.5); a1.tick_params(labelsize=7.8)
a1.set_title('(a) solid: $\\phi$ ($\\alpha$=0.15); dashed: Mises $q$',fontsize=7.6,color=GREY,pad=3)
hh=np.array([x[0] for x in R['dresp']['fd']]); ee=np.array([x[1] for x in R['dresp']['fd']])
a2.loglog(hh,ee,'o-',color=RED,ms=3,lw=1.0); a2.invert_xaxis()
a2.set_xlabel('relative step $h$',fontsize=8.5); a2.set_ylabel('max |$\\partial\\phi/\\partial S_i$ − FD|',fontsize=8.5); a2.tick_params(labelsize=7.8)
tx(a2,-0.35,1.02,'(b)',transform=a2.transAxes,color=GREY,fontsize=8)
fig.subplots_adjust(wspace=0.5,left=0.1,right=0.99,top=0.93,bottom=0.2)
save(fig,'fig_dresp.png')

# ---------------- Fig 14.8-1: offset history ----------------
fig,ax=plt.subplots(figsize=(4.4,2.1),dpi=240)
off=R['off']; it=[int(o[2]) for o in off]; sd=[float(o[3]) for o in off]; of=[float(o[4]) for o in off]; st=[int(o[1]) for o in off]
ax.axvspan(0.5,5.5,color=LB,alpha=0.7,lw=0); ax.axvspan(5.5,8.5,color='#FDF0E0',alpha=0.8,lw=0)
ax.plot(it,sd,'o-',color=BLUE,lw=1.1,ms=3.5); ax.set_ylim(0,1.15); ax.set_xlim(0.5,8.5)
ax.set_xlabel('call number',fontsize=8.5); ax.set_ylabel('SDEGOLD (–)',fontsize=8.5,color=BLUE); ax.tick_params(labelsize=7.8)
ax2=ax.twinx(); ax2.spines['right'].set_visible(True); ax2.step(it,of,where='post',color=RED,lw=1.4); ax2.plot(it,of,'s',color=RED,ms=3.5)
ax2.set_ylim(-0.0004,0.0058); ax2.set_ylabel('OFFSETNEW (mm)',fontsize=8.5,color=RED); ax2.tick_params(labelsize=7.8)
tx(ax,3,1.06,'step 1',color=NAVY,ha='center',fontsize=8); tx(ax,7,1.06,'step 2',color=NAVY,ha='center',fontsize=8)
save(fig,'fig_off.png')
print('figs ok')
