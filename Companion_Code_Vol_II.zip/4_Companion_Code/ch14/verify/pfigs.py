import sys, os
sys.path.insert(0,'/home/claude/vol2/lib')
from figstyle import *
import numpy as np
os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)),'..'))
FS=7.8
COL={0:'#CFE0F7',90:'#F7D9D4',45:'#D8EFE0',-45:'#EBDDF3',30:'#D8EFE0',-30:'#EBDDF3'}
def tx(ax,x,y,s,fs=FS,**k): k.setdefault('fontsize',fs); ax.text(x,y,s,**k)
def stk(ax,angles,th,x0,w,sc,lab=True):
    z=0
    for a,t in zip(angles,th):
        ax.add_patch(Rectangle((x0,z*sc),w,t*sc,fc=COL.get(a,'#EEE'),ec=NAVY,lw=0.8))
        tx(ax,x0+w/2,(z+t/2)*sc,f'{a}°'.replace('-','−'),ha='center',va='center',color=NAVY); z+=t
    return z
# A1: [0/90]
fig,ax=new(2.5,1.45); ax.set_xlim(-1.2,3.4); ax.set_ylim(-0.5,2.4); ax.set_aspect('auto')
stk(ax,[0,90],[0.5,0.5],0,1.2,1.8)
for z,l in ((0,'$-$0.5'),(0.9,'0'),(1.8,'0.5')): tx(ax,1.35,z,'$z$ = '+l if l!='0' else '$z$ = 0',ha='left',va='center',color=GREY)
tx(ax,0.6,2.15,'[0/90], $t_p$ = 0.5 mm',ha='center',color=NAVY)
tx(ax,-0.1,0.45,'ply 1',ha='right',va='center',color=GREY); tx(ax,-0.1,1.35,'ply 2',ha='right',va='center',color=GREY)
tx(ax,2.4,0.9,'$E_1$ = 140 000\n$E_2$ = 10 000 MPa\n$G_{12}$ = 5000 MPa\n$\\nu_{12}$ = 0.3',ha='left',va='center',color=GREY,fontsize=7.5)
save(fig,'p_14A1.png')
# A2: [0/90/0]
fig,ax=new(2.08,1.28); ax.set_xlim(-1.4,3.6); ax.set_ylim(-0.3,2.4); ax.set_aspect('auto')
stk(ax,[0,90,0],[0.2,0.2,0.2],0,1.2,3.0)
tx(ax,1.35,0.3,'$t_p$ = 0.2 mm',ha='left',va='center',color=GREY)
ax.annotate('',xy=(-0.25,1.8),xytext=(-0.25,0),arrowprops=dict(arrowstyle='<->',color=GREY,lw=0.7)); tx(ax,-0.35,0.9,'0.6 mm',rotation=90,ha='right',va='center',color=GREY)
tx(ax,2.0,1.4,'one *SHELL GENERAL\nSECTION, USER,\nlayout of Listing 14.1',ha='left',va='center',color=NAVY,fontsize=7.5)
save(fig,'p_14A2.png')
# A3: tau-gamma
fig,ax=plt.subplots(figsize=(2.2,1.3),dpi=240)
t=np.linspace(0,70,100); g=(t/5000+2e-8*t**3)*1e3
ax.plot(g,t,color=BLUE,lw=1.4); ax.plot(t/5000*1e3,t,color=GREY,lw=0.8,ls='--')
ax.plot(12.5,50,'o',color=RED,ms=4); tx(ax,12.0,50,'$\\tau$ = 50 MPa',ha='right',va='bottom',color=RED)
tx(ax,20,6,'$\\beta$ = 2×10$^{-8}$ MPa$^{-3}$',ha='right',color=GREY,fontsize=7.5)
ax.set_xlabel('$\\gamma_{12}$ ($10^{-3}$)',fontsize=8.5); ax.set_ylabel('$\\tau_{12}$ (MPa)',fontsize=8.5); ax.tick_params(labelsize=7.8)
fig.subplots_adjust(left=0.2,bottom=0.2); save(fig,'p_14A3.png')
# B1: two reference planes
fig,ax=new(2.6,1.3); ax.set_xlim(-1.8,4.6); ax.set_ylim(-0.4,3.2); ax.set_aspect('auto')
stk(ax,[0,45,-45,90,90,-45,45,0],[0.125]*8,0,1.0,3.0)
arr(ax,(1.25,1.5),(1.25,2.8),c=BLUE,lw=1.0); tx(ax,1.35,2.5,'$z$ (mid-plane, $z$ = 0 at 1.5)',ha='left',color=BLUE,fontsize=7.5)
arr(ax,(-0.3,0),(-0.3,1.4),c=RED,lw=1.0); tx(ax,-0.4,0.9,"$z'$ (bottom)",ha='right',color=RED,fontsize=7.5)
ax.plot([-0.1,1.1],[1.5,1.5],color=GREY,lw=0.6,ls=':')
tx(ax,2.2,0.5,'$h$ = 1 mm,\n$t_p$ = 0.125 mm\nplies as in Example 14.5-1',ha='left',color=GREY,fontsize=7.5)
save(fig,'p_14B1.png')
# B2: stress cube
fig,ax=new(2.08,1.52); ax.set_xlim(-0.2,5.6); ax.set_ylim(-0.3,3.5); ax.set_aspect('auto')
ax.add_patch(Rectangle((0.5,0.3),1.8,1.8,fc=LB,ec=BLUE,lw=1.0))
ax.add_patch(Polygon([[0.5,2.1],[1.1,2.7],[2.9,2.7],[2.3,2.1]],fc='#CFE0F7',ec=BLUE,lw=1.0)); ax.add_patch(Polygon([[2.3,0.3],[2.9,0.9],[2.9,2.7],[2.3,2.1]],fc='#B9D0F0',ec=BLUE,lw=1.0))
arr(ax,(2.3,1.2),(3.2,1.2),c=RED,lw=1.1); tx(ax,3.25,1.2,'$S_{11}$',color=RED,va='center'); arr(ax,(1.4,2.1),(1.4,2.9),c=RED,lw=1.1); tx(ax,1.5,3.05,'$S_{22}$',color=RED)
tx(ax,3.9,1.8,'$S$ = (120, $-$45, 30,\n60, $-$25, 15) MPa',ha='left',color=NAVY,fontsize=7.5); tx(ax,3.9,0.9,'order: S11, S22, S33,\nS12, S13, S23',ha='left',color=GREY,fontsize=7.5)
save(fig,'p_14B2.png')
# C1: flowchart
fig,ax=new(3.4,1.5); ax.set_xlim(0,10); ax.set_ylim(0,4.4); ax.set_aspect('auto')
box(ax,0.1,1.6,2.6,1.2,'one path of\n20 increments',fc=LGREY,ec=GREY,fs=7.6)
box(ax,3.3,2.9,3.6,1.2,'UGENS, one point\n(STRAN, DSTRAN)',fc=LB,ec=BLUE,fs=7.5); box(ax,3.3,0.3,3.6,1.2,'VUGENS, block of 3\n(strainInc, curvInc)',fc=LB,ec=BLUE,fs=7.5)
box(ax,7.7,1.6,2.3,1.2,'compare\nFORCE',fc=PINK,ec=RED,fs=7.5)
arr(ax,(2.7,2.4),(3.3,3.4),c=BLUE,lw=1.0); arr(ax,(2.7,2.0),(3.3,1.0),c=BLUE,lw=1.0); arr(ax,(6.9,3.4),(7.7,2.6),c=RED,lw=1.0); arr(ax,(6.9,1.0),(7.7,1.8),c=RED,lw=1.0)
save(fig,'p_14C1.png')
# C2: S4R membrane shear
fig,ax=new(2.7,1.7); ax.set_xlim(-0.6,5.2); ax.set_ylim(-0.7,3.2); ax.set_aspect('auto')
ax.add_patch(Rectangle((0.3,0.2),2.2,2.2,fc=LB,ec=BLUE,lw=1.2))
ax.add_patch(Polygon([[0.3,0.2],[2.5,0.2],[2.72,2.4],[0.52,2.4]],fc='none',ec=RED,lw=1.0,ls='--'))
tx(ax,3.0,1.6,'S4R, 10 × 10 mm\n$\\gamma_{12}$ = 0.01\n(top edge $u_1$ = 0.1 mm,\nbottom fixed)',ha='left',va='center',color=NAVY,fontsize=7.5)
arr(ax,(1.4,2.55),(2.0,2.55),c=RED,lw=1.0)
for x in (0.3,1.0,1.7,2.4): ax.plot([x,x-0.3],[0.2,-0.1],color=NAVY,lw=0.7)
ax.plot([-0.1,2.8],[0.2,0.2],color=NAVY,lw=1.0)
save(fig,'p_14C2.png')
# D1: curling
fig,ax=new(3.4,1.6); ax.set_xlim(0,10); ax.set_ylim(0,4.6); ax.set_aspect('auto')
ax.add_patch(Rectangle((0.3,1.7),3.0,0.5,fc=COL[0],ec=NAVY,lw=0.8)); ax.add_patch(Rectangle((0.3,2.2),3.0,0.5,fc=COL[90],ec=NAVY,lw=0.8))
tx(ax,1.8,1.95,'0°',ha='center',va='center',color=NAVY); tx(ax,1.8,2.45,'90°',ha='center',va='center',color=NAVY)
arr(ax,(0.3,1.2),(3.3,1.2),c=RED,lw=1.0); arr(ax,(3.3,1.2),(0.3,1.2),c=RED,lw=1.0); tx(ax,1.8,0.7,'in-plane load $N_{11}$',ha='center',color=RED,fontsize=7.5)
th=np.linspace(0,0.6,40); R_=6; xs=5.0+R_*np.sin(th)*0+ (np.linspace(0,3,40)); ys=2.2-(xs-5.0)**2/(2*R_)*(-1)
ax.plot(xs,2.2+(xs-5.0)**2/(2*7),color=BLUE,lw=1.6); ax.plot(xs,2.2*np.ones_like(xs),color=GREY,lw=0.8,ls='--')
tx(ax,6.5,3.4,'curvature $\\kappa_{11}$: sign?',ha='center',color=BLUE,fontsize=7.8)
tx(ax,6.5,0.7,'compare with *SHELL SECTION,\nCOMPOSITE',ha='center',color=GREY,fontsize=7.5)
save(fig,'p_14D1.png'); print('ok')
