import sys; sys.path.insert(0,'/home/claude/vol2/lib'); from mkeq import mkeq
import os
out=os.path.join(os.path.dirname(__file__),'..')
E={
'e1421':[r'$\varepsilon_{\alpha\beta}(z)\;=\;\varepsilon^{0}_{\alpha\beta}+z\,\kappa_{\alpha\beta}$',
         r'$\mathbf{e}=\left(\varepsilon^{0}_{11},\ \varepsilon^{0}_{22},\ \gamma^{0}_{12},\ \kappa_{11},\ \kappa_{22},\ \kappa_{12}\right)^{T}$'],
'e1422':r'$N_{\alpha\beta}=\int_{-h/2}^{h/2}\sigma_{\alpha\beta}\,dz,\qquad M_{\alpha\beta}=\int_{-h/2}^{h/2}z\,\sigma_{\alpha\beta}\,dz$',
'e1423':[r'$\mathbf{N}=\mathbf{A}\,\varepsilon^{0}+\mathbf{B}\,\kappa$',r'$\mathbf{M}=\mathbf{B}\,\varepsilon^{0}+\mathbf{D}\,\kappa$'],
'e1424':[r'$\mathbf{A}=\sum_{k=1}^{n}\bar{\mathbf{Q}}_k\,(z_k-z_{k-1})$',
         r'$\mathbf{B}=\frac{1}{2}\sum_{k=1}^{n}\bar{\mathbf{Q}}_k\,(z_k^{2}-z_{k-1}^{2})$',
         r'$\mathbf{D}=\frac{1}{3}\sum_{k=1}^{n}\bar{\mathbf{Q}}_k\,(z_k^{3}-z_{k-1}^{3})$'],
'e1425':[r'$Q_{11}=\frac{E_1}{1-\nu_{12}\nu_{21}},\quad Q_{22}=\frac{E_2}{1-\nu_{12}\nu_{21}},\quad Q_{12}=\frac{\nu_{12}E_2}{1-\nu_{12}\nu_{21}},\quad Q_{66}=G_{12}$'],
'e1441':[r'$\gamma_{12}=\frac{\tau_{12}}{G_{12}}+\beta\,\tau_{12}^{3}$',
         r'$G_t=\frac{d\tau_{12}}{d\gamma_{12}}=\frac{1}{1/G_{12}+3\beta\tau_{12}^{2}}$'],
'e1442':r'$w=\frac{1}{2}\left(\sigma_1\varepsilon_1+\sigma_2\varepsilon_2\right)+\frac{\tau_{12}^{2}}{2G_{12}}+\frac{3}{4}\beta\,\tau_{12}^{4}$',
'e1443':r'$\mathbf{N}=\sum_{i}w_i\,\sigma_i,\qquad \mathbf{M}=\sum_{i}w_i\,z_i\,\sigma_i$',
'e1444':r'$F=\left(\frac{\sigma_1}{X}\right)^{2}-\frac{\sigma_1\sigma_2}{X^{2}}+\left(\frac{\sigma_2}{Y}\right)^{2}+\left(\frac{\tau_{12}}{S}\right)^{2}$',
'e1451':[r'$A_{11}=t\,U_1,\qquad A_{12}=t\,U_4,\qquad A_{66}=t\,U_5,\qquad \mathbf{B}=\mathbf{0}$',
         r'$B_{11}=\frac{t_p^{2}}{2}\,(Q_{22}-Q_{11})\quad ([0/90],\ \mathrm{plies\ of\ thickness}\ t_p)$'],
'e1452':r'$\left(\mathbf{C}_{\mathrm{fd}}\right)_{ij}=\frac{F_i(\mathbf{e}+h_j\mathbf{u}_j)-F_i(\mathbf{e}-h_j\mathbf{u}_j)}{2\,h_j}$',
'e1461':[r'$\mathbf{e}_{n+1}=\mathbf{e}_{n}+\Delta\mathbf{e},\qquad \gamma_{12}=2\,\varepsilon_{12},\qquad \kappa_{12}=2\,\kappa^{\mathrm{t}}_{12}$'],
'e1471':[r'$\phi(\mathbf{S})=q+\alpha\,I_1,\qquad q=\sqrt{\frac{3}{2}\,\mathbf{s}:\mathbf{s}},\qquad I_1=S_{11}+S_{22}+S_{33}$',
         r'$\frac{\partial\phi}{\partial S_{ii}}=\frac{3\,s_{ii}}{2q}+\alpha,\qquad \frac{\partial\phi}{\partial S_{12}}=\frac{3\,S_{12}}{q}$'],
}
mkeq(E,out)

# ---- equations with true matrices ----
import matplotlib.pyplot as plt
def matrix_eq(name,label,rows,cw=0.62,rh=0.30,fs=11.5,tail=None):
    fig=plt.figure(figsize=(6,1.2)); r=fig.canvas.get_renderer()
    t=fig.text(0,0.5,label,fontsize=fs,va='center'); bb=t.get_window_extent(r); x0=bb.width/fig.dpi+0.06
    nr=len(rows); nc=len(rows[0]); H=nr*rh
    # brackets
    xl=x0; xr=x0+nc*cw+0.1
    for x,d in ((xl,1),(xr,-1)):
        fig.add_artist(plt.Line2D([x/6,x/6],[0.5-H/2/1.2,0.5+H/2/1.2],color='k',lw=0.8,transform=fig.transFigure))
        for yy in (0.5-H/2/1.2,0.5+H/2/1.2): fig.add_artist(plt.Line2D([x/6,(x+d*0.06)/6],[yy,yy],color='k',lw=0.8,transform=fig.transFigure))
    for i,row in enumerate(rows):
        for j,e in enumerate(row):
            fig.text((x0+0.05+(j+0.5)*cw)/6,0.5+(nr/2-i-0.5)*rh/1.2,e,fontsize=fs,ha='center',va='center')
    if tail: fig.text((xr+0.1)/6,0.5,tail,fontsize=fs,va='center')
    fig.savefig(f'{name}.png',dpi=300,bbox_inches='tight',pad_inches=0.03,facecolor='white'); plt.close(fig)
matrix_eq('e1426',r'$\bar{\mathbf{Q}}=\mathbf{T}^{T}\mathbf{Q}\,\mathbf{T},\qquad \mathbf{T}=$',
  [[r'$c^2$',r'$s^2$',r'$cs$'],[r'$s^2$',r'$c^2$',r'$-cs$'],[r'$-2cs$',r'$2cs$',r'$c^2-s^2$']],cw=0.56,rh=0.27,tail=r'$,\quad c=\cos\theta,\ s=\sin\theta$')
matrix_eq('e1443b',r'$\mathbf{C}_t=\sum_i\,w_i\,$',
  [[r'$\bar{\mathbf{Q}}_{t,i}$',r'$z_i\bar{\mathbf{Q}}_{t,i}$'],[r'$z_i\bar{\mathbf{Q}}_{t,i}$',r'$z_i^2\bar{\mathbf{Q}}_{t,i}$']],cw=0.8,rh=0.30)
