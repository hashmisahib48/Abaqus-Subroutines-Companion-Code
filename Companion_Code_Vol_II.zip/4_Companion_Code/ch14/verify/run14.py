"""Chapter 14 verification: independent CLT in numpy/scipy, driver runs, results to ../out/results.json"""
import numpy as np, subprocess, json, os
from scipy.optimize import brentq
os.chdir(os.path.join(os.path.dirname(__file__),'..','code'))
E1,E2,G12,NU12,BETA,XS,YS,SS = 140000.,10000.,5000.,0.30,2.0e-8,1500.,40.,70.
TP=0.125
def props(angles,thick,beta=BETA):
    p=[E1,E2,G12,NU12,beta,XS,YS,SS,len(angles)]
    for a,t in zip(angles,thick): p+= [a,t]
    return p
LAYUPS={
 'QI':  ([0,45,-45,90,90,-45,45,0],[TP]*8),
 'CP':  ([0,90],[0.5,0.5]),
 'AP':  ([30,-30],[0.5,0.5]),
}
# ---------- independent CLT: Tsai-Pagano invariants, analytic z integrals ----------
def Qinv(beta_shear=None):
    nu21=NU12*E2/E1; d=1-NU12*nu21
    Q11,Q22,Q12,Q66=E1/d,E2/d,NU12*E2/d,G12
    return Q11,Q22,Q12,Q66
def abd_clt(angles,thick):
    Q11,Q22,Q12,Q66=Qinv()
    U1=(3*Q11+3*Q22+2*Q12+4*Q66)/8; U2=(Q11-Q22)/2; U3=(Q11+Q22-2*Q12-4*Q66)/8
    U4=(Q11+Q22+6*Q12-4*Q66)/8; U5=(Q11+Q22-2*Q12+4*Q66)/8
    h=sum(thick); z=-h/2; A=np.zeros((3,3));B=np.zeros((3,3));D=np.zeros((3,3))
    for a,t in zip(angles,thick):
        th=np.radians(a); c2,c4,s2,s4=np.cos(2*th),np.cos(4*th),np.sin(2*th),np.sin(4*th)
        Qb=np.array([[U1+U2*c2+U3*c4, U4-U3*c4, 0.5*U2*s2+U3*s4],
                     [U4-U3*c4, U1-U2*c2+U3*c4, 0.5*U2*s2-U3*s4],
                     [0.5*U2*s2+U3*s4, 0.5*U2*s2-U3*s4, U5-U3*c4]])
        z1=z+t; A+=Qb*(z1-z); B+=Qb*(z1**2-z**2)/2; D+=Qb*(z1**3-z**3)/3; z=z1
    return np.block([[A,B],[B,D]]),(U1,U2,U3,U4,U5)
# ---------- independent nonlinear section (rotation matrices, scipy root finding, 12 Gauss points) ----------
def ply_resp(th,e,beta):
    Q11,Q22,Q12,Q66=Qinv(); c,s=np.cos(np.radians(th)),np.sin(np.radians(th))
    R=np.array([[c*c,s*s,c*s],[s*s,c*c,-c*s],[-2*c*s,2*c*s,c*c-s*s]])
    e12=R@e; g=e12[2]
    f=lambda t:t/G12+beta*t**3-g
    tau=0.0 if g==0 else brentq(f,-abs(g)*G12*1.01-1,abs(g)*G12*1.01+1,xtol=1e-14,rtol=1e-15)
    s12=np.array([Q11*e12[0]+Q12*e12[1],Q12*e12[0]+Q22*e12[1],tau])
    w=0.5*(s12[0]*e12[0]+s12[1]*e12[1])+tau**2/(2*G12)+0.75*beta*tau**4
    return R.T@s12,w
def section(angles,thick,beta,eps):
    h=sum(thick); z=-h/2; x,wt=np.polynomial.legendre.leggauss(12); F=np.zeros(6); W=0.
    for a,t in zip(angles,thick):
        for xi,wi in zip(x,wt):
            zz=z+0.5*t*(1+xi); w_=0.5*t*wi; e=eps[:3]+zz*eps[3:]
            s,wd=ply_resp(a,e,beta); F[:3]+=w_*s; F[3:]+=w_*zz*s; W+=w_*wd
        z+=t
    return F,W
def run(name,exe,pr,path,extra=''):
    with open('ex14_case.in','w') as f:
        f.write(f"{len(pr)}\n"+" ".join(f"{v:.17g}" for v in pr)+f"\n{len(path)}\n")
        for r in path: f.write(" ".join(f"{v:.17g}" for v in r)+"\n")
    subprocess.run(['../out/'+exe],check=True,stdout=subprocess.DEVNULL)
R={}
if __name__=='__main__':
    # build
    inc='-I/home/claude/vol2/lib/aba'; fl=['-O1','-w','-ffixed-form','-ffixed-line-length-none','-std=legacy','-ffpe-summary=none',inc]
    st='/home/claude/vol2/lib/aba/stubs.f'
    for exe,src in [('drv1',['ex14_drv.f','ex14_ugens.f']),('drv2',['ex14_drv2.f','ex14_vugens.f','ex14_ugens.f']),('drv3',['ex14_drv3.f','ex14_dresp.f'])]:
        subprocess.run(['gfortran']+fl+src+[st,'-o','../out/'+exe],check=True)
    # ---- Test 1: ABD of the three laminates (beta = 0), via unit strains in the driver
    R['abd']={}
    for nm,(ang,th) in LAYUPS.items():
        pr=props(ang,th,0.0); M=np.zeros((6,6))
        run(nm,'drv1',pr,[[0]*6])
        L=open('ex14_out.txt').read().split('\n'); dd=[l for l in L if l.startswith('D ')]
        M=np.array([[float(x) for x in l.split()[2:]] for l in dd])
        ref,U=abd_clt(ang,th)
        R['abd'][nm]={'driver':M.tolist(),'ref':ref.tolist(),'maxrel':float(np.abs(M-ref).max()/np.abs(ref).max()),'U':U}
    # QI closed forms
    ref,U=abd_clt(*LAYUPS['QI']); t=1.0
    R['qi']={'A11':float(ref[0,0]),'tU1':t*U[0],'A12':float(ref[0,1]),'tU4':t*U[3],'A66':float(ref[2,2]),'tU5':t*U[4],'Bmax':float(np.abs(ref[:3,3:]).max()),'A16':float(ref[0,2])}
    # cross-ply closed form of B11 = h^2/2 (Q22-Q11) with h=0.5
    Q11,Q22,Q12,Q66=Qinv(); R['cp']={'B11':float(abd_clt(*LAYUPS['CP'])[0][0,3]),'B11cf':0.5*0.5**2*(Q22-Q11)}
    R['Q']=[Q11,Q22,Q12,Q66]
    # eigenvalues
    R['eig']={nm:float(np.linalg.eigvalsh(np.array(R['abd'][nm]['driver'])).min()) for nm in LAYUPS}
    # ---- Test 2: linear force = ABD*strain  (random-ish state), driver vs numpy
    # ---- Test 3: nonlinear path, QI, gamma12 membrane + twist (combined), 20 increments
    ang,th=LAYUPS['QI']; pr=props(ang,th)
    N=20; tot=np.array([0.0008,-0.0002,0.008,0.0016,0.0,0.0032]); path=[tot/N]*N
    run('nl','drv1',pr,path); L=open('ex14_out.txt').read().split('\n')
    S=[[float(x) for x in l.split()[2:]] for l in L if l.startswith('S ')]
    S=np.array(S); Fd=S[-1,:6]; SSEd=S[-1,6]; fi=S[-1,7:9]
    Fr,Wr=section(ang,th,BETA,tot)
    dd=np.array([[float(x) for x in l.split()[2:]] for l in L if l.startswith('D ')])
    HH=[l.split() for l in L if l.startswith('H ')]
    R['nl']={'F_drv':Fd.tolist(),'F_ref':Fr.tolist(),'sse_drv':SSEd,'sse_ref':Wr,'maxrel':float(np.abs(Fd-Fr).max()/np.abs(Fr).max()),
             'fd':[[float(h[2]),float(h[3])] for h in HH],'DD':dd.tolist(),'fi':fi.tolist()}
    # linear-limit comparison at the same strain: shows nonlinearity
    pr0=props(ang,th,0.0); ABD=abd_clt(ang,th)[0]; R['nl']['F_lin']=(ABD@tot).tolist()
    # work integral along path with N increments vs SSE
    work={}
    for Nw in (20,100,500):
        run('w','drv1',pr,[tot/Nw]*Nw); L2=open('ex14_out.txt').read().split('\n')
        S2=np.array([[float(x) for x in l.split()[2:]] for l in L2 if l.startswith('S ')])
        Fs=np.vstack([np.zeros(6),S2[:,:6]]); W=0.
        for k in range(Nw): W+=0.5*(Fs[k]+Fs[k+1])@(tot/Nw)
        work[Nw]=W
    R['work']=work
    # exact reference tangent by a complex-free high-accuracy central difference of the independent model
    eps=tot.copy(); Dref=np.zeros((6,6)); h=1e-6
    for j in range(6):
        d=np.zeros(6); d[j]=h*max(1e-2,abs(eps[j])); Dref[:,j]=(section(ang,th,BETA,eps+d)[0]-section(ang,th,BETA,eps-d)[0])/(2*d[j])
    R['nl']['DD_ref_maxrel']=float(np.abs(dd-Dref).max()/np.abs(dd).max())
    # secant/linear tangent mismatch (what a wrong linear tangent would give)
    R['nl']['DD_lin_maxrel']=float(np.abs(dd-ABD).max()/np.abs(dd).max())
    # response curve for the figure: gamma0 sweep
    gs=np.linspace(0,0.02,41); Fg=[];Fl=[]
    for g in gs:
        e=np.array([0,0,g,0,0,0]); Fg.append(section(ang,th,BETA,e)[0][2]); Fl.append(ABD[2,2]*g)
    R['curve']={'g':gs.tolist(),'N12':Fg,'N12lin':Fl}
    def fi_ref(eps):
        best=0;ip=0;z=-sum(th)/2
        for k,(a,t) in enumerate(zip(ang,th)):
            for xi in (-0.7745966692414834,0,0.7745966692414834):
                zz=z+0.5*t*(1+xi); e=eps[:3]+zz*eps[3:]; sg,w=ply_resp(a,e,BETA)
                c,sn=np.cos(np.radians(a)),np.sin(np.radians(a)); Rm=np.array([[c*c,sn*sn,c*sn],[sn*sn,c*c,-c*sn],[-2*c*sn,2*c*sn,c*c-sn*sn]])
                s12=np.linalg.solve(Rm.T,sg); fi=(s12[0]/XS)**2-s12[0]*s12[1]/XS**2+(s12[1]/YS)**2+(s12[2]/SS)**2
                if fi>best: best=fi;ip=k+1
            z+=t
        return best,ip
    R['nl']['fi_ref']=list(fi_ref(tot))
    # failure index states
    R['fi_path']=S[:,7:9].tolist()
    # ---- Test 4: VUGENS vs UGENS
    run('v','drv2',pr,path); L3=open('ex14_out2.txt').read().split('\n')
    R['vug']={'maxdiff':float([l for l in L3 if l.startswith('MAXDIFF')][0].split()[1])}
    FV=[[float(x) for x in l.split()[2:]] for l in L3 if l.startswith('V ')]
    FG=[[float(x) for x in l.split()[2:]] for l in L3 if l.startswith('F ')]
    R['vug']['F']=FG; R['vug']['FV']=FV
    # ---- Test 5: dresp, offsets
    subprocess.run(['../out/drv3'],check=True); L5=open('ex14_out3.txt').read().split('\n')
    R['dresp']={'val':float([l for l in L5 if l.startswith('VAL')][0].split()[1]),
      'ana':[float(x) for x in [l for l in L5 if l.startswith('ANA')][0].split()[1:]],
      'fd':[[float(l.split()[2]),float(l.split()[3])] for l in L5 if l.startswith('FD')],
      'cf':[float(x) for x in [l for l in L5 if l.startswith('CF')][0].split()[1:]]}
    R['off']=[l.split() for l in L5 if l.startswith('OFF')]
    S0=np.array([120,-45,30,60,-25,15.]); a=0.15
    p=S0[:3].mean(); sd=S0[:3]-p; q=np.sqrt(1.5*(sd@sd+2*(S0[3:]@S0[3:]))); R['dresp']['val_ref']=float(q+3*a*p)
    json.dump(R,open('../out/results.json','w'),indent=1)
    print(json.dumps({k:R[k] for k in ['qi','cp','eig','work']},indent=1))
    print({k:R['abd'][k]['maxrel'] for k in R['abd']})
    print({k:R['nl'][k] for k in ['maxrel','sse_drv','sse_ref','DD_ref_maxrel','DD_lin_maxrel','fi']})
    print(R['nl']['fd']); print(R['vug']['maxdiff']); print(R['dresp']); print(R['off'])
