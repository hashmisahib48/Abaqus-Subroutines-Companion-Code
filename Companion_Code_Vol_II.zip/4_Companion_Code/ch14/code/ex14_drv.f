!     ex14_drv.f   Driver for UGENS, VUGENS, UELEMDRESP and
!     UCOHESIVEOFFSET, written for Chapter 14 (not an Abaqus run).
!     Reads  ex14_case.in:  NPROPS, PROPS, NSTEP, then NSTEP rows of
!     the strain increment DSTRAN(1:6).  Writes ex14_out.txt:
!     per increment FORCE(6), SSE, STATEV(1:3); then, for the final
!     state, DDNDDE (6 x 6) and a central-difference Jacobian
!     for several steps H; then the same path through VUGENS.
      PROGRAM EX14DRV
      INCLUDE 'ABA_PARAM.INC'
      PARAMETER (MAXP = 64, NB = 3)
      DIMENSION PROPS(MAXP), DS(6, 2000), STRAN(6), DSTRAN(6)
      DIMENSION DDNDDE(6,6), FORCE(6), STATEV(3), TSS(2), TIME(2)
      DIMENSION PREDEF(1), DPRED(1), COORDS(3), DFGRD(3,3), CURV(2,2)
      DIMENSION BASIS(3,3), FD(6,6), F1(6), F2(6), DJ(6,6), DUM(6,6)
      DIMENSION STV2(3)
      CHARACTER*80 CENAME
      INTEGER JPR(1)
      OPEN(10, FILE='ex14_case.in')
      OPEN(11, FILE='ex14_out.txt')
      READ(10,*) NPROPS
      READ(10,*) (PROPS(I), I = 1, NPROPS)
      READ(10,*) NSTEP
      DO K = 1, NSTEP
         READ(10,*) (DS(I,K), I = 1, 6)
      ENDDO
      STRAN = 0.0D0
      STATEV = 0.0D0
      TSS = 0.0D0
      TIME = 0.0D0
      CENAME = 'LAM'
      DO K = 1, NSTEP
         DSTRAN = DS(:,K)
         CALL UGENS(DDNDDE,FORCE,STATEV,SSE,SPD,PNEWDT,STRAN,DSTRAN,
     1    TSS,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CENAME,2,1,6,3,PROPS,
     2    JPR,NPROPS,0,COORDS,CELENT,THICK,DFGRD,CURV,BASIS,1,1,1,K,
     3    0,0)
         STRAN = STRAN + DSTRAN
         WRITE(11,'(A,I5,10ES24.15)') 'S', K, FORCE, SSE,
     1      STATEV(1), STATEV(2)
      ENDDO
!     tangent at the final state: routine value and central differences
      DSTRAN = 0.0D0
      STV2 = 0.0D0
      CALL UGENS(DDNDDE,FORCE,STV2,SSE,SPD,PNEWDT,STRAN,DSTRAN,
     1    TSS,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CENAME,2,1,6,3,PROPS,
     2    JPR,NPROPS,0,COORDS,CELENT,THICK,DFGRD,CURV,BASIS,1,1,1,1,
     3    0,0)
      DO I = 1, 6
         WRITE(11,'(A,I2,6ES24.15)') 'D', I, (DDNDDE(I,J), J = 1, 6)
      ENDDO
      DO IH = 1, 9
         H = 10.0D0**(-IH)
         DO J = 1, 6
            DSTRAN = 0.0D0
            DSTRAN(J) = H*MAX(1.0D-2, ABS(STRAN(J)))
            HH = DSTRAN(J)
            STV2 = 0.0D0
            CALL UGENS(DUM,F1,STV2,SSE,SPD,PNEWDT,STRAN,DSTRAN,
     1       TSS,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CENAME,2,1,6,3,
     2       PROPS,JPR,NPROPS,0,COORDS,CELENT,THICK,DFGRD,CURV,BASIS,
     3       1,1,1,1,0,0)
            DSTRAN(J) = -HH
            STV2 = 0.0D0
            CALL UGENS(DUM,F2,STV2,SSE,SPD,PNEWDT,STRAN,DSTRAN,
     1       TSS,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CENAME,2,1,6,3,
     2       PROPS,JPR,NPROPS,0,COORDS,CELENT,THICK,DFGRD,CURV,BASIS,
     3       1,1,1,1,0,0)
            DO I = 1, 6
               FD(I,J) = (F1(I) - F2(I))/(2.0D0*HH)
            ENDDO
         ENDDO
         DMAX = 0.0D0
         DREF = 0.0D0
         DO I = 1, 6
            DO J = 1, 6
               DMAX = MAX(DMAX, ABS(FD(I,J) - DDNDDE(I,J)))
               DREF = MAX(DREF, ABS(DDNDDE(I,J)))
            ENDDO
         ENDDO
         WRITE(11,'(A,I3,ES12.3,ES24.15)') 'H', IH, H, DMAX/DREF
      ENDDO
      CLOSE(11)
      END
