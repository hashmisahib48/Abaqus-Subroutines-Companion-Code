!     ex14_ugens.f   Laminated shell section by classical lamination
!     theory with nonlinear in-plane shear (Hahn-Tsai). N, mm, MPa.
!     Section strains and forces are ordered (11, 22, 12) membrane,
!     then (11, 22, 12) bending; shear strain and twist are engineering.
!
!     PROPS(1) E1   (MPa)      PROPS(2) E2   (MPa)
!     PROPS(3) G12  (MPa)      PROPS(4) NU12 (-)
!     PROPS(5) BETA (MPa**-3)  gamma12 = tau/G12 + BETA*tau**3
!     PROPS(6) X, PROPS(7) Y, PROPS(8) S   (MPa) strengths
!     PROPS(9) NPLY (number of plies, stored as a real number)
!     PROPS(10+2*(K-1)) angle of ply K (degrees from local axis 1)
!     PROPS(11+2*(K-1)) thickness of ply K (mm), K = 1 at the bottom
!
      SUBROUTINE K14_LAM(PROPS, TH, EXY, SXY, QB, WD, FI)
!     Response of one ply to the strain EXY = (e11, e22, g12) given in
!     the section axes: stress SXY, tangent QB, energy density WD and
!     the Tsai-Hill failure index FI.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(*), EXY(3), SXY(3), QB(3,3)
      DIMENSION T(3,3), E12(3), S12(3), QT(3,3), QTT(3,3)
      PARAMETER (PI = 3.14159265358979D0)
      E1 = PROPS(1)
      E2 = PROPS(2)
      G12 = PROPS(3)
      XNU12 = PROPS(4)
      BETA = PROPS(5)
      XNU21 = XNU12*E2/E1
      DEN = 1.0D0 - XNU12*XNU21
      Q11 = E1/DEN
      Q22 = E2/DEN
      Q12 = XNU12*E2/DEN
      C = COS(TH*PI/180.0D0)
      S = SIN(TH*PI/180.0D0)
!     strain transformation, engineering shear: e(12) = T e(xy)
      T(1,1) = C*C
      T(1,2) = S*S
      T(1,3) = C*S
      T(2,1) = S*S
      T(2,2) = C*C
      T(2,3) = -C*S
      T(3,1) = -2.0D0*C*S
      T(3,2) = 2.0D0*C*S
      T(3,3) = C*C - S*S
      DO I = 1, 3
         E12(I) = T(I,1)*EXY(1) + T(I,2)*EXY(2) + T(I,3)*EXY(3)
      ENDDO
!     shear stress from gamma = tau/G + BETA*tau**3 by Newton's method
      TAU = G12*E12(3)
      DO IT = 1, 50
         RES = TAU/G12 + BETA*TAU**3 - E12(3)
         IF (ABS(RES) .LE. 1.0D-14*MAX(ABS(E12(3)), 1.0D-12)) EXIT
         TAU = TAU - RES/(1.0D0/G12 + 3.0D0*BETA*TAU*TAU)
      ENDDO
      GT = 1.0D0/(1.0D0/G12 + 3.0D0*BETA*TAU*TAU)
      S12(1) = Q11*E12(1) + Q12*E12(2)
      S12(2) = Q12*E12(1) + Q22*E12(2)
      S12(3) = TAU
      QT = 0.0D0
      QT(1,1) = Q11
      QT(1,2) = Q12
      QT(2,1) = Q12
      QT(2,2) = Q22
      QT(3,3) = GT
!     stress in the section axes: s(xy) = T**T s(12); QB = T**T QT T
      DO I = 1, 3
         SXY(I) = T(1,I)*S12(1) + T(2,I)*S12(2) + T(3,I)*S12(3)
      ENDDO
      DO I = 1, 3
         DO J = 1, 3
            QTT(I,J) = QT(I,1)*T(1,J) + QT(I,2)*T(2,J)
     1               + QT(I,3)*T(3,J)
         ENDDO
      ENDDO
      DO I = 1, 3
         DO J = 1, 3
            QB(I,J) = T(1,I)*QTT(1,J) + T(2,I)*QTT(2,J)
     1              + T(3,I)*QTT(3,J)
         ENDDO
      ENDDO
      WD = 0.5D0*(S12(1)*E12(1) + S12(2)*E12(2))
     1   + 0.5D0*TAU*TAU/G12 + 0.75D0*BETA*TAU**4
      FI = (S12(1)/PROPS(6))**2 - S12(1)*S12(2)/PROPS(6)**2
     1   + (S12(2)/PROPS(7))**2 + (TAU/PROPS(8))**2
      RETURN
      END
!
      SUBROUTINE K14_SEC(PROPS, NPROPS, EPS, CUR, FN, FM, DD, W,
     1                   FIMAX, IPMAX)
!     Section integration: forces FN, moments FM, tangent DD(6,6),
!     energy per unit area W and the largest ply failure index.
!     Three Gauss points per ply integrate the product of a quadratic
!     in z and the (possibly nonlinear) ply response.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PROPS(NPROPS), EPS(3), CUR(3), FN(3), FM(3), DD(6,6)
      DIMENSION GP(3), GW(3), EXY(3), SXY(3), QB(3,3)
      DATA GP /-0.774596669241483D0, 0.0D0, 0.774596669241483D0/
      DATA GW /0.555555555555556D0, 0.888888888888889D0,
     1         0.555555555555556D0/
      NPLY = NINT(PROPS(9))
      HTOT = 0.0D0
      DO K = 1, NPLY
         HTOT = HTOT + PROPS(11 + 2*(K-1))
      ENDDO
      FN = 0.0D0
      FM = 0.0D0
      DD = 0.0D0
      W = 0.0D0
      FIMAX = 0.0D0
      IPMAX = 1
      ZB = -0.5D0*HTOT
      DO K = 1, NPLY
         TH = PROPS(10 + 2*(K-1))
         TK = PROPS(11 + 2*(K-1))
         DO IG = 1, 3
            Z = ZB + 0.5D0*TK*(1.0D0 + GP(IG))
            WT = 0.5D0*TK*GW(IG)
            DO I = 1, 3
               EXY(I) = EPS(I) + Z*CUR(I)
            ENDDO
            CALL K14_LAM(PROPS, TH, EXY, SXY, QB, WD, FI)
            DO I = 1, 3
               FN(I) = FN(I) + WT*SXY(I)
               FM(I) = FM(I) + WT*Z*SXY(I)
               DO J = 1, 3
                  DD(I,J)     = DD(I,J)     + WT*QB(I,J)
                  DD(I,J+3)   = DD(I,J+3)   + WT*Z*QB(I,J)
                  DD(I+3,J)   = DD(I+3,J)   + WT*Z*QB(I,J)
                  DD(I+3,J+3) = DD(I+3,J+3) + WT*Z*Z*QB(I,J)
               ENDDO
            ENDDO
            W = W + WT*WD
            IF (FI .GT. FIMAX) THEN
               FIMAX = FI
               IPMAX = K
            ENDIF
         ENDDO
         ZB = ZB + TK
      ENDDO
      RETURN
      END
!
      SUBROUTINE UGENS(DDNDDE,FORCE,STATEV,SSE,SPD,PNEWDT,STRAN,
     1 DSTRAN,TSS,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CENAME,NDI,NSHR,
     2 NSECV,NSTATV,PROPS,JPROPS,NPROPS,NJPROP,COORDS,CELENT,THICK,
     3 DFGRD,CURV,BASIS,NOEL,NPT,KSTEP,KINC,NIT,LINPER)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CENAME
      DIMENSION DDNDDE(NSECV,NSECV), FORCE(NSECV), STATEV(NSTATV),
     1 STRAN(NSECV), DSTRAN(NSECV), TSS(2), TIME(2), PREDEF(*),
     2 DPRED(*), PROPS(NPROPS), JPROPS(*), COORDS(3), DFGRD(3,3),
     3 CURV(2,2), BASIS(3,3)
      DIMENSION ET(6), DD(6,6), FN(3), FM(3)
!
      IF (NSECV .NE. 6 .OR. NSTATV .LT. 3) THEN
         WRITE(7,*) 'UGENS: needs NSECV = 6 and VARIABLES >= 3'
         CALL XIT
      ENDIF
!     total section strain at the end of the increment
      DO I = 1, 6
         ET(I) = STRAN(I) + DSTRAN(I)
      ENDDO
      CALL K14_SEC(PROPS, NPROPS, ET(1), ET(4), FN, FM, DD, W,
     1             FIMAX, IPMAX)
      DO I = 1, 3
         FORCE(I) = FN(I)
         FORCE(I+3) = FM(I)
      ENDDO
      DO I = 1, 6
         DO J = 1, 6
            DDNDDE(I,J) = DD(I,J)
         ENDDO
      ENDDO
      SSE = W
      SPD = 0.0D0
      STATEV(1) = FIMAX
      STATEV(2) = MAX(STATEV(2), FIMAX)
      STATEV(3) = DBLE(IPMAX)
      RETURN
      END
