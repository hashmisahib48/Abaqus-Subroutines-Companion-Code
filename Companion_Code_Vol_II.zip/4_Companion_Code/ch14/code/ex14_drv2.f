!     ex14_drv2.f   VUGENS for a block of three points against UGENS;
!     UELEMDRESP against central differences; UCOHESIVEOFFSET history.
!     Reads ex14_case.in (as ex14_drv.f; the increments are applied
!     to point 1, point 2 gets 0.5 times and point 3 gets -1 times).
      PROGRAM EX14DRV2
      INCLUDE 'VABA_PARAM.INC'
      PARAMETER (MAXP = 64, NB = 3)
      DIMENSION PROPS(MAXP), DS(6, 2000), STRAN(6,NB), DSTRAN(6)
      DIMENSION FORCEG(6), STATEG(3), DDG(6,6), TSS(2), TIME(2)
      DIMENSION PREDEF(1), DPRED(1), COORDS(3), DFGRD(3,3), CURV(2,2)
      DIMENSION BASIS(3,3), FAC(NB), DUM(6,6)
      DIMENSION SI(NB,3), CI(NB,3), SO(NB,9), SN(NB,9), FO(NB,3),
     1 XO(NB,3), FNW(NB,3), XNW(NB,3), DDV(NB,21), DEN(NB), TH(NB)
      DIMENSION DEO(NB), DEN2(NB), DEI(NB), DEI2(NB), JEL(NB)
      DIMENSION CM(NB,3), TOLD(NB), TNEW(NB), FLO(NB,1), FLN(NB,1)
      DIMENSION DEFO(NB,5), DEFN(NB,5), DIRE(NB,3,3), CVN(NB,3)
      DIMENSION GAM(NB,2), JPR(1)
      CHARACTER*80 CENAME
      CHARACTER*80 CSET
      DATA FAC /1.0D0, 0.5D0, -1.0D0/
      OPEN(10, FILE='ex14_case.in')
      OPEN(11, FILE='ex14_out2.txt')
      READ(10,*) NPROPS
      READ(10,*) (PROPS(I), I = 1, NPROPS)
      READ(10,*) NSTEP
      DO K = 1, NSTEP
         READ(10,*) (DS(I,K), I = 1, 6)
      ENDDO
      STRAN = 0.0D0
      SO = 0.0D0
      CENAME = 'LAM'
      CSET = 'LAM'
      DO IB = 1, NB
         DEN(IB) = 1.6D-9
         TH(IB) = 1.0D0
      ENDDO
      DEO = 0.0D0
      DEFO = 0.0D0
      STATEG = 0.0D0
      DIFMAX = 0.0D0
      DO K = 1, NSTEP
!        VUGENS: tensor shear = engineering/2, shear position 4
         DO IB = 1, NB
            SI(IB,1) = FAC(IB)*DS(1,K)
            SI(IB,2) = FAC(IB)*DS(2,K)
            SI(IB,3) = 0.0D0
            CI(IB,1) = FAC(IB)*DS(4,K)
            CI(IB,2) = FAC(IB)*DS(5,K)
            CI(IB,3) = 0.5D0*FAC(IB)*DS(6,K)
         ENDDO
         CALL K14_CALLV(NB, SI, CI, DS(3,K), FAC, SO, SN, FNW, XNW,
     1        DDV, DEN, TH, PROPS, NPROPS, DEO, DEN2)
         DO IB = 1, NB
            DO L = 1, 9
               SO(IB,L) = SN(IB,L)
            ENDDO
            DEO(IB) = DEN2(IB)
!           UGENS for the same point
            DSTRAN = FAC(IB)*DS(:,K)
            STATEG = 0.0D0
            CALL UGENS(DDG,FORCEG,STATEG,SSE,SPD,PNEWDT,STRAN(1,IB),
     1       DSTRAN,TSS,TIME,DTIME,TEMP,DTEMP,PREDEF,DPRED,CENAME,2,1,
     2       6,3,PROPS,JPR,NPROPS,0,COORDS,CELENT,THICK,DFGRD,CURV,
     3       BASIS,1,1,1,K,0,0)
            STRAN(:,IB) = STRAN(:,IB) + DSTRAN
            DO I = 1, 3
               DIFMAX = MAX(DIFMAX, ABS(FNW(IB,I) - FORCEG(I)),
     1                      ABS(XNW(IB,I) - FORCEG(I+3)))
            ENDDO
            DIFMAX = MAX(DIFMAX, ABS(DEN2(IB)*DEN(IB)*TH(IB) - SSE))
            L = 0
            DO J = 1, 6
               DO I = 1, J
                  L = L + 1
                  DIFMAX = MAX(DIFMAX, ABS(DDV(IB,L) - DDG(I,J)))
               ENDDO
            ENDDO
            IF (K .EQ. NSTEP) THEN
               WRITE(11,'(A,I2,6ES24.15)') 'F', IB, FORCEG
               WRITE(11,'(A,I2,6ES24.15)') 'V', IB, (FNW(IB,I),I=1,3),
     1              (XNW(IB,I), I = 1, 3)
               WRITE(11,'(A,I2,ES24.15)') 'E', IB, SSE
               WRITE(11,'(A,I2,ES24.15)') 'W', IB, DEN2(IB)*DEN(IB)
     1              *TH(IB)
            ENDIF
         ENDDO
      ENDDO
      WRITE(11,'(A,ES24.15)') 'MAXDIFF', DIFMAX
      CLOSE(11)
      END
!
      SUBROUTINE K14_CALLV(NB, SI, CI, DG, FAC, SO, SN, FNW, XNW,
     1     DDV, DEN, TH, PROPS, NPROPS, DEO, DEN2)
!     one VUGENS call for a block of NB points
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION SI(NB,3), CI(NB,3), SO(NB,9), SN(NB,9), FNW(NB,3),
     1 XNW(NB,3), DDV(NB,21), DEN(NB), TH(NB), PROPS(NPROPS),
     2 DEO(NB), DEN2(NB), FAC(NB)
      DIMENSION JEL(3), CM(3,3), T0(3), T1(3), FLD(3,1), DEFG(3,5),
     1 DIRE(3,3,3), CVN(3,3), GAM(3,2), SIX(3,4), JPR(1), FO(3,3),
     2 XO(3,3), DEI(3)
      CHARACTER*80 CSET
      CSET = 'LAM'
      DO IB = 1, NB
         JEL(IB) = IB
         T0(IB) = 20.0D0
         T1(IB) = 20.0D0
         DEI(IB) = 0.0D0
         SIX(IB,1) = SI(IB,1)
         SIX(IB,2) = SI(IB,2)
         SIX(IB,3) = 0.0D0
         SIX(IB,4) = 0.5D0*FAC(IB)*DG
         FO(IB,1) = 0.0D0
         XO(IB,1) = 0.0D0
      ENDDO
      CALL VUGENS(NB, 2, 1, 9, 0, JEL, 1, 1, 0.0D0, 0.0D0, 1.0D0,
     1 CSET, CM, SIX, CI, T0, FLD, DEFG, DIRE, FO, XO, SO, DEO,
     2 DEI, PROPS, NPROPS, JPR, 0, DEN, TH, T1, FLD, DEFG, CVN, GAM,
     3 DDV, FNW, XNW, SN, DEN2, DEI)
      RETURN
      END
