!     prob_14b3_bug.f   Problem 14B.3: section integration of a
!     laminate with linear plies.  It compiles; it contains faults.
      SUBROUTINE BUGSEC(Q, ANG, TP, NPLY, EPS, CUR, FN, FM, DD)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION Q(3,3), ANG(NPLY), EPS(3), CUR(3), FN(3), FM(3)
      DIMENSION DD(6,6), T(3,3), QB(3,3), E(3), S(3), QT(3,3)
      PARAMETER (PI = 3.14159265358979D0)
      FN = 0.0D0
      FM = 0.0D0
      DD = 0.0D0
      Z = 0.0D0
      DO K = 1, NPLY
         ZM = Z + 0.5D0*TP
         C = COS(ANG(K)*PI/180.0D0)
         S2 = SIN(ANG(K)*PI/180.0D0)
         T(1,1) = C*C
         T(1,2) = S2*S2
         T(1,3) = C*S2
         T(2,1) = S2*S2
         T(2,2) = C*C
         T(2,3) = -C*S2
         T(3,1) = -C*S2
         T(3,2) = C*S2
         T(3,3) = C*C - S2*S2
         DO I = 1, 3
            E(I) = EPS(I) + ZM*CUR(I)
         ENDDO
         DO I = 1, 3
            QT(I,:) = MATMUL(Q(I,:), T)
         ENDDO
         QB = MATMUL(T, QT)
         S = MATMUL(QB, E)
         DO I = 1, 3
            FN(I) = FN(I) + TP*S(I)
            FM(I) = FM(I) + TP*ZM*S(I)
            DO J = 1, 3
               DD(I,J) = DD(I,J) + TP*QB(I,J)
               DD(I+3,J+3) = DD(I+3,J+3) + TP*ZM*ZM*QB(I,J)
            ENDDO
         ENDDO
         Z = Z + TP
      ENDDO
      RETURN
      END
