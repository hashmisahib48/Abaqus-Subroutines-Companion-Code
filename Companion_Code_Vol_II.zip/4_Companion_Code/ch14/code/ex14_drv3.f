!     ex14_drv3.f   UELEMDRESP against central differences and
!     closed forms; UCOHESIVEOFFSET for a damage history.
!     Writes ex14_out3.txt.
      PROGRAM EX14DRV3
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(6), S1(6), DV(6), IX(1,2), FLD(1), STV(1), DIR(3,3)
      DIMENSION TT(3,3), TIME(2), CRD(3), IAR(1), RAR(1), CAR(1)
      DIMENSION DEL(2), STO(2), STN(2), DDS(2,2), SV(1), PD(1), DP2(1)
      DIMENSION JM(1), JT(1)
      CHARACTER*80 DID, OID(1), CMN, ORN, CAR1(1)
      OPEN(11, FILE='ex14_out3.txt')
      S = (/ 120.0D0, -45.0D0, 30.0D0, 60.0D0, -25.0D0, 15.0D0 /)
      IX(1,1) = 1
      IX(1,2) = 6
      DID = 'DPSTRESS'
      OID(1) = 'S'
      CMN = ' '
      ORN = ' '
      DIR = 0.0D0
      TT = 0.0D0
!     value, analytical derivatives and central differences
      CALL UELEMDRESP(3, 3, 6, 1, 1, IX, S, DID, OID, VAL, DV, 20.0D0,
     1 FLD, STV, DIR, TT, 1.0D0, TIME, CRD, CMN, ORN, 0, 1, 1, 1, 1, 1,
     2 1, 1, IAR, 1, RAR, 1, CAR1, 1)
      WRITE(11,'(A,ES24.15)') 'VAL', VAL
      CALL UELEMDRESP(3, 3, 6, 2, 1, IX, S, DID, OID, VAL, DV, 20.0D0,
     1 FLD, STV, DIR, TT, 1.0D0, TIME, CRD, CMN, ORN, 0, 1, 1, 1, 1, 1,
     2 1, 1, IAR, 1, RAR, 1, CAR1, 1)
      WRITE(11,'(A,6ES24.15)') 'ANA', DV
      EMAX = 0.0D0
      DO IH = 1, 8
         H = 10.0D0**(-IH)
         EM = 0.0D0
         DO I = 1, 6
            S1 = S
            S1(I) = S(I) + H*100.0D0
            CALL UELEMDRESP(3, 3, 6, 1, 1, IX, S1, DID, OID, VP, DV,
     1       20.0D0, FLD, STV, DIR, TT, 1.0D0, TIME, CRD, CMN, ORN, 0,
     2       1, 1, 1, 1, 1, 1, 1, IAR, 1, RAR, 1, CAR1, 1)
            S1(I) = S(I) - H*100.0D0
            CALL UELEMDRESP(3, 3, 6, 1, 1, IX, S1, DID, OID, VM, DV,
     1       20.0D0, FLD, STV, DIR, TT, 1.0D0, TIME, CRD, CMN, ORN, 0,
     2       1, 1, 1, 1, 1, 1, 1, IAR, 1, RAR, 1, CAR1, 1)
            CALL UELEMDRESP(3, 3, 6, 2, 1, IX, S, DID, OID, VX, DV,
     1       20.0D0, FLD, STV, DIR, TT, 1.0D0, TIME, CRD, CMN, ORN, 0,
     2       1, 1, 1, 1, 1, 1, 1, IAR, 1, RAR, 1, CAR1, 1)
            EM = MAX(EM, ABS((VP-VM)/(200.0D0*H) - DV(I)))
         ENDDO
         WRITE(11,'(A,I2,ES12.3,ES24.15)') 'FD', IH, H, EM
      ENDDO
!     closed forms: uniaxial tension, compression, hydrostatic
      S1 = 0.0D0
      S1(1) = 100.0D0
      CALL UELEMDRESP(3, 3, 6, 1, 1, IX, S1, DID, OID, V1, DV, 20.0D0,
     1 FLD, STV, DIR, TT, 1.0D0, TIME, CRD, CMN, ORN, 0, 1, 1, 1, 1, 1,
     2 1, 1, IAR, 1, RAR, 1, CAR1, 1)
      S1(1) = -100.0D0
      CALL UELEMDRESP(3, 3, 6, 1, 1, IX, S1, DID, OID, V2, DV, 20.0D0,
     1 FLD, STV, DIR, TT, 1.0D0, TIME, CRD, CMN, ORN, 0, 1, 1, 1, 1, 1,
     2 1, 1, IAR, 1, RAR, 1, CAR1, 1)
      S1 = 0.0D0
      S1(1) = 100.0D0
      S1(2) = 100.0D0
      S1(3) = 100.0D0
      CALL UELEMDRESP(3, 3, 6, 1, 1, IX, S1, DID, OID, V3, DV, 20.0D0,
     1 FLD, STV, DIR, TT, 1.0D0, TIME, CRD, CMN, ORN, 0, 1, 1, 1, 1, 1,
     2 1, 1, IAR, 1, RAR, 1, CAR1, 1)
      WRITE(11,'(A,3ES24.15)') 'CF', V1, V2, V3
!     UCOHESIVEOFFSET: damage history in steps 1, 2
      OLD = 0.0D0
      DO IT = 1, 8
         KST = 1
         SDG = 0.2D0*IT
         IF (IT .GE. 6) KST = 2
         IF (IT .EQ. 5) SDG = 1.0D0
         IF (IT .EQ. 6) SDG = 0.5D0
         IF (IT .EQ. 7) SDG = 1.0D0
         IF (IT .EQ. 8) SDG = 0.99998D0
         DEL = 0.0D0
         CALL UCOHESIVEOFFSET(OLD, ONEW, DEL, 0.0D0, 1, 1, CRD, KST, 1,
     1    0.0D0, 1.0D0, 20.0D0, 0.0D0, PD, DP2, 0, JM, JT, 1, 1, SDG,
     2    0.0D0, 1.0D0, STO, STN, DDS, 2, 2, 0, 0.0D0, 0.0D0, JF, SV,
     3    1, 1, IAR, 1, RAR, 1, CAR1)
         WRITE(11,'(A,I2,I3,F10.5,F10.5,I3)') 'OFF', KST, IT, SDG, ONEW
     1    , JF
         OLD = ONEW
      ENDDO
      CLOSE(11)
      END
