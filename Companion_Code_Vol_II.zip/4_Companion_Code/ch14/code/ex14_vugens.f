!     ex14_vugens.f   The laminate section for Abaqus/Explicit.
!     VUGENS receives only increments; the total section strain is
!     therefore carried in the state variables:
!     STATEV(1:3) total membrane strain (11, 22, engineering 12)
!     STATEV(4:6) total curvature (11, 22, engineering twist)
!     STATEV(7)   largest failure index now, STATEV(8) its maximum,
!     STATEV(9)   number of the ply with the largest index.
!     Needs K14_SEC of ex14_ugens.f.
!
      SUBROUTINE K14_PACK(DD, DDP)
!     Upper triangle of the symmetric 6 x 6 matrix, by columns:
!     (1,1) (1,2) (2,2) (1,3) (2,3) (3,3) ... 21 numbers.
!     The order of the packed storage must be checked against the
!     'Stored as' table of the VUGENS page (UNVERIFIED here).
      INCLUDE 'VABA_PARAM.INC'
      DIMENSION DD(6,6), DDP(21)
      L = 0
      DO J = 1, 6
         DO I = 1, J
            L = L + 1
            DDP(L) = 0.5D0*(DD(I,J) + DD(J,I))
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE VUGENS(
! Read only -
     * NBLOCK, NDIR, NSHR, NSTATEV, NFIELDV,
     * JELEM, KINTPT, KINCR,
     * STEPTIME, TOTALTIME, DT,
     * CELSETNAME, COORDMP,
     * STRAININC, CURVINC,
     * TEMPOLD, FIELDOLD,
     * DEFGRADOLD, DIRECT,
     * FORCEOLD, XMOMOLD, STATEOLD,
     * ENERINTERNOLD, ENERINELASOLD,
     * PROPS, NPROPS, JPROPS, NJPROPS,
     * DENSITY, THICK,
     * TEMPNEW, FIELDNEW,
     * DEFGRADNEW, CURVNEW, GAMMA,
! Write only -
     * DDNDDE,
     * FORCENEW, XMOMNEW, STATENEW,
     * ENERINTERNNEW, ENERINELASNEW )
!
      INCLUDE 'VABA_PARAM.INC'
!
      CHARACTER*80 CELSETNAME
      DIMENSION JELEM(NBLOCK), JPROPS(*),
     * FORCENEW(NBLOCK,NDIR+NSHR), FORCEOLD(NBLOCK,NDIR+NSHR),
     1 XMOMNEW(NBLOCK,NDIR+NSHR), XMOMOLD(NBLOCK,NDIR+NSHR),
     2 STATEOLD(NBLOCK,NSTATEV), STATENEW(NBLOCK,NSTATEV),
     3 COORDMP(NBLOCK,3), STRAININC(NBLOCK,NDIR+1+NSHR),
     4 CURVINC(NBLOCK,NDIR+NSHR), DDNDDE(NBLOCK,*),
     5 DEFGRADNEW(NBLOCK,NDIR+1+NSHR+NSHR),
     6 DEFGRADOLD(NBLOCK,NDIR+1+NSHR+NSHR), DIRECT(NBLOCK,3,3),
     7 CURVNEW(NBLOCK,NDIR+NSHR), GAMMA(NBLOCK,2), TEMPNEW(NBLOCK),
     8 TEMPOLD(NBLOCK), FIELDNEW(NBLOCK,NFIELDV),
     9 FIELDOLD(NBLOCK,NFIELDV), PROPS(NPROPS), DENSITY(NBLOCK),
     * THICK(NBLOCK), ENERINTERNNEW(NBLOCK), ENERINTERNOLD(NBLOCK),
     * ENERINELASOLD(NBLOCK), ENERINELASNEW(NBLOCK)
      DIMENSION EPS(3), CUR(3), FN(3), FM(3), DD(6,6), DDP(21)
!     position of the (tensor) shear component in STRAININC
      PARAMETER (IS = 4)
!
      IF (NDIR .NE. 2 .OR. NSHR .NE. 1 .OR. NSTATEV .LT. 9) THEN
         WRITE(*,*) 'VUGENS: needs NDIR=2, NSHR=1, VARIABLES >= 9'
         CALL XIT
      ENDIF
      DO K = 1, NBLOCK
!        total strain: old total (state) + increment; shear and twist
!        arrive as tensor components, the section law uses engineering
         EPS(1) = STATEOLD(K,1) + STRAININC(K,1)
         EPS(2) = STATEOLD(K,2) + STRAININC(K,2)
         EPS(3) = STATEOLD(K,3) + 2.0D0*STRAININC(K,IS)
         CUR(1) = STATEOLD(K,4) + CURVINC(K,1)
         CUR(2) = STATEOLD(K,5) + CURVINC(K,2)
         CUR(3) = STATEOLD(K,6) + 2.0D0*CURVINC(K,3)
         CALL K14_SEC(PROPS, NPROPS, EPS, CUR, FN, FM, DD, W,
     1                FIMAX, IPMAX)
         DO I = 1, 3
            FORCENEW(K,I) = FN(I)
            XMOMNEW(K,I) = FM(I)
         ENDDO
         CALL K14_PACK(DD, DDP)
         DO L = 1, 21
            DDNDDE(K,L) = DDP(L)
         ENDDO
         DO I = 1, 3
            STATENEW(K,I) = EPS(I)
            STATENEW(K,I+3) = CUR(I)
         ENDDO
         STATENEW(K,7) = FIMAX
         STATENEW(K,8) = MAX(STATEOLD(K,8), FIMAX)
         STATENEW(K,9) = DBLE(IPMAX)
!        energies are per unit mass: mass per unit area = DENSITY*THICK
         ENERINTERNNEW(K) = W/(DENSITY(K)*THICK(K))
         ENERINELASNEW(K) = ENERINELASOLD(K)
      ENDDO
      RETURN
      END
