!     ex14_dresp.f   Element design response: Drucker-Prager type
!     equivalent stress  phi = q + ALPHA*I1  of the stress tensor S,
!     with q the Mises stress and I1 the trace.  Units MPa.
!
      SUBROUTINE K14_DP(NDI, NSHR, S, ALPHA, PHI, DPHI)
!     S(1:NDI) direct, S(NDI+1:NDI+NSHR) shear components (12, 13, 23);
!     DPHI(I) = d phi / d S(I) with each stored component an
!     independent variable.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION S(*), DPHI(*), SD(3), SS(3)
      SD = 0.0D0
      SS = 0.0D0
      DO I = 1, NDI
         SD(I) = S(I)
      ENDDO
      DO I = 1, NSHR
         SS(I) = S(NDI+I)
      ENDDO
      P = (SD(1) + SD(2) + SD(3))/3.0D0
      Q2 = 1.5D0*((SD(1)-P)**2 + (SD(2)-P)**2 + (SD(3)-P)**2
     1   + 2.0D0*(SS(1)**2 + SS(2)**2 + SS(3)**2))
      Q = SQRT(Q2)
      PHI = Q + ALPHA*3.0D0*P
      DO I = 1, NDI
         DPHI(I) = ALPHA
         IF (Q .GT. 0.0D0) DPHI(I) = DPHI(I) + 1.5D0*(SD(I)-P)/Q
      ENDDO
      DO I = 1, NSHR
         DPHI(NDI+I) = 0.0D0
         IF (Q .GT. 0.0D0) DPHI(NDI+I) = 3.0D0*SS(I)/Q
      ENDDO
      RETURN
      END
!
      SUBROUTINE UELEMDRESP(NDI, NSHR, NTENS, LFLAG, NOUTPUT,
     1 INDEX_OUTPUT, PRIMAL_VAR, DRESP_ID, OUTPUT_ID, DRESP_VALUE,
     2 DRESP_DERIVATIVES, TEMP, FIELD, STATEV, DIRECT, T, CELENT,
     3 TIME, COORD, CMNAME, ORNAME, NFIELD, NSTATV, NOEL, NPT, LAYER,
     4 KSPT, KSTEP, KINC, I_ARRAY, NIARRAY, R_ARRAY, NRARRAY,
     5 C_ARRAY, NCARRAY)
!
      INCLUDE 'ABA_PARAM.INC'
!
      PARAMETER (ALPHA = 0.15D0)
      DIMENSION PRIMAL_VAR(*), DRESP_DERIVATIVES(*),
     1 INDEX_OUTPUT(NOUTPUT,2)
      DIMENSION FIELD(NFIELD), STATEV(NSTATV), DIRECT(3,3), T(3,3),
     1 TIME(2), COORD(*), I_ARRAY(NIARRAY), R_ARRAY(NRARRAY),
     2 C_ARRAY(NCARRAY)
      CHARACTER*80 DRESP_ID, OUTPUT_ID(NOUTPUT)
      DIMENSION DPHI(6)
!
      IF (OUTPUT_ID(1)(1:1) .NE. 'S' .OR. NTENS .NE. NDI + NSHR) THEN
         WRITE(7,*) 'UELEMDRESP: response defined for the stress S'
         CALL XIT
      ENDIF
      I0 = INDEX_OUTPUT(1,1)
      CALL K14_DP(NDI, NSHR, PRIMAL_VAR(I0), ALPHA, PHI, DPHI)
      IF (LFLAG .EQ. 1) THEN
         DRESP_VALUE = PHI
      ELSE
         DO I = 1, NTENS
            DRESP_DERIVATIVES(I) = DPHI(I)
         ENDDO
      ENDIF
      RETURN
      END
!
      SUBROUTINE UCOHESIVEOFFSET(OFFSETOLD, OFFSETNEW, DELTA, OPENMAX,
     1 NOEL, NPT, COORDS, KSTEP, KINC, STIME, DTIME, TEMP, DTEMP,
     2 PREDEF, DPRED, NFIELD, JMAC, JMATYP, MATLAYO, LACCFLA, SDEGOLD,
     3 GAPINI, THICKINI, STRESSOLD, STRESSNEW, DDSDDE, NTENS, NDI,
     4 NSHR, DP, CV, JFLGOPT, STATEV, NSTATEV, NIARRAY, I_ARRAY,
     5 NRARRAY, R_ARRAY, NCARRAY, C_ARRAY)
!
      INCLUDE 'ABA_PARAM.INC'
!
      PARAMETER (OFF0 = 0.005D0, SDLIM = 0.99999D0)
      DIMENSION DELTA(*), COORDS(*), PREDEF(*), DPRED(*), JMAC(*),
     1 JMATYP(*), STRESSOLD(NTENS), STRESSNEW(NTENS),
     2 DDSDDE(NTENS,NTENS), STATEV(NSTATEV), I_ARRAY(NIARRAY),
     3 R_ARRAY(NRARRAY), C_ARRAY(NCARRAY)
!
!     JFLGOPT = 1: Abaqus derives the traction from the offset
      JFLGOPT = 1
!     OFF0 (mm): offset kept once the interface has failed completely,
!     in the steps after the first; it is never reduced again
      OFFSETNEW = 0.0D0
      IF (KSTEP .GT. 1 .AND. SDEGOLD .GE. SDLIM) OFFSETNEW = OFF0
      OFFSETNEW = MAX(OFFSETNEW, OFFSETOLD)
      RETURN
      END
