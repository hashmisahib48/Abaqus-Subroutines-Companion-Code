!     k16_drv_adh.f  Driver for the adhesive UINTER: replays a history
!     of relative displacements (RDISP), 2-D interface (NDIR = 2).
!     Output per increment: RDISP, STRESS, DDSDDR, finite-difference
!     DDSDDR, STATEV, SED, cumulative SPD and the work of the stress.
      PROGRAM K16_DRV_ADH
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (NSEGMAX = 12)
      DIMENSION PROPS(3), RD(2), RD0(2), DRD(2), ST(2), DD(2,2)
      DIMENSION STV(3), STV0(3), STVC(3), STP(2), STM(2), DDX(2,2)
      DIMENSION RDP(2), TARG(2,0:NSEGMAX), FD(2,2)
      PROPS(1) = 1.D4
      PROPS(2) = 20.D0
      PROPS(3) = 0.5D0
      DO ICASE = 1, 4
         NSEG = 0
         IF (ICASE .EQ. 1) THEN
!           mode I: open, partial unload, reload, fail, close, compress
            NSEG = 6
            TARG(1,0) = 0.D0
            TARG(1,1) = -0.02D0
            TARG(1,2) = -0.01D0
            TARG(1,3) = -0.04D0
            TARG(1,4) = -0.06D0
            TARG(1,5) = -0.03D0
            TARG(1,6) = 0.01D0
            DO K = 0, NSEG
               TARG(2,K) = 0.D0
            END DO
         ELSE IF (ICASE .EQ. 2) THEN
!           mode II: shear, unload, reverse, fail
            NSEG = 4
            TARG(1,0) = 0.D0
            TARG(2,0) = 0.D0
            DO K = 1, NSEG
               TARG(1,K) = 0.D0
            END DO
            TARG(2,1) = 0.03D0
            TARG(2,2) = 0.D0
            TARG(2,3) = -0.03D0
            TARG(2,4) = -0.06D0
         ELSE IF (ICASE .EQ. 3) THEN
!           mixed mode, equal opening and shear, to failure
            NSEG = 3
            TARG(1,0) = 0.D0
            TARG(2,0) = 0.D0
            TARG(1,1) = -0.015D0
            TARG(2,1) = 0.015D0
            TARG(1,2) = -0.005D0
            TARG(2,2) = 0.005D0
            TARG(1,3) = -0.06D0
            TARG(2,3) = 0.06D0
         ELSE
!           shear under compression (closed interface)
            NSEG = 2
            TARG(1,0) = 0.D0
            TARG(2,0) = 0.D0
            TARG(1,1) = 0.01D0
            TARG(2,1) = 0.03D0
            TARG(1,2) = 0.01D0
            TARG(2,2) = 0.07D0
         END IF
         STV = 0.D0
         RD = 0.D0
         SPDSUM = 0.D0
         WORK = 0.D0
         FDMAX = 0.D0
         WRITE(*,'(A,I2)') '# case', ICASE
         DO ISEG = 1, NSEG
            NINC = 200
            DO INC = 1, NINC
               RD0 = RD
               STV0 = STV
               S10 = 0.D0
               F = DBLE(INC)/NINC
               RD(1) = TARG(1,ISEG-1) + F*(TARG(1,ISEG)-TARG(1,ISEG-1))
               RD(2) = TARG(2,ISEG-1) + F*(TARG(2,ISEG)-TARG(2,ISEG-1))
               DRD = RD - RD0
!              stress at the start of the increment, for the work
               STVC = STV0
               CALL K16_CALLU(2, RD0, DRD, PROPS, 3, STVC, 3, STP, DDX,
     1            SEDX, SPDX)
               STVC = STV0
               CALL K16_CALLU(2, RD, DRD, PROPS, 3, STVC, 3, ST, DD, SED,
     1            SPD)
               STV = STVC
!              finite-difference Jacobian from the start-of-increment
!              state, central differences, step 1E-7 mm
               H = 1.D-7
               DO J = 1, 2
                  RDP = RD
                  RDP(J) = RD(J) + H
                  STVC = STV0
                  CALL K16_CALLU(2, RDP, DRD, PROPS, 3, STVC, 3, STP,
     1               DDX, SEDX, SPDX)
                  RDP(J) = RD(J) - H
                  STVC = STV0
                  CALL K16_CALLU(2, RDP, DRD, PROPS, 3, STVC, 3, STM,
     1               DDX, SEDX, SPDX)
                  DO I = 1, 2
                     FD(I,J) = (STP(I) - STM(I))/(2.D0*H)
                  END DO
               END DO
               ERR = 0.D0
               DO I = 1, 2
                  DO J = 1, 2
                     ERR = MAX(ERR, ABS(FD(I,J) - DD(I,J)))
                  END DO
               END DO
               ERR = ERR/PROPS(1)
!              skip points within 1E-6 mm of a kink of the law
               DM = SQRT(MAX(-RD(1),0.D0)**2 + RD(2)**2)
               IF (ABS(DM - PROPS(2)/PROPS(1)) .GT. 1.D-6 .AND.
     1            ABS(DM - 2.D0*PROPS(3)/PROPS(2)) .GT. 1.D-6 .AND.
     2            ABS(RD(1)) .GT. 1.D-6) FDMAX = MAX(FDMAX, ERR)
               S10 = 0.D0
               STVC = STV0
               CALL K16_CALLU(2, RD0, DRD, PROPS, 3, STVC, 3, STP, DDX,
     1            SEDX, SPDX)
               WORK = WORK + 0.5D0*((STP(1) + ST(1))*DRD(1)
     1            + (STP(2) + ST(2))*DRD(2))
               SPDSUM = SPDSUM + SPD
               IF (INC .EQ. NINC) THEN
                  WRITE(*,'(A,2F9.4,2F11.5,4F11.2,F9.5,F8.5,3F10.6,
     1               ES10.2)') 'P', RD(1), RD(2), ST(1), ST(2), DD(1,1),
     2               DD(1,2), DD(2,1), DD(2,2), STV(1), STV(2), SED,
     3               SPDSUM, WORK, ERR
               END IF
               WRITE(*,'(A,2F10.6,2F12.5,F9.5,F10.6,F11.6,F11.6)')
     1            'T', RD(1), RD(2), ST(1), ST(2), STV(2), SED, SPDSUM,
     2            WORK
            END DO
         END DO
         WRITE(*,'(A,ES11.3)') 'E max FD error / K =', FDMAX
      END DO
      END
