!     k16_drv_exp.f  Driver for VUINTER (exponential law): (1) block
!     result against the scalar UINTER; (2) mass dropped on the
!     interface, integrated by the central-difference rule of
!     Abaqus/Explicit; energy balance and peak overclosure.
      PROGRAM K16_DRV_EXP
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (NS = 6)
      DIMENSION PROPS(3), RB(2,NS), DRB(2,NS), SB(2,NS), SEDB(NS)
      DIMENSION STV(1,NS), R1(2), D1(2), S1(2), DD1(2,2), STV1(1)
      DIMENSION STVM(1)
      PROPS(1) = 5.D0
      PROPS(2) = 0.05D0
      PROPS(3) = 600.D0
      DRB = 0.D0
      RB(1,1) = -1.D36
      RB(1,2) = -0.08D0
      RB(1,3) = -0.03D0
      RB(1,4) = 0.D0
      RB(1,5) = 0.04D0
      RB(1,6) = 0.12D0
      RB(2,:) = 0.D0
      STV = 0.D0
      CALL K16_CALLV(NS, RB, DRB, PROPS, 3, STV, 1, SB, SEDB)
      DMAX = 0.D0
      DO K = 1, NS
         R1(1) = RB(1,K)
         R1(2) = 0.D0
         D1 = 0.D0
         CALL K16_CALLU(2, R1, D1, PROPS, 3, STV1, 1, S1, DD1, SED1,
     1      SPD1)
         DMAX = MAX(DMAX, ABS(SB(1,K) - S1(1)), ABS(SEDB(K) - SED1))
         WRITE(*,'(A,ES10.2,2ES16.8)') 'V', RB(1,K), SB(1,K), SEDB(K)
      END DO
      WRITE(*,'(A,ES10.2)') 'V max difference to UINTER =', DMAX
!     ---- drop test ----
      AM = 0.01D0
      G = 9810.D0
      A = 100.D0
      H0 = 1.D0
      DO IDT = 1, 3
         DT = 1.D-4/10.D0**(IDT-1)
         IF (IDT .EQ. 1) DT = 1.D-4
         GAP = H0
         V = 0.D0
!        v at -1/2: from the first half step
         ACC = -G
         V = V + 0.5D0*DT*ACC
         E0 = AM*G*H0
         DPEN = 0.D0
         TPEAK = 0.D0
         EMAX = 0.D0
         FPEAK = 0.D0
         STV = 0.D0
         NSTEP = NINT(0.025D0/DT)
         TOUCH = -1.D0
         TLEAVE = -1.D0
         DO N = 1, NSTEP
            T = N*DT
            RB(1,1) = -GAP
            RB(2,1) = 0.D0
            DRB(1,1) = 0.D0
            CALL K16_CALLV(1, RB(1,1), DRB(1,1), PROPS, 3, STV, 1,
     1         SB(1,1), SEDB(1))
            F = A*SB(1,1)
            IF (F .GT. 0.D0 .AND. TOUCH .LT. 0.D0) TOUCH = T
            IF (F .EQ. 0.D0 .AND. TOUCH .GT. 0.D0 .AND. TLEAVE .LT.
     1         0.D0) TLEAVE = T
            ACC = (-AM*G + F)/AM
            VOLD = V
            V = V + DT*ACC
            VMID = 0.5D0*(VOLD + V)
            EKIN = 0.5D0*AM*VMID*VMID
            ETOT = EKIN + AM*G*GAP + A*SEDB(1)
            EMAX = MAX(EMAX, ABS(ETOT - E0)/E0)
            IF (-GAP .GT. DPEN) THEN
               DPEN = -GAP
               TPEAK = T
            END IF
            FPEAK = MAX(FPEAK, F)
            IF (IDT .EQ. 2 .AND. MOD(N,10) .EQ. 0) WRITE(*,'(A,F9.5,
     1         F10.6,F10.3,3F11.5)') 'H', T, GAP, F, EKIN, AM*G*GAP,
     2         A*SEDB(1)
            GAP = GAP + DT*V
         END DO
         WRITE(*,'(A,ES9.1,F10.6,F9.5,F10.3,F9.5,F9.5,ES10.2)')
     1      'D', DT, DPEN, TPEAK, FPEAK, TOUCH, TLEAVE, EMAX
      END DO
      END
