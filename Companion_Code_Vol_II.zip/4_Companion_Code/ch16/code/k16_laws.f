!     k16_laws.f   Interface laws shared by UINTER, VUINTER and
!     VUINTERACTION (units: N, mm, MPa; stress = force per unit area).
!     Double precision is declared here so that one copy serves both
!     Abaqus/Standard and Abaqus/Explicit.
      SUBROUTINE K16_EXPO(DELTA, P0, C0, AKMAX, P, DPDD, W)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (ZERO = 0.D0, ONE = 1.D0, BIG = 1.D30)
!     DELTA overclosure (mm, > 0 penetration), P0 (MPa), C0 (mm),
!     AKMAX slope cap (MPa/mm, <= 0: none); P (MPa), DPDD (MPa/mm),
!     W energy per unit area (N/mm)
      EM1 = EXP(ONE) - ONE
      P = ZERO
      DPDD = ZERO
      W = ZERO
      IF (DELTA .LE. -C0) RETURN
      XK = BIG
      IF (AKMAX .GT. ZERO) XK = MAX(ZERO, LOG(AKMAX*EM1*C0/P0))
      X = (DELTA + C0)/C0
      IF (X .LE. XK) THEN
         EX = EXP(X)
         P = P0*(EX - ONE)/EM1
         DPDD = P0*EX/(EM1*C0)
         W = P0*C0*(EX - ONE - X)/EM1
      ELSE
!        linear continuation with the slope AKMAX beyond X = XK
         EK = EXP(XK)
         PK = P0*(EK - ONE)/EM1
         WK = P0*C0*(EK - ONE - XK)/EM1
         DD = DELTA - (XK*C0 - C0)
         P = PK + AKMAX*DD
         DPDD = AKMAX
         W = WK + PK*DD + 0.5D0*AKMAX*DD*DD
      END IF
      RETURN
      END
!
      SUBROUTINE K16_ADH(RD, AK, T0, GC, DMAX0, S, DS, DMAX, DMG,
     1   SEL, PHI)
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (ZERO = 0.D0, ONE = 1.D0, HALF = 0.5D0)
      DIMENSION RD(3), S(3), DS(3,3)
!     Eqs. 16.5-1 to 16.5-5.  RD: RDISP(1:3) (mm); AK (MPa/mm), T0
!     (MPa), GC (N/mm); DMAX0 largest separation so far (mm).
!     Out: S stress, DS Jacobian, DMAX, DMG damage, SEL stored
!     energy and PHI dissipated energy (N/mm).
      D0 = T0/AK
      DF = 2.D0*GC/T0
      UN = MAX(-RD(1), ZERO)
      DM = SQRT(UN*UN + RD(2)*RD(2) + RD(3)*RD(3))
      DMAX = MAX(DMAX0, DM)
      DP = ZERO
      IF (DMAX .LE. D0) THEN
         DMG = ZERO
      ELSE IF (DMAX .GE. DF) THEN
         DMG = ONE
      ELSE
         DMG = DF*(DMAX - D0)/(DMAX*(DF - D0))
         IF (DM .GT. DMAX0) DP = D0*DF/(DMAX*DMAX*(DF - D0))
      END IF
      DS = ZERO
      FAC = (ONE - DMG)*AK
      IF (RD(1) .GT. ZERO) THEN
         S(1) = AK*RD(1)
         DS(1,1) = AK
      ELSE
         S(1) = FAC*RD(1)
         DS(1,1) = FAC - AK*DP*UN*UN/MAX(DM, 1.D-300)
      END IF
      DO K = 2, 3
         S(K) = FAC*RD(K)
         DS(K,K) = FAC
      END DO
      IF (DP .GT. ZERO) THEN
         DO K = 2, 3
            DO J = 2, 3
               DS(K,J) = DS(K,J) - AK*DP*RD(K)*RD(J)/DM
            END DO
            DS(1,K) = AK*DP*UN*RD(K)/DM
            DS(K,1) = DS(1,K)
         END DO
      END IF
      SEL = HALF*FAC*(UN*UN + RD(2)*RD(2) + RD(3)*RD(3))
      IF (RD(1) .GT. ZERO) SEL = SEL + HALF*AK*RD(1)**2
      PHI = ZERO
      IF (DMAX .GT. D0) THEN
         DC = MIN(DMAX, DF)
         WT = HALF*T0*D0 + T0*(DF*(DC - D0) - HALF*(DC*DC - D0*D0))
     1      /(DF - D0)
         PHI = WT - HALF*T0*(DF - DC)/(DF - D0)*DC
      END IF
      RETURN
      END
