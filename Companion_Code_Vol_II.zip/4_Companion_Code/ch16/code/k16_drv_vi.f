!     k16_drv_vi.f  Driver for VUINTERACTION (adhesive with damage).
!     Case 1: mode I, penetration 0 -> -0.06 mm, unloaded to -0.02.
!     Case 2: opening and shear together (increments of equal size).
!     Case 3: one secondary node with two proximity points; the update
!     of the tangential separation must not be repeated within an
!     increment (the guard on STATE(6)).
      PROGRAM K16_DRV_VI
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(3), PEN(2), DRD(2,2), STATE(6,1,2), ST(2,2)
      DIMENSION SED(2), SPD(2), SPDSUM(2)
      PROPS(1) = 1.D4
      PROPS(2) = 20.D0
      PROPS(3) = 0.5D0
      DO ICASE = 1, 2
         STATE = 0.D0
         SPDSUM = 0.D0
         PEN(1) = 0.D0
         NINC = 600
         WRITE(*,'(A,I2)') '# case', ICASE
         DO KINC = 1, NINC + 200
            DUN = -0.06D0/NINC
            IF (KINC .GT. NINC) DUN = 0.04D0/200.D0
            IF (ICASE .EQ. 2) DUN = DUN*0.5D0
            PEN(1) = PEN(1) + DUN
            DRD = 0.D0
            DRD(1,1) = DUN
            IF (ICASE .EQ. 2) DRD(2,1) = -DUN
            CALL K16_CALLVI(1, KINC, PEN, DRD, PROPS, STATE, ST, SED,
     1         SPD)
            SPDSUM(1) = SPDSUM(1) + SPD(1)
            IF (MOD(KINC,50) .EQ. 0) WRITE(*,'(A,I5,F10.5,2F11.5,F9.5,
     1         2F10.6)') 'T', KINC, PEN(1), ST(1,1), ST(2,1),
     2         STATE(2,1,1), SED(1), SPDSUM(1)
         END DO
      END DO
!     ---- case 3 ----
      STATE = 0.D0
      PEN(1) = -0.02D0
      PEN(2) = -0.03D0
      DRD = 0.D0
      DRD(2,1) = 0.001D0
      DRD(2,2) = 0.001D0
      AR1 = 0.6D0
      AR2 = 0.4D0
      CALL K16_CALLVI(2, 1, PEN, DRD, PROPS, STATE, ST, SED, SPD)
      WRITE(*,'(A,4ES14.6)') 'B1', STATE(4,1,1), STATE(4,1,2),
     1   ST(1,1), ST(1,2)
      FN = AR1*ST(1,1) + AR2*ST(1,2)
      FS = AR1*ST(2,1) + AR2*ST(2,2)
      WRITE(*,'(A,2ES14.6)') 'B2 node force (N), normal and shear', FN,
     1   FS
!     second call for the same increment, with the updated state
      CALL K16_CALLVI(2, 1, PEN, DRD, PROPS, STATE, ST, SED, SPD)
      WRITE(*,'(A,4ES14.6)') 'B3', STATE(4,1,1), STATE(4,1,2),
     1   ST(1,1), ST(1,2)
      END
