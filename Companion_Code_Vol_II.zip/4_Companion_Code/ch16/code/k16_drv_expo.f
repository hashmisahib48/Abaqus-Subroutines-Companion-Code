!     k16_drv_expo.f  Driver for the exponential UINTER (Chapter 16).
!     Part 1: curve, finite-difference slope, energy by quadrature.
!     Part 2: Newton iterations on a spring-loaded plate (Example 16.4-2).
      PROGRAM K16_DRV_EXPO
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      DIMENSION PROPS(3), RD(2), DRD(2), ST(2), DD(2,2), STV(1)
      DIMENSION RDP(2), STP(2), DDP(2,2), RDM(2), STM(2), DDM(2,2)
      PROPS(1) = 5.D0
      PROPS(2) = 0.05D0
      DRD(1) = 0.D0
      DRD(2) = 0.D0
      DO ICASE = 1, 2
         PROPS(3) = 0.D0
         IF (ICASE .EQ. 2) PROPS(3) = 600.D0
         WRITE(*,'(A,I2,A,F8.1)') '# case', ICASE, '  AKMAX =',
     1      PROPS(3)
         DO IG = -7, 14
            DEL = 0.01D0*IG
            IF (ICASE .EQ. 1 .AND. IG .GT. 8) CYCLE
            RD(1) = DEL
            RD(2) = 0.D0
            CALL K16_CALLU(2, RD, DRD, PROPS, 3, STV, 1, ST, DD, SED,
     1         SPD)
            H = 1.D-7
            RDP(1) = DEL + H
            RDP(2) = 0.D0
            CALL K16_CALLU(2, RDP, DRD, PROPS, 3, STV, 1, STP, DDP,
     1         SEDP, SPD)
            RDM(1) = DEL - H
            RDM(2) = 0.D0
            CALL K16_CALLU(2, RDM, DRD, PROPS, 3, STV, 1, STM, DDM,
     1         SEDM, SPD)
            FD = (STP(1) - STM(1))/(2.D0*H)
!           energy by Simpson's rule from -C0 to DEL with 2000 panels
            WQ = 0.D0
            IF (DEL .GT. -PROPS(2)) THEN
               N = 2000
               HH = (DEL + PROPS(2))/N
               DO I = 0, N
                  RD(1) = -PROPS(2) + HH*I
                  CALL K16_CALLU(2, RD, DRD, PROPS, 3, STV, 1, STP, DDP,
     1               SEDX, SPD)
                  WGT = 2.D0
                  IF (MOD(I,2) .EQ. 1) WGT = 4.D0
                  IF (I .EQ. 0 .OR. I .EQ. N) WGT = 1.D0
                  WQ = WQ + WGT*STP(1)
               END DO
               WQ = WQ*HH/3.D0
            END IF
            WRITE(*,'(A,F7.3,5ES16.8)') 'C', DEL, ST(1), DD(1,1), FD,
     1         SED, WQ
         END DO
      END DO
!     ---- Part 2: Newton on a spring-loaded plate ----
      PROPS(3) = 0.D0
      AKS = 6000.D0
      AREA = 100.D0
      G0 = 0.2D0
      DO ITAN = 1, 3
         WRITE(*,'(A,I2)') '# newton tangent', ITAN
         U = 0.D0
         DO INC = 1, 3
            UD = 0.25D0 + 0.05D0*(INC - 1)
            RD(1) = U - G0
            CALL K16_CALLU(2, RD, DRD, PROPS, 3, STV, 1, ST, DD, SED,
     1         SPD)
            R = AKS*(UD - U) - AREA*ST(1)
            R0 = ABS(R)
            TAN0 = AKS + AREA*DD(1,1)
            DO IT = 1, 60
               WRITE(*,'(A,2I3,ES16.6,F14.2)') 'N', INC, IT-1, ABS(R),
     1            U
               IF (ABS(R) .LT. 1.D-9*AKS*UD) EXIT
               RD(1) = U - G0
               CALL K16_CALLU(2, RD, DRD, PROPS, 3, STV, 1, ST, DD, SED,
     1            SPD)
               IF (ITAN .EQ. 1) TK = AKS + AREA*DD(1,1)
               IF (ITAN .EQ. 2) TK = AKS
               IF (ITAN .EQ. 3) TK = AKS + AREA*PROPS(1)*EXP(1.D0)
     1            /((EXP(1.D0) - 1.D0)*PROPS(2))
               U = U + R/TK
               RD(1) = U - G0
               CALL K16_CALLU(2, RD, DRD, PROPS, 3, STV, 1, ST, DD, SED,
     1            SPD)
               R = AKS*(UD - U) - AREA*ST(1)
            END DO
            WRITE(*,'(A,I3,F12.6,F10.5,A,I3)') 'S', INC, U, U-G0,
     1         '   iters', IT-1
         END DO
      END DO
      END
