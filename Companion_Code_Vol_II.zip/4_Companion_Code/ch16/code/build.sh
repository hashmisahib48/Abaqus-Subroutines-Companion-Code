#!/bin/bash
# compile all listings and drivers (gfortran 13, stubs of lib/aba) and run them
cd "$(dirname "$0")"; I=-I/home/claude/vol2/lib/aba; F="-ffixed-form -ffixed-line-length-none -std=legacy $I"
for f in k16_laws ex16_uinter ex16_uinter_adh ex16_vuinter ex16_vuinteraction prob_16b2_bug; do gfortran -c $F -Wall -Wno-unused $f.f -o /tmp/claude-0/$f.o 2>&1 | grep -E "Error|error" ; done
gfortran $F k16_drv_expo.f k16_call.f ex16_uinter.f k16_laws.f -o drv_expo && ./drv_expo > ../verify/out_expo.txt
gfortran $F k16_drv_adh.f k16_call.f ex16_uinter_adh.f k16_laws.f -o drv_adh && ./drv_adh > ../verify/out_adh.txt
gfortran $F k16_drv_exp.f k16_call.f k16_callv.f ex16_uinter.f ex16_vuinter.f k16_laws.f -o drv_exp && ./drv_exp > ../verify/out_exp.txt
gfortran $F k16_drv_vi.f k16_callvi.f ex16_vuinteraction.f k16_laws.f -o drv_vi && ./drv_vi > ../verify/out_vi.txt
cd ../verify && python3 check.py > out_check.txt && python3 check2.py >> out_check.txt && python3 prob.py > /dev/null
