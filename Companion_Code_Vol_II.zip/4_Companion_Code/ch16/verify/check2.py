import os; B=os.path.dirname(os.path.abspath(__file__))
import math, json, numpy as np
K,T0,GC=1e4,20.,.5; d0=T0/K; df=2*GC/T0
def adh(un,us,dmax0=0.0):
    dm=math.hypot(un,us); dmax=max(dmax0,dm)
    D=0 if dmax<=d0 else (1 if dmax>=df else df*(dmax-d0)/(dmax*(df-d0)))
    return (1-D)*K*un,(1-D)*K*us,D,dmax
out={}
# VI case 1 table lines (T lines)
c=None; mx1=0; mx2=0
for l in open(B+'/out_vi.txt'):
    if l.startswith('# case'): c=int(l.split()[2]); dmax=0; pen=0; us=0
    elif l.startswith('T'):
        t=l.split(); kinc=int(t[1])
    elif l.startswith('B1'):
        t=l.split(); b1=[float(x) for x in t[1:]]
# recompute the two cases with the same increments
for case in (1,2):
    pen=0.; us=0.; dmax=0.; worst=0.
    for kinc in range(1,801):
        dun=-0.06/600
        if kinc>600: dun=0.04/200
        if case==2: dun*=0.5
        pen+=dun
        if case==2: us+=-dun
        tn,ts,D,dmax=adh(max(-pen,0),us,dmax)
        S1=-tn if pen<=0 else K*pen
        if kinc%50==0:
            # compare with printed line
            for l in open(B+'/out_vi.txt'):
                pass
        if kinc%50==0: out.setdefault(case,[]).append((kinc,pen,S1,ts if case==2 else 0,D))
vals={1:[],2:[]}; c=None
for l in open(B+'/out_vi.txt'):
    if l.startswith('# case'): c=int(l.split()[2])
    elif l.startswith('T'):
        t=l.split(); vals[c].append((int(t[1]),float(t[2]),float(t[3]),float(t[4]),float(t[5])))
for case in (1,2):
    e=max(max(abs(a[2]-b[2]),abs(a[3]-b[3]),abs(a[4]-b[4])) for a,b in zip(out[case],vals[case]))
    print('VI case',case,'max |driver-closed form| (MPa):',e)
# B-lines
un1,un2,us=0.02,0.03,0.001
for un in (un1,un2):
    tn,ts,D,_=adh(un,us); print('B closed form un',un,'S1',-tn,'S2',ts)
tn1,ts1,_,_=adh(un1,us); tn2,ts2,_,_=adh(un2,us)
print('node force', -0.6*tn1-0.4*tn2, 0.6*ts1+0.4*ts2)
# drop test comparison
P=json.load(open(B+'/prob.json'))['drop']; print(P)
for l in open(B+'/out_exp.txt'):
    if l.startswith('D'):
        t=l.split(); print('dt',t[1],'dmax err',float(t[2])-P['dmax'],'F err',float(t[4])-P['Fmax'],'touch',t[5],'leave',t[6],'dur',float(t[6])-float(t[5]),'Eerr',t[7])
