"""Independent checks for Chapter 16 (closed forms in Python, compared with the Fortran drivers)."""
import os; B=os.path.dirname(os.path.abspath(__file__))
import numpy as np, json, math, re
from scipy.optimize import brentq
from scipy.integrate import quad
R={}
E1=math.e-1
def expo(d,p0,c0,kmax=0.0):
    if d<=-c0: return 0.0,0.0,0.0
    xk=math.log(kmax*E1*c0/p0) if kmax>0 else 1e30
    xk=max(xk,0.0); x=(d+c0)/c0
    if x<=xk:
        return p0*(math.exp(x)-1)/E1, p0*math.exp(x)/(E1*c0), p0*c0*(math.exp(x)-1-x)/E1
    ek=math.exp(xk); pk=p0*(ek-1)/E1; wk=p0*c0*(ek-1-xk)/E1; dd=d-(xk*c0-c0)
    return pk+kmax*dd,kmax,wk+pk*dd+0.5*kmax*dd*dd
# ---- exponential law, driver table
rows=[l.split() for l in open(B+'/out_expo.txt') if l.startswith('C ')]
case=0; err=dict(p=0,k=0,w=0,fd=0,wq=0)
for l in open(B+'/out_expo.txt'):
    if l.startswith('# case'): case=int(l.split()[2]); continue
    if not l.startswith('C '): continue
    t=l.split(); d=float(t[1]); p,dp,s,fd,w,wq=[float(x) for x in t[2:8]] if False else (float(t[2]),float(t[3]),0,float(t[4]),float(t[5]),float(t[6]))
    pe,ke,we=expo(d,5.0,0.05,600.0 if case==2 else 0.0)
    err['p']=max(err['p'],abs(p-pe)); err['k']=max(err['k'],abs(dp-ke)); err['w']=max(err['w'],abs(w-we)); err['wq']=max(err['wq'],abs(wq-we))
    if abs(d+0.05)>1e-9: err['fd']=max(err['fd'],abs(fd-dp)/max(dp,1))
R['expo_err']=err; print('expo',err)
# ---- Newton equilibrium
ks,A,g0=6000.,100.,0.2
eq={}
for ud in (0.25,0.30,0.35):
    f=lambda u: ks*(ud-u)-A*expo(u-g0,5.,0.05)[0]
    u=brentq(f,0.0,ud,xtol=1e-14); eq[ud]=(u,u-g0,expo(u-g0,5.,0.05)[0])
R['newton_eq']={str(k):v for k,v in eq.items()}; print('newton',eq)
# parse newton table
nt={}; cur=None
for l in open(B+'/out_expo.txt'):
    if l.startswith('# newton'): cur=int(l.split()[-1]); nt[cur]={}
    elif l.startswith('N') and cur:
        t=l.split(); inc,it,res=int(t[1]),int(t[2]),float(t[3]); nt[cur].setdefault(inc,[]).append(res)
    elif l.startswith('S') and cur:
        t=l.split(); print('S',cur,t)
R['newton_hist']={str(k):{str(i):v for i,v in d.items()} for k,d in nt.items()}
# ---- adhesive closed form
K,T0,GC=1e4,20.,0.5; d0=T0/K; df=2*GC/T0
def env(u): 
    return K*u if u<=d0 else (T0*(df-u)/(df-d0) if u<df else 0.0)
print('d0,df',d0,df)
cases={}; cur=None
for l in open(B+'/out_adh.txt'):
    if l.startswith('# case'): cur=int(l.split()[2]); cases[cur]={'T':[],'P':[]}
    elif l.startswith('T'): cases[cur]['T'].append([float(x) for x in l.split()[1:]])
    elif l.startswith('P'): cases[cur]['P'].append([float(x) for x in l.split()[1:]])
    elif l.startswith('E'): cases[cur]['fd']=float(l.split()[-1])
# mode I check vs closed form on the envelope (loading) and secant unloading
T=np.array(cases[1]['T'])
mx=0; umax=0
for rd1,rd2,s1,s2,dmg,sed,spd,work in T:
    u=-rd1
    if u<0: continue
    # reconstruct max so far
umaxs=np.maximum.accumulate(np.maximum(-T[:,0],0))
exp_s=[]
for k,(rd1,rd2,s1,s2,dmg,sed,spd,work) in enumerate(T):
    u=max(-rd1,0.0); um=umaxs[k]
    if rd1>0: se=K*rd1
    else:
        se=-env(um)/um*u if um>0 else 0.0
        if um<=d0: se=-K*u
    exp_s.append(se)
    mx=max(mx,abs(se-s1))
R['adh_modeI_maxerr_MPa']=mx; print('adh mode I max stress err',mx)
# energy balance: sed+spd vs work at all steps
bal=max(abs(T[k,5]+T[k,6]-T[k,7]) for k in range(len(T))); R['adh_energy_balance_max']=bal; print('balance',bal)
R['adh_fd']={k:cases[k]['fd'] for k in cases}
R['adh_P']={k:cases[k]['P'] for k in cases}
# closed-form dissipated energy at failure
R['adh_gc_driver']=[cases[1]['P'][3][11],cases[2]['P'][3][11],cases[3]['P'][2][11]]
print('Gc from drivers',R['adh_gc_driver'])
json.dump({k:v for k,v in R.items()},open(B+'/results.json','w'),indent=1,default=float)
