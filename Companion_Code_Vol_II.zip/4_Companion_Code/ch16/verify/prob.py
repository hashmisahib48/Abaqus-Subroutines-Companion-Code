import os; B=os.path.dirname(os.path.abspath(__file__))
import math, numpy as np, json
from scipy.optimize import brentq
from check import expo   # reuses the closed-form law (prints its own checks)
E1=math.e-1
out={}
# drop test: m=0.01 t, A=100 mm2, h0=1 mm, p0=5, c0=0.05, kmax=600
m,G,A,H0=0.01,9810.,100.,1.0
f=lambda d: m*G*(H0+d)-A*expo(d,5.,0.05,600.)[2]
d=brentq(f,0.0,0.2,xtol=1e-14); pk=expo(d,5.,0.05,600.)
out['drop']=dict(dmax=d,pmax=pk[0],Fmax=A*pk[0],slope=pk[1])
tfall=math.sqrt(2*(H0-0.05)/G); out['drop']['tfall']=tfall; out['drop']['v_touch']=math.sqrt(2*G*(H0-0.05))
out['drop']['omega_max']=math.sqrt(A*600./m); out['drop']['dt_crit']=2/out['drop']['omega_max']
out['drop']['omega0']=math.sqrt(A*expo(0,5.,0.05)[1]/m)
# contact duration estimate by numerical integration of energy: t = 2*int dd/v
def v(dd): 
    return math.sqrt(max(2*(G*(H0+dd)-A/m*expo(dd,5.,.05,600.)[2]),0))
# contact begins at delta=-c0 where speed is v_touch
tc=2*quad_t if False else None
from scipy.integrate import quad
tc=2*quad(lambda x:1/max(v(x),1e-9),-0.05,d-1e-9,limit=200)[0]
out['drop']['t_contact']=tc
# Problem A1: p0=4, c0=0.1
for dl in (-0.04,0.02):
    out.setdefault('A1',[]).append((dl,)+expo(dl,4.,0.1))
# Problem A2: K=5000,T0=30,Gc=0.4, load to 0.015
K,T0,GC=5000.,30.,0.4; d0=T0/K; df=2*GC/T0
u=0.015; t=T0*(df-u)/(df-d0); D=df*(u-d0)/(u*(df-d0)); ku=(1-D)*K
Wt=0.5*T0*d0+T0*(df*(u-d0)-0.5*(u*u-d0*d0))/(df-d0); phi=Wt-0.5*t*u
out['A2']=dict(d0=d0,df=df,t=t,D=D,ku=ku,soft=-T0/(df-d0),phi=phi,sed=0.5*t*u,Wt=Wt)
# A3: m=0.02,A=200,h0=0.5, no cap p0=5,c0=.05
m3,A3,H3=0.02,200.,0.5
f=lambda d: m3*G*(H3+d)-A3*expo(d,5.,0.05)[2]
d3=brentq(f,0.0,0.3,xtol=1e-14); p3=expo(d3,5.,.05)
om=math.sqrt(A3*p3[1]/m3)
out['A3']=dict(dmax=d3,pmax=p3[0],F=A3*p3[0],k=p3[1],omega=om,dt=2/om)
# B1: tangent at un=0.02, us=0.01 on the loading branch, K=1e4,T0=20,Gc=.5
K,T0,GC=1e4,20.,.5; d0=T0/K; df=2*GC/T0
un,us=0.02,0.01; dm=math.hypot(un,us)
D=df*(dm-d0)/(dm*(df-d0)); Dp=d0*df/(dm**2*(df-d0))
S=np.array([-(1-D)*K*un,(1-D)*K*us])
DS=np.array([[(1-D)*K-K*Dp*un**2/dm, K*Dp*un*us/dm],[K*Dp*un*us/dm,(1-D)*K-K*Dp*us**2/dm]])
w,vv=np.linalg.eigh(DS)
out['B1']=dict(dm=dm,D=D,Dp=Dp,S=S.tolist(),DS=DS.tolist(),eig=w.tolist(),slope=-T0/(df-d0))
# C2: power-law initiation, Tn=20,Ts=30,K=1e4, phi=45 deg
Tn,Ts=20.,30.
for ph in (0,45,90):
    c,s=math.cos(math.radians(ph)),math.sin(math.radians(ph))
    d0m=1/(K*math.sqrt((c/Tn)**2+(s/Ts)**2)); out.setdefault('C2',[]).append((ph,d0m,K*d0m*c,K*d0m*s))
json.dump(out,open(B+'/prob.json','w'),indent=1,default=float)
print(json.dumps(out,indent=1,default=float))
