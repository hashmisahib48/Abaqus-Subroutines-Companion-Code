      SUBROUTINE UTRS(SHIFT,TEMP,DTEMP,TIME,DTIME,PREDEF,DPRED,
     1 STATEV,CMNAME,COORDS)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION SHIFT(2),TIME(2),PREDEF(*),DPRED(*),STATEV(*),
     1 COORDS(*)
      DOUBLE PRECISION K6_LNA
!
!     Shift function of Eq. (6.4-1); UTRS has no PROPS argument,
!     so the constants are fixed here.
!     TG in deg C, C1 dimensionless, C2 in K
      PARAMETER (TG = 80.0D0, C1 = 17.44D0, C2 = 51.6D0)
!
!     TEMP is the temperature at the END of the increment
      ALNB = K6_LNA(TEMP - DTEMP, TG, C1, C2)
      ALNE = K6_LNA(TEMP, TG, C1, C2)
      IF (MAX(ALNB, ALNE) .GT. 600.0D0) THEN
         WRITE(7,*) 'UTRS: shift function out of range, TEMP =', TEMP
         CALL XIT
      ENDIF
      SHIFT(1) = EXP(ALNB)
      SHIFT(2) = EXP(ALNE)
      RETURN
      END
