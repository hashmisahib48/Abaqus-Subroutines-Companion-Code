      PROGRAM K6TRS
!     Driver for UTRS, VUTRS and UTRSNETWORK (outside Abaqus).
!     MODE 1: read N lines (TEMP, DTEMP); print the shift functions
!             returned by UTRS, VUTRS, UTRSNETWORK (networks 1 and 2).
!     MODE 2: Prony relaxation in reduced time (one unit strain step
!             at t = 0); input: NP, (G_i, TAU_i), RULE, N, (T_j, TH_j).
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (MAXN=200000)
      DIMENSION TT(MAXN),TH(MAXN),G(10),TAU(10),H(10)
      DIMENSION SHIFT(2),TIME(2),PREDEF(1),DPRED(1),STATEV(1),COORDS(3)
      DIMENSION VSH(1,2),TOLD(1),TNEW(1),VP(3),DEN(1),CM(1,3)
      DIMENSION FO(1,1),FN(1,1),SO(1,1),SN(1,1)
      DIMENSION OD(2),PRP(4),IA(6),RA(4)
      CHARACTER*80 CMNAME,CA(1)
      CMNAME='K6'
      READ(*,*) MODE
      IF (MODE .EQ. 1) THEN
         READ(*,*) N
         VP(1)=80.0D0
         VP(2)=17.44D0
         VP(3)=51.6D0
         PRP(1)=80.0D0
         PRP(2)=17.44D0
         PRP(3)=51.6D0
         PRP(4)=4000.0D0
         DO K=1,N
            READ(*,*) T,DT
            CALL UTRS(SHIFT,T,DT,TIME,0.0D0,PREDEF,DPRED,STATEV,CMNAME,
     1           COORDS)
            TOLD(1)=T-DT
            TNEW(1)=T
            CALL VUTRS(1,0,0,3,0.0D0,0.0D0,0.0D0,CMNAME,VP,DEN,CM,
     1           TOLD,FO,SO,TNEW,FN,VSH,SN)
            CALL UTRSNETWORK(OD,STATEV,2,0,1,COORDS,T,DT,0,PREDEF,DPRED,
     1           4,PRP,IA,6,RA,4,CA,1)
            A1=OD(1)
            A2=OD(2)
            CALL UTRSNETWORK(OD,STATEV,2,0,2,COORDS,T,DT,0,PREDEF,DPRED,
     1           4,PRP,IA,6,RA,4,CA,1)
            WRITE(*,'(A,1P,10E26.16E3)') 'S ',T,DT,SHIFT(1),SHIFT(2),
     1           VSH(1,1),VSH(1,2),A1,A2,OD(1),OD(2)
         ENDDO
      ELSE
         READ(*,*) NP
         DO I=1,NP
            READ(*,*) G(I),TAU(I)
         ENDDO
         GINF=1.0D0
         DO I=1,NP
            GINF=GINF-G(I)
            H(I)=G(I)
         ENDDO
         READ(*,*) IRULE,N
         DO J=1,N
            READ(*,*) TT(J),TH(J)
         ENDDO
         XI=0.0D0
         WRITE(*,'(A,1P,4E26.16E3)') 'R ',TT(1),TH(1),XI,1.0D0
         DO J=2,N
            DTT=TT(J)-TT(J-1)
            DTH=TH(J)-TH(J-1)
            CALL UTRS(SHIFT,TH(J),DTH,TIME,DTT,PREDEF,DPRED,STATEV,
     1           CMNAME,COORDS)
            A1=SHIFT(1)
            A2=SHIFT(2)
            IF (IRULE .EQ. 1) THEN
               DXI=DTT/A1
            ELSE IF (IRULE .EQ. 2) THEN
               DXI=DTT/SQRT(A1*A2)
            ELSE IF (IRULE .EQ. 3) THEN
               IF (ABS(LOG(A2/A1)) .GT. 1.0D-10) THEN
                  DXI=DTT*(1.0D0/A1-1.0D0/A2)/LOG(A2/A1)
               ELSE
                  DXI=DTT/A1
               ENDIF
            ELSE
               DXI=DTT/(0.5D0*(A1+A2))
            ENDIF
            XI=XI+DXI
            R=GINF
            DO I=1,NP
               H(I)=H(I)*EXP(-DXI/TAU(I))
               R=R+H(I)
            ENDDO
            WRITE(*,'(A,1P,4E26.16E3)') 'R ',TT(J),TH(J),XI,R
         ENDDO
      ENDIF
      END
