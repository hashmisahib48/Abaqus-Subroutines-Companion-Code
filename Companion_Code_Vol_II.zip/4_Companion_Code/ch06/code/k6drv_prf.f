      PROGRAM K6PRF
!     Driver for UCREEPNETWORK, VUCREEPNETWORK and UTRSNETWORK.
!     Incompressible neo-Hookean networks in uniaxial tension.
!     MODE 1: derivative test (finite differences) and Standard/Explicit
!             comparison at NS states.
!     MODE 2: stress relaxation at fixed stretch.
!     MODE 3: creep of one network at fixed Kirchhoff stress.
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (MAXN=100000, MAXNET=3)
      DIMENSION TT(MAXN),TH(MAXN)
      DIMENSION SR(MAXNET),PRP(5,MAXNET),TRP(4,MAXNET),ITRS(MAXNET)
      DIMENSION ALC(MAXNET),EQS(MAXNET),XI(MAXNET),SIGK(MAXNET)
      DIMENSION QK(MAXNET),NITK(MAXNET),OD(2),IA(6),RA(4)
      DIMENSION STATEV(1),COORDS(3),PREDEF(1),DPRED(1)
      CHARACTER*80 CA(1)
      COMMON /K6SC/ DSC3,DSC4,JINC
      DSC3=1.0D0
      DSC4=1.0D0
      READ(*,*) MODE
      IF (MODE .EQ. 1) THEN
         CALL K6_FDTEST
         STOP
      ENDIF
      READ(*,*) XMU,TARGET,NNET
      SEQ=1.0D0
      DO K=1,NNET
         READ(*,*) SR(K),(PRP(J,K),J=1,5),(TRP(J,K),J=1,4),ITRS(K)
         SEQ=SEQ-SR(K)
      ENDDO
      READ(*,*) DSC3,DSC4
      READ(*,*) N
      DO J=1,N
         READ(*,*) TT(J),TH(J)
      ENDDO
!     initial state: instantaneous elastic response
      IF (MODE .EQ. 2) THEN
         ALAM=TARGET
      ELSE
         ALAM=0.0D0
         SIGT=TARGET
!        elastic stretch of the single network: s*mu*(x*x-1/x)=sigma
         X=1.0D0+SIGT/(3.0D0*SR(1)*XMU)
         DO IT=1,60
            F=SR(1)*XMU*(X*X-1.0D0/X)-SIGT
            DF=SR(1)*XMU*(2.0D0*X+1.0D0/X**2)
            X=X-F/DF
         ENDDO
         ALE0=X
         ALAM=ALE0
      ENDIF
      DO K=1,NNET
         ALC(K)=1.0D0
         EQS(K)=0.0D0
         XI(K)=0.0D0
      ENDDO
      SIGEQ=SEQ*XMU*(ALAM**2-1.0D0/ALAM)
      STOT=SIGEQ
      DO K=1,NNET
         SIGK(K)=SR(K)*XMU*((ALAM)**2-1.0D0/ALAM)
         STOT=STOT+SIGK(K)
         QK(K)=ABS(SIGK(K))
         NITK(K)=0
      ENDDO
      CALL K6_PRINT(1,TT(1),TH(1),STOT,NNET,XI,EQS,QK,NITK,ALAM)
      DO J=2,N
         JINC=J
         DTT=TT(J)-TT(J-1)
         DTH=TH(J)-TH(J-1)
         SOTH0=SIGEQ
         DO K=1,NNET
            SOTH0=SOTH0+SIGK(K)
         ENDDO
         DO K=1,NNET
!           reduced time increment (log-linear A, exact integral)
            DXI=DTT
            IF (ITRS(K) .EQ. 1) THEN
               CALL UTRSNETWORK(OD,STATEV,2,0,K,COORDS,TH(J),DTH,0,
     1              PREDEF,DPRED,4,TRP(1,K),IA,6,RA,4,CA,1)
               A1=OD(1)
               A2=OD(2)
               IF (ABS(LOG(A2/A1)) .GT. 1.0D-10) THEN
                  DXI=DTT*(1.0D0/A1-1.0D0/A2)/LOG(A2/A1)
               ELSE
                  DXI=DTT/A1
               ENDIF
            ENDIF
            SOTH=SOTH0-SIGK(K)
            CALL K6_SOLVE(MODE,XMU,SR(K),ALAM,ALE0,SIGT,SOTH,ALC(K),
     1           EQS(K),DXI,XI(K)+DXI,TH(J),DTH,PRP(1,K),DEQ,NIT,SIG,Q)
            ALC(K)=ALC(K)*EXP(DEQ)
            EQS(K)=EQS(K)+DEQ
            XI(K)=XI(K)+DXI
            SIGK(K)=SIG
            QK(K)=Q
            NITK(K)=NIT
         ENDDO
         IF (MODE .EQ. 3) ALAM=ALE0*ALC(1)
         STOT=SEQ*XMU*(ALAM**2-1.0D0/ALAM)
         DO K=1,NNET
            STOT=STOT+SIGK(K)
         ENDDO
         CALL K6_PRINT(J,TT(J),TH(J),STOT,NNET,XI,EQS,QK,NITK,ALAM)
      ENDDO
      END
!
      SUBROUTINE K6_PRINT(J,T,TH,STOT,NNET,XI,EQS,QK,NITK,ALAM)
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION XI(*),EQS(*),QK(*),NITK(*)
      WRITE(*,'(A,I7,1P,5E25.16E3,3(1X,3E25.16E3,I4))') 'P ',J,T,TH,
     1  STOT,ALAM,0.0D0,(XI(K),EQS(K),QK(K),NITK(K),K=1,NNET)
      RETURN
      END
!
      SUBROUTINE K6_CALL(OUT,PRP,DXI,XIE,EQ,Q,P,TRC,AI1,AI2,AJ,TE,DTE)
!     one call of UCREEPNETWORK with the argument arrays filled
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION OUT(8),PRP(5),RA(11),IA(7),STATEV(1),COORDS(3)
      DIMENSION PREDEF(1),DPRED(1)
      CHARACTER*80 CA(1)
      CA(1)='K6'
      DO I=1,7
         IA(I)=0
      ENDDO
      IA(7)=1
      RA(1)=0.0D0
      RA(2)=0.0D0
      RA(3)=XIE
      RA(4)=DXI
      RA(5)=EQ
      RA(6)=Q
      RA(7)=TRC
      RA(8)=AI1
      RA(9)=AI2
      RA(10)=AJ
      RA(11)=P
      CALL UCREEPNETWORK(OUT,STATEV,8,0,1,COORDS,TE,DTE,0,PREDEF,DPRED,
     1     5,PRP,IA,7,RA,11,CA,1)
      RETURN
      END
!
      SUBROUTINE K6_SOLVE(MODE,XMU,S,ALAM,ALE0,SIGT,SOTH,ALCN,EQN,DXI,
     1     XIE,TE,DTE,PRP,X,NIT,SIG,Q)
!     local Newton iteration for the equivalent creep strain increment
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PRP(5),OUT(8)
      COMMON /K6SC/ DSC3,DSC4,JINC
      X=0.0D0
      NIT=0
      AI1=ALAM**2+2.0D0/ALAM
      AI2=2.0D0*ALAM+1.0D0/ALAM**2
      DO IT=1,60
         ALC=ALCN*EXP(X)
         IF (MODE .EQ. 2) THEN
            ALE=ALAM/ALC
            SIG=S*XMU*(ALE**2-1.0D0/ALE)
            DSIG=-S*XMU*(2.0D0*ALE**2+1.0D0/ALE)
         ELSE
            SIG=SIGT
            DSIG=0.0D0
         ENDIF
         Q=ABS(SIG)
         DQ=SIGN(1.0D0,SIG)*DSIG
         P=-(SIG+SOTH)/3.0D0
         DP=-DSIG/3.0D0
         TRC=ALC**2+2.0D0/ALC
         DTRC=2.0D0*ALC**2-2.0D0/ALC
         CALL K6_CALL(OUT,PRP,DXI,XIE,EQN+X,Q,P,TRC,AI1,AI2,1.0D0,TE,
     1        DTE)
         R=X-OUT(1)
         WRITE(*,'(A,I7,I4,1P,E25.16E3)') 'N ',JINC,IT,ABS(R)
         DG=OUT(3)*DSC3*DQ+OUT(8)*DP+OUT(2)+OUT(4)*DSC4*DTRC
         DX=-R/(1.0D0-DG)
         X=X+DX
         NIT=IT
         IF (ABS(DX) .LT. 1.0D-13*(1.0D0+ABS(X)) .AND.
     1       ABS(R) .LT. 1.0D-12) GOTO 10
      ENDDO
      NIT=-NIT
   10 CONTINUE
!     final state
      ALC=ALCN*EXP(X)
      IF (MODE .EQ. 2) THEN
         ALE=ALAM/ALC
         SIG=S*XMU*(ALE**2-1.0D0/ALE)
      ELSE
         SIG=SIGT
      ENDIF
      Q=ABS(SIG)
      RETURN
      END
!
      SUBROUTINE K6_FDTEST
!     derivative test: slots 2-8 against central differences of slot 1
!     and Standard/Explicit comparison.  All states share DXI = S(1,1).
!     DXI,EQ,Q,P,TRC,AI1,AI2,AJ  and the five properties once.
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (MS=20)
      DIMENSION PRP(5),OUT(8),OP(8),OM(8),S(8,MS),V(7),DGV(MS,4)
      DIMENSION QV(MS),PV(MS),EQV(MS),TRV(MS),R11(MS,10),I11(MS,1)
      DIMENSION TOLD(MS),TNEW(MS),FO(MS,1),SO(MS,1),CM(MS,3),JE(MS)
      DIMENSION STV(MS,1)
      CHARACTER*80 CN
      READ(*,*) NS
      READ(*,*) (PRP(I),I=1,5)
      DO K=1,NS
         READ(*,*) (S(I,K),I=1,8)
      ENDDO
!     inputs ordered as slots 2..8: EQ, Q, TRC, AI1, AI2, AJ, P
      DO K=1,NS
         DXI=S(1,K)
         V(1)=S(2,K)
         V(2)=S(3,K)
         V(3)=S(5,K)
         V(4)=S(6,K)
         V(5)=S(7,K)
         V(6)=S(8,K)
         V(7)=S(4,K)
         CALL K6_CALL(OUT,PRP,DXI,0.0D0,V(1),V(2),V(7),V(3),V(4),V(5),
     1        V(6),20.0D0,0.0D0)
         DO M=1,7
            H=1.0D-6*MAX(1.0D0,ABS(V(M)))
            V(M)=V(M)+H
            CALL K6_CALL(OP,PRP,DXI,0.0D0,V(1),V(2),V(7),V(3),V(4),
     1           V(5),V(6),20.0D0,0.0D0)
            V(M)=V(M)-2.0D0*H
            CALL K6_CALL(OM,PRP,DXI,0.0D0,V(1),V(2),V(7),V(3),V(4),
     1           V(5),V(6),20.0D0,0.0D0)
            V(M)=V(M)+H
!           slot M+1 = derivative with respect to V(M)
            FD=(OP(1)-OM(1))/(2.0D0*H)
            WRITE(*,'(A,I3,I3,1P,3E26.16E3)') 'D ',K,M+1,OUT(M+1),FD,
     1           OUT(1)
         ENDDO
      ENDDO
!     Explicit comparison, vectorised call
      DO K=1,MS
         KK=MIN(K,NS)
         QV(K)=S(3,KK)
         PV(K)=S(4,KK)
         EQV(K)=S(2,KK)
         TRV(K)=S(5,KK)
         TOLD(K)=20.0D0
         TNEW(K)=20.0D0
         JE(K)=K
      ENDDO
      CN='K6'
      CALL VUCREEPNETWORK(MS,1,0,0,5,4,0.0D0,0.0D0,S(1,1),JE,1,1,1,CN,
     1     PRP,CM,TOLD,FO,SO,TNEW,FO,1,I11,1,R11,QV,PV,EQV,TRV,DGV,STV)
      DO K=1,NS
         CALL K6_CALL(OUT,PRP,S(1,K),0.0D0,S(2,K),S(3,K),S(4,K),S(5,K),
     1        S(6,K),S(7,K),S(8,K),20.0D0,0.0D0)
         WRITE(*,'(A,I3,1P,4E26.16E3)') 'V ',K,DGV(K,1)-OUT(1),
     1        DGV(K,2)-OUT(3),DGV(K,3)-OUT(2),DGV(K,4)-OUT(4)
      ENDDO
      RETURN
      END
