      DOUBLE PRECISION FUNCTION K6_LNA(TH,TG,C1,C2)
!
!     Natural logarithm of the shift function A(TH), Eq. (6.4-1):
!        TH >= TG : Williams-Landel-Ferry with reference TG
!        TH <  TG : Arrhenius, activation energy chosen so that
!                   ln A and d(ln A)/d(TH) are continuous at TG
!     TH, TG in deg C;  C1 dimensionless;  C2 in K.
!     No Abaqus include: shared by Standard and Explicit.
!
      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (DLN10 = 2.302585092994046D0, T0K = 273.15D0)
!
      D = TH - TG
      IF (D .GE. 0.0D0) THEN
         K6_LNA = -DLN10*C1*D/(C2 + D)
      ELSE
         TGK = TG + T0K
         EAR = DLN10*C1*TGK**2/C2
         K6_LNA = EAR*(1.0D0/(TH + T0K) - 1.0D0/TGK)
      ENDIF
      RETURN
      END
