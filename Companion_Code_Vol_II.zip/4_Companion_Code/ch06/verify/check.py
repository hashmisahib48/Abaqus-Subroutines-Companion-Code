"""Chapter 6: runs the drivers, compares with the closed forms of ref.py, writes results.json and data.npz."""
import sys, json, numpy as np
sys.path.insert(0,'.')
from drv import *; from ref import *
from scipy.optimize import brentq
R={}; D={}
PR=(2e-4,0.5,2.0,0.5,0.05)        # EDOT0 (1/s), SIG0 (MPa), SIGP (MPa), EPSS, EREG
TRP1=(80.0,17.44,51.6,4000.0)
NET1=[dict(s=1.0,pr=PR,trp=TRP1)]
# ---------------------------------------------------------------- 1. shift functions
ths=[120,100,90,80,70,60,50,40,20]
tl=np.concatenate([np.linspace(0,130,261),[79.9999,80.0001]])
inp="1\n%d\n"%len(tl)+"\n".join("%.17g 0"%x for x in tl)+"\n"
rows=[[float(x) for x in l.split()[1:]] for l in run_trs(inp)]
S=np.array(rows)   # T DT S1 S2 VS1 VS2 N1S1 N1S2 N2S1 N2S2
ref=np.exp(lnA(S[:,0]))
R['shift_maxrel']=float(np.max(np.abs(S[:,2]/ref-1)))
R['vutrs_maxdiff']=float(np.max(np.abs(S[:,4]/S[:,2]-1)))
R['net1_maxdiff']=float(np.max(np.abs(S[:,6]/S[:,2]-1)))
ref2=np.exp(lnA_arr(S[:,0],80.0,4000.0)); R['net2_maxrel']=float(np.max(np.abs(S[:,8]/ref2-1)))
tab=[]
for th in ths:
    i=np.argmin(np.abs(S[:,0]-th)); tab.append([th,float(np.log10(S[i,2])),float(lnA_wlf(th)/DLN10) if th>80-51.6 else None])
R['table']=tab
tgk=353.15; R['ear']=DLN10*17.44*tgk**2/51.6; R['slope_exact']=-DLN10*17.44/51.6
h=1e-4; iL=len(S)-2; iR=len(S)-1
R['slopeL']=float((0-np.log(S[iL,2]))/1e-4); R['slopeR']=float((np.log(S[iR,2])-0)/1e-4)
R['lnA_at_Tg']=float(np.log(S[np.argmin(np.abs(S[:,0]-80)),2]))
# increment SHIFT(1)/(2)
r=run_trs("1\n1\n70 10\n")[0].split(); R['incr']=[float(x) for x in r[3:5]]; R['incr_ref']=[float(np.exp(lnA(60.0))),float(np.exp(lnA(70.0)))]
R['wlf_singular']=80-51.6
R['wlf_raw40']=float(lnA_wlf(40.0)/DLN10)
D['shift_T']=S[:,0]; D['shift_A']=S[:,2]
# ---------------------------------------------------------------- 2. reduced time on a cooling ramp (Prony)
g=[0.2,0.25,0.15]; tau=[0.1,1.0,10.0]
def Rf(xi): return 0.4+sum(gi*np.exp(-xi/ti) for gi,ti in zip(g,tau))
pts=[(0,80),(20,50)]; xe=xi_exact(20,pts); R['ramp_xi']=xe; R['ramp_R']=float(Rf(xe))
Ns=[5,10,20,40,80,160]; E={}
for rule in (1,2,3,4):
    ex=[];er=[]
    for N in Ns:
        t=np.linspace(0,20,N+1); th=theta_of(t,pts)
        inp="2\n3\n"+"\n".join(f"{a} {b}" for a,b in zip(g,tau))+f"\n{rule} {len(t)}\n"+"\n".join("%.17g %.17g"%(a,b) for a,b in zip(t,th))+"\n"
        last=run_trs(inp)[-1].split(); ex.append((float(last[3])-xe)/xe); er.append(float(last[4])-Rf(xe))
    E[rule]=(ex,er)
R['ramp']={str(k):{'N':Ns,'xi_err':v[0],'R_err':v[1]} for k,v in E.items()}
D['ramp_N']=np.array(Ns); D['ramp_err']=np.array([[abs(x) for x in E[k][0]] for k in (1,2,3,4)])
# isothermal relaxation at several temperatures = closed form G(t/A)
mc={}
for th in (100,90,80,70,60):
    A=np.exp(lnA(th)); t=np.concatenate([[0],10**np.arange(-3,12.01,0.25)])*1.0
    tt=A*np.concatenate([[0],10**np.arange(-3,3.01,0.25)])
    inp="2\n3\n"+"\n".join(f"{a} {b}" for a,b in zip(g,tau))+f"\n3 {len(tt)}\n"+"\n".join("%.17g %.17g"%(a,float(th)) for a in tt)+"\n"
    L=[[float(x) for x in l.split()[1:]] for l in run_trs(inp)]; L=np.array(L)
    # reference: exp(-t/(A tau)) recursion is exact for constant theta
    ref=0.4+sum(gi*np.exp(-(L[:,0]/A)/ti) for gi,ti in zip(g,tau))
    mc[th]=(float(np.max(np.abs(L[:,3]-ref))),L[:,0],L[:,3],A)
R['master_maxerr']=max(v[0] for v in mc.values())
D['mc_T']=np.array(sorted(mc)); 
for th,v in mc.items(): D[f'mc_t_{th}']=v[1]; D[f'mc_R_{th}']=v[2]; D[f'mc_A_{th}']=v[3]
# ---------------------------------------------------------------- 3. derivative test
st=[(0.5,0.15,1.2,-0.4,3.6,4.5,4.1,1.0),(0.5,0.0,0.3,-0.1,3.0,3.2,3.2,1.0),(0.5,0.6,2.0,-0.7,4.4,5.5,5.9,1.0)]
inp="1\n3\n"+" ".join(repr(x) for x in PR)+"\n"+"\n".join(" ".join(repr(x) for x in s) for s in st)+"\n"
out=subprocess.run([OUT+'/k6drv_prf'],input=inp,capture_output=True,text=True).stdout.splitlines()
dd=[l.split() for l in out if l.startswith('D ')]
fd=[(int(l[1]),int(l[2]),float(l[3]),float(l[4]),float(l[5])) for l in dd]
R['fd']=[{'state':a,'slot':b,'ana':c,'fd':d_,'dg':e} for a,b,c,d_,e in fd]
R['fd_maxrel']=max(abs(c-d_)/max(abs(c),1e-300) for a,b,c,d_,e in fd if b in (2,3,4,8))
R['fd_zero']=max(abs(c)+abs(d_) for a,b,c,d_,e in fd if b in (5,6,7))
vv=[[float(x) for x in l.split()[2:]] for l in out if l.startswith('V ')]
R['vu_maxdiff']=float(np.max(np.abs(vv)))
# ---------------------------------------------------------------- 4. relaxation, closed form
cv={}
for nd in (5,10,20,40,80,160):
    t=grid(0.01,1000,nd); th=np.full_like(t,80.0)
    d=run_prf(2,1.0,1.5,NET1,t,th)
    s,e=relax_exact(1.5,1.0,PR,t[1:])
    cv[nd]=(float(np.abs(d['sig'][1:]-s).max()/d['sig'][0]), int(d['nit'][0][1:].max()), int(d['nit'][0][1:].sum()))
R['relax_conv']={str(k):v for k,v in cv.items()}
t=grid(0.01,1000,20); th=np.full_like(t,80.0); d=run_prf(2,1.0,1.5,NET1,t,th)
s,e=relax_exact(1.5,1.0,PR,t[1:]); D['rel_t']=t; D['rel_sig']=d['sig']; D['rel_ref_sig']=np.concatenate([[1.5-1/1.5],s]); D['rel_eps']=d['eps'][0]; D['rel_ref_eps']=np.concatenate([[0],e])
# quadrature cross check of ODE reference
x=relax_exact(1.5,1.0,PR,np.array([10.0]))[1][0]; le=1.5/np.exp(x); R['quad_check']=abs(relax_quad(1.5,1.0,PR,le)-10.0)/10.0
tk=[0.1,1,10,100]; R['relax_tab']=[]
idx=[int(np.argmin(np.abs(t-x))) for x in tk]
for ii in idx:
    R['relax_tab'].append([float(t[ii]),float(d['sig'][ii]),float(D['rel_ref_sig'][ii]),float(d['eps'][0][ii] if False else d['eps'][0][ii]),float(D['rel_ref_eps'][ii])])
R['relax_sig0']=float(d['sig'][0])
# ---------------------------------------------------------------- 5. Newton iterations
nit={}
for name,dsc in (('exact',(1,1)),('q70',(0.7,1)),('q0',(0.0,1)),('i1c0',(1,0))):
    dd_=run_prf(2,1.0,1.5,NET1,t,th,dsc); k=dd_['nit'][0][1:]
    nit[name]=(int(k.sum()),int(k.max()),float(np.abs(dd_['sig'][1:]-s).max()/dd_['sig'][0]))
    if name in ('exact','q70','q0'):
        j=[tt for tt in range(2,len(t)+1)]; jj=int(np.argmin(np.abs(t-1.0)))+1
        nw=dd_['newton']; sel=nw[nw[:,0]==jj]; D['newton_'+name]=sel[:,2]
R['newton']=nit
# ---------------------------------------------------------------- 6. creep
t=grid(0.01,300,40); th=np.full_like(t,80.0)
dc=run_prf(3,1.0,1.0,NET1,t,th)
def eps_at(xi):
    f=lambda e: creep_quad(1.0,1.0,PR,e)[0]-xi
    return brentq(f,1e-12,3.0,xtol=1e-14)
epsr=np.array([eps_at(x) for x in t[1:]])
R['creep_maxerr']=float(np.max(np.abs(dc['eps'][0][1:]-epsr)))
R['creep_maxrel']=float(np.max(np.abs(dc['eps'][0][1:]-epsr)/epsr))
D['cr_t']=t; D['cr_eps']=dc['eps'][0]; D['cr_ref']=np.concatenate([[0],epsr]); D['cr_lam']=dc['lam']
R['creep_le']=creep_quad(1.0,1.0,PR,0.1)[1]
R['creep_pts']=[[float(t[i]),float(dc['eps'][0][i]),float(D['cr_ref'][i]),float(dc['lam'][i])] for i in [int(np.argmin(np.abs(t-x))) for x in (1,10,100)]]
# convergence of creep
cc={}
for nd in (10,20,40,80):
    tt=grid(0.01,300,nd); thh=np.full_like(tt,80.0); dcc=run_prf(3,1.0,1.0,NET1,tt,thh)
    er=np.array([eps_at(x) for x in tt[1:]]); cc[nd]=float(np.max(np.abs(dcc['eps'][0][1:]-er)/er))
R['creep_conv']={str(k):v for k,v in cc.items()}
# ---------------------------------------------------------------- 7. temperature step on the network
pts=[(0,80),(10,80),(10.01,75),(2000,75)]
ts={}
for nd in (10,20,40,80):
    t=grid(0.01,1000,nd,extra=[10,10.01]); th=theta_of(t,pts)
    n1=[dict(s=1.0,pr=PR,trp=TRP1,trs=1)]
    d=run_prf(2,1.0,1.5,n1,t,th)
    xi=np.array([xi_exact(x,pts) for x in t[1:]]); s,e=relax_exact(1.5,1.0,PR,xi)
    ts[nd]=float(np.abs(d['sig'][1:]-s).max()/d['sig'][0])
R['tstep_conv']={str(k):v for k,v in ts.items()}
D['ts_t']=t; D['ts_sig']=d['sig']; D['ts_ref']=np.concatenate([[1.5-1/1.5],s]); D['ts_th']=th
R['tstep_A75']=float(np.exp(lnA(75.0))); R['tstep_xi_end']=float(xi_exact(1000,pts))
# isothermal reference without step
s0,_=relax_exact(1.5,1.0,PR,t[1:]); D['ts_iso']=np.concatenate([[1.5-1/1.5],s0])
# ---------------------------------------------------------------- 8. two networks + equilibrium, linear limit = Prony
mu=1.0; sig0=1e3
spec=[(0.35,2.0,1),(0.25,0.05,2)]      # ratio, tau at TG (s), network id
def netpr(s,tau_):
    e0=sig0/(3*tau_*s*mu); return (e0,sig0,1e9,1e9,1.0)
def netspec(lam):
    return [dict(s=s,pr=netpr(s,ta),trp=((80.0,17.44,51.6,4000.0)),trs=1) for s,ta,_ in spec]
def prony(t_,th_,pts_):
    xi1=np.array([xi_exact(x,pts_,lambda th:lnA(th)) for x in t_])
    xi2=np.array([xi_exact(x,pts_,lambda th:lnA_arr(th,80.0,4000.0)) for x in t_])
    return 0.4+0.35*np.exp(-xi1/2.0)+0.25*np.exp(-xi2/0.05)
lm={}
def prony_be(t_,thc):
    """backward-Euler recursion of the linear model (same increments as the driver)"""
    A1=np.exp(lnA(thc)); A2=np.exp(lnA_arr(thc,80.0,4000.0)); h1=0.35; h2=0.25; out=[]
    for k in range(1,len(t_)):
        dt_=t_[k]-t_[k-1]; h1/=1+dt_/A1/2.0; h2/=1+dt_/A2/0.05; out.append(0.4+h1+h2)
    return np.array(out)
for lam in (1.0001,1.001):
    for thc in (80.0,70.0,60.0):
        pts_=[(0,thc),(1e9,thc)]
        t=grid(1e-3,1e5,20); th=np.full_like(t,thc)
        d=run_prf(2,mu,lam,netspec(lam),t,th,(1,1))
        rf=prony(t[1:],th[1:],pts_); be=prony_be(t,thc)
        sig0_=mu*(lam**2-1/lam)
        sn=d['sig'][1:]/sig0_
        lm[(lam,thc)]=(float(np.abs(sn-be).max()),float(np.abs(sn-rf).max()))
        if lam==1.0001: D[f'lm_t_{int(thc)}']=t; D[f'lm_s_{int(thc)}']=d['sig']/sig0_; D[f'lm_r_{int(thc)}']=np.concatenate([[1.0],rf])
R['linlimit']={f"{k[0]}_{k[1]}":v for k,v in lm.items()}
R['A_net']=[float(np.exp(lnA(th))) for th in (80,70,60)]; R['A_net2']=[float(np.exp(lnA_arr(th,80.0,4000.0))) for th in (80,70,60)]
json.dump(R,open('results.json','w'),indent=1,default=float)
np.savez('data.npz',**D)

