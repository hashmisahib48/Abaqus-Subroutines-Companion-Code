import sys, json, numpy as np
sys.path.insert(0,'.')
from ref import *; from drv import *
from scipy.optimize import brentq
P={}
# 6A.1
P['A1_A95']=float(np.exp(lnA_wlf(95.0))); P['A1_log95']=float(lnA_wlf(95.0)/DLN10)
d=brentq(lambda d: -17.44*d/(51.6+d)+3,0,100); P['A1_th']=80+d
P['A1_sing']=80-51.6
# 6A.2 two-step history
A70=float(np.exp(lnA(70.0))); P['A2_xi']=5.0+100.0/A70; P['A2_A70']=A70
g=[0.2,0.25,0.15]; tau=[0.1,1.0,10.0]
P['A2_R']=0.4+sum(gi*np.exp(-P['A2_xi']/ti) for gi,ti in zip(g,tau))
P['A2_R_noshift']=0.4+sum(gi*np.exp(-105/ti) for gi,ti in zip(g,tau))
# 6A.3 arrays at state 1 (already in results)
# 6B.1
P['B1_e0']=1e3/(3*2.0*0.35*1.0)
# 6B.3
x=brentq(lambda x: np.sinh(x)/x-1.01,1e-6,3); P['B3_delta']=2*x
slope60=97057.89964354245/(60+273.15)**2; P['B3_slope60']=slope60; P['B3_dth']=2*x/slope60
slope70=97057.89964354245/(70+273.15)**2; P['B3_slope70']=slope70; dl=2*slope70; P['B3_ratio2']=float(np.sinh(dl/2)/(dl/2)); P['B3_delta2']=dl
# 6C.1 aging closed form
te0,m=10.0,0.8
P['C1_xi']=te0**m*((te0+100)**(1-m)-te0**(1-m))/(1-m)
# 6C.2 creep with A=2: eps(100 s, A=2) = eps_unshifted(50 s)
PR=(2e-4,0.5,2.0,0.5,0.05)
def eps_at(xi):
    return brentq(lambda e: creep_quad(1.0,1.0,PR,e)[0]-xi,1e-12,3.0,xtol=1e-14)
P['C2_e50']=eps_at(50.0); P['C2_e100']=eps_at(100.0)
P['C2_lam50']=creep_quad(1.0,1.0,PR,P['C2_e50'])[1]*np.exp(P['C2_e50']); P['C2_lam100']=creep_quad(1.0,1.0,PR,P['C2_e100'])[1]*np.exp(P['C2_e100'])
json.dump(P,open('probs.json','w'),indent=1)
print(json.dumps(P,indent=1))
