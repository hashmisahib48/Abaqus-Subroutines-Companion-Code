import subprocess, numpy as np, os
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'out')
def grid(tmin,tmax,nd,extra=()):
    n=int(round(nd*np.log10(tmax/tmin)))
    t=np.concatenate([[0.0],tmin*10**(np.arange(n+1)/nd)])
    t=np.unique(np.concatenate([t,np.array(extra,float)])); return t
def run_prf(mode,mu,target,nets,t,th,dsc=(1,1)):
    """nets: list of dict(s,pr(5),trp(4),trs)"""
    L=[f"{mode}",f"{mu} {target} {len(nets)}"]
    for n in nets:
        L.append(f"{n['s']} "+" ".join(repr(float(x)) for x in n['pr'])+" "+" ".join(repr(float(x)) for x in n['trp'])+f" {n.get('trs',0)}")
    L.append(f"{dsc[0]} {dsc[1]}"); L.append(str(len(t)))
    for a,b in zip(t,th): L.append("%.17g %.17g"%(a,b))
    r=subprocess.run([OUT+'/k6drv_prf'],input="\n".join(L)+"\n",capture_output=True,text=True)
    rows=[l.split() for l in r.stdout.splitlines() if l.startswith('P ')]; nl=[l.split() for l in r.stdout.splitlines() if l.startswith('N ')]
    nn=len(nets); A=np.array([[float(x) for x in l[1:]] for l in rows])
    # columns: j t th stot lam 0 then per net (xi eps q nit)
    d=dict(j=A[:,0],t=A[:,1],th=A[:,2],sig=A[:,3],lam=A[:,4])
    d['xi']=[A[:,6+4*k] for k in range(nn)]; d['eps']=[A[:,7+4*k] for k in range(nn)]
    d['q']=[A[:,8+4*k] for k in range(nn)]; d['nit']=[A[:,9+4*k] for k in range(nn)]
    d['newton']=np.array([[float(x) for x in l[1:]] for l in nl]) if nl else np.zeros((0,3)); return d
def run_trs(inp):
    r=subprocess.run([OUT+'/k6drv_trs'],input=inp,capture_output=True,text=True)
    return [l for l in r.stdout.splitlines()]
