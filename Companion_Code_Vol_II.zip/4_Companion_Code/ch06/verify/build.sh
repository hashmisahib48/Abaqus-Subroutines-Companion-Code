#!/bin/sh
# builds the drivers of Chapter 6 with the stub include files
A=/home/claude/vol2/lib/aba
C=/home/claude/vol2/ch06/code
cd $C
gfortran -ffixed-form -std=legacy -ffixed-line-length-none -I$A -o ../verify/out/k6drv_trs k6drv_trs.f ex6_utrs.f ex6_vutrs.f ex6_utrsnetwork.f k6_shift.f $A/stubs.f || exit 1
gfortran -ffixed-form -std=legacy -ffixed-line-length-none -I$A -o ../verify/out/k6drv_prf k6drv_prf.f ex6_ucreepnetwork.f ex6_vucreepnetwork.f ex6_utrsnetwork.f k6_shift.f $A/stubs.f || exit 1
# every listing compiles on its own (Standard: default 72-column rule; Explicit: free length for the stub include)
for f in k6_shift ex6_utrs ex6_utrsnetwork ex6_ucreepnetwork prob_6b2_bug; do [ -f $f.f ] && gfortran -c -ffixed-form -std=legacy -I$A $f.f -o /tmp/k6_$f.o || true; done
for f in ex6_vutrs ex6_vucreepnetwork; do gfortran -c -ffixed-form -std=legacy -ffixed-line-length-none -I$A $f.f -o /tmp/k6_$f.o || exit 1; done
echo built
