"""Reference solutions for Chapter 6 (independent of the Fortran routines)."""
import numpy as np
from scipy.integrate import solve_ivp, quad
from scipy.optimize import brentq
DLN10=np.log(10.0)
# ---------------- shift function, Eq. (6.4-1) ----------------
def lnA(th,tg=80.0,c1=17.44,c2=51.6):
    th=np.asarray(th,float); d=th-tg
    tgk=tg+273.15; ear=DLN10*c1*tgk**2/c2
    wlf=-DLN10*c1*d/(c2+np.where(d>=0,d,0.0))
    arr=ear*(1/(th+273.15)-1/tgk)
    return np.where(d>=0,wlf,arr)
def lnA_wlf(th,tg=80.0,c1=17.44,c2=51.6):
    d=np.asarray(th,float)-tg; return -DLN10*c1*d/(c2+d)
def lnA_arr(th,tg,ear):
    return ear*(1/(np.asarray(th,float)+273.15)-1/(tg+273.15))
def theta_of(t,pts):
    """piecewise linear temperature history; pts=[(t,th),...]"""
    pts=np.array(pts,float); return np.interp(t,pts[:,0],pts[:,1])
def xi_exact(tend,pts,lna=lnA):
    """reduced time  integral_0^tend dt/A(theta(t)); break points handled"""
    pts=np.array(pts,float); br=[b for b in pts[:,0] if 0<b<tend]
    edges=[0.0]+br+[tend]; s=0.0
    for a,b in zip(edges[:-1],edges[1:]):
        v,_=quad(lambda t: np.exp(-lna(theta_of(t,pts))),a,b,epsabs=0,epsrel=1e-13,limit=400); s+=v
    return s
# ---------------- network law, Eq. (6.6-1) ----------------
def rate(q,p,eq,i1c,pr):
    e0,s0,sp,es,ereg=pr
    return e0*np.sinh(q/s0)*np.exp(-p/sp)*np.exp(-eq/es)/(np.sqrt(i1c/3)-1+ereg)
def relax_exact(lam,mu,pr,xi,s=1.0):
    """stress relaxation of ONE network (ratio s, no equilibrium network) at fixed stretch lam; returns sigma(xi)"""
    def f(t,y):
        le=np.exp(y[0]); lc=lam/le
        q=s*mu*(le**2-1/le); p=-q/3
        return [-rate(q,p,np.log(lc),lc**2+2/lc,pr)]
    sol=solve_ivp(f,[0,xi[-1]],[np.log(lam)],t_eval=xi,method='DOP853',rtol=1e-13,atol=1e-15)
    le=np.exp(sol.y[0]); return s*mu*(le**2-1/le), np.log(lam/le)
def relax_quad(lam,mu,pr,lam_e,s=1.0):
    """reduced time needed to relax from lam to lam_e (closed form as a quadrature)"""
    def g(x):
        q=s*mu*(x**2-1/x); lc=lam/x
        return 1.0/(x*rate(q,-q/3,np.log(lc),lc**2+2/lc,pr))
    v,_=quad(g,lam_e,lam,epsabs=0,epsrel=1e-13,limit=400); return v
def creep_quad(sig,mu,pr,eps,s=1.0):
    """reduced time to reach equivalent creep strain eps under constant Kirchhoff stress sig"""
    le=brentq(lambda x:s*mu*(x**2-1/x)-sig,1.0,50.0); q=sig; p=-q/3
    def g(e):
        lc=np.exp(e); return 1.0/rate(q,p,e,lc**2+2/lc,pr)
    v,_=quad(g,0,eps,epsabs=0,epsrel=1e-13,limit=400); return v,le
