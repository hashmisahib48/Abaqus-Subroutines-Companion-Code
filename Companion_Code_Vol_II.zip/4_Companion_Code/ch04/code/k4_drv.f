!     Driver for the HGO routines of Chapter 4 (outside Abaqus).
!     It calls UANISOHYPER_INV, UANISOHYPER_STRAIN, VUANISOHYPER_INV
!     and VUANISOHYPER_STRAIN as Abaqus would, forms the stress from the
!     returned derivatives, and compares with finite differences and
!     closed forms.  Results go to the standard output and to ../out.
      PROGRAM K4DRV
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), A(3,3), PR(6)
      COMMON /K4P/ PR, A, NFIB
      PI = 4.D0*ATAN(1.D0)
      GAM = 40.D0*PI/180.D0
      A = 0.D0
      A(1,1) = COS(GAM)
      A(2,1) = SIN(GAM)
      A(1,2) = COS(GAM)
      A(2,2) = -SIN(GAM)
      A(3,3) = 1.D0
      PR(1) = 0.01D0
      PR(2) = 1.D-4
      PR(3) = 0.02D0
      PR(4) = 2.D0
      PR(5) = 0.1D0
      PR(6) = 0.D0
      OPEN(10, FILE='../out/k4_main.txt')
      CALL K4_T1(10)
      CALL K4_T2(10)
      CALL K4_T3(10)
      CALL K4_T4(10)
      CALL K4_T5(10)
      CALL K4_T6(10)
      CALL K4_T7(10)
      CALL K4_T8(10)
      CLOSE(10)
      END
!
      SUBROUTINE K4_DET3(F, DET)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3)
      DET = F(1,1)*(F(2,2)*F(3,3)-F(2,3)*F(3,2))
     1    - F(1,2)*(F(2,1)*F(3,3)-F(2,3)*F(3,1))
     2    + F(1,3)*(F(2,1)*F(3,2)-F(2,2)*F(3,1))
      RETURN
      END
!
      SUBROUTINE K4_INV3(B, BI)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION B(3,3), BI(3,3)
      CALL K4_DET3(B, DET)
      BI(1,1) = (B(2,2)*B(3,3)-B(2,3)*B(3,2))/DET
      BI(1,2) = (B(1,3)*B(3,2)-B(1,2)*B(3,3))/DET
      BI(1,3) = (B(1,2)*B(2,3)-B(1,3)*B(2,2))/DET
      BI(2,1) = (B(2,3)*B(3,1)-B(2,1)*B(3,3))/DET
      BI(2,2) = (B(1,1)*B(3,3)-B(1,3)*B(3,1))/DET
      BI(2,3) = (B(1,3)*B(2,1)-B(1,1)*B(2,3))/DET
      BI(3,1) = (B(2,1)*B(3,2)-B(2,2)*B(3,1))/DET
      BI(3,2) = (B(1,2)*B(3,1)-B(1,1)*B(3,2))/DET
      BI(3,3) = (B(1,1)*B(2,2)-B(1,2)*B(2,1))/DET
      RETURN
      END
!
      SUBROUTINE K4_INVAR(F, A, N, AINV, ZETA, CB)
!     enumerated invariants and ZETA of the deformation F
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), A(3,3), AINV(*), ZETA(*), CB(3,3), C2(3,3)
      DIMENSION AA(3), BB(3)
      INTEGER K4_I4, K4_Z
      CALL K4_DET3(F, AJ)
      CB = MATMUL(TRANSPOSE(F), F)*AJ**(-2.D0/3.D0)
      C2 = MATMUL(CB, CB)
      AINV(1) = CB(1,1) + CB(2,2) + CB(3,3)
      AINV(2) = 0.5D0*(AINV(1)**2 - C2(1,1) - C2(2,2) - C2(3,3))
      AINV(3) = AJ
      DO JB = 1, N
        DO IA = 1, JB
          AA = A(:,IA)
          BB = A(:,JB)
          AINV(K4_I4(IA,JB)) = DOT_PRODUCT(AA, MATMUL(CB,BB))
          AINV(K4_I4(IA,JB)+1) = DOT_PRODUCT(AA, MATMUL(C2,BB))
          IF (IA .LT. JB) ZETA(K4_Z(IA,JB)) = DOT_PRODUCT(AA,BB)
        ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K4_CALL(AINV, ZETA, N, PROPS, INCMP, UA, UI1, UI2, UI3)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION AINV(*), ZETA(*), PROPS(*), UA(2), UI1(*), UI2(*)
      DIMENSION UI3(*), STATEV(1), FIELDV(1), FIELDVINC(1)
      CHARACTER*80 CMNAME
      NINV = 3 + N*(N+1)
      CMNAME = 'HGO'
!     sentinel: the routine must define every output entry itself
      UA(1) = 7.7D77
      UA(2) = 7.7D77
      UI1(1:NINV) = 7.7D77
      UI2(1:NINV*(NINV+1)/2) = 7.7D77
      UI3(1:NINV*(NINV+1)/2) = 7.7D77
      CALL UANISOHYPER_INV(AINV, UA, ZETA, N, NINV, UI1, UI2, UI3,
     1  20.D0, 1, CMNAME, INCMP, 0, 0, STATEV, 0, FIELDV, FIELDVINC,
     2  6, PROPS)
      RETURN
      END
!
      SUBROUTINE K4_STRESS(F, A, N, PROPS, INCMP, SIG, U)
!     Cauchy stress from the first derivatives (what Abaqus does)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), A(3,3), PROPS(*), SIG(3,3)
      DIMENSION AINV(15), ZETA(3), UI1(15), UI2(120), UI3(120), UA(2)
      DIMENSION CB(3,3), C(3,3), CI(3,3), SB(3,3), S(3,3), AA(3), BB(3)
      DIMENSION CBA(3), CBB(3), EYE(3,3), TMP(3,3)
      INTEGER K4_I4
      EYE = 0.D0
      EYE(1,1) = 1.D0
      EYE(2,2) = 1.D0
      EYE(3,3) = 1.D0
      CALL K4_INVAR(F, A, N, AINV, ZETA, CB)
      CALL K4_CALL(AINV, ZETA, N, PROPS, INCMP, UA, UI1, UI2, UI3)
      U = UA(1)
      AJ = AINV(3)
      C = MATMUL(TRANSPOSE(F), F)
      CALL K4_INV3(C, CI)
      SB = UI1(1)*EYE + UI1(2)*(AINV(1)*EYE - CB)
      DO JB = 1, N
        DO IA = 1, JB
          AA = A(:,IA)
          BB = A(:,JB)
          CBA = MATMUL(CB,AA)
          CBB = MATMUL(CB,BB)
          N4 = K4_I4(IA,JB)
          DO I = 1, 3
            DO J = 1, 3
              SB(I,J) = SB(I,J)
     1          + 0.5D0*UI1(N4)*(AA(I)*BB(J)+AA(J)*BB(I))
     1          + 0.5D0*UI1(N4+1)*(AA(I)*CBB(J)+CBB(I)*AA(J)
     2                            +BB(I)*CBA(J)+CBA(I)*BB(J))
            ENDDO
          ENDDO
        ENDDO
      ENDDO
      SB = 2.D0*SB
      TR = 0.D0
      DO I = 1, 3
        DO J = 1, 3
          TR = TR + SB(I,J)*C(I,J)
        ENDDO
      ENDDO
      S = AJ**(-2.D0/3.D0)*(SB - TR/3.D0*CI) + AJ*UI1(3)*CI
      TMP = MATMUL(F, MATMUL(S, TRANSPOSE(F)))
      SIG = TMP/AJ
      RETURN
      END
!
      SUBROUTINE K4_FD(F, A, N, PROPS, ERR, H, K4IN)
!     finite-difference errors: ERR(1) UI1, ERR(2) UI2, ERR(3) UI3,
!     ERR(4) stress from UI1 against the derivative of U with respect
!     to F.  H is the step in the invariants.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), A(3,3), PROPS(*), ERR(4)
      DIMENSION AINV(15), ZETA(3), UA(2), UI1(15), UI2(120), UI3(120)
      DIMENSION AP(15), AM(15), UAP(2), UAM(2), U1P(15), U1M(15)
      DIMENSION U2P(120), U2M(120), U3(120), CB(3,3), SIG(3,3)
      DIMENSION FP(3,3), FM(3,3), P(3,3), SFD(3,3), FT(3,3)
      INTEGER K4_IX
      NINV = 3 + N*(N+1)
      NP = NINV*(NINV+1)/2
      CALL K4_INVAR(F, A, N, AINV, ZETA, CB)
      CALL K4_CALL(AINV, ZETA, N, PROPS, 0, UA, UI1, UI2, UI3)
      E1 = 0.D0
      E2 = 0.D0
      E3 = 0.D0
      S1 = 0.D0
      S2 = 0.D0
      S3 = 0.D0
      DO M = 1, NINV
        AP = AINV
        AM = AINV
        AP(M) = AP(M) + H
        AM(M) = AM(M) - H
        CALL K4_CALL(AP, ZETA, N, PROPS, 0, UAP, U1P, U2P, U3)
        CALL K4_CALL(AM, ZETA, N, PROPS, 0, UAM, U1M, U2M, U3)
        E1 = MAX(E1, ABS((UAP(1)-UAM(1))/(2.D0*H) - UI1(M)))
        S1 = MAX(S1, ABS(UI1(M)))
        DO L = 1, NINV
          E2 = MAX(E2, ABS((U1P(L)-U1M(L))/(2.D0*H) - UI2(K4_IX(L,M))))
        ENDDO
        IF (M .EQ. 3) THEN
          DO L = 1, NP
            E3 = MAX(E3, ABS((U2P(L)-U2M(L))/(2.D0*H) - UI3(L)))
          ENDDO
        ENDIF
      ENDDO
      DO L = 1, NP
        S2 = MAX(S2, ABS(UI2(L)))
        S3 = MAX(S3, ABS(UI3(L)))
      ENDDO
      ERR(1) = E1/S1
      ERR(2) = E2/S2
      ERR(3) = E3/S3
!     stress against dU/dF, sigma = (dU/dF) F^T / J
      HF = 1.D-6
      DO I = 1, 3
        DO J = 1, 3
          FP = F
          FM = F
          FP(I,J) = FP(I,J) + HF
          FM(I,J) = FM(I,J) - HF
          CALL K4_STRESS(FP, A, N, PROPS, 0, SIG, UP)
          CALL K4_STRESS(FM, A, N, PROPS, 0, SIG, UM)
          P(I,J) = (UP - UM)/(2.D0*HF)
        ENDDO
      ENDDO
      CALL K4_DET3(F, AJ)
      FT = TRANSPOSE(F)
      SFD = MATMUL(P, FT)/AJ
      CALL K4_STRESS(F, A, N, PROPS, 0, SIG, U)
      ERR(4) = MAXVAL(ABS(SFD - SIG))/MAXVAL(ABS(SIG))
      K4IN = 0
      RETURN
      END
!
      SUBROUTINE K4_T1(IU)
!     Example 4.5-1: finite-difference tests of the derivatives
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), F2(3,3), A(3,3), PR(6), AO(3,3), ERR(4), P2(6)
      DIMENSION AINV(15), ZETA(3), CB(3,3)
      COMMON /K4P/ PR, A, NFIB
      AO = 0.D0
      AO(1,1) = 1.D0
      AO(2,2) = 1.D0
      AO(3,3) = 1.D0
      F = RESHAPE((/1.30D0, 0.08D0, 0.04D0, 0.12D0, 0.95D0, 0.06D0,
     1   0.05D0, -0.10D0, 0.90D0/), (/3,3/))
      F2 = 0.D0
      F2(1,1) = 0.8D0
      F2(2,2) = 1.25D0
      F2(3,3) = 1.05D0
      WRITE(IU,'(A)') 'T1 finite-difference tests (H = 1e-6)'
!     case a: two oblique families, no coupling
      CALL K4_FD(F, A, 2, PR, ERR, 1.D-6, K)
      WRITE(IU,'(A,4ES10.2)') 'a  N=2 oblique        ', ERR
      CALL K4_INVAR(F, A, 2, AINV, ZETA, CB)
      WRITE(IU,'(A,9F9.4)') '   AINV a: ', AINV(1:9)
      WRITE(IU,'(A,F9.4)') '   ZETA12: ', ZETA(1)
      DO IA = 1, 2
        N4 = 4 + IA*(IA-1) + 2*(IA-1)
        E = PR(5)*(AINV(1)-3.D0) + (1.D0-3.D0*PR(5))*(AINV(N4)-1.D0)
        WRITE(IU,'(A,I2,F10.5)') '   E_alpha ', IA, E
      ENDDO
!     case b: three families with coupling
      P2 = PR
      P2(6) = 0.02D0
      CALL K4_FD(F, A, 3, P2, ERR, 1.D-6, K)
      WRITE(IU,'(A,4ES10.2)') 'b  N=3 coupling       ', ERR
!     case c: orthogonal families, family 1 slack
      CALL K4_FD(F2, AO, 3, P2, ERR, 1.D-6, K)
      WRITE(IU,'(A,4ES10.2)') 'c  N=3 one slack      ', ERR
      CALL K4_INVAR(F2, AO, 3, AINV, ZETA, CB)
      DO IA = 1, 3
        N4 = 4 + IA*(IA-1) + 2*(IA-1)
        E = PR(5)*(AINV(1)-3.D0) + (1.D0-3.D0*PR(5))*(AINV(N4)-1.D0)
        WRITE(IU,'(A,I2,F10.5)') '   E_alpha ', IA, E
      ENDDO
!     step scan for case a (Fig. 4.5-1)
      OPEN(11, FILE='../out/fdscan.dat')
      DO K = 1, 11
        H = 10.D0**(-K)
        CALL K4_FD(F, A, 2, PR, ERR, H, KK)
        WRITE(11,'(ES10.2,3ES12.3)') H, ERR(1), ERR(2), ERR(3)
      ENDDO
      CLOSE(11)
      RETURN
      END
!
      SUBROUTINE K4_UNI(LAM, IAX, A, N, PR, MODE, SIGAX, ST)
!     uniaxial stress along axis IAX.  MODE 0: incompressible (J = 1,
!     the two lateral stretches follow from s_pp = s_qq).  MODE 1:
!     compressible, equal lateral stretches with s_pp = 0.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), PR(*), ST(3), F(3,3), SIG(3,3)
      DOUBLE PRECISION LAM, K4_G
      IP = MOD(IAX,3) + 1
      IQ = MOD(IP,3) + 1
      XM0 = LAM**(-0.5D0)*0.97D0
      XM1 = LAM**(-0.5D0)*1.03D0
      DO IT = 1, 60
        G0 = K4_G(LAM, IAX, IP, IQ, XM0, A, N, PR, MODE)
        G1 = K4_G(LAM, IAX, IP, IQ, XM1, A, N, PR, MODE)
        IF (ABS(G1-G0) .LT. 1.D-300) EXIT
        XM2 = XM1 - G1*(XM1-XM0)/(G1-G0)
        XM0 = XM1
        XM1 = XM2
        IF (ABS(XM1-XM0) .LT. 1.D-15) EXIT
      ENDDO
      F = 0.D0
      F(IAX,IAX) = LAM
      F(IP,IP) = XM1
      IF (MODE .EQ. 0) THEN
        F(IQ,IQ) = 1.D0/(LAM*XM1)
      ELSE
        F(IQ,IQ) = XM1
      ENDIF
      CALL K4_STRESS(F, A, N, PR, 1-MODE, SIG, U)
      SIGAX = SIG(IAX,IAX) - SIG(IQ,IQ)
      IF (MODE .EQ. 1) SIGAX = SIG(IAX,IAX)
      ST(IAX) = LAM
      ST(IP) = F(IP,IP)
      ST(IQ) = F(IQ,IQ)
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION K4_G(LAM, IAX, IP, IQ, XM, A, N, PR,
     1                               MODE)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), PR(*), F(3,3), SIG(3,3)
      DOUBLE PRECISION LAM
      F = 0.D0
      F(IAX,IAX) = LAM
      F(IP,IP) = XM
      IF (MODE .EQ. 0) THEN
        F(IQ,IQ) = 1.D0/(LAM*XM)
      ELSE
        F(IQ,IQ) = XM
      ENDIF
      CALL K4_STRESS(F, A, N, PR, 1-MODE, SIG, U)
      IF (MODE .EQ. 0) THEN
        K4_G = SIG(IP,IP) - SIG(IQ,IQ)
      ELSE
        K4_G = SIG(IP,IP)
      ENDIF
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION K4_CF(LAM, PR, NF)
!     closed form: incompressible uniaxial stress along ONE fibre
!     family (NF = 1), or kappa = 1/3 with NF families of any direction
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PR(*)
      DOUBLE PRECISION LAM
      C10 = PR(1)
      XK1 = PR(3)
      XK2 = PR(4)
      XKAP = PR(5)
      B = LAM*LAM - 1.D0/LAM
      E = XKAP*(LAM*LAM + 2.D0/LAM - 3.D0)
     1  + (1.D0-3.D0*XKAP)*(LAM*LAM - 1.D0)
      IF (NF .LT. 0) THEN
!       isotropic limit kappa = 1/3, -NF families
        E = (LAM*LAM + 2.D0/LAM - 3.D0)/3.D0
        PE = 0.D0
        IF (E .GT. 0.D0) PE = XK1*E*EXP(XK2*E*E)
        K4_CF = 2.D0*B*(C10 + DBLE(-NF)*PE/3.D0)
        RETURN
      ENDIF
      PE = 0.D0
      IF (E .GT. 0.D0) PE = XK1*E*EXP(XK2*E*E)
      K4_CF = 2.D0*((C10 + XKAP*PE)*B + (1.D0-3.D0*XKAP)*PE*LAM*LAM)
      RETURN
      END
!
      SUBROUTINE K4_T2(IU)
!     uniaxial stress along the fibre, tension and compression
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), PR(6), AA(3,3), ST(3), P(6), AX(3,3)
      DIMENSION XL(8), XKS(3)
      DOUBLE PRECISION LAM, K4_CF
      DATA XL /0.8D0,0.9D0,1.1D0,1.2D0,1.3D0,1.4D0,1.5D0,1.6D0/
      DATA XKS /0.D0, 0.1D0, 0.3333333333333333D0/
      COMMON /K4P/ PR, A, NFIB
      AA = 0.D0
      AA(1,1) = 1.D0
      WRITE(IU,'(A)') 'T2 uniaxial along fibre (kappa = 0.1), N = 1'
      WRITE(IU,'(A)') '   lam      driver sigma     closed form     lat'
      DMAX = 0.D0
      DO K = 1, 8
        LAM = XL(K)
        CALL K4_UNI(LAM, 1, AA, 1, PR, 0, SIG, ST)
        CF = K4_CF(LAM, PR, 1)
        DMAX = MAX(DMAX, ABS(SIG-CF))
        WRITE(IU,'(F6.2,2F18.10,F10.5,ES10.2)') LAM, SIG, CF, ST(2),
     1    SIG-CF
      ENDDO
      WRITE(IU,'(A,ES10.2)') '   max |driver - closed| = ', DMAX
!     scan for the figure: along (A=e1) and across (A=e2), 3 kappas
      OPEN(12, FILE='../out/scan.dat')
      DO K = 0, 45
        LAM = 0.7D0 + 0.02D0*K
        WRITE(12,'(F6.3)', ADVANCE='NO') LAM
        DO IK = 1, 3
          P = PR
          P(5) = XKS(IK)
          CALL K4_UNI(LAM, 1, AA, 1, P, 0, S1, ST)
          AX = 0.D0
          AX(2,1) = 1.D0
          CALL K4_UNI(LAM, 1, AX, 1, P, 0, S2, ST)
          WRITE(12,'(2ES16.8)', ADVANCE='NO') S1, S2
        ENDDO
        WRITE(12,*)
      ENDDO
      CLOSE(12)
      RETURN
      END
!
      SUBROUTINE K4_T3(IU)
!     compressible limit of the along-fibre test
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), PR(6), AA(3,3), ST(3), P(6)
      DOUBLE PRECISION LAM, K4_CF
      COMMON /K4P/ PR, A, NFIB
      AA = 0.D0
      AA(1,1) = 1.D0
      LAM = 1.3D0
      CF = K4_CF(LAM, PR, 1)
      WRITE(IU,'(A,F14.8)') 'T3 compressible, lam = 1.3, closed(inc) ',
     1   CF
      DO K = 1, 4
        P = PR
        P(2) = 10.D0**(-K-1)
        CALL K4_UNI(LAM, 1, AA, 1, P, 1, SIG, ST)
        WRITE(IU,'(A,ES9.1,F14.8,ES11.2,F12.8)') '   D = ', P(2), SIG,
     1    (SIG-CF)/CF, ST(2)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K4_T4(IU)
!     uniaxial stress across the fibre (fibre along 2, load along 1)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), PR(6), AX(3,3), ST(3), P(6), XKS(3), XL(3)
      DOUBLE PRECISION LAM
      DATA XKS /0.D0, 0.1D0, 0.2D0/
      DATA XL /1.2D0, 1.4D0, 1.6D0/
      COMMON /K4P/ PR, A, NFIB
      AX = 0.D0
      AX(2,1) = 1.D0
      WRITE(IU,'(A)') 'T4 across the fibre: kappa lam sigma NH mu'
      DO IK = 1, 3
        DO IL = 1, 3
          P = PR
          P(5) = XKS(IK)
          LAM = XL(IL)
          CALL K4_UNI(LAM, 1, AX, 1, P, 0, SIG, ST)
          ANH = 2.D0*P(1)*(LAM*LAM - 1.D0/LAM)
          WRITE(IU,'(F5.2,F6.2,2F16.10,F11.6)') P(5), LAM, SIG, ANH,
     1      ST(2)
        ENDDO
      ENDDO
!     compression along the fibre axis, fibre along 1, load along 1
      RETURN
      END
!
      SUBROUTINE K4_T5(IU)
!     isotropic limit kappa = 1/3, N = 2 fibres along 1 and 2
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), PR(6), AO(3,3), ST(3), P(6), XL(3)
      DOUBLE PRECISION LAM, K4_CF
      DATA XL /1.2D0, 1.4D0, 1.6D0/
      COMMON /K4P/ PR, A, NFIB
      AO = 0.D0
      AO(1,1) = 1.D0
      AO(2,2) = 1.D0
      AO(3,3) = 1.D0
      P = PR
      P(5) = 1.D0/3.D0
      WRITE(IU,'(A)') 'T5 kappa = 1/3, N=2: lam, s(axis1), s(axis3), CF'
      DO IL = 1, 3
        LAM = XL(IL)
        CALL K4_UNI(LAM, 1, AO, 2, P, 0, S1, ST)
        CALL K4_UNI(LAM, 3, AO, 2, P, 0, S3, ST)
        CF = K4_CF(LAM, P, -2)
        WRITE(IU,'(F6.2,3F16.10)') LAM, S1, S3, CF
      ENDDO
      RETURN
      END
!
      SUBROUTINE K4_CALLE(EB, AJ, NT, PROPS, INCMP, UA, D1, D2, D3)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION EB(*), PROPS(*), UA(2), D1(*), D2(*), D3(*)
      DIMENSION STATEV(1), FIELDV(1), FIELDVINC(1)
      CHARACTER*80 CMNAME
      CMNAME = 'HGOE'
      CALL UANISOHYPER_STRAIN(EB, AJ, UA, D1, D2, D3, 20.D0, 1,
     1  CMNAME, INCMP, 0, 3, NT-3, NT, 0, STATEV, 0, FIELDV,
     2  FIELDVINC, 6, PROPS)
      RETURN
      END
!
      SUBROUTINE K4_EBAR(F, EB, AJ)
!     modified Green strain, order 11 22 33 12 13 23
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), EB(6), CB(3,3), AINV(15), ZETA(3), AA(3,3)
      AA = 0.D0
      CALL K4_INVAR(F, AA, 0, AINV, ZETA, CB)
      AJ = AINV(3)
      EB(1) = 0.5D0*(CB(1,1)-1.D0)
      EB(2) = 0.5D0*(CB(2,2)-1.D0)
      EB(3) = 0.5D0*(CB(3,3)-1.D0)
      EB(4) = 0.5D0*CB(1,2)
      EB(5) = 0.5D0*CB(1,3)
      EB(6) = 0.5D0*CB(2,3)
      RETURN
      END
!
      SUBROUTINE K4_STRESSE(F, PROPS, SIG, U)
!     Cauchy stress from the strain-form derivatives
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), PROPS(*), SIG(3,3), EB(6), D1(7), D2(28)
      DIMENSION D3(28), UA(2), C(3,3), CI(3,3), SB(3,3), S(3,3)
      CALL K4_EBAR(F, EB, AJ)
      CALL K4_CALLE(EB, AJ, 6, PROPS, 0, UA, D1, D2, D3)
      U = UA(1)
      C = MATMUL(TRANSPOSE(F), F)
      CALL K4_INV3(C, CI)
!     dU/dEbar_ij of an off-diagonal pair is shared by (i,j) and (j,i)
      SB(1,1) = D1(1)
      SB(2,2) = D1(2)
      SB(3,3) = D1(3)
      SB(1,2) = 0.5D0*D1(4)
      SB(1,3) = 0.5D0*D1(5)
      SB(2,3) = 0.5D0*D1(6)
      SB(2,1) = SB(1,2)
      SB(3,1) = SB(1,3)
      SB(3,2) = SB(2,3)
      TR = SUM(SB*C)
      S = AJ**(-2.D0/3.D0)*(SB - TR/3.D0*CI) + AJ*D1(7)*CI
      SIG = MATMUL(F, MATMUL(S, TRANSPOSE(F)))/AJ
      RETURN
      END
!
      SUBROUTINE K4_T6(IU)
!     strain form against invariant form; Explicit against Standard
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), PR(6), AO(3,3), F(3,3), FS(3,3,4), P2(6), PQ(6)
      DIMENSION SIG(3,3), SIGE(3,3), EB(6), D1(7), D2(28), D3(28)
      DIMENSION UA(2), UAP(2), UAM(2), EP(6), EM(6), D1P(7), D1M(7), D2P(28), D2M(28), D3S(28)
      DIMENSION AINV(15), ZETA(3), CB(3,3), U1(15), U2(120), U3(120)
      DIMENSION SINV(4,9), ZET(4,1), UDEV(4), DUDI(4,9), D2I(4,45)
      DIMENSION TO(4), TN(4), FO(4,1), FN(4,1), SO(4,1), SNW(4,1)
      DIMENSION EBK(4,6), DETU(4), UDV(4), DUDE(4,6), DUDJ(4)
      DIMENSION D2E(4,21), D2JJ(4), D2EJ(4,6), JEL(4)
      CHARACTER*80 CMN
      INTEGER K4_IX
      COMMON /K4P/ PR, A, NFIB
      AO = 0.D0
      AO(1,1) = 1.D0
      AO(2,2) = 1.D0
      AO(3,3) = 1.D0
      F = RESHAPE((/1.25D0, 0.06D0, 0.03D0, 0.10D0, 1.15D0, 0.05D0,
     1   0.04D0, -0.08D0, 0.70D0/), (/3,3/))
      CALL K4_DET3(F, DETF)
      F = F*(1.02D0/DETF)**(1.D0/3.D0)
      PQ = PR
      PQ(2) = 0.01D0
      P2 = PQ
      P2(6) = 2.D0
!     energy and stress, both forms (two orthogonal families)
      CALL K4_STRESS(F, AO, 2, PQ, 0, SIG, U1X)
      CALL K4_STRESSE(F, P2, SIGE, U2X)
      CALL K4_EBAR(F, EB, AJ)
      WRITE(IU,'(A)') 'T6 strain form against invariant form'
      WRITE(IU,'(A,F8.5,A,2F8.5)') '   J = ', AJ, '   E_alpha 1, 2 =',
     1  2.D0*(PQ(5)*(EB(1)+EB(2)+EB(3)) + (1.D0-3.D0*PQ(5))*EB(1)),
     2  2.D0*(PQ(5)*(EB(1)+EB(2)+EB(3)) + (1.D0-3.D0*PQ(5))*EB(2))
      WRITE(IU,'(A,2F18.12)') '   U inv, U strain ', U1X, U2X
      WRITE(IU,'(A,ES10.2)') '   |U diff| ', ABS(U1X-U2X)
      WRITE(IU,'(A,ES10.2)') '   max |sigma diff| ', MAXVAL(ABS(SIG-SIGE))
      WRITE(IU,'(A,ES10.2)') '   max |sigma diff|/max|sigma| ',
     1   MAXVAL(ABS(SIG-SIGE))/MAXVAL(ABS(SIG))
      WRITE(IU,'(A,3F14.9)') '   sigma_inv row 1 ', SIG(1,:)
      WRITE(IU,'(A,3F14.9)') '   sigma_str row 1 ', SIGE(1,:)
!     finite differences of DU1, DU2, DU3
      CALL K4_EBAR(F, EB, AJ)
      CALL K4_CALLE(EB, AJ, 6, P2, 0, UA, D1, D2, D3)
      H = 1.D-6
      E1 = 0.D0
      E2 = 0.D0
      E3 = 0.D0
      DO M = 1, 7
        EP = EB
        EM = EB
        AJP = AJ
        AJM = AJ
        IF (M .LE. 6) THEN
          EP(M) = EP(M) + H
          EM(M) = EM(M) - H
        ELSE
          AJP = AJ + H
          AJM = AJ - H
        ENDIF
        CALL K4_CALLE(EP, AJP, 6, P2, 0, UAP, D1P, D2P, D3S)
        UAPP = UAP(1)
        CALL K4_CALLE(EM, AJM, 6, P2, 0, UAM, D1M, D2M, D3S)
        E1 = MAX(E1, ABS((UAPP-UAM(1))/(2.D0*H) - D1(M)))
        DO L = 1, 7
          E2 = MAX(E2, ABS((D1P(L)-D1M(L))/(2.D0*H) - D2(K4_IX(L,M))))
        ENDDO
        IF (M .EQ. 7) THEN
          DO L = 1, 28
            E3 = MAX(E3, ABS((D2P(L)-D2M(L))/(2.D0*H) - D3(L)))
          ENDDO
        ENDIF
      ENDDO
      WRITE(IU,'(A,3ES10.2)') '   FD errors DU1 DU2 DU3 (rel) ',
     1  E1/MAXVAL(ABS(D1)), E2/MAXVAL(ABS(D2)), E3/MAXVAL(ABS(D3))
!     Explicit blocks: four material points
      FS = 0.D0
      DO K = 1, 4
        FS(1,1,K) = 1.D0 + 0.1D0*K
        FS(2,2,K) = 1.D0 - 0.03D0*K
        FS(3,3,K) = 1.D0/(FS(1,1,K)*FS(2,2,K))*(1.D0+0.02D0*K)
        FS(1,2,K) = 0.05D0*K
        CALL K4_INVAR(FS(:,:,K), A, 2, AINV, ZETA, CB)
        SINV(K,1:9) = AINV(1:9)
        ZET(K,1) = ZETA(1)
        CALL K4_EBAR(FS(:,:,K), EB, AJ)
        EBK(K,:) = EB
        DETU(K) = AJ
      ENDDO
      CMN = 'HGO'
      CALL VUANISOHYPER_INV(4, 2, 9, JEL, 1, 1, 1, CMN, 0, 0, 6, PQ,
     1  TO, TN, FO, FN, SO, SINV, ZET, UDEV, DUDI, D2I, SNW)
      DM1 = 0.D0
      DM2 = 0.D0
      DO K = 1, 4
        AINV(1:9) = SINV(K,1:9)
        CALL K4_CALL(AINV, ZET(K,1), 2, PQ, 0, UA, U1, U2, U3)
        DM1 = MAX(DM1, ABS(UDEV(K)-UA(2)))
        DO N = 1, 9
          DM1 = MAX(DM1, ABS(DUDI(K,N)-U1(N)))
        ENDDO
        DO N = 1, 45
          DM2 = MAX(DM2, ABS(D2I(K,N)-U2(N)))
        ENDDO
      ENDDO
      WRITE(IU,'(A,2ES10.2)') 'T6 VUANISOHYPER_INV vs standard ',
     1  DM1, DM2
      CALL VUANISOHYPER_STRAIN(4, JEL, 1, 1, 1, CMN, 3, 3, 0, 0, 6,
     1  P2, TO, TN, FO, FN, SO, EBK, DETU, UDV, DUDE, DUDJ, D2E, D2JJ,
     2  D2EJ, SNW)
      DM1 = 0.D0
      DM2 = 0.D0
      DO K = 1, 4
        CALL K4_CALLE(EBK(K,:), DETU(K), 6, P2, 0, UA, D1, D2, D3)
        DM1 = MAX(DM1, ABS(UDV(K)-UA(2)), ABS(DUDJ(K)-D1(7)),
     1           ABS(D2JJ(K)-D2(28)))
        DO N = 1, 6
          DM1 = MAX(DM1, ABS(DUDE(K,N)-D1(N)),
     1              ABS(D2EJ(K,N)-D2(K4_IX(N,7))))
        ENDDO
        DO N = 1, 21
          DM2 = MAX(DM2, ABS(D2E(K,N)-D2(N)))
        ENDDO
      ENDDO
      WRITE(IU,'(A,2ES10.2)') 'T6 VUANISOHYPER_STRAIN vs standard ',
     1  DM1, DM2
      WRITE(IU,'(A,I3,A,I3)') '   packed length 9x9: ', 45,
     1  ';  7x7: ', 28
      RETURN
      END
!
      SUBROUTINE K4_T7(IU)
!     stress and energy at a general F, for comparison outside Fortran
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3), A(3,3), PR(6), P2(6), SIG(3,3)
      COMMON /K4P/ PR, A, NFIB
      F = RESHAPE((/1.30D0, 0.08D0, 0.04D0, 0.12D0, 0.95D0, 0.06D0,
     1   0.05D0, -0.10D0, 0.90D0/), (/3,3/))
      CALL K4_DET3(F, DETF)
      F = F*(1.02D0/DETF)**(1.D0/3.D0)
      PR(2) = 0.01D0
      P2 = PR
      P2(6) = 0.02D0
      CALL K4_STRESS(F, A, 3, P2, 0, SIG, U)
      WRITE(IU,'(A,ES24.15)') 'T7 U(N=3, cc=0.02) ', U
      DO I = 1, 3
        WRITE(IU,'(A,3ES24.15)') 'T7 sig ', SIG(I,:)
      ENDDO
      CALL K4_STRESS(F, A, 2, PR, 0, SIG, U)
      WRITE(IU,'(A,ES24.15)') 'T7 U(N=2) ', U
      DO I = 1, 3
        WRITE(IU,'(A,3ES24.15)') 'T7 sig ', SIG(I,:)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K4_T8(IU)
!     effect of the dispersion parameter, lam = 1.4 and 1.6
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3), PR(6), AA(3,3), AX(3,3), ST(3), P(6), XKS(4)
      DOUBLE PRECISION LAM
      DATA XKS /0.D0, 0.1D0, 0.2D0, 0.3333333333333333D0/
      COMMON /K4P/ PR, A, NFIB
      AA = 0.D0
      AA(1,1) = 1.D0
      AX = 0.D0
      AX(2,1) = 1.D0
      WRITE(IU,'(A)') 'T8 kappa, lam, along, across, mu_across'
      DO IL = 1, 2
        LAM = 1.2D0 + 0.2D0*IL
        DO IK = 1, 4
          P = PR
          P(5) = XKS(IK)
          CALL K4_UNI(LAM, 1, AA, 1, P, 0, S1, ST)
          CALL K4_UNI(LAM, 1, AX, 1, P, 0, S2, ST)
          WRITE(IU,'(A,F6.3,F6.2,2F14.8,F10.5)') 'T8 ', P(5), LAM, S1,
     1      S2, ST(2)
        ENDDO
      ENDDO
      RETURN
      END
