!     HGO-type anisotropic hyperelastic material, user formulation
!     (Abaqus 2024).  Invariant form: UANISOHYPER_INV, VUANISOHYPER_INV.
!     Strain form: UANISOHYPER_STRAIN, VUANISOHYPER_STRAIN.
!
!     PROPS(1) C10    MPa        matrix shear parameter (mu0 = 2 C10)
!     PROPS(2) D      1/MPa      compressibility (K0 = 2/D), used when
!                                INCMPFLAG = 0 and in Abaqus/Explicit
!     PROPS(3) k1     MPa        fibre stiffness
!     PROPS(4) k2     -          fibre exponent
!     PROPS(5) kappa  -          dispersion, 0 <= kappa <= 1/3
!     PROPS(6) cc     MPa        fibre-fibre coupling (invariant form),
!                                or number of fibre families on the
!                                local axes 1, 2 (strain form)
!
!     ---------- index functions of the packed storage ----------
      INTEGER FUNCTION K4_IX(I,J)
!     position of the pair (I,J) in the packed upper triangle
      II = MIN(I,J)
      JJ = MAX(I,J)
      K4_IX = II + JJ*(JJ-1)/2
      RETURN
      END
!
      INTEGER FUNCTION K4_I4(I,J)
!     enumerated position of the invariant I4(I,J)
      II = MIN(I,J)
      JJ = MAX(I,J)
      K4_I4 = 4 + JJ*(JJ-1) + 2*(II-1)
      RETURN
      END
!
      INTEGER FUNCTION K4_Z(I,J)
!     enumerated position of ZETA(I,J), I /= J (assumed order 12,13,23)
      II = MIN(I,J)
      JJ = MAX(I,J)
      K4_Z = II + (JJ-1)*(JJ-2)/2
      RETURN
      END
!
!     ---------- the energy kernel, shared by Standard and Explicit ----
      SUBROUTINE K4_HGO(AINV,ZETA,NFIB,NINV,PROPS,INCMP,
     1                  UA,UI1,UI2,UI3)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION AINV(NINV), ZETA(*), PROPS(*), UA(2), UI1(NINV)
      DIMENSION UI2(NINV*(NINV+1)/2), UI3(NINV*(NINV+1)/2)
      INTEGER K4_IX, K4_I4, K4_Z
      PARAMETER (ZERO=0.D0, ONE=1.D0, TWO=2.D0, THREE=3.D0)
      C10 = PROPS(1)
      XK1 = PROPS(3)
      XK2 = PROPS(4)
      XKAP = PROPS(5)
      CC = PROPS(6)
      AJ = AINV(3)
      DO N = 1, NINV
        UI1(N) = ZERO
      ENDDO
      DO N = 1, NINV*(NINV+1)/2
        UI2(N) = ZERO
        UI3(N) = ZERO
      ENDDO
!     isochoric matrix: C10 (I1 - 3)
      UA(2) = C10*(AINV(1) - THREE)
      UI1(1) = C10
!     fibres: tension only, Macaulay bracket on E_alpha
      DO IA = 1, NFIB
        N4 = K4_I4(IA,IA)
        E = XKAP*(AINV(1) - THREE)
     1    + (ONE - THREE*XKAP)*(AINV(N4) - ONE)
        IF (E .GT. ZERO) THEN
          EX = EXP(XK2*E*E)
          D1 = XKAP
          D4 = ONE - THREE*XKAP
          UA(2) = UA(2) + XK1/(TWO*XK2)*(EX - ONE)
          PE = XK1*E*EX
          PEE = XK1*(ONE + TWO*XK2*E*E)*EX
          UI1(1) = UI1(1) + PE*D1
          UI1(N4) = UI1(N4) + PE*D4
          UI2(K4_IX(1,1)) = UI2(K4_IX(1,1)) + PEE*D1*D1
          UI2(K4_IX(1,N4)) = UI2(K4_IX(1,N4)) + PEE*D1*D4
          UI2(K4_IX(N4,N4)) = UI2(K4_IX(N4,N4)) + PEE*D4*D4
        ENDIF
      ENDDO
!     coupling of two families: (cc/2) (I4(a,b) - zeta(a,b))**2
      IF (CC .NE. ZERO) THEN
        DO IB = 2, NFIB
          DO IA = 1, IB-1
            N4 = K4_I4(IA,IB)
            DZ = AINV(N4) - ZETA(K4_Z(IA,IB))
            UA(2) = UA(2) + CC*DZ*DZ/TWO
            UI1(N4) = UI1(N4) + CC*DZ
            UI2(K4_IX(N4,N4)) = UI2(K4_IX(N4,N4)) + CC
          ENDDO
        ENDDO
      ENDIF
!     volumetric part, compressible material only
      UA(1) = UA(2)
      IF (INCMP .EQ. 0) THEN
        D = PROPS(2)
        UA(1) = UA(1) + ((AJ*AJ - ONE)/TWO - LOG(AJ))/D
        UI1(3) = (AJ - ONE/AJ)/D
        UI2(K4_IX(3,3)) = (ONE + ONE/(AJ*AJ))/D
        UI3(K4_IX(3,3)) = -TWO/(D*AJ**3)
      ENDIF
      RETURN
      END
!
      SUBROUTINE UANISOHYPER_INV (AINV, UA, ZETA, NFIBERS, NINV,
     1 UI1, UI2, UI3, TEMP, NOEL, CMNAME, INCMPFLAG, IHYBFLAG,
     2 NUMSTATEV, STATEV, NUMFIELDV, FIELDV, FIELDVINC,
     3 NUMPROPS, PROPS)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION AINV(NINV), UA(2), ZETA(NFIBERS*(NFIBERS-1)/2)
      DIMENSION UI1(NINV), UI2(NINV*(NINV+1)/2)
      DIMENSION UI3(NINV*(NINV+1)/2)
      DIMENSION STATEV(NUMSTATEV), FIELDV(NUMFIELDV)
      DIMENSION FIELDVINC(NUMFIELDV), PROPS(NUMPROPS)
      IF (NFIBERS .GT. 3) CALL XIT
      CALL K4_HGO(AINV, ZETA, NFIBERS, NINV, PROPS, INCMPFLAG,
     1            UA, UI1, UI2, UI3)
      RETURN
      END
!
!     ---------- strain form: energy in the modified Green strain ------
      SUBROUTINE K4_HGOE(EBAR,AJ,NDI,NTENS,PROPS,INCMP,
     1                   UA,DU1,DU2,DU3)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION EBAR(NTENS), PROPS(*), UA(2), DU1(NTENS+1)
      DIMENSION DU2((NTENS+1)*(NTENS+2)/2)
      DIMENSION DU3((NTENS+1)*(NTENS+2)/2)
      DIMENSION DE(6)
      INTEGER K4_IX
      PARAMETER (ZERO=0.D0, ONE=1.D0, TWO=2.D0, THREE=3.D0)
      C10 = PROPS(1)
      XK1 = PROPS(3)
      XK2 = PROPS(4)
      XKAP = PROPS(5)
      NFIB = NINT(PROPS(6))
      NJ = NTENS + 1
      DO N = 1, NJ
        DU1(N) = ZERO
      ENDDO
      DO N = 1, NJ*(NJ+1)/2
        DU2(N) = ZERO
        DU3(N) = ZERO
      ENDDO
      TR = ZERO
      DO N = 1, NDI
        TR = TR + EBAR(N)
        DU1(N) = TWO*C10
      ENDDO
      UA(2) = TWO*C10*TR
      DO IA = 1, MIN(NFIB,NDI)
!       E_alpha = 2 kappa tr(Ebar)
!               + 2 (1 - 3 kappa) Ebar(alpha,alpha)
        E = TWO*XKAP*TR + TWO*(ONE - THREE*XKAP)*EBAR(IA)
        IF (E .GT. ZERO) THEN
          EX = EXP(XK2*E*E)
          PE = XK1*E*EX
          PEE = XK1*(ONE + TWO*XK2*E*E)*EX
          DO N = 1, NDI
            DE(N) = TWO*XKAP
          ENDDO
          DE(IA) = DE(IA) + TWO*(ONE - THREE*XKAP)
          UA(2) = UA(2) + XK1/(TWO*XK2)*(EX - ONE)
          DO N = 1, NDI
            DU1(N) = DU1(N) + PE*DE(N)
            DO M = 1, N
              DU2(K4_IX(M,N)) = DU2(K4_IX(M,N)) + PEE*DE(M)*DE(N)
            ENDDO
          ENDDO
        ENDIF
      ENDDO
      UA(1) = UA(2)
      IF (INCMP .EQ. 0) THEN
        D = PROPS(2)
        UA(1) = UA(1) + ((AJ*AJ - ONE)/TWO - LOG(AJ))/D
        DU1(NJ) = (AJ - ONE/AJ)/D
        DU2(K4_IX(NJ,NJ)) = (ONE + ONE/(AJ*AJ))/D
        DU3(K4_IX(NJ,NJ)) = -TWO/(D*AJ**3)
      ENDIF
      RETURN
      END
!
      SUBROUTINE UANISOHYPER_STRAIN (EBAR, AJ, UA, DU1, DU2, DU3,
     1 TEMP, NOEL, CMNAME, INCMPFLAG, IHYBFLAG, NDI, NSHR, NTENS,
     2 NUMSTATEV, STATEV, NUMFIELDV, FIELDV, FIELDVINC,
     3 NUMPROPS, PROPS)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION EBAR(NTENS), UA(2), DU1(NTENS+1)
      DIMENSION DU2((NTENS+1)*(NTENS+2)/2)
      DIMENSION DU3((NTENS+1)*(NTENS+2)/2)
      DIMENSION STATEV(NUMSTATEV), FIELDV(NUMFIELDV)
      DIMENSION FIELDVINC(NUMFIELDV), PROPS(NUMPROPS)
      CALL K4_HGOE(EBAR, AJ, NDI, NTENS, PROPS, INCMPFLAG,
     1             UA, DU1, DU2, DU3)
      RETURN
      END
!
!     ---------- Abaqus/Explicit: blocks of material points -----------
      SUBROUTINE VUANISOHYPER_INV (NBLOCK, NFIBER, NINV,
     1 JELEM, KINTPT, KLAYER, KSECPT, CMNAME,
     2 NSTATEV, NFIELDV, NPROPS, PROPS, TEMPOLD, TEMPNEW,
     3 FIELDOLD, FIELDNEW, STATEOLD, SINVARIANT, ZETA,
     4 UDEV, DUDI, D2UDIDI, STATENEW)
      INCLUDE 'VABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION JELEM(NBLOCK), PROPS(NPROPS), TEMPOLD(NBLOCK)
      DIMENSION TEMPNEW(NBLOCK), FIELDOLD(NBLOCK,NFIELDV)
      DIMENSION FIELDNEW(NBLOCK,NFIELDV), STATEOLD(NBLOCK,NSTATEV)
      DIMENSION SINVARIANT(NBLOCK,NINV)
      DIMENSION ZETA(NBLOCK,NFIBER*(NFIBER-1)/2), UDEV(NBLOCK)
      DIMENSION DUDI(NBLOCK,NINV), D2UDIDI(NBLOCK,NINV*(NINV+1)/2)
      DIMENSION STATENEW(NBLOCK,NSTATEV)
      DIMENSION AI(15), ZE(3), U1(15), U2(120), U3(120), UA(2)
      DO K = 1, NBLOCK
        DO N = 1, NINV
          AI(N) = SINVARIANT(K,N)
        ENDDO
        DO N = 1, NFIBER*(NFIBER-1)/2
          ZE(N) = ZETA(K,N)
        ENDDO
        CALL K4_HGO(AI, ZE, NFIBER, NINV, PROPS, 0,
     1              UA, U1, U2, U3)
        UDEV(K) = UA(2)
        DO N = 1, NINV
          DUDI(K,N) = U1(N)
        ENDDO
        DO N = 1, NINV*(NINV+1)/2
          D2UDIDI(K,N) = U2(N)
        ENDDO
        DO N = 1, NSTATEV
          STATENEW(K,N) = STATEOLD(K,N)
        ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE VUANISOHYPER_STRAIN (NBLOCK, JELEM, KINTPT, KLAYER,
     1 KSECPT, CMNAME, NDIR, NSHR, NSTATEV, NFIELDV, NPROPS, PROPS,
     2 TEMPOLD, TEMPNEW, FIELDOLD, FIELDNEW, STATEOLD, EBAR, DETU,
     3 UDEV, DUDE, DUDJ, D2UDEDE, D2UDJDJ, D2UDEDJ, STATENEW)
      INCLUDE 'VABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION JELEM(NBLOCK), PROPS(NPROPS), TEMPOLD(NBLOCK)
      DIMENSION TEMPNEW(NBLOCK), FIELDOLD(NBLOCK,NFIELDV)
      DIMENSION FIELDNEW(NBLOCK,NFIELDV), STATEOLD(NBLOCK,NSTATEV)
      DIMENSION EBAR(NBLOCK,NDIR+NSHR), DETU(NBLOCK), UDEV(NBLOCK)
      DIMENSION DUDE(NBLOCK,NDIR+NSHR), DUDJ(NBLOCK)
      DIMENSION D2UDEDE(NBLOCK,(NDIR+NSHR)*(NDIR+NSHR+1)/2)
      DIMENSION D2UDJDJ(NBLOCK), D2UDEDJ(NBLOCK,NDIR+NSHR)
      DIMENSION STATENEW(NBLOCK,NSTATEV)
      DIMENSION EB(6), D1(7), D2(28), D3(28), UA(2)
      NT = NDIR + NSHR
      NJ = NT + 1
      DO K = 1, NBLOCK
        DO N = 1, NT
          EB(N) = EBAR(K,N)
        ENDDO
        CALL K4_HGOE(EB, DETU(K), NDIR, NT, PROPS, 0,
     1               UA, D1, D2, D3)
        UDEV(K) = UA(2)
        DUDJ(K) = D1(NJ)
        D2UDJDJ(K) = D2(NJ*(NJ+1)/2)
        DO N = 1, NT
          DUDE(K,N) = D1(N)
          D2UDEDJ(K,N) = D2(N + NT*NJ/2)
        ENDDO
        DO N = 1, NT*(NT+1)/2
          D2UDEDE(K,N) = D2(N)
        ENDDO
        DO N = 1, NSTATEV
          STATENEW(K,N) = STATEOLD(K,N)
        ENDDO
      ENDDO
      RETURN
      END
