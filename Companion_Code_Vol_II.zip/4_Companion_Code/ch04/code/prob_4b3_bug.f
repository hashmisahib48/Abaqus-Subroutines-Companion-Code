      SUBROUTINE UANISOHYPER_INV (AINV, UA, ZETA, NFIBERS, NINV,
     1 UI1, UI2, UI3, TEMP, NOEL, CMNAME, INCMPFLAG, IHYBFLAG,
     2 NUMSTATEV, STATEV, NUMFIELDV, FIELDV, FIELDVINC,
     3 NUMPROPS, PROPS)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME
      DIMENSION AINV(NINV), UA(2), ZETA(*), UI1(NINV)
      DIMENSION UI2(NINV*(NINV+1)/2), UI3(NINV*(NINV+1)/2)
      DIMENSION STATEV(*), FIELDV(*), FIELDVINC(*), PROPS(*)
      C10 = PROPS(1)
      D = PROPS(2)
      XK1 = PROPS(3)
      XK2 = PROPS(4)
      XKAP = PROPS(5)
      AJ = AINV(3)
      UA(2) = C10*(AINV(1) - 3.D0)
      UI1(1) = C10
      DO IA = 1, NFIBERS
        N4 = 4 + 2*(IA - 1)
        E = (1.D0 - 3.D0*XKAP)*(AINV(1) - 3.D0)
     1    + XKAP*(AINV(N4) - 1.D0)
        EX = EXP(XK2*E*E)
        UA(2) = UA(2) + XK1/(2.D0*XK2)*(EX - 1.D0)
        PE = XK1*E*EX
        PEE = XK1*(1.D0 + 2.D0*XK2*E*E)*EX
        UI1(1) = UI1(1) + PE*(1.D0 - 3.D0*XKAP)
        UI1(N4) = UI1(N4) + PE*XKAP
        UI2(1) = UI2(1) + PEE*(1.D0 - 3.D0*XKAP)**2
        K = (N4-1)*NINV - (N4-1)*(N4-2)/2 + 1
        UI2(K) = UI2(K) + PEE*XKAP**2
      ENDDO
      UA(1) = UA(2) + ((AJ*AJ - 1.D0)/2.D0 - LOG(AJ))/D
      UI2(6) = (1.D0 + 1.D0/(AJ*AJ))/D
      RETURN
      END
