"""Independent reference for Chapter 4: HGO energy as an explicit function of F,
stress by complex-step differentiation (no use of invariant derivatives), closed forms."""
import numpy as np, re, sys
C10,D,K1,K2,KAP=0.01,1e-4,0.02,2.0,0.1
def U(F,fibres,p,cc=0.0):
    C10,D,K1,K2,KAP=p
    J=F[0,0]*(F[1,1]*F[2,2]-F[1,2]*F[2,1])-F[0,1]*(F[1,0]*F[2,2]-F[1,2]*F[2,0])+F[0,2]*(F[1,0]*F[2,1]-F[1,1]*F[2,0])
    C=F.T@F; Cb=C*J**(-2/3); I1=np.trace(Cb)
    u=C10*(I1-3)+((J*J-1)/2-np.log(J))/D
    for a in fibres:
        E=KAP*(I1-3)+(1-3*KAP)*(a@Cb@a-1)
        if E.real>0: u+=K1/(2*K2)*(np.exp(K2*E*E)-1)
    for i in range(len(fibres)):
        for j in range(i):
            z=fibres[i]@fibres[j]; u+=cc/2*(fibres[j]@Cb@fibres[i]-z)**2
    return u
def cauchy(F,fibres,p,cc=0.0):
    h=1e-30; P=np.zeros((3,3))
    for i in range(3):
        for j in range(3):
            Fc=F.astype(complex); Fc[i,j]+=1j*h
            P[i,j]=U(Fc,fibres,p,cc).imag/h
    J=np.linalg.det(F); return P@F.T/J
def Fgen():
    F=np.array([[1.30,0.12,0.05],[0.08,0.95,-0.10],[0.04,0.06,0.90]])
    return F
if __name__=='__main__':
    p=(0.01,0.01,0.02,2.0,0.1)
    g=np.radians(40); a1=np.array([np.cos(g),np.sin(g),0]); a2=np.array([np.cos(g),-np.sin(g),0]); a3=np.array([0,0,1.0])
    F=Fgen(); F=F*(1.02/np.linalg.det(F))**(1/3)
    for name,fib,cc in (('N=3 cc=0.02',[a1,a2,a3],0.02),('N=2',[a1,a2],0.0)):
        print(name,'U=%.15e'%U(F,fib,p,cc).real); s=cauchy(F,fib,p,cc)
        for r in s: print('  sig',' '.join('%.15e'%x for x in r))
    # fortran output
    txt=open('../out/k4_main.txt').read()
    blocks=re.findall(r'T7 U\((.*?)\)\s+(\S+)\n((?:T7 sig .*\n){3})',txt)
    for (nm,u,rows),(fib,cc) in zip(blocks,(([a1,a2,a3],0.02),([a1,a2],0.0))):
        S=np.array([[float(x) for x in l.split()[2:]] for l in rows.strip().split('\n')])
        s=cauchy(F,fib,p,cc); print(nm,'U diff',abs(float(u)-U(F,fib,p,cc).real),'sig rel diff',np.abs(S-s).max()/np.abs(s).max())
