import numpy as np, sys
sys.path.insert(0,'.')
from ref import U, cauchy
from ref_uni import closed_along
np.set_printoptions(precision=6,suppress=True,linewidth=150)
# 4A.1
F=np.array([[1.2,0.3,0],[0,1,0],[0,0,1/1.2]]); g=np.radians(35)
a1=np.array([np.cos(g),np.sin(g),0]); a2=np.array([np.cos(g),-np.sin(g),0])
J=np.linalg.det(F); C=F.T@F; Cb=C*J**(-2/3); I1=np.trace(Cb); I2=0.5*(I1**2-np.trace(Cb@Cb))
print('4A.1 J',J,'I1',I1,'I2',I2)
for nm,(a,b) in {'I4(11)':(a1,a1),'I5(11)':(a1,a1),'I4(12)':(a1,a2),'I5(12)':(a1,a2),'I4(22)':(a2,a2),'I5(22)':(a2,a2)}.items():
    M=Cb if nm[1]=='4' else Cb@Cb
    print(nm,a@M@b)
print('zeta12',a1@a2)
# E alpha for kappa=0.1
k=0.1
for a in (a1,a2): print('E',k*(I1-3)+(1-3*k)*(a@Cb@a-1))
# 4A.2
n4=lambda a,b:4+max(a,b)*(max(a,b)-1)+2*(min(a,b)-1)
ix=lambda n,m:min(n,m)+max(n,m)*(max(n,m)-1)//2
print('4A.2 n4(1,3)',n4(1,3),'n5(2,3)',n4(2,3)+1,'n4(3,3)',n4(3,3),'ix(1,13)',ix(1,13),'ix(3,14)',ix(3,14),'ix(13,14)',ix(13,14),'ix(10,10)',ix(10,10), 'packed',15*16//2)
# 4A.3
p=(0.01,1e-4,0.02,2.0,0.1)
for lam in (1.25,0.9):
    E=0.1*(lam**2+2/lam-3)+0.7*(lam**2-1)
    print('4A.3 lam',lam,'E',E,'sigma',closed_along(lam,p), 'matrix part',2*0.01*(lam**2-1/lam))
lam=1.25; E=0.1*(lam**2+2/lam-3)+0.7*(lam**2-1); psi=0.02*E*np.exp(2*E*E); print('psiE',psi,'exp',np.exp(2*E*E))
# 4B.2  SVK transversely/orthotropic chain rule check
def Usvk(E):  # isotropic SVK for the check
    lam,mu=2.0,1.0
    return lam/2*np.trace(E)**2+mu*np.trace(E@E)
Fs=np.array([[1.15,0.1,0.0],[0.05,0.95,0.04],[0,0,1.02]]);Js=np.linalg.det(Fs);Cs=Fs.T@Fs
Es=0.5*(Cs-np.eye(3)); Eb=0.5*(Js**(-2/3)*Cs-np.eye(3))
def dUdE(E):
    lam,mu=2.0,1.0; return lam*np.trace(E)*np.eye(3)+2*mu*E
S=dUdE(Es)
dUdEb=Js**(2/3)*S
dUdJ=(2/3)*Js**(-1/3)*np.sum(Eb*S)+(1/3)*Js**(-1/3)*np.trace(S)
# FD
def UbJ(Eb,J): 
    E=J**(2/3)*Eb+0.5*(J**(2/3)-1)*np.eye(3); return Usvk(E)
h=1e-6; fd11=(UbJ(Eb+h*np.diag([1,0,0]),Js)-UbJ(Eb-h*np.diag([1,0,0]),Js))/(2*h); fdJ=(UbJ(Eb,Js+h)-UbJ(Eb,Js-h))/(2*h)
print('4B.2 J',Js,'Eb11',Eb[0,0],'dUdEb11',dUdEb[0,0],fd11,'dUdJ',dUdJ,fdJ, 'U',Usvk(Es),UbJ(Eb,Js))
# 4C.1
for lam in (1.2,):
    print('4C.1', 2*0.5*(lam**2-1/lam)+2*10*lam**2*(lam**2-1), 2*0.5*(lam**2-1/lam), 2*10*lam**2*(lam**2-1))
