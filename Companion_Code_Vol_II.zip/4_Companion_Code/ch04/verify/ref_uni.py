"""Independent uniaxial references for Chapter 4 (incompressible, J = 1):
   along the fibre: closed form; across the fibre: lateral stretch from dW/dmu = 0,
   sigma = lam dW/dlam, W the explicit HGO energy (complex-step derivatives)."""
import numpy as np
from scipy.optimize import brentq
from ref import U
H=1e-30
def W(lam,mu,fib,p):
    F=np.diag([lam,mu,1/(lam*mu)]) if not isinstance(lam,complex) and not isinstance(mu,complex) else None
    return None
def Wf(lam,mu,fib,p):
    F=np.zeros((3,3),dtype=complex); F[0,0]=lam; F[1,1]=mu; F[2,2]=1/(lam*mu)
    return U(F,fib,p)
def uni(lam,fib,p):
    g=lambda m: Wf(lam,m+1j*H,fib,p).imag/H
    mu=brentq(g,0.3,1.6,xtol=1e-15,rtol=1e-14)
    s=lam*Wf(lam+1j*H,mu,fib,p).imag/H
    return s,mu
def closed_along(lam,p):
    C10,D,K1,K2,KAP=p
    B=lam**2-1/lam; E=KAP*(lam**2+2/lam-3)+(1-3*KAP)*(lam**2-1)
    PE=K1*E*np.exp(K2*E*E) if E>0 else 0.0
    return 2*((C10+KAP*PE)*B+(1-3*KAP)*PE*lam**2)
if __name__=='__main__':
    e1=np.array([1.,0,0]); e2=np.array([0,1.,0])
    base=(0.01,1e-4,0.02,2.0,0.1)
    rows=np.loadtxt('../out/scan.dat')
    kaps=[0.0,0.1,1/3]; dm1=dm2=0
    for r in rows:
        lam=r[0]
        for ik,k in enumerate(kaps):
            p=(base[0],base[1],base[2],base[3],k)
            sa=closed_along(lam,p); sb,_=uni(lam,[e2],p)
            dm1=max(dm1,abs(r[1+2*ik]-sa)); dm2=max(dm2,abs(r[2+2*ik]-sb))
    print('scan: max |Fortran along - closed| = %.2e ; max |Fortran across - independent solve| = %.2e'%(dm1,dm2))
    p=(0.01,1e-4,0.02,2.0,0.2); s,mu=uni(1.6,[e2],p); print('across kappa=0.2 lam=1.6: sigma %.10f  mu %.6f'%(s,mu))
    # isotropic limit
    p=(0.01,1e-4,0.02,2.0,1/3)
    for lam in (1.2,1.4,1.6):
        s1,_=uni(lam,[e1,e2],p) if False else (None,None)
    print('along fibre kappa=0.1 lam=1.3: %.10f'%closed_along(1.3,(0.01,1e-4,0.02,2.0,0.1)))
