"""Answers to the problems of Chapter 10 (independent numpy computations)."""
import numpy as np, sys
sys.path.insert(0,'.')
exec(open('check10.py').read().split("print('--- truss')")[0])   # kq4, D, stress_q4
np.set_printoptions(precision=4,suppress=True,linewidth=150)
print('=== 10A.1 aluminium bar (0,0)-(400,300), E=70000, A=250')
E1,A1=70000.,250.; x1=np.array([0,0.]); x2=np.array([400,300.]); L=np.linalg.norm(x2-x1); e=(x2-x1)/L; k=E1*A1/L
ee=np.outer(e,e); K=k*np.block([[ee,-ee],[-ee,ee]]); u=np.array([0.05,-0.02,0.30,0.10])
elong=e@(u[2:]-u[:2]); N=k*elong
print('L',L,'k',k); print(K); print('elong',elong,'N',N,'sigma',N/A1,'RHS',-K@u,'W',.5*u@K@u)
print('=== 10A.2 rectangle 30x15, t=2, E=70000, nu=0.33')
a,b,t,E2,nu=30.,15.,2.,70000.,0.33; c=E2*t/(1-nu**2)
k11=c*(b/(3*a)+(1-nu)*a/(6*b)); k12=c*(1+nu)/8; k13=c*(-b/(3*a)+(1-nu)*a/(12*b)); k22=c*(a/(3*b)+(1-nu)*b/(6*a))
print('c',c,'k11',k11,'k12',k12,'k13',k13,'k22',k22)
Kn=kq4(np.array([[0,0],[a,0],[a,b],[0,b]],float),E=E2,nu=nu,t=t); print('num',Kn[0,0],Kn[0,1],Kn[0,2],Kn[1,1])
print('sum of row 1 (u-dofs, rigid x translation):',Kn[0,0::2].sum())
print('=== 10B.2 one-point K11')
print('3/4 ratio: 2x2 K11',k11,'1pt',0.75*k11)
# one point numeric check
sx=np.array([-1,1,1,-1]); sy=np.array([-1,-1,1,1]); X=np.array([[0,0],[a,0],[a,b],[0,b]],float)
d=np.array([0.25*sx,0.25*sy]); J=d@X; dx=np.linalg.solve(J,d); B=np.zeros((3,8)); B[0,0::2]=dx[0]; B[1,1::2]=dx[1]; B[2,0::2]=dx[1]; B[2,1::2]=dx[0]
K1=4*t*np.linalg.det(J)*B.T@D(E2,nu)@B; print('1pt K11',K1[0,0],'ratio',K1[0,0]/k11,'rank',np.linalg.matrix_rank(K1,tol=1e-6*K1.max()))
print('=== 10C.1 CST (0,0),(40,0),(0,20), E=210000 nu=.3 t=5')
def kcst(X,E=210000.,nu=.3,t=5.):
    x=X[:,0];y=X[:,1]; A=.5*((x[1]-x[0])*(y[2]-y[0])-(x[2]-x[0])*(y[1]-y[0]))
    bq=np.array([y[1]-y[2],y[2]-y[0],y[0]-y[1]])/(2*A); cq=np.array([x[2]-x[1],x[0]-x[2],x[1]-x[0]])/(2*A)
    B=np.zeros((3,6)); B[0,0::2]=bq; B[1,1::2]=cq; B[2,0::2]=cq; B[2,1::2]=bq
    return t*A*B.T@D(E,nu)@B,A
Kc,A=kcst(np.array([[0,0],[40,0],[0,20.]])); print('A',A); print(Kc[0,:]); print('eig',np.linalg.eigvalsh(Kc))
print('=== 10C.2 strip: see out_drv10')
print('=== 10D.1 Wilson/Taylor Q6, cantilever 10x1, 20x2 and clamped')
def kq6(X,E=210000.,nu=.3,t=1.):
    Dm=D(E,nu); g=1/np.sqrt(3); pts=[(-g,-g),(g,-g),(g,g),(-g,g)]
    def dN(a,b): return np.array([0.25*sx*(1+sy*b),0.25*sy*(1+sx*a)])
    J0=dN(0,0)@X; dJ0=np.linalg.det(J0); J0i=np.linalg.inv(J0)
    Kuu=np.zeros((8,8));Kua=np.zeros((8,4));Kaa=np.zeros((4,4))
    for a,b in pts:
        d=dN(a,b); J=d@X; dx=np.linalg.solve(J,d); dJ=np.linalg.det(J)
        B=np.zeros((3,8)); B[0,0::2]=dx[0]; B[1,1::2]=dx[1]; B[2,0::2]=dx[1]; B[2,1::2]=dx[0]
        # incompatible modes: N5=1-xi^2, N6=1-eta^2, derivatives mapped with J0 (Taylor et al. 1976)
        dxi=np.array([-2*a,0.]); det_=np.array([0.,-2*b]); 
        g5=J0i.T@np.array([-2*a,0.]); g6=J0i.T@np.array([0.,-2*b])
        G=np.zeros((3,4)); G[0,0]=g5[0];G[1,1]=g5[1];G[2,0]=g5[1];G[2,1]=g5[0]
        G[0,2]=g6[0];G[1,3]=g6[1];G[2,2]=g6[1];G[2,3]=g6[0]
        G*=dJ0/dJ
        w=t*dJ
        Kuu+=w*B.T@Dm@B; Kua+=w*B.T@Dm@G; Kaa+=w*G.T@Dm@G
    return Kuu-Kua@np.linalg.solve(Kaa,Kua.T)
def cant6(nx,ny,L=100.,h=10.,P=1000.,kfun=kq6):
    nn=(nx+1)*(ny+1); ke=kfun(np.array([[0,0],[L/nx,0],[L/nx,h/ny],[0,h/ny]]))
    Kg=np.zeros((2*nn,2*nn)); f=np.zeros(2*nn)
    for j in range(ny):
        for i in range(nx):
            n=[i+j*(nx+1),i+1+j*(nx+1),i+1+(j+1)*(nx+1),i+(j+1)*(nx+1)]; idx=[2*m+q for m in n for q in (0,1)]
            Kg[np.ix_(idx,idx)]+=ke
    for j in range(ny+1): f[2*(nx+j*(nx+1))+1]=-P/ny*(0.5 if j in (0,ny) else 1)
    free=[2*m+q for m in range(nn) if m%(nx+1)!=0 for q in (0,1)]
    u=np.zeros(2*nn); u[free]=np.linalg.solve(Kg[np.ix_(free,free)],f[free]); return f@u/P
EB=1000*100**3/(3*210000*(10**3/12))
for nx,ny in [(5,1),(10,1),(20,2),(40,4)]:
    print(nx,ny,'Q6 %.5f ratio %.4f'%(cant6(nx,ny),cant6(nx,ny)/EB),' Q4 ratio %.4f'%(cant6(nx,ny,kfun=kq4)/EB))
