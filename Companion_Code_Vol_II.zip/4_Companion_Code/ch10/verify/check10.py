"""Independent checks for Chapter 10 (numpy/sympy, no Fortran).  Prints the numbers quoted in the text."""
import numpy as np, re, sys
import scipy.sparse as sps, scipy.sparse.linalg as spl
E,NU,T=210000.,0.3,1.
def D(E=E,nu=NU): f=E/(1-nu**2); return f*np.array([[1,nu,0],[nu,1,0],[0,0,(1-nu)/2]])
def kq4(X,E=E,nu=NU,t=T):
    # independent: shape functions by symbolic differentiation
    sx=np.array([-1,1,1,-1]); sy=np.array([-1,-1,1,1])
    dN=lambda a,b: np.array([0.25*sx*(1+sy*b),0.25*sy*(1+sx*a)])
    g=1/np.sqrt(3); K=np.zeros((8,8)); Dm=D(E,nu)
    for a,b in [(-g,-g),(g,-g),(g,g),(-g,g)]:
        d=dN(a,b); J=d@X; dx=np.linalg.solve(J,d)
        B=np.zeros((3,8)); B[0,0::2]=dx[0]; B[1,1::2]=dx[1]; B[2,0::2]=dx[1]; B[2,1::2]=dx[0]
        K+=t*np.linalg.det(J)*B.T@Dm@B
    return K
def stress_q4(X,u,E=E,nu=NU):
    g=1/np.sqrt(3); out=[]
    sx=np.array([-1,1,1,-1]); sy=np.array([-1,-1,1,1])
    for a,b in [(-g,-g),(g,-g),(g,g),(-g,g)]:
        d=np.array([0.25*sx*(1+sy*b),0.25*sy*(1+sx*a)]); J=d@X; dx=np.linalg.solve(J,d)
        B=np.zeros((3,8)); B[0,0::2]=dx[0]; B[1,1::2]=dx[1]; B[2,0::2]=dx[1]; B[2,1::2]=dx[0]
        out.append(D(E,nu)@B@u)
    return np.array(out)
print('--- truss'); 
def ktruss(x1,x2,E=210000.,A=100.):
    d=np.array(x2)-np.array(x1); L=np.linalg.norm(d); e=d/L; n=len(d)
    k=E*A/L; ee=np.outer(e,e); return k*np.block([[ee,-ee],[-ee,ee]]),k,L
K,k,L=ktruss([0,0],[300,400]); print('L',L,'k',k); print(K); print('eig',np.round(np.linalg.eigvalsh(K),6))
u=np.array([0,0,.01,.02]); print('RHS',-K@u,'N',k*((u[2:]-u[:2])@np.array([.6,.8])),'W',.5*u@K@u)
K3,k3,L3=ktruss([0,0,0],[200,300,600]); print('3D L',L3,'2k',2*k3,'eig',np.round(np.linalg.eigvalsh(K3),4))
# A-frame
EA=210000*100.; Lb=500.; s=.8; c=.6
dv=10000*Lb/(2*EA*s**2); print('A-frame u3y',-dv,'N',-10000/(2*s),'sigma',-10000/(2*s)/100,'W bar',.5*(10000/(2*s))**2*Lb/EA)
print('--- rectangle 40x20 t=5')
a,b,t=40.,20.,5.; X=np.array([[0,0],[a,0],[a,b],[0,b]],float)
K=kq4(X,t=t); c_=E*t/(1-NU**2)
cf={'k11':c_*(b/(3*a)+(1-NU)*a/(6*b)),'k12':c_*(1+NU)/8,'k13':c_*(-b/(3*a)+(1-NU)*a/(12*b)),'k14':c_*(3*NU-1)/8,
    'k15':c_*(-b/(6*a)-(1-NU)*a/(12*b)),'k16':-c_*(1+NU)/8,'k17':c_*(b/(6*a)-(1-NU)*a/(6*b)),'k18':c_*(1-3*NU)/8,
    'k22':c_*(a/(3*b)+(1-NU)*b/(6*a))}
for kk,v in cf.items():
    i,j=int(kk[1])-1,int(kk[2])-1; print(kk,'closed form %.3f'%v,'numpy %.3f'%K[i,j])
print('c',c_,'eig',np.round(np.linalg.eigvalsh(K),1))
XD=np.array([[0,0],[40,5],[45,30],[-5,20]],float); print('distorted eig',np.round(np.linalg.eigvalsh(kq4(XD,t=5)),1))
print('--- patch')
XY=np.array([[0,0],[24,0],[24,12],[0,12],[4,2],[18,3],[16,8],[8,8]],float); EL=[[1,2,6,5],[2,3,7,6],[3,4,8,7],[4,1,5,8],[5,6,7,8]]
Ks=np.zeros((16,16)); 
for e in EL:
    idx=[2*(n-1)+j for n in e for j in (0,1)]; Ks[np.ix_(idx,idx)]+=kq4(XY[[n-1 for n in e]])
a_=1e-3; ue=np.array([[a_*(x+y/2),a_*(y+x/2)] for x,y in XY]).ravel(); u=np.zeros(16); u[:8]=ue[:8]
fr=np.arange(8,16); u[fr]=np.linalg.solve(Ks[np.ix_(fr,fr)],-Ks[np.ix_(fr,np.arange(8))]@u[:8])
print('max err u',abs(u-ue).max()); 
sg=[stress_q4(XY[[n-1 for n in e]],np.array([u[2*(n-1)+j] for n in e for j in (0,1)])) for e in EL]
print('stress range',np.min(sg,axis=(0,1)),np.max(sg,axis=(0,1)))
print('--- cantilever')
def cant(nx,ny,L=100.,h=10.,P=1000.):
    nn=(nx+1)*(ny+1); xy=np.array([[L*i/nx,h*j/ny] for j in range(ny+1) for i in range(nx+1)])
    I,J,V=[],[],[]
    ke=kq4(np.array([[0,0],[L/nx,0],[L/nx,h/ny],[0,h/ny]]))
    for j in range(ny):
        for i in range(nx):
            n=[i+j*(nx+1),i+1+j*(nx+1),i+1+(j+1)*(nx+1),i+(j+1)*(nx+1)]; idx=[2*m+q for m in n for q in (0,1)]
            for p,ii in enumerate(idx):
                for q,jj in enumerate(idx): I.append(ii);J.append(jj);V.append(ke[p,q])
    Kg=sps.csr_matrix((V,(I,J)),shape=(2*nn,2*nn)); f=np.zeros(2*nn)
    for j in range(ny+1):
        w=1/ny*(0.5 if j in (0,ny) else 1); f[2*(nx+j*(nx+1))+1]=-P*w
    free=[2*m+q for m in range(nn) if m%(nx+1)!=0 for q in (0,1)]
    u=np.zeros(2*nn); u[free]=spl.spsolve(Kg[free][:,free].tocsc(),f[free]); return f@u/P  # work-equivalent deflection (magnitude)
EB=1000*100**3/(3*E*(10**3/12)); print('EB',EB)
for nx,ny in [(5,1),(10,1),(20,2),(40,4),(80,8),(160,16),(320,32)]:
    d=cant(nx,ny); print(nx,ny,'%.5f'%d,'ratio %.4f'%(d/EB))
print('--- sign test'); print([10000*2**k for k in range(7)])
