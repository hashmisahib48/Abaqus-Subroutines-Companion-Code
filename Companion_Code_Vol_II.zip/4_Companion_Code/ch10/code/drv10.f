!     Driver for the user elements of Chapter 10: calls UEL the way
!     Abaqus/Standard does (LFLAGS(3) = 1, 2, 5), assembles a few
!     elements and runs the tests of Section 10.8.
      PROGRAM DRV10
      INCLUDE 'ABA_PARAM.INC'
      CALL T_TRUSS
      CALL T_AFRAME
      CALL T_Q4
      CALL T_INTERFACE
      CALL T_PATCH
      CALL T_SIGN
      CALL T_CANT
      END
!
      SUBROUTINE K10_CALL(JT, MCRD, NN, X, PR, NPR, U, LF3, MLV, NR,
     1                    RHS, AM, SV, NSV, EN)
!     Fills the arguments that Abaqus passes and calls UEL once.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(MCRD,NN), PR(*), U(*), RHS(MLV,*), AM(8,8), SV(*),
     1 EN(8)
      DIMENSION AMX(64), DUX(64,2), VX(8), AX(8), TIM(2), PAR(3),
     1 JDL(1,1), ADL(1,1), DDL(1,1), PRE(2,1,4), LFL(7), JPR(1)
      NDOF = NN*MCRD
      DO I = 1, 7
         LFL(I) = 0
      ENDDO
      LFL(1) = 1
      LFL(3) = LF3
      DO I = 1, 8
         VX(I) = 0.D0
         AX(I) = 0.D0
      ENDDO
      TIM(1) = 1.D0
      TIM(2) = 1.D0
      PN = 1.D30
      CALL UEL(RHS, AMX, SV, EN, NDOF, NR, NSV, PR, NPR, X, MCRD, NN,
     1 U, DUX, VX, AX, JT, TIM, 1.D0, 1, 1, 7, PAR, 0, JDL, ADL, PRE,
     2 0, LFL, MLV, DDL, 1, PN, JPR, 0, 1.D0)
      DO I = 1, 8
         DO J = 1, 8
            AM(I,J) = 0.D0
         ENDDO
      ENDDO
      DO I = 1, NDOF
         DO J = 1, NDOF
            AM(I,J) = AMX(I + (J-1)*NDOF)
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K10_JAC(A0, N, W)
!     Eigenvalues of the symmetric matrix A0(8,8) (cyclic Jacobi),
!     returned in ascending order in W.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A0(8,8), A(8,8), W(8)
      DO I = 1, N
         DO J = 1, N
            A(I,J) = A0(I,J)
         ENDDO
      ENDDO
      DO ISW = 1, 100
         OFF = 0.D0
         DO I = 1, N-1
            DO J = I+1, N
               OFF = OFF + A(I,J)**2
            ENDDO
         ENDDO
         IF (OFF .LT. 1.D-30) GOTO 10
         DO IP = 1, N-1
            DO IQ = IP+1, N
               IF (ABS(A(IP,IQ)) .GT. 1.D-300) THEN
                  TH = (A(IQ,IQ) - A(IP,IP))/(2.D0*A(IP,IQ))
                  T = SIGN(1.D0, TH)/(ABS(TH) + SQRT(TH*TH + 1.D0))
                  C = 1.D0/SQRT(T*T + 1.D0)
                  S = T*C
                  DO K = 1, N
                     AKP = A(K,IP)
                     AKQ = A(K,IQ)
                     A(K,IP) = C*AKP - S*AKQ
                     A(K,IQ) = S*AKP + C*AKQ
                  ENDDO
                  DO K = 1, N
                     APK = A(IP,K)
                     AQK = A(IQ,K)
                     A(IP,K) = C*APK - S*AQK
                     A(IQ,K) = S*APK + C*AQK
                  ENDDO
               ENDIF
            ENDDO
         ENDDO
      ENDDO
 10   CONTINUE
      DO I = 1, N
         W(I) = A(I,I)
      ENDDO
      DO I = 1, N-1
         DO J = I+1, N
            IF (W(J) .LT. W(I)) THEN
               TMP = W(I)
               W(I) = W(J)
               W(J) = TMP
            ENDIF
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE K10_SOLVE(A, B, N)
!     Gauss elimination with partial pivoting: A*X = B, X in B.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(N,N), B(N)
      DO K = 1, N
         IP = K
         DO I = K+1, N
            IF (ABS(A(I,K)) .GT. ABS(A(IP,K))) IP = I
         ENDDO
         IF (IP .NE. K) THEN
            DO J = 1, N
               TMP = A(K,J)
               A(K,J) = A(IP,J)
               A(IP,J) = TMP
            ENDDO
            TMP = B(K)
            B(K) = B(IP)
            B(IP) = TMP
         ENDIF
         DO I = K+1, N
            F = A(I,K)/A(K,K)
            IF (F .NE. 0.D0) THEN
               DO J = K, N
                  A(I,J) = A(I,J) - F*A(K,J)
               ENDDO
               B(I) = B(I) - F*B(K)
            ENDIF
         ENDDO
      ENDDO
      DO K = N, 1, -1
         S = B(K)
         DO J = K+1, N
            S = S - A(K,J)*B(J)
         ENDDO
         B(K) = S/A(K,K)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K10_ASM(JT, MCRD, NN, NEL, IEN, NNOD, XY, PR, NPR,
     1                   U, SGN, R, GK)
!     Assembles the global residual R (external load not included)
!     and Jacobian GK from NEL elements of type JT.  Element nodes in
!     IEN(NN,NEL); coordinates XY(MCRD,NNOD).  SGN = +1 is the
!     Abaqus convention RHS = -K*U; SGN = -1 reproduces a wrong sign.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION IEN(NN,NEL), XY(MCRD,NNOD), PR(*), U(MCRD*NNOD),
     1 R(MCRD*NNOD), GK(MCRD*NNOD,MCRD*NNOD)
      DIMENSION X(MCRD,NN), UE(8), RHS(8,1), AM(8,8), SV(12), EN(8)
      NDOF = NN*MCRD
      NT = MCRD*NNOD
      DO I = 1, NT
         R(I) = 0.D0
         DO J = 1, NT
            GK(I,J) = 0.D0
         ENDDO
      ENDDO
      NSV = 12
      DO IE = 1, NEL
         DO K = 1, NN
            DO IC = 1, MCRD
               X(IC,K) = XY(IC, IEN(K,IE))
               UE(MCRD*(K-1)+IC) = U(MCRD*(IEN(K,IE)-1)+IC)
            ENDDO
         ENDDO
         CALL K10_CALL(JT, MCRD, NN, X, PR, NPR, UE, 1, 8, 1, RHS, AM,
     1                 SV, NSV, EN)
         DO K = 1, NDOF
            IG = MCRD*(IEN((K-1)/MCRD+1,IE)-1) + MOD(K-1,MCRD) + 1
            R(IG) = R(IG) + SGN*RHS(K,1)
            DO L = 1, NDOF
               JG = MCRD*(IEN((L-1)/MCRD+1,IE)-1) + MOD(L-1,MCRD) + 1
               GK(IG,JG) = GK(IG,JG) + AM(K,L)
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE T_TRUSS
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,2), PR(2), U(4), RHS(4,1), AM(8,8), SV(12), EN(8),
     1 W(8), X3(3,2), U3(6), RHS3(6,1), PR3(2), AM3(8,8)
      DATA PR /210000.D0, 100.D0/
      WRITE(*,'(A)') '=== T1 inclined truss (0,0)-(300,400)'
      X(1,1) = 0.D0
      X(2,1) = 0.D0
      X(1,2) = 300.D0
      X(2,2) = 400.D0
      DO I = 1, 4
         U(I) = 0.D0
      ENDDO
      U(3) = 0.01D0
      U(4) = 0.02D0
      EN(2) = 0.D0
      CALL K10_CALL(1, 2, 2, X, PR, 2, U, 1, 4, 1, RHS, AM, SV, 3, EN)
      WRITE(*,'(A,4F12.3)') 'K row1', (AM(1,J),J=1,4)
      WRITE(*,'(A,4F12.3)') 'K row2', (AM(2,J),J=1,4)
      WRITE(*,'(A,4F12.3)') 'K row3', (AM(3,J),J=1,4)
      WRITE(*,'(A,4F12.3)') 'K row4', (AM(4,J),J=1,4)
      CALL K10_JAC(AM, 4, W)
      WRITE(*,'(A,4ES14.5)') 'eig', (W(I),I=1,4)
      WRITE(*,'(A,4F12.4)') 'RHS', (RHS(I,1),I=1,4)
      WRITE(*,'(A,3F14.6)') 'SVARS eps,sig,N', (SV(I),I=1,3)
      WRITE(*,'(A,F12.5)') 'ENERGY(2)', EN(2)
!     3-D truss (0,0,0)-(2,3,6) mm: eigenvalues
      X3(1,1) = 0.D0
      X3(2,1) = 0.D0
      X3(3,1) = 0.D0
      X3(1,2) = 200.D0
      X3(2,2) = 300.D0
      X3(3,2) = 600.D0
      PR3(1) = 210000.D0
      PR3(2) = 100.D0
      DO I = 1, 6
         U3(I) = 0.D0
      ENDDO
      CALL K10_CALL(3, 3, 2, X3, PR3, 2, U3, 1, 6, 1, RHS3, AM3, SV,
     1              3, EN)
      CALL K10_JAC(AM3, 6, W)
      WRITE(*,'(A,6ES14.5)') '3D eig', (W(I),I=1,6)
      RETURN
      END
!
      SUBROUTINE T_AFRAME
!     Two bars (0,0)-(300,400) and (600,0)-(300,400), P = 10 kN at
!     the apex, supports at nodes 1 and 2.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XY(2,3), IEN(2,2), PR(2), U(6), R(6), GK(6,6), F(6),
     1 EN(8), RHS(4,1), AM(8,8), SV(12), X(2,2), UE(4)
      DATA PR /210000.D0, 100.D0/
      DATA XY /0.D0,0.D0, 600.D0,0.D0, 300.D0,400.D0/
      DATA IEN /1,3, 2,3/
      WRITE(*,'(A)') '=== T2 A-frame'
      DO I = 1, 6
         U(I) = 0.D0
         F(I) = 0.D0
      ENDDO
      F(6) = -10000.D0
      CALL K10_ASM(1, 2, 2, 2, IEN, 3, XY, PR, 2, U, 1.D0, R, GK)
      F(5) = F(5)
!     free dofs 5, 6: solve the 2 x 2 system
      DET = GK(5,5)*GK(6,6) - GK(5,6)*GK(6,5)
      U(5) = (F(5)*GK(6,6) - GK(5,6)*F(6))/DET
      U(6) = (GK(5,5)*F(6) - GK(6,5)*F(5))/DET
      WRITE(*,'(A,2ES16.8)') 'u3', U(5), U(6)
      DO IE = 1, 2
         DO K = 1, 2
            DO IC = 1, 2
               X(IC,K) = XY(IC,IEN(K,IE))
               UE(2*(K-1)+IC) = U(2*(IEN(K,IE)-1)+IC)
            ENDDO
         ENDDO
         CALL K10_CALL(1, 2, 2, X, PR, 2, UE, 1, 4, 1, RHS, AM, SV, 3,
     1                 EN)
         WRITE(*,'(A,I2,A,F12.4,A,F10.5,A,F10.4)') 'bar', IE, ' N=',
     1        SV(3), ' sig=', SV(2), ' ENERGY(2)=', EN(2)
         WRITE(*,'(A,4F12.4)') '  RHS', (RHS(I,1),I=1,4)
      ENDDO
      CALL K10_ASM(1, 2, 2, 2, IEN, 3, XY, PR, 2, U, 1.D0, R, GK)
      WRITE(*,'(A,6F12.4)') 'RHS_global at solution', (R(I),I=1,6)
      RETURN
      END
!
      SUBROUTINE T_Q4
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), PR(3), U(8), RHS(8,1), AM(8,8), SV(12), EN(8),
     1 W(8), XD(2,4), XR(2,4), UR(8), AMD(8,8), UP(8), UM(8), RP(8,1),
     2 RM(8,1)
      DATA PR /210000.D0, 0.3D0, 5.D0/
      WRITE(*,'(A)') '=== T3 quad: rectangle 40 x 20, t = 5'
      X(1,1) = 0.D0
      X(2,1) = 0.D0
      X(1,2) = 40.D0
      X(2,2) = 0.D0
      X(1,3) = 40.D0
      X(2,3) = 20.D0
      X(1,4) = 0.D0
      X(2,4) = 20.D0
      DO I = 1, 8
         U(I) = 0.D0
      ENDDO
      CALL K10_CALL(2, 2, 4, X, PR, 3, U, 1, 8, 1, RHS, AM, SV, 12,
     1              EN)
      WRITE(*,'(A,8F13.3)') 'K row1', (AM(1,J),J=1,8)
      WRITE(*,'(A,8F13.3)') 'K row2', (AM(2,J),J=1,8)
      CALL K10_JAC(AM, 8, W)
      WRITE(*,'(A,8ES13.4)') 'eig', (W(I),I=1,8)
      ASYM = 0.D0
      DO I = 1, 8
         DO J = 1, 8
            ASYM = MAX(ASYM, ABS(AM(I,J) - AM(J,I)))
         ENDDO
      ENDDO
      WRITE(*,'(A,ES10.2)') 'max asymmetry', ASYM
!     distorted quadrilateral: eigenvalues, rigid-body residual
      XD(1,1) = 0.D0
      XD(2,1) = 0.D0
      XD(1,2) = 40.D0
      XD(2,2) = 5.D0
      XD(1,3) = 45.D0
      XD(2,3) = 30.D0
      XD(1,4) = -5.D0
      XD(2,4) = 20.D0
      CALL K10_CALL(2, 2, 4, XD, PR, 3, U, 1, 8, 1, RHS, AMD, SV, 12,
     1              EN)
      CALL K10_JAC(AMD, 8, W)
      WRITE(*,'(A,8ES13.4)') 'eig distorted', (W(I),I=1,8)
!     rigid translation + small rotation about (7,3): u = u0 - th*dy
      TH = 1.D-3
      DO I = 1, 4
         UR(2*I-1) = 0.2D0 - TH*(XD(2,I) - 3.D0)
         UR(2*I)   = -0.1D0 + TH*(XD(1,I) - 7.D0)
      ENDDO
      CALL K10_CALL(2, 2, 4, XD, PR, 3, UR, 1, 8, 1, RHS, AMD, SV, 12,
     1              EN)
      RN = 0.D0
      DO I = 1, 8
         RN = MAX(RN, ABS(RHS(I,1)))
      ENDDO
      DO I = 1, 4
         XR(1,I) = XD(1,5-I)
         XR(2,I) = XD(2,5-I)
      ENDDO
      CALL K10_Q4(XR, PR, UP, AMD, SV, ISTAT)
      WRITE(*,'(A,I2)') 'clockwise node order: ISTAT =', ISTAT
      WRITE(*,'(A,ES10.2,A,ES10.2)') 'rigid: max|RHS| =', RN,
     1      '  max|SVARS| =', MAXVAL(ABS(SV(1:12)))
!     central-difference check of AMATRX = -dRHS/dU
      FDERR = 0.D0
      DO J = 1, 8
         DO I = 1, 8
            UP(I) = UR(I)
            UM(I) = UR(I)
         ENDDO
         UP(J) = UP(J) + 1.D-2
         UM(J) = UM(J) - 1.D-2
         CALL K10_CALL(2, 2, 4, XD, PR, 3, UP, 1, 8, 1, RP, AM, SV,
     1                 12, EN)
         CALL K10_CALL(2, 2, 4, XD, PR, 3, UM, 1, 8, 1, RM, AM, SV,
     1                 12, EN)
         CALL K10_CALL(2, 2, 4, XD, PR, 3, UM, 1, 8, 1, RM, AMD, SV,
     1                 12, EN)
         DO I = 1, 8
            FD = -(RP(I,1) - RM(I,1))/2.D-2
            FDERR = MAX(FDERR, ABS(FD - AMD(I,J)))
         ENDDO
      ENDDO
      WRITE(*,'(A,ES10.2,A,ES10.2)') 'FD: max|AMATRX + dRHS/dU| =',
     1      FDERR, ' (largest K entry', MAXVAL(ABS(AMD))
      RETURN
      END
!
      SUBROUTINE T_INTERFACE
!     MLVARX larger than NDOFEL, NRHS = 2, other LFLAGS(3) values.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), PR(3), U(8), RHSA(8,1), RHSB(12,2), AM(8,8),
     1 AMB(8,8), SV(12), EN(8)
      DATA PR /210000.D0, 0.3D0, 5.D0/
      WRITE(*,'(A)') '=== T4 interface: MLVARX, NRHS, LFLAGS(3)'
      X(1,1) = 0.D0
      X(2,1) = 0.D0
      X(1,2) = 40.D0
      X(2,2) = 0.D0
      X(1,3) = 40.D0
      X(2,3) = 20.D0
      X(1,4) = 0.D0
      X(2,4) = 20.D0
      DO I = 1, 8
         U(I) = 0.01D0*I
      ENDDO
      CALL K10_CALL(2, 2, 4, X, PR, 3, U, 1, 8, 1, RHSA, AM, SV, 12,
     1              EN)
      DO J = 1, 2
         DO I = 1, 12
            RHSB(I,J) = 999.D0
         ENDDO
      ENDDO
      CALL K10_CALL(2, 2, 4, X, PR, 3, U, 1, 12, 2, RHSB, AMB, SV, 12,
     1              EN)
      D1 = 0.D0
      DO I = 1, 8
         D1 = MAX(D1, ABS(RHSA(I,1) - RHSB(I,1)))
      ENDDO
      WRITE(*,'(A,ES10.2)') 'MLVARX=12 vs 8: max diff RHS(:,1)', D1
      WRITE(*,'(A,2F8.1,A,2F8.1)') 'canaries RHS(9:10,1)',
     1      RHSB(9,1), RHSB(10,1), '  RHS(1:2,2)', RHSB(1,2), RHSB(2,2)
      CALL K10_CALL(2, 2, 4, X, PR, 3, U, 2, 12, 1, RHSB, AMB, SV, 12,
     1              EN)
      WRITE(*,'(A,F10.3,A,F10.3)') 'LFLAGS(3)=2: AMATRX(1,1)=',
     1      AMB(1,1), '  RHS(1,1)=', RHSB(1,1)
      CALL K10_CALL(2, 2, 4, X, PR, 3, U, 5, 12, 1, RHSB, AMB, SV, 12,
     1              EN)
      WRITE(*,'(A,F10.3,A,F12.3)') 'LFLAGS(3)=5: AMATRX(1,1)=',
     1      AMB(1,1), '  RHS(1,1)=', RHSB(1,1)
      WRITE(*,'(A,F12.3)') 'LFLAGS(3)=1: RHS(1,1)=', RHSA(1,1)
      RETURN
      END
!
      SUBROUTINE T_PATCH
!     MacNeal-Harder patch test, 24 mm x 12 mm, five elements.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XY(2,8), IEN(4,5), PR(3), U(16), R(16), GK(16,16),
     1 F(16), UEX(16), GKFF(8,8), RF(8), IFR(8), EN(8), X(2,4),
     2 UE(8), RHS(8,1), AM(8,8), SV(12)
      DATA PR /210000.D0, 0.3D0, 1.D0/
      DATA XY /0.D0,0.D0, 24.D0,0.D0, 24.D0,12.D0, 0.D0,12.D0,
     1         4.D0,2.D0, 18.D0,3.D0, 16.D0,8.D0, 8.D0,8.D0/
      DATA IEN /1,2,6,5, 2,3,7,6, 3,4,8,7, 4,1,5,8, 5,6,7,8/
      A = 1.D-3
      WRITE(*,'(A)') '=== T5 patch test, u = a(x+y/2), v = a(y+x/2)'
      DO I = 1, 8
         UEX(2*I-1) = A*(XY(1,I) + 0.5D0*XY(2,I))
         UEX(2*I)   = A*(XY(2,I) + 0.5D0*XY(1,I))
      ENDDO
!     Newton iteration as Abaqus does it: boundary values prescribed,
!     interior displacements start from zero.
      DO I = 1, 16
         U(I) = 0.D0
         F(I) = 0.D0
      ENDDO
      DO I = 1, 8
         U(I) = UEX(I)
      ENDDO
      DO ITER = 1, 3
         CALL K10_ASM(2, 2, 4, 5, IEN, 8, XY, PR, 3, U, 1.D0, R, GK)
         RN = 0.D0
         DO I = 9, 16
            RN = MAX(RN, ABS(F(I) + R(I)))
         ENDDO
         WRITE(*,'(A,I2,A,ES11.3)') 'iteration', ITER,
     1        '  max free residual', RN
         IF (ITER .EQ. 3) GOTO 20
         DO I = 1, 8
            DO J = 1, 8
               GKFF(I,J) = GK(8+I,8+J)
            ENDDO
            RF(I) = F(8+I) + R(8+I)
         ENDDO
         CALL K10_SOLVE(GKFF, RF, 8)
         DO I = 1, 8
            U(8+I) = U(8+I) + RF(I)
         ENDDO
      ENDDO
 20   CONTINUE
      ERR = 0.D0
      DO I = 1, 16
         ERR = MAX(ERR, ABS(U(I) - UEX(I)))
      ENDDO
      WRITE(*,'(A,ES10.2,A,ES10.2)') 'max |u - u_exact| =', ERR,
     1      '  (max u_exact', MAXVAL(ABS(UEX))
!     stresses at all Gauss points
      SXE = 300.D0
      SYE = 300.D0
      TXE = 210000.D0/2.6D0*2.D0*A
      TXE = 210000.D0/2.6D0*A
      SMAX = 0.D0
      DO IE = 1, 5
         DO K = 1, 4
            DO IC = 1, 2
               X(IC,K) = XY(IC,IEN(K,IE))
               UE(2*(K-1)+IC) = U(2*(IEN(K,IE)-1)+IC)
            ENDDO
         ENDDO
         CALL K10_CALL(2, 2, 4, X, PR, 3, UE, 1, 8, 1, RHS, AM, SV, 12,
     1                 EN)
         DO IG = 1, 4
            SMAX = MAX(SMAX, ABS(SV(3*IG-2) - SXE),
     1                 ABS(SV(3*IG-1) - SYE), ABS(SV(3*IG) - TXE))
         ENDDO
         IF (IE .EQ. 5) WRITE(*,'(A,3F12.6)') 'element 5, point 1:',
     1        SV(1), SV(2), SV(3)
         IF (IE .EQ. 1) WRITE(*,'(A,3F12.6)') 'element 1, point 3:',
     1        SV(7), SV(8), SV(9)
      ENDDO
      WRITE(*,'(A,ES10.2,A,F9.4)') 'max |sigma - sigma_exact| =', SMAX,
     1      ' MPa; tau_exact =', TXE
      RETURN
      END
!
      SUBROUTINE T_SIGN
!     Newton iteration on the A-frame with RHS = -K*U (SGN = +1) and
!     with the wrong sign RHS = +K*U (SGN = -1).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION XY(2,3), IEN(2,2), PR(2), U(6), R(6), GK(6,6), F(6),
     1 UEX(2)
      DATA PR /210000.D0, 100.D0/
      DATA XY /0.D0,0.D0, 600.D0,0.D0, 300.D0,400.D0/
      DATA IEN /1,3, 2,3/
      WRITE(*,'(A)') '=== T6 sign of RHS: A-frame, P = 10 kN'
      UEX(1) = 0.D0
      UEX(2) = -10000.D0*500.D0/(2.D0*210000.D0*100.D0*0.64D0)
      DO ISG = 1, 2
         SGN = 1.D0
         IF (ISG .EQ. 2) SGN = -1.D0
         DO I = 1, 6
            U(I) = 0.D0
            F(I) = 0.D0
         ENDDO
         F(6) = -10000.D0
         WRITE(*,'(A,F4.1)') 'SGN =', SGN
         DO ITER = 1, 7
            CALL K10_ASM(1, 2, 2, 2, IEN, 3, XY, PR, 2, U, SGN, R, GK)
            R5 = F(5) + R(5)
            R6 = F(6) + R(6)
            DET = GK(5,5)*GK(6,6) - GK(5,6)*GK(6,5)
            D5 = (R5*GK(6,6) - GK(5,6)*R6)/DET
            D6 = (GK(5,5)*R6 - GK(6,5)*R5)/DET
            WRITE(*,'(A,I2,A,ES11.3,A,ES11.3)') ' it', ITER,
     1       '  |residual| =', SQRT(R5*R5 + R6*R6), '  u3y =', U(6)
            U(5) = U(5) + D5
            U(6) = U(6) + D6
         ENDDO
      ENDDO
      WRITE(*,'(A,ES14.6)') 'exact u3y', UEX(2)
      RETURN
      END
!
      SUBROUTINE T_CANT
!     Cantilever strip L = 100, h = 10, t = 1, tip load 1000 N.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PR(3), NXS(5), NYS(5)
      DATA PR /210000.D0, 0.3D0, 1.D0/
      DATA NXS /10, 20, 40, 80, 5/
      DATA NYS /1, 2, 4, 8, 1/
      WRITE(*,'(A)') '=== T7 cantilever, work-equivalent tip deflection'
      DEB = 1000.D0*100.D0**3/(3.D0*210000.D0*(1.D0*10.D0**3/12.D0))
      WRITE(*,'(A,F10.5)') 'Euler-Bernoulli PL^3/3EI =', DEB
      DO IM = 1, 5
         CALL T_CANT1(NXS(IM), NYS(IM), PR, DEB)
      ENDDO
      RETURN
      END
!
      SUBROUTINE T_CANT1(NX, NY, PR, DEB)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION PR(3)
      INTEGER, ALLOCATABLE :: IEN(:,:)
      REAL*8, ALLOCATABLE :: XY(:,:), U(:), R(:), GK(:,:), F(:),
     1 GKFF(:,:), RF(:)
      INTEGER, ALLOCATABLE :: IFR(:)
      NNOD = (NX+1)*(NY+1)
      NEL = NX*NY
      NT = 2*NNOD
      ALLOCATE(IEN(4,NEL), XY(2,NNOD), U(NT), R(NT), GK(NT,NT),
     1 F(NT), IFR(NT))
      DO J = 0, NY
         DO I = 0, NX
            N = I + J*(NX+1) + 1
            XY(1,N) = 100.D0*I/NX
            XY(2,N) = 10.D0*J/NY
         ENDDO
      ENDDO
      DO J = 0, NY-1
         DO I = 0, NX-1
            IE = I + J*NX + 1
            IEN(1,IE) = I + J*(NX+1) + 1
            IEN(2,IE) = I + 1 + J*(NX+1) + 1
            IEN(3,IE) = I + 1 + (J+1)*(NX+1) + 1
            IEN(4,IE) = I + (J+1)*(NX+1) + 1
         ENDDO
      ENDDO
      DO I = 1, NT
         U(I) = 0.D0
         F(I) = 0.D0
      ENDDO
      DO J = 0, NY
         N = NX + J*(NX+1) + 1
         W = 1.D0/NY
         IF (J.EQ.0 .OR. J.EQ.NY) W = 0.5D0/NY
         F(2*N) = -1000.D0*W
      ENDDO
      NF = 0
      DO N = 1, NNOD
         IF (MOD(N-1,NX+1) .NE. 0) THEN
            NF = NF + 1
            IFR(NF) = 2*N-1
            NF = NF + 1
            IFR(NF) = 2*N
         ENDIF
      ENDDO
      ALLOCATE(GKFF(NF,NF), RF(NF))
      CALL K10_ASM(2, 2, 4, NEL, IEN, NNOD, XY, PR, 3, U, 1.D0, R,
     1              GK)
      DO I = 1, NF
         RF(I) = F(IFR(I)) + R(IFR(I))
         DO J = 1, NF
            GKFF(I,J) = GK(IFR(I),IFR(J))
         ENDDO
      ENDDO
      CALL K10_SOLVE(GKFF, RF, NF)
      DO I = 1, NF
         U(IFR(I)) = RF(I)
      ENDDO
      CALL K10_ASM(2, 2, 4, NEL, IEN, NNOD, XY, PR, 3, U, 1.D0, R,
     1              GK)
      RN = 0.D0
      DO I = 1, NF
         RN = MAX(RN, ABS(F(IFR(I)) + R(IFR(I))))
      ENDDO
      DEL = 0.D0
      DO J = 0, NY
         N = NX + J*(NX+1) + 1
         DEL = DEL + F(2*N)*U(2*N)/1000.D0
      ENDDO
      WRITE(*,'(A,I3,A,I2,A,F10.5,A,F7.4,A,ES9.2)') 'mesh', NX, ' x',
     1      NY, '  tip =', DEL, '  /EB =', DEL/DEB, '  residual',RN
      IF (NX.EQ.10 .AND. NY.EQ.1) WRITE(*,'(A,4F11.5)')
     1   '  nodes 11, 22: ux, uy', U(21), U(22), U(43), U(44)
      RETURN
      END
