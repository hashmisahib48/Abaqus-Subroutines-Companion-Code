#!/bin/sh
# Compile every listing of Chapter 10 and run the driver (gfortran, no Abaqus involved).
cd /home/claude/vol2/ch10/code || exit 1
INC=-I/home/claude/vol2/lib/aba
for f in ex10_uel ex10_elems prob_10b3_bug; do gfortran -c -ffixed-form -std=legacy $INC $f.f -o /tmp/$f.o || exit 1; done
gfortran -ffixed-form -std=legacy $INC drv10.f ex10_uel.f ex10_elems.f /home/claude/vol2/lib/aba/stubs.f -o /tmp/drv10 && /tmp/drv10 > ../verify/out_drv10.txt
python3 ../verify/check10.py > ../verify/out_check10.txt
echo done
