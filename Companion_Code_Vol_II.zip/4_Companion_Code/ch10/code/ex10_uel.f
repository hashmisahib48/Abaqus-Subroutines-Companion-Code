      SUBROUTINE UEL(RHS,AMATRX,SVARS,ENERGY,NDOFEL,NRHS,NSVARS,
     1 PROPS,NPROPS,COORDS,MCRD,NNODE,U,DU,V,A,JTYPE,TIME,DTIME,
     2 KSTEP,KINC,JELEM,PARAMS,NDLOAD,JDLTYP,ADLMAG,PREDEF,NPREDF,
     3 LFLAGS,MLVARX,DDLMAG,MDLOAD,PNEWDT,JPROPS,NJPROP,PERIOD)
!     Linear elastic user elements for static analysis:
!       JTYPE 1, 3 : two-node truss in 2-D (U1) and 3-D (U3)
!       JTYPE 2    : four-node plane-stress quadrilateral (U2)
!     PROPS (truss): E (MPa), A (mm**2).  PROPS (quad): E (MPa),
!     NU (-), T (mm).  SVARS: truss 3 values, quad 12 values.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION RHS(MLVARX,*),AMATRX(NDOFEL,NDOFEL),PROPS(*),
     1 SVARS(*),ENERGY(8),COORDS(MCRD,NNODE),U(NDOFEL),
     2 DU(MLVARX,*),V(NDOFEL),A(NDOFEL),TIME(2),PARAMS(*),
     3 JDLTYP(MDLOAD,*),ADLMAG(MDLOAD,*),DDLMAG(MDLOAD,*),
     4 PREDEF(2,NPREDF,NNODE),LFLAGS(*),JPROPS(*)
      DIMENSION AK(8,8), FI(8), SV(12), INTV(2), REALV(1)
      CHARACTER*8 CHARV(1)
!
      LF3 = LFLAGS(3)
      IF (LF3.EQ.3 .OR. LF3.EQ.4 .OR. LF3.EQ.6) THEN
         INTV(1) = LF3
         CALL STDB_ABQERR(-3, 'UEL: LFLAGS(3)=%I (damping or mass) '//
     1      'is not implemented in this element.', INTV, REALV, CHARV)
      ENDIF
      IF (NDLOAD .GT. 0) THEN
         INTV(1) = JELEM
         CALL STDB_ABQERR(-3, 'UEL: element %I does not support '//
     1      'distributed loads.', INTV, REALV, CHARV)
      ENDIF
      IF (NDOFEL.GT.8 .OR. NSVARS.LT.3) THEN
         INTV(1) = JELEM
         CALL STDB_ABQERR(-3, 'UEL: inconsistent *USER ELEMENT '//
     1      'data for element %I.', INTV, REALV, CHARV)
      ENDIF
!     Zero everything that is returned, whatever LFLAGS(3) asks for.
      DO KRHS = 1, NRHS
         DO K1 = 1, NDOFEL
            RHS(K1,KRHS) = 0.D0
         ENDDO
      ENDDO
      DO K1 = 1, NDOFEL
         DO K2 = 1, NDOFEL
            AMATRX(K1,K2) = 0.D0
         ENDDO
      ENDDO
      IF (LF3 .EQ. 100) RETURN
!     Element kernel: stiffness AK and stresses SV from the total U.
      ISTAT = 0
      NSV = 0
      IF (JTYPE.EQ.1 .OR. JTYPE.EQ.3) THEN
         NSV = 3
         IF (NPROPS .LT. 2) ISTAT = 3
         IF (ISTAT .EQ. 0) THEN
            CALL K10_TRUSS(COORDS, MCRD, PROPS, U, AK, SV, ISTAT)
         ENDIF
      ELSE IF (JTYPE.EQ.2) THEN
         NSV = 12
         IF (NPROPS .LT. 3) ISTAT = 3
         IF (ISTAT .EQ. 0) THEN
            CALL K10_Q4(COORDS, PROPS, U, AK, SV, ISTAT)
         ENDIF
      ELSE
         ISTAT = 9
      ENDIF
      IF (ISTAT .NE. 0 .OR. NSVARS.LT.NSV) THEN
         INTV(1) = JELEM
         INTV(2) = ISTAT
         CALL STDB_ABQERR(-3, 'UEL: element %I rejected (status '//
     1      '%I): check properties, nodes, VARIABLES.', INTV, REALV,
     2      CHARV)
      ENDIF
!     Internal force FI = K*U; Abaqus wants RHS = external - internal.
      DO K1 = 1, NDOFEL
         FI(K1) = 0.D0
         DO K2 = 1, NDOFEL
            FI(K1) = FI(K1) + AK(K1,K2)*U(K2)
         ENDDO
      ENDDO
      IF (LF3.EQ.1 .OR. LF3.EQ.5) THEN
         DO K1 = 1, NDOFEL
            RHS(K1,1) = -FI(K1)
         ENDDO
      ENDIF
      IF (LF3.EQ.1 .OR. LF3.EQ.2) THEN
         DO K1 = 1, NDOFEL
            DO K2 = 1, NDOFEL
               AMATRX(K1,K2) = AK(K1,K2)
            ENDDO
         ENDDO
      ENDIF
      IF (LF3 .EQ. 1) THEN
         ENERGY(2) = 0.D0
         DO K1 = 1, NDOFEL
            ENERGY(2) = ENERGY(2) + 0.5D0*U(K1)*FI(K1)
         ENDDO
         DO K1 = 1, NSV
            SVARS(K1) = SV(K1)
         ENDDO
      ENDIF
      RETURN
      END
