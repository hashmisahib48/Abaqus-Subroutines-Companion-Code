      SUBROUTINE K10_TRUSS(X, MCRD, PROPS, U, AK, SV, ISTAT)
!     Two-node truss, MCRD = 2 or 3.  X(MCRD,2) in mm, PROPS(1) = E
!     (MPa), PROPS(2) = A (mm**2).  AK(8,8) in N/mm.  SV(1) = axial
!     strain, SV(2) = stress (MPa), SV(3) = axial force (N).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(MCRD,2), PROPS(*), U(2*MCRD), AK(8,8), SV(*), D(3)
      ISTAT = 0
      E = PROPS(1)
      AREA = PROPS(2)
      IF (E.LE.0.D0 .OR. AREA.LE.0.D0) ISTAT = 1
      EL = 0.D0
      DO I = 1, MCRD
         D(I) = X(I,2) - X(I,1)
         EL = EL + D(I)*D(I)
      ENDDO
      EL = SQRT(EL)
      IF (EL .LE. 0.D0) ISTAT = 2
      IF (ISTAT .NE. 0) RETURN
      DO I = 1, MCRD
         D(I) = D(I)/EL
      ENDDO
      CK = E*AREA/EL
      DO I = 1, 8
         DO J = 1, 8
            AK(I,J) = 0.D0
         ENDDO
      ENDDO
      DO I = 1, MCRD
         DO J = 1, MCRD
            AK(I,J) = CK*D(I)*D(J)
            AK(I+MCRD,J+MCRD) = AK(I,J)
            AK(I,J+MCRD) = -AK(I,J)
            AK(I+MCRD,J) = -AK(I,J)
         ENDDO
      ENDDO
      ELONG = 0.D0
      DO I = 1, MCRD
         ELONG = ELONG + D(I)*(U(I+MCRD) - U(I))
      ENDDO
      SV(1) = ELONG/EL
      SV(2) = E*SV(1)
      SV(3) = AREA*SV(2)
      RETURN
      END
!
      SUBROUTINE K10_DPS(E, ANU, D)
!     Plane-stress elasticity matrix, engineering shear strain.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION D(3,3)
      DO I = 1, 3
         DO J = 1, 3
            D(I,J) = 0.D0
         ENDDO
      ENDDO
      FAC = E/(1.D0 - ANU*ANU)
      D(1,1) = FAC
      D(2,2) = FAC
      D(1,2) = FAC*ANU
      D(2,1) = FAC*ANU
      D(3,3) = 0.5D0*FAC*(1.D0 - ANU)
      RETURN
      END
!
      SUBROUTINE K10_Q4B(X, XI, ETA, B, DETJ)
!     Strain-displacement matrix B(3,8) and Jacobian determinant of
!     the 4-node quadrilateral (this is K1_Q4B of Listing 1.5).
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), B(3,8), XS(4), ES(4), DNXI(4), DNET(4)
      DATA XS /-1.D0, 1.D0, 1.D0, -1.D0/
      DATA ES /-1.D0, -1.D0, 1.D0, 1.D0/
      AJ11 = 0.D0
      AJ12 = 0.D0
      AJ21 = 0.D0
      AJ22 = 0.D0
      DO I = 1, 4
         DNXI(I) = 0.25D0*XS(I)*(1.D0 + ES(I)*ETA)
         DNET(I) = 0.25D0*ES(I)*(1.D0 + XS(I)*XI)
         AJ11 = AJ11 + DNXI(I)*X(1,I)
         AJ12 = AJ12 + DNXI(I)*X(2,I)
         AJ21 = AJ21 + DNET(I)*X(1,I)
         AJ22 = AJ22 + DNET(I)*X(2,I)
      ENDDO
      DETJ = AJ11*AJ22 - AJ12*AJ21
      IF (DETJ .LE. 0.D0) RETURN
      DO I = 1, 4
         DNX = ( AJ22*DNXI(I) - AJ12*DNET(I))/DETJ
         DNY = (-AJ21*DNXI(I) + AJ11*DNET(I))/DETJ
         B(1,2*I-1) = DNX
         B(1,2*I)   = 0.D0
         B(2,2*I-1) = 0.D0
         B(2,2*I)   = DNY
         B(3,2*I-1) = DNY
         B(3,2*I)   = DNX
      ENDDO
      RETURN
      END
!
      SUBROUTINE K10_Q4(X, PROPS, U, AK, SV, ISTAT)
!     Plane-stress quadrilateral, 2 x 2 Gauss points numbered like
!     the nodes: (-,-), (+,-), (+,+), (-,+).  X(2,4) in mm, PROPS =
!     E (MPa), NU (-), T (mm).  AK(8,8) in N/mm.  SV(3*IG-2:3*IG) =
!     sigma_x, sigma_y, tau_xy (MPa) at Gauss point IG.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION X(2,4), PROPS(*), U(8), AK(8,8), SV(12), D(3,3),
     1 B(3,8), DB(3,8), EPS(3), XG(4), EG(4)
      DATA XG /-0.5773502691896258D0, 0.5773502691896258D0,
     1          0.5773502691896258D0, -0.5773502691896258D0/
      DATA EG /-0.5773502691896258D0, -0.5773502691896258D0,
     1          0.5773502691896258D0, 0.5773502691896258D0/
      ISTAT = 0
      E = PROPS(1)
      ANU = PROPS(2)
      T = PROPS(3)
      IF (E.LE.0.D0 .OR. T.LE.0.D0 .OR. ANU.LE.-1.D0 .OR.
     1    ANU.GE.1.D0) ISTAT = 1
      IF (ISTAT .NE. 0) RETURN
      CALL K10_DPS(E, ANU, D)
      DO I = 1, 8
         DO J = 1, 8
            AK(I,J) = 0.D0
         ENDDO
      ENDDO
      DO IG = 1, 4
         CALL K10_Q4B(X, XG(IG), EG(IG), B, DETJ)
         IF (DETJ .LE. 0.D0) THEN
            ISTAT = 2
            RETURN
         ENDIF
         DO I = 1, 3
            DO J = 1, 8
               DB(I,J) = D(I,1)*B(1,J) + D(I,2)*B(2,J) + D(I,3)*B(3,J)
            ENDDO
         ENDDO
         DO I = 1, 8
            DO J = 1, 8
               AK(I,J) = AK(I,J) + T*DETJ*(B(1,I)*DB(1,J)
     1                 + B(2,I)*DB(2,J) + B(3,I)*DB(3,J))
            ENDDO
         ENDDO
         DO I = 1, 3
            EPS(I) = 0.D0
            DO J = 1, 8
               EPS(I) = EPS(I) + B(I,J)*U(J)
            ENDDO
         ENDDO
         DO I = 1, 3
            SV(3*IG-3+I) = D(I,1)*EPS(1) + D(I,2)*EPS(2)
     1                   + D(I,3)*EPS(3)
         ENDDO
      ENDDO
      RETURN
      END
