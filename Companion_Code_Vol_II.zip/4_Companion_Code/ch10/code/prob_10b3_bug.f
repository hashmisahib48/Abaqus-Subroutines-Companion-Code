      SUBROUTINE UEL(RHS,AMATRX,SVARS,ENERGY,NDOFEL,NRHS,NSVARS,
     1 PROPS,NPROPS,COORDS,MCRD,NNODE,U,DU,V,A,JTYPE,TIME,DTIME,
     2 KSTEP,KINC,JELEM,PARAMS,NDLOAD,JDLTYP,ADLMAG,PREDEF,NPREDF,
     3 LFLAGS,MLVARX,DDLMAG,MDLOAD,PNEWDT,JPROPS,NJPROP,PERIOD)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION RHS(NDOFEL,*),AMATRX(NDOFEL,NDOFEL),PROPS(*),
     1 SVARS(*),ENERGY(8),COORDS(MCRD,NNODE),U(NDOFEL),
     2 DU(MLVARX,*),V(NDOFEL),A(NDOFEL),TIME(2),PARAMS(*),
     3 JDLTYP(MDLOAD,*),ADLMAG(MDLOAD,*),DDLMAG(MDLOAD,*),
     4 PREDEF(2,NPREDF,NNODE),LFLAGS(*),JPROPS(*)
      DIMENSION AK(4,4), FI(4)
!     two-node truss in 2-D, PROPS(1) = E, PROPS(2) = A
      DX = COORDS(1,2) - COORDS(1,1)
      DY = COORDS(2,2) - COORDS(2,1)
      EL = SQRT(DX*DX + DY*DY)
      C = DX/EL
      S = DY/EL
      CK = PROPS(1)*PROPS(2)/EL
      AK(1,1) = CK*C*C
      AK(1,2) = CK*C*S
      AK(1,3) = -CK*C*C
      AK(1,4) = -CK*C*S
      AK(2,2) = CK*S*S
      AK(2,3) = -CK*C*S
      AK(2,4) = -CK*S*S
      AK(3,3) = CK*C*C
      AK(3,4) = CK*C*S
      AK(4,4) = CK*S*S
      DO K1 = 1, 4
         FI(K1) = 0.D0
         DO K2 = K1, 4
            FI(K1) = FI(K1) + AK(K1,K2)*DU(K2,1)
         ENDDO
      ENDDO
      DO K1 = 1, 4
         RHS(K1,1) = FI(K1)
         DO K2 = 1, 4
            AMATRX(K1,K2) = AK(K1,K2)
         ENDDO
      ENDDO
      ENERGY(2) = 0.D0
      DO K1 = 1, 4
         ENERGY(2) = ENERGY(2) + U(K1)*FI(K1)
      ENDDO
      RETURN
      END
