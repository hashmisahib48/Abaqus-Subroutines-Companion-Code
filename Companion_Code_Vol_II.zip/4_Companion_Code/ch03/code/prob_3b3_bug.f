      SUBROUTINE UHYPER_STRETCH(DLAMBDA,AJ,U,U1,U2,U3,U4,TEMP,NOEL,
     1 CMNAME,INCMPFLAG,NUMSTATEV,STATEVOLD,STATEV,NUMFIELDV,FIELDV,
     2 FIELDVINC,NUMPROPS,PROPS,I_ARRAY,NIARRAY,R_ARRAY,NRARRAY,
     3 C_ARRAY,NCARRAY)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 CMNAME,C_ARRAY(*)
      DIMENSION DLAMBDA(*),U(2),U1(4),U2(4),U3(4),U4(3),STATEVOLD(*),
     1 STATEV(*),FIELDV(*),FIELDVINC(*),PROPS(*),I_ARRAY(*),R_ARRAY(*)
!
      NT = NUMPROPS/3
      U(1) = 0.0D0
      DO I = 1, 4
         U1(I) = 0.0D0
         U2(I) = 0.0D0
         U3(I) = 0.0D0
         U4(I) = 0.0D0
      ENDDO
      DO KP = 1, NT
         XMU = PROPS(3*KP-2)
         ALP = PROPS(3*KP-1)
         D   = PROPS(3*KP)
         C0 = 2.0D0*XMU/ALP
         DO I = 1, 3
            X  = DLAMBDA(I)
            XA = X**ALP
            U(1)  = U(1) + C0*(XA - 1.0D0)
            U1(I) = U1(I) + C0*XA/X
            U2(I) = U2(I) + C0*(ALP-1.0D0)*XA/X**2
            U3(I) = U3(I) + C0*(ALP-1.0D0)*(ALP-3.0D0)*XA/X**3
            U4(I) = U4(I) + C0*(ALP-1.0D0)*(ALP-2.0D0)*
     1              (ALP-3.0D0)*XA/X**4
         ENDDO
         IF (INCMPFLAG .EQ. 0 .AND. D .GT. 0.0D0) THEN
            M = 2*KP
            U(1) = U(1) + AJ**M/D
            U1(4) = U1(4) + M*AJ**(M-1)/D
            U2(4) = U2(4) + M*AJ**(M-2)/D
         ENDIF
      ENDDO
      RETURN
      END
