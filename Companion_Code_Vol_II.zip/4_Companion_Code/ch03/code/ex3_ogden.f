      SUBROUTINE UHYPER_STRETCH(DLAMBDA,AJ,U,U1,U2,U3,U4,TEMP,NOEL,
     1 CMNAME,INCMPFLAG,NUMSTATEV,STATEVOLD,STATEV,NUMFIELDV,FIELDV,
     2 FIELDVINC,NUMPROPS,PROPS,I_ARRAY,NIARRAY,R_ARRAY,NRARRAY,
     3 C_ARRAY,NCARRAY)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME,C_ARRAY(*)
      DIMENSION DLAMBDA(*),U(2),U1(4),U2(4),U3(4),U4(3),STATEVOLD(*),
     1 STATEV(*),FIELDV(*),FIELDVINC(*),PROPS(*),I_ARRAY(*),R_ARRAY(*)
!
!     Ogden model with N = NUMPROPS/3 terms, Abaqus form:
!       U = SUM(p) 2 MU(p)/ALPHA(p)**2 *
!             (L1**ALPHA(p) + L2**ALPHA(p) + L3**ALPHA(p) - 3)
!         + SUM(p) (AJ - 1)**(2p) / D(p)
!     PROPS(3p-2) MU(p)     MPa
!     PROPS(3p-1) ALPHA(p)  -       (nonzero)
!     PROPS(3p)   D(p)      1/MPa   (D = 0: no volumetric term p)
!     Array use:  U1(i) = dU/dL(i),  U1(4) = dU/dJ, and so on.
!
      NT = NUMPROPS/3
      UD = 0.0D0
      UV = 0.0D0
      DO I = 1, 4
         U1(I) = 0.0D0
         U2(I) = 0.0D0
         U3(I) = 0.0D0
      ENDDO
      DO I = 1, 3
         U4(I) = 0.0D0
      ENDDO
      DO KP = 1, NT
         XMU = PROPS(3*KP-2)
         ALP = PROPS(3*KP-1)
         D   = PROPS(3*KP)
         IF (ALP .EQ. 0.0D0) THEN
            WRITE(7,*) 'UHYPER_STRETCH: ALPHA = 0, use the Hencky form'
            CALL XIT
         ENDIF
         C0 = 2.0D0*XMU/ALP**2
         DO I = 1, 3
            X  = DLAMBDA(I)
            XA = X**ALP
            UD = UD + C0*(XA - 1.0D0)
            U1(I) = U1(I) + C0*ALP*XA/X
            U2(I) = U2(I) + C0*ALP*(ALP-1.0D0)*XA/X**2
            U3(I) = U3(I) + C0*ALP*(ALP-1.0D0)*(ALP-2.0D0)*XA/X**3
            U4(I) = U4(I) + C0*ALP*(ALP-1.0D0)*(ALP-2.0D0)*
     1              (ALP-3.0D0)*XA/X**4
         ENDDO
         IF (INCMPFLAG .EQ. 0 .AND. D .GT. 0.0D0) THEN
            E = AJ - 1.0D0
            M = 2*KP
            UV = UV + E**M/D
            U1(4) = U1(4) + M*E**(M-1)/D
            U2(4) = U2(4) + M*(M-1)*E**(M-2)/D
            IF (M .GT. 2) U3(4) = U3(4) + M*(M-1)*(M-2)*E**(M-3)/D
         ENDIF
      ENDDO
      U(1) = UD + UV
      U(2) = UD
      RETURN
      END
