      PROGRAM K3HAND
!     Arrays U1..U4 at the undeformed state, and the moduli they imply
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION DL(3),U(2),U1(4),U2(4),U3(4),U4(3),PR(9),SV(1),FV(1)
      DIMENSION IA(1),RA(1)
      CHARACTER*80 CNAME,CA(1)
      DATA DL /1.0D0,1.0D0,1.0D0/
      DATA PR /1.0D0,2.0D0,0.02D0,0.2D0,-2.0D0,0.0D0,0.0D0,0.0D0,0.0D0/
      CNAME = 'HAND'
      CALL UHYPER_STRETCH(DL,1.0D0,U,U1,U2,U3,U4,0.0D0,1,CNAME,0,0,
     1 SV,SV,0,FV,FV,6,PR,IA,0,RA,0,CA,0)
      WRITE(*,'(A,2F12.6)') 'U(1),U(2)     ',U(1),U(2)
      WRITE(*,'(A,4F12.6)') 'U1            ',U1
      WRITE(*,'(A,4F12.6)') 'U2            ',U2
      WRITE(*,'(A,4F12.6)') 'U3            ',U3
      WRITE(*,'(A,3F12.6)') 'U4            ',U4
      WRITE(*,'(A,F12.6)') 'G = (U1+U2)/2 ',0.5D0*(U1(1)+U2(1))
      WRITE(*,'(A,F12.6)') 'K = U2(4)     ',U2(4)
      END
