#!/bin/sh
# Builds the Chapter 3 drivers (gfortran 13, stub routines)
A=/home/claude/vol2/lib/aba
F="-ffixed-form -std=legacy -I$A -g -fcheck=all"
cd "$(dirname "$0")"; mkdir -p ../out
for m in ogden hencky; do
  gfortran $F k3_drv.f k3_assemble.f ex3_$m.f $A/stubs.f -o ../out/drv_$m || exit 1
done
gfortran $F k3_alpha.f k3_assemble.f ex3_ogden.f $A/stubs.f -o ../out/drv_alpha || exit 1
