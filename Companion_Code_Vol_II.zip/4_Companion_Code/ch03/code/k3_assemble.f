      SUBROUTINE K3_EIG3(A,EV,V)
!     Eigenvalues EV and eigenvectors V (columns) of a symmetric 3x3
!     matrix A by cyclic Jacobi rotations (testing code, not Abaqus)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION A(3,3),EV(3),V(3,3),W(3,3)
      DO I = 1, 3
         DO J = 1, 3
            W(I,J) = A(I,J)
            V(I,J) = 0.0D0
         ENDDO
         V(I,I) = 1.0D0
      ENDDO
      DO ISW = 1, 40
         DO IP = 1, 2
            DO IQ = IP+1, 3
               IF (ABS(W(IP,IQ)) .GT. 1.0D-300) THEN
                  TH = (W(IQ,IQ) - W(IP,IP))/(2.0D0*W(IP,IQ))
                  T  = SIGN(1.0D0,TH)/(ABS(TH) + SQRT(TH*TH + 1.0D0))
                  C  = 1.0D0/SQRT(T*T + 1.0D0)
                  S  = T*C
                  DO K = 1, 3
                     WP = W(K,IP)
                     WQ = W(K,IQ)
                     W(K,IP) = C*WP - S*WQ
                     W(K,IQ) = S*WP + C*WQ
                  ENDDO
                  DO K = 1, 3
                     WP = W(IP,K)
                     WQ = W(IQ,K)
                     W(IP,K) = C*WP - S*WQ
                     W(IQ,K) = S*WP + C*WQ
                  ENDDO
                  DO K = 1, 3
                     VP = V(K,IP)
                     VQ = V(K,IQ)
                     V(K,IP) = C*VP - S*VQ
                     V(K,IQ) = S*VP + C*VQ
                  ENDDO
               ENDIF
            ENDDO
         ENDDO
      ENDDO
      DO I = 1, 3
         EV(I) = W(I,I)
      ENDDO
      RETURN
      END
!
      SUBROUTINE K3_DD(X,Y,PHX,PHY,P1X,P1Y,P2X,P2Y,P3X,P3Y,IMODE,DD)
!     Divided difference (PH(X)-PH(Y))/(X-Y) of PH(X) = X*W'(X).
!     P1, P2, P3 are the first three derivatives of PH at X and Y.
!     IMODE 1: direct quotient (0/0 for X = Y)
!     IMODE 2: mean of the slopes at the two points   (uses U2)
!     IMODE 3: slopes, curvatures and third derivatives at both
!              points, error of order (X-Y)**4          (uses U2..U4)
      INCLUDE 'ABA_PARAM.INC'
      H = Y - X
      IF (IMODE .EQ. 1) THEN
         DD = (PHY - PHX)/H
      ELSE IF (IMODE .EQ. 2) THEN
         DD = 0.5D0*(P1X + P1Y)
      ELSE
         DD = 0.5D0*(P1X + P1Y) + 0.25D0*H*(P2X - P2Y)
     1      + H*H*(P3X + P3Y)/12.0D0
      ENDIF
      RETURN
      END
!
      SUBROUTINE K3_MAT(F,INCMP,NPR,PR,TEMP,IMODE,THR,W,SIG,CT)
!     The part of Abaqus that this chapter has to play: from F to the
!     principal stretches, a call of UHYPER_STRETCH, the Cauchy stress
!     SIG and the spatial tangent CT (Lie derivative of Kirchhoff
!     stress per unit current volume, c_ijkl).  IMODE selects the
!     divided difference used for a pair of stretches whose relative
!     gap |X-Y|/(0.5(X+Y)) is below THR: 2 or 3 as in K3_DD, 1 direct.
!     Production use: IMODE = 3, THR = 1.D-3.
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3),PR(*),SIG(3,3),CT(3,3,3,3)
      DIMENSION B(3,3),EV(3),V(3,3),DL(3),U(2),U1(4),U2(4),U3(4)
      DIMENSION U4(3),PH(3),PS(3),TAU(3),A(3,3),G(3,3),SV(1),FV(1)
      DIMENSION IA(1),RA(1)
      CHARACTER*80 CNAME,CA(1)
      CNAME = 'K3'
      DO I = 1, 3
         DO J = 1, 3
            B(I,J) = 0.0D0
            DO K = 1, 3
               B(I,J) = B(I,J) + F(I,K)*F(J,K)
            ENDDO
         ENDDO
      ENDDO
      AJ = F(1,1)*(F(2,2)*F(3,3) - F(2,3)*F(3,2))
     1   - F(1,2)*(F(2,1)*F(3,3) - F(2,3)*F(3,1))
     2   + F(1,3)*(F(2,1)*F(3,2) - F(2,2)*F(3,1))
      CALL K3_EIG3(B,EV,V)
      FAC = AJ**(-1.0D0/3.0D0)
      DO I = 1, 3
         DL(I) = SQRT(EV(I))*FAC
      ENDDO
      SV(1) = 0.0D0
      CALL UHYPER_STRETCH(DL,AJ,U,U1,U2,U3,U4,TEMP,1,CNAME,INCMP,0,
     1 SV,SV,0,FV,FV,NPR,PR,IA,0,RA,0,CA,0)
      W = U(1)
      VOL = 1.0D0
      IF (INCMP .NE. 0) VOL = 0.0D0
      SPH = 0.0D0
      SPS = 0.0D0
      DO I = 1, 3
         PH(I) = DL(I)*U1(I)
         PS(I) = DL(I)*(U1(I) + DL(I)*U2(I))
         SPH = SPH + PH(I)
         SPS = SPS + PS(I)
      ENDDO
      DO I = 1, 3
         TAU(I) = PH(I) - SPH/3.0D0 + VOL*AJ*U1(4)
      ENDDO
!     d tau(a)/d ln L(b), minus 2 tau(a) on the diagonal
      DO I = 1, 3
         DO J = 1, 3
            A(I,J) = -(PS(I) + PS(J))/3.0D0 + SPS/9.0D0
     1             + VOL*AJ*(U1(4) + AJ*U2(4))
         ENDDO
         A(I,I) = A(I,I) + PS(I) - 2.0D0*TAU(I)
      ENDDO
!     shear coefficients g(a,b) = (tau(a) L(b)**2 - tau(b) L(a)**2)
!                                 / (L(a)**2 - L(b)**2)
      DO I = 1, 3
         DO J = 1, 3
            G(I,J) = 0.0D0
            IF (I .NE. J) THEN
               X = DL(I)
               Y = DL(J)
               MD = 1
               IF (ABS(X-Y) .LT. THR*0.5D0*(X+Y)) MD = IMODE
               P1X = U1(I) + X*U2(I)
               P1Y = U1(J) + Y*U2(J)
               P2X = 2.0D0*U2(I) + X*U3(I)
               P2Y = 2.0D0*U2(J) + Y*U3(J)
               P3X = 3.0D0*U3(I) + X*U4(I)
               P3Y = 3.0D0*U3(J) + Y*U4(J)
               CALL K3_DD(X,Y,PH(I),PH(J),P1X,P1Y,P2X,P2Y,P3X,P3Y,MD,DD)
!              (tau(a)-tau(b))/(l(a)^2-l(b)^2), l(a)^2 = J^(2/3) X^2
               GAB = DD/((X + Y)*AJ**(2.0D0/3.0D0))
               G(I,J) = GAB*EV(J) - TAU(J)
            ENDIF
         ENDDO
      ENDDO
      DO I = 1, 3
         DO J = 1, 3
            SIG(I,J) = 0.0D0
            DO IA3 = 1, 3
               SIG(I,J) = SIG(I,J) + TAU(IA3)*V(I,IA3)*V(J,IA3)/AJ
            ENDDO
         ENDDO
      ENDDO
      DO I = 1, 3
         DO J = 1, 3
            DO K = 1, 3
               DO L = 1, 3
                  S = 0.0D0
                  DO IA3 = 1, 3
                     DO IB3 = 1, 3
                        S = S + A(IA3,IB3)*V(I,IA3)*V(J,IA3)*
     1                      V(K,IB3)*V(L,IB3)
                        IF (IA3 .NE. IB3) S = S + G(IA3,IB3)*(
     1                      V(I,IA3)*V(J,IB3)*V(K,IA3)*V(L,IB3) +
     2                      V(I,IA3)*V(J,IB3)*V(K,IB3)*V(L,IA3))
                     ENDDO
                  ENDDO
                  CT(I,J,K,L) = S/AJ
               ENDDO
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
