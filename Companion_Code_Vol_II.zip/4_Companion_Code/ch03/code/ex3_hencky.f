      SUBROUTINE UHYPER_STRETCH(DLAMBDA,AJ,U,U1,U2,U3,U4,TEMP,NOEL,
     1 CMNAME,INCMPFLAG,NUMSTATEV,STATEVOLD,STATEV,NUMFIELDV,FIELDV,
     2 FIELDVINC,NUMPROPS,PROPS,I_ARRAY,NIARRAY,R_ARRAY,NRARRAY,
     3 C_ARRAY,NCARRAY)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME,C_ARRAY(*)
      DIMENSION DLAMBDA(*),U(2),U1(4),U2(4),U3(4),U4(3),STATEVOLD(*),
     1 STATEV(*),FIELDV(*),FIELDVINC(*),PROPS(*),I_ARRAY(*),R_ARRAY(*)
!
!     Hencky (logarithmic strain) energy, Valanis-Landel form:
!       U = MU SUM(i) (LN L(i))**2 + K/2 (LN J)**2
!     MU = MU0 (1 + BETA (TEMP - T0))
!     PROPS(1) MU0 (MPa)   PROPS(2) K (MPa, ignored if incompressible)
!     PROPS(3) BETA (1/K)  PROPS(4) T0 (K or degC, as TEMP)
!
      XMU = PROPS(1)*(1.0D0 + PROPS(3)*(TEMP - PROPS(4)))
      XK  = PROPS(2)
      UD = 0.0D0
      DO I = 1, 3
         X  = DLAMBDA(I)
         EL = LOG(X)
         UD = UD + XMU*EL**2
         U1(I) = 2.0D0*XMU*EL/X
         U2(I) = 2.0D0*XMU*(1.0D0 - EL)/X**2
         U3(I) = 2.0D0*XMU*(2.0D0*EL - 3.0D0)/X**3
         U4(I) = 2.0D0*XMU*(11.0D0 - 6.0D0*EL)/X**4
      ENDDO
      U1(4) = 0.0D0
      U2(4) = 0.0D0
      U3(4) = 0.0D0
      UV = 0.0D0
      IF (INCMPFLAG .EQ. 0) THEN
         EJ = LOG(AJ)
         UV = 0.5D0*XK*EJ**2
         U1(4) = XK*EJ/AJ
         U2(4) = XK*(1.0D0 - EJ)/AJ**2
         U3(4) = XK*(2.0D0*EJ - 3.0D0)/AJ**3
      ENDIF
      U(1) = UD + UV
      U(2) = UD
      RETURN
      END
