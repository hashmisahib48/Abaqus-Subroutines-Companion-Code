      PROGRAM K3DRV
!     Driver for UHYPER_STRETCH routines (Chapter 3).  Reads the model
!     from props_<tag>.txt and writes out/<tag>_*.dat.
!        line 1:  INCMP  NPROPS  TEMP      line 2:  PROPS(1..NPROPS)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*80 TAG
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      CALL GET_COMMAND_ARGUMENT(1,TAG)
      OPEN(10,FILE='props_'//TRIM(TAG)//'.txt',STATUS='OLD')
      READ(10,*) INCMP,NPR,TEMP
      READ(10,*) (PR(I),I=1,NPR)
      CLOSE(10)
      CALL T_DERIV(TRIM(TAG))
      CALL T_HOM(TRIM(TAG))
      CALL T_GEN(TRIM(TAG))
      CALL T_TANG(TRIM(TAG))
      CALL T_DEGEN(TRIM(TAG))
      CALL T_GRID(TRIM(TAG))
      END
!
      SUBROUTINE EVAL(DL,AJ,U,U1,U2,U3,U4)
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION DL(3),U(2),U1(4),U2(4),U3(4),U4(3),SV(1),FV(1),IA(1)
      DIMENSION RA(1)
      CHARACTER*80 CNAME,CA(1)
      CNAME = 'K3'
      SV(1) = 0.0D0
      CALL UHYPER_STRETCH(DL,AJ,U,U1,U2,U3,U4,TEMP,1,CNAME,INCMP,0,
     1 SV,SV,0,FV,FV,NPR,PR,IA,0,RA,0,CA,0)
      RETURN
      END
!
      SUBROUTINE T_DERIV(TAG)
!     finite-difference test of U1..U4 and of the Valanis-Landel form
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) TAG
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION DL(3),D2(3),U(2),U1(4),U2(4),U3(4),U4(3)
      DIMENSION UP(2),UP1(4),UP2(4),UP3(4),UP4(3)
      DIMENSION UM(2),UM1(4),UM2(4),UM3(4),UM4(3),E(7),Q(7)
      DATA DL /1.25D0,0.90D0,0.70D0/
      AJ = 1.08D0
      CALL EVAL(DL,AJ,U,U1,U2,U3,U4)
      OPEN(11,FILE='../out/'//TAG//'_deriv.dat')
      DO K = 1, 10
         HR = 10.0D0**(-K)
         HX = HR*DL(1)
         HJ = HR*AJ
         D2 = DL
         D2(1) = DL(1) + HX
         CALL EVAL(D2,AJ,UP,UP1,UP2,UP3,UP4)
         D2(1) = DL(1) - HX
         CALL EVAL(D2,AJ,UM,UM1,UM2,UM3,UM4)
         Q(1) = (UP(1)-UM(1))/(2*HX)
         Q(2) = (UP1(1)-UM1(1))/(2*HX)
         Q(3) = (UP2(1)-UM2(1))/(2*HX)
         Q(4) = (UP3(1)-UM3(1))/(2*HX)
         CALL EVAL(DL,AJ+HJ,UP,UP1,UP2,UP3,UP4)
         CALL EVAL(DL,AJ-HJ,UM,UM1,UM2,UM3,UM4)
         Q(5) = (UP(1)-UM(1))/(2*HJ)
         Q(6) = (UP1(4)-UM1(4))/(2*HJ)
         Q(7) = (UP2(4)-UM2(4))/(2*HJ)
         E(1) = ABS(Q(1)-U1(1))/ABS(U1(1))
         E(2) = ABS(Q(2)-U2(1))/ABS(U2(1))
         E(3) = ABS(Q(3)-U3(1))/ABS(U3(1))
         E(4) = ABS(Q(4)-U4(1))/ABS(U4(1))
         DO I = 5, 7
            E(I) = 0.0D0
         ENDDO
         IF (INCMP .EQ. 0) THEN
            E(5) = ABS(Q(5)-U1(4))/ABS(U1(4))
            E(6) = ABS(Q(6)-U2(4))/ABS(U2(4))
            IF (ABS(U3(4)) .GT. 0.0D0)
     1         E(7) = ABS(Q(7)-U3(4))/ABS(U3(4))
         ENDIF
         WRITE(11,'(I3,7ES14.5)') K,(E(I),I=1,7)
      ENDDO
      CLOSE(11)
!     mixed second differences of U(1): zero for a Valanis-Landel form
      H1 = 1.0D-4
      OPEN(12,FILE='../out/'//TAG//'_mixed.dat')
      DO IP = 1, 4
         CALL MIXED(DL,AJ,IP,H1,XM)
         WRITE(12,'(I3,ES14.5)') IP,XM
      ENDDO
      WRITE(12,'(A,ES14.5)') ' scale max|U2| ',
     1   MAX(ABS(U2(1)),ABS(U2(2)),ABS(U2(3)))
      CLOSE(12)
      RETURN
      END
!
      SUBROUTINE MIXED(DL,AJ,IP,H1,XM)
!     IP 1: (L1,L2)  2: (L1,L3)  3: (L2,L3)  4: (L1,J)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION DL(3),D2(3),U(2),U1(4),U2(4),U3(4),U4(3),V(4)
      DIMENSION IAA(4),IBB(4)
      DATA IAA /1,1,2,1/, IBB /2,3,3,4/
      IA = IAA(IP)
      IB = IBB(IP)
      K = 0
      DO SA = -1.0D0, 1.0D0, 2.0D0
         DO SB = -1.0D0, 1.0D0, 2.0D0
            K = K + 1
            D2 = DL
            AJ2 = AJ
            D2(IA) = DL(IA)*(1.0D0 + SA*H1)
            IF (IB .LE. 3) THEN
               D2(IB) = DL(IB)*(1.0D0 + SB*H1)
            ELSE
               AJ2 = AJ*(1.0D0 + SB*H1)
            ENDIF
            CALL EVAL(D2,AJ2,U,U1,U2,U3,U4)
            V(K) = U(1)
         ENDDO
      ENDDO
      XA = DL(IA)*H1
      IF (IB .LE. 3) THEN
         XB = DL(IB)*H1
      ELSE
         XB = AJ*H1
      ENDIF
      XM = (V(4) - V(3) - V(2) + V(1))/(4.0D0*XA*XB)
      RETURN
      END
!
      SUBROUTINE T_HOM(TAG)
!     homogeneous states: uniaxial, equibiaxial, planar (incompressible)
!     or uniaxial stress with free lateral stretch (compressible)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) TAG
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION F(3,3),SIG(3,3),CT(3,3,3,3)
      OPEN(11,FILE='../out/'//TAG//'_hom.dat')
      DO N = 0, 50
         XL = 1.0D0 + 0.1D0*N
         IF (INCMP .NE. 0) THEN
!           uniaxial, equibiaxial, planar
            F = 0.0D0
            F(1,1) = XL
            F(2,2) = XL**(-0.5D0)
            F(3,3) = XL**(-0.5D0)
            CALL K3_MAT(F,INCMP,NPR,PR,TEMP,3,1.0D-3,W,SIG,CT)
            P1 = (SIG(1,1) - SIG(2,2))/XL
            F(2,2) = XL
            F(3,3) = XL**(-2)
            CALL K3_MAT(F,INCMP,NPR,PR,TEMP,3,1.0D-3,W,SIG,CT)
            P2 = (SIG(1,1) - SIG(3,3))/XL
            F(2,2) = 1.0D0
            F(3,3) = 1.0D0/XL
            CALL K3_MAT(F,INCMP,NPR,PR,TEMP,3,1.0D-3,W,SIG,CT)
            P3 = (SIG(1,1) - SIG(3,3))/XL
            P3L = SIG(2,2) - SIG(3,3)
            WRITE(11,'(F10.5,4ES24.15)') XL,P1,P2,P3,P3L
         ELSE
!           uniaxial stress: secant iteration on the lateral stretch
            XA = XL**(-0.5D0)
            XB = XA*1.01D0
            FA = SLAT(XL,XA)
            FB = SLAT(XL,XB)
            DO IT = 1, 60
               IF (ABS(FB-FA) .LT. 1.0D-300) EXIT
               XC = XB - FB*(XB-XA)/(FB-FA)
               XA = XB
               FA = FB
               XB = XC
               FB = SLAT(XL,XB)
               IF (ABS(FB) .LT. 1.0D-14) EXIT
            ENDDO
            F = 0.0D0
            F(1,1) = XL
            F(2,2) = XB
            F(3,3) = XB
            CALL K3_MAT(F,INCMP,NPR,PR,TEMP,3,1.0D-3,W,SIG,CT)
            WRITE(11,'(F10.5,4ES24.15)') XL,XB,XL*XB*XB,SIG(1,1),
     1         SIG(2,2)
         ENDIF
      ENDDO
      CLOSE(11)
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION SLAT(XL,XT)
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION F(3,3),SIG(3,3),CT(3,3,3,3)
      F = 0.0D0
      F(1,1) = XL
      F(2,2) = XT
      F(3,3) = XT
      CALL K3_MAT(F,INCMP,NPR,PR,TEMP,3,1.0D-3,W,SIG,CT)
      SLAT = SIG(2,2)
      RETURN
      END
!
      SUBROUTINE T_GEN(TAG)
!     stress in general (non-coaxial) deformations
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) TAG
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION F(3,3),F0(3,3,3),SIG(3,3),CT(3,3,3,3)
      DATA F0 /1.30D0,-0.15D0,0.05D0, 0.20D0,0.85D0,-0.10D0,
     1 -0.10D0,0.25D0,0.95D0,
     2 1.0D0,0.0D0,0.0D0, 0.5D0,1.0D0,0.0D0, 0.0D0,0.0D0,1.0D0,
     3 1.8D0,0.3D0,0.0D0, -0.2D0,0.7D0,0.4D0, 0.0D0,-0.3D0,1.1D0/
      OPEN(11,FILE='../out/'//TAG//'_gen.dat')
      DO N = 1, 3
         F = F0(:,:,N)
         AJ = F(1,1)*(F(2,2)*F(3,3) - F(2,3)*F(3,2))
     1      - F(1,2)*(F(2,1)*F(3,3) - F(2,3)*F(3,1))
     2      + F(1,3)*(F(2,1)*F(3,2) - F(2,2)*F(3,1))
         IF (INCMP .NE. 0) F = F*AJ**(-1.0D0/3.0D0)
         CALL K3_MAT(F,INCMP,NPR,PR,TEMP,3,1.0D-3,W,SIG,CT)
         WRITE(11,'(I2,9ES24.15)') N,((F(I,J),I=1,3),J=1,3)
         WRITE(11,'(2X,9ES24.15)') ((SIG(I,J),I=1,3),J=1,3)
         WRITE(11,'(2X,ES24.15)') W
      ENDDO
      CLOSE(11)
      RETURN
      END
!
      SUBROUTINE LIETAN(F,IMODE,THR,ERR,CMAX)
!     compare CT with the finite difference of the Kirchhoff stress
      INCLUDE 'ABA_PARAM.INC'
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION F(3,3),FP(3,3),FM(3,3),D(3,3),SIG(3,3),CT(3,3,3,3)
      DIMENSION TP(3,3),TM(3,3),SD(3,3,3,3),DS(3,3),SDD(3,3)
      CALL K3_MAT(F,INCMP,NPR,PR,TEMP,IMODE,THR,W,SIG,CT)
      AJ = F(1,1)*(F(2,2)*F(3,3) - F(2,3)*F(3,2))
     1   - F(1,2)*(F(2,1)*F(3,3) - F(2,3)*F(3,1))
     2   + F(1,3)*(F(2,1)*F(3,2) - F(2,2)*F(3,1))
      EPS = 1.0D-6
      ERR = 0.0D0
      CMAX = 0.0D0
      IF (CT(1,1,1,1) .NE. CT(1,1,1,1)) THEN
         ERR = CT(1,1,1,1)
         CMAX = ERR
         RETURN
      ENDIF
      DO I = 1, 3
         DO J = 1, 3
            DO K = 1, 3
               DO L = 1, 3
                  CMAX = MAX(CMAX,ABS(CT(I,J,K,L))*AJ)
               ENDDO
            ENDDO
         ENDDO
      ENDDO
      DO IV = 1, 6
         D = 0.0D0
         IF (IV .LE. 3) THEN
            D(IV,IV) = 1.0D0
         ELSE
            I = IV - 3
            J = MOD(I,3) + 1
            D(I,J) = 0.5D0
            D(J,I) = 0.5D0
         ENDIF
         FP = F + EPS*MATMUL(D,F)
         FM = F - EPS*MATMUL(D,F)
         CALL K3_MAT(FP,INCMP,NPR,PR,TEMP,IMODE,THR,WP,TP,SD)
         AJP = FP(1,1)*(FP(2,2)*FP(3,3) - FP(2,3)*FP(3,2))
     1      - FP(1,2)*(FP(2,1)*FP(3,3) - FP(2,3)*FP(3,1))
     2      + FP(1,3)*(FP(2,1)*FP(3,2) - FP(2,2)*FP(3,1))
         CALL K3_MAT(FM,INCMP,NPR,PR,TEMP,IMODE,THR,WM,TM,SD)
         AJM = FM(1,1)*(FM(2,2)*FM(3,3) - FM(2,3)*FM(3,2))
     1      - FM(1,2)*(FM(2,1)*FM(3,3) - FM(2,3)*FM(3,1))
     2      + FM(1,3)*(FM(2,1)*FM(3,2) - FM(2,2)*FM(3,1))
         DS = MATMUL(D,SIG) + MATMUL(SIG,D)
         DO I = 1, 3
            DO J = 1, 3
!              d(tau)/dt - d tau - tau d  =  c : d  (Kirchhoff)
               DT = (AJP*TP(I,J) - AJM*TM(I,J))/(2*EPS)
               DT = DT - AJ*DS(I,J)
               CD = 0.0D0
               DO K = 1, 3
                  DO L = 1, 3
                     CD = CD + AJ*CT(I,J,K,L)*D(K,L)
                  ENDDO
               ENDDO
               ERR = MAX(ERR,ABS(DT-CD))
            ENDDO
         ENDDO
      ENDDO
      RETURN
      END
!
      SUBROUTINE T_TANG(TAG)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) TAG
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION F(3,3),FQ(3,3),QT(3,3)
      DATA F /1.30D0,-0.15D0,0.05D0, 0.20D0,0.85D0,-0.10D0,
     1 -0.10D0,0.25D0,0.95D0/
      CALL K3ROT(QT)
      OPEN(11,FILE='../out/'//TAG//'_tang.dat')
      AJ = F(1,1)*(F(2,2)*F(3,3) - F(2,3)*F(3,2))
     1   - F(1,2)*(F(2,1)*F(3,3) - F(2,3)*F(3,1))
     2   + F(1,3)*(F(2,1)*F(3,2) - F(2,2)*F(3,1))
      IF (INCMP .NE. 0) F = F*AJ**(-1.0D0/3.0D0)
      DO IM = 1, 3, 2
         CALL LIETAN(F,IM,1.0D-3,ERR,CMAX)
         WRITE(11,'(I3,2ES16.6)') IM,ERR,CMAX
      ENDDO
!     coaxial-rotated states with nearly equal stretches
      DO KD = 1, 3
         DEL = 0.0D0
         IF (KD .EQ. 1) DEL = 1.0D-12
         IF (KD .EQ. 2) DEL = 1.0D-6
         X1 = 1.4D0*(1.0D0 + 0.5D0*DEL)
         X2 = 1.4D0*(1.0D0 - 0.5D0*DEL)
         X3 = 0.8D0
         IF (INCMP .NE. 0) X3 = 1.0D0/(X1*X2)
         DO I = 1, 3
            DO J = 1, 3
               FQ(I,J) = QT(I,1)*X1*QT(J,1) + QT(I,2)*X2*QT(J,2)
     1                 + QT(I,3)*X3*QT(J,3)
            ENDDO
         ENDDO
         DO IM = 1, 3, 2
            CALL LIETAN(FQ,IM,1.0D-3,ERR,CMAX)
            WRITE(11,'(I3,2ES16.6,ES10.1)') IM,ERR,CMAX,DEL
         ENDDO
      ENDDO
      CLOSE(11)
      RETURN
      END
!
      SUBROUTINE K3ROT(Q)
!     a fixed rotation: axis (1,2,2)/3, angle 0.7 rad
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION Q(3,3)
      A = 0.7D0
      C = COS(A)
      S = SIN(A)
      V1 = 1.0D0/3.0D0
      V2 = 2.0D0/3.0D0
      Q(1,1) = C + V1*V1*(1-C)
      Q(1,2) = V1*V2*(1-C) - V2*S
      Q(1,3) = V1*V2*(1-C) + V2*S
      Q(2,1) = V1*V2*(1-C) + V2*S
      Q(2,2) = C + V2*V2*(1-C)
      Q(2,3) = V2*V2*(1-C) - V1*S
      Q(3,1) = V1*V2*(1-C) - V2*S
      Q(3,2) = V2*V2*(1-C) + V1*S
      Q(3,3) = C + V2*V2*(1-C)
      RETURN
      END
!
      SUBROUTINE T_DEGEN(TAG)
!     equal-stretch sweep: lambda1 = L(1+d/2), lambda2 = L(1-d/2)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) TAG
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION F(3,3),FQ(3,3),Q(3,3),SIG(3,3),CT(3,3,3,3)
      DIMENSION CD(3,3,3,3),CQ(3,3,3,3),CR(3,3,3,3),GG(3),ER(4)
      DIMENSION CREF(3,3,3,3)
      CALL K3ROT(Q)
      OPEN(11,FILE='../out/'//TAG//'_degen.dat')
      DO K = 0, 30
         IF (K .EQ. 0) THEN
            DEL = 0.0D0
         ELSE
            DEL = 10.0D0**(-(K-1)*0.5D0)
         ENDIF
         XL = 1.4D0
         X1 = XL*(1.0D0 + 0.5D0*DEL)
         X2 = XL*(1.0D0 - 0.5D0*DEL)
         X3 = 0.8D0
         IF (INCMP .NE. 0) X3 = 1.0D0/(X1*X2)
!        reference: diagonal F, mode 3
         F = 0.0D0
         F(1,1) = X1
         F(2,2) = X2
         F(3,3) = X3
         CALL K3_MAT(F,INCMP,NPR,PR,TEMP,3,1.0D-3,W,SIG,CREF)
         CMAX = MAXVAL(ABS(CREF))
!        F = Q diag Q^T
         DO I = 1, 3
            DO J = 1, 3
               FQ(I,J) = Q(I,1)*X1*Q(J,1) + Q(I,2)*X2*Q(J,2)
     1                 + Q(I,3)*X3*Q(J,3)
            ENDDO
         ENDDO
         DO IM = 1, 3
            CALL K3_MAT(F,INCMP,NPR,PR,TEMP,IM,0.4D0,W,SIG,CD)
            GG(IM) = CD(1,2,1,2)
            CALL K3_MAT(FQ,INCMP,NPR,PR,TEMP,IM,0.4D0,W,SIG,CQ)
            ER(IM) = TENERR(CQ,CREF,Q,CMAX)
         ENDDO
         CALL K3_MAT(FQ,INCMP,NPR,PR,TEMP,3,1.0D-3,W,SIG,CQ)
         ER(4) = TENERR(CQ,CREF,Q,CMAX)
         WRITE(11,'(ES11.3,3ES25.16,4ES12.3)') DEL,(GG(I),I=1,3),
     1      (ER(I),I=1,4)
      ENDDO
      CLOSE(11)
      RETURN
      END
!
      DOUBLE PRECISION FUNCTION TENERR(CQ,CREF,Q,CMAX)
!     max |CQ - Q*CREF| / CMAX, (Q*C)_ijkl = Q_ip Q_jq Q_kr Q_ls C_pqrs
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION CQ(3,3,3,3),CREF(3,3,3,3),Q(3,3),T1(3,3,3,3)
      DIMENSION T2(3,3,3,3),T3(3,3,3,3),T4(3,3,3,3)
      T1 = 0.0D0
      T2 = 0.0D0
      T3 = 0.0D0
      T4 = 0.0D0
      DO I = 1, 3
        DO P = 1, 3
          T1(I,:,:,:) = T1(I,:,:,:) + Q(I,P)*CREF(P,:,:,:)
        ENDDO
      ENDDO
      DO J = 1, 3
        DO P = 1, 3
          T2(:,J,:,:) = T2(:,J,:,:) + Q(J,P)*T1(:,P,:,:)
        ENDDO
      ENDDO
      DO K = 1, 3
        DO P = 1, 3
          T3(:,:,K,:) = T3(:,:,K,:) + Q(K,P)*T2(:,:,P,:)
        ENDDO
      ENDDO
      DO L = 1, 3
        DO P = 1, 3
          T4(:,:,:,L) = T4(:,:,:,L) + Q(L,P)*T3(:,:,:,P)
        ENDDO
      ENDDO
      TENERR = MAXVAL(ABS(CQ - T4))/CMAX
      RETURN
      END
!
      SUBROUTINE T_GRID(TAG)
!     arrays U1, U2 on a grid of logarithmic strains (stability maps)
      INCLUDE 'ABA_PARAM.INC'
      CHARACTER*(*) TAG
      COMMON /K3P/ PR(30),TEMP,INCMP,NPR
      DIMENSION DL(3),U(2),U1(4),U2(4),U3(4),U4(3)
      IF (INCMP .EQ. 0) RETURN
      OPEN(11,FILE='../out/'//TAG//'_grid.dat')
      DO I = 0, 60
         E1 = -1.5D0 + 0.05D0*I
         DO J = 0, 60
            E2 = -1.5D0 + 0.05D0*J
            DL(1) = EXP(E1)
            DL(2) = EXP(E2)
            DL(3) = EXP(-E1-E2)
            CALL EVAL(DL,1.0D0,U,U1,U2,U3,U4)
            WRITE(11,'(2F8.3,6ES22.14)') E1,E2,(U1(K),K=1,3),
     1         (U2(K),K=1,3)
         ENDDO
      ENDDO
      CLOSE(11)
      RETURN
      END
