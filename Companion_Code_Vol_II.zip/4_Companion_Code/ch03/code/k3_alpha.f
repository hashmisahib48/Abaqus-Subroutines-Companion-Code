      PROGRAM K3ALPHA
!     Ogden term with ALPHA -> 0 against the Hencky limit (Section 3.8)
      INCLUDE 'ABA_PARAM.INC'
      DIMENSION F(3,3),SIG(3,3),CT(3,3,3,3),PR(3)
      OPEN(11,FILE='../out/alpha.dat')
      DO K = -1, 13
         ALP = 10.0D0**(-K)
         IF (K .EQ. -1) ALP = 2.0D0
         PR(1) = 1.0D0
         PR(2) = ALP
         PR(3) = 0.0D0
         F = 0.0D0
         F(1,1) = 2.0D0
         F(2,2) = 2.0D0**(-0.5D0)
         F(3,3) = 2.0D0**(-0.5D0)
         CALL K3_MAT(F,1,3,PR,0.0D0,3,1.0D-3,W,SIG,CT)
         WRITE(11,'(ES10.2,2ES25.16)') ALP,SIG(1,1)-SIG(2,2),W
      ENDDO
      CLOSE(11)
      END
