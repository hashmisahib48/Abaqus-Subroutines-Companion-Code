"""Builds single-bug variants of the Ogden routine and runs the driver on each (Problem 3B.3)."""
import subprocess, re, os, json
code='/home/claude/vol2/ch03/code/'; A='/home/claude/vol2/lib/aba'
ref=open(code+'ex3_ogden.f').read()
def variant(n):
    s=ref
    if n==1: s=s.replace("UD = UD + C0*(XA - 1.0D0)","UD = UD + C0*ALP*(XA - 1.0D0)/ALP**2*ALP")  # placeholder replaced below
    return s
# ---- hand-written single-bug variants (textual edits of the correct routine)
V={}
V[1]=ref.replace("C0 = 2.0D0*XMU/ALP**2","C0 = 2.0D0*XMU/ALP**2").replace("UD = UD + C0*(XA - 1.0D0)","UD = UD + 2.0D0*XMU/ALP*(XA - 1.0D0)")
V[2]=ref.replace("U3(I) = U3(I) + C0*ALP*(ALP-1.0D0)*(ALP-2.0D0)*XA/X**3","U3(I) = U3(I) + C0*ALP*(ALP-1.0D0)*(ALP-3.0D0)*XA/X**3")
V[3]=ref.replace("      DO I = 1, 3\n         U4(I) = 0.0D0\n      ENDDO","      DO I = 1, 4\n         U4(I) = 0.0D0\n      ENDDO")
V[4]=ref.replace("E = AJ - 1.0D0","E = AJ")
V[5]=ref.replace("U2(4) = U2(4) + M*(M-1)*E**(M-2)/D","U2(4) = U2(4) + M*E**(M-2)/D")
V[6]=ref.replace("      U(2) = UD\n","")
out={}
for n,s in V.items():
    assert s!=ref or n==1, n
    f=f'/home/claude/vol2/ch03/out/bug{n}.f'; open(f,'w').write(s)
    exe=f'/home/claude/vol2/ch03/out/drvbug{n}'
    r=subprocess.run(f"gfortran -ffixed-form -std=legacy -I{A} -g -fcheck=all {code}k3_drv.f {code}k3_assemble.f {f} {A}/stubs.f -o {exe}",shell=True,capture_output=True,text=True)
    if r.returncode: print(n,'compile failed',r.stderr[:500]); continue
    res={}
    for tag in ('mrc','ogd3c'):
        r=subprocess.run(f"cd {code} && {exe} {tag}",shell=True,capture_output=True,text=True)
        res[tag]={'rc':r.returncode,'err':r.stderr.strip().split('\n')[0:3],'files':{k:open(f'/home/claude/vol2/ch03/out/{tag}_{k}.dat').read() if os.path.exists(f'/home/claude/vol2/ch03/out/{tag}_{k}.dat') else None for k in ('deriv','hom','gen')}}
    out[n]=res
    print('--- bug',n)
    for tag in res:
        print(tag,'rc',res[tag]['rc'],res[tag]['err'])
        d=res[tag]['files']['deriv']
        if d: print(' deriv h=1e-5 row:',d.split('\n')[4])
# regenerate correct outputs afterwards
subprocess.run(f"cd {code} && ./build.sh && for t in mrc mri ogd3 ogd3c; do ../out/drv_ogden $t; done",shell=True)
