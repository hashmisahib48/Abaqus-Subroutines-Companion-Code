"""Independent checks of the Fortran driver output (Chapter 3).
Closed forms and reference values are computed here, in Python, without
using the Fortran routines."""
import numpy as np, json, mpmath as mp
from scipy.optimize import brentq
O='../out/'
C10,C01,D1=0.5,0.1,0.02
R={}
def load(n): return np.loadtxt(O+n)
# ---------- Mooney-Rivlin as Ogden N=2, incompressible ----------
h=load('mri_hom.dat'); L=h[:,0]
Pu=2*(L-L**-2)*(C10+C01/L); Pb=2*(L-L**-5)*(C10+C01*L**2); Pp=2*(L-L**-3)*(C10+C01)
Ql=2*C10*(1-L**-2)+2*C01*(L**2-1)
def rel(a,b): return np.max(np.abs(a-b)/np.maximum(np.abs(b),1e-12)) if True else 0
R['mr']={'uni':float(np.max(np.abs(h[:,1]-Pu))),'bi':float(np.max(np.abs(h[:,2]-Pb))),'pl':float(np.max(np.abs(h[:,3]-Pp))),'plq':float(np.max(np.abs(h[:,4]-Ql))),
 'maxP':float(Pb.max()),'lmax':float(L.max()),'P_uni_at2':None}
# ---------- three-term Ogden (Treloar set, Abaqus mu) ----------
mu=np.array([0.4017,0.00295,0.00981]); al=np.array([1.3,5.0,-2.0])
h=load('ogd3_hom.dat'); L=h[:,0]
def S(f): return sum(2*m/a*f(a) for m,a in zip(mu,al))
Pu=S(lambda a:L**(a-1)-L**(-a/2-1)); Pb=S(lambda a:L**(a-1)-L**(-2*a-1)); Pp=S(lambda a:L**(a-1)-L**(-a-1))
R['og3']={'uni':float(np.max(np.abs(h[:,1]-Pu))),'bi':float(np.max(np.abs(h[:,2]-Pb))),'pl':float(np.max(np.abs(h[:,3]-Pp))),
 'mu0':float(mu.sum()),'maxPu':float(Pu.max()), 'Pu':Pu.tolist(),'Pb':Pb.tolist(),'Pp':Pp.tolist(),'L':L.tolist()}
# ---------- Hencky incompressible ----------
h=load('hi_hom.dat'); L=h[:,0]; mu0=1.0*(1-0.003*(20-20))
R['hi']={'uni':float(np.max(np.abs(h[:,1]-3*mu0*np.log(L)/L))),'bi':float(np.max(np.abs(h[:,2]-6*mu0*np.log(L)/L))),
  'pl':float(np.max(np.abs(h[:,3]-4*mu0*np.log(L)/L))),'plq':float(np.max(np.abs(h[:,4]-2*mu0*np.log(L)*0 - 0))) }
# planar Hencky: s11-s33 = 2mu(ln L - ln(1/L)) = 4 mu lnL ; s22-s33 = 2mu(0 - ln(1/L)) = 2 mu ln L
R['hi']['plq']=float(np.max(np.abs(h[:,4]-2*mu0*np.log(L))))
# ---------- general F: energy by independent finite differences ----------
def Wmr(F):
    J=np.linalg.det(F); B=F@F.T; Bb=B*J**(-2/3); I1=np.trace(Bb); I2=0.5*(I1**2-np.trace(Bb@Bb))
    return C10*(I1-3)+C01*(I2-3)+(J-1)**2/D1
def Wog(F,mu,al,Dv):
    J=np.linalg.det(F); lam=np.sqrt(np.linalg.eigvalsh(F@F.T))*J**(-1/3)
    w=sum(2*m/a**2*np.sum(lam**a-1) for m,a in zip(mu,al))
    w+=sum((J-1)**(2*(k+1))/d for k,d in enumerate(Dv) if d>0)
    return w
def Whc(F,mu=1.0,K=100.0):
    J=np.linalg.det(F); lam=np.sqrt(np.linalg.eigvalsh(F@F.T))*J**(-1/3)
    return mu*np.sum(np.log(lam)**2)+0.5*K*np.log(J)**2
def cauchy_fd(W,F,h=1e-6):
    P=np.zeros((3,3))
    for i in range(3):
        for j in range(3):
            E=np.zeros((3,3)); E[i,j]=h
            P[i,j]=(W(F+E)-W(F-E))/(2*h)
    return P@F.T/np.linalg.det(F)
def readgen(tag):
    t=open(O+tag+'_gen.dat').read().split('\n'); out=[]
    for n in range(3):
        a=np.array(t[3*n].split()[1:],float).reshape(3,3,order='F')
        s=np.array(t[3*n+1].split(),float).reshape(3,3,order='F'); w=float(t[3*n+2])
        out.append((a,s,w))
    return out
def MRclosed(F):
    J=np.linalg.det(F); B=F@F.T; Bb=B*J**(-2/3); I1=np.trace(Bb)
    M=2*((C10+C01*I1)*Bb-C01*Bb@Bb); M=M-np.trace(M)/3*np.eye(3)
    return M/J+2/D1*(J-1)*np.eye(3)
gen={}
for tag,W in [('mrc',Wmr),('ogd3c',lambda F:Wog(F,mu,al,[0.02,0.001,0.001])),('hc',Whc)]:
    e=[];e2=[]
    for F,s,w in readgen(tag):
        sref=cauchy_fd(W,F)
        e.append(float(np.max(np.abs(s-sref))/np.max(np.abs(sref)))); e2.append(abs(w-W(F)))
        if tag=='mrc': e2.append(float(np.max(np.abs(s-MRclosed(F)))))
    gen[tag]=(e,e2)
R['gen']={k:{'err_vs_FD':v[0],'extra':v[1]} for k,v in gen.items()}
# MR incompressible general
e=[]
for F,s,w in readgen('mri'):
    b=F@F.T; sc=2*C10*b-2*C01*np.linalg.inv(b); sc=sc-np.trace(sc)/3*np.eye(3); sd=s-np.trace(s)/3*np.eye(3)
    e.append(float(np.max(np.abs(sd-sc))))
R['mri_gen']=e
# ---------- compressible uniaxial stress ----------
h=load('mrc_hom.dat')
def sig_uni(L,t,W): F=np.diag([L,t,t]); return cauchy_fd(W,F,1e-6)
err=0;errl=0
for row in h:
    L,t,J,s11,s22=row
    tref=brentq(lambda t:sig_uni(L,t,Wmr)[1,1],0.3,1.6,xtol=1e-14)
    s=sig_uni(L,tref,Wmr)[0,0]; err=max(err,abs(s-s11)/abs(s) if abs(s)>1e-9 else 0); errl=max(errl,abs(t-tref))
R['mrc_uni']={'sig_err':float(err),'lat_err':float(errl),'at2':[float(x) for x in h[np.argmin(abs(h[:,0]-2.0))]] ,'rows':h[::8].tolist()}
# ---------- equal-stretch reference g12 by mpmath ----------
mp.mp.dps=60
def gref(delta,props=(1.0,2.0,0.02,0.2,-2.0,0.0),compr=True):
    XL=mp.mpf('1.4'); x1=XL*(1+mp.mpf(delta)/2); x2=XL*(1-mp.mpf(delta)/2); x3=mp.mpf('0.8')
    J=x1*x2*x3; f=J**(-mp.mpf(1)/3); d=[x1*f,x2*f,x3*f]
    mus=props[0::3]; als=props[1::3]; Ds=props[2::3]
    def w1(x): return sum(2*mp.mpf(m)/mp.mpf(a)*x**(mp.mpf(a)-1) for m,a in zip(mus,als))
    ph=[x*w1(x) for x in d]
    UJ=sum(2*(k+1)*mp.mpf(dd)**-1*(J-1)**(2*(k+1)-1) for k,dd in enumerate(Ds) if dd>0)
    tau=[p-sum(ph)/3+J*UJ for p in ph]
    G=(ph[0]-ph[1])/(J**(mp.mpf(2)/3)*(d[0]**2-d[1]**2))
    l2=x2**2
    g=(G*l2-tau[1])/J
    return g
PROPS={'mrc':(1.0,2.0,0.02,0.2,-2.0,0.0),'ogd3c':(0.4017,1.3,0.02,0.00295,5.0,0.001,0.00981,-2.0,0.001)}
for tag,pr in PROPS.items():
    dd=np.loadtxt(O+tag+'_degen.dat'); rows=[]
    for kk,r_ in enumerate(dd[1:]):
        dlt=mp.mpf(10)**(-mp.mpf(kk)/2); g=gref(dlt,pr); rows.append([float(dlt)]+[float(abs((mp.mpf(r_[k])-g)/g)) for k in (1,2,3)]+[float(r_[8-1+1-1]) if False else float(r_[7])])
    R['degen_'+tag]=rows
    R['degen0_'+tag]=[float(dd[0][k]) if dd[0][k]==dd[0][k] else None for k in (1,2,3,4,5,6,7)]
    R['g12_0_'+tag]=float(gref(mp.mpf('1e-25'),pr))
json.dump(R,open(O+'checks.json','w'))
for k,v in R.items():
    if k in('mr','hi','mri_gen','og3'): continue
    if k.startswith('degen_'):
        print(k)
        for r_ in v[::2]: print('  %.2e %.2e %.2e %.2e   tensor(prod) %.1e'%tuple(r_))
    elif k=='gen': print('gen',{a:[ '%.2e'%x for x in b['err_vs_FD']] for a,b in v.items()})
    elif k!='mrc_uni': print(k,v)
print(R['mrc_uni']['at2'])
for tag in ('mr','og3','hi'): print(tag,{a:b for a,b in R[tag].items() if not isinstance(b,list)})
