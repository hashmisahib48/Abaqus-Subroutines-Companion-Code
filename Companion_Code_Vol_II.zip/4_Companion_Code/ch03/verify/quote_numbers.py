import numpy as np, json
O='../out/'
R=json.load(open(O+'checks.json'))
for tag in ('ogd3c','hc','mrc'):
    d=np.loadtxt(O+tag+'_deriv.dat'); print(tag,'deriv h=1e-5',d[4,1:],' h=1e-6 max',d[5,1:].max(),' min over h per col',d[:,1:].min(axis=0))
    m=open(O+tag+'_mixed.dat').read().split('\n'); print(m)
for tag in ('mrc','ogd3c','hc','mri','ogd3','hi'):
    print(tag,open(O+tag+'_tang.dat').read())
print('hom MR at 2',np.loadtxt(O+'mri_hom.dat')[10], 'at 3',np.loadtxt(O+'mri_hom.dat')[20])
h=np.loadtxt(O+'ogd3_hom.dat'); print('og3 at 2,4,6',h[[10,30,50]])
h=np.loadtxt(O+'hi_hom.dat'); print('hi at 2',h[10], 3*np.log(2)/2)
h=np.loadtxt(O+'mrc_hom.dat'); print('mrc uni at 2',h[10],'at 4',h[30])
h=np.loadtxt(O+'ogd3c_hom.dat'); print('ogd3c uni at 2',h[10])
h=np.loadtxt(O+'hc_hom.dat'); print('hc uni at 2',h[10])
print(open(O+'mrc_gen.dat').read())
print(open(O+'alpha.dat').read())
print('gen errs',R['gen']); print('mri_gen',R['mri_gen'])
print({k:R[k] for k in ('mr','hi')})
print('mrc_uni', R['mrc_uni']['sig_err'], R['mrc_uni']['lat_err'])
