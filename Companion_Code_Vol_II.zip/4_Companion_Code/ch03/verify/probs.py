"""Answers of the Chapter 3 problems (independent Python evaluation)."""
import numpy as np
np.set_printoptions(precision=6,suppress=False)
# ---- 3A.1
mu_o=np.array([0.618,0.00118,-0.00981]); al=np.array([1.3,5.0,-2.0]); mu=al/2*mu_o
print('3A.1 mu_abq',mu,'mu0',mu.sum(),'E0',3*mu.sum())
Pu=lambda L: sum(2*m/a*(L**(a-1)-L**(-a/2-1)) for m,a in zip(mu,al))
print('P_uni(2)=',Pu(2.0))
# ---- 3A.2
m1,m2=1.0,0.2; L=1.5; x=np.array([L,L**-0.5,L**-0.5])
U1=m1*x-m2*x**-3; U2=m1+3*m2*x**-4
psi=x*(U1+x*U2); tau=x*U1-np.sum(x*U1)/3
print('3A.2 x',x,'U1',U1,'U2',U2,'psi',psi,'tau',tau,'s1-s2',tau[0]-tau[1],'P',(tau[0]-tau[1])/L, 'closed',2*(L-L**-2)*(0.5+0.1/L))
# ---- 3A.3
mu0,beta,T0,T=1.0,-0.003,20.0,60.0; mu_T=mu0*(1+beta*(T-T0)); L=1.5
print('3A.3 mu',mu_T,'sigma',3*mu_T*np.log(L),'P',3*mu_T*np.log(L)/L,'psi',2*mu_T)
# ---- 3B.1: equal stretches, compressible MR, lambda=(1.4,1.4,0.8)
C10,C01,D=0.5,0.1,0.02
lam=np.array([1.4,1.4,0.8]); J=lam.prod(); x=lam*J**(-1/3)
U1=m1*x-m2*x**-3; U2=m1+3*m2*x**-4
UJ=2*(J-1)/D; UJJ=2/D
ph=x*U1; tau=ph-ph.sum()/3+J*UJ; psi=x*(U1+x*U2)
A=np.zeros((3,3))
for i in range(3):
    for j in range(3):
        A[i,j]=-(psi[i]+psi[j])/3+psi.sum()/9+J*(UJ+J*UJJ)+(psi[i]-2*tau[i] if i==j else 0)
g=0.5*((A[0,0]+2*tau[0])-A[0,1])-tau[0]
print('3B.1 J',J,'tau',tau,'A11/J',A[0,0]/J,'A12/J',A[0,1]/J,'g12/J',g/J,'iso check',(A[0,0]-A[0,1]-2*g)/J)
# ---- 3B.2
mu1,a1,xb=0.4017,1.3,1.25
print('3B.2 dU1',-2*mu1/(a1*xb),'dU2',2*mu1/(a1*xb**2),'dU3',-4*mu1/(a1*xb**3))
# ---- 3C.1 (from driver output) ; 3C.2
for T in (20.0,60.0):
    m=1.0*(1+beta*(T-T0)); print('3C.2 T',T,'mu',m,'P(2)',3*m*np.log(2)/2)
