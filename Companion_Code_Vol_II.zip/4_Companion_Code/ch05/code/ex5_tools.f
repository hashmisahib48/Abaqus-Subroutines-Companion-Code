      SUBROUTINE K5_EVAL(IMODE,XL,UMAXOLD,DMGOLD,PRM,NPM,PMR,
     1 ETA,DETADW,P0,DP0,W,UMAXNEW,DMGNEW,SENER,DPTOT,WP)
!
!     Driver service routine (Chapter 5).  Evaluates one material point
!     under homogeneous incompressible stretch XL the way Abaqus does:
!     UHYPER gives the primary energy, UMAXNEW = MAX(UMAXOLD, W), then
!     UMULLINS gives ETA and DETADW.  IMODE = 1 uniaxial, 2 equibiaxial,
!     3 planar tension.  Nominal stress P = ETA*P0 (Eq. 5.5-1), tangent
!     DPTOT = dP/dXL (Eq. 5.6-1).  WP = dW/dXL.
!     PMR(1), PMR(2) = C10, C01 (MPa) of the primary response.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PRM(*),PMR(*),U(2),UI1(3),UI2(6),UI3(6),SV(2),FV(1),
     1 FVI(1),STV(2)
      CHARACTER*80 CMNAME
      CMNAME = 'MULLINS_TEST'
      XLL = XL
      IF (IMODE .EQ. 1) THEN
         BI1 = XLL*XLL + 2.0D0/XLL
         BI2 = 2.0D0*XLL + 1.0D0/(XLL*XLL)
      ELSEIF (IMODE .EQ. 2) THEN
         BI1 = 2.0D0*XLL*XLL + XLL**(-4)
         BI2 = XLL**4 + 2.0D0/(XLL*XLL)
      ELSE
         BI1 = XLL*XLL + 1.0D0 + 1.0D0/(XLL*XLL)
         BI2 = BI1
      ENDIF
      CALL UHYPER(BI1,BI2,1.0D0,U,UI1,UI2,UI3,293.0D0,1,CMNAME,1,0,
     1 SV,0,FV,FVI,2,PMR)
      W  = U(2)
      U1 = UI1(1)
      U2 = UI1(2)
      IF (IMODE .EQ. 1) THEN
         P0  = 2.0D0*(XLL - XLL**(-2))*(U1 + U2/XLL)
         DP0 = 2.0D0*(1.0D0 + 2.0D0*XLL**(-3))*(U1 + U2/XLL)
     1       - 2.0D0*(XLL - XLL**(-2))*U2/(XLL*XLL)
         WP  = P0
      ELSEIF (IMODE .EQ. 2) THEN
         P0  = 2.0D0*(XLL - XLL**(-5))*(U1 + U2*XLL*XLL)
         DP0 = 2.0D0*(1.0D0 + 5.0D0*XLL**(-6))*(U1 + U2*XLL*XLL)
     1       + 4.0D0*(XLL - XLL**(-5))*U2*XLL
         WP  = 2.0D0*P0
      ELSE
         P0  = 2.0D0*(XLL - XLL**(-3))*(U1 + U2)
         DP0 = 2.0D0*(1.0D0 + 3.0D0*XLL**(-4))*(U1 + U2)
         WP  = P0
      ENDIF
      UMAXNEW = MAX(UMAXOLD, W)
      CALL UMULLINS(NPM,PRM,UMAXNEW,UMAXOLD,W,ETA,DETADW,DMGOLD,
     1 DMGNEW,SENER,0,STV,293.0D0,0.0D0,0,FV,FVI,CMNAME,0)
      DPTOT = ETA*DP0 + DETADW*WP*P0
      RETURN
      END
