#!/bin/sh
# Compiles every listing of Chapter 5 and runs the drivers (gfortran 13,
# outside Abaqus).  Output goes to ../verify/out.
A=/home/claude/vol2/lib/aba
F="-ffixed-form -ffixed-line-length-none -std=legacy -I$A"
O=../verify/out; mkdir -p $O
for f in ex5_uhyper_mr ex5_umullins_or ex5_umullins_tanh ex5_umullins_bug ex5_vumullins_or ex5_vumullins_volokh ex5_tools; do
  gfortran -c $F $f.f -o /tmp/k5_$f.o || exit 1
done
# standard-form check of the Standard listings (72 columns, no extension)
for f in ex5_umullins_or ex5_umullins_tanh ex5_umullins_bug ex5_tools; do
  gfortran -c -ffixed-form -std=legacy -I$A $f.f -o /tmp/k5_$f.o || exit 1
done
for m in or tanh bug; do
  gfortran $F -o $O/drv_$m ex5_drv.f ex5_tools.f ex5_uhyper_mr.f ex5_umullins_$m.f $A/stubs.f || exit 1
  gfortran $F -o $O/newt_$m ex5_drv_newton.f ex5_tools.f ex5_uhyper_mr.f ex5_umullins_$m.f $A/stubs.f || exit 1
  gfortran $F -o $O/fd_$m ex5_drv_fd.f ex5_umullins_$m.f $A/stubs.f || exit 1
done
gfortran $F -o $O/drv_exp ex5_drv_exp.f ex5_vumullins_or.f ex5_umullins_or.f $A/stubs.f || exit 1
gfortran $F -o $O/drv_vol ex5_drv_vol.f ex5_vumullins_volokh.f $A/stubs.f || exit 1
echo built
