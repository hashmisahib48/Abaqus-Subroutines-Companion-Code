      PROGRAM K5DRV
!
!     Driver for UMULLINS (Chapter 5): strain-driven cycle in a
!     homogeneous incompressible state.  Reads from unit 5
!        IMODE, NPM     PRM(1..NPM)     C10, C01, UMAX0
!        NSEG, NSTEP    XLEND(1..NSEG)
!     The path starts at stretch 1 and runs linearly in the stretch to
!     XLEND(1), then to XLEND(2), ... NSTEP steps per segment.
!     Writes out_cycle.txt: one line per step.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PRM(10),PMR(2),XLEND(50)
      READ(5,*) IMODE, NPM
      READ(5,*) (PRM(I), I = 1, NPM)
      READ(5,*) PMR(1), PMR(2), UMAX0
      READ(5,*) NSEG, NSTEP
      READ(5,*) (XLEND(I), I = 1, NSEG)
      NDIR = 1
      IF (IMODE .EQ. 2) NDIR = 2
      OPEN(10, FILE='out_cycle.txt')
      XL0   = 1.0D0
      UMAX  = UMAX0
      DMG   = 0.0D0
      WEXT  = 0.0D0
      CALL K5_EVAL(IMODE,XL0,UMAX,DMG,PRM,NPM,PMR,ETA,DET,P0,DP0,W,
     1 UMN,DMGN,SEN,DPT,WP)
      PPREV = ETA*P0
      KSTEP = 0
      DO ISEG = 1, NSEG
         XLA = XL0
         DO IS = 1, NSTEP
            XL = XLA + (XLEND(ISEG) - XLA)*DBLE(IS)/DBLE(NSTEP)
            CALL K5_EVAL(IMODE,XL,UMAX,DMG,PRM,NPM,PMR,ETA,DET,P0,DP0,
     1       W,UMN,DMGN,SEN,DPT,WP)
            P = ETA*P0
!           tangent by central difference of the stress at fixed state
            H = 1.0D-6*XL
            CALL K5_EVAL(IMODE,XL+H,UMAX,DMG,PRM,NPM,PMR,E1,D1,Q1,
     1       Q2,W1,A1,A2,A3,A4,A5)
            CALL K5_EVAL(IMODE,XL-H,UMAX,DMG,PRM,NPM,PMR,E2,D2,Q3,
     1       Q4,W2,A1,A2,A3,A4,A5)
            DPFD = (E1*Q1 - E2*Q3)/(2.0D0*H)
!           external work per unit reference volume, trapezoid rule
            WEXT = WEXT + 0.5D0*DBLE(NDIR)*(P + PPREV)*(XL - XL0)
            PPREV = P
            KSTEP = KSTEP + 1
            WRITE(10,'(I6,13(1X,ES22.14))') KSTEP, XL, W, UMN, ETA,
     1       DET, P0, P, DPT, DPFD, DMGN, SEN, WEXT, DP0
!           accept the increment
            UMAX = UMN
            DMG  = DMGN
            XL0  = XL
         ENDDO
      ENDDO
      CLOSE(10)
      END
