      SUBROUTINE VUMULLINS(
C Read only (unmodifiable) variables -
     1  NBLOCK,
     2  JELEM, KINTPT, KLAYER, KSECPT,
     3  CMNAME,
     4  NSTATEV, NFIELDV, NPROPS,
     5  PROPS, TEMPOLD, TEMPNEW, FIELDOLD, FIELDNEW,
     6  STATEOLD, ENERDAMAGEOLD,
     7  UMAXOLD, UMAXNEW, UDEV,
C Write only (modifiable) variables -
     8  ETA, DETADUDEV,
     9  STATENEW, ENERDAMAGENEW)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION JELEM(NBLOCK), PROPS(NPROPS), TEMPOLD(NBLOCK),
     1  FIELDOLD(NBLOCK,NFIELDV), STATEOLD(NBLOCK,NSTATEV),
     2  TEMPNEW(NBLOCK), FIELDNEW(NBLOCK,NFIELDV),
     3  ENERDAMAGEOLD(NBLOCK), UMAXOLD(NBLOCK), UMAXNEW(NBLOCK),
     4  UDEV(NBLOCK), ETA(NBLOCK), DETADUDEV(NBLOCK),
     5  STATENEW(NBLOCK,NSTATEV), ENERDAMAGENEW(NBLOCK)
      CHARACTER*80 CMNAME
!
!     Ogden-Roxburgh law of Eq. (5.2-3) for a block of points.
!     PROPS = R (-), M (MPa), BETA (-); Abaqus/Explicit default BETA=0.1
      PARAMETER (XSQPI = 1.7724538509055160D0, XTINY = 1.0D-30)
!
      R    = PROPS(1)
      XM   = PROPS(2)
      BETA = PROPS(3)
      IF (R .LE. 1.D0 .OR. XM .LT. 0.D0 .OR. BETA .LT. 0.D0 .OR.
     1    XM + BETA .LE. 0.D0) THEN
         WRITE(*,*) 'VUMULLINS: need R>1, M>=0, BETA>=0, M+BETA>0'
         CALL XPLB_EXIT
      ENDIF
      DO 100 K = 1, NBLOCK
         UM = UMAXNEW(K)
         C  = XM + BETA*UM
         IF (UM .LE. XTINY .OR. C .LE. XTINY) THEN
            ETA(K) = 1.D0
            DETADUDEV(K) = 0.D0
            ENERDAMAGENEW(K) = 0.D0
         ELSE
            T = UM/C
            X = MAX(UM - UDEV(K), 0.D0)/C
            ETA(K) = 1.D0 - ERF(X)/R
            DETADUDEV(K) = 0.D0
            IF (UMAXNEW(K) .LE. UMAXOLD(K))
     1         DETADUDEV(K) = 2.D0*EXP(-X*X)/(R*XSQPI*C)
            FT = T*ERF(T) + EXP(-T*T)/XSQPI
            ENERDAMAGENEW(K) = C/R*(FT - 1.D0/XSQPI)
         ENDIF
         IF (NSTATEV .GE. 1) STATENEW(K,1) = ETA(K)
  100 CONTINUE
      RETURN
      END
