      SUBROUTINE VUMULLINS(
C Read only (unmodifiable) variables -
     1  NBLOCK,
     2  JELEM, KINTPT, KLAYER, KSECPT,
     3  CMNAME,
     4  NSTATEV, NFIELDV, NPROPS,
     5  PROPS, TEMPOLD, TEMPNEW, FIELDOLD, FIELDNEW,
     6  STATEOLD, ENERDAMAGEOLD,
     7  UMAXOLD, UMAXNEW, UDEV,
C Write only (modifiable) variables -
     8  ETA, DETADUDEV,
     9  STATENEW, ENERDAMAGENEW)
!
      INCLUDE 'VABA_PARAM.INC'
!
      DIMENSION JELEM(NBLOCK), PROPS(NPROPS), TEMPOLD(NBLOCK),
     1  FIELDOLD(NBLOCK,NFIELDV), STATEOLD(NBLOCK,NSTATEV),
     2  TEMPNEW(NBLOCK), FIELDNEW(NBLOCK,NFIELDV),
     3  ENERDAMAGEOLD(NBLOCK), UMAXOLD(NBLOCK), UMAXNEW(NBLOCK),
     4  UDEV(NBLOCK), ETA(NBLOCK), DETADUDEV(NBLOCK),
     5  STATENEW(NBLOCK,NSTATEV), ENERDAMAGENEW(NBLOCK)
      CHARACTER*80 CMNAME
!
!     Softening law ETA = EXP(-UM/U0), Eq. (5.8-1).  PROPS(1) = U0 (MPa)
!
      U0 = PROPS(1)
      IF (U0 .LE. 0.D0) THEN
         WRITE(*,*) 'VUMULLINS: U0 must be positive'
         CALL XPLB_EXIT
      ENDIF
      U0INV = 1.D0/U0
      DO 100 K = 1, NBLOCK
         ETA(K) = EXP(-UMAXNEW(K)*U0INV)
!        ETA depends on the maximum only: slope on the primary path
         DETADUDEV(K) = 0.D0
         IF (UMAXNEW(K) .GT. UMAXOLD(K))
     1      DETADUDEV(K) = -U0INV*ETA(K)
!        energy dissipated on complete unloading, Eq. (5.8-2)
         ENERDAMAGENEW(K) = U0*(1.D0 - ETA(K)) - ETA(K)*UMAXNEW(K)
  100 CONTINUE
      RETURN
      END
