      SUBROUTINE UMULLINS(NUMPROPS,PROPS,UMAXNEW,UMAXOLD,SEDDEV,
     1 ETA,DETADW,DMGDISSOLD,DMGDISSNEW,SENERNEW,NUMSTATEV,STATEV,
     2 TEMP,DTEMP,NUMFIELDV,FIELDV,FIELDVINC,CMNAME,LINPER)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION PROPS(*),STATEV(*),FIELDV(*),FIELDVINC(*)
!
!     Alternative law, Eq. (5.7-1):  ETA = 1 - TANH(X)/R,
!        X = (UM - W)/(XM + BETA*UM)
!     PROPS(1) = R (-), PROPS(2) = XM (MPa), PROPS(3) = BETA (-)
      PARAMETER (XTINY = 1.0D-30)
!
      IF (NUMPROPS .LT. 3) THEN
         WRITE(7,*) 'UMULLINS: three properties R, M, BETA needed'
         CALL XIT
      ENDIF
      R    = PROPS(1)
      XM   = PROPS(2)
      BETA = PROPS(3)
      IF (R .LE. 1.0D0 .OR. XM .LT. 0.0D0 .OR. BETA .LT. 0.0D0
     1    .OR. XM + BETA .LE. 0.0D0) THEN
         WRITE(7,*) 'UMULLINS: need R>1, M>=0, BETA>=0, M+BETA>0'
         CALL XIT
      ENDIF
      UM = UMAXNEW
      C  = XM + BETA*UM
      IF (UM .LE. XTINY .OR. C .LE. XTINY) THEN
         ETA = 1.0D0
         DETADW = 0.0D0
         DMGDISSNEW = 0.0D0
         SENERNEW = SEDDEV
      ELSE
         T = UM/C
         X = MAX(UM - SEDDEV, 0.0D0)/C
         ETA = 1.0D0 - TANH(X)/R
         DETADW = 0.0D0
         IF (UMAXNEW .LE. UMAXOLD)
     1      DETADW = 1.0D0/(R*C*COSH(X)**2)
!        LOG(COSH(Y)) = Y + LOG((1 + EXP(-2Y))/2), no overflow
         FT = T + LOG(0.5D0*(1.0D0 + EXP(-2.0D0*T)))
         FX = X + LOG(0.5D0*(1.0D0 + EXP(-2.0D0*X)))
         DMGDISSNEW = C/R*FT
         SENERNEW = SEDDEV - C/R*(FT - FX)
      ENDIF
      IF (NUMSTATEV .GE. 1) STATEV(1) = ETA
      RETURN
      END
