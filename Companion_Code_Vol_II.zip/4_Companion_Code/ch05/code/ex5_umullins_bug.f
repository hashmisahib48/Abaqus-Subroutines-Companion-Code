      SUBROUTINE UMULLINS(NUMPROPS,PROPS,UMAXNEW,UMAXOLD,SEDDEV,
     1 ETA,DETADW,DMGDISSOLD,DMGDISSNEW,SENERNEW,NUMSTATEV,STATEV,
     2 TEMP,DTEMP,NUMFIELDV,FIELDV,FIELDVINC,CMNAME,LINPER)
!
      INCLUDE 'ABA_PARAM.INC'
!
      CHARACTER*80 CMNAME
      DIMENSION PROPS(*),STATEV(*),FIELDV(*),FIELDVINC(*)
!
!     Ogden-Roxburgh damage variable, Eq. (5.2-3):
!        ETA = 1 - ERF((UM - W)/(XM + BETA*UM))/R
!     PROPS(1) = R    (-)    R > 1
!     PROPS(2) = XM   (MPa)  XM >= 0
!     PROPS(3) = BETA (-)    BETA >= 0, XM + BETA > 0
!     UM = UMAXNEW, W = SEDDEV (deviatoric energy densities, MPa)
      PARAMETER (XSQPI = 1.7724538509055160D0, XTINY = 1.0D-30)
!
      IF (NUMPROPS .LT. 3) THEN
         WRITE(7,*) 'UMULLINS: three properties R, M, BETA needed'
         CALL XIT
      ENDIF
      R    = PROPS(1)
      BETA = PROPS(2)
      XM   = PROPS(3)
      IF (R .LE. 1.0D0 .OR. XM .LT. 0.0D0 .OR. BETA .LT. 0.0D0
     1    .OR. XM + BETA .LE. 0.0D0) THEN
         WRITE(7,*) 'UMULLINS: need R>1, M>=0, BETA>=0, M+BETA>0'
         CALL XIT
      ENDIF
      UM = UMAXNEW
      C  = XM + BETA*UMAXOLD
      IF (UM .LE. XTINY .OR. C .LE. XTINY) THEN
!        virgin material: nothing to damage yet
         ETA = 1.0D0
         DETADW = 0.0D0
         DMGDISSNEW = 0.0D0
         SENERNEW = SEDDEV
      ELSE
         T = UM/C
         X = MAX(UM - SEDDEV, 0.0D0)/C
         ETA = 1.0D0 - ERF(X/R)
!        d(ETA)/dW at fixed UM; zero on the primary path, Eq. (5.4-1)
         DETADW = 2.0D0*EXP(-X*X)/(R*XSQPI)
!        dissipated and recoverable energy densities, Eq. (5.2-6)
         FT = T*ERF(T) + EXP(-T*T)/XSQPI
         FX = X*ERF(X) + EXP(-X*X)/XSQPI
         DMGDISSNEW = C*(FT - 1.0D0/XSQPI)
         SENERNEW = SEDDEV - C/R*(FT - FX)
      ENDIF
      IF (NUMSTATEV .GE. 1) STATEV(1) = ETA
      RETURN
      END
