      PROGRAM K5EXP
!
!     Driver for VUMULLINS (Chapter 5): one block of NB material
!     points, called the way Abaqus/Explicit calls it, and compared
!     with UMULLINS of Listing 5.1 point by point.
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NB = 8)
      DIMENSION PROPS(3),JELEM(NB),TO(NB),TN(NB),FO(NB,1),FN(NB,1),
     1 SO(NB,1),SN(NB,1),EDO(NB),UMO(NB),UMN(NB),UD(NB),ETA(NB),
     2 DET(NB),EDN(NB)
      CHARACTER*80 CMNAME
      DATA PROPS /2.0D0, 2.0D0, 0.1D0/
      DATA UMO /0.0D0,1.0D0,1.0D0,3.0D0,3.644444444444444D0,
     1 3.644444444444444D0,3.644444444444444D0,3.644444444444444D0/
      DATA UD  /0.0D0,1.125D0,0.6D0,3.644444444444444D0,3.5D0,2.0D0,
     1 0.3D0,0.0D0/
      CMNAME = 'MULLINS_TEST'
      DO K = 1, NB
         JELEM(K) = K
         TO(K) = 293.0D0
         TN(K) = 293.0D0
         FO(K,1) = 0.0D0
         FN(K,1) = 0.0D0
         SO(K,1) = 0.0D0
         EDO(K) = 0.0D0
         UMN(K) = MAX(UMO(K), UD(K))
      ENDDO
      CALL VUMULLINS(NB,JELEM,1,1,1,CMNAME,1,1,3,PROPS,TO,TN,FO,FN,
     1 SO,EDO,UMO,UMN,UD,ETA,DET,SN,EDN)
      OPEN(10, FILE='out_exp.txt')
      DO K = 1, NB
         CALL UMULLINS(3,PROPS,UMN(K),UMO(K),UD(K),E2,D2,0.0D0,DM2,
     1    SE2,0,V,293.0D0,0.0D0,0,FO,FN,CMNAME,0)
         WRITE(10,'(I3,9(1X,ES22.14))') K, UMO(K), UMN(K), UD(K),
     1    ETA(K), E2, DET(K), D2, EDN(K), DM2
      ENDDO
      CLOSE(10)
      END
