      PROGRAM K5NEWT
!
!     Load-controlled equilibrium iteration with the tangent of
!     Chapter 5 (uniaxial tension, incompressible, one material point).
!     Reads from unit 5:  NPM  PRM(1..NPM);  C10 C01;  ITAN;  NLOAD;
!     PT(1..NLOAD) = nominal stress (MPa) at the end of each load step.
!     ITAN = 1 consistent tangent, 2 DETADW omitted, 3 primary tangent.
!     Newton iteration from the last converged stretch; at most IMAX
!     iterations, then the load step is cut to one quarter (as Abaqus
!     does).  Writes one line per load step and out_hist.txt for step
!     step number IWATCH (residual of every iteration).
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (IMAX = 12, TOL = 1.0D-10, IWATCH = 9)
      DIMENSION PRM(10),PMR(2),PT(200)
      LOGICAL CONV
      READ(5,*) NPM, (PRM(I), I = 1, NPM)
      READ(5,*) PMR(1), PMR(2)
      READ(5,*) ITAN, NLOAD
      READ(5,*) (PT(I), I = 1, NLOAD)
      OPEN(10, FILE='out_hist.txt')
      XL = 1.0D0
      UMAX = 0.0D0
      DMG = 0.0D0
      PPREV = 0.0D0
      NIT = 0
      NCUT = 0
      DO ISTEP = 1, NLOAD
         TAU = 0.0D0
         DTAU = 1.0D0
         NITS = 0
         NCUTS = 0
  10     CONTINUE
         PTRY = PPREV + (TAU + DTAU)*(PT(ISTEP) - PPREV)
         XLT = XL
         CONV = .FALSE.
         DO IT = 0, IMAX
            CALL K5_EVAL(1,XLT,UMAX,DMG,PRM,NPM,PMR,ETA,DET,P0,DP0,W,
     1       UMN,DMGN,SEN,DPT,WP)
            RES = ETA*P0 - PTRY
            IF (ISTEP .EQ. IWATCH)
     1         WRITE(10,'(I3,1X,I3,2(1X,ES22.14))')
     1       NCUTS, IT, XLT, ABS(RES)
            IF (ABS(RES) .LT. TOL) THEN
               CONV = .TRUE.
               GOTO 20
            ENDIF
            IF (ITAN .EQ. 1) TANG = DPT
            IF (ITAN .EQ. 2) TANG = ETA*DP0
            IF (ITAN .EQ. 3) TANG = DP0
            XLT = XLT - RES/TANG
            IF (XLT .LT. 0.2D0) XLT = 0.2D0
            NITS = NITS + 1
         ENDDO
  20     CONTINUE
         IF (CONV) THEN
            XL = XLT
            UMAX = UMN
            DMG = DMGN
            TAU = TAU + DTAU
            DTAU = MIN(DTAU, 1.0D0 - TAU)
         ELSE
            DTAU = 0.25D0*DTAU
            NCUTS = NCUTS + 1
            IF (DTAU .LT. 1.0D-4) THEN
               WRITE(*,'(A,I4)') 'ABORT at load step', ISTEP
               STOP
            ENDIF
         ENDIF
         IF (TAU .LT. 1.0D0 - 1.0D-12) GOTO 10
         PPREV = PT(ISTEP)
         NIT = NIT + NITS
         NCUT = NCUT + NCUTS
         WRITE(*,'(I4,1X,F8.4,1X,F9.5,1X,F9.6,2(1X,I4))') ISTEP,
     1    PT(ISTEP), XL, ETA, NITS, NCUTS
      ENDDO
      WRITE(*,'(A,2I6)') 'TOTAL iterations, cutbacks', NIT, NCUT
      END
