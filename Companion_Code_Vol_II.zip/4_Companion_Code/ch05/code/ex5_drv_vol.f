      PROGRAM K5VOL
!
!     Driver for the softening routine of Listing 5.8 (Eq. 5.8-1).
!     Reads U0 (MPa), NB, and NB lines  UMAXOLD UMAXNEW UDEV  from
!     unit 5.  One block of NB points is passed to VUMULLINS, as
!     Abaqus/Explicit does.  For every point the file out_vol.txt
!     gets ETA, DETADUDEV, a central difference of ETA with respect to
!     UMAXNEW, ENERDAMAGENEW and a quadrature of the stored energy.
      IMPLICIT REAL*8 (A-H,O-Z)
      PARAMETER (NBMAX = 4000)
      DIMENSION PROPS(1),JELEM(NBMAX),TO(NBMAX),TN(NBMAX),
     1 FO(NBMAX,1),FN(NBMAX,1),SO(NBMAX,1),SN(NBMAX,1),EDO(NBMAX),
     2 UMO(NBMAX),UMN(NBMAX),UD(NBMAX),ETA(NBMAX),DET(NBMAX),
     3 EDN(NBMAX),ETP(NBMAX),ETM(NBMAX),DP(NBMAX),DM(NBMAX),
     4 DX(NBMAX),EX(NBMAX)
      CHARACTER*80 CMNAME
      READ(5,*) PROPS(1), NB
      DO K = 1, NB
         READ(5,*) UMO(K), UMN(K), UD(K)
         JELEM(K) = K
         TO(K) = 293.0D0
         TN(K) = 293.0D0
         FO(K,1) = 0.0D0
         FN(K,1) = 0.0D0
         SO(K,1) = 0.0D0
         EDO(K) = 0.0D0
      ENDDO
      CMNAME = 'VOLOKH'
      H = 1.0D-6
      DO K = 1, NB
         DP(K) = UMN(K) + H
         DM(K) = UMN(K) - H
      ENDDO
      CALL VUMULLINS(NB,JELEM,1,1,1,CMNAME,1,1,1,PROPS,TO,TN,FO,FN,
     1 SO,EDO,UMO,UMN,UD,ETA,DET,SN,EDN)
      CALL VUMULLINS(NB,JELEM,1,1,1,CMNAME,1,1,1,PROPS,TO,TN,FO,FN,
     1 SO,EDO,UMO,DP,UD,ETP,DX,SN,EX)
      CALL VUMULLINS(NB,JELEM,1,1,1,CMNAME,1,1,1,PROPS,TO,TN,FO,FN,
     1 SO,EDO,UMO,DM,UD,ETM,DX,SN,EX)
      OPEN(10, FILE='out_vol.txt')
      DO K = 1, NB
         QSUM = 0.0D0
         NQ = 20000
         DO IQ = 1, NQ
            QSUM = QSUM + 0.5D0*UMN(K)/NQ*(EXP(-(IQ-1)*UMN(K)/NQ/
     1       PROPS(1)) + EXP(-IQ*UMN(K)/NQ/PROPS(1)))
         ENDDO
         WRITE(10,'(I5,7(1X,ES22.14))') K, UMN(K), ETA(K), DET(K),
     1    (ETP(K) - ETM(K))/(2.0D0*H), EDN(K), QSUM - ETA(K)*UMN(K)
      ENDDO
      CLOSE(10)
      END
