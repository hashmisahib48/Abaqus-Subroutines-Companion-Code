      PROGRAM K5FD
!
!     Finite-difference test of DETADW (Chapter 5).  Reads NPM, PRM,
!     then UM (maximum), W (current energy).  The state is one of
!     unloading: UMAXOLD = UMAXNEW = UM.  Central differences of ETA
!     with respect to SEDDEV for steps H = 10**(-K), K = 1..9, are
!     compared with DETADW; the relative error is written for each K.
      IMPLICIT REAL*8 (A-H,O-Z)
      DIMENSION PRM(10),FV(1),FVI(1),SV(2)
      CHARACTER*80 CMNAME
      READ(5,*) NPM, (PRM(I), I = 1, NPM)
      READ(5,*) UM, W
      CMNAME = 'MULLINS_TEST'
      CALL UMULLINS(NPM,PRM,UM,UM,W,ETA,DET,0.0D0,D1,S1,0,SV,293.0D0,
     1 0.0D0,0,FV,FVI,CMNAME,0)
      DO K = 1, 9
         H = 10.0D0**(-K)*MAX(1.0D0, ABS(W))
         CALL UMULLINS(NPM,PRM,UM,UM,W+H,EP,DP,0.0D0,D1,S1,0,SV,293.0D0,
     1    0.0D0,0,FV,FVI,CMNAME,0)
         CALL UMULLINS(NPM,PRM,UM,UM,W-H,EM,DM,0.0D0,D1,S1,0,SV,293.0D0,
     1    0.0D0,0,FV,FVI,CMNAME,0)
         DFD = (EP - EM)/(2.0D0*H)
         WRITE(*,'(I2,3(1X,ES22.14))') K, DET, DFD,
     1    ABS(DFD - DET)/ABS(DET)
      ENDDO
      END
