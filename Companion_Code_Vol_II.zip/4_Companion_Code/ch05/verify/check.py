"""Chapter 5 verification: runs the Fortran drivers (outside Abaqus) and compares with closed forms
written independently in Python/SciPy.  Writes out/results.json and prints a report."""
import subprocess, json, os, numpy as np
from scipy.special import erf, erfinv
from scipy.integrate import quad
os.chdir(os.path.dirname(os.path.abspath(__file__))); O='out'
C10,C01=0.5,0.1; RR,MM,BB=2.0,2.0,0.1
SQPI=np.sqrt(np.pi)
R={}
def run(exe,inp,cwd=None):
    d=cwd or O; os.makedirs(d,exist_ok=True)
    exe=os.path.abspath(os.path.join(O,exe))
    return subprocess.run([exe],input=inp,capture_output=True,text=True,cwd=d).stdout
def inv(mode,l):
    if mode==1: return l*l+2/l, 2*l+1/l**2
    if mode==2: return 2*l*l+l**-4, l**4+2*l**-2
    I=l*l+1+l**-2; return I,I
def Wf(mode,l):
    I1,I2=inv(mode,l); return C10*(I1-3)+C01*(I2-3)
def P0f(mode,l):
    if mode==1: return 2*(l-l**-2)*(C10+C01/l)
    if mode==2: return 2*(l-l**-5)*(C10+C01*l*l)
    return 2*(l-l**-3)*(C10+C01)
def etaOR(Wm,w,r=RR,m=MM,b=BB):
    c=m+b*Wm; return 1-erf(np.maximum(Wm-w,0)/c)/r
def etaTH(Wm,w,r=RR,m=MM,b=BB):
    c=m+b*Wm; return 1-np.tanh(np.maximum(Wm-w,0)/c)/r
def detaOR(Wm,w,r=RR,m=MM,b=BB):
    c=m+b*Wm; X=np.maximum(Wm-w,0)/c; return 2*np.exp(-X*X)/(r*SQPI*c)
def DOR(Wm,r=RR,m=MM,b=BB): return quad(lambda w:1-etaOR(Wm,w,r,m,b),0,Wm,epsabs=1e-13,epsrel=1e-13)[0]
def DTH(Wm,r=RR,m=MM,b=BB): return quad(lambda w:1-etaTH(Wm,w,r,m,b),0,Wm,epsabs=1e-13,epsrel=1e-13)[0]
def RORq(Wm,w,eta=etaOR): return quad(lambda s:eta(Wm,s),0,w,epsabs=1e-13,epsrel=1e-13)[0]
def cycle(exe,mode,ends,nstep,prm=(RR,MM,BB),umax0=0.0):
    inp="%d %d\n%s\n%g %g %.16g\n%d %d\n%s\n"%(mode,len(prm)," ".join(map(str,prm)),C10,C01,umax0,len(ends),nstep," ".join(map(str,ends)))
    d=os.path.join(O,'cyc_%s_%d'%(exe,mode)); run(exe,inp,d)
    return np.loadtxt(os.path.join(d,'out_cycle.txt'))
# columns: 0 step,1 lam,2 W,3 UMN,4 eta,5 deta,6 P0,7 P,8 DPT,9 DPFD,10 DMG,11 SEN,12 WEXT,13 DP0
def analyse(a,mode,etaf=etaOR,detaf=detaOR,Df=DOR,tag='',umax0=0.0):
    lam=a[:,1]; W=a[:,2]; Um=a[:,3]
    Wc=Wf(mode,lam); P0c=P0f(mode,lam); etac=etaf(Um,Wc); Pc=etac*P0c
    out={}
    out['W_err']=float(np.max(np.abs(W-Wc)/np.maximum(Wc,1e-12)))
    out['eta_err']=float(np.max(np.abs(a[:,4]-etac)))
    out['P_err']=float(np.max(np.abs(a[:,7]-Pc))/np.max(Pc))
    Uprev=np.concatenate([[umax0],Um[:-1]])
    kink=np.abs(W-Uprev)<1e-9*np.maximum(W,1e-9)        # steps that end exactly at a previous maximum
    out['n_kink']=int(np.sum(kink&(np.arange(len(a))>0)))
    ok=~kink
    out['tan_vs_fd']=float(np.max((np.abs(a[:,8]-a[:,9])/np.abs(a[:,9]))[ok]))
    # tangent from closed form
    nd={1:1,2:2,3:1}[mode]
    # dP/dl at fixed state: eta*dP0 + deta*dW/dl*P0 ; check with independent FD of closed-form stress
    h=1e-6*lam
    def Pst(l): return etaf(Uprev,Wf(mode,l))*P0f(mode,l)
    tcf=(Pst(lam+h)-Pst(lam-h))/(2*h)
    out['tan_vs_cf']=float(np.max((np.abs(a[:,8]-tcf)/np.abs(tcf))[ok]))
    Dc=np.array([Df(u) if u>0 else 0.0 for u in Um])
    out['D_err']=float(np.max(np.abs(a[:,10]-Dc))/np.max(Um))
    k=np.arange(len(a))>0
    net=a[:,11]+a[:,10]
    out['work_err']=float(np.max(np.abs(a[k,12]-net[k]))/np.max(net))
    return out
if __name__=='__main__':
    # ---------------- 1. uniaxial cycle ----------------
    ends=[2.0,1.3,3.0,1.5,3.5,1.0]
    a=cycle('drv_or',1,ends,1000); R['ut']=analyse(a,1)
    np.save(os.path.join(O,'cyc_ut.npy'),a)
    # key states: end of each segment
    seg=[a[(k+1)*1000-1] for k in range(6)]
    R['seg']=[dict(lam=float(s[1]),W=float(s[2]),Um=float(s[3]),eta=float(s[4]),P=float(s[7]),D=float(s[10]),R=float(s[11]),Wext=float(s[12])) for s in seg]
    # ---------------- 2. example 5.5-1 path: full unloads ----------------
    ends2=[2.0,1.0,3.0,1.0,3.5,1.0]
    b=cycle('drv_or',1,ends2,2000); R['ex551']=analyse(b,1)
    np.save(os.path.join(O,'cyc_ex551.npy'),b)
    R['ex551_seg']=[dict(lam=float(b[(k+1)*2000-1][1]),W=float(b[(k+1)*2000-1][2]),Um=float(b[(k+1)*2000-1][3]),eta=float(b[(k+1)*2000-1][4]),P=float(b[(k+1)*2000-1][7]),D=float(b[(k+1)*2000-1][10]),R=float(b[(k+1)*2000-1][11]),Wext=float(b[(k+1)*2000-1][12])) for k in range(6)]
    # unloading states from the peak lambda=3: eta at lambda= 2.5,2,1.5,1
    seg3=b[2000*3:2000*4]
    def at(arr,l):
        k=np.argmin(np.abs(arr[:,1]-l)); return arr[k]
    R['unl3']=[dict(lam=l,eta=float(at(seg3,l)[4]),P=float(at(seg3,l)[7]),P0=float(at(seg3,l)[6]),W=float(at(seg3,l)[2])) for l in (2.5,2.0,1.5,1.2)]
    # loop area 1->3 unload ->1 reload ->3 : external work from the end of seg3 loading... use hysteresis area
    # ---------------- 3. other modes ----------------
    for mode,ends3 in ((2,[1.6,1.1,2.0,1.2,2.2,1.0]),(3,[2.0,1.3,3.0,1.5,3.5,1.0])):
        c=cycle('drv_or',mode,ends3,1000); R['mode%d'%mode]=analyse(c,mode)
    # cross-mode: preload uniaxial to lambda=3 (Wm), then equibiaxial from 1 to 1.8
    Wm3=float(Wf(1,3.0)); c=cycle('drv_or',2,[1.8],500,umax0=Wm3); np.save(os.path.join(O,'cyc_cross.npy'),c)
    R['cross']=dict(Wm=Wm3,**analyse(c,2,umax0=Wm3))
    # ---------------- 4. FD test of DETADW ----------------
    def fd(exe,um,w):
        o=run(exe,"3 %g %g %g\n%.16g %.16g\n"%(RR,MM,BB,um,w))
        rows=[l.split() for l in o.strip().split('\n')]
        return [(int(r[0]),float(r[1]),float(r[2]),float(r[3])) for r in rows]
    Wm=float(Wf(1,3.0))
    R['fd']={}
    for tag,exe in (('ok','fd_or'),('bug','fd_bug')):
        for w in (3.0,1.5):
            rows=fd(exe,Wm,w); R['fd']['%s_%g'%(tag,w)]=[r[3] for r in rows]; R['fd']['%s_%g_det'%(tag,w)]=rows[0][1]
    R['fd']['closed_3.0']=float(detaOR(Wm,3.0)); R['fd']['closed_1.5']=float(detaOR(Wm,1.5))
    # ---------------- 5. Newton ----------------
    P3=float(P0f(1,3.0)); Pn=float(P0f(1,3.5))
    hist=list(np.linspace(0,P3,9)[1:])+list(np.linspace(P3,0,11)[1:])+list(np.linspace(0,Pn,11)[1:])
    R['newt']={}
    for t in (1,2,3):
        inp="3 %g %g %g\n%g %g\n%d %d\n%s\n"%(RR,MM,BB,C10,C01,t,len(hist)," ".join("%.12f"%p for p in hist))
        d=os.path.join(O,'newt_%d'%t); o=run('newt_or',inp,d)
        lines=o.strip().split('\n')
        steps=[l.split() for l in lines if not l.startswith('TOTAL') and not l.startswith('ABORT')]
        R['newt'][t]=dict(out=lines[-1],steps=[[float(x) for x in s] for s in steps],hist=open(os.path.join(d,'out_hist.txt')).read() if os.path.exists(os.path.join(d,'out_hist.txt')) else '')
    # ---------------- 6. explicit ----------------
    run('drv_exp',"",os.path.join(O,'exp')); e=np.loadtxt(os.path.join(O,'exp','out_exp.txt'))
    R['exp']=dict(max_eta=float(np.max(np.abs(e[:,4]-e[:,5]))),max_det=float(np.max(np.abs(e[:,6]-e[:,7]))),max_dis=float(np.max(np.abs(e[:,8]-e[:,9]))),rows=e.tolist())
    # six sample points (table) and a uniaxial path (figure)
    pts=[(0.19,0.2,0.2),(0.79,0.8,0.8),(1.49,1.5,1.5),(2.99,3.0,3.0),(5.99,6.0,6.0),(6.0,6.0,2.0)]
    o=run('drv_vol',"1.5\n%d\n"%len(pts)+"\n".join("%g %g %g"%p for p in pts)+"\n",os.path.join(O,'vol'))
    v=np.loadtxt(os.path.join(O,'vol','out_vol.txt')); R['vol']=v.tolist()
    U0=5.0
    lam=np.concatenate([np.linspace(1,2,101),np.linspace(2,1.2,81)[1:],np.linspace(1.2,3,181)[1:],np.linspace(3,1,201)[1:]])
    Wp=Wf(1,lam); Um=np.maximum.accumulate(Wp); Uo=np.concatenate([[0],Um[:-1]])
    o=run('drv_vol',"%g\n%d\n"%(U0,len(lam))+"\n".join("%.16g %.16g %.16g"%(a,b,c) for a,b,c in zip(Uo,Um,Wp))+"\n",os.path.join(O,'volpath'))
    vp=np.loadtxt(os.path.join(O,'volpath','out_vol.txt'))
    P0=P0f(1,lam); dP0=2*(1+2*lam**-3)*(C10+C01/lam)-2*(lam-lam**-2)*C01/lam**2
    Pv=vp[:,2]*P0; tanv=vp[:,3]*P0*P0+vp[:,2]*dP0
    np.save(os.path.join(O,'vol_path.npy'),np.column_stack([lam,Wp,Um,vp[:,2],Pv,tanv,vp[:,5]]))
    R['volpath']=dict(U0=U0,eta_err=float(np.max(np.abs(vp[:,2]-np.exp(-Um/U0)))),
        D_err=float(np.max(np.abs(vp[:,5]-(U0*(1-np.exp(-Um/U0))-np.exp(-Um/U0)*Um)))),
        D_quad=float(np.max(np.abs(vp[:,5]-vp[:,6]))), etaend=float(vp[180+0,2]))
    # tangent check on the loading branches by central differences of the stress at fixed UMAXOLD
    h=1e-6*lam; Wpp=Wf(1,lam+h); Wpm=Wf(1,lam-h)
    def Pv_(l,w): return np.exp(-np.maximum(Uo,w)/U0)*P0f(1,l)
    tfd=(Pv_(lam+h,Wpp)-Pv_(lam-h,Wpm))/(2*h)
    msk=np.abs(Wp-Uo)>1e-9
    R['volpath']['tan_fd']=float(np.max((np.abs(tanv-tfd)/np.abs(tfd))[msk&(np.arange(len(lam))>0)]))
    # ---------------- 7. tanh law ----------------
    t_=cycle('drv_tanh',1,ends2,2000); R['tanh']=analyse(t_,1,etaTH,None,DTH); np.save(os.path.join(O,'cyc_tanh.npy'),t_)
    # ---------------- 8. bug routine ----------------
    gb=cycle('drv_bug',1,ends2,1000)
    R['bug']=dict(P_vs_ok=float(np.max(np.abs(gb[:,7]-b[::2][:len(gb),7]))/np.max(b[:,7])),
                  tan_vs_fd=float(np.max(np.abs(gb[:,8]-gb[:,9])/np.abs(gb[:,9]))))

    # ---------------- 8b. single-fault variants of the routine (Problem 5B.3) ----------------
    src=open('/home/claude/vol2/ch05/code/ex5_umullins_or.f').read()
    V=[("props order","      XM   = PROPS(2)\n      BETA = PROPS(3)\n","      BETA = PROPS(2)\n      XM   = PROPS(3)\n"),
       ("C from UMAXOLD","      C  = XM + BETA*UM\n","      C  = XM + BETA*UMAXOLD\n"),
       ("ERF(X/R)","ETA = 1.0D0 - ERF(X)/R","ETA = 1.0D0 - ERF(X/R)"),
       ("no 1/C","*EXP(-X*X)/(R*XSQPI*C)","*EXP(-X*X)/(R*XSQPI)"),
       ("no branch test","         DETADW = 0.0D0\n         IF (UMAXNEW .LE. UMAXOLD)\n     1      DETADW =","         DETADW ="),
       ("no 1/R in D","DMGDISSNEW = C/R*(FT","DMGDISSNEW = C*(FT")]
    R['variants']=[]
    A='/home/claude/vol2/lib/aba'
    ref=np.load(os.path.join(O,'cyc_ex551.npy'))
    for k,(nm,a_,b_) in enumerate(V):
        assert a_ in src,nm
        d=os.path.abspath(os.path.join(O,'bugs')); os.makedirs(d,exist_ok=True)
        open(os.path.join(d,'v%d.f'%k),'w').write(src.replace(a_,b_))
        subprocess.run('gfortran -ffixed-form -ffixed-line-length-none -std=legacy -I%s -o %s/v%d /home/claude/vol2/ch05/code/ex5_drv.f /home/claude/vol2/ch05/code/ex5_tools.f /home/claude/vol2/ch05/code/ex5_uhyper_mr.f v%d.f %s/stubs.f'%(A,d,k,k,A),shell=True,check=True,cwd=d,capture_output=True)
        exe='bugs/v%d'%k
        g=cycle(exe,1,ends2,2000)
        Pm=np.max(ref[:,7]); dP=float(np.max(np.abs(g[:,7]-ref[:,7]))/Pm)
        ok=np.abs(g[:,2]-np.concatenate([[0],g[:-1,3]]))>1e-9*np.maximum(g[:,2],1e-9)
        tanerr=float(np.max((np.abs(g[:,8]-g[:,9])/np.abs(g[:,9]))[ok]))
        net=g[:,11]+g[:,10]; werr=float(np.max(np.abs(g[1:,12]-net[1:]))/np.max(net))
        # FD test of DETADW at W=3.0 with a standalone FD driver
        subprocess.run('gfortran -ffixed-form -ffixed-line-length-none -std=legacy -I%s -o %s/f%d /home/claude/vol2/ch05/code/ex5_drv_fd.f v%d.f %s/stubs.f'%(A,d,k,k,A),shell=True,check=True,cwd=d,capture_output=True)
        o=subprocess.run(['%s/f%d'%(d,k)],input="3 %g %g %g\n%.16g 3.0\n"%(RR,MM,BB,Wm),capture_output=True,text=True).stdout.strip().split('\n')
        fde=float(o[4].split()[3]); scan=[float(l.split()[3]) for l in o]
        fdl=float(subprocess.run(['%s/f%d'%(d,k)],input="3 %g %g %g\n%.16g 3.0\n"%(RR,MM,BB,Wm),capture_output=True,text=True).stdout.strip().split('\n')[0].split()[1])
        g40=cycle(exe,1,ends2,40); dD=analyse(g40,1)['D_err']
        R['variants'].append(dict(name=nm,dP=dP,tan=tanerr,work=werr,fd=fde,dD40=dD,scan=scan))
    json.dump(R,open(os.path.join(O,'results.json'),'w'),indent=1,default=float)
    print(json.dumps(R['variants'],indent=1,default=float))
