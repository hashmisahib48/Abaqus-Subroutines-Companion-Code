import numpy as np, json
from scipy.special import erf
from scipy.optimize import least_squares
exec(open('check.py').read().split("def cycle")[0])
SQ=np.sqrt(np.pi)
F={}
# 5A.1
r,m,b,Um,U=3.0,0.5,0.0,2.0,1.2
c=m+b*Um; X=(Um-U)/c; F['5A1']=dict(eta=1-erf(X)/r,etamin=1-erf(Um/c)/r,det=2*np.exp(-X*X)/(r*SQ*c),X=X)
# 5A.2: neo-Hookean C10=0.4, r=2.5,m=0.8,b=0.1, lam_m=2.5 -> 1.8
C10n=0.4; r,m,b=2.5,0.8,0.1
Wn=lambda l:C10n*(l*l+2/l-3); Pn=lambda l:2*C10n*(l-l**-2)
Wm_=Wn(2.5); c=m+b*Wm_; eta=1-erf((Wm_-Wn(1.8))/c)/r
F['5A2']=dict(Wm=Wm_,c=c,W18=Wn(1.8),eta=eta,P0=Pn(1.8),P=eta*Pn(1.8),Pm=Pn(2.5),etamin=1-erf(Wm_/c)/r)
T=Wm_/c; Fn=lambda x:x*erf(x)+np.exp(-x*x)/SQ
F['5A3']=dict(D=c/r*(Fn(T)-1/SQ),Wm=Wm_,frac=c/r*(Fn(T)-1/SQ)/Wm_)
# 5B.1 tanh
Wm=Wf(1,3.0); c=MM+BB*Wm; T=Wm/c; F['5B1']=dict(D=c/RR*np.log(np.cosh(T)),c=c,T=T)
# 5B.2 tangent at lam=2 on unloading from 3, reference set
a=np.load('out/cyc_ex551.npy'); seg=a[3*2000:4*2000]
k=np.argmin(np.abs(seg[:,1]-2.0)); s=seg[k]
F['5B2']=dict(lam=s[1],eta=s[4],det=s[5],P0=s[6],P=s[7],dP=s[8],dP0=s[13],W=s[2])
# 5C.1
k=np.argmin(np.abs(seg[:,1]-1.5)); s=seg[k]; F['5C1']=dict(P15=s[7],eta15=s[4],P0_15=s[6])
k=np.argmin(np.abs(seg[:,1]-2.5)); s=seg[k]; F['5C1']['P25']=s[7]; F['5C1']['eta25']=s[4]
# 5C.2 calibration (beta=0), Um=3.644 : data (U, eta)
Umd=3.6444
data=np.array([[2.9,0.778],[2.4,0.669],[1.8,0.592],[1.2,0.559],[0.6,0.549],[0.0,0.546]])
def res(p):
    r_,m_=p; return 1-erf((Umd-data[:,0])/m_)/r_-data[:,1]
sol=least_squares(res,[2.0,1.5]); F['5C2']=dict(r=sol.x[0],m=sol.x[1],rms=float(np.sqrt(np.mean(sol.fun**2))),etamin=1-erf(Umd/sol.x[1])/sol.x[0])
# cross
c_=np.load('out/cyc_cross.npy'); F['cross']=dict(lam=c_[-1][1],W=c_[-1][2],eta=c_[-1][4],P=c_[-1][7],P0=c_[-1][6])
print(json.dumps(F,indent=1,default=float))
json.dump(F,open('out/facts.json','w'),indent=1,default=float)
